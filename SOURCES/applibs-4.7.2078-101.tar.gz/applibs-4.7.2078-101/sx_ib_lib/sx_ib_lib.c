/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sx_ib_lib.h"
#include "ibl2/ib_port.h"
#include "tcal3/ib_tca.h"
#include "tcal3/ib_tca_db.h"
#include "ibl3/ib_router.h"
#include "ibl3/ib_router_mc.h"
#include "ibl3/router_attr_db.h"
#include "../sx_core/sx_core_cmd_db.h"
#include "../sx_api/sx_api_internal.h"
#include "../sx_api_ib/sx_api_ib_internal.h"
#include <include/resource_manager/resource_manager.h>


#ifndef __SX_IB_LIB__
#define __SX_IB_LIB__

#undef  __MODULE__
#define __MODULE__ SX_IB_LIB

/*************************************************
 *  Local Functions
 ************************************************/
static sx_status_t __ib_router_init_param(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                          uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ib_router_interface_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                             uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ib_router_interface_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                             uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ib_router_neigh_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                         uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ib_router_neigh_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                         uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ib_router_mc_egress_rif_set(sx_core_td_event_src_t *event,
                                                 uint8_t                *cmd_body,
                                                 uint32_t                cmd_body_size) __attribute__((used));
static sx_status_t __ib_router_mc_egress_rif_get(sx_core_td_event_src_t *event,
                                                 uint8_t                *cmd_body,
                                                 uint32_t                cmd_body_size) __attribute__((used));
static sx_status_t __ib_router_attributes_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                              uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ib_router_attributes_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                              uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ib_tca_port_state_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                           uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ib_tca_port_state_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                           uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ib_port_init(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                  uint32_t cmd_body_size) __attribute__((used));

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static sx_api_command_t sx_core_api_ib_cmd_table[] = {
    {SX_API_INT_CMD_IB_ROUTER_INIT_E, "SX_API_INT_CMD_IB_INIT_E", __ib_router_init_param, SX_API_PROTOCOL_IB_E,
     SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_ROUTER_INTERFACE_SET_E, "SX_API_INT_CMD_IB_ROUTER_INTERFACE_SET_E", __ib_router_interface_set,
     SX_API_PROTOCOL_IB_E,   SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_ROUTER_INTERFACE_GET_E, "SX_API_INT_CMD_IB_ROUTER_INTERFACE_GET_E", __ib_router_interface_get,
     SX_API_PROTOCOL_IB_E,   SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_ROUTER_NEIGH_SET_E, "SX_API_INT_CMD_IB_ROUTER_NEIGH_SET_E", __ib_router_neigh_set,
     SX_API_PROTOCOL_IB_E,   SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_ROUTER_NEIGH_GET_E, "SX_API_INT_CMD_IB_ROUTER_NEIGH_GET_E", __ib_router_neigh_get,
     SX_API_PROTOCOL_IB_E,   SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_ROUTER_MC_EGRESS_RIF_SET_E, "SX_API_INT_CMD_IB_ROUTER_MC_EGRESS_RIF_SET_E",
     __ib_router_mc_egress_rif_set, SX_API_PROTOCOL_IB_E,   SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_ROUTER_MC_EGRESS_RIF_GET_E, "SX_API_INT_CMD_IB_ROUTER_MC_EGRESS_RIF_GET_E",
     __ib_router_mc_egress_rif_get, SX_API_PROTOCOL_IB_E, SX_API_CMD_PRIO_HIGH_E,  ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_ROUTER_ATTRIBUTES_SET_E, "SX_API_INT_CMD_IB_TCA_SET_E", __ib_router_attributes_set,
     SX_API_PROTOCOL_IB_E,   SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_ROUTER_ATTRIBUTES_GET_E, "SX_API_INT_CMD_IB_TCA_GET_E", __ib_router_attributes_get,
     SX_API_PROTOCOL_IB_E,   SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_TCA_PORT_STATE_SET_E, "SX_API_INT_CMD_IB_TCA_PORT_STATE_SET_E", __ib_tca_port_state_set,
     SX_API_PROTOCOL_IB_E,   SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_TCA_PORT_STATE_GET_E, "SX_API_INT_CMD_IB_TCA_PORT_STATE_GET_E", __ib_tca_port_state_get,
     SX_API_PROTOCOL_IB_E,   SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_IB_PORT_INIT_E, "SX_API_INT_CMD_IB_PORT_INIT_E", __ib_port_init, SX_API_PROTOCOL_IB_E,
     SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP},
    {SX_API_INT_CMD_NUM_E, "", NULL, SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, ALL_ACTIVE_IB_ASIC_BITMAP}                                                                                                               /* NULL Entry. Keep at end!! */
};

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
int sx_ib_lib_init(sx_ib_lib_init_params_t* params, sxd_chip_types_t asic_type)
{
    int               i = 0;
    sx_api_command_t* cmd = &sx_core_api_ib_cmd_table[i++];
    sx_status_t       err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(params);
    SX_LOG(SX_LOG_DEBUG, " system ASIC bit="BYTE_TO_BINARY_PATTERN,  BYTE_TO_BINARY((uint32_t)(1UL << asic_type)));

    do {
        if ((cmd->supported_asic_types) & (1UL << asic_type)) {
            SX_LOG(SX_LOG_DEBUG, "i=%d Add cmd %s to IB Lib CMD table.\n", i, cmd->name);

            err = sx_core_set_api_command(cmd);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ib api cmd initialization failed \n");
                goto out;
            }
        } else {
            SX_LOG(SX_LOG_DEBUG, "Supported ASIC bitmap="BYTE_TO_BINARY_PATTERN,
                   BYTE_TO_BINARY((uint32_t)(cmd->supported_asic_types)));
            SX_LOG(SX_LOG_DEBUG, "Skip adding unsupported cmd %s to SX Router table.\n", cmd->name);
        }
        cmd = &sx_core_api_ib_cmd_table[i++];
    } while (cmd->cmd_id != SX_API_INT_CMD_NUM_E);

    ib_port_init();

    SX_LOG_INF("IB LIB is loaded\n");

out:
    return (int)err;
}


int sx_ib_l3_init(sx_router_params_t *router_init_params)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_INF("IB LIB is loaded\n");
    UNUSED_PARAM(router_init_params);

    err = ib_tca_port_state_init();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ib L3 initialization failed \n");
        goto out;
    }
out:
    return (int)err;
}

int sx_ib_l3_deinit()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = sx_ib_deinit_router();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ib L3 router deinit failed \n");
        goto out;
    }

    err = ib_tca_port_state_deinit();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ib TCA deinitialization failed \n");
        goto out;
    }


out:
    return (int)err;
}

static sx_status_t __ib_router_init_param(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_vpi_router_init_params_t *params = NULL;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_vpi_router_init_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_vpi_router_init_params_t*)cmd_body;

    err = ib_router_init_param(&(params->general_params_p), &(params->router_resource_p));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_vpi_router_init_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_interface_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_ib_router_interface_set_params_t *params = NULL;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_ib_router_interface_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_router_interface_set_params_t*)cmd_body;
    if (params->vrid > rm_resource_global.router_vrid_max) {
        SX_LOG(SX_LOG_ERROR, "params->vrid [%d] exceeds range [%d] \n",
               params->vrid, rm_resource_global.router_vrid_max);
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    if ((params->cmd == SX_ACCESS_CMD_ADD) || (params->cmd == SX_ACCESS_CMD_EDIT)) {
        if (params->l2_ibifc.pkey < IB_ROUTER_PKEYS_ID_MIN) {
            SX_LOG(SX_LOG_ERROR, "params->l2_ibifc.pkey [%d] exceeds range [%d] \n",
                   params->l2_ibifc.pkey, IB_ROUTER_PKEYS_ID_MIN);
            err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
            goto out;
        }

        if (params->l2_ibifc.qpn > IB_ROUTER_QPN_MAX) {
            SX_LOG(SX_LOG_ERROR, "params->l2_ibifc.qpn [%d] exceeds range [%d] \n",
                   params->l2_ibifc.qpn, IB_ROUTER_QPN_MAX);
            err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
            goto out;
        }
    }


    err = ib_router_interface_set(params->cmd, params->vrid, &(params->l2_ibifc),
                                  &(params->rif));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_ib_router_interface_set_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_interface_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_ib_router_interface_get_params_t *params = NULL;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_ib_router_interface_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_router_interface_get_params_t*)cmd_body;

    err = ib_router_interface_get(params->rif, &(params->vrid), &(params->l2_ibifc));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_ib_router_interface_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __ib_router_neigh_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_ib_router_neigh_set_params_t *params = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_ib_router_neigh_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_router_neigh_set_params_t*)cmd_body;

    if ((params->action == SX_ROUTER_ACTION_FORWARD) &&
        ((params->cmd == SX_ACCESS_CMD_EDIT) || (params->cmd == SX_ACCESS_CMD_ADD))) {
        if ((params->adj_param.dlid > IB_ROUTER_UC_LID_MAX) ||
            (params->adj_param.dlid < IB_ROUTER_UC_LID_MIN) ||
            (params->adj_param.dqpn > IB_ROUTER_QPN_MAX) ||
            (SX_UC_MYLID_CHECK_RANGE(params->adj_param.my_lid) != TRUE)) {
            err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
            goto out;
        }
    }


    err = ib_router_neigh_set(params->cmd, params->vrid, &(params->ip_addr),
                              &(params->adj_param), params->action, params->rif);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_neigh_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_ib_router_neigh_get_params_t *params = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_ib_router_neigh_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_router_neigh_get_params_t*)cmd_body;

    err = ib_router_neigh_get(params->cmd, params->vrid, &(params->ip_addr),
                              &(params->adj_param), &(params->rif), &(params->activity));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_ib_router_neigh_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __ib_router_mc_egress_rif_set(sx_core_td_event_src_t *event,
                                                 uint8_t                *cmd_body,
                                                 uint32_t                cmd_body_size)
{
    uint32_t                                     size = 0;
    sx_api_ib_router_mc_egress_rif_set_params_t *params = NULL;
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    uint32_t                                     i = 0;

    if (cmd_body_size < sizeof(sx_api_ib_router_mc_egress_rif_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_router_mc_egress_rif_set_params_t*)cmd_body;

    if ((params->ingress_rif >= rm_resource_global.router_rifs_max) &&
        (params->ingress_rif != rm_resource_global.router_rifs_dontcare)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    if (params->cmd != SX_ACCESS_CMD_DELETE_ALL) {
        for (i = 0; i < params->adj_num; i++) {
            if (
                (params->mc_ipoib_adj_arr[i].mlid > IB_ROUTER_MC_LID_MAX) ||
                (params->mc_ipoib_adj_arr[i].mlid < IB_ROUTER_MC_LIDS_MIN)
                ) {
                err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
                goto out;
            }
        }
    }

    size = sizeof(sx_api_ib_router_mc_egress_rif_set_params_t) +
           (params->adj_num * sizeof(sx_mc_ipoib_adj_t));

    if (cmd_body_size != size) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = ib_router_mc_egress_set(params->cmd,
                                  params->vrid,
                                  &(params->source_addr),
                                  &(params->mc_group_addr),
                                  params->ingress_rif,
                                  params->adj_num,
                                  params->mc_ipoib_adj_arr);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_mc_egress_rif_get(sx_core_td_event_src_t *event,
                                                 uint8_t                *cmd_body,
                                                 uint32_t                cmd_body_size)
{
    uint32_t                                     size = 0;
    sx_api_ib_router_mc_egress_rif_get_params_t *params = NULL;
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    uint32_t                                     adj_num;

    if (cmd_body_size < sizeof(sx_api_ib_router_mc_egress_rif_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_router_mc_egress_rif_get_params_t*)cmd_body;
    adj_num = params->adj_num;

    if ((params->ingress_rif >= rm_resource_global.router_rifs_max) &&
        (params->ingress_rif != rm_resource_global.router_rifs_dontcare)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    err = ib_router_mc_egress_get(params->vrid, &(params->source_addr), &(params->mc_group_addr), params->ingress_rif,
                                  &(params->adj_num), params->mc_ipoib_adj_arr);

    /* if adj_num==0 than counter was asked so params->adj_num still contains counter */
    if (adj_num != 0) {
        params->adj_num = MIN(params->adj_num, adj_num);
        adj_num = params->adj_num;
    }

    size = sizeof(sx_api_ib_router_mc_egress_rif_get_params_t) +
           (adj_num * sizeof(sx_mc_ipoib_adj_t));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __ib_router_attributes_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_ib_router_set_attr_t *params = NULL;
    sx_status_t                  err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_ib_router_set_attr_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_router_set_attr_t*)cmd_body;

    if (params->swid > rm_resource_global.swid_id_max) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        return err;
    }

    if (params->sx_ib_router_attr.lmc_valid) {
        if (params->sx_ib_router_attr.lmc > IB_ROUTER_LMC_MAX) {
            err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
            return err;
        }
    }

    if (params->sx_ib_router_attr.lid_valid) {
        if ((params->sx_ib_router_attr.lid > rm_resource_global.ib_router_lids_max) ||
            (params->sx_ib_router_attr.lid == 0)) {
            err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
            return err;
        }
    }


    err = ib_router_attributes_set(params->swid, params->cmd, &(params->sx_ib_router_attr));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_attributes_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_ib_router_get_attr_t *params = NULL;
    sx_status_t                  err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_ib_router_get_attr_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_router_get_attr_t*)cmd_body;

    if (params->swid > rm_resource_global.swid_id_max) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        return err;
    }
    err = ib_router_attributes_get(params->swid, &(params->sx_ib_router_attr));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_ib_router_get_attr_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_tca_port_state_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_ib_tca_port_state_set_params_t *params = NULL;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_ib_tca_port_state_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_tca_port_state_set_params_t*)cmd_body;
    if (params->swid > rm_resource_global.swid_id_max) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        return err;
    }
    err = ib_tca_port_state_set(params->swid, &(params->sx_ib_tca_port_state_params));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_tca_port_state_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_ib_tca_port_state_get_params_t *params = NULL;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_ib_tca_port_state_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_tca_port_state_get_params_t*)cmd_body;

    err = ib_tca_port_state_get(params->swid, &(params->sx_ib_tca_port_state_params));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_ib_tca_port_state_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_port_init(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_ib_port_init_params_t *params = NULL;
    sx_status_t                   err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_ib_port_init_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_ib_port_init_params_t*)cmd_body;

    if (params->ib_port > rm_resource_global.ib_ports_max) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    err = ib_port_internal_init(params->log_port, params->ib_port);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_ib_port_init_params_t));

out:
    SX_LOG_EXIT();
    return err;
}


#endif /* ifndef __SX_IB_LIB__ */
