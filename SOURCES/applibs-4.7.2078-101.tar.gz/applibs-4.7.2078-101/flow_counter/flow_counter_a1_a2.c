/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <complib/cl_list.h>

#include <sx/sxd/sxd_access_register.h>

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "ethl2/port.h"
#include "utils/sx_adviser.h"
#include "ethl2/topo.h"
#include "flow_counter/flow_counter.h"

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ FLOW_COUNTER

/************************************************
 *  Global variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local defines
 ***********************************************/

#define FLOW_COUNTER_DB_MAX_ALLOCATE           255
#define FLOW_COUNTER_BYTES_TYPE_MAX_ALLOCATE   204
#define FLOW_COUNTER_PACKETS_TYPE_MAX_ALLOCATE 255

typedef struct flow_counter_db {
    cl_list_t flow_counter_list;
    cl_list_t flow_counter_byte_type_pre_allocated_list;
    cl_list_t flow_counter_packet_type_pre_allocated_list;
    uint32_t  num_of_pre_allocted_byte_counters;
    uint32_t  num_of_pre_allocted_packet_counters;
    uint32_t  num_of_counters;
} flow_counter_db_t;

typedef struct {
    sx_flow_counter_id_t cntr_id;
} flow_counter_pre_allocated_pool_entry_t;

/************************************************
 *  Local variables
 ***********************************************/

/* global counter id */
static sx_flow_counter_id_t       g_counter_id = 1;
static uint32_t                   g_bytes_flow_counter_count = 0;
static uint32_t                   g_packets_flow_counter_count = 0;
static flow_counter_db_t          flow_counter_db;
static flow_counter_global_attr_t g_flow_counter_global_attr;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __flow_counter_get_all_devs_list(sx_dev_id_t *devs_list,
                                                    uint16_t    *devs_count);
static sx_status_t __create_counter(flow_counter_attr_t **attr);
static sx_status_t __destroy_counter(flow_counter_attr_t *flow_counter_attr);
static sx_status_t __get_counter(flow_counter_attr_t   *flow_counter_attr,
                                 sx_flow_counter_set_t *p_counter_set);
static sx_status_t __clear_counter(flow_counter_attr_t *flow_counter_attr);
static sx_status_t __flow_counter_device_ready_callback(adviser_event_e event_type,
                                                        void           *param);

/************************************************
 *  Function implementations
 ***********************************************/
static sx_status_t __create_counter(flow_counter_attr_t **attr)
{
    sxd_status_t       sxd_status;
    int                err = SX_STATUS_SUCCESS;
    sx_dev_id_t        devs_list[SX_DEV_NUM_MAX];
    uint16_t           devs_count = 0;
    int                dev_idx;
    struct ku_pfca_reg pfca;
    sxd_reg_meta_t     meta;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pfca);

    flow_counter_attr_t *flow_counter_attr = *attr;

    if (flow_counter_attr->counter_type == SX_FLOW_COUNTER_TYPE_BYTES) {
        /* Check if pre allocated pool */
        if (0 < flow_counter_db.num_of_pre_allocted_byte_counters) {
            *attr = (flow_counter_attr_t*)cl_list_remove_head(
                &flow_counter_db.flow_counter_byte_type_pre_allocated_list);
            if (NULL == *attr) {
                SX_LOG_ERR("Flow Counter : Failed to get bytes flow counter from pre allocated pool\n");
                return SX_STATUS_ERROR;
            }

            flow_counter_attr = *attr;
            flow_counter_attr->pre_allocated = 0;
            flow_counter_db.num_of_pre_allocted_byte_counters--;
            goto out;
        }
    } else if (flow_counter_attr->counter_type == SX_FLOW_COUNTER_TYPE_PACKETS) {
        /* Check if pre allocated pool */
        if (0 < flow_counter_db.num_of_pre_allocted_packet_counters) {
            *attr = (flow_counter_attr_t*)cl_list_remove_head(
                &flow_counter_db.flow_counter_packet_type_pre_allocated_list);
            if (NULL == *attr) {
                SX_LOG_ERR("Flow Counter : Failed to get packet flow counter from pre allocated pool\n");
                return SX_STATUS_ERROR;
            }

            flow_counter_attr = *attr;
            flow_counter_attr->pre_allocated = 0;
            flow_counter_db.num_of_pre_allocted_packet_counters--;
            goto out;
        }
    } else {
        return SX_STATUS_PARAM_ERROR;
    }
    pfca.type = flow_counter_attr->counter_type;
    pfca.index = flow_counter_attr->flow_counter_id;
    pfca.flow_counter_handle = 0;

    /* Prepare a list of relevant devices */
    __flow_counter_get_all_devs_list(devs_list, &devs_count);

    flow_counter_attr->allocated = 1;
    flow_counter_attr->bounded_rules_num = 0;

    SX_MEM_CLR(flow_counter_attr->flow_counter_handle);

    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        pfca.op = SXD_PFCA_OP_ALLOCATE;
        meta.access_cmd = SXD_ACCESS_CMD_SET;
        meta.dev_id = devs_list[dev_idx];
        meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PFCA_E, &pfca, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Flow Counter : Failed to create flow counter entry SXD err [%u] dev_id [%u]\n",
                       sxd_status,
                       dev_idx);
            err = sxd_status_to_sx_status(sxd_status);
            goto out;
        }

        /*SX_LOG_ERR("Flow Counter : flow counter id %u == flow counter handle [%x] dev_idx %d\n",counter_id,pfca.flow_counter_handle,dev_idx);*/
        /* store the flow counter handle */
        flow_counter_attr->flow_counter_handle[devs_list[dev_idx]] = pfca.flow_counter_handle;
    }

    flow_counter_db.num_of_counters++;

    if (flow_counter_attr->counter_type == SX_FLOW_COUNTER_TYPE_BYTES) {
        g_bytes_flow_counter_count++;
    } else if (flow_counter_attr->counter_type == SX_FLOW_COUNTER_TYPE_PACKETS) {
        g_packets_flow_counter_count++;
    }

out:
    if (err != SX_STATUS_SUCCESS) {
        /* deallocate created counters */
        dev_idx--;
        while (dev_idx >= 0) {
            pfca.op = SXD_PFCA_OP_FREE;
            meta.access_cmd = SXD_ACCESS_CMD_SET;
            meta.dev_id = devs_list[dev_idx];
            meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PFCA_E, &pfca, &meta, 1, NULL, NULL);
            if (sxd_status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Flow Counter : Failed to destroy flow counter entry SXD err [%u] dev id [%u]\n",
                           sxd_status,
                           dev_idx);
            }
            dev_idx--;
        }
    }
    return err;
}

static sx_status_t __destroy_counter(flow_counter_attr_t *attr)
{
    sxd_status_t       sxd_status;
    int                err = SX_STATUS_SUCCESS;
    sx_dev_id_t        devs_list[SX_DEV_NUM_MAX];
    uint16_t           devs_count = 0;
    uint32_t           dev_idx;
    struct ku_pfca_reg pfca;
    sxd_reg_meta_t     meta;
    cl_status_t        cl_status;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pfca);

    if (attr->counter_type == SX_FLOW_COUNTER_TYPE_BYTES) {
        /* Check if pre allocated pool */
        if (g_flow_counter_global_attr.flow_counter_byte_type_min_number >
            flow_counter_db.num_of_pre_allocted_byte_counters) {
            cl_status = cl_list_insert_tail(&flow_counter_db.flow_counter_byte_type_pre_allocated_list, (void*)attr);
            if (CL_SUCCESS != cl_status) {
                SX_LOG_ERR("Flow Counter : Failed to insert flow counter to internal pre allocated db CL err [%u]\n",
                           cl_status);
                return SX_STATUS_ERROR;
            }

            attr->pre_allocated = 1;
            flow_counter_db.num_of_pre_allocted_byte_counters++;
            goto out;
        }
    } else if (attr->counter_type == SX_FLOW_COUNTER_TYPE_PACKETS) {
        /* Check if pre allocated pool */
        if (g_flow_counter_global_attr.flow_counter_packet_type_min_number >
            flow_counter_db.num_of_pre_allocted_packet_counters) {
            cl_status = cl_list_insert_tail(&flow_counter_db.flow_counter_packet_type_pre_allocated_list, (void*)attr);
            if (CL_SUCCESS != cl_status) {
                SX_LOG_ERR("Flow Counter : Failed to insert flow counter to internal pre allocated db CL err [%u]\n",
                           cl_status);
                return SX_STATUS_ERROR;
            }

            attr->pre_allocated = 1;
            flow_counter_db.num_of_pre_allocted_packet_counters++;
            goto out;
        }
    } else {
        return SX_STATUS_PARAM_ERROR;
    }

    pfca.type = attr->counter_type;
    pfca.index = attr->flow_counter_id;
    pfca.flow_counter_handle = 0;

    /* Prepare a list of relevant devices */
    __flow_counter_get_all_devs_list(devs_list, &devs_count);

    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        pfca.op = SXD_PFCA_OP_FREE;
        pfca.flow_counter_handle = attr->flow_counter_handle[devs_list[dev_idx]];
        meta.access_cmd = SXD_ACCESS_CMD_SET;
        meta.dev_id = devs_list[dev_idx];
        meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PFCA_E, &pfca, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Flow Counter : Failed to destroy flow counter entry SXD err [%u]\n", sxd_status);
            err = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }


    attr->allocated = 0;
    flow_counter_db.num_of_counters--;

    if (attr->counter_type == SX_FLOW_COUNTER_TYPE_BYTES) {
        g_bytes_flow_counter_count--;
    } else if (attr->counter_type == SX_FLOW_COUNTER_TYPE_PACKETS) {
        g_packets_flow_counter_count--;
    }

out:
    return err;
}

static sx_status_t __get_counter(flow_counter_attr_t *flow_counter_attr, sx_flow_counter_set_t *p_counter_set)
{
    sxd_status_t        sxd_status;
    int                 err = SX_STATUS_SUCCESS;
    sx_dev_id_t         devs_list[SX_DEV_NUM_MAX];
    uint16_t            devs_count = 0;
    uint32_t            dev_idx;
    struct ku_pfcnt_reg pfcnt;
    sxd_reg_meta_t      meta;
    uint64_t            counter_value = 0;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pfcnt);

    p_counter_set->flow_counter_bytes = 0;
    p_counter_set->flow_counter_packets = 0;

    pfcnt.clr = 0;

    /* Prepare a list of relevant devices */
    __flow_counter_get_all_devs_list(devs_list, &devs_count);

    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        pfcnt.flow_counter_handle = flow_counter_attr->flow_counter_handle[devs_list[dev_idx]];
        meta.access_cmd = SXD_ACCESS_CMD_GET;
        meta.dev_id = devs_list[dev_idx];
        /* SX_LOG_ERR("Flow Counter : get flow counter handle [%x] dev_idx %d\n",pfcnt.flow_counter_handle,dev_idx); */
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PFCNT_E, &pfcnt, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Flow Counter : Failed to get flow counter value SXD err [%u]\n", sxd_status);
            err = sxd_status_to_sx_status(sxd_status);
            goto out;
        }

        counter_value += pfcnt.flow_counter;
    }

    switch (flow_counter_attr->counter_type) {
    case SX_FLOW_COUNTER_TYPE_BYTES:
        p_counter_set->flow_counter_bytes = counter_value;
        break;

    case SX_FLOW_COUNTER_TYPE_PACKETS:
        p_counter_set->flow_counter_packets = counter_value;
        break;

    default:
        SX_LOG_ERR("Flow Counter : Invalid counter type [%u]\n", flow_counter_attr->counter_type);
        return SX_STATUS_ERROR;
    }

out:

    return err;
}

static sx_status_t __clear_counter(flow_counter_attr_t *flow_counter_attr)
{
    sxd_status_t        sxd_status;
    int                 err = SX_STATUS_SUCCESS;
    sx_dev_id_t         devs_list[SX_DEV_NUM_MAX];
    uint16_t            devs_count = 0;
    uint32_t            dev_idx;
    struct ku_pfcnt_reg pfcnt;
    sxd_reg_meta_t      meta;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pfcnt);

    pfcnt.clr = 1;

    /* Prepare a list of relevant devices */
    __flow_counter_get_all_devs_list(devs_list, &devs_count);


    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        pfcnt.flow_counter_handle = flow_counter_attr->flow_counter_handle[devs_list[dev_idx]];
        meta.access_cmd = SXD_ACCESS_CMD_GET;
        meta.dev_id = devs_list[dev_idx];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PFCNT_E, &pfcnt, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Flow Counter : Failed to set vlan group entry SXD err [%u]\n", sxd_status);
            err = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }

out:
    return err;
}

/**
 * Get Device List (All Devices in the system)
 */
static sx_status_t __flow_counter_get_all_devs_list(sx_dev_id_t *devs_list, uint16_t *devs_count)
{
    sx_status_t   err = SX_STATUS_SUCCESS;
    sx_dev_info_t leaf_filter = {
        .dev_id = 0,
        .node_type = SX_DEV_NODE_TYPE_LEAF,
    };
    length_t      dev_info_arr_size = SX_DEV_ID_MAX;
    sx_dev_info_t dev_info_arr[SX_DEV_NUM_MAX];
    length_t      dev_idx = 0;

    *devs_count = 0;

    err = topo_device_tbl_bulk_get(SX_ACCESS_CMD_GET, &leaf_filter, dev_info_arr, &dev_info_arr_size);
    for (dev_idx = 0; dev_idx < dev_info_arr_size; dev_idx++) {
        devs_list[*devs_count] = dev_info_arr[dev_idx].dev_id;
        *devs_count += 1;
    }
    return err;
}

static sx_status_t __flow_counter_device_ready_callback(adviser_event_e event_type, void *param)
{
    int err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(event_type);
    UNUSED_PARAM(param);

    SX_LOG_EXIT();
    return err;
}

static sx_status_t sx_flow_counter_set(const sx_access_cmd_t        cmd,
                                       const sx_flow_counter_type_t cntr_type,
                                       sx_flow_counter_id_t        *cntr_id)
{
    cl_list_iterator_t   itor, list_end;
    boolean_t            found = FALSE;
    flow_counter_attr_t *attr = NULL;
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_status_t          mem_status = SX_STATUS_SUCCESS;
    cl_status_t          cl_status;

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:

        /* validate flow counter type */
        if (FALSE == SX_FLOW_COUNTER_CHECK_TYPE(cntr_type)) {
            SX_LOG_ERR("Flow Counter : Incorrect flow counter type.\n");
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }

        if (cntr_type == SX_FLOW_COUNTER_TYPE_BYTES) {
            /* validate max number of flow counters */
            if (g_bytes_flow_counter_count >= g_flow_counter_global_attr.flow_counter_byte_type_max_number) {
                SX_LOG_ERR("Flow Counter : Not enough resource max number of bytes flow counter "
                           "in the system is %d.\n", g_flow_counter_global_attr.flow_counter_byte_type_max_number);
                return SX_STATUS_NO_RESOURCES;
            }
        } else if (cntr_type == SX_FLOW_COUNTER_TYPE_PACKETS) {
            if (g_packets_flow_counter_count >= g_flow_counter_global_attr.flow_counter_packet_type_max_number) {
                SX_LOG_ERR("Flow Counter : Not enough resource max number of packets flow counter "
                           "in the system is %d.\n", g_flow_counter_global_attr.flow_counter_packet_type_max_number);
                return SX_STATUS_NO_RESOURCES;
            }
        }

        /* Iterate over the flow counter db*/
        itor = cl_list_head(&flow_counter_db.flow_counter_list);
        list_end = cl_list_end(&flow_counter_db.flow_counter_list);
        while (itor != list_end) {
            attr = (flow_counter_attr_t*)cl_list_obj(itor);

            if (attr->allocated == 0) {
                /* Save counter_id and clear the entry from the db */
                /* clear out attr from db */

                found = TRUE;
                attr->counter_type = cntr_type;
                sx_status = __create_counter(&attr);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Flow Counter : Failed to create flow counter entry.\n");
                    goto out;
                }

                *cntr_id = attr->flow_counter_id;

                break;
            }
            itor = cl_list_next(itor);
        }

        if (found == FALSE) {
            sx_status = utils_clr_memory_get((void**)(&attr),
                                             1,
                                             sizeof(flow_counter_attr_t),
                                             UTILS_MEM_TYPE_ID_FLOW_COUNTER_E);
            SX_CHECK_RC(sx_status, "Allocate Flow Counter attributes");
            if (sx_status != SX_STATUS_SUCCESS) {
                goto out;
            }

            attr->counter_type = cntr_type;
            attr->flow_counter_id = g_counter_id;

            /* Flow is not exist */
            sx_status = __create_counter(&attr);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Flow Counter : Failed to create flow counter entry.\n");
                mem_status = utils_memory_put(attr, UTILS_MEM_TYPE_ID_FLOW_COUNTER_E);
                SX_CHECK_RC(mem_status, "Free Flow Counter attributes");
                goto out;
            }

            cl_status = cl_list_insert_tail(&flow_counter_db.flow_counter_list, (void*)attr);
            if (CL_SUCCESS != cl_status) {
                SX_LOG_ERR("Flow Counter : Failed to insert flow counter to internal db CL err [%u]\n", cl_status);
                sx_status = SX_STATUS_ERROR;
                goto out;
            }

            g_counter_id++;
            /* Return the counter id to the user */
            *cntr_id = attr->flow_counter_id;
        }

        break;

    case SX_ACCESS_CMD_DESTROY:

        itor = cl_list_head(&flow_counter_db.flow_counter_list);
        list_end = cl_list_end(&flow_counter_db.flow_counter_list);
        while (itor != list_end) {
            attr = (flow_counter_attr_t*)cl_list_obj(itor);
            if ((attr->flow_counter_id == *cntr_id) && (attr->allocated == 1)) {
                found = TRUE;
                /* Check bounded rules */
                if (attr->bounded_rules_num != 0) {
                    /* Counter is bounded. cannot be destroyed */
                    sx_status = SX_STATUS_RESOURCE_IN_USE;
                } else {
                    sx_status = __destroy_counter(attr);
                    SX_CHECK_RC(sx_status, "Destroy Flow Counter");
                }

                break;
            }
            itor = cl_list_next(itor);
        }

        if (found == FALSE) {
            /* Flow is not exist */
            sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        }
        break;

    default:
        /* cmd not supported */
        return SX_STATUS_CMD_UNSUPPORTED;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t sx_flow_counter_get(const sx_flow_counter_id_t cntr_id, sx_flow_counter_set_t     *cntr_set)
{
    cl_list_iterator_t itor, list_end;
    boolean_t          found = FALSE;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Iterate over the flow counter db*/
    itor = cl_list_head(&flow_counter_db.flow_counter_list);
    list_end = cl_list_end(&flow_counter_db.flow_counter_list);
    while (itor != list_end) {
        flow_counter_attr_t* attr = (flow_counter_attr_t*)cl_list_obj(itor);

        /* is there a match in flow counter DB for the flow counter id ? */
        if (attr->flow_counter_id == cntr_id) {
            if (attr->allocated) {
                found = TRUE;
                sx_status = __get_counter(attr, cntr_set);
            }
            break;
        }

        itor = cl_list_next(itor);
    }

    if (found == FALSE) {
        /* Error , Flow counter is not created */
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("flow Counter Id %u does not exist\n", cntr_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static boolean_t sx_flow_estimator_counting_is_enabled()
{
    return FALSE;
}

static sx_status_t sx_flow_estimator_counter_get(const sx_access_cmd_t            cmd,
                                                 const sx_flow_counter_id_t       cntr_id,
                                                 sx_flow_estimator_counter_set_t *cntr_set_p)
{
    UNUSED_PARAM(cmd);
    UNUSED_PARAM(cntr_id);
    UNUSED_PARAM(cntr_set_p);

    SX_LOG_ERR("sx_flow_estimator_counter_get is not support.\n");
    return SX_STATUS_CMD_UNSUPPORTED;
}

static sx_status_t sx_flow_counter_iter_get(const sx_access_cmd_t           cmd,
                                            const sx_flow_counter_id_t      counter_id_key,
                                            const sx_flow_counter_filter_t *counter_id_filter_p,
                                            sx_flow_counter_id_t           *counter_id_list_p,
                                            uint32_t                       *counter_id_cnt_p)
{
    UNUSED_PARAM(cmd);
    UNUSED_PARAM(counter_id_key);
    UNUSED_PARAM(counter_id_filter_p);
    UNUSED_PARAM(counter_id_list_p);
    UNUSED_PARAM(counter_id_cnt_p);

    SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
               cmd, sx_access_cmd_str(cmd),
               sx_status_str(SX_STATUS_CMD_UNSUPPORTED));
    return SX_STATUS_CMD_UNSUPPORTED;
}

static sx_status_t sx_flow_counter_clear(const sx_flow_counter_id_t cntr_id)
{
    cl_list_iterator_t itor, list_end;
    boolean_t          found = FALSE;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    /* Iterate over the flow counter db*/
    itor = cl_list_head(&flow_counter_db.flow_counter_list);
    list_end = cl_list_end(&flow_counter_db.flow_counter_list);
    while (itor != list_end) {
        flow_counter_attr_t* attr = (flow_counter_attr_t*)cl_list_obj(itor);

        if (attr->flow_counter_id == cntr_id) {
            if (attr->allocated) {
                found = TRUE;
                sx_status = __clear_counter(attr);
            }
            break;
        }

        itor = cl_list_next(itor);
    }

    if (found == FALSE) {
        /* Error , Flow counter is not created */
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sx_flow_counter_get_flow_counter_attr_from_flow_counter_id(sx_flow_counter_id_t  flow_counter_id,
                                                                       flow_counter_attr_t **flow_counter_attr)
{
    cl_list_iterator_t itor, list_end;
    boolean_t          found = FALSE;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *flow_counter_attr = NULL;

    /* Iterate over the flow counter db*/
    itor = cl_list_head(&flow_counter_db.flow_counter_list);
    list_end = cl_list_end(&flow_counter_db.flow_counter_list);
    while (itor != list_end) {
        flow_counter_attr_t *attr = (flow_counter_attr_t*)cl_list_obj(itor);

        if (attr->flow_counter_id == flow_counter_id) {
            if (attr->allocated == 0) {
                found = FALSE;
                break;
            }
            found = TRUE;
            *flow_counter_attr = attr;

            break;
        }
        itor = cl_list_next(itor);
    }

    if (found == FALSE) {
        /* Error , Flow counter is not created */
        SX_LOG_ERR("Trying to get a non-allocated flow counter [%u].\n", flow_counter_id);
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sx_flow_counter_increment_bounded_rules_num(sx_flow_counter_id_t flow_counter_id)
{
    cl_list_iterator_t itor, list_end;
    boolean_t          found = FALSE;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Iterate over the flow counter db*/
    itor = cl_list_head(&flow_counter_db.flow_counter_list);
    list_end = cl_list_end(&flow_counter_db.flow_counter_list);
    while (itor != list_end) {
        flow_counter_attr_t *attr = (flow_counter_attr_t*)cl_list_obj(itor);

        if (attr->flow_counter_id == flow_counter_id) {
            attr->bounded_rules_num++;
            found = TRUE;
            break;
        }
        itor = cl_list_next(itor);
    }

    if (found == FALSE) {
        /* Error, Flow counter is not created */
        SX_LOG_ERR("Trying to get a non-allocated flow counter [%u].\n", flow_counter_id);
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sx_flow_counter_decrease_bounded_rules_num(sx_flow_counter_id_t flow_counter_id)
{
    cl_list_iterator_t itor, list_end;
    boolean_t          found = FALSE;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Iterate over the flow counter db*/
    itor = cl_list_head(&flow_counter_db.flow_counter_list);
    list_end = cl_list_end(&flow_counter_db.flow_counter_list);
    while (itor != list_end) {
        flow_counter_attr_t *attr = (flow_counter_attr_t*)cl_list_obj(itor);

        if (attr->flow_counter_id == flow_counter_id) {
            if (attr->bounded_rules_num == 0) {
                SX_LOG_ERR("Trying to decrease bounded rules num from non "
                           "bounded flow counter [%u].\n", flow_counter_id);
                return SX_STATUS_ENTRY_NOT_FOUND;
            }
            attr->bounded_rules_num--;
            found = TRUE;
            break;
        }
        itor = cl_list_next(itor);
    }

    if (found == FALSE) {
        /* Error, Flow counter is not created */
        SX_LOG_ERR("Trying to get a non-allocated flow counter [%u].\n", flow_counter_id);
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t sx_flow_counter_is_exists(sx_flow_counter_id_t flow_counter_id)
{
    cl_list_iterator_t itor, list_end;
    boolean_t          found = FALSE;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Iterate over the flow counter db*/
    itor = cl_list_head(&flow_counter_db.flow_counter_list);
    list_end = cl_list_end(&flow_counter_db.flow_counter_list);
    while (itor != list_end) {
        flow_counter_attr_t *attr = (flow_counter_attr_t*)cl_list_obj(itor);

        if (attr->flow_counter_id == flow_counter_id) {
            if (attr->allocated == TRUE) {
                if (attr->pre_allocated == FALSE) {
                    found = TRUE;
                } else {
                    found = FALSE;
                }
            } else {
                found = FALSE;
            }
            break;
        }
        itor = cl_list_next(itor);
    }

    if (found == FALSE) {
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sx_flow_counter_create_counter_new_device(sx_dev_id_t *devs_list, uint16_t devs_count)
{
    struct ku_pfca_reg pfca;
    sxd_reg_meta_t     meta;
    uint32_t           dev;
    cl_list_iterator_t itor, list_end;
    sxd_status_t       sxd_status;
    sx_status_t        err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pfca);

    SX_LOG_ENTER();

    /* Iterate over the flow counter db*/
    itor = cl_list_head(&flow_counter_db.flow_counter_list);
    list_end = cl_list_end(&flow_counter_db.flow_counter_list);
    while (itor != list_end) {
        flow_counter_attr_t *flow_counter_attr = (flow_counter_attr_t*)cl_list_obj(itor);

        /* for each flow counter configure the new device in HW */
        for (dev = 0; dev < devs_count; dev++) {
            pfca.type = flow_counter_attr->counter_type;
            pfca.index = flow_counter_attr->flow_counter_id;
            pfca.op = SXD_PFCA_OP_ALLOCATE;
            meta.access_cmd = SXD_ACCESS_CMD_SET;
            meta.dev_id = devs_list[dev];
            meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PFCA_E, &pfca, &meta, 1, NULL, NULL);
            if (sxd_status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("Flow Counter : Failed to create flow counter entry SXD err [%u].\n",
                           sxd_status);
                err = sxd_status_to_sx_status(sxd_status);
                goto out;
            }

            /* store the flow counter device handle */
            flow_counter_attr->flow_counter_handle[devs_list[dev]] = pfca.flow_counter_handle;
        }

        itor = cl_list_next(itor);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_flow_counter_bulk_set(const sx_access_cmd_t             cmd,
                                     const sx_flow_counter_bulk_attr_t bulk_attr,
                                     sx_flow_counter_bulk_data_t      *bulk_data_p)
{
    UNUSED_PARAM(cmd);
    UNUSED_PARAM(bulk_attr);
    UNUSED_PARAM(bulk_data_p);
    SX_LOG_ERR("%s - this operation is not supported. \n", __func__);
    return SX_STATUS_UNSUPPORTED;
}

sx_status_t sx_flow_counter_lock(sx_flow_counter_id_t cntr_id,
                                 cm_type_e           *type_p,
                                 cm_hw_type_t        *hw_type_p,
                                 cm_index_t          *index_p)
{
    UNUSED_PARAM(cntr_id);
    UNUSED_PARAM(type_p);
    UNUSED_PARAM(hw_type_p);
    UNUSED_PARAM(index_p);

    SX_LOG_ERR("%s - this operation is not supported. \n", __func__);
    return SX_STATUS_UNSUPPORTED;
}

sx_status_t sx_flow_counter_unlock(sx_flow_counter_id_t cntr_id)
{
    UNUSED_PARAM(cntr_id);

    SX_LOG_ERR("%s - this operation is not supported. \n", __func__);
    return SX_STATUS_UNSUPPORTED;
}

sx_status_t sx_flow_counter_ref_inc(sx_flow_counter_id_t cntr_id)
{
    UNUSED_PARAM(cntr_id);
    SX_LOG_ERR("%s - this operation is not supported. \n", __func__);
    return SX_STATUS_UNSUPPORTED;
}

sx_status_t sx_flow_counter_ref_dec(sx_flow_counter_id_t cntr_id)
{
    UNUSED_PARAM(cntr_id);
    SX_LOG_ERR("%s - this operation is not supported. \n", __func__);
    return SX_STATUS_UNSUPPORTED;
}

sx_status_t sx_flow_counter_ref_modify(sx_flow_counter_id_t cntr_id, int32_t val)
{
    UNUSED_PARAM(cntr_id);
    UNUSED_PARAM(val);
    SX_LOG_ERR("%s - this operation is not supported. \n", __func__);
    return SX_STATUS_UNSUPPORTED;
}

boolean_t sx_flow_counter_is_accuflow(sx_flow_counter_id_t cntr_id)
{
    UNUSED_PARAM(cntr_id);
    return FALSE;
}

sx_status_t sx_flow_counter_accumulated_num_get(uint32_t *accumulated_type_max_number_p)
{
    *accumulated_type_max_number_p = 0;
    return SX_STATUS_SUCCESS;
}

sx_status_t sx_flow_estimator_profile_set(const sx_access_cmd_t                  cmd,
                                          const sx_flow_estimator_profile_key_t *profile_key_p,
                                          const sx_flow_estimator_profile_cfg_t *profile_cfg_p)
{
    UNUSED_PARAM(cmd);
    UNUSED_PARAM(profile_key_p);
    UNUSED_PARAM(profile_cfg_p);

    SX_LOG_ERR("sx_flow_estimator_profile_set is not support.\n");
    return SX_STATUS_CMD_UNSUPPORTED;
}

sx_status_t sx_flow_estimator_profile_get(const sx_flow_estimator_profile_key_t *profile_key_p,
                                          sx_flow_estimator_profile_attr_t      *profile_attr_p)
{
    UNUSED_PARAM(profile_key_p);
    UNUSED_PARAM(profile_attr_p);

    SX_LOG_ERR("sx_flow_estimator_profile_get is not support.\n");
    return SX_STATUS_CMD_UNSUPPORTED;
}

sx_status_t sx_flow_estimator_profile_iter_get(const sx_access_cmd_t                     cmd,
                                               const sx_flow_estimator_profile_key_t    *profile_key_p,
                                               const sx_flow_estimator_profile_filter_t *profile_key_filter_p,
                                               sx_flow_estimator_profile_key_t          *profile_key_list_p,
                                               uint32_t                                 *profile_key_cnt_p)
{
    UNUSED_PARAM(cmd);
    UNUSED_PARAM(profile_key_p);
    UNUSED_PARAM(profile_key_filter_p);
    UNUSED_PARAM(profile_key_list_p);
    UNUSED_PARAM(profile_key_cnt_p);

    SX_LOG_ERR("sx_flow_estimator_profile_iter_get is not support.\n");
    return SX_STATUS_CMD_UNSUPPORTED;
}

sx_status_t sx_flow_estimator_profile_is_exists(const sx_flow_estimator_profile_key_t *profile_key_p)
{
    UNUSED_PARAM(profile_key_p);

    SX_LOG_ERR("sx_flow_estimator_profile_is_exists is not support.\n");
    return SX_STATUS_CMD_UNSUPPORTED;
}

sx_status_t sx_flow_estimator_profile_ref_inc(const sx_flow_estimator_profile_key_t *profile_key_p)
{
    UNUSED_PARAM(profile_key_p);

    SX_LOG_ERR("sx_flow_estimator_profile_ref_inc is not support.\n");
    return SX_STATUS_CMD_UNSUPPORTED;
}


sx_status_t sx_flow_estimator_profile_ref_dec(const sx_flow_estimator_profile_key_t *profile_key_p)
{
    UNUSED_PARAM(profile_key_p);

    SX_LOG_ERR("sx_flow_estimator_profile_ref_dec is not support.\n");
    return SX_STATUS_CMD_UNSUPPORTED;
}


sx_status_t sx_flow_estimator_counter_is_matching_profile(const sx_flow_counter_id_t             base_counter_id,
                                                          const sx_flow_estimator_profile_key_t *profile_key_p,
                                                          boolean_t                             *match)
{
    UNUSED_PARAM(base_counter_id);
    UNUSED_PARAM(profile_key_p);
    UNUSED_PARAM(match);

    SX_LOG_ERR("sx_flow_estimator_counter_is_matching_profile is not support.\n");
    return SX_STATUS_CMD_UNSUPPORTED;
}


sx_status_t sx_flow_counter_dgb_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    UNUSED_PARAM(dbg_dump_params_p);
    SX_LOG_INF("%s - this operation is not supported. \n", __func__);
    return SX_STATUS_SUCCESS;
}

static flow_counter_cb_t sx_flow_counters = {
    .set = sx_flow_counter_set,
    .get = sx_flow_counter_get,
    .clear = sx_flow_counter_clear,
    .is_exists = sx_flow_counter_is_exists,
    .iter_get = sx_flow_counter_iter_get,
    .bulk_set = sx_flow_counter_bulk_set,
    .lock = sx_flow_counter_lock,
    .unlock = sx_flow_counter_unlock,
    .ref_inc = sx_flow_counter_ref_inc,
    .ref_dec = sx_flow_counter_ref_dec,
    .ref_modify = sx_flow_counter_ref_modify,
    .is_accuflow = sx_flow_counter_is_accuflow,
    .accumulated_num_get = sx_flow_counter_accumulated_num_get,
    .estimator_counting_is_enabled = sx_flow_estimator_counting_is_enabled,
    .estimator_get = sx_flow_estimator_counter_get,
    .estimator_profile_set = sx_flow_estimator_profile_set,
    .estimator_profile_get = sx_flow_estimator_profile_get,
    .estimator_profile_iter_get = sx_flow_estimator_profile_iter_get,
    .estimator_profile_is_exists = sx_flow_estimator_profile_is_exists,
    .estimator_profile_ref_inc = sx_flow_estimator_profile_ref_inc,
    .estimator_profile_ref_dec = sx_flow_estimator_profile_ref_dec,
    .estimator_counter_is_matching_profile = sx_flow_estimator_counter_is_matching_profile,
    .dgb_dump = sx_flow_counter_dgb_dump,
};

sx_status_t sx_flow_counter_init(sx_flow_counter_params_t *init_params)
{
    int                  num_of_flow_counter = FLOW_COUNTER_DB_MAX_ALLOCATE;
    sx_status_t          rc;
    uint32_t             i = 0;
    sx_flow_counter_id_t cntr_id = 0;
    cl_status_t          cl_status;
    flow_counter_attr_t *flow_counter_attr = NULL;
    uint32_t             total_flow_counters = 0;

    flow_counter_set_cb(&sx_flow_counters);

    /* Validate init params */
    total_flow_counters = init_params->flow_counter_byte_type_max_number +
                          init_params->flow_counter_packet_type_max_number;
    if (total_flow_counters > FLOW_COUNTER_DB_MAX_ALLOCATE) {
        SX_LOG_ERR("Flow Counter : Error Max total number of flow counter in the system is [%u]\n",
                   FLOW_COUNTER_DB_MAX_ALLOCATE);
        return SX_STATUS_ERROR;
    }
    if (init_params->flow_counter_byte_type_max_number > FLOW_COUNTER_BYTES_TYPE_MAX_ALLOCATE) {
        SX_LOG_ERR("Flow Counter : Error Max total number of bytes type flow counter in the system is [%u]\n",
                   FLOW_COUNTER_BYTES_TYPE_MAX_ALLOCATE);
        return SX_STATUS_ERROR;
    }
    if (init_params->flow_counter_packet_type_max_number > FLOW_COUNTER_PACKETS_TYPE_MAX_ALLOCATE) {
        SX_LOG_ERR("Flow Counter : Error Max total number of packets type flow counter in the system is [%u]\n",
                   FLOW_COUNTER_PACKETS_TYPE_MAX_ALLOCATE);
        return SX_STATUS_ERROR;
    }

    g_flow_counter_global_attr.flow_counter_byte_type_max_number = init_params->flow_counter_byte_type_max_number;
    g_flow_counter_global_attr.flow_counter_byte_type_min_number = init_params->flow_counter_byte_type_min_number;
    g_flow_counter_global_attr.flow_counter_packet_type_max_number = init_params->flow_counter_packet_type_max_number;
    g_flow_counter_global_attr.flow_counter_packet_type_min_number = init_params->flow_counter_packet_type_min_number;

    /* Allocate Flow Counter DB*/
    rc = cl_list_init(&flow_counter_db.flow_counter_list,
                      num_of_flow_counter);

    SX_CHECK_RC(rc, "cl_list_init");

    flow_counter_db.num_of_counters = 0;

    /* Allocate Pre Allocate Flow Counter lists*/
    rc = cl_list_init(&flow_counter_db.flow_counter_byte_type_pre_allocated_list,
                      num_of_flow_counter);
    SX_CHECK_RC(rc, "cl_list_init");
    flow_counter_db.num_of_pre_allocted_byte_counters = 0;

    rc = cl_list_init(&flow_counter_db.flow_counter_packet_type_pre_allocated_list,
                      num_of_flow_counter);
    SX_CHECK_RC(rc, "cl_list_init");
    flow_counter_db.num_of_pre_allocted_packet_counters = 0;


    rc = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                __flow_counter_device_ready_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise , error: %s \n", sx_status_str(rc));
        return rc;
    }

    /* Allocate minimum number of packet counter in the pool */

    for (i = 0; i < g_flow_counter_global_attr.flow_counter_byte_type_min_number; i++) {
        rc = sx_flow_counter_set(SX_ACCESS_CMD_CREATE, SX_FLOW_COUNTER_TYPE_BYTES, &cntr_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to allocate byte flow counter , error: %s \n", sx_status_str(rc));
            return rc;
        }

        rc = sx_flow_counter_get_flow_counter_attr_from_flow_counter_id(cntr_id,
                                                                        &flow_counter_attr);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flow Counter : Failed to get flow counter attribute of flow counter id [%u]\n", cntr_id);
            return rc;
        }

        flow_counter_attr->pre_allocated = 1;
        cl_status = cl_list_insert_tail(&flow_counter_db.flow_counter_byte_type_pre_allocated_list,
                                        (void*)flow_counter_attr);
        if (CL_SUCCESS != cl_status) {
            SX_LOG_ERR("Flow Counter : Failed to insert flow counter to internal pre allocated db CL err [%u]\n",
                       cl_status);
            return SX_STATUS_ERROR;
        }
    }

    flow_counter_db.num_of_pre_allocted_byte_counters = g_flow_counter_global_attr.flow_counter_byte_type_min_number;

    /* Allocate minimum number of packets counter in the pool */
    for (i = 0; i < g_flow_counter_global_attr.flow_counter_packet_type_min_number; i++) {
        rc = sx_flow_counter_set(SX_ACCESS_CMD_CREATE, SX_FLOW_COUNTER_TYPE_PACKETS, &cntr_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to allocate packet flow counter , error: %s \n", sx_status_str(rc));
            return rc;
        }

        rc = sx_flow_counter_get_flow_counter_attr_from_flow_counter_id(cntr_id,
                                                                        &flow_counter_attr);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flow Counter : Failed to get flow counter attribute of flow counter id [%u]\n", cntr_id);
            return rc;
        }

        flow_counter_attr->pre_allocated = 1;
        cl_status = cl_list_insert_tail(&flow_counter_db.flow_counter_packet_type_pre_allocated_list,
                                        (void*)flow_counter_attr);
        if (CL_SUCCESS != cl_status) {
            SX_LOG_ERR("Flow Counter : Failed to insert flow counter to internal pre allocated db CL err [%u]\n",
                       cl_status);
            return SX_STATUS_ERROR;
        }
    }

    flow_counter_db.num_of_pre_allocted_packet_counters =
        g_flow_counter_global_attr.flow_counter_packet_type_min_number;

    return SX_STATUS_SUCCESS;
}

void sx_flow_counter_deinit(const boolean_t is_forced)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    flow_counter_attr_t *attr = NULL;

    UNUSED_PARAM(is_forced);

    /* DeAllocate Flow Counter DB */
    attr = (flow_counter_attr_t*)cl_list_remove_head(&flow_counter_db.flow_counter_list);
    while (NULL != attr) {
        sx_status = utils_memory_put((void*)(attr), UTILS_MEM_TYPE_ID_FLOW_COUNTER_E);

        SX_CHECK_RC(sx_status, "Deallocate Flow Counter attributes");

        attr = (flow_counter_attr_t*)cl_list_remove_head(&flow_counter_db.flow_counter_list);
    }
    cl_list_destroy(&flow_counter_db.flow_counter_list);

    cl_list_remove_all(&flow_counter_db.flow_counter_packet_type_pre_allocated_list);
    cl_list_destroy(&flow_counter_db.flow_counter_packet_type_pre_allocated_list);

    cl_list_remove_all(&flow_counter_db.flow_counter_byte_type_pre_allocated_list);
    cl_list_destroy(&flow_counter_db.flow_counter_byte_type_pre_allocated_list);


    SX_LOG_NTC("Flow Counter : Terminated\n");
}
