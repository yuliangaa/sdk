/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/cl_mem.h>
#include "flow_counter/flow_counter.h"

#undef  __MODULE__
#define __MODULE__ FLOW_COUNTER

/************************************************
 *  Global variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
flow_counter_cb_t* g_flow_counter_cb = NULL;

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t flow_counter_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

sx_status_t flow_counter_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

    return err;
}

flow_counter_cb_t* flow_counter_get_cb()
{
    CL_ASSERT(g_flow_counter_cb != NULL);
    return g_flow_counter_cb;
}

void flow_counter_set_cb(flow_counter_cb_t* cb)
{
    CL_ASSERT(cb != NULL);
    g_flow_counter_cb = cb;
}
