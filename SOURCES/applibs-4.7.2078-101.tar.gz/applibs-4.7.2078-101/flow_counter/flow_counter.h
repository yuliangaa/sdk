/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLOW_COUNTER_H_INCL__
#define __FLOW_COUNTER_H_INCL__

#include <sx/sdk/sx_types.h>
#include <counters/counter_manager/counter_manager.h>
#include <utils/utils.h>

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/
/**
 * Flow counter ID
 *   This is the logical ID used by flow counter module and clients to
 *   address a flow counter.
 *
 * Field composition:
 * |32        13|12     0|
 * +------------+--------+
 * | lid        | offset |
 * +------------+--------+
 *
 *  bits 0-12    - Counter index inside counters group.
 *  bits 13-32   - Logical ID of the counters group received from the counter manager.
 */
#define FLOW_CNTR_ID_OFFSET_MASK (0x1FFF)           /* 13 bits */
#define FLOW_CNTR_ID_LID_MASK    (0x7FFFF)          /* 19 bits */
#define FLOW_CNTR_ID_OFFSET_GET(cntr_id) (cntr_id & FLOW_CNTR_ID_OFFSET_MASK)
#define FLOW_CNTR_ID_LID_GET(cntr_id)    ((cm_logical_id_t)((cntr_id >> 13) & FLOW_CNTR_ID_LID_MASK))
#define LID_OFFSET_TO_FLOW_CNTR_ID(lid, offset)                     \
    ((sx_flow_counter_id_t)(((lid & FLOW_CNTR_ID_LID_MASK) << 13) | \
                            (offset & FLOW_CNTR_ID_OFFSET_MASK)))

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct flow_counter_attr {
    sx_flow_counter_id_t   flow_counter_id;
    uint32_t               flow_counter_handle[SX_DEV_NUM_MAX];
    uint8_t                allocated;
    uint8_t                pre_allocated;
    uint16_t               bounded_rules_num;
    sx_flow_counter_type_t counter_type;
} flow_counter_attr_t;

typedef struct {
    uint16_t flow_counter_byte_type_min_number;
    uint16_t flow_counter_packet_type_min_number;
    uint16_t flow_counter_byte_type_max_number;
    uint16_t flow_counter_packet_type_max_number;
} flow_counter_global_attr_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

typedef struct {
    sx_status_t (*set)(const sx_access_cmd_t        cmd,
                       const sx_flow_counter_type_t cntr_type,
                       sx_flow_counter_id_t        *cntr_id);
    sx_status_t (*get)(const sx_flow_counter_id_t cntr_id,
                       sx_flow_counter_set_t     *cntr_val);
    sx_status_t (*clear)(const sx_flow_counter_id_t cntr_id);
    sx_status_t (*is_exists)(sx_flow_counter_id_t cntr_id);
    sx_status_t (*iter_get)(const sx_access_cmd_t           cmd,
                            const sx_flow_counter_id_t      counter_id_key,
                            const sx_flow_counter_filter_t *counter_id_filter_p,
                            sx_flow_counter_id_t           *counter_id_list_p,
                            uint32_t                       *counter_id_cnt_p);
    sx_status_t (*bulk_set)(const sx_access_cmd_t             cmd,
                            const sx_flow_counter_bulk_attr_t bulk_attr,
                            sx_flow_counter_bulk_data_t      *bulk_data_p);
    sx_status_t (*lock)(sx_flow_counter_id_t cntr_id,
                        cm_type_e           *type_p,
                        cm_hw_type_t        *hw_type_p,
                        cm_index_t          *index_p);
    sx_status_t (*unlock)(sx_flow_counter_id_t cntr_id);
    sx_status_t (*ref_inc)(sx_flow_counter_id_t cntr_id);
    sx_status_t (*ref_dec)(sx_flow_counter_id_t cntr_id);
    sx_status_t (*ref_modify)(sx_flow_counter_id_t cntr_id, int32_t val);
    boolean_t (*is_accuflow)(sx_flow_counter_id_t cntr_id);
    sx_status_t (*accumulated_num_get)(uint32_t *accumulated_type_max_number_p);
    boolean_t (*estimator_counting_is_enabled)(void);
    sx_status_t (*estimator_get)(const sx_access_cmd_t            cmd,
                                 const sx_flow_counter_id_t       cntr_id,
                                 sx_flow_estimator_counter_set_t *cntr_val);
    sx_status_t (*estimator_profile_set)(const sx_access_cmd_t                  cmd,
                                         const sx_flow_estimator_profile_key_t *profile_key_p,
                                         const sx_flow_estimator_profile_cfg_t *profile_cfg_p);
    sx_status_t (*estimator_profile_get)(const sx_flow_estimator_profile_key_t *profile_key_p,
                                         sx_flow_estimator_profile_attr_t      *profile_attr_p);
    sx_status_t (*estimator_profile_iter_get)(const sx_access_cmd_t                     cmd,
                                              const sx_flow_estimator_profile_key_t    *profile_key_p,
                                              const sx_flow_estimator_profile_filter_t *profile_key_filter_p,
                                              sx_flow_estimator_profile_key_t          *profile_key_list_p,
                                              uint32_t                                 *profile_key_cnt_p);
    sx_status_t (*estimator_profile_is_exists)(const sx_flow_estimator_profile_key_t *profile_key_p);
    sx_status_t (*estimator_profile_ref_inc)(const sx_flow_estimator_profile_key_t *profile_key_p);
    sx_status_t (*estimator_profile_ref_dec)(const sx_flow_estimator_profile_key_t *profile_key_p);
    sx_status_t (*estimator_counter_is_matching_profile)(const sx_flow_counter_id_t             cntr_id,
                                                         const sx_flow_estimator_profile_key_t *profile_key_p,
                                                         boolean_t                             *match);
    sx_status_t (*dgb_dump)(dbg_dump_params_t *dbg_dump_params_p);
    boolean_t (*is_counter_by_ref_type_base)(sx_flow_counter_id_t cntr_id);
} flow_counter_cb_t;

/************************************************
 * API implementation
 ***********************************************/
flow_counter_cb_t* flow_counter_get_cb();
void flow_counter_set_cb(flow_counter_cb_t* cb);

sx_status_t flow_counter_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t flow_counter_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

static inline sx_status_t flow_counter_set(const sx_access_cmd_t        cmd,
                                           const sx_flow_counter_type_t cntr_type,
                                           sx_flow_counter_id_t        *cntr_id)
{
    return flow_counter_get_cb()->set(cmd, cntr_type, cntr_id);
}

static inline sx_status_t flow_counter_get(const sx_flow_counter_id_t cntr_id, sx_flow_counter_set_t *cntr_val)
{
    return flow_counter_get_cb()->get(cntr_id, cntr_val);
}

static inline sx_status_t flow_counter_iter_get(const sx_access_cmd_t           cmd,
                                                const sx_flow_counter_id_t      counter_id_key,
                                                const sx_flow_counter_filter_t *counter_id_filter_p,
                                                sx_flow_counter_id_t           *counter_id_list_p,
                                                uint32_t                       *counter_id_cnt_p)
{
    return flow_counter_get_cb()->iter_get(cmd, counter_id_key, counter_id_filter_p,
                                           counter_id_list_p, counter_id_cnt_p);
}


static inline sx_status_t flow_counter_clear(const sx_flow_counter_id_t cntr_id)
{
    return flow_counter_get_cb()->clear(cntr_id);
}

static inline sx_status_t flow_counter_is_exists(sx_flow_counter_id_t cntr_id)
{
    return flow_counter_get_cb()->is_exists(cntr_id);
}

static inline boolean_t flow_counter_is_counter_by_ref_type_base(sx_flow_counter_id_t cntr_id)
{
    return flow_counter_get_cb()->is_counter_by_ref_type_base(cntr_id);
}


static inline boolean_t flow_counter_is_accuflow(sx_flow_counter_id_t cntr_id)
{
    return flow_counter_get_cb()->is_accuflow(cntr_id);
}

static inline sx_status_t flow_counter_accumulated_num_get(uint32_t *accumulated_type_max_number_p)
{
    return flow_counter_get_cb()->accumulated_num_get(accumulated_type_max_number_p);
}

static inline sx_status_t flow_counter_dbg_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    return flow_counter_get_cb()->dgb_dump(dbg_dump_params_p);
}

static inline sx_status_t flow_counter_bulk_set(const sx_access_cmd_t             cmd,
                                                const sx_flow_counter_bulk_attr_t bulk_attr,
                                                sx_flow_counter_bulk_data_t      *bulk_data_p)
{
    return flow_counter_get_cb()->bulk_set(cmd, bulk_attr, bulk_data_p);
}

static inline sx_status_t flow_counter_lock(sx_flow_counter_id_t cntr_id,
                                            cm_type_e           *type_p,
                                            cm_hw_type_t        *hw_type_p,
                                            cm_index_t          *index_p)
{
    return flow_counter_get_cb()->lock(cntr_id, type_p, hw_type_p, index_p);
}

static inline sx_status_t flow_counter_unlock(sx_flow_counter_id_t cntr_id)
{
    return flow_counter_get_cb()->unlock(cntr_id);
}

static inline sx_status_t flow_counter_ref_inc(sx_flow_counter_id_t cntr_id)
{
    return flow_counter_get_cb()->ref_inc(cntr_id);
}

static inline sx_status_t flow_counter_ref_dec(sx_flow_counter_id_t cntr_id)
{
    return flow_counter_get_cb()->ref_dec(cntr_id);
}

static inline sx_status_t flow_counter_ref_modify(sx_flow_counter_id_t cntr_id, int32_t val)
{
    return flow_counter_get_cb()->ref_modify(cntr_id, val);
}

static inline boolean_t flow_estimator_counting_is_enabled(void)
{
    return flow_counter_get_cb()->estimator_counting_is_enabled();
}

static inline sx_status_t flow_estimator_counter_get(const sx_access_cmd_t            cmd,
                                                     const sx_flow_counter_id_t       cntr_id,
                                                     sx_flow_estimator_counter_set_t *cntr_val)
{
    return flow_counter_get_cb()->estimator_get(cmd, cntr_id, cntr_val);
}

static inline sx_status_t flow_estimator_profile_set(const sx_access_cmd_t                  cmd,
                                                     const sx_flow_estimator_profile_key_t *profile_key_p,
                                                     const sx_flow_estimator_profile_cfg_t *profile_cfg_p)
{
    return flow_counter_get_cb()->estimator_profile_set(cmd,
                                                        profile_key_p,
                                                        profile_cfg_p);
}

static inline sx_status_t flow_estimator_profile_get(const sx_flow_estimator_profile_key_t *profile_key_p,
                                                     sx_flow_estimator_profile_attr_t      *profile_attr_p)
{
    return flow_counter_get_cb()->estimator_profile_get(profile_key_p, profile_attr_p);
}

static inline sx_status_t flow_estimator_profile_iter_get(const sx_access_cmd_t                     cmd,
                                                          const sx_flow_estimator_profile_key_t    *profile_key_p,
                                                          const sx_flow_estimator_profile_filter_t *profile_key_filter_p,
                                                          sx_flow_estimator_profile_key_t          *profile_key_list_p,
                                                          uint32_t                                 *profile_key_cnt_p)
{
    return flow_counter_get_cb()->estimator_profile_iter_get(cmd,
                                                             profile_key_p,
                                                             profile_key_filter_p,
                                                             profile_key_list_p,
                                                             profile_key_cnt_p);
}

static inline sx_status_t flow_estimator_profile_is_exists(const sx_flow_estimator_profile_key_t *profile_key_p)
{
    return flow_counter_get_cb()->estimator_profile_is_exists(profile_key_p);
}

static inline sx_status_t flow_estimator_profile_ref_inc(const sx_flow_estimator_profile_key_t *profile_key_p)
{
    return flow_counter_get_cb()->estimator_profile_ref_inc(profile_key_p);
}

static inline sx_status_t flow_estimator_profile_ref_dec(const sx_flow_estimator_profile_key_t *profile_key_p)
{
    return flow_counter_get_cb()->estimator_profile_ref_dec(profile_key_p);
}

static inline sx_status_t flow_estimator_counter_is_matching_profile(
    const sx_flow_counter_id_t             base_counter_id,
    const sx_flow_estimator_profile_key_t *profile_key_p,
    boolean_t                             *match)
{
    return flow_counter_get_cb()->estimator_counter_is_matching_profile(base_counter_id, profile_key_p, match);
}

/************************************************
 * Legacy function declarations
 ***********************************************/
sx_status_t sx_flow_counter_init(sx_flow_counter_params_t *init_params);
sx_status_t sdk_flow_counter_init(sx_flow_counter_params_t *init_params);

void sx_flow_counter_deinit(const boolean_t is_forced);
void sdk_flow_counter_deinit(const boolean_t is_forced);

sx_status_t sx_flow_counter_get_flow_counter_attr_from_flow_counter_id(sx_flow_counter_id_t  flow_counter_id,
                                                                       flow_counter_attr_t **flow_counter_attr);

sx_status_t sx_flow_counter_increment_bounded_rules_num(sx_flow_counter_id_t flow_counter_id);

sx_status_t sx_flow_counter_decrease_bounded_rules_num(sx_flow_counter_id_t flow_counter_id);

sx_status_t sx_flow_counter_create_counter_new_device(sx_dev_id_t *devs_list,
                                                      uint16_t     devs_count);

#endif /* ifndef __FLOW_COUNTER_H_INCL__ */
