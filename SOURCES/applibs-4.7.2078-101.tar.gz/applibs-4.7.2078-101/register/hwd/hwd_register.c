/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include "utils/sx_mem.h"
#include "flex_parser/hwi/flex_parser_impl.h"
#include "hwd_register.h"
#include "hwd_register_db.h"
#include "hwd_register_reg.h"

#undef __MODULE__
#define __MODULE__ REGISTER

/************************************************
 *  Global variables
 ***********************************************/
extern rm_resources_t rm_resource_global;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t hwd_register_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    hwd_register_db_log_verbosity_level_set(verbosity_level);
    hwd_register_reg_log_verbosity_level_set(verbosity_level);
    SX_LOG_EXIT();

    return rc;
}

sx_status_t hwd_gp_register_set_validate(sx_access_cmd_t cmd, sx_gp_register_key_t reg_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    ref_count = 0;
    boolean_t   is_allocated = FALSE;

    SX_LOG_ENTER();

    if (reg_key.reg_id >= rm_resource_global.gp_register_num_max) {
        SX_LOG_ERR("Invalid value %d for GP register ID, max valid ID: %d.\n",
                   reg_key.reg_id, rm_resource_global.gp_register_num_max - 1);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = hwd_gp_register_db_is_allocated(reg_key.reg_id, &is_allocated);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get allocation information from DB for GP register ID %d, error: [%s]\n",
                   reg_key.reg_id, sx_status_str(rc));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        if (is_allocated == TRUE) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("GP register ID %d is already allocated, error: [%s]\n",
                       reg_key.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        if (is_allocated == FALSE) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("GP register ID %d is not allocated, error: [%s]\n",
                       reg_key.reg_id, sx_status_str(rc));
            goto out;
        }

        rc = hwd_gp_register_db_refcount_get(reg_key.reg_id, &ref_count);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get reference counter information from DB for GP register ID %d, error: [%s]\n",
                       reg_key.reg_id, sx_status_str(rc));
            goto out;
        }

        if (ref_count != 0) {
            SX_LOG_ERR("GP register ID %d is in use: ref_count [%d].\n",
                       reg_key.reg_id, ref_count);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to validate set GP register operation: invalid cmd %s\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_gp_register_set(sx_access_cmd_t cmd, sx_gp_register_key_t reg_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        rc = hwd_gp_register_db_reg_create(reg_key.reg_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to create GP register ID %d in DB, error: [%s]\n",
                       reg_key.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        rc = hwd_gp_register_db_reg_destroy(reg_key.reg_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to destroy GP register ID %d in DB, error: [%s]\n",
                       reg_key.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to set GP register: invalid cmd %s\n", sx_access_cmd_str(cmd));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_gp_register_set_protected(sx_access_cmd_t cmd, sx_gp_register_key_t reg_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_ENABLE:
        rc = hwd_gp_register_db_protected_reg_enable(reg_key.reg_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to create protected GP register ID %d in DB, error: [%s]\n",
                       reg_key.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DISABLE:
        rc = hwd_gp_register_db_protected_reg_disable(reg_key.reg_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to destroy protected GP register ID %d in DB, error: [%s]\n",
                       reg_key.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Failed to set GP register: invalid cmd %s\n", sx_access_cmd_str(cmd));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t hwd_gp_register_ref_counter_update(sx_gp_register_key_t gp_reg,
                                               boolean_t            increase,
                                               ref_name_data_t     *ref_name_data_p,
                                               sdk_ref_t           *ref_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    ref_count = 0;
    boolean_t   is_allocated = FALSE;
    boolean_t   is_protected = FALSE;

    SX_LOG_ENTER();

    rc = hwd_gp_register_db_is_allocated(gp_reg.reg_id, &is_allocated);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get allocation information from DB for GP register ID %d, error: [%s]\n",
                   gp_reg.reg_id, sx_status_str(rc));
        goto out;
    }

    if (is_allocated == FALSE) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to update GP register ID %d reference counter, "
                   "register is not allocated, error: [%s]\n",
                   gp_reg.reg_id, sx_status_str(rc));
        goto out;
    }

    rc = hwd_gp_register_db_is_protected(gp_reg.reg_id, &is_protected);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get protection information from DB for GP register ID %d, error: [%s]\n",
                   gp_reg.reg_id, sx_status_str(rc));
        goto out;
    }

    if (is_protected == TRUE) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Updating GP register ID %d reference counter is not allowed, "
                   "register protected, error: [%s]\n",
                   gp_reg.reg_id, sx_status_str(rc));
        goto out;
    }

    if (increase == FALSE) {
        rc = hwd_gp_register_db_refcount_get(gp_reg.reg_id, &ref_count);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get reference counter information from DB for GP register ID %d, error: [%s]\n",
                       gp_reg.reg_id, sx_status_str(rc));
            goto out;
        }
        if (ref_count == 0) {
            SX_LOG_ERR("GP register ID %d is not in use: can not decrease reference counter [%d].\n",
                       gp_reg.reg_id, ref_count);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    rc = hwd_gp_register_db_reg_ref_counter_update(gp_reg.reg_id, increase, ref_name_data_p, ref_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to update GP register ID %d reference counter in DB, error: [%s]\n",
                   gp_reg.reg_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_gp_register_init()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = hwd_gp_register_db_init();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init hwd GP register DB, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_gp_register_deinit(boolean_t is_forced)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = hwd_gp_register_db_deinit(is_forced);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to de-init hwd GP register DB, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_register_init_ops(register_hwd_ops_t *register_hwd_ops_p)
{
    register_hwd_ops_p->gp_register_init_pfn = hwd_gp_register_init;
    register_hwd_ops_p->gp_register_deinit_pfn = hwd_gp_register_deinit;
    register_hwd_ops_p->gp_register_set_validate_pfn = hwd_gp_register_set_validate;
    register_hwd_ops_p->gp_register_set_pfn = hwd_gp_register_set;
    register_hwd_ops_p->gp_register_set_protected_pfn = NULL;
    register_hwd_ops_p->gp_register_debug_dump_pfn = hwd_gp_register_db_debug_dump;
    register_hwd_ops_p->gp_register_is_allocated_pfn = hwd_gp_register_db_is_allocated;
    register_hwd_ops_p->gp_register_ref_count_update_pfn = hwd_gp_register_ref_counter_update;
    register_hwd_ops_p->gp_register_iter_get_pfn = hwd_gp_register_db_iter_get;
    return SX_STATUS_SUCCESS;
}


sx_status_t hwd_register_init_ops_spectrum4(register_hwd_ops_t *register_hwd_ops_p)
{
    register_hwd_ops_p->gp_register_init_pfn = hwd_gp_register_init;
    register_hwd_ops_p->gp_register_deinit_pfn = hwd_gp_register_deinit;
    register_hwd_ops_p->gp_register_set_validate_pfn = hwd_gp_register_set_validate;
    register_hwd_ops_p->gp_register_set_pfn = hwd_gp_register_set;
    register_hwd_ops_p->gp_register_set_protected_pfn = hwd_gp_register_set_protected;
    register_hwd_ops_p->gp_register_debug_dump_pfn = hwd_gp_register_db_debug_dump_spectrum4;
    register_hwd_ops_p->gp_register_is_allocated_pfn = hwd_gp_register_db_is_allocated;
    register_hwd_ops_p->gp_register_ref_count_update_pfn = hwd_gp_register_ref_counter_update;
    register_hwd_ops_p->gp_register_iter_get_pfn = hwd_gp_register_db_iter_get;
    return SX_STATUS_SUCCESS;
}
