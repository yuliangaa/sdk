/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include <sx/sdk/sx_strings.h>
#include "register_be.h"
#include "register_impl.h"
#include "register/hwd/hwd_register.h"

#undef __MODULE__
#define __MODULE__ REGISTER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t register_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    sdk_register_impl_log_verbosity_level_set(verbosity_level);
    hwd_register_log_verbosity_level_set(verbosity_level);

    SX_LOG_EXIT();

    return rc;
}

sx_status_t register_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (verbosity_level_p == NULL) {
        SX_LOG_ERR("verbosity level pointer is NULL.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t register_set(sx_access_cmd_t cmd, uint32_t reg_key_cnt, sx_register_key_t* reg_key_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Failed to set register, invalid command (%s), error: [%s]\n",
                   sx_access_cmd_str(cmd), sx_status_str(rc));
        goto out;
    }

    if (reg_key_cnt == 0) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to set register, received empty list, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    rc = sdk_register_impl_set(cmd, reg_key_list_p, reg_key_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set register, error: %s \n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT()
    return rc;
}

sx_status_t register_iter_get(sx_access_cmd_t       cmd,
                              sx_register_key_t     reg_key,
                              sx_register_filter_t *filter_p,
                              sx_register_key_t    *reg_key_list_p,
                              uint32_t             *reg_key_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_GETNEXT) && (cmd != SX_ACCESS_CMD_GET_FIRST)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Failed to iter get register, invalid command (%s), error: [%s]\n",
                   sx_access_cmd_str(cmd), sx_status_str(rc));
        goto out;
    }

    rc = sdk_register_impl_iter_get(cmd, reg_key, filter_p, reg_key_list_p, reg_key_cnt_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to iter get register, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT()
    return rc;
}
