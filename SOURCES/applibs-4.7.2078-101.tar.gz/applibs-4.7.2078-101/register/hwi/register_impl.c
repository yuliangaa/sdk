/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include "complib/cl_fcntl.h"
#include <sx/utils/debug_cmd.h>
#include "acl/flex_acl_db.h"
#include "ethl2/brg.h"
#include "register_impl.h"
#include <include/resource_manager/resource_manager.h>
#include "resource_manager/resource_manager_sdk_table.h"

#undef __MODULE__
#define __MODULE__ REGISTER


/************************************************
 *  Global variables
 ***********************************************/
extern sx_brg_context_t brg_context;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static register_hwd_ops_t g_register_hwd_ops;
static boolean_t          g_is_module_initialized = FALSE;
static register_mode_e    g_register_mode = REGISTER_MODE_NONE_E;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sdk_register_impl_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __hwd_gp_register_set_validation_wrapper(sx_access_cmd_t cmd, sx_gp_register_key_t reg_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_register_hwd_ops.gp_register_set_validate_pfn == NULL) {
        SX_LOG_ERR("GP registers are not supported\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }
    rc = g_register_hwd_ops.gp_register_set_validate_pfn(cmd, reg_key);

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __hwd_gp_register_set_wrapper(sx_access_cmd_t cmd, sx_gp_register_key_t reg_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_register_hwd_ops.gp_register_set_pfn == NULL) {
        SX_LOG_ERR("GP registers are not supported\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_register_hwd_ops.gp_register_set_pfn(cmd, reg_key);

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __hwd_gp_register_set_protected_wrapper(sx_access_cmd_t cmd, sx_gp_register_key_t reg_key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_register_hwd_ops.gp_register_set_protected_pfn == NULL) {
        SX_LOG_ERR("Protected GP registers are not supported\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_register_hwd_ops.gp_register_set_protected_pfn(cmd, reg_key);

out:
    SX_LOG_EXIT();
    return rc;
}

static void __hwd_gp_register_debug_dump_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    SX_LOG_ENTER();

    if (g_register_hwd_ops.gp_register_debug_dump_pfn != NULL) {
        g_register_hwd_ops.gp_register_debug_dump_pfn(dbg_dump_params_p);
    }

    SX_LOG_EXIT();
}

static sx_status_t __register_hwd_init_wrapper()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_register_hwd_ops.gp_register_init_pfn != NULL) {
        rc = g_register_hwd_ops.gp_register_init_pfn();
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to init HWD register [%s].\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __register_hwd_deinit_wrapper(boolean_t is_forced)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_register_hwd_ops.gp_register_deinit_pfn != NULL) {
        rc = g_register_hwd_ops.gp_register_deinit_pfn(is_forced);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to de-init HWD register [%s].\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __register_hwd_gp_register_is_allocated_wrapper(sx_gp_register_e gp_reg_id,
                                                                   boolean_t       *is_allocated_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_register_hwd_ops.gp_register_is_allocated_pfn != NULL) {
        rc = g_register_hwd_ops.gp_register_is_allocated_pfn(gp_reg_id, is_allocated_p);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __register_hwd_gp_register_ref_count_update_wrapper(sx_gp_register_key_t gp_reg,
                                                                       boolean_t            increase,
                                                                       ref_name_data_t     *ref_name_data_p,
                                                                       sdk_ref_t           *ref_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_register_hwd_ops.gp_register_ref_count_update_pfn != NULL) {
        rc = g_register_hwd_ops.gp_register_ref_count_update_pfn(gp_reg, increase, ref_name_data_p, ref_p);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __register_hwd_gp_register_db_iter_get_wrapper(sx_access_cmd_t       cmd,
                                                                  sx_register_key_t     reg_key,
                                                                  sx_register_filter_t *filter_p,
                                                                  sx_register_key_t    *reg_key_list_p,
                                                                  uint32_t             *reg_key_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_register_hwd_ops.gp_register_iter_get_pfn == NULL) {
        SX_LOG_ERR("GP registers are not supported\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }
    rc = g_register_hwd_ops.gp_register_iter_get_pfn(cmd, reg_key, filter_p, reg_key_list_p, reg_key_cnt_p);

out:
    SX_LOG_EXIT();
    return rc;
}

static void __debug_cmd_gp_register_dump_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params = {
        .stream = stream,
        .thread_idx = 0,
        .thread_num = 1,
        .hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    };

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    SX_MEM_CLR(printer_params);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI: failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    __hwd_gp_register_debug_dump_wrapper(&dbg_dump_params);

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}

/*
 * The APIs sx_api_register_set and sx_api_acl_custom_bytes_set are mutually exclusive,
 * so per single SDK life cycle only one of them can be used.
 * This function is internal back door to reset the mutual exclusion, for verification
 * NO RESET tests.
 * Usage:
 *     sx_debug_cmd_client register gp reset
 */
static void __register_mode_reset()
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    boolean_t         cbset_is_used = FALSE;
    uint32_t          reg_count = 0;
    sx_register_key_t reg_key;

    SX_MEM_CLR(reg_key);

    if (g_register_mode == REGISTER_MODE_CUTSOM_BYTES_E) {
        rc = flex_acl_db_custom_bytes_set_is_used(&cbset_is_used);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get if cbset were allocated\n");
        }

        if (cbset_is_used == TRUE) {
            SX_LOG_NTC(
                "Reset mutual exclusion between register and custom bytes APIs while custom byte set are in used\n");
        }
    } else if (g_register_mode == REGISTER_MODE_GP_REGISTER_E) {
        rc = sdk_register_impl_iter_get(SX_ACCESS_CMD_GET, reg_key, NULL, NULL, &reg_count);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get if cbset were allocated\n");
        }

        if (reg_count > 0) {
            SX_LOG_NTC("Reset mutual exclusion between register and custom bytes APIs while GP register are in used\n");
        }
    }

    g_register_mode = REGISTER_MODE_NONE_E;
}

static void __debug_cmd_gp_register_reset_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    dbg_utils_print(stream, "Will reset mutual exclusion between register and custom bytes APIs\n");
    __register_mode_reset();
}

static void __register_debug_cmd_register(void)
{
    sx_utils_debug_cmd_register_path("register gp all", __debug_cmd_gp_register_dump_cb, NULL);
    sx_utils_debug_cmd_register_path("register gp reset", __debug_cmd_gp_register_reset_cb, NULL);
}

static void __register_debug_cmd_unregister(void)
{
    sx_utils_debug_cmd_unregister_path("register");
}

static sx_status_t __register_init_ops_wrapper()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    memset(&g_register_hwd_ops, 0, sizeof(g_register_hwd_ops));

    if (brg_context.spec_cb_g.register_init_ops_cb != NULL) {
        rc = brg_context.spec_cb_g.register_init_ops_cb(&g_register_hwd_ops);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_register_impl_init()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_is_module_initialized == TRUE) {
        rc = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Failed to initialized Register module: already initialized, error: [%s].\n",
                   sx_status_str(rc));
        goto out;
    }

    /* Set the hwd operations */
    rc = __register_init_ops_wrapper();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init hwd register ops\n");
        goto out;
    }

    /* Initialize the hwd layer */
    rc = __register_hwd_init_wrapper();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in hwd register init, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    __register_debug_cmd_register();

    /* Make sure the mode is in reset mode (can be changed by UT) */
    __register_mode_reset();

    /* RM GP register management */
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_GP_REGISTER_E].is_initialized = TRUE;
    rc = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_GP_REGISTER_E);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init RM for %s, rc: %s\n",
                   SX_RESOURCE_MSG(RM_SDK_TABLE_TYPE_GP_REGISTER_E), sx_status_str(rc));
        goto out;
    }

    g_is_module_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_register_impl_deinit(boolean_t is_forced)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_is_module_initialized == FALSE) {
        SX_LOG_INF("Register module is not initialized: return success.\n");
        goto out;
    }

    /* Deinit the hwd layer */
    rc = __register_hwd_deinit_wrapper(is_forced);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to de-init hwd register error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    __register_debug_cmd_unregister();

    /* Make sure the mode is in reset mode (can be changed by UT) */
    __register_mode_reset();

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_GP_REGISTER_E].is_initialized = FALSE;
    rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_GP_REGISTER_E, TRUE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deinit span sessions in rm, err = %s\n",
                   sx_status_str(rc));
        goto out;
    }

    g_is_module_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_register_impl_protected_set(sx_access_cmd_t    cmd,
                                            sx_register_key_t *reg_key_list_p,
                                            uint32_t           reg_key_cnt)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint16_t    i = 0;

    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_ENABLE) && (cmd != SX_ACCESS_CMD_DISABLE)) {
        SX_LOG_ERR("Command not valid for GP register protection %d.\n", reg_key_list_p[i].key.gp_reg.reg_id);
        goto out;
    }


    for (i = 0; i < reg_key_cnt; i++) {
        rc = __hwd_gp_register_set_protected_wrapper(cmd, reg_key_list_p[i].key.gp_reg);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set protection of GP register %d:.\n", reg_key_list_p[i].key.gp_reg.reg_id);
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_register_impl_set(sx_access_cmd_t cmd, sx_register_key_t *reg_key_list_p, uint32_t reg_key_cnt)
{
    sx_status_t rc = SX_STATUS_SUCCESS, rollback_rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    boolean_t   rm_rollback = FALSE;

    SX_LOG_ENTER();

    rc = sdk_register_mode_test_and_set(REGISTER_MODE_GP_REGISTER_E);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set register: sx_api_acl_custom_bytes_set() already called.\n");
        goto out;
    }

    for (i = 0; i < reg_key_cnt; i++) {
        switch (reg_key_list_p[i].type) {
        case SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
            rc = __hwd_gp_register_set_validation_wrapper(cmd, reg_key_list_p[i].key.gp_reg);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Validation failed for input GP register list and cmd (%s), error: [%s]\n",
                           sx_access_cmd_str(cmd), sx_status_str(rc));
                goto out;
            }
            break;

        default:
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Failed to set register: invalid register type %d\n", reg_key_list_p[i].type);
            goto out;
        }
    }

    for (i = 0; i < reg_key_cnt; i++) {
        switch (reg_key_list_p[i].type) {
        case SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:

            if (cmd == SX_ACCESS_CMD_CREATE) {
                rc = rm_entries_set(RM_SDK_TABLE_TYPE_GP_REGISTER_E, SX_ACCESS_CMD_ADD, 1, NULL);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR_RESOURCE_COND(rc, "%s: rm_entries_set failed \n", __func__);
                    goto out;
                }
                rm_rollback = TRUE;
            }

            rc = __hwd_gp_register_set_wrapper(cmd, reg_key_list_p[i].key.gp_reg);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set GP register, error: [%s]\n", sx_status_str(rc));
                goto out;
            }

            if (cmd == SX_ACCESS_CMD_DESTROY) {
                rc = rm_entries_set(RM_SDK_TABLE_TYPE_GP_REGISTER_E, SX_ACCESS_CMD_DELETE, 1, NULL);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR_RESOURCE_COND(rc, "%s: rm_entries_set failed \n", __func__);
                    goto out;
                }
            }

            break;

        default:
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Failed to set register: invalid register type %d\n", reg_key_list_p[i].type);
            goto out;
        }
    }

out:

    /* RM rollback is done only on failed register */
    if (rc && (rm_rollback == TRUE)) {
        rollback_rc = rm_entries_set(RM_SDK_TABLE_TYPE_GP_REGISTER_E, SX_ACCESS_CMD_DELETE, 1, NULL);
        if (SX_STATUS_SUCCESS != rollback_rc) {
            SX_LOG_ERR_RESOURCE_COND(rollback_rc, "%s rollback: rm_entries_set failed \n", __func__);
        }
    }
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_register_impl_iter_get(sx_access_cmd_t       cmd,
                                       sx_register_key_t     reg_key,
                                       sx_register_filter_t *filter_p,
                                       sx_register_key_t    *reg_key_list_p,
                                       uint32_t             *reg_key_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = __register_hwd_gp_register_db_iter_get_wrapper(cmd, reg_key, filter_p, reg_key_list_p, reg_key_cnt_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get iterator for GP register, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

void sdk_register_impl_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }

    dbg_utils_pprinter_module_header_print(dbg_dump_params_p->stream, "Register Module");
    __hwd_gp_register_debug_dump_wrapper(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
}

sx_status_t sdk_register_impl_is_allocated(sx_register_key_t reg_key, boolean_t *is_allocated_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (reg_key.type) {
    case SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
        rc = __register_hwd_gp_register_is_allocated_wrapper(reg_key.key.gp_reg.reg_id, is_allocated_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to fetch allocation information for GP register %d, error: [%s]\n",
                       reg_key.key.gp_reg.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to fetch allocation information: invalid register type %d\n", reg_key.type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_register_impl_ref_increase(sx_register_key_t reg_key,
                                           ref_name_data_t  *ref_name_data_p,
                                           sdk_ref_t        *ref_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (reg_key.type) {
    case SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
        rc = __register_hwd_gp_register_ref_count_update_wrapper(reg_key.key.gp_reg, TRUE, ref_name_data_p, ref_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed increase reference GP register %d, error: [%s]\n",
                       reg_key.key.gp_reg.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to increase reference register: invalid register type %d\n", reg_key.type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_register_impl_ref_decrease(sx_register_key_t reg_key, sdk_ref_t *ref_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (reg_key.type) {
    case SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
        rc = __register_hwd_gp_register_ref_count_update_wrapper(reg_key.key.gp_reg, FALSE, NULL, ref_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed decrease reference GP register %d, error: [%s]\n",
                       reg_key.key.gp_reg.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to decrease reference register: invalid register type %d\n", reg_key.type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_register_mode_test_and_set(register_mode_e mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_valid_mode = FALSE;

    SX_LOG_ENTER();

    if (mode >= REGISTER_MODE_LAST_E) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid internal register mode %d\n", mode);
        goto out;
    }

    is_valid_mode = (g_register_mode == REGISTER_MODE_NONE_E) || (g_register_mode == mode);

    if (is_valid_mode == FALSE) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    g_register_mode = mode;

out:
    SX_LOG_EXIT();
    return rc;
}
