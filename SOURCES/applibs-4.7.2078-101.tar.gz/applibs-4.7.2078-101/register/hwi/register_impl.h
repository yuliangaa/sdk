/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __REGISTER_IMPL_H__
#define __REGISTER_IMPL_H__

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_register.h>
#include <sx/utils/sdk_refcount.h>
#include "utils/sx_adviser.h"
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/

typedef enum {
    REGISTER_MODE_NONE_E = 0,
    REGISTER_MODE_CUTSOM_BYTES_E,
    REGISTER_MODE_GP_REGISTER_E,
    REGISTER_MODE_LAST_E,
} register_mode_e;

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct {
    sx_status_t (*gp_register_init_pfn)();
    sx_status_t (*gp_register_deinit_pfn)(boolean_t is_forced);
    sx_status_t (*gp_register_set_validate_pfn)(sx_access_cmd_t cmd, sx_gp_register_key_t reg_key);
    sx_status_t (*gp_register_set_pfn)(sx_access_cmd_t cmd, sx_gp_register_key_t reg_key);
    sx_status_t (*gp_register_set_protected_pfn)(sx_access_cmd_t cmd, sx_gp_register_key_t reg_key);
    void (*gp_register_debug_dump_pfn)(dbg_dump_params_t *dbg_dump_params_p);
    sx_status_t (*gp_register_is_allocated_pfn)(sx_gp_register_e gp_reg_id, boolean_t *is_allocated_p);
    sx_status_t (*gp_register_ref_count_update_pfn)(sx_gp_register_key_t gp_reg,
                                                    boolean_t            increase,
                                                    ref_name_data_t     *ref_name_data_p,
                                                    sdk_ref_t           *ref_p);
    sx_status_t (*gp_register_iter_get_pfn)(sx_access_cmd_t       cmd,
                                            sx_register_key_t     reg_key,
                                            sx_register_filter_t *filter_p,
                                            sx_register_key_t    *reg_key_list_p,
                                            uint32_t             *reg_key_cnt_p);
} register_hwd_ops_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t sdk_register_impl_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

sx_status_t sdk_register_impl_init();

sx_status_t sdk_register_impl_deinit(boolean_t is_forced);

sx_status_t sdk_register_impl_set(sx_access_cmd_t    cmd,
                                  sx_register_key_t *reg_key_list_p,
                                  uint32_t           reg_key_cnt);
sx_status_t sdk_register_impl_protected_set(sx_access_cmd_t    cmd,
                                            sx_register_key_t *reg_key_list_p,
                                            uint32_t           reg_key_cnt);

sx_status_t sdk_register_impl_iter_get(sx_access_cmd_t       cmd,
                                       sx_register_key_t     reg_key,
                                       sx_register_filter_t *filter_p,
                                       sx_register_key_t    *reg_key_list_p,
                                       uint32_t             *reg_key_cnt_p);

void sdk_register_impl_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

sx_status_t sdk_register_impl_is_allocated(sx_register_key_t reg_key,
                                           boolean_t        *is_allocated_p);

sx_status_t sdk_register_impl_ref_increase(sx_register_key_t reg_key,
                                           ref_name_data_t  *ref_name_data_p,
                                           sdk_ref_t        *ref_p);

sx_status_t sdk_register_impl_ref_decrease(sx_register_key_t reg_key, sdk_ref_t *ref_p);

sx_status_t sdk_register_mode_test_and_set(register_mode_e mode);

#endif /*__REGISTER_IMPL_H__ */
