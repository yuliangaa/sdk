/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __MPE_MANAGER_H__
#define __MPE_MANAGER_H__

#include "sx/sdk/sx_status.h"
#include "sx/sdk/sx_router.h"
#include "ethl3/hwd/hwd_rif/hwd_rif_db.h"

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define FOREACH_MPE_KEY(F)          \
    F(MPE_KEY_FID_E, "MPE_KEY_FID") \
    F(MPE_KEY_RIF_E, "MPE_KEY_RIF")

typedef enum mpe_key_type {
    FOREACH_MPE_KEY(SX_GENERATE_ENUM) \
} mpe_key_type_t;

typedef struct mpe_key {
    sx_port_log_id_t log_port;
    union {
        hwd_rif_id_t rif;
        sx_fid_t     fid;
    } key;
    mpe_key_type_t type;
} mpe_key_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t mpe_manager_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t mpe_manager_init(sx_api_sx_sdk_init_t *sx_sdk_params_p, uint32_t max_mpe);
sx_status_t mpe_manager_deinit(boolean_t is_forced);

sx_status_t mpe_manager_create(mpe_key_t mpe_key, uint16_t *index_p);
sx_status_t mpe_manager_get_index(mpe_key_t mpe_key, uint16_t *index_p);
sx_status_t mpe_manager_rif_deleted(hwd_rif_id_t rif);
sx_status_t mpe_manager_fid_deleted(sx_fid_t fid);
sx_status_t mpe_manager_set(mpe_key_t mpe_key, uint16_t val);
sx_status_t mpe_manager_bulk_set(mpe_key_t         mpe_key,
                                 uint16_t          entry_num,
                                 sx_port_log_id_t *log_port_p,
                                 sx_vlan_id_t     *vlan_arr_p);

/**
 * Generates MPE manager debug dump
 * @param[in] stream A stream to output the dump to
 */
void mpe_manager_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

#endif /* __MPE_MANAGER_H__ */
