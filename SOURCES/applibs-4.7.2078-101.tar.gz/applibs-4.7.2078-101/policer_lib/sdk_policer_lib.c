/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sdk_policer_lib.h"

#include "sx_core/sx_core_cmd_db.h"
#include "sx_api/sx_api_internal.h"
#include <include/resource_manager/resource_manager.h>
#include <complib/sx_log.h>
#include <complib/cl_types.h>
#include <sx/sxd/sxd_access_register.h>
#include "sdk_policer_lib.h"
#include "policer/policer_db.h"
#include "policer/sdk_policer.h"
#include "ethl2/port.h"
#include "ethl2/port_db.h"
#include "utils/sx_adviser.h"
#include "ethl2/fdb_common.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "ethl2/lag_sink.h"
#include "policer/policer_manager.h"
#include "ethl2/brg.h"

#undef  __MODULE__
#define __MODULE__ POLICER_LIB

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/*************************************************
 *  Local Functions
 ************************************************/

static sx_status_t __policer_verbosity(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                       uint32_t cmd_body_size);
static sx_status_t __policer_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                 uint32_t cmd_body_size);
static sx_status_t __policer_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                 uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __policer_iter_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                      uint32_t cmd_body_size);
static sx_status_t __policer_counters_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                          uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __policer_counters_clear_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                                uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __policer_storm_control_counters_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                                        uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __policer_storm_control_counters_clear_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                                              uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __policer_lib_init_core_cmds(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type);
static sx_status_t __policer_lib_init_internal_apis_spectrum();
static sx_status_t __policer_lib_init_internal_apis_spectrum2();
static sx_status_t __policer_lib_init_internal_apis_spectrum4();
static sx_status_t __policer_verbosity(sx_core_td_event_src_t *event, uint8_t * cmd_body, uint32_t cmd_body_size)
{
    sx_api_command_log_verbosity_t *params = NULL;
    sx_status_t                     err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_command_log_verbosity_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_command_log_verbosity_t*)cmd_body;

    switch (params->cmd) {
    case SX_ACCESS_CMD_SET:
        err = sdk_policer_log_verbosity_level_set(params->verbosity_level);
        break;

    case SX_ACCESS_CMD_GET:
        err = sdk_policer_log_verbosity_level_get(&(params->verbosity_level));
        break;

    default:
        break;
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    params->cmd == SX_ACCESS_CMD_GET ?
                                    sizeof(sx_api_command_log_verbosity_t) : 0);

out:
    return err;
}

static sx_status_t __policer_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_policer_set_params_t *cmd_body_p = NULL;
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_policer_info_t            policer_info;


    SX_MEM_CLR(policer_info);

    if (cmd_body_size != sizeof(sx_api_policer_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_policer_set_params_t*)cmd_body;

    policer_info.policer_attributes = cmd_body_p->policer_attr;
    policer_info.policer_type = SX_POLICER_TYPE_GLOBAL_E;

    err = sdk_policer_set(cmd_body_p->cmd,
                          SX_POLICER_MODE_POLICER_E,
                          &(cmd_body_p->policer_id),
                          &policer_info);

    if (err != SX_STATUS_SUCCESS) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
        goto out;
    }

    err =
        sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)cmd_body_p, sizeof(sx_api_policer_set_params_t));

out:
    return err;
}

static sx_status_t __policer_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_policer_get_params_t *cmd_body_p = NULL;
    sx_status_t                  err = SX_STATUS_SUCCESS;


    if (cmd_body_size != sizeof(sx_api_policer_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }


    cmd_body_p = (sx_api_policer_get_params_t*)cmd_body;

    err = sdk_policer_get(cmd_body_p->policer_id,
                          &(cmd_body_p->policer_attr));
    if (err != SX_STATUS_SUCCESS) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
        goto out;
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err,
                                    (uint8_t*)cmd_body_p,
                                    sizeof(sx_api_policer_get_params_t));

out:
    return err;
}

static sx_status_t __policer_iter_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_policer_id_iter_get_params_t *params_p = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;
    uint32_t                             size = 0;
    uint32_t                             policer_id_cnt = 0;


    if (cmd_body_size != sizeof(sx_api_policer_id_iter_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params_p = (sx_api_policer_id_iter_get_params_t*)cmd_body;
    policer_id_cnt = params_p->policer_id_cnt;

    err = sdk_policer_iter_get(params_p->cmd,
                               params_p->policer_id_key,
                               &(params_p->policer_id_filter),
                               params_p->policer_id_list,
                               &policer_id_cnt);

    if (params_p->policer_id_cnt > 0) {
        size = sizeof(sx_api_policer_id_iter_get_params_t) +
               (policer_id_cnt * sizeof(sx_policer_id_t));
    } else {
        size = sizeof(sx_api_policer_id_iter_get_params_t);
    }

    params_p->policer_id_cnt = policer_id_cnt;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err,
                                    (uint8_t*)params_p, size);

out:
    return err;
}

static sx_status_t __policer_counters_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_policer_counters_get_params_t *cmd_body_p = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;


    if (cmd_body_size != sizeof(sx_api_policer_counters_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }


    cmd_body_p = (sx_api_policer_counters_get_params_t*)cmd_body;

    err = sdk_policer_counters_get(cmd_body_p->policer_id,
                                   &(cmd_body_p->policer_counters));
    if (err != SX_STATUS_SUCCESS) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
        goto out;
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err,
                                    (uint8_t*)cmd_body_p,
                                    sizeof(sx_api_policer_counters_get_params_t));

out:
    return err;
}

static sx_status_t __policer_counters_clear_set(sx_core_td_event_src_t *event,
                                                uint8_t                *cmd_body,
                                                uint32_t                cmd_body_size)
{
    sx_api_policer_counters_clear_set_params_t *cmd_body_p = NULL;
    sx_status_t                                 err = SX_STATUS_SUCCESS;


    if (cmd_body_size != sizeof(sx_api_policer_counters_clear_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }


    cmd_body_p = (sx_api_policer_counters_clear_set_params_t*)cmd_body;

    err = sdk_policer_counters_clear_set(cmd_body_p->policer_id,
                                         &cmd_body_p->policer_counters_clear);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);


out:
    return err;
}

static sx_status_t __policer_storm_control_counters_get(sx_core_td_event_src_t *event,
                                                        uint8_t                *cmd_body,
                                                        uint32_t                cmd_body_size)
{
    sx_api_port_storm_control_counters_get_params_t *cmd_body_p = NULL;
    sx_status_t                                      err = SX_STATUS_SUCCESS;
    sx_policer_id_t                                  policer_id;

    SX_MEM_CLR(policer_id);

    if (cmd_body_size != sizeof(sx_api_port_storm_control_counters_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_port_storm_control_counters_get_params_t*)cmd_body;

    SX_POLICER_LOG_PORT_SET(policer_id, cmd_body_p->log_port);
    SX_POLICER_PID_SET(policer_id, cmd_body_p->storm_control_id);

    err = sdk_policer_counters_get(policer_id,
                                   &(cmd_body_p->policer_counters));
    if (err != SX_STATUS_SUCCESS) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
        goto out;
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err,
                                    (uint8_t*)cmd_body_p,
                                    sizeof(sx_api_policer_counters_get_params_t));

out:
    return err;
}

static sx_status_t __policer_storm_control_counters_clear_set(sx_core_td_event_src_t *event,
                                                              uint8_t                *cmd_body,
                                                              uint32_t                cmd_body_size)
{
    sx_api_port_storm_control_counters_clear_set_params_t *cmd_body_p = NULL;
    sx_status_t                                            err = SX_STATUS_SUCCESS;
    sx_policer_id_t                                        policer_id;

    SX_MEM_CLR(policer_id);

    if (cmd_body_size != sizeof(sx_api_port_storm_control_counters_clear_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }


    cmd_body_p = (sx_api_port_storm_control_counters_clear_set_params_t*)cmd_body;

    SX_POLICER_LOG_PORT_SET(policer_id, cmd_body_p->log_port);
    SX_POLICER_PID_SET(policer_id, cmd_body_p->storm_control_id);

    err = sdk_policer_counters_clear_set(policer_id,
                                         &cmd_body_p->policer_counters_clear);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);


out:
    return err;
}

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
/* SPC1, SPCA1, SPC2, SPC3, SPC4 */
#define SDK_POLICER_LIB_ALLOWED_ASIC_BITMAP (ALL_ACTIVE_ETH_ASIC_BITMAP)
static sx_api_command_t sx_core_api_sx_policer_cmd_table[] = {
    {SX_API_INT_CMD_POLICER_VERBOSITY_E,        "SX_API_INT_CMD_POLICER_VERBOSITY_E",       __policer_verbosity,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_POLICER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_POLICER_SET_E,          "SX_API_INT_CMD_POLICER_SET_E",         __policer_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_POLICER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_POLICER_GET_E,          "SX_API_INT_CMD_POLICER_GET_E",         __policer_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_POLICER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_POLICER_ITER_GET_E,          "SX_API_INT_CMD_POLICER_ITER_GET_E",         __policer_iter_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SDK_POLICER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_POLICER_COUNTERS_CLEAR_SET_E, "SX_API_INT_CMD_POLICER_COUNTERS_CLEAR_SET_E",
     __policer_counters_clear_set, SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_POLICER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_POLICER_COUNTERS_GET_E, "SX_API_INT_CMD_POLICER_COUNTERS_GET_E",
     __policer_counters_get, SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_POLICER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_PORT_STORM_CONTROL_COUNTERS_GET_E,       "SX_API_INT_CMD_PORT_STORM_CONTROL_COUNTERS_GET_E",
     __policer_storm_control_counters_get,       SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_POLICER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_PORT_STORM_CONTROL_COUNTERS_CLEAR_SET_E,
     "SX_API_INT_CMD_PORT_STORM_CONTROL_COUNTERS_CLEAR_SET_E",
     __policer_storm_control_counters_clear_set,       SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SDK_POLICER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_NUM_E, "", NULL, SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, ALL_SPC_ETH_ASIC_BITMAP}     /* NULL Entry. Keep at end!! */
};

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

/* This function adds the specific policer commands to the core api command structure */
int sdk_policer_lib_init_spectrum2(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type)
{
    sx_status_t status;

    status = __policer_lib_init_core_cmds(default_verbosity, asic_type);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("__policer_lib_init_core_cmds failed, err (%s)\n", sx_status_str(status));
        goto out;
    }


    status = __policer_lib_init_internal_apis_spectrum2();
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to initialize policer lib internal APIs, err (%s)\n", sx_status_str(status));
        goto out;
    }

out:
    return (int)status;
}

/* This function adds the specific policer commands to the core api command structure */
int sdk_policer_lib_init_spectrum4(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type)
{
    sx_status_t status;

    status = __policer_lib_init_core_cmds(default_verbosity, asic_type);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("__policer_lib_init_core_cmds failed, err (%s)\n", sx_status_str(status));
        goto out;
    }


    status = __policer_lib_init_internal_apis_spectrum4();
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to initialize policer lib internal APIs, err (%s)\n", sx_status_str(status));
        goto out;
    }

out:
    return (int)status;
}

/* This function adds the specific policer commands to the core api command structure */
int sdk_policer_lib_init(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type)
{
    sx_status_t status;

    status = __policer_lib_init_core_cmds(default_verbosity, asic_type);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("__policer_lib_init_core_cmds failed, err (%s)\n", sx_status_str(status));
        goto out;
    }

    status = __policer_lib_init_internal_apis_spectrum();
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to initialize policer lib internal APIs, err (%s)\n", sx_status_str(status));
        goto out;
    }

out:
    return (int)status;
}

static sx_status_t __policer_lib_init_core_cmds(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type)
{
    int               cmd_index = 0;
    sx_api_command_t* cmd = &sx_core_api_sx_policer_cmd_table[cmd_index++];
    sx_status_t       err = SX_STATUS_SUCCESS;

    SX_LOG(SX_LOG_DEBUG, "System ASIC bit="BYTE_TO_BINARY_PATTERN,  BYTE_TO_BINARY((uint32_t)(1UL << asic_type)));

    do {
        if ((cmd->supported_asic_types) & (1UL << asic_type)) {
            SX_LOG(SX_LOG_DEBUG, "i=%d Add cmd %s to Policer Lib CMD table.\n", cmd_index, cmd->name);
            err = sx_core_set_api_command(cmd);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("sx bridge api cmd initialization failed \n");
                goto out;
            }
        } else {
            SX_LOG(SX_LOG_DEBUG, " SUPP ASIC bitmap="BYTE_TO_BINARY_PATTERN,
                   BYTE_TO_BINARY((uint32_t)(cmd->supported_asic_types)));
            SX_LOG(SX_LOG_DEBUG, "Skip adding unsupported cmd %s to SDK Policer table.\n", cmd->name);
        }
        cmd = &sx_core_api_sx_policer_cmd_table[cmd_index++];
    } while (cmd->cmd_id != SX_API_INT_CMD_NUM_E);

    LOG_VAR_NAME(__MODULE__) = default_verbosity;
    err = sdk_policer_log_verbosity_level_set(default_verbosity);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set log level, POLICER module, return message: [%s]\n", sx_status_str(err));
    }

out:
    return err;
}

static sx_status_t __policer_lib_init_internal_apis_common(policer_specific_cb_t **policer_cb_api_pp)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    status = policer_common_cb_table_get(policer_cb_api_pp);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to initialize policer lib internal APIs, err (%s)\n", sx_status_str(status));
        goto out;
    }

    /* Now we can fill the API pointers */
    (*policer_cb_api_pp)->policer_device_ready_callback = sdk_policer_device_ready_callback;
    (*policer_cb_api_pp)->policer_lag_port_update = sdk_policer_lag_port_update;
    (*policer_cb_api_pp)->policer_lag_global_update = sdk_policer_lag_global_update;
    (*policer_cb_api_pp)->policer_log_verbosity_level_set = sdk_policer_log_verbosity_level_set;
    (*policer_cb_api_pp)->policer_log_verbosity_level_get = sdk_policer_log_verbosity_level_get;
    (*policer_cb_api_pp)->policer_init = sdk_policer_init;
    (*policer_cb_api_pp)->policer_deinit = sdk_policer_deinit;
    (*policer_cb_api_pp)->policer_set = sdk_policer_set;
    (*policer_cb_api_pp)->policer_get = sdk_policer_get;
    (*policer_cb_api_pp)->policer_counters_get = sdk_policer_counters_get;
    (*policer_cb_api_pp)->policer_counters_clear_set = sdk_policer_counters_clear_set;
    (*policer_cb_api_pp)->policer_validate_attrib = NULL;
    (*policer_cb_api_pp)->policer_db_create = sdk_policer_db_create;
    (*policer_cb_api_pp)->policer_storm_control_bind_validations = NULL;
    (*policer_cb_api_pp)->policer_storm_control_set = sdk_port_storm_control_set;
    (*policer_cb_api_pp)->policer_storm_control_get = sdk_policer_storm_control_get;

out:
    return status;
}

static sx_status_t __policer_lib_init_internal_apis_spectrum()
{
    sx_status_t            status = SX_STATUS_SUCCESS;
    policer_specific_cb_t* policer_cb_api_p = NULL;

    status = __policer_lib_init_internal_apis_common(&policer_cb_api_p);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed common initialize policer lib internal APIs, err (%s)\n", sx_status_str(status));
        goto out;
    }
    /* Following are the callbacks that are different between chip types */
    policer_cb_api_p->policer_validate_attrib = sdk_policer_validate_attrib_spectrum;
out:
    return status;
}

static sx_status_t __policer_lib_init_internal_apis_spectrum2()
{
    sx_status_t            status = SX_STATUS_SUCCESS;
    policer_specific_cb_t* policer_cb_api_p = NULL;

    status = __policer_lib_init_internal_apis_common(&policer_cb_api_p);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed common initialize policer lib internal APIs, err (%s)\n", sx_status_str(status));
        goto out;
    }
    /* Following are the callbacks that are different between chip types */
    policer_cb_api_p->policer_validate_attrib = sdk_policer_validate_attrib_spectrum2;
out:
    return status;
}

static sx_status_t __policer_lib_init_internal_apis_spectrum4()
{
    sx_status_t            status = SX_STATUS_SUCCESS;
    policer_specific_cb_t* policer_cb_api_p = NULL;

    status = __policer_lib_init_internal_apis_common(&policer_cb_api_p);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed common initialize policer lib internal APIs, err (%s)\n", sx_status_str(status));
        goto out;
    }
    /* Following are the callbacks that are different between chip types */
    policer_cb_api_p->policer_validate_attrib = sdk_policer_validate_attrib_spectrum4;
out:
    return status;
}
