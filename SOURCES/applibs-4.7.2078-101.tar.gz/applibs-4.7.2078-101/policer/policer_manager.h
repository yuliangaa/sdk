/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __POLICER_MANAGER_H_INCL__
#define __POLICER_MANAGER_H_INCL__

/**
 * Policer manager module responsible for management of policer ID table
 * The module has the following operations:
 *  - Init/Deinit.
 *  - Add block/Delete block
 *  - Add reference to data/ Delete reference (for cost calculation)
 */

#include <sx/utils/linear_manager.h>
#include <complib/cl_types.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

#define POLICER_MANAGER_BA_INDEX_TO_GLOBAL_ID(id) (id + rm_resource_global.policer_host_ifc_pool_size)
#define POLICER_MANAGER_GLOBAL_ID_TO_BA_INDEX(id) (id - rm_resource_global.policer_host_ifc_pool_size)
#define POLICER_MANAGER_GLOBAL_POLICER_TYPE_GET(id)                                                \
    ((id <= rm_resource_global.policer_host_ifc_pool_size)                                         \
     ? POLICER_MANAGER_TYPE_HOST_IFC_E :                                                           \
     ((id <= rm_resource_global.policer_host_ifc_pool_size + rm_resource_global.policer_pool_size) \
      ? POLICER_MANAGER_TYPE_ACL_E : POLICER_MANAGER_TYPE_SPAN_E))


#define POLICER_MANAGER_BA_INDEX_TO_SPAN_ID(id)       \
    (id +                                             \
     (rm_resource_global.policer_host_ifc_pool_size + \
      rm_resource_global.policer_pool_size))
#define POLICER_MANAGER_SPAN_ID_TO_BA_INDEX(id)       \
    (id -                                             \
     (rm_resource_global.policer_host_ifc_pool_size + \
      rm_resource_global.policer_pool_size))

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum policer_manager_policer_type {
    POLICER_MANAGER_TYPE_ACL_E           = 1,
    POLICER_MANAGER_TYPE_HOST_IFC_E      = 2,
    POLICER_MANAGER_TYPE_STORM_CONTROL_E = 3,
    POLICER_MANAGER_TYPE_SPAN_E          = 4,
    POLICER_MANAGER_TYPE_MIN_E           = POLICER_MANAGER_TYPE_ACL_E,
    POLICER_MANAGER_TYPE_MAX_E           = POLICER_MANAGER_TYPE_SPAN_E
} policer_manager_policer_type_e;

/*A policer handle is the identifier of a policer. This number will be associated with one policer only, from the time it is created until it is destroyed. It will not change due to defragmentation */
typedef linear_manager_handle_t policer_manager_handle_t;


/* A policer index is the hardware index of the policer. This index will not change as long as the policer is locked. */
typedef ba_index_t policer_manager_index_t;

/* can be 1 or 2 according to the policer type */
typedef uint32_t policer_manager_block_length_t;

typedef uint32_t policer_manager_user_handle_t;

/**
 * Callback function.
 * Copies contents of block from old index to new index.
 * This callback is called when bin allocator relocates a block
 * @param policer_id            [in] The policer ID of the block which is being relocated
 * @param size                  [in] The block size
 * @param old_index             [in] index to relocate from
 * @param new_index             [in] index to relocate to
 * size will be the size of the block.
 * The contents from new_index until new_index+size should be copied
 * It is guaranteed that this callback is never called on a locked block
 */
typedef sx_status_t (*policer_block_copy_t)(sx_policer_id_t                policer_id,
                                            policer_manager_block_length_t size,
                                            policer_manager_index_t        old_index,
                                            policer_manager_index_t        new_index);


/**
 * Callback function.
 * increase the new_index policer counters with old_index values
 * This callback is called when bin allocator relocates a block
 * @param policer_id            [in] The policer ID of the policer which is being relocated
 * @param size                  [in] The block size
 * @param old_index             [in] index to take counters from
 * @param new_index             [in] index to increase counters
 * The contents from new_index until new_index+size should be copied
 * It is guaranteed that this callback is never called on a locked block
 */
typedef sx_status_t (*policer_increase_counters_t)(sx_policer_id_t                policer_id,
                                                   policer_manager_block_length_t size,
                                                   policer_manager_index_t        old_index,
                                                   policer_manager_index_t        new_index);

/**
 * Callback function.
 * Changes all references to the block
 * This callback is called when bin allocator relocates a block
 * @param policer_id            [in] The policer ID of the policer which is being relocated
 * @param size                  [in] The block size
 * @param old_index             [in] index to relocate from
 * @param new_index             [in] index to relocate to
 * The contents from new_index until new_index+size should be copied
 * It is guaranteed that this callback is never called on a locked block
 */
typedef sx_status_t (*policer_change_refs_cb_t)(sx_policer_id_t                policer_id,
                                                policer_manager_block_length_t size,
                                                policer_manager_index_t        old_index,
                                                policer_manager_index_t        new_index);

typedef struct policer_manager_user_params {
    /*callback function to relocate block from old index to new index*/
    policer_change_refs_cb_t change_refs_cb;
    boolean_t                is_initialized;
} policer_manager_user_params_t;

typedef struct policer_manager_params {
    boolean_t                     is_initialized;
    policer_manager_index_t       global_table_size;
    policer_manager_index_t       host_ifc_table_size;
    policer_manager_index_t       storm_control_table_size;
    policer_manager_index_t       span_table_size;
    policer_block_copy_t          block_copy;
    policer_increase_counters_t   increase_counters;
    policer_manager_user_params_t user_params;
    ba_handle_t                   global_ba_handle;
    ba_handle_t                   host_ifc_ba_handle;
    ba_handle_t                   storm_control_ba_handle;
    ba_handle_t                   span_ba_handle;
    ba_group_t                    global_ba_group;
    ba_group_t                    host_ifc_ba_group;
    ba_group_t                    storm_control_ba_group;
    ba_group_t                    span_ba_group;
    boolean_t                     global_ba_group_used;
    boolean_t                     host_ifc_ba_group_used;
    boolean_t                     storm_control_ba_group_used;
    boolean_t                     span_ba_group_used;
} policer_manager_params_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initialize policer manager module
 *
 * @param global_start_index           [in] First index into the global policer table
 * @param global_end_index             [in] One after the last index into the global policer table
 * @param global_start_index           [in] First index into the host_ifc policer table
 * @param global_end_index             [in] One after the last index into the host_ifc policer table
 * @param copy_callback                [in] Callback function that creates a new policer in the de-fragmentation process
 * @param increase_counters_callback   [in] Callback function that increases a policer counters in the de-fragmentation process
 */
sx_status_t policer_manager_init(policer_manager_index_t     global_start_index,
                                 policer_manager_index_t     global_end_index,
                                 policer_manager_index_t     host_ifc_start_index,
                                 policer_manager_index_t     host_ifc_end_index,
                                 policer_manager_index_t     storm_control_start_index,
                                 policer_manager_index_t     storm_control_end_index,
                                 policer_manager_index_t     span_start_index,
                                 policer_manager_index_t     span_end_index,
                                 policer_block_copy_t        copy_callback,
                                 policer_increase_counters_t increase_counters_callback);

/**
 * Deinitialize policer manager module
 *
 */
sx_status_t policer_manager_deinit(void);

/**
 * Initialize policer block relocate callback function
 *
 * @param block_relocate_callback [in] Callback function that updates all the references of a policer in the defragmentation process
 * @param user_handle_p [out] the user handle
 */
sx_status_t policer_manager_user_init(policer_change_refs_cb_t       block_relocate_callback,
                                      policer_manager_user_handle_t *user_handle_p);
/**
 * Deinitialize policer manager user callback
 * @param user_handle [in] the user handle to deinit
 *
 */
sx_status_t policer_manager_user_deinit(policer_manager_user_handle_t user_handle);

/**
 * Add block to policer manager table
 * A user calls this function to add a new block.
 * Further operations on the block are done using the returned policer ID.
 *
 * @param size                  [in] Size of block
 * @param is_host_ifc           [in] is the policer a host_ifc policer
 * @param policer_id_p          [out] Returns a policer ID
 *
 */
sx_status_t policer_manager_block_add(policer_manager_block_length_t size,
                                      policer_manager_policer_type_e policer_type,
                                      sx_policer_id_t               *policer_id_p);

/**
 * Delete a block from policer table
 *
 * @param policer_id               [in] A policer ID
 */
sx_status_t policer_manager_block_delete(sx_policer_id_t                policer_id,
                                         policer_manager_policer_type_e policer_type);

/**
 * Get size of block
 *
 * @param policer_id           [in] A policer_ID
 * @param size                 [out] Returns the size of the block
 *
 */
sx_status_t policer_manager_block_size_get(sx_policer_id_t                 policer_id,
                                           policer_manager_policer_type_e  policer_type,
                                           policer_manager_block_length_t *size_p);

/**
 * Lock a block in order to perform HW operations
 * Call this function to prevent relocation of the block until it is released.
 * @param policer_id           [in] A policer ID
 * @param index_p              [out] Returns the hardware index of the policer
 * @param size_p               [out] Returns the actual size of the policer
 *
 */
sx_status_t policer_manager_handle_lock(sx_policer_id_t                 policer_id,
                                        policer_manager_policer_type_e  policer_type,
                                        policer_manager_index_t        *index_p,
                                        policer_manager_block_length_t *size_p);

/**
 * Release a locked policer, so it can be relocated again
 *
 * @param policer_id           [in] A policer ID
 */
sx_status_t policer_manager_handle_release(sx_policer_id_t                policer_id,
                                           policer_manager_policer_type_e policer_type);

/**
 * Add a reference to a policer, and update its relocation cost
 *
 * @param policer_id           [in] A policer ID
 */
sx_status_t policer_manager_ref_add(sx_policer_id_t                policer_id,
                                    policer_manager_policer_type_e policer_type);

/**
 * Delete a reference to a policer, and update its relocation cost
 *
 * @param policer_id               [in] A policer ID
 */
sx_status_t policer_manager_ref_delete(sx_policer_id_t                policer_id,
                                       policer_manager_policer_type_e policer_type);


#endif /* __POLICER_MANAGER_H_INCL__ */
