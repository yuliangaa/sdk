/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "ulay_default_rif_tunnel_impl.h"
#include <complib/cl_byteswap.h>
#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <complib/cl_mem.h>
#include <utils/utils.h>
#include <sx/sdk/sx_types.h>

#include <ethl3/hwi/sdk_router/sdk_router_impl.h>
#include <ethl3/hwi/sdk_router_vrid/sdk_router_vrid_impl.h>
#include <ethl3/hwi/rif/rif_db.h>
#include <ethl3/hwi/rif/rif_impl.h>
#include <ethl3/hwi/rif/rif_be.h>
#include <ethl2/vlan.h>
#include <ethl2/fdb.h>
#include "ethl2/brg.h"
#include "tunnel_impl.h"
#include "decap_table_impl.h"
#include "ulay_default_rif_tunnel_impl.h"
#include "mc_container/hwi/mc_container_impl.h"
#include "tunnel/hwd/hwd_tunnel.h"

#undef  __MODULE__
#define __MODULE__ TUNNEL

/************************************************
 *  Global variables
 ***********************************************/

extern rm_resources_t   rm_resource_global;
extern sx_brg_context_t brg_context;

/************************************************
 *  Local defines
 ***********************************************/

/* The following define indicates that VRID is not created yet. */
#define SX_TUNNEL_UNDERLAY_VRID_INVALID (0xFFFF)

#define VXLAN_NON_RESERVED_BITS_MASK  (~0xF7FFFFFF000000FF)
#define GPE_NON_RESERVED_BITS_MASK    (~0xC0FFFF00000000FF)
#define GENEVE_NON_RESERVED_BITS_MASK (~0x003F0000000000FF)
#define NVGRE_NON_RESERVED_BITS_MASK  (~(0x0FF80000ULL))

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/* The following VRID is internal and used only for default underlay RIF in case
 * of backward compatible flow, so it won't be used in case of uRIF was not created.
 */
static sx_router_id_t __tunnel_dummy_vrid = SX_TUNNEL_UNDERLAY_VRID_INVALID;

/************************************************
 *  Local function declarations
 ***********************************************/

static sx_status_t __ulay_default_rif_tunnel_impl_underlay_vrid_get(const sx_tunnel_attribute_t *tunnel_attr_p,
                                                                    sx_router_id_t              *vrid_p);
static sx_status_t __ulay_default_rif_tunnel_impl_underlay_vrid_cleanup(const sx_router_id_t vrid);
static sx_status_t __ulay_default_rif_tunnel_impl_prepare_create(sx_tunnel_attribute_t * tunnel_attr_p,
                                                                 sx_tunnel_id_t        * tunnel_id_p);
static sx_status_t __ulay_default_rif_tunnel_impl_prepare_create_rollback(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                                          sx_tunnel_id_t              * tunnel_id_p);
static sx_status_t __ulay_default_rif_tunnel_impl_get_underlay_rif_and_validate_edit_action(
    sx_tunnel_direction_e   direction,
    sx_tunnel_attribute_t  *tunnel_attr_p,
    sx_router_interface_t * underlay_rif_p);
static sx_status_t __ulay_default_rif_tunnel_impl_edit_action(sx_tunnel_id_t              tunnel_id,
                                                              const sdk_db_tunnel_data_t *tunnel_params_p,
                                                              sx_tunnel_attribute_t      *old_tunnel_attr,
                                                              sx_tunnel_attribute_t     * new_tunnel_attr_p);
static sx_status_t __ulay_default_rif_tunnel_impl_post_edit_action(sx_tunnel_id_t                tunnel_id,
                                                                   sx_tunnel_attribute_t        *old_tunnel_attr,
                                                                   const sx_tunnel_attribute_t * new_tunnel_attr_p);
static sx_status_t __ulay_default_rif_tunnel_impl_edit_action_rollback(sx_tunnel_id_t                tunnel_id,
                                                                       const sdk_db_tunnel_data_t   *tunnel_params_p,
                                                                       sx_tunnel_attribute_t        *old_tunnel_attr,
                                                                       const sx_tunnel_attribute_t * new_tunnel_attr_p);
static sx_status_t __ulay_default_rif_tunnel_impl_delete_action_rollback(sx_tunnel_id_t              tunnel_id,
                                                                         const sdk_db_tunnel_data_t *tunnel_params_p);
static sx_status_t __ulay_default_rif_tunnel_impl_delete_action(sx_tunnel_id_t              tunnel_id,
                                                                const sdk_db_tunnel_data_t *tunnel_params_p);
static sx_status_t __ulay_default_rif_tunnel_impl_check_learn_mode(sx_port_log_id_t    log_port,
                                                                   sx_fdb_learn_mode_t learn_mode);

/* Check if loopback RIF exist */
static sx_status_t __ulay_default_rif_tunnel_impl_check_loopback_rif_exist(sx_router_interface_t loopback_rif);
static sx_status_t __ulay_default_rif_tunnel_impl_init_hwd(void);
static sx_status_t __ulay_default_rif_tunnel_impl_counter_get(const sx_tunnel_id_t        tunnel_id,
                                                              const sdk_db_tunnel_data_t *tunnel_params_p,
                                                              boolean_t                   is_clear,
                                                              sx_tunnel_counter_t        *counter_p);
static sx_status_t __ulay_default_rif_tunnel_impl_check_init_params(sx_tunnel_general_params_t * params_p);
static boolean_t __ulay_tunnel_impl_l3_gw_supported(sx_tunnel_id_t tunnel_id);

static sx_status_t __l2_ethertype_validate(const sx_tunnel_attribute_t *tunnel_attr_p);
static sx_status_t __ulay_tunnel_impl_attr_validate_spectrum2(sx_tunnel_attribute_t * tunnel_attr_p);
static sx_status_t __ulay_tunnel_impl_attr_validate_spectrum4(sx_tunnel_attribute_t * tunnel_attr_p);

static sx_status_t __ulay_default_rif_tunnel_impl_validate_ipinip_rif(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                                      const sx_tunnel_id_t        * tunnel_id_p);
static sx_status_t __ulay_default_rif_tunnel_impl_validate_l2_tunnel_rif(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                                         const sx_tunnel_id_t        * tunnel_id_p);


/************************************************
 *  Local variables
 ***********************************************/

static tunnel_ops_t ulay_default_rif_tunnel_impl_ops = {
    .hwi_tunnel_impl_init_hwd_pfn = __ulay_default_rif_tunnel_impl_init_hwd,
    .hwi_tunnel_impl_prepare_create_pfn = __ulay_default_rif_tunnel_impl_prepare_create,
    .hwi_tunnel_impl_prepare_create_rollback_pfn = __ulay_default_rif_tunnel_impl_prepare_create_rollback,
    .hwi_tunnel_impl_delete_action_pfn = __ulay_default_rif_tunnel_impl_delete_action,
    .hwi_tunnel_impl_delete_action_rollback_pfn = __ulay_default_rif_tunnel_impl_delete_action_rollback,
    .hwi_tunnel_impl_edit_action_pfn = __ulay_default_rif_tunnel_impl_edit_action,
    .hwi_tunnel_impl_post_edit_action_pfn = __ulay_default_rif_tunnel_impl_post_edit_action,
    .hwi_tunnel_impl_edit_action_rollback_pfn = __ulay_default_rif_tunnel_impl_edit_action_rollback,
    .hwi_tunnel_impl_check_learn_mode_pfn = __ulay_default_rif_tunnel_impl_check_learn_mode,
    .hwi_tunnel_impl_counter_get_pfn = __ulay_default_rif_tunnel_impl_counter_get,
    .hwi_tunnel_impl_check_init_params_pfn = __ulay_default_rif_tunnel_impl_check_init_params,
    .hwi_tunnel_impl_l3_gw_supported = __ulay_tunnel_impl_l3_gw_supported,
    .hwi_tunnel_impl_attr_validate_pfn = __ulay_tunnel_impl_attr_validate_spectrum2,
};

static hwd_tunnel_ops_t ulay_default_rif_hwd_tunnel_ops = {
    hwd_tunnel_init,                            /* hwd_tunnel_init_pfn */
    hwd_tunnel_deinit,                          /* hwd_tunnel_deinit_pfn */
    ulay_default_rif_hwd_tunnel_create,         /* hwd_tunnel_create_pfn */
    ulay_default_rif_hwd_tunnel_delete,         /* hwd_tunnel_delete_pfn */
    ulay_default_rif_hwd_tunnel_edit,           /* hwd_tunnel_edit_pfn */
    hwd_tunnel_decap_block_lock,                /* hwd_tunnel_decap_block_lock_pfn */
    hwd_tunnel_decap_block_unlock,              /* hwd_tunnel_decap_block_unlock_pfn */
    hwd_tunnel_encap_block_lock,                /* hwd_tunnel_encap_block_lock_pfn */
    hwd_tunnel_encap_block_unlock,              /* hwd_tunnel_encap_block_unlock_pfn */
    ulay_default_rif_hwd_tunnel_counter_get,    /* hwd_tunnel_counter_get_pfn */
    hwd_tunnel_tunnel_mapping_add,              /* hwd_tunnel_tunnel_mapping_add_pfn */
    hwd_tunnel_tunnel_mapping_update,           /* hwd_tunnel_tunnel_mapping_update_pfn */
    hwd_tunnel_tunnel_mapping_delete,           /* hwd_tunnel_tunnel_mapping_delete_pfn */
    hwd_tunnel_port_isolate_hw_set,             /* hwd_tunnel_port_isolate_hw_set_pfn */
    hwd_tunnel_ttl_set_spc2,                    /* hwd_tunnel_ttl_set_pfn */
    hwd_tunnel_ttl_get_spc2,                    /* hwd_tunnel_ttl_get_pfn */
    hwd_tunnel_hash_set,                        /* hwd_tunnel_hash_set_pfn */
    hwd_tunnel_hash_get,                        /* hwd_tunnel_hash_get_pfn */
    hwd_tunnel_cos_set,                         /* hwd_tunnel_cos_set_pfn */
    hwd_tunnel_cos_get,                         /* hwd_tunnel_cos_get_pfn */
    ulay_default_rif_hwd_tunnel_debug_dump,     /* hwd_tunnel_debug_dump_pfn */
    ulay_default_rif_hwd_tunnel_counter_clear,  /* hwd_tunnel_counter_clear_pfn */
    hwd_tunnel_nve_reg_deinit,                  /* hwd_tunnel_nve_reg_deinit_pfn */
    hwd_tunnel_issu_vni_set,                    /* hwd_tunnel_issu_vni_set_pfn */
    hwd_tunnel_nve_learn_set_spc2,              /* hwd_tunnel_nve_learn_set_pfn */
    hwd_tunnel_nve_loopback_filter_set,         /* hwd_tunnel_nve_loopback_filter_set_pfn */
    hwd_tunnel_nve_port_issu_end_set,           /* hwd_tunnel_nve_port_issu_end_set_pfn */
    hwd_tunnel_nve_group_size_flood_get_spc2,   /* hwd_tunnel_nve_group_size_flood_get_pfn */
    hwd_tunnel_nve_group_size_mc_get_spc2,      /* hwd_tunnel_nve_group_size_mc_get_pfn */
    hwd_tunnel_zeroed_reserved_tngee_index_get, /* hwd_tunnel_zeroed_reserved_tngee_index_get_pfn */
};

/************************************************
 *  Function implementations
 ***********************************************/

static sx_status_t __ulay_tunnel_impl_attr_validate_spectrum2(sx_tunnel_attribute_t *tunnel_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = __l2_ethertype_validate(tunnel_attr_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Invalid NVE ethertype is specified, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.vxlan.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            SX_LOG_ERR("The check mask mode is not supported on this device.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mask = 0;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.vxlan_gpe.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            SX_LOG_ERR("The check mask mode is not supported on this device.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mask = 0;
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.geneve.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            SX_LOG_ERR("The check mask mode is not supported on this device.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mask = 0;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.nvgre.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            SX_LOG_ERR("The check mask mode is not supported on this device.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mask = 0;
        break;

    default:
        break;
    }

out:
    return err;
}

static sx_status_t __ulay_tunnel_impl_attr_validate_spectrum4(sx_tunnel_attribute_t *tunnel_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = __l2_ethertype_validate(tunnel_attr_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Invalid NVE ethertype is specified, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.vxlan.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            if (tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mask & VXLAN_NON_RESERVED_BITS_MASK) {
                SX_LOG_ERR("VXLAN mask includes non-reserved bits [0x%" PRIx64 "].\n",
                           tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mask);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        } else {
            tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mask = 0;
        }
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.vxlan_gpe.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            if (tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mask & GPE_NON_RESERVED_BITS_MASK) {
                SX_LOG_ERR("VXLAN GPE mask includes non-reserved bits [0x%" PRIx64 "].\n",
                           tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mask);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        } else {
            tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mask = 0;
        }
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.geneve.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            if (tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mask & GENEVE_NON_RESERVED_BITS_MASK) {
                SX_LOG_ERR("GENEVE mask includes non-reserved bits [0x%" PRIx64 "].\n",
                           tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mask);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        } else {
            tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mask = 0;
        }

        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.nvgre.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            if (tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mask & NVGRE_NON_RESERVED_BITS_MASK) {
                SX_LOG_ERR("NVGRE mask includes invalid bits [0x%" PRIx64 "].\n",
                           tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mask);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        } else {
            tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mask = 0;
        }

        break;

    default:
        break;
    }

out:
    return err;
}

static sx_status_t __l2_ethertype_validate(const sx_tunnel_attribute_t *tunnel_attr_p)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    sx_vlan_tag_mode_t tag_mode = SX_VLAN_TAG_MODE_802_1Q_E;
    boolean_t          egress_et_set = FALSE;
    sx_ether_type_t    ethertype = 0;

    SX_LOG_ENTER();

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        tag_mode = tunnel_attr_p->attributes.vxlan.decap.tag_mode;
        egress_et_set = tunnel_attr_p->attributes.vxlan.decap.egress_et_set;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        tag_mode = tunnel_attr_p->attributes.vxlan_gpe.decap.tag_mode;
        egress_et_set = tunnel_attr_p->attributes.vxlan_gpe.decap.egress_et_set;
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        tag_mode = tunnel_attr_p->attributes.geneve.decap.tag_mode;
        egress_et_set = tunnel_attr_p->attributes.geneve.decap.egress_et_set;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        tag_mode = tunnel_attr_p->attributes.nvgre.decap.tag_mode;
        egress_et_set = tunnel_attr_p->attributes.nvgre.decap.egress_et_set;
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        tag_mode = tunnel_attr_p->attributes.l2_flex.decap.tag_mode;
        egress_et_set = tunnel_attr_p->attributes.l2_flex.decap.egress_et_set;
        if (egress_et_set != FALSE) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Setting the Ethertype after decapsulation at the egress port is not supported, error= %s.\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    default:
        break;
    }

    if ((egress_et_set == FALSE) && (tag_mode == SX_VLAN_TAG_MODE_802_1AD_E)) {
        err = sx_port_ethertype_get(VLAN_ETHER_TYPE_INDEX_1, &ethertype);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to verify the .1AD EtherType is configured, error: (%s)\n",
                       sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t ulay_default_rif_tunnel_init_ops(void)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = sdk_tunnel_impl_register_tunnel_ops(&ulay_default_rif_tunnel_impl_ops);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register tunnel ops, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = hwd_tunnel_urif_internal_callbacks_register();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register HWD tunnel ops, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t ulay_default_rif_tunnel_init_ops_spectrum4(void)
{
    sx_status_t  sx_status = SX_STATUS_SUCCESS;
    tunnel_ops_t ops;

    SX_LOG_ENTER();

    SX_MEM_CPY(ops, ulay_default_rif_tunnel_impl_ops);
    ops.hwi_tunnel_impl_attr_validate_pfn = __ulay_tunnel_impl_attr_validate_spectrum4;

    sx_status = sdk_tunnel_impl_register_tunnel_ops(&ops);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register tunnel ops, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = hwd_tunnel_urif_internal_callbacks_register_spectrum4();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register HWD tunnel ops, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


const char* get_tunnel_underlay_rif_ref_name(char* name_buf, size_t name_size, void* data)
{
    rif_tunnel_t *rip_tunnel_p = (rif_tunnel_t*)data;

    snprintf(name_buf, name_size, "TUN%d_UNDERLAY_RIF%d", rip_tunnel_p->tunnel_id, rip_tunnel_p->rif);
    return name_buf;
}

const char* get_tunnel_underlay_rif_decap_ref_name(char* name_buf, size_t name_size, void* data)
{
    rif_tunnel_t *rip_tunnel_p = (rif_tunnel_t*)data;

    snprintf(name_buf, name_size, "TUN%d_DECAP_UNDERLAY_RIF%d", rip_tunnel_p->tunnel_id, rip_tunnel_p->rif);
    return name_buf;
}

static sx_status_t __ulay_default_rif_tunnel_impl_check_init_params(sx_tunnel_general_params_t * params_p)
{
    params_p->nve.flood_ecmp_enabled = FALSE; /* For Spectrum only */
    params_p->nve.mc_ecmp_enabled = FALSE;    /* For Spectrum only */
    params_p->nve.ecmp_max_size = 0;          /* For Spectrum only */
    return SX_STATUS_SUCCESS;
}


sx_status_t sdk_ulay_default_rif_tunnel_impl_create_validation(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                               sx_tunnel_id_t              * tunnel_id_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_router_interface_t            underlay_rif = 0;
    sx_router_interface_t            underlay_decap_rif = 0;
    sx_tunnel_id_t                   tunnel_id = *tunnel_id_p;
    sx_tunnel_underlay_domain_type_e underlay_domain_type;

    err = tunnel_impl_get_underlay_rif(tunnel_attr_p, &underlay_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }
    err = tunnel_impl_get_underlay_decap_rif(tunnel_attr_p, &underlay_decap_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay decap RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    underlay_domain_type = tunnel_impl_get_underlay_domain_type(tunnel_attr_p);

    /* Check Underlay Domain Type */
    switch (underlay_domain_type) {
    case SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID:
        if ((underlay_rif != 0) || (underlay_decap_rif != 0)) {
            /* Validation Error */
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Validation error Underlay Rif [%d] is set but should not be when setting Underlay Domain type to VRID tunnel[0x%08x], err = %s\n"
                       ,
                       underlay_rif,
                       tunnel_id,
                       sx_status_str(
                           err));
            goto out;
        }
        break;

    case SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF:
        /* The validation for this type is done on higher levels. */
        break;

    default:
        SX_LOG_ERR("Error Unknown Underlay domain Type [%d] tunnel[0x%08x], err = %s\n",
                   underlay_domain_type, tunnel_id, sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(sx_access_cmd_t        access_cmd,
                                                              sx_router_id_t         vrid,
                                                              sx_router_interface_t *loopback_rif)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_router_interface_param_t ifc;
    sx_interface_attributes_t   ifc_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(ifc);
    SX_MEM_CLR(ifc_attr);

    ifc.type = SX_L2_INTERFACE_TYPE_LOOPBACK;
    ifc_attr.loopback_enable = TRUE;
    ifc_attr.mtu = SX_PORT_MTU_MAX;
    err = sdk_router_interface_set(access_cmd,
                                   vrid,
                                   &ifc,
                                   &ifc_attr,
                                   loopback_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("could not create loopback rif(err=%s)\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t __ulay_default_rif_tunnel_impl_check_loopback_rif_exist(sx_router_interface_t loopback_rif)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_router_interface_param_t ifc;
    sx_interface_attributes_t   ifc_attr;
    sx_router_id_t              vrid;

    SX_LOG_ENTER();

    SX_MEM_CLR(ifc);
    SX_MEM_CLR(ifc_attr);
    SX_MEM_CLR(vrid);

    err = sdk_router_interface_get(loopback_rif,
                                   &vrid,
                                   &ifc,
                                   &ifc_attr);
    if (err == SX_STATUS_ENTRY_NOT_FOUND) {
        goto out;
    } else if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("could not get loopback rif(err=%s)\n", sx_status_str(err));
        goto out;
    }

    /* Validate RIF is loopback */
    if (ifc.type != SX_L2_INTERFACE_TYPE_LOOPBACK) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ulay_default_rif_tunnel_impl_validate_ipinip_rif(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                                      const sx_tunnel_id_t        * tunnel_id_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_router_interface_t underlay_rif = 0;
    sx_tunnel_id_t        tunnel_id = *tunnel_id_p;

    SX_LOG_ENTER();

    err = tunnel_impl_get_underlay_rif(tunnel_attr_p, &underlay_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    /* Check if underlay RIF exist */
    err = __ulay_default_rif_tunnel_impl_check_loopback_rif_exist(underlay_rif);
    if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    if (err == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_ERR("Failed in create tunnel[0x%08x], encap Underlay RIF does not exist err = %s\n",
                   tunnel_id,
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ulay_default_rif_tunnel_impl_validate_l2_tunnel_rif(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                                         const sx_tunnel_id_t        * tunnel_id_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_router_interface_t underlay_rif = 0;
    sx_router_interface_t underlay_rif_decap = 0;
    sx_tunnel_id_t        tunnel_id = *tunnel_id_p;

    SX_LOG_ENTER();

    if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
        err = tunnel_impl_get_underlay_rif(tunnel_attr_p, &underlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        /* Check if underlay RIF exist */
        err = __ulay_default_rif_tunnel_impl_check_loopback_rif_exist(underlay_rif);
        if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("Failed in create tunnel[0x%08x], encap Underlay RIF does not exist err = %s\n",
                       tunnel_id,
                       sx_status_str(err));
            goto out;
        }

        if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
            err = sdk_tunnel_impl_flex_header_bind_get(tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                                                       NULL);
            if (err == SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Cannot create flex tunnel [0x%08x], flex tunnel header [%u] is already in use\n",
                           tunnel_id, tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id);
                err = SX_STATUS_RESOURCE_IN_USE;
                goto out;
            } else if (err != SX_STATUS_ENTRY_NOT_BOUND) {
                SX_LOG_ERR("Cannot create flex tunnel [0x%08x], flex tunnel header [%u] is invalid\n",
                           tunnel_id, tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id);
                goto out;
            }
        }
    }

    if (SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id)) {
        err = tunnel_impl_get_underlay_decap_rif(tunnel_attr_p, &underlay_rif_decap);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] decap underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        /* Check if decap underlay RIF exist */
        err = __ulay_default_rif_tunnel_impl_check_loopback_rif_exist(underlay_rif_decap);
        if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] decap underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("Failed in create tunnel[0x%08x], decap Underlay RIF does not exist err = %s\n",
                       tunnel_id,
                       sx_status_str(err));
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ulay_default_rif_tunnel_impl_prepare_create(sx_tunnel_attribute_t * tunnel_attr_p,
                                                                 sx_tunnel_id_t        * tunnel_id_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_status_t                      rollback_err = SX_STATUS_SUCCESS;
    sdk_ref_t                        rif_ref;
    boolean_t                        rif_ref_increase_rollback = FALSE;
    boolean_t                        rif_ref_tunnel_attach_rollback = FALSE;
    boolean_t                        vrid_to_default_rif_rollback = FALSE;
    boolean_t                        underlay_rif_ref_increase_rollback = FALSE;
    boolean_t                        underlay_rif_decap_ref_increase_rollback = FALSE;
    boolean_t                        underlay_rif_l2_tunnel_attach_rollback = FALSE;
    boolean_t                        flex_header_bind_rollback = FALSE;
    boolean_t                        default_rif_rollback = FALSE;
    boolean_t                        counter_alloc_rollback = FALSE;
    boolean_t                        counter_bind_rollback = FALSE;
    sdk_db_tunnel_data_t             tunnel_params;
    sx_tunnel_id_t                   tmp_tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_tunnel_id_t                   tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_port_log_id_t                 log_port = 0;
    sx_fdb_learn_mode_t              learn_mode_old;
    sx_router_interface_t            ipinip_overlay_rif;
    rif_tunnel_t                     rif_tunnel_data;
    rif_tunnel_t                     rif_decap_tunnel_data;
    sx_tunnel_underlay_domain_type_e underlay_domain_type;
    ref_name_data_t                  ipinip_olay_rif_name_data = {.print_func_p = get_tunnel_rif_ref_name,
                                                                  .ref_data_p = &rif_tunnel_data,
                                                                  .data_size = sizeof(rif_tunnel_data)};
    ref_name_data_t                  ulay_rif_name_data = {.print_func_p = get_tunnel_underlay_rif_ref_name,
                                                           .ref_data_p = &rif_tunnel_data,
                                                           .data_size = sizeof(rif_tunnel_data)};
    ref_name_data_t                  ulay_rif_decap_name_data =
    {.print_func_p = get_tunnel_underlay_rif_decap_ref_name,
     .ref_data_p = &rif_decap_tunnel_data,
     .data_size = sizeof(rif_decap_tunnel_data)};
    sx_router_interface_t          underlay_rif = 0;
    sx_router_interface_t          underlay_rif_decap = 0;
    sx_router_interface_t          default_underlay_rif = 0;
    sx_router_id_t                 underlay_vrid = 0;
    sdk_ref_t                      underlay_rif_ref = 0;
    sdk_ref_t                      underlay_rif_decap_ref = 0;
    sx_router_counter_id_t         counter_id;
    sx_router_counter_attributes_t cntr_attributes;

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_params);
    SX_MEM_CLR(rif_ref);
    SX_MEM_CLR(underlay_rif_ref);
    SX_MEM_CLR(ipinip_overlay_rif);
    SX_MEM_CLR(tmp_tunnel_id);
    SX_MEM_CLR(underlay_rif);
    SX_MEM_CLR(default_underlay_rif);
    SX_MEM_CLR(underlay_vrid);
    SX_MEM_CLR(cntr_attributes);

    tmp_tunnel_id = *tunnel_id_p;
    tunnel_id = *tunnel_id_p;

    err = sdk_ulay_default_rif_tunnel_impl_create_validation(tunnel_attr_p, tunnel_id_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in create validation for tunnel[0x%08x], err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = tunnel_impl_get_underlay_rif(tunnel_attr_p, &underlay_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }
    err = tunnel_impl_get_underlay_decap_rif(tunnel_attr_p, &underlay_rif_decap);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay decap RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    /* Ulay default RIF behavior: Need to set underlay RIF at Underlay ingress router interface */
    /* Encap flow: Create default RIF and set underlay_rif param */
    underlay_domain_type = tunnel_impl_get_underlay_domain_type(tunnel_attr_p);

    if (underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) {
        if (SX_TUNNEL_TYPE_IPINIP_CHECK(tunnel_id)) {
            err = __ulay_default_rif_tunnel_impl_validate_ipinip_rif(tunnel_attr_p, tunnel_id_p);
        } else {
            err = __ulay_default_rif_tunnel_impl_validate_l2_tunnel_rif(tunnel_attr_p, tunnel_id_p);
        }
    } else if (underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        err = __ulay_default_rif_tunnel_impl_underlay_vrid_get(tunnel_attr_p, &underlay_vrid);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] underlay VRID, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        /* If not exist create default RIF */
        /* Default RIF for VRID should be created */

        /* Check VRID-default-RIF exist */
        err = sdk_tunnel_db_vrid_to_default_rif_mapping_get(underlay_vrid,
                                                            &default_underlay_rif);
        if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] default underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            /* Default RIF does not exist */
            /* Create the loopback RIF. This behavior is keep backward compatible behavior with Spectrum */

            err = sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(SX_ACCESS_CMD_ADD,
                                                                    underlay_vrid,
                                                                    &default_underlay_rif);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in create loop back RIF for tunnel[0x%08x], err = %s\n",
                           tunnel_id,
                           sx_status_str(err));
                goto out;
            }
            default_rif_rollback = TRUE;

            /* Add to Map */
            vrid_to_default_rif_rollback = TRUE;
            err = sdk_tunnel_db_vrid_to_default_rif_mapping_add(underlay_vrid,
                                                                default_underlay_rif);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't add mapping tunnel[0x%08x] default underlay RIF, err = %s\n",
                           tunnel_id,
                           sx_status_str(err));
                goto out;
            }


            /* Add counter to the RIF */
            cntr_attributes.type = SX_ROUTER_COUNTER_TYPE_BASIC;
            err = sdk_router_interface_counter_alloc_set(SX_ACCESS_CMD_CREATE, &counter_id, cntr_attributes);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't create underlay RIF counter for tunnel[0x%08x], err = %s\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }
            counter_alloc_rollback = TRUE;

            err = sdk_router_interface_counter_bind_set(SX_ACCESS_CMD_BIND, counter_id, default_underlay_rif);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't bind counter [%#x] to underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                           counter_id, default_underlay_rif, tunnel_id, sx_status_str(err));
                goto out;
            }
            counter_bind_rollback = TRUE;

            err = sdk_router_interface_counter_clear(counter_id, FALSE);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't clear counter [%#x] of underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                           counter_id, default_underlay_rif, tunnel_id, sx_status_str(err));
                goto out;
            }
        }
        /* Update underlay_rif value */
        underlay_rif = default_underlay_rif;
        err = tunnel_impl_set_underlay_rif(tunnel_attr_p, underlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't set tunnel[0x%08x] default underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        err = tunnel_impl_set_decap_underlay_rif(tunnel_attr_p, underlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't set tunnel[0x%08x] default underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }


        err = sdk_tunnel_db_edit(tunnel_id, tunnel_attr_p);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to update tunnel[%d] attr to DB, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
    }

    if ((underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) || SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
        rif_tunnel_data.tunnel_id = tmp_tunnel_id;
        rif_tunnel_data.rif = underlay_rif;
        err = sdk_rif_impl_ref_increase(
            underlay_rif,
            &ulay_rif_name_data,
            &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to increase underlay RIF[%d] reference, err = %s\n",
                       underlay_rif, sx_status_str(err));
            goto out;
        }
        underlay_rif_ref_increase_rollback = TRUE;

        err = sdk_tunnel_db_ulay_rif_ref_set(tunnel_id, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to assign underlay RIF[%d] to tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
        /* Set the underlay rif for L2 flex tunnels. Specifically the rif to usip mapping.  */
        if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
            err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_ADD,
                                                 underlay_rif,
                                                 tunnel_attr_p);

            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to attach L2 flex tunnel to underlay_rif[%d], err = %s\n",
                           underlay_rif, sx_status_str(err));
                goto out;
            }
            underlay_rif_l2_tunnel_attach_rollback = TRUE;

            /* Set the rif in the flex header as well and take reference to it */
            err = sdk_tunnel_impl_flex_header_bind(tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                                                   tunnel_id,
                                                   underlay_rif);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to update rif [%u] and bind to flex tunnel header [%u], err = %s\n",
                           underlay_rif,
                           tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                           sx_status_str(err));
                goto out;
            }
            flex_header_bind_rollback = TRUE;
        }
    }

    if ((underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) &&
        (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id))
        && SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id)) {
        /* Increase decap underlay RIF callback */
        rif_decap_tunnel_data.tunnel_id = tmp_tunnel_id;
        rif_decap_tunnel_data.rif = underlay_rif_decap;
        err = sdk_rif_impl_ref_increase(
            underlay_rif_decap,
            &ulay_rif_decap_name_data,
            &underlay_rif_decap_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to increase underlay RIF[%d] decap reference, err = %s\n",
                       underlay_rif_decap, sx_status_str(err));
            goto out;
        }
        underlay_rif_decap_ref_increase_rollback = TRUE;

        err = sdk_tunnel_db_ulay_rif_decap_ref_set(tunnel_id, &underlay_rif_decap_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to assign decap_underlay RIF[%d] to tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
    } else if (SX_TUNNEL_TYPE_IPINIP_CHECK(tmp_tunnel_id)) {
        err = tunnel_impl_get_ipinip_overlay_rif(tunnel_attr_p, &ipinip_overlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] overlay RIF, err = %s\n", tmp_tunnel_id, sx_status_str(err));
            goto out;
        }

        /* Underlay VRID configuration is not allowed in Phoenix - uVRID is reserved. */
        tunnel_attr_p->attributes.ipinip_p2p.encap.underlay_vrid = 0;

        err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_ADD,
                                             ipinip_overlay_rif,
                                             tunnel_attr_p);

        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to attach tunnel to overlay_rif[%d], err = %s\n",
                       ipinip_overlay_rif, sx_status_str(err));
            goto out;
        }
        rif_tunnel_data.tunnel_id = tmp_tunnel_id;
        rif_tunnel_data.rif = ipinip_overlay_rif;
        rif_ref_tunnel_attach_rollback = TRUE;
        err = sdk_rif_impl_ref_increase(
            ipinip_overlay_rif,
            &ipinip_olay_rif_name_data,
            &rif_ref);

        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to increase RIF[%d] reference, err = %s\n",
                       ipinip_overlay_rif, sx_status_str(err));
            goto out;
        }
        rif_ref_increase_rollback = TRUE;
        err = sdk_tunnel_db_rif_ref_set(tmp_tunnel_id, &rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to assign RIF[%d] to tunnel, err = %s\n",
                       tmp_tunnel_id, sx_status_str(err));
            goto out;
        }
    }

    /* Disable learning if tunnel type is Flex or IPv6. */
    if ((tunnel_attr_p->type == SX_TUNNEL_TYPE_L2_FLEX) ||
        (tunnel_attr_p->type == SX_TUNNEL_TYPE_L2_FLEX_IPV6) ||
        (SX_TUNNEL_TYPE_NVE_VXLAN_IPV6 == tunnel_attr_p->type) ||
        (SX_TUNNEL_TYPE_NVE_NVGRE_IPV6 == tunnel_attr_p->type)) {
        log_port = tunnel_impl_get_l2_log_port(tunnel_attr_p);

        /* Get current learn mode */
        err = fdb_port_learn_mode_get(log_port, &learn_mode_old);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get learning mode for logical port %u\n", log_port);
            goto out;
        }

        if (learn_mode_old != SX_FDB_LEARN_MODE_DONT_LEARN) {
            SX_LOG_WRN("Disabling learning mode for logical port 0x%x\n", log_port);

            err = fdb_port_learn_mode_set(log_port, SX_FDB_LEARN_MODE_DONT_LEARN, FALSE);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to disable learning for logical port 0x%x in tunnel %u\n",
                           log_port, tmp_tunnel_id);
                goto out;
            }
        }
    }

out:
    if (SX_STATUS_SUCCESS != err) {
        if (rif_ref_increase_rollback) {
            rollback_err = sdk_rif_impl_ref_decrease(ipinip_overlay_rif,
                                                     &rif_ref);
            if (rollback_err) {
                SX_LOG_ERR("Failed to reference for RIF[%d], err = %s\n",
                           ipinip_overlay_rif, sx_status_str(rollback_err));
            }
        }

        if (rif_ref_tunnel_attach_rollback) {
            rollback_err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_DELETE,
                                                          ipinip_overlay_rif,
                                                          tunnel_attr_p);

            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to rollback attach overlay RIF[%d] for tunnel, err = %s\n",
                           ipinip_overlay_rif, sx_status_str(rollback_err));
            }
        }

        if (default_rif_rollback) {
            rollback_err =
                sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(SX_ACCESS_CMD_DELETE,
                                                                  underlay_vrid,
                                                                  &default_underlay_rif);
            if (rollback_err) {
                SX_LOG_ERR("Failed to delete loop back RIF for tunnel[0x%08x], err = %s\n", tunnel_id,
                           sx_status_str(rollback_err));
            }
        }

        if (counter_bind_rollback) {
            rollback_err =
                sdk_router_interface_counter_bind_set(SX_ACCESS_CMD_UNBIND, counter_id, default_underlay_rif);
            if (rollback_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to unbind counter [%#x] from underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                           counter_id, default_underlay_rif, tunnel_id, sx_status_str(rollback_err));
            }
        }

        if (counter_alloc_rollback) {
            rollback_err = sdk_router_interface_counter_alloc_set(SX_ACCESS_CMD_DESTROY, &counter_id, cntr_attributes);
            if (rollback_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to delete underlay RIF counter [%#x] for tunnel[0x%08x], err = %s\n",
                           counter_id, tunnel_id, sx_status_str(rollback_err));
            }
        }

        if (vrid_to_default_rif_rollback) {
            rollback_err = sdk_tunnel_db_vrid_to_default_rif_mapping_delete(underlay_vrid);
            if (rollback_err) {
                SX_LOG_ERR("Failed to remove mapping of VRID [%d] to default underlay RIF, err = %s\n",
                           underlay_vrid,
                           sx_status_str(rollback_err));
            }
        }

        if (underlay_rif_ref_increase_rollback) {
            rollback_err = sdk_rif_impl_ref_decrease(
                underlay_rif, &underlay_rif_ref);
            if (rollback_err) {
                SX_LOG_ERR("Failed to decrease underlay RIF[%d] reference, err = %s\n",
                           underlay_rif, sx_status_str(rollback_err));
            }
        }

        if (flex_header_bind_rollback == TRUE) {
            rollback_err = sdk_tunnel_impl_flex_header_unbind(
                tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                tunnel_id);
            if (SX_CHECK_FAIL(rollback_err)) {
                SX_LOG_ERR("Failed to rollback unbind to flex tunnel header [%u] tunnel id [%u], err = %s\n",
                           tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                           tunnel_id,
                           sx_status_str(err));
                goto out;
            }
        }

        if (underlay_rif_l2_tunnel_attach_rollback) {
            rollback_err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_DELETE,
                                                          underlay_rif,
                                                          tunnel_attr_p);
            if (rollback_err) {
                SX_LOG_ERR("Failed to detach underlay RIF[%d] rollback, err = %s\n",
                           underlay_rif, sx_status_str(rollback_err));
            }
        }

        if (underlay_rif_decap_ref_increase_rollback) {
            rollback_err = sdk_rif_impl_ref_decrease(
                underlay_rif_decap, &underlay_rif_decap_ref);
            if (rollback_err) {
                SX_LOG_ERR("Failed to decrease decap underlay RIF[%d] reference, err = %s\n",
                           underlay_rif, sx_status_str(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t __ulay_default_rif_tunnel_impl_prepare_create_rollback(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                                   sx_tunnel_id_t              * tunnel_id_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sdk_ref_t                        vrid_ref;
    sdk_ref_t                        rif_ref;
    sdk_db_tunnel_data_t             tunnel_params;
    sx_tunnel_id_t                   tmp_tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_router_interface_t            ipinip_overlay_rif;
    sx_tunnel_id_t                   tunnel_id = SX_TUNNEL_ID_INVALID;
    sdk_ref_t                        underlay_rif_ref;
    sx_router_interface_t            underlay_rif = 0;
    sdk_ref_t                        underlay_rif_decap_ref;
    sx_router_interface_t            underlay_rif_decap = 0;
    sx_router_id_t                   underlay_vrid;
    uint32_t                         interface_ref_cnt = 0;
    sx_tunnel_underlay_domain_type_e underlay_domain_type;
    sx_router_counter_id_t           counter_id;
    sx_router_counter_attributes_t   cntr_attributes = {.type = SX_ROUTER_COUNTER_TYPE_BASIC};


    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_params);
    SX_MEM_CLR(vrid_ref);
    SX_MEM_CLR(rif_ref);
    SX_MEM_CLR(ipinip_overlay_rif);
    SX_MEM_CLR(tmp_tunnel_id);
    SX_MEM_CLR(underlay_rif);
    SX_MEM_CLR(underlay_rif_ref);
    SX_MEM_CLR(underlay_rif_decap);
    SX_MEM_CLR(underlay_rif_decap_ref);
    SX_MEM_CLR(tunnel_id);
    SX_MEM_CLR(underlay_vrid);
    SX_MEM_CLR(underlay_domain_type);

    tmp_tunnel_id = *tunnel_id_p;
    tunnel_id = *tunnel_id_p;
    underlay_domain_type = tunnel_impl_get_underlay_domain_type(tunnel_attr_p);

    err = __ulay_default_rif_tunnel_impl_underlay_vrid_get(tunnel_attr_p, &underlay_vrid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay VRID, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = tunnel_impl_get_underlay_rif(tunnel_attr_p, &underlay_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
        err = sdk_tunnel_db_ulay_rif_ref_get(tunnel_id, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get underlay RIF[%d] reference of tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_rif_impl_ref_decrease(underlay_rif, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to decrease underlay RIF[%d] reference, err = %s\n",
                       underlay_rif, sx_status_str(err));
            goto out;
        }

        if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
            /* Remove the underlay rif for L2 flex tunnels */
            err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_DELETE,
                                                 underlay_rif,
                                                 tunnel_attr_p);

            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to delete L2 flex tunnel to underlay_rif[%d], err = %s\n",
                           underlay_rif, sx_status_str(err));
                goto out;
            }
            /* Unbind from the flex tunnel header */
            err = sdk_tunnel_impl_flex_header_unbind(tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                                                     tunnel_id);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to rollback unbind to flex tunnel header [%u] tunnel id [%u], err = %s\n",
                           tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                           tunnel_id,
                           sx_status_str(err));
                goto out;
            }
        }
    }

    if ((underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) &&
        (SX_TUNNEL_TYPE_NVE_CHECK(tmp_tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(tmp_tunnel_id))
        && SX_TUNNEL_DIRECTION_CHECK_DECAP(tmp_tunnel_id)) {
        err = tunnel_impl_get_underlay_decap_rif(tunnel_attr_p, &underlay_rif_decap);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] decap underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_ulay_rif_ref_get(tunnel_id, &underlay_rif_decap_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get decap underlay RIF[%d] reference of tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_rif_impl_ref_decrease(
            underlay_rif_decap, &underlay_rif_decap_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to decrease decap underlay RIF[%d] reference, err = %s\n",
                       underlay_rif_decap, sx_status_str(err));
            goto out;
        }
    }

    if (underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        /* Get default RIF */
        err = sdk_tunnel_db_vrid_to_default_rif_mapping_get(underlay_vrid, &underlay_rif);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get mapping of VRID [%d] to default underlay RIF, err = %s\n",
                       underlay_vrid,
                       sx_status_str(err));
            goto out;
        }

        /* If ref count of default RIF is 0 we need to delete the RIF */
        /* Get Default RIF and read then reference count of the default RIF */

        /*
         * check ref.count
         */
        err = sdk_rif_db_rif_ref_cnt_get(underlay_rif, &interface_ref_cnt);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get RIF count of underlay RIF [%d] to default underlay RIF, err = %s\n",
                       underlay_rif,  sx_status_str(err));
            goto out;
        }

        if (interface_ref_cnt == 0) {
            /* Default RIF is not in used delete it */
            /* Delete only if reference is 0... */

            /* Get RIF counter */
            err = sdk_router_interface_counter_bind_get_counter(underlay_rif, &counter_id);
            if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
                SX_LOG_ERR("Can't find counter to underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                           underlay_rif, tunnel_id, sx_status_str(err));
                /* Not a critical issue */
            } else if (err == SX_STATUS_SUCCESS) {
                /* Unbind and delete counter */
                err = sdk_router_interface_counter_bind_set(SX_ACCESS_CMD_UNBIND, counter_id, underlay_rif);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to unbind counter [%#x] from underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                               counter_id, underlay_rif, tunnel_id, sx_status_str(err));
                    goto out;
                }

                err = sdk_router_interface_counter_alloc_set(SX_ACCESS_CMD_DESTROY, &counter_id, cntr_attributes);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to delete underlay RIF counter [%#x] for tunnel[0x%08x], err = %s\n",
                               counter_id, tunnel_id, sx_status_str(err));
                    goto out;
                }
            }


            err = sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(SX_ACCESS_CMD_DELETE, underlay_vrid,
                                                                    &underlay_rif);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to delete loop back RIF for tunnel[0x%08x], err = %s\n", tunnel_id,
                           sx_status_str(err));
                goto out;
            }


            err = sdk_tunnel_db_vrid_to_default_rif_mapping_delete(underlay_vrid);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to remove mapping of VRID [%d] to default underlay RIF, err = %s\n",
                           underlay_vrid,
                           sx_status_str(err));
                goto out;
            }
        }
    }

    if (SX_TUNNEL_TYPE_IPINIP_CHECK(tmp_tunnel_id)) {
        err = tunnel_impl_get_ipinip_overlay_rif(tunnel_attr_p, &ipinip_overlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] overlay RIF, err = %s\n", tmp_tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_rif_ref_get(tmp_tunnel_id, &rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get RIF of tunnel [%d], err = %s\n",
                       tmp_tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_rif_impl_ref_decrease(ipinip_overlay_rif,
                                        &rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to reference for RIF[%d], err = %s\n",
                       ipinip_overlay_rif, sx_status_str(err));
        }


        err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_DELETE,
                                             ipinip_overlay_rif,
                                             tunnel_attr_p);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to rollback attach overlay RIF[%d] for tunnel, err = %s\n",
                       ipinip_overlay_rif, sx_status_str(err));
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __ulay_default_rif_tunnel_impl_get_underlay_rif_and_validate_edit_action(sx_tunnel_direction_e   direction,
                                                                                     sx_tunnel_attribute_t * tunnel_attr_p,
                                                                                     sx_router_interface_t * underlay_rif_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    /* Get underlay RIF */
    switch (direction) {
    case SX_TUNNEL_DIRECTION_ENCAP:
        err = tunnel_impl_get_underlay_rif(tunnel_attr_p, underlay_rif_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel underlay RIF, err = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case SX_TUNNEL_DIRECTION_DECAP:
        err = tunnel_impl_get_underlay_decap_rif(tunnel_attr_p, underlay_rif_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel decap underlay RIF, err = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Can't get underlay_rif. Invalid direction %d\n", direction);
        goto out;
    }

    /* Check if underlay RIF exist */
    err = __ulay_default_rif_tunnel_impl_check_loopback_rif_exist(*underlay_rif_p);
    if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Error checking loopback RIF exist, err = %s\n",
                   sx_status_str(err));
        goto out;
    } else if (err == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_ERR("Failed in edit tunnel, Underlay RIF does not exist err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    return err;
}


sx_status_t sdk_ulay_default_rif_tunnel_impl_swap_underlay_rif(sx_tunnel_id_t          tunnel_id,
                                                               sx_tunnel_attribute_t * new_tunnel_attr_p,
                                                               sx_tunnel_direction_e   direction,
                                                               sx_router_interface_t   old_underlay_rif,
                                                               sx_router_interface_t   new_underlay_rif)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    rif_tunnel_t    rif_tunnel_data;
    sdk_ref_t       underlay_rif_ref = 0;
    sx_status_t     rollback_err = SX_STATUS_SUCCESS;
    boolean_t       underlay_rif_ref_increase_rollback = FALSE;
    boolean_t       underlay_rif_ref_decrease_rollback = FALSE;
    ref_name_data_t ulay_rif_name_data = {.print_func_p = get_tunnel_underlay_rif_ref_name,
                                          .ref_data_p = &rif_tunnel_data,
                                          .data_size = sizeof(rif_tunnel_data)};

    SX_LOG_ENTER();

    if (direction == SX_TUNNEL_DIRECTION_ENCAP) {
        err = sdk_tunnel_db_ulay_rif_ref_get(tunnel_id, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get underlay RIF[%d] tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
        ulay_rif_name_data.print_func_p = get_tunnel_underlay_rif_ref_name;
    } else if (direction == SX_TUNNEL_DIRECTION_DECAP) {
        err = sdk_tunnel_db_ulay_rif_decap_ref_get(tunnel_id, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get underlay RIF[%d] tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
        ulay_rif_name_data.print_func_p = get_tunnel_underlay_rif_ref_name;
    } else {
        /* Invalid direction */
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to get underlay RIF[%d] tunnel, err = %s\n",
                   tunnel_id, sx_status_str(err));
    }

    rif_tunnel_data.tunnel_id = tunnel_id;
    rif_tunnel_data.rif = old_underlay_rif;

    err = sdk_rif_impl_ref_decrease(old_underlay_rif, &underlay_rif_ref);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to decrease old underlay RIF[%d] reference, err = %s\n",
                   old_underlay_rif, sx_status_str(err));
        goto out;
    }

    underlay_rif_ref_decrease_rollback = TRUE;

    rif_tunnel_data.tunnel_id = tunnel_id;
    rif_tunnel_data.rif = new_underlay_rif;

    err = sdk_rif_impl_ref_increase(new_underlay_rif, &ulay_rif_name_data, &underlay_rif_ref);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to increase underlay RIF[%d] reference, err = %s\n",
                   new_underlay_rif, sx_status_str(err));
        goto out;
    }

    underlay_rif_ref_increase_rollback = TRUE;

    if (direction == SX_TUNNEL_DIRECTION_ENCAP) {
        err = sdk_tunnel_db_ulay_rif_ref_set(tunnel_id, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to assign underlay RIF[%d] to tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = tunnel_impl_set_underlay_rif(new_tunnel_attr_p, new_underlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't set tunnel[0x%08x] new underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }
    } else if (direction == SX_TUNNEL_DIRECTION_DECAP) {
        err = sdk_tunnel_db_ulay_rif_decap_ref_set(tunnel_id, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to assign underlay RIF[%d] to tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = tunnel_impl_set_decap_underlay_rif(new_tunnel_attr_p, new_underlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't set tunnel[0x%08x] new underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }
    }

    err = sdk_tunnel_db_edit(tunnel_id, new_tunnel_attr_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to update tunnel[%d] attr to DB, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    if (SX_STATUS_SUCCESS != err) {
        if (underlay_rif_ref_decrease_rollback) {
            rollback_err = sdk_rif_impl_ref_increase(old_underlay_rif, &ulay_rif_name_data, &underlay_rif_ref);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to decrease underlay RIF[%d] reference, err = %s\n",
                           new_underlay_rif, sx_status_str(rollback_err));
            }
        }

        if (underlay_rif_ref_increase_rollback) {
            rollback_err = sdk_rif_impl_ref_decrease(new_underlay_rif, &underlay_rif_ref);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to decrease underlay RIF[%d] reference, err = %s\n",
                           new_underlay_rif, sx_status_str(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t __ulay_default_rif_tunnel_impl_edit_action(sx_tunnel_id_t               tunnel_id,
                                                       const sdk_db_tunnel_data_t * tunnel_params_p,
                                                       sx_tunnel_attribute_t      * old_tunnel_attr,
                                                       sx_tunnel_attribute_t      * new_tunnel_attr_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_status_t                      rollback_err = SX_STATUS_SUCCESS;
    sx_router_id_t                   old_uvrid, new_uvrid;
    sx_router_interface_t            old_underlay_rif = 0;
    sx_router_interface_t            old_underlay_rif_decap = 0;
    sx_router_interface_t            new_underlay_rif = 0;
    sx_router_interface_t            new_underlay_rif_decap = 0;
    sx_router_interface_t            default_underlay_rif = 0;
    boolean_t                        default_rif_rollback = FALSE;
    boolean_t                        vrid_to_default_rif_rollback = FALSE;
    sx_tunnel_underlay_domain_type_e old_underlay_domain_type;
    sx_tunnel_underlay_domain_type_e new_underlay_domain_type;
    sx_router_counter_id_t           counter_id = 0;
    sx_router_counter_attributes_t   cntr_attributes = {.type = SX_ROUTER_COUNTER_TYPE_BASIC};
    boolean_t                        counter_alloc_rollback = FALSE;
    boolean_t                        counter_bind_rollback = FALSE;
    sx_tunnel_id_t                   bound_flex_tunnel_id = SX_TUNNEL_ID_INVALID;
    uint32_t                         tunnel_refcount = 0;

    SX_LOG_ENTER();

    UNUSED_PARAM(tunnel_params_p);

    SX_MEM_CLR(old_uvrid);
    SX_MEM_CLR(new_uvrid);
    SX_MEM_CLR(new_underlay_domain_type);
    SX_MEM_CLR(old_underlay_domain_type);

    new_underlay_domain_type = tunnel_impl_get_underlay_domain_type(new_tunnel_attr_p);
    old_underlay_domain_type = tunnel_impl_get_underlay_domain_type(old_tunnel_attr);

    if (old_underlay_domain_type != new_underlay_domain_type) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Can't edit tunnel[0x%08x] underlay domain type, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = __ulay_default_rif_tunnel_impl_underlay_vrid_get(old_tunnel_attr, &old_uvrid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay VRID, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = __ulay_default_rif_tunnel_impl_underlay_vrid_get(new_tunnel_attr_p, &new_uvrid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay VRID, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    if (old_underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        err = sdk_tunnel_db_vrid_to_default_rif_mapping_get(old_uvrid, &old_underlay_rif);
        if ((err != SX_STATUS_SUCCESS)) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        /* default RIF for VRID should be created */
        /* Check VRID-default-RIF exist */
        err = sdk_tunnel_db_vrid_to_default_rif_mapping_get(new_uvrid, &default_underlay_rif);
        if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] default underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            /* Default RIF does not exist */
            /* Create the loopback RIF. This behavior is keep backward compatible behavior with Spectrum */
            /* Not clear whether this may happen */

            err =
                sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(SX_ACCESS_CMD_ADD, new_uvrid, &default_underlay_rif);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in create loopback RIF for tunnel[0x%08x], err = %s\n", tunnel_id,
                           sx_status_str(err));
                goto out;
            }
            default_rif_rollback = TRUE;

            /* Add to Map */
            err = sdk_tunnel_db_vrid_to_default_rif_mapping_add(new_uvrid, default_underlay_rif);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't add mapping tunnel[0x%08x] default underlay RIF, err = %s\n",
                           tunnel_id,
                           sx_status_str(err));
                goto out;
            }
            vrid_to_default_rif_rollback = TRUE;

            /* Add counter to the RIF */
            cntr_attributes.type = SX_ROUTER_COUNTER_TYPE_BASIC;
            err = sdk_router_interface_counter_alloc_set(SX_ACCESS_CMD_CREATE, &counter_id, cntr_attributes);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't create underlay RIF counter for tunnel[0x%08x], err = %s\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }
            counter_alloc_rollback = TRUE;

            err = sdk_router_interface_counter_bind_set(SX_ACCESS_CMD_BIND, counter_id, default_underlay_rif);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't bind counter [%#x] to underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                           counter_id, default_underlay_rif, tunnel_id, sx_status_str(err));
                goto out;
            }
            counter_bind_rollback = TRUE;

            err = sdk_router_interface_counter_clear(counter_id, FALSE);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't clear counter [%#x] of underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                           counter_id, default_underlay_rif, tunnel_id, sx_status_str(err));
                goto out;
            }
        }
        /* Update underlay_rif value */
        new_underlay_rif = default_underlay_rif;

        /* copy old uRIF since it is default for VRID domain type */
        err = tunnel_impl_set_underlay_rif(new_tunnel_attr_p,  default_underlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't set tunnel[0x%08x] encap uRIF %u, err = %s\n", tunnel_id, default_underlay_rif,
                       sx_status_str(err));
            goto out;
        }

        err = tunnel_impl_set_decap_underlay_rif(new_tunnel_attr_p,  default_underlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't set tunnel[0x%08x] decap uRIF %u, err = %s\n", tunnel_id, default_underlay_rif,
                       sx_status_str(err));
            goto out;
        }
    } else if (old_underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) {
        /* Get encap underlay RIF */
        if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
            err = tunnel_impl_get_underlay_rif(old_tunnel_attr, &old_underlay_rif);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
                goto out;
            }

            err = __ulay_default_rif_tunnel_impl_get_underlay_rif_and_validate_edit_action(SX_TUNNEL_DIRECTION_ENCAP,
                                                                                           new_tunnel_attr_p,
                                                                                           &new_underlay_rif);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to validate edit tunnel[0x%08x] decap underlay RIF, err = %s\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }
            /* check that the new flex header exists and it's not bound to some other flex tunnel */
            if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
                err = sdk_tunnel_impl_flex_header_bind_get(
                    new_tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                    &bound_flex_tunnel_id);
                if (err == SX_STATUS_SUCCESS) {
                    if (bound_flex_tunnel_id != tunnel_id) {
                        SX_LOG_ERR("Cannot change flex tunnel [0x%08x], flex tunnel header [%u] is already in use\n",
                                   tunnel_id,
                                   new_tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id);
                        err = SX_STATUS_PARAM_ERROR;
                        goto out;
                    }
                } else if (err != SX_STATUS_ENTRY_NOT_BOUND) {
                    SX_LOG_ERR("Cannot change flex tunnel [0x%08x], flex tunnel header [%u] is invalid\n",
                               tunnel_id, new_tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id);
                    goto out;
                }
                err = SX_STATUS_SUCCESS;

                err = sdk_tunnel_db_ref_count_get(tunnel_id, &tunnel_refcount, 0, NULL);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to get the tunnel[0x%08x] ref.count from DB, err = %s\n",
                               tunnel_id, sx_status_str(err));
                    goto out;
                }

                if (new_tunnel_attr_p->attributes.l2_flex.encap.underlay_rif !=
                    old_tunnel_attr->attributes.l2_flex.encap.underlay_rif) {
                    SX_LOG_ERR("Tunnel underlay_rif cannot be changed for used L2 flex tunnel\n");
                    err = SX_STATUS_UNSUPPORTED;
                    goto out;
                }

                if (!SX_IP_ADDR_EQUAL(new_tunnel_attr_p->attributes.l2_flex.encap.underlay_sip,
                                      old_tunnel_attr->attributes.l2_flex.encap.underlay_sip)) {
                    SX_LOG_ERR("Tunnel underlay_sip cannot be changed for used L2 flex tunnel\n");
                    err = SX_STATUS_UNSUPPORTED;
                    goto out;
                }
            }
        }

        if ((SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) &&
            SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id)) {
            /* Get old decap underlay RIF */
            err = tunnel_impl_get_underlay_decap_rif(old_tunnel_attr, &old_underlay_rif_decap);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't get tunnel[0x%08x] decap underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
                goto out;
            }

            err = __ulay_default_rif_tunnel_impl_get_underlay_rif_and_validate_edit_action(SX_TUNNEL_DIRECTION_DECAP,
                                                                                           new_tunnel_attr_p,
                                                                                           &new_underlay_rif_decap);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to validate edit tunnel[0x%08x] decap underlay RIF, err = %s\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }
        }
    } else {
        /* Unknown underlay domain type */
        SX_LOG_ERR("Unknown underlay domain type tunnel[0x%08x], err = %s\n", tunnel_id, sx_status_str(err));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
        if (old_underlay_rif != new_underlay_rif) {
            err = sdk_ulay_default_rif_tunnel_impl_swap_underlay_rif(tunnel_id,
                                                                     new_tunnel_attr_p,
                                                                     SX_TUNNEL_DIRECTION_ENCAP,
                                                                     old_underlay_rif,
                                                                     new_underlay_rif);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to swap old and new encap underlay RIF[%d] tunnel, err = %s\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }

            if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
                err = sdk_tunnel_impl_flex_header_unbind(
                    old_tunnel_attr->attributes.l2_flex.encap.tunnel_flex_header_id,
                    tunnel_id);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to unbind flex tunnel header for tunnel edit [%u], err = %s\n",
                               old_tunnel_attr->attributes.l2_flex.encap.tunnel_flex_header_id,
                               sx_status_str(err));
                    goto out;
                }
                err = sdk_tunnel_impl_flex_header_bind(
                    new_tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                    tunnel_id,
                    new_underlay_rif);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR(
                        "Failed to update rif [%u] and bind to flex tunnel header [%u] for tunnel edit, err = %s\n",
                        new_underlay_rif,
                        new_tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                        sx_status_str(err));
                    goto out;
                }

                err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_DELETE,
                                                     old_underlay_rif,
                                                     old_tunnel_attr);

                if (SX_STATUS_SUCCESS != err) {
                    SX_LOG_ERR("Failed to detach L2 flex tunnel to underlay_rif [%d] edit, err = %s\n",
                               old_underlay_rif, sx_status_str(err));
                    goto out;
                }
                err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_ADD,
                                                     new_underlay_rif,
                                                     new_tunnel_attr_p);

                if (SX_STATUS_SUCCESS != err) {
                    SX_LOG_ERR("Failed to attach L2 flex tunnel to underlay_rif [%d] edit, err = %s\n",
                               new_underlay_rif, sx_status_str(err));
                    goto out;
                }
            }
        }
    }

    /* Get decap underlay RIF */
    if ((old_underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) &&
        SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id) && SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id)) {
        if (old_underlay_rif_decap != new_underlay_rif_decap) {
            /* Underlay domain type is RIF */
            err = sdk_ulay_default_rif_tunnel_impl_swap_underlay_rif(tunnel_id,
                                                                     new_tunnel_attr_p,
                                                                     SX_TUNNEL_DIRECTION_DECAP,
                                                                     old_underlay_rif_decap,
                                                                     new_underlay_rif_decap);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to swap old and new decap underlay RIF[%d] tunnel, err = %s\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }
        }
    }

out:
    if (SX_STATUS_SUCCESS != err) {
        if (counter_bind_rollback) {
            rollback_err =
                sdk_router_interface_counter_bind_set(SX_ACCESS_CMD_UNBIND, counter_id, default_underlay_rif);
            if (rollback_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to unbind counter [%#x] from underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                           counter_id, default_underlay_rif, tunnel_id, sx_status_str(rollback_err));
            }
        }

        if (counter_alloc_rollback) {
            rollback_err = sdk_router_interface_counter_alloc_set(SX_ACCESS_CMD_DESTROY, &counter_id, cntr_attributes);
            if (rollback_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to delete underlay RIF counter [%#x] for tunnel[0x%08x], err = %s\n",
                           counter_id, tunnel_id, sx_status_str(rollback_err));
            }
        }

        if (default_rif_rollback) {
            rollback_err = sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(SX_ACCESS_CMD_DELETE,
                                                                             new_uvrid,
                                                                             &default_underlay_rif);
            if (rollback_err) {
                SX_LOG_ERR("Failed to delete loop back RIF for tunnel[0x%08x], err = %s\n", tunnel_id,
                           sx_status_str(rollback_err));
            }
        }

        if (vrid_to_default_rif_rollback) {
            rollback_err = sdk_tunnel_db_vrid_to_default_rif_mapping_delete(new_uvrid);
            if (rollback_err) {
                SX_LOG_ERR("Failed to remove mapping of VRID [%d] to default underlay RIF, err = %s\n",
                           new_uvrid, sx_status_str(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t __ulay_default_rif_tunnel_impl_post_edit_action(sx_tunnel_id_t                tunnel_id,
                                                            sx_tunnel_attribute_t       * old_tunnel_attr,
                                                            const sx_tunnel_attribute_t * new_tunnel_attr_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_router_id_t                   old_uvrid, new_uvrid;
    sx_router_interface_t            old_underlay_rif = 0;
    sx_router_interface_t            new_underlay_rif = 0;
    uint32_t                         interface_ref_cnt = 0;
    sx_tunnel_underlay_domain_type_e old_underlay_domain_type = 0;
    sx_router_counter_id_t           counter_id;
    sx_router_counter_attributes_t   cntr_attributes = {.type = SX_ROUTER_COUNTER_TYPE_BASIC};

    SX_LOG_ENTER();

    SX_MEM_CLR(old_uvrid);
    SX_MEM_CLR(new_uvrid);

    err = __ulay_default_rif_tunnel_impl_underlay_vrid_get(old_tunnel_attr, &old_uvrid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay VRID, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = __ulay_default_rif_tunnel_impl_underlay_vrid_get(new_tunnel_attr_p, &new_uvrid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay VRID, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    old_underlay_domain_type = tunnel_impl_get_underlay_domain_type(old_tunnel_attr);
    if (old_underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        err = sdk_tunnel_db_vrid_to_default_rif_mapping_get(old_uvrid, &old_underlay_rif);
        if ((err != SX_STATUS_SUCCESS)) {
            SX_LOG_ERR("Error edit tunnel[0x%08x] didn't find old underlay RIF, err = %s\n", tunnel_id,
                       sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_vrid_to_default_rif_mapping_get(new_uvrid, &new_underlay_rif);
        if ((err != SX_STATUS_SUCCESS)) {
            SX_LOG_ERR("Error edit tunnel[0x%08x] didn't find new underlay RIF, err = %s\n", tunnel_id,
                       sx_status_str(err));
            goto out;
        }

        if (old_underlay_rif != new_underlay_rif) {
            /* If default RIF reference counter is 0, destroy the RIF (call sdk_router_interface_set with command DELETE) */
            /* Remove default RIF from vrid_to_default_rif_mapping */
            err = sdk_rif_db_rif_ref_cnt_get(old_underlay_rif, &interface_ref_cnt);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to get RIF count of underlay RIF [%d] to default underlay RIF, err = %s\n",
                           old_underlay_rif, sx_status_str(err));
                goto out;
            }

            /* Delete only if the reference count is 0 */
            if (interface_ref_cnt == 0) {
                /* Get RIF counter */
                err = sdk_router_interface_counter_bind_get_counter(old_underlay_rif, &counter_id);
                if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
                    SX_LOG_ERR("Can't find counter to underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                               old_underlay_rif, tunnel_id, sx_status_str(err));
                    /* Not a critical issue */
                } else if (err == SX_STATUS_SUCCESS) {
                    /* Unbind and delete counter */
                    err = sdk_router_interface_counter_bind_set(SX_ACCESS_CMD_UNBIND, counter_id, old_underlay_rif);
                    if (err != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR(
                            "Failed to unbind counter [%#x] from underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                            counter_id,
                            old_underlay_rif,
                            tunnel_id,
                            sx_status_str(err));
                        goto out;
                    }

                    err = sdk_router_interface_counter_alloc_set(SX_ACCESS_CMD_DESTROY, &counter_id, cntr_attributes);
                    if (err != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed to delete underlay RIF counter [%#x] for tunnel[0x%08x], err = %s\n",
                                   counter_id, tunnel_id, sx_status_str(err));
                        goto out;
                    }
                }

                /* Default RIF is not used. Delete it */
                err = sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(SX_ACCESS_CMD_DELETE, old_uvrid,
                                                                        &old_underlay_rif);
                if (err) {
                    SX_LOG_ERR("Failed to delete loop back RIF for tunnel[0x%08x], err = %s\n", tunnel_id,
                               sx_status_str(err));
                    goto out;
                }

                err = sdk_tunnel_db_vrid_to_default_rif_mapping_delete(old_uvrid);
                if (err) {
                    SX_LOG_ERR("Failed to remove mapping of VRID [%d] to default underlay RIF, err = %s\n",
                               old_uvrid,
                               sx_status_str(err));
                    goto out;
                }
            }
        }
    }

out:

    SX_LOG_EXIT();
    return err;
}


sx_status_t __ulay_default_rif_tunnel_impl_edit_action_rollback(sx_tunnel_id_t                tunnel_id,
                                                                const sdk_db_tunnel_data_t  * tunnel_params_p,
                                                                sx_tunnel_attribute_t       * old_tunnel_attr,
                                                                const sx_tunnel_attribute_t * new_tunnel_attr_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_router_id_t                   old_uvrid, new_uvrid;
    sdk_ref_t                        underlay_rif_ref;
    sdk_ref_t                        underlay_rif_decap_ref;
    uint32_t                         interface_ref_cnt = 0;
    sx_router_interface_t            new_underlay_rif = 0;
    sx_router_interface_t            new_underlay_rif_decap = 0;
    sx_router_interface_t            old_underlay_rif = 0;
    sx_router_interface_t            old_underlay_rif_decap = 0;
    rif_tunnel_t                     rif_tunnel_data;
    ref_name_data_t                  ulay_rif_name_data = {.print_func_p = get_tunnel_underlay_rif_ref_name,
                                                           .ref_data_p = &rif_tunnel_data,
                                                           .data_size = sizeof(rif_tunnel_data)};
    sx_tunnel_underlay_domain_type_e old_underlay_domain_type;
    sx_router_counter_id_t           counter_id;
    sx_router_counter_attributes_t   cntr_attributes = {.type = SX_ROUTER_COUNTER_TYPE_BASIC};

    SX_LOG_ENTER();

    UNUSED_PARAM(tunnel_params_p);

    SX_MEM_CLR(old_uvrid);
    SX_MEM_CLR(new_uvrid);
    SX_MEM_CLR(old_underlay_rif);
    SX_MEM_CLR(rif_tunnel_data);
    SX_MEM_CLR(old_underlay_domain_type);


    err = tunnel_impl_get_underlay_rif(old_tunnel_attr, &old_underlay_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = tunnel_impl_get_underlay_rif(new_tunnel_attr_p, &new_underlay_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = __ulay_default_rif_tunnel_impl_underlay_vrid_get(old_tunnel_attr, &old_uvrid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay VRID, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = __ulay_default_rif_tunnel_impl_underlay_vrid_get(new_tunnel_attr_p, &new_uvrid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay VRID, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    old_underlay_domain_type = tunnel_impl_get_underlay_domain_type(old_tunnel_attr);

    if ((old_underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) ||
        SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
        if (new_underlay_rif != old_underlay_rif) {
            err = sdk_tunnel_db_ulay_rif_ref_get(tunnel_id, &underlay_rif_ref);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to get underlay RIF[%d] tunnel, err = %s\n", tunnel_id, sx_status_str(err));
                goto out;
            }

            /* Decrease new underlay RIF */
            err = sdk_rif_impl_ref_decrease(
                new_underlay_rif, &underlay_rif_ref);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to decrease underlay RIF[%d] reference, err = %s\n",
                           new_underlay_rif, sx_status_str(err));
                goto out;
            }

            if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
                err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_DELETE,
                                                     new_underlay_rif,
                                                     new_tunnel_attr_p);

                if (SX_STATUS_SUCCESS != err) {
                    SX_LOG_ERR("Failed to detach L2 flex tunnel from underlay_rif[%d] edit rollback, err = %s\n",
                               new_underlay_rif, sx_status_str(err));
                    goto out;
                }
            }
        }
    }

    /* If 0 take from the mapping, otherwise create a new one */
    if (old_underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        /* If ref.count is 0 delete the RIF */
        err = sdk_rif_db_rif_ref_cnt_get(new_underlay_rif, &interface_ref_cnt);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get RIF count of underlay RIF [%d] to default underlay RIF, err = %s\n",
                       new_underlay_rif, sx_status_str(err));
            goto out;
        }

        /* Delete only if reference count is 0 */
        if (interface_ref_cnt == 0) {
            /* Default RIF is not used. Delete it */

            /* Get RIF counter */
            err = sdk_router_interface_counter_bind_get_counter(new_underlay_rif, &counter_id);
            if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
                /* Not critical issue */
                SX_LOG_ERR("Can't find counter to underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                           new_underlay_rif, tunnel_id, sx_status_str(err));
            } else if (err == SX_STATUS_SUCCESS) {
                /* Unbind and delete counter */
                err = sdk_router_interface_counter_bind_set(SX_ACCESS_CMD_UNBIND, counter_id, new_underlay_rif);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to unbind counter [%#x] from underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                               counter_id, new_underlay_rif, tunnel_id, sx_status_str(err));
                    goto out;
                }

                err = sdk_router_interface_counter_alloc_set(SX_ACCESS_CMD_DESTROY, &counter_id, cntr_attributes);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to delete underlay RIF counter [%#x] for tunnel[0x%08x], err = %s\n",
                               counter_id, tunnel_id, sx_status_str(err));
                    goto out;
                }
            }

            err =
                sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(SX_ACCESS_CMD_DELETE, new_uvrid, &new_underlay_rif);
            if (err) {
                SX_LOG_ERR("Failed to delete loop back RIF for tunnel[0x%08x], err = %s\n", tunnel_id,
                           sx_status_str(err));
                goto out;
            }

            err = sdk_tunnel_db_vrid_to_default_rif_mapping_delete(new_uvrid);
            if (err) {
                SX_LOG_ERR("Failed to remove mapping of VRID [%d] to default underlay RIF, err = %s\n",
                           new_uvrid,
                           sx_status_str(err));
                goto out;
            }
        }
    } else if (old_underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) {
        if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id) && SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id)) {
            err = tunnel_impl_get_underlay_decap_rif(new_tunnel_attr_p, &new_underlay_rif_decap);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
                goto out;
            }

            /* Decrease new underlay RIF */
            err = sdk_rif_impl_ref_decrease(new_underlay_rif_decap, &underlay_rif_decap_ref);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to decrease underlay RIF[%d] reference, err = %s\n",
                           new_underlay_rif, sx_status_str(err));
                goto out;
            }

            /* Increase old underlay RIF */
            rif_tunnel_data.tunnel_id = tunnel_id;
            rif_tunnel_data.rif = old_underlay_rif_decap;
            ulay_rif_name_data.print_func_p = get_tunnel_underlay_rif_decap_ref_name;

            err = sdk_rif_impl_ref_increase(old_underlay_rif_decap, &ulay_rif_name_data, &underlay_rif_decap_ref);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to increase underlay RIF[%d] reference, err = %s\n",
                           old_underlay_rif_decap, sx_status_str(err));
                goto out;
            }
        }
    }

    /* Increase old underlay RIF */
    if (new_underlay_rif != old_underlay_rif) {
        rif_tunnel_data.tunnel_id = tunnel_id;
        rif_tunnel_data.rif = old_underlay_rif;
        ulay_rif_name_data.print_func_p = get_tunnel_underlay_rif_ref_name;

        err = sdk_rif_impl_ref_increase(old_underlay_rif, &ulay_rif_name_data, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to increase underlay RIF[%d] reference, err = %s\n",
                       old_underlay_rif, sx_status_str(err));
            goto out;
        }

        if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
            err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_ADD,
                                                 old_underlay_rif,
                                                 old_tunnel_attr);

            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to attach L2 flex tunnel from underlay_rif[%d] edit rollback, err = %s\n",
                           old_underlay_rif, sx_status_str(err));
                goto out;
            }
        }

        err = sdk_tunnel_db_ulay_rif_ref_set(tunnel_id, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to assign underlay RIF[%d] to tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __ulay_default_rif_tunnel_impl_check_learn_mode(sx_port_log_id_t log_port, sx_fdb_learn_mode_t learn_mode)
{
    sx_tunnel_id_t tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_status_t    sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = sdk_tunnel_db_tunnel_id_by_log_port_get(log_port, &tunnel_id);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_DBG("Tunnel is not bound to log_port: 0x%x\n", log_port);
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    }

    if (((SX_TUNNEL_TYPE_ID_GET(tunnel_id) == SX_TUNNEL_TYPE_L2_FLEX) ||
         (SX_TUNNEL_TYPE_ID_GET(tunnel_id) == SX_TUNNEL_TYPE_L2_FLEX_IPV6) ||
         (SX_TUNNEL_TYPE_NVE_VXLAN_IPV6 == SX_TUNNEL_TYPE_ID_GET(tunnel_id)) ||
         (SX_TUNNEL_TYPE_NVE_NVGRE_IPV6 == SX_TUNNEL_TYPE_ID_GET(tunnel_id))) &&
        (SX_FDB_LEARN_MODE_DONT_LEARN != learn_mode)) {
        SX_LOG_ERR("Unsupported learn mode (%s) for Flex and IPv6 tunnel\n",
                   sx_fdb_learn_mode_str(learn_mode));
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t __ulay_default_rif_tunnel_impl_delete_action(sx_tunnel_id_t               tunnel_id,
                                                         const sdk_db_tunnel_data_t * tunnel_params_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_status_t                      rollback_err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t            tunnel_attr;
    sdk_ref_t                        ref;
    sx_router_interface_t            underlay_rif = 0;
    sx_router_interface_t            underlay_rif_decap = 0;
    sx_router_id_t                   underlay_vrid = 0;
    boolean_t                        underlay_rif_ref_increase_rollback = FALSE;
    boolean_t                        default_rif_delete_rollback = FALSE;
    boolean_t                        db_delete_rif_from_vrid_rollback = FALSE;
    rif_tunnel_t                     rif_tunnel_data;
    ref_name_data_t                  ulay_rif_name_data = {.print_func_p = get_tunnel_underlay_rif_ref_name,
                                                           .ref_data_p = &rif_tunnel_data,
                                                           .data_size = sizeof(rif_tunnel_data)};
    sx_router_interface_t            default_underlay_rif = 0;
    sdk_ref_t                        underlay_rif_ref;
    sdk_ref_t                        underlay_rif_decap_ref;
    uint32_t                         interface_ref_cnt = 0;
    sx_tunnel_underlay_domain_type_e underlay_domain_type = 0;
    sx_router_counter_id_t           counter_id;
    sx_router_counter_attributes_t   cntr_attributes = {.type = SX_ROUTER_COUNTER_TYPE_BASIC};

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_attr);
    SX_MEM_CLR(ref);
    SX_MEM_CLR(underlay_rif);
    SX_MEM_CLR(default_underlay_rif);
    SX_MEM_CLR(underlay_vrid);
    SX_MEM_CLR(underlay_rif_ref);

    SX_MEM_CPY(tunnel_attr, tunnel_params_p->tun_attr);

    /*
     *  1. Get default RIF from vrid_to_default_rif mapping , if default RIF does not exist return error.
     *  2. Set HW (Delete tunnel), call sdk_tunnel_db_delete.
     *  3. Decrease default RIF reference counter
     *  4. If default RIF reference counter is 0, destroy the RIF (call sdk_router_interface_set with command DELETE).
     *  5. Remove default RIF from vrid_to_default_rif_mapping
     *
     */

    /* 1. Get default RIF from vrid_to_default_rif mapping, if default RIF does not exist return error */
    err = tunnel_impl_get_underlay_rif(&tunnel_attr, &underlay_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    underlay_domain_type = tunnel_impl_get_underlay_domain_type(&tunnel_attr);
    if (underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        err = __ulay_default_rif_tunnel_impl_underlay_vrid_get(&tunnel_attr, &underlay_vrid);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] underlay VRID, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_vrid_to_default_rif_mapping_get(underlay_vrid,
                                                            &default_underlay_rif);
        if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] default underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        /* Update underlay_rif value */
        underlay_rif = default_underlay_rif;
    }

    /* 3.  Decrease default RIF reference counter */
    if ((underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) || SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
        err = sdk_tunnel_db_ulay_rif_ref_get(tunnel_id, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get underlay RIF[%d] tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        rif_tunnel_data.tunnel_id = tunnel_id;
        rif_tunnel_data.rif = underlay_rif;
        err = sdk_rif_impl_ref_decrease(
            underlay_rif, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to decrease underlay RIF[%d] reference, err = %s\n",
                       underlay_rif, sx_status_str(err));
            goto out;
        }
        underlay_rif_ref_increase_rollback = TRUE;

        if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
            err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_DELETE,
                                                 underlay_rif,
                                                 &tunnel_params_p->tun_attr);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to detach L2 tunnel RIF[%d] for delete tunnel, err = %s\n",
                           underlay_rif, sx_status_str(err));
                goto out;
            }
            /* Unbind from the flex tunnel header */
            err = sdk_tunnel_impl_flex_header_unbind(tunnel_attr.attributes.l2_flex.encap.tunnel_flex_header_id,
                                                     tunnel_id);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to unbind to flex tunnel header [%u] tunnel id [%u] for tunnel delete, err = %s\n",
                           tunnel_attr.attributes.l2_flex.encap.tunnel_flex_header_id,
                           tunnel_id,
                           sx_status_str(err));
                goto out;
            }
        }
    }

    /* If default RIF reference counter is 0, destroy the RIF (call sdk_router_interface_set with command DELETE) */
    /* Remove default RIF from vrid_to_default_rif_mapping */
    if (underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        err = sdk_rif_db_rif_ref_cnt_get(underlay_rif, &interface_ref_cnt);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get RIF count of underlay RIF [%d] to default underlay RIF, err = %s\n",
                       underlay_rif,
                       sx_status_str(err));
            goto out;
        }

        /* Delete only if reference count is 0 */
        if (interface_ref_cnt == 0) {
            /* Default RIF is not used delete it */
            /* Get RIF counter */
            err = sdk_router_interface_counter_bind_get_counter(underlay_rif, &counter_id);
            if ((SX_STATUS_SUCCESS != err) && (SX_STATUS_ENTRY_NOT_FOUND != err)) {
                SX_LOG_ERR("Can't find counter to underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                           underlay_rif, tunnel_id, sx_status_str(err));
                /* Not a critical issue */
            } else if (SX_STATUS_SUCCESS == err) {
                /* Unbind and delete counter */
                err = sdk_router_interface_counter_bind_set(SX_ACCESS_CMD_UNBIND, counter_id, underlay_rif);
                if (SX_STATUS_SUCCESS != err) {
                    SX_LOG_ERR("Failed to unbind counter [%#x] from underlay RIF [%#x] for tunnel[0x%08x], err = %s\n",
                               counter_id, underlay_rif, tunnel_id, sx_status_str(err));
                    goto out;
                }

                err = sdk_router_interface_counter_alloc_set(SX_ACCESS_CMD_DESTROY, &counter_id, cntr_attributes);
                if (SX_STATUS_SUCCESS != err) {
                    SX_LOG_ERR("Failed to delete underlay RIF counter [%#x] for tunnel[0x%08x], err = %s\n",
                               counter_id, tunnel_id, sx_status_str(err));
                    goto out;
                }
            }

            err =
                sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(SX_ACCESS_CMD_DELETE, underlay_vrid, &underlay_rif);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to delete loopback RIF for tunnel[0x%08x], err = %s\n", tunnel_id,
                           sx_status_str(err));
                goto out;
            }

            default_rif_delete_rollback = TRUE;

            err = sdk_tunnel_db_vrid_to_default_rif_mapping_delete(underlay_vrid);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to remove mapping of VRID [%d] to default underlay RIF, err = %s\n",
                           underlay_vrid,
                           sx_status_str(err));
                goto out;
            }

            db_delete_rif_from_vrid_rollback = TRUE;

            /* Remove dummy underlay VRID */
            err = __ulay_default_rif_tunnel_impl_underlay_vrid_cleanup(underlay_vrid);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to delete dummy VRID, err = %s\n", sx_status_str(err));
                goto out;
            }
        }
    } else if (underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) {
        if ((SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id))
            && SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id)) {
            /* Decrease decap underlay RIF */
            err = tunnel_impl_get_underlay_decap_rif(&tunnel_attr, &underlay_rif_decap);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Can't get tunnel[0x%08x] decap underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
                goto out;
            }

            err = sdk_tunnel_db_ulay_rif_decap_ref_get(tunnel_id, &underlay_rif_decap_ref);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to get decap underlay RIF[%d] tunnel, err = %s\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }

            rif_tunnel_data.tunnel_id = tunnel_id;
            rif_tunnel_data.rif = underlay_rif_decap;

            err = sdk_rif_impl_ref_decrease(underlay_rif_decap, &underlay_rif_decap_ref);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to decrease decap underlay RIF[%d] reference, err = %s\n",
                           underlay_rif, sx_status_str(err));
                goto out;
            }
        }
    }


out:
    if (SX_STATUS_SUCCESS != err) {
        if (db_delete_rif_from_vrid_rollback) {
            rollback_err = sdk_tunnel_db_vrid_to_default_rif_mapping_add(underlay_vrid, underlay_rif);
            if (rollback_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in create loopback RIF for tunnel[0x%08x], err = %s\n", tunnel_id,
                           sx_status_str(rollback_err));
            }
        }

        if (default_rif_delete_rollback) {
            rollback_err = sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(SX_ACCESS_CMD_ADD,
                                                                             underlay_vrid,
                                                                             &default_underlay_rif);
            if (rollback_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in create loopback RIF for tunnel[0x%08x], err = %s\n", tunnel_id,
                           sx_status_str(rollback_err));
            }
        }

        if (underlay_rif_ref_increase_rollback) {
            rollback_err = sdk_rif_impl_ref_increase(underlay_rif, &ulay_rif_name_data, &underlay_rif_ref);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to decrease underlay RIF[%d] reference, err = %s\n",
                           underlay_rif, sx_status_str(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}


sx_status_t __ulay_default_rif_tunnel_impl_delete_action_rollback(sx_tunnel_id_t               tunnel_id,
                                                                  const sdk_db_tunnel_data_t * tunnel_params_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t            tunnel_attr;
    sdk_ref_t                        ref;
    sx_router_interface_t            underlay_rif = 0;
    sx_router_interface_t            underlay_rif_decap = 0;
    sx_router_id_t                   underlay_vrid = 0;
    sx_router_interface_t            default_underlay_rif = 0;
    rif_tunnel_t                     rif_tunnel_data;
    ref_name_data_t                  ulay_rif_name_data = {.print_func_p = get_tunnel_underlay_rif_ref_name,
                                                           .ref_data_p = &rif_tunnel_data,
                                                           .data_size = sizeof(rif_tunnel_data)};
    sdk_ref_t                        underlay_rif_ref = 0;
    sdk_ref_t                        underlay_rif_decap_ref = 0;
    sx_tunnel_underlay_domain_type_e underlay_domain_type;

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_attr);
    SX_MEM_CLR(ref);
    SX_MEM_CLR(underlay_rif);
    SX_MEM_CLR(underlay_vrid);
    SX_MEM_CLR(underlay_domain_type);

    SX_MEM_CPY(tunnel_attr, tunnel_params_p->tun_attr);

    err = tunnel_impl_get_underlay_rif(&tunnel_attr, &underlay_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    underlay_domain_type = tunnel_impl_get_underlay_domain_type(&tunnel_attr);
    if (underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        /* Default RIF for VRID should be created */
        /* Check VRID-default-RIF exist */
        err = __ulay_default_rif_tunnel_impl_underlay_vrid_get(&tunnel_attr, &underlay_vrid);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] underlay VRID, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_vrid_to_default_rif_mapping_get(underlay_vrid, &default_underlay_rif);
        if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] default underlay RIF, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            /* Default RIF does not exist */
            /* Create the loopback RIF. This behavior is keep backward compatible behavior with Spectrum */
            err = sdk_ulay_default_rif_tunnel_impl_set_loopback_rif(SX_ACCESS_CMD_ADD,
                                                                    underlay_vrid,
                                                                    &default_underlay_rif);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in create loopback RIF for tunnel[0x%08x], err = %s\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }

            /* Add to Map */
            err = sdk_tunnel_db_vrid_to_default_rif_mapping_add(underlay_vrid, default_underlay_rif);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't add mapping tunnel[0x%08x] default underlay RIF, err = %s\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }
        }

        /* Update underlay_rif value */
        underlay_rif = default_underlay_rif;
    }

    if ((underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) || SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
        rif_tunnel_data.tunnel_id = tunnel_id;
        rif_tunnel_data.rif = underlay_rif;

        err = sdk_rif_impl_ref_increase(underlay_rif, &ulay_rif_name_data, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to increase underlay RIF[%d] reference, err = %s\n",
                       underlay_rif, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_ulay_rif_ref_set(tunnel_id, &underlay_rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to assign underlay RIF[%d] to tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
            err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_ADD,
                                                 underlay_rif,
                                                 &tunnel_attr);

            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to attach L2 flex tunnel from underlay_rif[%d] delete rollback, err = %s\n",
                           underlay_rif, sx_status_str(err));
                goto out;
            }
        }
    }

    if ((underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) &&
        SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id) && SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id)) {
        err = tunnel_impl_get_underlay_decap_rif(&tunnel_attr, &underlay_rif_decap);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        rif_tunnel_data.tunnel_id = tunnel_id;
        rif_tunnel_data.rif = underlay_rif_decap;
        ulay_rif_name_data.print_func_p = get_tunnel_underlay_rif_decap_ref_name;

        err = sdk_rif_impl_ref_increase(underlay_rif_decap, &ulay_rif_name_data, &underlay_rif_decap_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to increase decap underlay RIF[%d] reference, err = %s\n",
                       underlay_rif_decap, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_ulay_rif_decap_ref_set(tunnel_id, &underlay_rif_decap_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to assign decap underlay RIF[%d] to tunnel, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ulay_default_rif_tunnel_impl_dummy_vrid_init(void)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_router_general_param_t *general_param_p = NULL;
    sx_router_attributes_t     router_attr = {0};

    SX_LOG_ENTER();

    rc = sdk_router_impl_params_get(NULL, &general_param_p, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get params from router (rc = %s)\n", sx_status_str(rc));
        goto out;
    }

    router_attr.ipv4_enable = general_param_p->ipv4_enable;
    router_attr.ipv6_enable = general_param_p->ipv6_enable;
    router_attr.ipv4_mc_enable = general_param_p->ipv4_mc_enable;
    router_attr.ipv6_mc_enable = general_param_p->ipv6_mc_enable;
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP;
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP;
    router_attr.uc_default_rule_counter = 0;

    rc = sdk_router_vrid_impl_add(&__tunnel_dummy_vrid, &router_attr);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create VRID for general RIF (rc = %s)\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __ulay_default_rif_tunnel_impl_underlay_vrid_get(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                                    sx_router_id_t              * vrid_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_ENCAP) {
        *vrid_p = tunnel_impl_get_underlay_vrid(tunnel_attr_p);
    } else {
        /* Check whether dummy VRID already exists */
        if (__tunnel_dummy_vrid == SX_TUNNEL_UNDERLAY_VRID_INVALID) {
            rc = __sdk_ulay_default_rif_tunnel_impl_dummy_vrid_init();
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get dummy underlay VRID, (rc = %s)\n", sx_status_str(rc));
                goto out;
            }
        }

        *vrid_p = __tunnel_dummy_vrid;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __ulay_default_rif_tunnel_impl_underlay_vrid_cleanup(const sx_router_id_t vrid)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Check whether we are going to delete dummy VRID */
    if ((vrid != SX_TUNNEL_UNDERLAY_VRID_INVALID) && (vrid == __tunnel_dummy_vrid)) {
        rc = sdk_router_vrid_impl_delete(vrid);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to delete VRID (rc = %s)\n", sx_status_str(rc));
            goto out;
        }

        /* Dummy VRID was removed - reset its value */
        __tunnel_dummy_vrid = SX_TUNNEL_UNDERLAY_VRID_INVALID;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __ulay_default_rif_tunnel_impl_counter_get(const sx_tunnel_id_t         tunnel_id,
                                                              const sdk_db_tunnel_data_t * tunnel_params_p,
                                                              boolean_t                    is_clear,
                                                              sx_tunnel_counter_t        * counter_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_router_interface_t            underlay_rif = 0;
    sx_router_counter_id_t           rif_counter_id;
    sx_access_cmd_t                  cmd;
    sx_router_counter_set_extended_t rif_cntr_data;
    uint64_t                         encapsulated_pkts = 0;
    uint64_t                         decapsulated_pkts = 0;
    uint64_t                         decapsulated_errors = 0;
    uint64_t                         decapsulated_discards = 0;
    sx_tunnel_underlay_domain_type_e underlay_domain_type = SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID;

    SX_LOG_ENTER();

    /* RIF counters are returned only in the VRID mode,
     *   In the RIF mode, the RIFs and RIF counters were allocated by the user and will be read
     *   by the user */
    underlay_domain_type = tunnel_impl_get_underlay_domain_type(&tunnel_params_p->tun_attr);
    if (underlay_domain_type != SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    if (tunnel_params_p->tun_attr.direction != SX_TUNNEL_DIRECTION_DECAP) {
        err = tunnel_impl_get_underlay_rif(&tunnel_params_p->tun_attr, &underlay_rif);
    } else {
        err = tunnel_impl_get_underlay_decap_rif(&tunnel_params_p->tun_attr, &underlay_rif);
    }
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    /* Get encap RIF counters */
    err = sdk_router_interface_counter_bind_get_counter(underlay_rif, &rif_counter_id);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get RIF counter Id for underlay rif:%#x Tunnel:%#x, err = %s\n",
                   underlay_rif,
                   tunnel_id,
                   sx_status_str(err));
        goto out;
    }

    cmd = is_clear ? SX_ACCESS_CMD_READ_CLEAR : SX_ACCESS_CMD_READ;
    rif_cntr_data.type = SX_ROUTER_COUNTER_TYPE_BASIC;
    SX_MEM_CLR(rif_cntr_data);

    err = sdk_router_interface_counter_get(cmd, rif_counter_id, &rif_cntr_data);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("sdk_router_interface_counter_get failed. underlay rif:%#x tunnel:%#x counter:%#x, err = %s\n",
                   underlay_rif, tunnel_id, rif_counter_id, sx_status_str(err));
        goto out;
    }

    encapsulated_pkts = rif_cntr_data.data.rif_basic.router_ingress_good_unicast_packets +
                        rif_cntr_data.data.rif_basic.router_ingress_good_multicast_packets +
                        rif_cntr_data.data.rif_basic.router_ingress_good_broadcast_packets +
                        rif_cntr_data.data.rif_basic.router_ingress_discard_packets +
                        rif_cntr_data.data.rif_basic.router_ingress_error_packets;

    /* Get decap RIF counters,
     *  in the case of the VRID mode, the ingress RIF and the egress RIF are the same RIF */
    decapsulated_pkts = rif_cntr_data.data.rif_basic.router_egress_good_unicast_packets +
                        rif_cntr_data.data.rif_basic.router_egress_good_multicast_packets +
                        rif_cntr_data.data.rif_basic.router_egress_good_broadcast_packets +
                        rif_cntr_data.data.rif_basic.router_egress_discard_packets;
    decapsulated_errors = 0;
    decapsulated_discards = rif_cntr_data.data.rif_basic.router_egress_discard_packets;

    if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        counter_p->counter.l2_flex.encapsulated_pkts = encapsulated_pkts;
        counter_p->counter.l2_flex.decapsulated_pkts = decapsulated_pkts;
        counter_p->counter.l2_flex.decapsulated_errors = decapsulated_errors;
        counter_p->counter.l2_flex.decapsulated_discards += decapsulated_discards;
    } else {
        counter_p->counter.nve.encapsulated_pkts = encapsulated_pkts;
        counter_p->counter.nve.decapsulated_pkts = decapsulated_pkts;
        counter_p->counter.nve.decapsulated_errors = decapsulated_errors;
        counter_p->counter.nve.decapsulated_discards += decapsulated_discards;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ulay_default_rif_tunnel_impl_init_hwd(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_tunnel_impl_register_hwd_ops(&ulay_default_rif_hwd_tunnel_ops);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init tunnel, err = %s\n", sx_status_str(err));
        goto out;
    }

out:

    SX_LOG_EXIT();
    return err;
}

static boolean_t __ulay_tunnel_impl_l3_gw_supported(sx_tunnel_id_t tunnel_id)
{
    boolean_t supported = TRUE;

    UNUSED_PARAM(tunnel_id);

    SX_LOG_ENTER();

    SX_LOG_EXIT();
    return supported;
}

sx_status_t sdk_ulay_default_rif_tunnel_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return status;
}
