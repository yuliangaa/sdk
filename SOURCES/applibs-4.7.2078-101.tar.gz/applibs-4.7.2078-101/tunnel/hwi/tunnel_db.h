/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __HWI_TUNNEL_DB_H__
#define __HWI_TUNNEL_DB_H__

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_tunnel.h>
#include <kvd/kvd_linear_manager.h>
#include "sx/utils/sdk_refcount.h"
#include <complib/cl_fleximap.h>
#include "sx/utils/bit_vector.h"


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/
#define SX_TUNNEL_MAKE_ID(IDENTIFIER, TYPE, DIR) \
    ((IDENTIFIER) |                              \
     ((TYPE) << SX_TUNNEL_TYPE_ID_OFFSET) |      \
     ((DIR) << SX_TUNNEL_DIRECTION_OFFSET))

/************************************************
 *  Defines
 ***********************************************/
#define TUNNEL_NAME_MAX_LEN 14

/************************************************
 *  Type definitions
 ***********************************************/
static __attribute__((__used__)) const char* sx_tunnel_direction_short_str[] = {
    "NONE",
    "ENCAP",
    "DECAP",
    "SYMMETRIC"
};

#define SX_TUNNEL_DIRECTION_SHORT_STR_LEN (sizeof(sx_tunnel_direction_short_str) / sizeof(char*))

#define SX_TUNNEL_DIRECTION_SHORT_STR(index)                      \
    (SX_CHECK_MAX(index, SX_TUNNEL_DIRECTION_SHORT_STR_LEN - 1) ? \
     sx_tunnel_direction_short_str[index] : "UNKNOWN")

typedef kvd_linear_manager_handle_t hwi_tunnel_hw_decap_handle_t;
typedef uint32_t hwi_tunnel_hw_encap_handle_t;

typedef kvd_linear_manager_index_t hwd_tunnel_decap_index_t;
typedef uint32_t hwd_tunnel_encap_index_t;

#define SDK_TUNNEL_INVALID_DECAP_HWD_HDL ((hwi_tunnel_hw_decap_handle_t)0xffffffff)
#define SDK_TUNNEL_INVALID_ENCAP_HWD_HDL ((hwi_tunnel_hw_encap_handle_t)0xffffffff)

typedef struct tunnel_id_item {
    cl_list_item_t list_item;
    uint32_t       tunnel_id;
} tunnel_id_item_t;

typedef struct tunnel_mapping_item {
    cl_pool_item_t        pool_item;
    cl_fmap_item_t        fid_map_item;
    cl_fmap_item_t        vni_map_item;
    sdk_refcount_t        ref_count;
    sx_tunnel_map_entry_t map_entry;
    sdk_ref_t             tunnel_ref;
    sx_flow_counter_id_t  decap_flow_counter_id; /*counter per fid for decap direction*/
    cl_list_item_t        decap_flow_counter_list_item;
    sx_flow_counter_id_t  encap_uc_flow_counter_id; /*counter per fid for encap uc direction*/
    cl_list_item_t        encap_uc_flow_counter_list_item;
    sx_flow_counter_id_t  encap_mc_flow_counter_id; /*counter per fid for encap mc direction*/
    cl_list_item_t        encap_mc_flow_counter_list_item;
    boolean_t             pending_delete;
} tunnel_mapping_item_t;

typedef struct tunnel_mapping_counters_list_map_key {
    sx_bridge_tunnel_counter_type_t type;
    sx_flow_counter_id_t            flow_counter_id;
} tunnel_mapping_counters_list_map_key_t;

typedef struct tunnel_mapping_counters_list {
    cl_pool_item_t                         list_pool_item;
    cl_fmap_item_t                         list_map_item;
    tunnel_mapping_counters_list_map_key_t list_map_key;
    cl_qlist_t                             counters_list;  /* list of tunnel_mapping_item_t */
} tunnel_mapping_counters_list_t;

/**
 * Tunnel vrid mapping entry
 */
typedef struct tunnel_vrid_to_default_rif_map_item {
    cl_pool_item_t        pool_item;
    cl_map_item_t         map_item;
    sx_router_interface_t rif;
    sx_router_id_t        vrid;
} tunnel_vrid_to_default_rif_map_item_t;

typedef struct sdk_db_tunnel {
    sdk_refcount_t               ref_count;
    uint32_t                     entry_count;
    sdk_ref_t                    rif_ref;
    sdk_ref_t                    underlay_rif_ref;
    sdk_ref_t                    underlay_rif_decap_ref;
    sdk_ref_t                    vrid_ref;
    sx_tunnel_attribute_t        tun_attr;
    hwi_tunnel_hw_decap_handle_t hwd_decap_handle;
    hwi_tunnel_hw_encap_handle_t hwd_encap_handle;
    uint32_t                     tunnel_identifier;
    cl_fmap_t                    tunnel_fid_map;
    cl_fmap_t                    tunnel_vni_map;
    bit_vector_t                 vni_to_fid_vector;
    boolean_t                    pending_delete;
} sdk_db_tunnel_data_t;

typedef struct sdk_db_tunnel_entry {
    cl_pool_item_t       pool_item;
    cl_map_item_t        map_item;
    cl_map_item_t        log_port_map_item;
    sdk_db_tunnel_data_t data;
} sdk_db_tunnel_entry_t;

typedef struct tunnel_flex_header_entry {
    boolean_t                   allocated;
    sx_tunnel_flex_header_id_t  header_id;
    sx_tunnel_flex_header_cfg_t header_cfg;
    sx_router_interface_t       uirif;
    sdk_ref_t                   emt_ref;
    boolean_t                   used_by_tunnel;
    sx_tunnel_id_t              tunnel_id;
} tunnel_flex_header_entry_t;

typedef sx_utils_status_t (*nve_tunnel_delete_func_p)(uint64_t id);
typedef sx_utils_status_t (*nve_tunnel_mapping_delete_func_p)(uint64_t id);

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t sdk_tunnel_check_init(void);
sx_status_t sdk_tunnel_check_terminated(void);
sx_status_t sdk_tunnel_impl_params_get(boolean_t *is_tunnel_init_done_p);

const char* get_tunnel_ref_name(char* name_buf, size_t name_size, void* tunnel_id);

sx_status_t sdk_tunnel_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t sdk_tunnel_db_init(uint32_t                         ipinip_tunnel_max_count,
                               uint32_t                         nve_tunnel_max_count,
                               uint32_t                         l2_flex_tunnel_max_count,
                               nve_tunnel_delete_func_p         nve_tunnel_delete_func_cb,
                               nve_tunnel_mapping_delete_func_p nve_tunnel_mapping_delete_func_cb);
sx_status_t sdk_tunnel_db_deinit(boolean_t is_forced);

sx_status_t sdk_tunnel_db_add(const sx_tunnel_attribute_t *tunnel_attr_p,
                              const sdk_ref_t             *vrid_ref_p,
                              sx_tunnel_id_t              *tunnel_id_p);

sx_status_t sdk_tunnel_db_delete(sx_tunnel_id_t tunnel_id);
sx_status_t sdk_tunnel_db_edit(sx_tunnel_id_t                tunnel_id,
                               const sx_tunnel_attribute_t * new_tunnel_attr_p);

sx_status_t sdk_tunnel_db_get(sx_tunnel_id_t               tunnel_id,
                              const sdk_db_tunnel_data_t **tunnel_params_p,
                              boolean_t                    ignore_pending_delete);

sx_status_t sdk_tunnel_db_total_tunnel_get(uint32_t * total_ipinip_count,
                                           uint32_t * total_nve_count,
                                           uint32_t * total_l2_flex_count);

sx_status_t sdk_tunnel_db_ref_increase(sx_tunnel_id_t    tunnel_id,
                                       ref_name_data_t * ref_name_data,
                                       sdk_ref_t       * ref);

sx_status_t sdk_tunnel_db_ref_decrease(sx_tunnel_id_t tunnel_id, const sdk_ref_t* ref);

sx_status_t sdk_tunnel_db_hw_handle_set(sx_tunnel_id_t               tunnel_id,
                                        hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                        hwi_tunnel_hw_decap_handle_t tunnel_decap_handle);

sx_status_t sdk_tunnel_db_hw_decap_handle_get(sx_tunnel_id_t                tunnel_id,
                                              hwi_tunnel_hw_decap_handle_t *tunnel_decap_handle_p);

sx_status_t sdk_tunnel_db_hw_encap_handle_get(sx_tunnel_id_t                tunnel_id,
                                              hwi_tunnel_hw_encap_handle_t *tunnel_encap_handle_p);

sx_status_t sdk_tunnel_db_ref_count_get(sx_tunnel_id_t tunnel_id, uint32_t *refcount_p,
                                        uint32_t buf_size, char* references_name);

sx_status_t sdk_tunnel_db_pending_delete_set(sx_tunnel_id_t tunnel_id, boolean_t pending_delete);
sx_status_t sdk_tunnel_db_pending_delete_get(sx_tunnel_id_t tunnel_id, boolean_t *pending_delete_p);

sx_status_t sdk_tunnel_db_vrid_ref_set(sx_tunnel_id_t tunnel_id, const sdk_ref_t *vrid_ref_p);

sx_status_t sdk_tunnel_db_vrid_ref_get(sx_tunnel_id_t tunnel_id, sdk_ref_t *vrid_ref_p);

sx_status_t sdk_tunnel_db_rif_ref_set(const sx_tunnel_id_t tunnel_id,
                                      const sdk_ref_t     *rif_ref_p);
sx_status_t sdk_tunnel_db_rif_ref_get(const sx_tunnel_id_t tunnel_id,
                                      sdk_ref_t           *rif_ref_p);
sx_status_t sdk_tunnel_db_ulay_rif_ref_set(const sx_tunnel_id_t tunnel_id,
                                           const sdk_ref_t     *rif_ref_p);
sx_status_t sdk_tunnel_db_ulay_rif_ref_get(const sx_tunnel_id_t tunnel_id,
                                           sdk_ref_t           *rif_ref_p);

sx_status_t sdk_tunnel_db_ulay_rif_decap_ref_set(const sx_tunnel_id_t tunnel_id, const sdk_ref_t *rif_ref_p);
sx_status_t sdk_tunnel_db_ulay_rif_decap_ref_get(const sx_tunnel_id_t tunnel_id, sdk_ref_t *rif_ref_p);
sx_status_t sdk_tunnel_db_tunnel_id_by_hw_decap_get(hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                                    sx_tunnel_id_t              *tunnel_id);

sx_status_t sdk_tunnel_db_tunnel_id_by_hw_encap_get(hwi_tunnel_hw_encap_handle_t tunnel_decap_handle,
                                                    sx_tunnel_id_t              *tunnel_id);

sx_status_t sdk_tunnel_db_tunnel_mapping_pending_delete_set(sx_tunnel_id_t               tunnel_id,
                                                            const sx_tunnel_map_entry_t *map_entry_p,
                                                            boolean_t                    pending_delete);
sx_status_t sdk_tunnel_db_tunnel_mapping_pending_delete_get(sx_tunnel_id_t               tunnel_id,
                                                            const sx_tunnel_map_entry_t *map_entry_p,
                                                            boolean_t                   *pending_delete_p);

sx_status_t sdk_tunnel_db_tunnel_mapping_add(const sx_tunnel_id_t         tunnel_id,
                                             const sx_tunnel_map_entry_t *map_entry_p,
                                             const uint32_t               map_entry_cnt);

sx_status_t sdk_tunnel_db_tunnel_mapping_delete(const sx_tunnel_id_t         tunnel_id,
                                                const sx_tunnel_map_entry_t *map_entry_p,
                                                const uint32_t               map_entry_cnt);

sx_status_t sdk_tunnel_db_tunnel_mapping_delete_all(const sx_tunnel_id_t tunnel_id,
                                                    boolean_t            is_forced);

sx_status_t sdk_tunnel_db_tunnel_mapping_check_if_can_deleted(const sx_tunnel_id_t         tunnel_id,
                                                              const sx_tunnel_map_entry_t *map_entry_p,
                                                              const uint32_t               map_entry_cnt);

sx_status_t sdk_tunnel_db_tunnel_mapping_get_first(const sx_tunnel_id_t   tunnel_id,
                                                   sx_tunnel_map_entry_t *map_entry_p,
                                                   uint32_t              *map_entry_cnt);

sx_status_t sdk_tunnel_db_tunnel_mapping_get_next(const sx_tunnel_id_t   tunnel_id,
                                                  sx_tunnel_map_entry_t  map_entry_key,
                                                  sx_tunnel_map_entry_t *map_entry_p,
                                                  uint32_t              *map_entry_cnt);

/* SET/DELETE tunnel fid counter to mapping DB */
sx_status_t sdk_tunnel_db_fid_counter_set(sx_tunnel_id_t                  tunnel_id,
                                          sx_fid_t                        fid,
                                          sx_bridge_tunnel_counter_type_t counter_type,
                                          sx_flow_counter_id_t            counter_id);

/* Get tunnel fid counter from mapping DB */
sx_status_t sdk_tunnel_db_fid_counter_get(sx_tunnel_id_t                  tunnel_id,
                                          sx_fid_t                        fid,
                                          sx_bridge_tunnel_counter_type_t counter_type,
                                          sx_flow_counter_id_t           *counter_id_p);

/*if map_entry_p = NULL the function will return only the count number*/
sx_status_t sdk_tunnel_db_map_entries_list_get(const sx_tunnel_id_t   tunnel_id,
                                               sx_tunnel_map_entry_t *map_entry_p,
                                               uint32_t              *map_entry_cnt,
                                               boolean_t              ignore_pending_delete);

sx_status_t sdk_tunnel_db_mapping_unbind_flow_counters(sx_tunnel_id_t tunnel_id,
                                                       sx_fid_t       fid);

sx_status_t sdk_tunnel_db_mapping_get_by_fid(sx_tunnel_id_t         tunnel_id,
                                             sx_fid_t               fid,
                                             sx_tunnel_map_entry_t *map_entry);
sx_status_t sdk_tunnel_db_mapping_get_by_vni(sx_tunnel_id_t         tunnel_id,
                                             sx_tunnel_vni_t        vni,
                                             sx_tunnel_map_entry_t *map_entry);
sx_status_t sdk_tunnel_db_mapping_ref_cnt_decrease(const sx_tunnel_id_t tunnel_id, const sx_fid_t fid,
                                                   const sdk_ref_t *ref_p);

sx_status_t sdk_tunnel_db_mapping_ref_cnt_increase(const sx_tunnel_id_t tunnel_id, const sx_fid_t fid,
                                                   ref_name_data_t*ref_name_data, sdk_ref_t *ref_p);

sx_status_t sdk_tunnel_db_mapping_ref_cnt_get(const sx_tunnel_id_t tunnel_id,
                                              const sx_fid_t       fid,
                                              uint32_t            *refcount_p);

sx_status_t hwi_db_decap_table_init(void);
sx_status_t hwi_db_decap_table_deinit(boolean_t is_forced);

sx_status_t sdk_tunnel_db_tunnel_id_by_log_port_get(sx_port_log_id_t log_port, sx_tunnel_id_t *tunnel_id_p);

sx_status_t sdk_tunnel_db_iter_get(const sx_access_cmd_t     cmd,
                                   const sx_tunnel_id_t      tunnel_id,
                                   const sx_tunnel_filter_t *filter_p,
                                   sx_tunnel_id_t           *tunnel_id_list_p,
                                   uint32_t                 *tunnel_id_cnt_p);

void sdk_tunnel_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p);


sx_status_t sdk_tunnel_db_vrid_to_default_rif_mapping_add(sx_router_id_t        vrid,
                                                          sx_router_interface_t rif);

sx_status_t sdk_tunnel_db_vrid_to_default_rif_mapping_delete(sx_router_id_t vrid);

sx_status_t sdk_tunnel_db_vrid_to_default_rif_mapping_get(sx_router_id_t         vrid,
                                                          sx_router_interface_t *rif_p);

sx_status_t tunnel_mapping_counters_list_get(sx_bridge_tunnel_counter_type_t counter_type,
                                             sx_flow_counter_id_t            counter_id,
                                             const cl_qlist_t              **tunnel_mapping_counters_list);

/* Get the tunnel flex header information from the DB. */
sx_status_t sdk_tunnel_db_tunnel_flex_header_get(const sx_tunnel_flex_header_id_t tunnel_flex_header_id,
                                                 tunnel_flex_header_entry_t     **tunnel_flex_header_entry_pp);

/* Find an unused flex header  */
sx_status_t sdk_tunnel_db_find_free_tunnel_flex_header(tunnel_flex_header_entry_t **tunnel_flex_header_entry_pp);

sx_status_t sdk_tunnel_db_nve_tunnel_attr_get(sdk_db_tunnel_data_t const **tunnel_data_p);

#endif    /* __HWI_TUNNEL_DB_H__ */
