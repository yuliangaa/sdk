/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#undef  __MODULE__
#define __MODULE__ IPV6_MGR

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/sx_mem.h"
#include "utils/sx_adviser.h"
#include "ethl3/common/router_utils.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "hwd_ipv6_mgr_db.h"
#include <complib/cl_dbg.h>


/************************************************
 *  Local defines
 ***********************************************/

typedef enum dgb_rips_db {
    DBG_RIPS_IPV6_ADDR_E,
    DBG_RIPS_HANDLE_E,
    DBG_RIPS_INDEX_E,
    DBG_RIPS_INSTANCE_CNT_E,
    DBG_RIPS_LOCK_CNT_E
} dgb_rips_db_e;

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static hwd_ipv6_db_t g_ipv6_mgr_db;
static boolean_t     g_db_initialized = FALSE;

#define IPV6_MGR_HWD_DB_INIT_CHECK()                         \
    if (FALSE == g_db_initialized) {                         \
        err = SX_STATUS_DB_NOT_INITIALIZED;                  \
        SX_LOG_ERR("IPv6 mgr HWD DB is not initialized.\n"); \
        goto out;                                            \
    }

/************************************************
 *  Local function declarations
 ***********************************************/

static sx_status_t __hwd_rips_db_entry_get(const hwi_ipv6_hw_handle_t ipv6_block_handle,
                                           hwd_ipv6_entry_t         **rips_entry_p)
{
    cl_map_item_t *map_item_p = NULL;
    sx_status_t    err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("IPv6 MGR HWD: Get RIPS entry for handle [0x%" PRIx64 "] from DB.\n", ipv6_block_handle);

    map_item_p = cl_qmap_get(&g_ipv6_mgr_db.rips_handle_map, ipv6_block_handle);
    if (map_item_p == cl_qmap_end(&g_ipv6_mgr_db.rips_handle_map)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("Entry for RIPS handle 0x%" PRIx64 " does not exist.\n", ipv6_block_handle);
        goto out;
    }
    *rips_entry_p = PARENT_STRUCT(map_item_p, hwd_ipv6_entry_t, handle_map_item);

out:
    SX_LOG_EXIT();
    return err;
}

static void __hwd_rips_db_entry_remove(hwi_ipv6_hw_handle_t ipv6_block_handle)
{
    hwd_ipv6_entry_t *rips_entry_p = NULL;
    cl_map_item_t    *map_item_p = NULL;

    map_item_p = cl_qmap_remove(&g_ipv6_mgr_db.rips_handle_map, ipv6_block_handle);
    rips_entry_p = PARENT_STRUCT(map_item_p, hwd_ipv6_entry_t, handle_map_item);
    cl_fmap_remove(&g_ipv6_mgr_db.rips_ip_map, &rips_entry_p->ip_addr);
    cl_qpool_put(&g_ipv6_mgr_db.rips_pool, &(rips_entry_p->pool_item));
}

static int __key_compare_cb(const void *k1, const void *k2)
{
    const sx_ip_addr_t *key1 = (sx_ip_addr_t*)k1;
    const sx_ip_addr_t *key2 = (sx_ip_addr_t*)k2;

    CL_ASSERT(key1 && key2);

    return sdk_router_utils_compare_ip_address(key1, key2);
}

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t hwd_rips_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    return SX_STATUS_SUCCESS;
}

sx_status_t hwd_rips_db_init_get(boolean_t *is_rips_db_init_done_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(err = utils_check_pointer(is_rips_db_init_done_p,
                                                "is_rips_db_init_done_p"))) {
        goto out;
    }
    *is_rips_db_init_done_p = g_db_initialized;

out:
    return err;
}

sx_status_t hwd_rips_db_init_set(boolean_t is_rips_db_init_done_p)
{
    g_db_initialized = is_rips_db_init_done_p;
    return SX_STATUS_SUCCESS;
}

sx_status_t hwd_rips_db_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    cl_status_t cl_status = CL_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Init RIPS HWD DB.\n");

    if (TRUE == g_db_initialized) {
        err = SX_STATUS_DB_ALREADY_INITIALIZED;
        SX_LOG_ERR("RIPS HWD DB is already initialized.\n");
        goto out;
    }

    cl_status = CL_QPOOL_INIT(&g_ipv6_mgr_db.rips_pool, IPV6_POOL_MIN_SIZE, IPV6_POOL_SIZE_MAX,
                              IPV6_POOL_GROW_SIZE, sizeof(hwd_ipv6_entry_t),
                              NULL, NULL, NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG(SX_LOG_ERROR, "No resources to allocate new rips pool entry.\n");
        goto out;
    }

    cl_qmap_init(&g_ipv6_mgr_db.rips_handle_map);
    cl_fmap_init(&g_ipv6_mgr_db.rips_ip_map, __key_compare_cb);

    g_db_initialized = TRUE;

out:

    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rips_db_deinit(boolean_t is_forced)
{
    cl_map_item_t       *map_item_p = NULL;
    sx_status_t          err = SX_STATUS_SUCCESS;
    hwi_ipv6_hw_handle_t ipv6_block_handle = 0;
    hwd_ipv6_entry_t    *entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Deinit RIPS HWD DB, is forced[%u]\n", is_forced);

    if (FALSE == g_db_initialized) {
        if (FALSE == is_forced) {
            err = SX_STATUS_DB_NOT_INITIALIZED;
            SX_LOG_ERR("RIPS HWD DB is not initialized.\n");
        }
        goto out;
    }

    if (FALSE == is_forced) {
        if ((cl_qmap_count(&g_ipv6_mgr_db.rips_handle_map) != 0) ||
            (cl_fmap_count(&g_ipv6_mgr_db.rips_ip_map) != 0)) {
            err = SX_STATUS_DB_NOT_EMPTY;
            SX_LOG_ERR("Failed to deinit, found used IPv6 address, err: %s.\n", sx_status_str(err));
            goto out;
        }
    }

    map_item_p = cl_qmap_head(&g_ipv6_mgr_db.rips_handle_map);
    while (map_item_p != cl_qmap_end(&g_ipv6_mgr_db.rips_handle_map)) {
        ipv6_block_handle = cl_qmap_key(map_item_p);
        entry_p = PARENT_STRUCT(map_item_p, hwd_ipv6_entry_t, handle_map_item);
        if (entry_p->lock_cnt > 0) {
            err = kvd_linear_manager_handle_release(ipv6_block_handle);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to release kvd block err = %s.\n",
                           sx_status_str(err));
            }
        }
        err = kvd_linear_manager_block_delete(ipv6_block_handle, FALSE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to release kvd block err = %s.\n",
                       sx_status_str(err));
        }
        __hwd_rips_db_entry_remove(ipv6_block_handle);
        map_item_p = cl_qmap_get_next(&g_ipv6_mgr_db.rips_handle_map, ipv6_block_handle);
    }
    cl_fmap_remove_all(&g_ipv6_mgr_db.rips_ip_map);
    CL_QPOOL_DESTROY(&g_ipv6_mgr_db.rips_pool);

    g_db_initialized = FALSE;
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rips_db_add(hwd_ipv6_data_t *rips_data_p)
{
    hwd_ipv6_entry_t *tmp_entry_p = NULL;
    hwd_ipv6_entry_t *new_entry_p = NULL;
    cl_pool_item_t   *pool_item_p = NULL;
    sx_status_t       err = SX_STATUS_SUCCESS;
    char              ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(rips_data_p, "rips_data_p"))) {
        goto out;
    }

    SX_LOG_DBG("IPv6 MGR HWD: add RIPS entry [%s] to DB.\n", format_ip_addr(&rips_data_p->ip_addr, ip_addr_str));
    IPV6_MGR_HWD_DB_INIT_CHECK();

    err = __hwd_rips_db_entry_get(rips_data_p->ipv6_block_handle, &tmp_entry_p);
    if (SX_STATUS_SUCCESS == err) {
        err = SX_STATUS_ENTRY_ALREADY_EXISTS;
        SX_LOG_ERR("RIPS entry [%s] already exists in IPv6 MGR HWD DB, err = %s\n",
                   format_ip_addr(&rips_data_p->ip_addr, ip_addr_str), sx_status_str(err));
        goto out;
    } else if (SX_STATUS_ENTRY_NOT_FOUND != err) {
        SX_LOG_ERR("Failed to get RIPS entry [%s] from IPv6 MGR HWD DB, err = %s.\n",
                   format_ip_addr(&rips_data_p->ip_addr, ip_addr_str), sx_status_str(err));
        goto out;
    } else {
        err = SX_STATUS_SUCCESS;
    }

    pool_item_p = cl_qpool_get(&g_ipv6_mgr_db.rips_pool);
    if (NULL == pool_item_p) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Out of resources in HWD RIPS DB, err = %s.\n", sx_status_str(err));
        goto out;
    }
    new_entry_p = PARENT_STRUCT(pool_item_p, hwd_ipv6_entry_t, pool_item);
    new_entry_p->hw_index = rips_data_p->hw_index;
    new_entry_p->instance_cnt = rips_data_p->instance_cnt;
    new_entry_p->ip_addr = rips_data_p->ip_addr;
    new_entry_p->ipv6_block_handle = rips_data_p->ipv6_block_handle;
    new_entry_p->lock_cnt = rips_data_p->lock_cnt;

    cl_qmap_insert(&g_ipv6_mgr_db.rips_handle_map, new_entry_p->ipv6_block_handle, &new_entry_p->handle_map_item);
    cl_fmap_insert(&g_ipv6_mgr_db.rips_ip_map, &new_entry_p->ip_addr, &new_entry_p->ip_map_item);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rips_db_get(const sx_ip_addr_t *ip_addr_p, hwd_ipv6_data_t *rips_data_p)
{
    hwd_ipv6_entry_t *hwd_rips_p = NULL;
    cl_fmap_item_t   *map_item_p = NULL;
    sx_status_t       err = SX_STATUS_SUCCESS;
    char              ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(rips_data_p, "rips_data_p"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(err = utils_check_pointer(ip_addr_p, "ip_addr_p"))) {
        goto out;
    }
    SX_LOG_DBG("IPv6 MGR HWD: get RIPS entry from DB by address [%s]\n", format_ip_addr(ip_addr_p, ip_addr_str));

    IPV6_MGR_HWD_DB_INIT_CHECK();

    map_item_p = cl_fmap_get(&g_ipv6_mgr_db.rips_ip_map, ip_addr_p);
    if (map_item_p == cl_fmap_end(&g_ipv6_mgr_db.rips_ip_map)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("RIPS entry [%s] not exists.\n", format_ip_addr(ip_addr_p, ip_addr_str));
        goto out;
    }
    hwd_rips_p = PARENT_STRUCT(map_item_p, hwd_ipv6_entry_t, ip_map_item);

    rips_data_p->hw_index = hwd_rips_p->hw_index;
    rips_data_p->instance_cnt = hwd_rips_p->instance_cnt;
    rips_data_p->ip_addr = hwd_rips_p->ip_addr;
    rips_data_p->ipv6_block_handle = hwd_rips_p->ipv6_block_handle;
    rips_data_p->lock_cnt = hwd_rips_p->lock_cnt;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rips_db_get_by_handle(hwi_ipv6_hw_handle_t ipv6_block_handle, hwd_ipv6_data_t *rips_data_p)
{
    hwd_ipv6_entry_t *tmp_entry_p = NULL;
    sx_status_t       err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(rips_data_p, "rips_data_p"))) {
        goto out;
    }
    SX_LOG_DBG("IPv6 MGR HWD: get RIPS entry from DB by handle [0x%" PRIx64 "]\n", ipv6_block_handle);

    IPV6_MGR_HWD_DB_INIT_CHECK();

    err = __hwd_rips_db_entry_get(ipv6_block_handle, &tmp_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("RIPS entry handle [0x%" PRIx64 "] doesn't exist in HW DB, err = %s.\n",
                   ipv6_block_handle, sx_status_str(err));
        goto out;
    }

    rips_data_p->hw_index = tmp_entry_p->hw_index;
    rips_data_p->instance_cnt = tmp_entry_p->instance_cnt;
    rips_data_p->ip_addr = tmp_entry_p->ip_addr;
    rips_data_p->ipv6_block_handle = tmp_entry_p->ipv6_block_handle;
    rips_data_p->lock_cnt = tmp_entry_p->lock_cnt;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rips_db_update(const hwi_ipv6_hw_handle_t ipv6_block_handle, const hwd_ipv6_data_t *rips_data_p)
{
    hwd_ipv6_entry_t *old_entry_p = NULL;
    sx_status_t       err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("IPv6 MGR HWD: update RIPS by handle [0x%" PRIx64 "] in DB.\n", ipv6_block_handle);

    if (SX_CHECK_FAIL(err = utils_check_pointer(rips_data_p, "rips_data_p"))) {
        goto out;
    }

    IPV6_MGR_HWD_DB_INIT_CHECK();

    err = __hwd_rips_db_entry_get(ipv6_block_handle, &old_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("RIPS entry handle [0x%" PRIx64 "] doesn't exist in HW DB, err = %s.\n",
                   ipv6_block_handle, sx_status_str(err));
        goto out;
    }

    old_entry_p->hw_index = rips_data_p->hw_index;
    old_entry_p->instance_cnt = rips_data_p->instance_cnt;
    old_entry_p->ip_addr = rips_data_p->ip_addr;
    old_entry_p->ipv6_block_handle = rips_data_p->ipv6_block_handle;
    old_entry_p->lock_cnt = rips_data_p->lock_cnt;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rips_db_delete(hwi_ipv6_hw_handle_t ipv6_block_handle)
{
    cl_map_item_t *map_item_p = NULL;
    sx_status_t    err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("IPv6 MGR HWD: delete RIPS entry by handle [0x%" PRIx64 "] from HW DB.\n", ipv6_block_handle);

    IPV6_MGR_HWD_DB_INIT_CHECK();

    map_item_p = cl_qmap_get(&g_ipv6_mgr_db.rips_handle_map, ipv6_block_handle);
    if (cl_qmap_end(&g_ipv6_mgr_db.rips_handle_map) == map_item_p) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to delete RIPS entry by handle [0x%" PRIx64 "] from HW DB, err = %s.\n",
                   ipv6_block_handle,  sx_status_str(err));
        goto out;
    }

    __hwd_rips_db_entry_remove(ipv6_block_handle);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rips_db_total_rips_get(uint32_t *rips_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("IPv6 MGR HWD : Get total number of RIPS entry in DB.\n");

    IPV6_MGR_HWD_DB_INIT_CHECK();

    if (SX_CHECK_FAIL(err = utils_check_pointer(rips_cnt_p, "rips_cnt_p"))) {
        goto out;
    }

    *rips_cnt_p = cl_qmap_count(&g_ipv6_mgr_db.rips_handle_map);
    SX_LOG_DBG("IPv6 MGR HWD: total RIPS count is %u.\n", *rips_cnt_p);
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rips_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t            *map_item_p = NULL;
    hwd_ipv6_entry_t         *rips_entry_p = NULL;
    uint32_t                  total_count = 0;
    dbg_utils_table_columns_t rips_entry_table[] = {
        {"IP address",   39, PARAM_IPV6_E,   NULL}, /* 0 */
        {"Handle",       10, PARAM_HEX_E,    NULL}, /* 1 */
        {"RIPS Index",   10, PARAM_HEX_E,    NULL}, /* 2 */
        {"Instance count", 14, PARAM_UINT32_E, NULL}, /* 3 */
        {"Lock cnt",     10, PARAM_UINT32_E, NULL}, /* 4 */
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                     *stream = NULL;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "HWD IPV6 MGR DB");
    dbg_utils_pprinter_field_print(stream, "DB initialized", &g_db_initialized, PARAM_BOOL_E);

    if (g_db_initialized != TRUE) {
        goto out;
    }

    dbg_utils_pprinter_general_header_print(stream, "RIPS DB");
    total_count = cl_qmap_count(&g_ipv6_mgr_db.rips_handle_map);
    dbg_utils_pprinter_field_print(stream, "Total count:", &total_count, PARAM_UINT32_E);

    dbg_utils_pprinter_print(stream, "\n");
    dbg_utils_pprinter_table_headline_print(stream, rips_entry_table);

    if (!cl_is_qmap_empty(&g_ipv6_mgr_db.rips_handle_map)) {
        map_item_p = cl_qmap_head(&g_ipv6_mgr_db.rips_handle_map);
        while (cl_qmap_end(&g_ipv6_mgr_db.rips_handle_map) != map_item_p) {
            rips_entry_p = PARENT_STRUCT(map_item_p, hwd_ipv6_entry_t, handle_map_item);

            rips_entry_table[DBG_RIPS_IPV6_ADDR_E].data = &rips_entry_p->ip_addr.addr.ipv6;
            rips_entry_table[DBG_RIPS_HANDLE_E].data = &rips_entry_p->ipv6_block_handle;
            rips_entry_table[DBG_RIPS_INDEX_E].data = &rips_entry_p->hw_index;
            rips_entry_table[DBG_RIPS_INSTANCE_CNT_E].data = &rips_entry_p->instance_cnt;
            rips_entry_table[DBG_RIPS_LOCK_CNT_E].data = &rips_entry_p->lock_cnt;

            dbg_utils_pprinter_table_data_line_print(stream, rips_entry_table);
            map_item_p = cl_qmap_next(map_item_p);
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
