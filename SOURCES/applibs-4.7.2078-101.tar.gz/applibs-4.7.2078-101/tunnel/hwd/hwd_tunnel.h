/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __HWD_TUNNEL_H__
#define __HWD_TUNNEL_H__

#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <sx/sdk/sx_types.h>

#include "hwd_tunnel_db.h"
#include "tunnel/hwi/tunnel_impl.h"


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define TUNNEL_NVE_GS_FLOOD_DEFAULT_ENABLED 16
#define TUNNEL_NVE_GS_MC_DEFAULT_ENABLED    16

#define VXLAN_RESERVED_BITS_DEFAULT_MASK  (0xF7FFFFFF000000FF)
#define GPE_RESERVED_BITS_DEFAULT_MASK    (0xC0FFFF00000000FF)
#define GENEVE_RESERVED_BITS_DEFAULT_MASK (0x003F0000000000FF)
#define NVGRE_RESERVED_BITS_DEFAULT_MASK  (0x0FF80000)

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct hwd_tunnel_cos_global_attr {
    sx_tunnel_cos_data_t encap_cos_data;
    sx_tunnel_cos_data_t decap_cos_data;
} hwd_tunnel_cos_global_attr_t;

#define TUNNEL_NVE_UC_TTL_DEFAULT    255
#define TUNNEL_NVE_MC_TTL_DEFAULT    TUNNEL_NVE_UC_TTL_DEFAULT
#define TUNNEL_IPINIP_UC_TTL_DEFAULT 255
typedef enum hwd_tunnel_qos_tunnel_type {
    SX_TUNNEL_QOS_TUNNEL_TYPE_IPINIP_E = 0,
    SX_TUNNEL_QOS_TUNNEL_TYPE_NVE_E    = 1,

    SX_TUNNEL_QOS_TUNNEL_TYPE_MIN = SX_TUNNEL_QOS_TUNNEL_TYPE_IPINIP_E,
    SX_TUNNEL_QOS_TUNNEL_TYPE_MAX = SX_TUNNEL_QOS_TUNNEL_TYPE_NVE_E
} hwd_tunnel_qos_tunnel_type_t;

typedef struct hwd_tunnel_global_config {
    sx_tunnel_general_params_t   general_params;
    hwd_tngcr_t                  tngcr_config;
    hwd_tigcr_t                  tigcr_config;
    hwd_tnpc_t                   tnpc_config[SX_PORT_TUNNEL_MAX + 1];
    hwd_tunnel_cos_global_attr_t cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_MAX + 1];
} hwd_tunnel_global_config_t;

/* A structure for notifying decap relocation */
typedef struct tunnel_decap_cb {
    sx_tunnel_id_t tunnel_id;
    uint32_t       old_index;
    uint32_t       new_index;
} tunnel_decap_cb_t;

typedef struct hwd_tunnel_map_entry {
    sx_tunnel_map_entry_t map_entry;
    sx_flow_counter_id_t  decap_flow_counter_id;
    boolean_t             v_rif;
    hwd_rif_id_t          hw_rif_id;
} hwd_tunnel_map_entry_t;

/* function pointers for HWD APIs */
typedef struct hwd_tunnel_ops {
    sx_status_t (*hwd_tunnel_init_pfn)(sdk_tunnel_init_params_t * tunnel_gen_params_p);
    sx_status_t (*hwd_tunnel_deinit_pfn)(boolean_t is_forced);
    sx_status_t (*hwd_tunnel_create_pfn)(const sx_tunnel_attribute_t  *tunnel_attr_p,
                                         hwi_tunnel_hw_encap_handle_t *tunnel_encap_handle,
                                         hwi_tunnel_hw_decap_handle_t *tunnel_decap_handle);
    sx_status_t (*hwd_tunnel_delete_pfn)(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                         hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                         const sx_tunnel_attribute_t *tunnel_attr_p);
    sx_status_t (*hwd_tunnel_edit_pfn)(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                       hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                       const sx_tunnel_attribute_t *old_tunnel_attr_p,
                                       const sx_tunnel_attribute_t *new_tunnel_attr_p);
    sx_status_t (*hwd_tunnel_decap_block_lock_pfn)(hwi_tunnel_hw_decap_handle_t tunnel_decap_block,
                                                   hwd_tunnel_decap_index_t    *tunnel_hwd_index_p);
    sx_status_t (*hwd_tunnel_decap_block_unlock_pfn)(hwi_tunnel_hw_decap_handle_t tunnel_decap_block);
    sx_status_t (*hwd_tunnel_encap_block_lock_pfn)(hwi_tunnel_hw_encap_handle_t tunnel_encap_block,
                                                   hwd_tunnel_decap_index_t    *tunnel_hwd_index_p);
    sx_status_t (*hwd_tunnel_encap_block_unlock_pfn)(hwi_tunnel_hw_encap_handle_t tunnel_encap_block);
    sx_status_t (*hwd_tunnel_counter_get_pfn)(const boolean_t               is_clear,
                                              const sx_port_tunnel_phy_id_t phy_tunnel_port,
                                              sx_tunnel_counter_items_t    *counter);
    sx_status_t (*hwd_tunnel_tunnel_mapping_add_pfn)(const sx_tunnel_id_t          tunnel_id,
                                                     const hwd_tunnel_map_entry_t *map_entry_p,
                                                     const uint32_t                map_entry_cnt);
    sx_status_t (*hwd_tunnel_tunnel_mapping_update_pfn)(const sx_tunnel_id_t          tunnel_id,
                                                        const hwd_tunnel_map_entry_t *map_entry_p,
                                                        const uint32_t                map_entry_cnt);
    sx_status_t (*hwd_tunnel_tunnel_mapping_delete_pfn)(const sx_tunnel_id_t          tunnel_id,
                                                        const hwd_tunnel_map_entry_t *map_entry_p,
                                                        const uint32_t                map_entry_cnt);
    sx_status_t (*hwd_tunnel_port_isolate_hw_set_pfn)(const sx_access_cmd_t         cmd,
                                                      const sx_swid_t               swid,
                                                      const sx_device_id_t          device_id,
                                                      const sx_port_log_id_t        log_port,
                                                      const sx_port_isolate_table_e isolation_table,
                                                      const sx_port_log_id_t      * port_list_p,
                                                      const uint32_t                log_port_num);
    sx_status_t (*hwd_tunnel_ttl_set_pfn)(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                          hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                          const sx_tunnel_ttl_data_t  *ttl_data_p,
                                          sx_tunnel_type_e             tunnel_type);
    sx_status_t (*hwd_tunnel_ttl_get_pfn)(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                          hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                          sx_tunnel_ttl_data_t        *ttl_data_p,
                                          sx_tunnel_type_e             tunnel_type);
    sx_status_t (*hwd_tunnel_hash_set_pfn)(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                           hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                           const sx_tunnel_hash_data_t *hash_data_p);
    sx_status_t (*hwd_tunnel_hash_get_pfn)(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                           hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                           sx_tunnel_hash_data_t       *hash_data_p);
    sx_status_t (*hwd_tunnel_cos_set_pfn)(const sx_tunnel_type_e      tunnel_type,
                                          const sx_tunnel_cos_data_t *cos_data_p);
    sx_status_t (*hwd_tunnel_cos_get_pfn)(const sx_tunnel_id_t  tunnel_id,
                                          sx_tunnel_cos_data_t *cos_data_p);
    sx_status_t (*hwd_tunnel_debug_dump_pfn)(dbg_dump_params_t *dbg_dump_params_p);
    sx_status_t (*hwd_tunnel_counter_clear_pfn)(sx_port_tunnel_phy_id_t phy_tunnel_port);
    sx_status_t (*hwd_tunnel_nve_reg_deinit_pfn)();
    sx_status_t (*hwd_tunnel_issu_vni_set_pfn)(hwd_tunnel_map_entry_t *map_entry_p, boolean_t encap);
    sx_status_t (*hwd_tunnel_nve_learn_set_pfn)(sx_port_log_id_t log_port, boolean_t learn_enable);
    sx_status_t (*hwd_tunnel_nve_loopback_filter_set_pfn)(const sx_port_log_id_t         nve_log_port,
                                                          sx_port_loopback_filter_mode_t lbf_mode);
    sx_status_t (*hwd_tunnel_nve_port_issu_end_set_pfn)();
    sx_status_t (*hwd_tunnel_nve_group_size_flood_get_pfn)(uint32_t *ecmp_nve_flood_size_p);
    sx_status_t (*hwd_tunnel_nve_group_size_mc_get_pfn)(uint32_t *ecmp_nve_mc_size_p);
    sx_status_t (*hwd_tunnel_zeroed_reserved_tngee_index_get_pfn)(kvd_linear_manager_index_t *kvd_index_p);
} hwd_tunnel_ops_t;
/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t hwd_tunnel_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t hwd_tunnel_urif_internal_callbacks_register();
sx_status_t hwd_tunnel_urif_internal_callbacks_register_spectrum4();
sx_status_t hwd_tunnel_uvrid_internal_callbacks_register();

sx_status_t hwd_tunnel_init(sdk_tunnel_init_params_t *tunnel_init_params_p);

sx_status_t hwd_tunnel_deinit(boolean_t is_forced);

sx_status_t hwd_tunnel_create(const sx_tunnel_attribute_t  *tunnel_attr_p,
                              hwi_tunnel_hw_encap_handle_t *tunnel_encap_handle,
                              hwi_tunnel_hw_decap_handle_t *tunnel_decap_handle);

sx_status_t hwd_tunnel_delete(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                              hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                              const sx_tunnel_attribute_t *tunnel_attr_p);

sx_status_t hwd_tunnel_edit(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                            hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                            const sx_tunnel_attribute_t *old_tunnel_attr_p,
                            const sx_tunnel_attribute_t *new_tunnel_attr_p);

sx_status_t sdk_hwd_tunnel_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
sx_status_t ulay_default_rif_hwd_tunnel_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
sx_status_t hwd_tunnel_debug_dump_common(dbg_dump_params_t *dbg_dump_params_p);
/* tunnel_hwd_index_p - index in KVDL of RTDP block */
sx_status_t hwd_tunnel_decap_block_lock(hwi_tunnel_hw_decap_handle_t tunnel_decap_block,
                                        hwd_tunnel_decap_index_t    *tunnel_hw_index_p);

sx_status_t hwd_tunnel_decap_block_unlock(hwi_tunnel_hw_decap_handle_t tunnel_decap_block);

sx_status_t hwd_tunnel_encap_block_lock(hwi_tunnel_hw_encap_handle_t tunnel_encap_block,
                                        hwd_tunnel_encap_index_t    *tunnel_hw_index_p);

sx_status_t hwd_tunnel_encap_block_unlock(hwi_tunnel_hw_encap_handle_t tunnel_encap_block);

sx_status_t hwd_tunnel_nve_group_size_flood_get(uint32_t *nve_group_size_flood_p);
sx_status_t hwd_tunnel_nve_group_size_flood_get_spc2(uint32_t *nve_group_size_flood_p);
sx_status_t hwd_tunnel_nve_group_size_mc_get(uint32_t *nve_group_size_mc_p);
sx_status_t hwd_tunnel_nve_group_size_mc_get_spc2(uint32_t *nve_group_size_mc_p);

sx_status_t hwd_tunnel_counter_get(const boolean_t               is_clear,
                                   const sx_port_tunnel_phy_id_t phy_tunnel_port,
                                   sx_tunnel_counter_items_t    *counter);
sx_status_t hwd_tunnel_sync_dev(const sx_dev_id_t dev_id);

sx_status_t hwd_tunnel_nve_learn_set(sx_port_log_id_t log_port, boolean_t learn_enable);
sx_status_t hwd_tunnel_nve_learn_set_spc2(sx_port_log_id_t log_port, boolean_t learn_enable);
sx_status_t hwd_tunnel_nve_loopback_filter_set(const sx_port_log_id_t         nve_log_port,
                                               sx_port_loopback_filter_mode_t lbf_mode);

sx_status_t hwd_tunnel_tunnel_mapping_add(const sx_tunnel_id_t          tunnel_id,
                                          const hwd_tunnel_map_entry_t *map_entry_p,
                                          const uint32_t                map_entry_cnt);
sx_status_t hwd_tunnel_tunnel_mapping_update(const sx_tunnel_id_t          tunnel_id,
                                             const hwd_tunnel_map_entry_t *map_entry_p,
                                             const uint32_t                map_entry_cnt);
sx_status_t hwd_tunnel_tunnel_mapping_delete(const sx_tunnel_id_t          tunnel_id,
                                             const hwd_tunnel_map_entry_t *map_entry_p,
                                             const uint32_t                map_entry_cnt);

sx_status_t hwd_tunnel_port_isolate_hw_set(const sx_access_cmd_t         cmd,
                                           const sx_swid_t               swid,
                                           const sx_device_id_t          device_id,
                                           const sx_port_log_id_t        log_port,
                                           const sx_port_isolate_table_e isolation_table,
                                           const sx_port_log_id_t      * port_list_p,
                                           const uint32_t                log_port_num);

sx_status_t hwd_tunnel_ttl_set(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                               hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                               const sx_tunnel_ttl_data_t  *ttl_data_p,
                               sx_tunnel_type_e             tunnel_type);

sx_status_t hwd_tunnel_ttl_get(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                               hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                               sx_tunnel_ttl_data_t        *ttl_data_p,
                               sx_tunnel_type_e             tunnel_type);
sx_status_t hwd_tunnel_ttl_set_spc2(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                    const sx_tunnel_ttl_data_t  *ttl_data_p,
                                    sx_tunnel_type_e             tunnel_type);

sx_status_t hwd_tunnel_ttl_get_spc2(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                    sx_tunnel_ttl_data_t        *ttl_data_p,
                                    sx_tunnel_type_e             tunnel_type);

sx_status_t hwd_tunnel_hash_set(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                const sx_tunnel_hash_data_t *hash_data_p);

sx_status_t hwd_tunnel_hash_get(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                sx_tunnel_hash_data_t       *hash_data_p);

sx_status_t hwd_tunnel_cos_set(const sx_tunnel_type_e      tunnel_type,
                               const sx_tunnel_cos_data_t *cos_data_p);

sx_status_t hwd_tunnel_cos_get(const sx_tunnel_id_t  tunnel_id,
                               sx_tunnel_cos_data_t *cos_data_p);

sx_status_t hwd_tunnel_zeroed_reserved_tngee_index_get(kvd_linear_manager_index_t *kvd_index_p);

sx_status_t sdk_hwd_tunnel_counter_clear(sx_port_tunnel_phy_id_t phy_tunnel_port);

sx_status_t ulay_default_rif_hwd_tunnel_counter_clear(sx_port_tunnel_phy_id_t phy_tunnel_port);
sx_status_t ulay_default_rif_hwd_tunnel_counter_get(const boolean_t               is_clear,
                                                    const sx_port_tunnel_phy_id_t phy_tunnel_port,
                                                    sx_tunnel_counter_items_t    *counter);

/**
 * Create tunnel.
 * Supported devices: Spectrum2, Spectrum3.
 */
sx_status_t ulay_default_rif_hwd_tunnel_create(const sx_tunnel_attribute_t  *tunnel_attr_p,
                                               hwi_tunnel_hw_encap_handle_t *tunnel_encap_handle,
                                               hwi_tunnel_hw_decap_handle_t *tunnel_decap_handle);

/**
 * Edit tunnel.
 * Supported devices: Spectrum2, Spectrum3.
 */
sx_status_t ulay_default_rif_hwd_tunnel_edit(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                             hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                             const sx_tunnel_attribute_t *old_tunnel_attr_p,
                                             const sx_tunnel_attribute_t *new_tunnel_attr_p);

/**
 * Delete tunnel.
 * Supported devices: Spectrum2, Spectrum3.
 */
sx_status_t ulay_default_rif_hwd_tunnel_delete(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                               hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                               const sx_tunnel_attribute_t *tunnel_attr_p);

sx_status_t hwd_tunnel_nve_reg_deinit();

sx_status_t hwd_tunnel_issu_vni_set(hwd_tunnel_map_entry_t *map_entry_p, boolean_t encap);
sx_status_t hwd_tunnel_nve_port_issu_end_set();

void hwd_tunnel_trap_nve_options_set(const struct ku_hpkt_reg *nve_options_hpkt_p);

#endif /* __HWD_TUNNEL_H__ */
