/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/sx_log.h>
#include <complib/cl_dbg.h>
#include <sx/utils/psort.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <complib/cl_types.h>
#include <complib/cl_map.h>
#include <complib/cl_fleximap.h>

#include "acl/flex_acl.h"
#include "acl/flex_acl_db.h"
#include "tunnel/hwi/tunnel_impl.h"
#include "hwd_decap_table_db.h"
#include "resource_manager/spectrum.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include <sx/utils/id_allocator.h>
#include <sx/sdk/sx_status_convertor.h>

#undef  __MODULE__
#define __MODULE__ TUNNEL

#define KEY_IS_EQUAL(KEY1, KEY2) ((KEY1 < KEY2) ? -1 : KEY1 > KEY2);
#define INDEX_MAP_HEAD(version)                             \
    ((version == SX_IP_VERSION_IPV4) ?                      \
     cl_qmap_head(&(g_decap_table_db.acl_rule_index_map)) : \
     cl_qmap_head(&(g_decap_table_db.acl_rule_index_map_v6)))
#define INDEX_MAP_END(version)                             \
    ((version == SX_IP_VERSION_IPV4) ?                     \
     cl_qmap_end(&(g_decap_table_db.acl_rule_index_map)) : \
     cl_qmap_end(&(g_decap_table_db.acl_rule_index_map_v6)))

#define INDEX_MAP_GET(version)                \
    ((version == SX_IP_VERSION_IPV4) ?        \
     &(g_decap_table_db.acl_rule_index_map) : \
     &(g_decap_table_db.acl_rule_index_map_v6))

#define KEY_MAP_HEAD     cl_fmap_head(&(g_decap_table_db.key_map))
#define KEY_MAP_END      cl_fmap_end(&(g_decap_table_db.key_map))
#define IPV6_ADDR8_COUNT 16

#define ID_ALLOCATOR_MAX_SIZE  (rm_resource_global.kvd_size)
#define ID_ALLOCATOR_GROW_SIZE 1024
#define ID_ALLOCATOR_START_ID  0

typedef struct {
    sx_port_log_id_t nve_port;
    sx_acl_id_t      acl_group_id;
    cl_fmap_t        decap_entry_group;
} decap_bound_info_t;

typedef struct {
    sx_acl_region_id_t region_id;
    sx_acl_region_id_t region_id_v6;
    uint32_t           region_size;
    uint32_t           region_size_v6;
    cl_qpool_t         free_entries_pool;
    cl_fmap_t          key_map;
    cl_qmap_t          acl_rule_index_map;
    cl_qmap_t          acl_rule_index_map_v6;
    psort_handle_t     psort_handle;
    psort_handle_t     psort_handle_v6;
    decap_bound_info_t entries_bound;
    id_allocator_t     id_allocator;
} decap_table_db_t;

typedef struct {
    cl_pool_item_t               free_pool_item;
    cl_fmap_item_t               key_map_item;
    cl_map_item_t                acl_rule_index_map_item;
    cl_fmap_item_t               bound_map_item;
    boolean_t                    used;
    sx_tunnel_decap_entry_key_t  key;
    sx_tunnel_decap_entry_data_t data;
    sx_acl_rule_offset_t         acl_rule_index;
    int                          acl_rule_priority;
    sdk_ref_t                    vrid_ref;
    sdk_ref_t                    fpp_ref;
    uint32_t                     decap_entry_id;
} decap_table_entry_t;

typedef enum {
    DBG_COL_INDEX_E = 0,
    DBG_COL_PRIORITY_E,
    DBG_COL_TUNNEL_TYPE_E,
    DBG_COL_TYPE_E,
    DBG_COL_DIP_E,
    DBG_COL_DIP_MASK_E,
    DBG_COL_SIP_E,
    DBG_COL_SIP_MASK_E,
    DBG_COL_VRID_E,
    DBG_COL_ENTRY_ID_E,
    DBG_COL_ACTION_E,
    DBG_COL_TRAP_PRIO_E,
    DBG_COL_TUNNEL_ID_E,
    DBG_COL_COUNTER_ID_E,
    DBG_COL_SPAN_SESSION_ID_E,
    DBG_COL_SET_USER_TOKEN_ID_E,
    DBG_COL_USER_TOKEN_DATA_ID_E,
    DBG_COL_USER_TOKEN_MASK_ID_E,
} entry_table_col_e;

static decap_table_db_t g_decap_table_db;
static boolean_t        g_db_is_initialized = FALSE;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

sx_status_t hwd_decap_table_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

static int __decap_table_db_ip_addr_cmp(const sx_ip_addr_t p_ip1, const sx_ip_addr_t p_ip2)
{
    int res = 0;
    int i;

    res = KEY_IS_EQUAL(p_ip1.version, p_ip2.version);
    if (res != 0) {
        goto out;
    }

    if (p_ip1.version == SX_IP_VERSION_IPV4) {
        res = KEY_IS_EQUAL(p_ip1.addr.ipv4.s_addr, p_ip2.addr.ipv4.s_addr);
    } else if (p_ip1.version == SX_IP_VERSION_IPV6) {
        for (i = 0; i < IPV6_ADDR8_COUNT; i++) {
            res = KEY_IS_EQUAL(p_ip1.addr.ipv6.s6_addr[i],
                               p_ip2.addr.ipv6.s6_addr[i]);
            if (res != 0) {
                goto out;
            }
        }
    }

out:
    return res;
}

static int __decap_table_db_acl_map_key_compare(const void *const p_key1, const void *const p_key2)
{
    const sx_tunnel_decap_entry_key_t *key1 = p_key1;
    const sx_tunnel_decap_entry_key_t *key2 = p_key2;
    int                                res = 0;

    SX_LOG(SX_LOG_DEBUG, "key1 tunnel_type=%u, type=%u, underlay_vrid=%u, underlay_dip=%u, underlay_sip=%u\n",
           key1->tunnel_type, key1->type, key1->underlay_vrid,
           key1->underlay_dip.addr.ipv4.s_addr, key1->underlay_sip.addr.ipv4.s_addr);
    SX_LOG(SX_LOG_DEBUG, "key2 tunnel_type=%u, type=%u, underlay_vrid=%u, underlay_dip=%u, underlay_sip=%u\n",
           key2->tunnel_type, key2->type, key2->underlay_vrid,
           key2->underlay_dip.addr.ipv4.s_addr, key2->underlay_sip.addr.ipv4.s_addr);

    res = KEY_IS_EQUAL(key1->tunnel_type, key2->tunnel_type);
    if (res != 0) {
        goto out;
    }

    res = KEY_IS_EQUAL(key1->type, key2->type);
    if (res != 0) {
        goto out;
    }

    res = KEY_IS_EQUAL(key1->underlay_vrid, key2->underlay_vrid);
    if (res != 0) {
        goto out;
    }

    res = __decap_table_db_ip_addr_cmp(key1->underlay_dip, key2->underlay_dip);

    if (res != 0) {
        goto out;
    }

    if ((key1->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP) ||
        (key1->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET)) {
        res = __decap_table_db_ip_addr_cmp(key1->underlay_sip, key2->underlay_sip);
    }
    if (res != 0) {
        goto out;
    }

    if (key1->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET) {
        res = __decap_table_db_ip_addr_cmp(key1->underlay_dip_mask, key2->underlay_dip_mask);
        if (res != 0) {
            goto out;
        }
        res = __decap_table_db_ip_addr_cmp(key1->underlay_sip_mask, key2->underlay_sip_mask);
        if (res != 0) {
            goto out;
        }
    }


    if ((key1->tunnel_type == SX_TUNNEL_TYPE_L2_FLEX) || (key1->tunnel_type == SX_TUNNEL_TYPE_L2_FLEX_IPV6)) {
        res = KEY_IS_EQUAL(key1->tunnel_attributes.l2_flex_decap_attributes.fpp_id.fpp_id,
                           key2->tunnel_attributes.l2_flex_decap_attributes.fpp_id.fpp_id);
    }

out:
    SX_LOG(SX_LOG_DEBUG, "res = %d\n", res);
    return res;
}

static void __decap_table_db_free_entry(decap_table_entry_t *decap_entry)
{
    SX_MEM_CLR(decap_entry->key);
    decap_entry->acl_rule_index = 0;
    decap_entry->used = FALSE;
    cl_qpool_put(&(g_decap_table_db.free_entries_pool),
                 &(decap_entry->free_pool_item));

    return;
}

static sx_status_t __decap_table_db_remove_index_item(sx_ip_version_t       version,
                                                      sx_acl_rule_offset_t  index,
                                                      decap_table_entry_t **decap_entry)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t *map_item_p = NULL;

    map_item_p = cl_qmap_remove(INDEX_MAP_GET(version), index);
    if (map_item_p == INDEX_MAP_END(version)) {
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_INFO, "decap entry delete failed. Could not find Index %u in map. \n",
               index);
        goto out;
    }
    if (decap_entry) {
        *decap_entry = PARENT_STRUCT(map_item_p, decap_table_entry_t, acl_rule_index_map_item);
    }

out:
    return sx_status;
}

static sx_status_t __decap_table_db_remove_key_item(const sx_tunnel_decap_entry_key_t* key,
                                                    decap_table_entry_t              **decap_entry)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    cl_fmap_item_t *map_item_p = NULL;

    map_item_p = cl_fmap_remove(&(g_decap_table_db.key_map),
                                (const void*)key);
    if (map_item_p == KEY_MAP_END) {
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_INFO,
               "decap entry delete failed. Could not find entry in key map\n");
        goto out;
    }
    if (decap_entry) {
        *decap_entry = PARENT_STRUCT(map_item_p, decap_table_entry_t, key_map_item);
    }

out:
    return sx_status;
}

static void __decap_table_db_destroy_pool()
{
    cl_map_item_t       *map_item_p = NULL;
    decap_table_entry_t *decap_entry = NULL;

    map_item_p = INDEX_MAP_HEAD(SX_IP_VERSION_IPV4);
    /* Free all entries to pool */
    while (map_item_p != INDEX_MAP_END(SX_IP_VERSION_IPV4)) {
        decap_entry = PARENT_STRUCT(map_item_p, decap_table_entry_t, acl_rule_index_map_item);
        map_item_p = cl_qmap_next(map_item_p);
        cl_qmap_remove(&(g_decap_table_db.acl_rule_index_map), cl_qmap_key(&decap_entry->acl_rule_index_map_item));
        __decap_table_db_free_entry(decap_entry);
    }

    map_item_p = INDEX_MAP_HEAD(SX_IP_VERSION_IPV6);
    /* Free all entries to pool */
    while (map_item_p != INDEX_MAP_END(SX_IP_VERSION_IPV6)) {
        decap_entry = PARENT_STRUCT(map_item_p, decap_table_entry_t, acl_rule_index_map_item);
        map_item_p = cl_qmap_next(map_item_p);
        cl_qmap_remove(&(g_decap_table_db.acl_rule_index_map_v6), cl_qmap_key(&decap_entry->acl_rule_index_map_item));
        __decap_table_db_free_entry(decap_entry);
    }

    cl_fmap_remove_all(&(g_decap_table_db.key_map));

    cl_fmap_remove_all(&(g_decap_table_db.entries_bound.decap_entry_group));

    CL_QPOOL_DESTROY(&(g_decap_table_db.free_entries_pool));

    return;
}

static sx_status_t __decap_table_db_find_key_item(const sx_tunnel_decap_entry_key_t* key,
                                                  decap_table_entry_t              **decap_entry)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    cl_fmap_item_t *map_item_p = NULL;

    map_item_p = cl_fmap_get(&(g_decap_table_db.key_map),
                             (const void*)key);
    if (map_item_p == KEY_MAP_END) {
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_DEBUG,
               "could not find decap entry. \n");
        goto out;
    }

    if (decap_entry) {
        *decap_entry = PARENT_STRUCT(map_item_p, decap_table_entry_t, key_map_item);
    }
out:
    return sx_status;
}

sx_status_t decap_table_db_get_ref(const sx_tunnel_decap_entry_key_t *key,
                                   sdk_ref_t                         *vrid_ref_p,
                                   sdk_ref_t                         *fpp_ref_p)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    decap_table_entry_t *decap_entry_p = NULL;

    if (NULL == vrid_ref_p) {
        SX_LOG_ERR("vrid_ref_p is null\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = __decap_table_db_find_key_item(key, &decap_entry_p);
    if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_ERR("Failed to find decap entry.\n");
        goto out;
    }

    if (vrid_ref_p != NULL) {
        *vrid_ref_p = decap_entry_p->vrid_ref;
    }
    if (fpp_ref_p != NULL) {
        *fpp_ref_p = decap_entry_p->fpp_ref;
    }

out:
    return sx_status;
}

void decap_table_db_get_region_id(sx_ip_version_t ip_version, sx_acl_region_id_t *region_id)
{
    if (region_id) {
        if (ip_version == SX_IP_VERSION_IPV6) {
            *region_id = g_decap_table_db.region_id_v6;
        } else {
            *region_id = g_decap_table_db.region_id;
        }
    }

    return;
}

void decap_table_db_set_region_id(sx_ip_version_t ip_version, sx_acl_region_id_t region_id)
{
    if (ip_version == SX_IP_VERSION_IPV6) {
        g_decap_table_db.region_id_v6 = region_id;
    } else {
        g_decap_table_db.region_id = region_id;
    }

    return;
}

void decap_table_db_get_region_size(sx_ip_version_t ip_version, uint32_t *region_size)
{
    if (region_size) {
        if (SX_IP_VERSION_IPV4 == ip_version) {
            *region_size = g_decap_table_db.region_size;
        } else {
            *region_size = g_decap_table_db.region_size_v6;
        }
    }

    return;
}

void decap_table_db_set_region_size(sx_ip_version_t ip_version, uint32_t region_size)
{
    if (SX_IP_VERSION_IPV4 == ip_version) {
        g_decap_table_db.region_size = region_size;
    } else {
        g_decap_table_db.region_size_v6 = region_size;
    }
    return;
}

void decap_table_db_get_psort_handle(sx_ip_version_t ip_version, psort_handle_t *psort_handle)
{
    if (psort_handle) {
        if (SX_IP_VERSION_IPV4 == ip_version) {
            *psort_handle = g_decap_table_db.psort_handle;
        } else {
            *psort_handle = g_decap_table_db.psort_handle_v6;
        }
    }
}

void decap_table_db_set_psort_handle(sx_ip_version_t ip_version, psort_handle_t psort_handle)
{
    if (SX_IP_VERSION_IPV4 == ip_version) {
        g_decap_table_db.psort_handle = psort_handle;
    } else {
        g_decap_table_db.psort_handle_v6 = psort_handle;
    }
}

sx_status_t decap_table_db_generate_unique_entry_id(uint32_t *decap_entry_id_p)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failure: Decap Table DB is not initialized - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (NULL == decap_entry_id_p) {
        SX_LOG_ERR("decap_entry_id_p is NULL.\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sx_utils_status = id_allocator_get(&g_decap_table_db.id_allocator, decap_entry_id_p);
    if (SX_UTILS_CHECK_FAIL(sx_utils_status)) {
        sx_status = sx_utils_status_to_sx_status(sx_utils_status);
        SX_LOG_ERR("Failed to get an id from allocator - %s.\n", sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}

sx_status_t decap_table_db_free_unique_entry_id(uint32_t decap_entry_id)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failure: Decap Table DB is not initialized - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    sx_utils_status = id_allocator_put(&g_decap_table_db.id_allocator, decap_entry_id);
    if (SX_UTILS_CHECK_FAIL(sx_utils_status)) {
        sx_status = sx_utils_status_to_sx_status(sx_utils_status);
        SX_LOG_ERR("Failed to free id [%u] to decap table id allocator - %s.\n", decap_entry_id,
                   sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t decap_table_db_map_entry_add(const sx_tunnel_decap_entry_key_t  *key,
                                         const sx_tunnel_decap_entry_data_t *data,
                                         int                                 priority,
                                         sx_acl_rule_offset_t                acl_rule_offset,
                                         sdk_ref_t                           vrid_ref,
                                         sdk_ref_t                           fpp_ref,
                                         sx_acl_id_t                        *acl_group_id_p,
                                         uint32_t                            decap_entry_id)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    cl_pool_item_t      *pool_item = NULL;
    decap_table_entry_t *decap_entry = NULL;
    uint64_t             index_map_key;
    sx_tunnel_id_t       tunnel_id;

    SX_LOG_ENTER();

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    /* prepare an item for lookup table  */
    pool_item = cl_qpool_get(&(g_decap_table_db.free_entries_pool));
    if (pool_item == NULL) {
        SX_LOG(SX_LOG_INFO, "Could not get free entry from pool.\n");
        sx_status = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    decap_entry = PARENT_STRUCT(pool_item, decap_table_entry_t, free_pool_item);
    decap_entry->key = *key;
    decap_entry->data = *data;
    decap_entry->acl_rule_index = acl_rule_offset;
    decap_entry->used = TRUE;
    decap_entry->acl_rule_priority = priority;
    decap_entry->vrid_ref = vrid_ref;
    decap_entry->fpp_ref = fpp_ref;
    decap_entry->decap_entry_id = decap_entry_id;
    /*
     * Add to key map
     */
    cl_fmap_insert(&(g_decap_table_db.key_map),
                   (const void*)&(decap_entry->key), &(decap_entry->key_map_item));

    /*
     * Add to index map
     */
    index_map_key = acl_rule_offset;
    cl_qmap_insert(INDEX_MAP_GET(decap_entry->key.underlay_dip.version),
                   index_map_key, &(decap_entry->acl_rule_index_map_item));

    /*
     * Add to bound entries
     */
    *acl_group_id_p = FLEX_ACL_INVALID_ACL_ID;
    if (g_decap_table_db.entries_bound.acl_group_id == FLEX_ACL_INVALID_ACL_ID) {
        goto out;
    }
    if (((key->tunnel_type == SX_TUNNEL_TYPE_NVE_VXLAN) ||
         (key->tunnel_type == SX_TUNNEL_TYPE_NVE_VXLAN_IPV6) ||
         (key->tunnel_type == SX_TUNNEL_TYPE_NVE_NVGRE) ||
         (key->tunnel_type == SX_TUNNEL_TYPE_NVE_NVGRE_IPV6)) &&
        ((data->action == SX_ROUTER_ACTION_FORWARD) ||
         (data->action == SX_ROUTER_ACTION_TRAP_FORWARD))) {
        sx_status = sdk_tunnel_impl_tunnel_id_by_log_port_get(g_decap_table_db.entries_bound.nve_port, &tunnel_id);
        if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
            /* Should not happen since tunnel BE verified already */
            SX_LOG_DBG("No vxlan tunnel id created yet\n");
            sx_status = SX_STATUS_SUCCESS;
            goto out;
        }
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get tunnel id from nve port 0x%08x.\n", g_decap_table_db.entries_bound.nve_port);
            goto out;
        }

        if (data->tunnel_id == tunnel_id) {
            cl_fmap_insert(&(g_decap_table_db.entries_bound.decap_entry_group),
                           (const void*)&(decap_entry->key), &(decap_entry->bound_map_item));
            *acl_group_id_p = g_decap_table_db.entries_bound.acl_group_id;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t decap_table_db_map_entry_edit(const sx_tunnel_decap_entry_key_t  *key,
                                          const sx_tunnel_decap_entry_data_t *data,
                                          sx_acl_id_t                        *acl_group_id_p)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    decap_table_entry_t *decap_entry = NULL;
    sx_tunnel_id_t       tunnel_id;
    boolean_t            is_bound, to_be_bound;

    SX_LOG_ENTER();

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = __decap_table_db_find_key_item(key, &decap_entry);
    if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG(SX_LOG_INFO,
               "could not find decap entry. \n");
        goto out;
    }

    decap_entry->data = *data;

    /*
     * Update bound entries
     */
    *acl_group_id_p = FLEX_ACL_INVALID_ACL_ID;
    if ((g_decap_table_db.entries_bound.acl_group_id != FLEX_ACL_INVALID_ACL_ID) &&
        ((key->tunnel_type == SX_TUNNEL_TYPE_NVE_VXLAN) ||
         (key->tunnel_type == SX_TUNNEL_TYPE_NVE_VXLAN_IPV6) ||
         (key->tunnel_type == SX_TUNNEL_TYPE_NVE_NVGRE) ||
         (key->tunnel_type == SX_TUNNEL_TYPE_NVE_NVGRE_IPV6))) {
        sx_status = sdk_tunnel_impl_tunnel_id_by_log_port_get(g_decap_table_db.entries_bound.nve_port, &tunnel_id);
        if (SX_CHECK_FAIL(sx_status)) {
            sx_status = SX_STATUS_ERROR;
            SX_LOG_DBG("Failed to get tunnel id from nve port 0x%08x.\n", g_decap_table_db.entries_bound.nve_port);
            goto out;
        }

        is_bound = (cl_fmap_get(&(g_decap_table_db.entries_bound.decap_entry_group), (const void*)key) !=
                    cl_fmap_end(&(g_decap_table_db.entries_bound.decap_entry_group)));
        to_be_bound = (((data->action == SX_ROUTER_ACTION_FORWARD) ||
                        (data->action == SX_ROUTER_ACTION_TRAP_FORWARD))
                       && (data->tunnel_id == tunnel_id));

        if ((is_bound == TRUE) && (to_be_bound == FALSE)) {
            cl_fmap_remove(&(g_decap_table_db.entries_bound.decap_entry_group),
                           (const void*)&(decap_entry->key));
        } else if ((is_bound == FALSE) && (to_be_bound == TRUE)) {
            cl_fmap_insert(&(g_decap_table_db.entries_bound.decap_entry_group),
                           (const void*)&(decap_entry->key), &(decap_entry->bound_map_item));
        }

        if (to_be_bound == TRUE) {
            *acl_group_id_p = g_decap_table_db.entries_bound.acl_group_id;
        }
    }

out:
    return sx_status;
}

sx_status_t decap_table_db_map_entry_delete(sx_ip_version_t version, const sx_acl_rule_offset_t index)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t    sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    decap_table_entry_t *decap_entry = NULL;

    SX_LOG_ENTER();

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = __decap_table_db_remove_index_item(version, index, &decap_entry);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "decap entry delete failed. Could not find Index %u in map. \n",
               index);
        goto out;
    }
    sx_status = __decap_table_db_remove_key_item(&(decap_entry->key), NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR,
               "Fatal Error: decap entry delete failed. Could not find entry in key map which is in index map\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sx_utils_status = id_allocator_put(&g_decap_table_db.id_allocator, decap_entry->decap_entry_id);
    if (SX_UTILS_CHECK_FAIL(sx_utils_status)) {
        sx_status = sx_utils_status_to_sx_status(sx_utils_status);
        SX_LOG_ERR("Failed to free id [%u] to decap table id allocator.\n", decap_entry->decap_entry_id);
        goto out;
    }

    cl_fmap_remove(&(g_decap_table_db.entries_bound.decap_entry_group),
                   (const void*)&(decap_entry->key));

    __decap_table_db_free_entry(decap_entry);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t decap_table_db_map_entry_move(const sx_ip_version_t      version,
                                          const sx_acl_rule_offset_t old_index,
                                          const sx_acl_rule_offset_t new_index,
                                          const uint32_t             size)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    decap_table_entry_t *decap_entry_old = NULL;
    decap_table_entry_t *decap_entry_new = NULL;
    sx_acl_rule_offset_t i;
    sx_acl_rule_offset_t gap;

    SX_LOG_ENTER();

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    /* Don't support overlap currently */
    gap = (old_index > new_index) ? (old_index - new_index) : (new_index - old_index);

    if (gap < size) {
        SX_LOG(SX_LOG_ERROR, "Failed to move overlapped entries\n");
        sx_status = SX_STATUS_CMD_UNPERMITTED;
        goto out;
    }

    for (i = 0; i < size; i++) {
        sx_status = __decap_table_db_remove_index_item(version, old_index + i, &decap_entry_old);
        if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG(SX_LOG_ERROR, "decap entry delete failed. Could not find Index %u in map. \n",
                   old_index + i);
            goto out;
        }
        decap_entry_old->acl_rule_index = new_index + i;

        sx_status = __decap_table_db_remove_index_item(version, new_index + i, &decap_entry_new);
        if (sx_status == SX_STATUS_SUCCESS) {
            /* Move to a non-empty slot, in case delete the entry and move another entry to it*/
            sx_status = __decap_table_db_remove_key_item(&(decap_entry_new->key), NULL);
            if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
                SX_LOG(SX_LOG_ERROR,
                       "Fatal Error: decap entry delete failed. Could not find entry in key map which is in index map\n");
                sx_status = SX_STATUS_ERROR;
                goto out;
            }
            cl_fmap_remove(&(g_decap_table_db.entries_bound.decap_entry_group),
                           (const void*)&(decap_entry_new->key));
            __decap_table_db_free_entry(decap_entry_new);
        }
        sx_status = SX_STATUS_SUCCESS;

        cl_qmap_insert(INDEX_MAP_GET(version),
                       new_index + i, &(decap_entry_old->acl_rule_index_map_item));
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t decap_table_db_map_entry_find(const sx_tunnel_decap_entry_key_t *key,
                                          sx_tunnel_decap_entry_data_t      *data,
                                          sx_acl_rule_offset_t              *offset_p,
                                          int                               *priority)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    decap_table_entry_t *decap_entry = NULL;

    SX_LOG_ENTER();

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = __decap_table_db_find_key_item(key, &decap_entry);
    if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG(SX_LOG_INFO,
               "could not find decap entry. \n");
        goto out;
    }

    if (offset_p != NULL) {
        *offset_p = decap_entry->acl_rule_index;
    }
    if (data != NULL) {
        *data = decap_entry->data;
    }
    if (priority != NULL) {
        *priority = decap_entry->acl_rule_priority;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t decap_table_db_bind_acl(sx_port_log_id_t nve_port, sx_acl_id_t acl_group_id)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    sx_tunnel_id_t        tunnel_id;
    cl_fmap_item_t       *map_item_p = NULL;
    const cl_fmap_item_t *map_item_end_p = NULL;
    decap_table_entry_t  *decap_entry_p = NULL;


    if (g_decap_table_db.entries_bound.acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
        /* Rebind */
        if (nve_port != g_decap_table_db.entries_bound.nve_port) {
            sx_status = SX_STATUS_ERROR;
            SX_LOG_ERR("Only one nve port supported.\n");
            goto out;
        }
        if (g_decap_table_db.entries_bound.acl_group_id == acl_group_id) {
            sx_status = SX_STATUS_ENTRY_ALREADY_BOUND;
            goto out;
        }
        g_decap_table_db.entries_bound.acl_group_id = acl_group_id;
        goto out;
    }

    /* New bind */
    g_decap_table_db.entries_bound.acl_group_id = acl_group_id;
    g_decap_table_db.entries_bound.nve_port = nve_port;

    sx_status = sdk_tunnel_impl_tunnel_id_by_log_port_get(nve_port, &tunnel_id);
    if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
        sx_status = SX_STATUS_SUCCESS;
        SX_LOG_DBG("No vxlan tunnel created yet.\n");
        goto out;
    }
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get tunnel id from nve port 0x%08x.\n", nve_port);
        goto out;
    }

    if (cl_is_fmap_empty(&(g_decap_table_db.entries_bound.decap_entry_group)) != TRUE) {
        /* Should not happen */
        SX_LOG_DBG("Bound decap entry group is not empty for new bind.\n");
        cl_fmap_remove_all(&(g_decap_table_db.entries_bound.decap_entry_group));
    }

    map_item_p = cl_fmap_head(&(g_decap_table_db.key_map));
    map_item_end_p = cl_fmap_end(&(g_decap_table_db.key_map));
    while (map_item_p != map_item_end_p) {
        decap_entry_p = PARENT_STRUCT(map_item_p, decap_table_entry_t, key_map_item);
        map_item_p = cl_fmap_next(map_item_p);
        if (((decap_entry_p->key.tunnel_type == SX_TUNNEL_TYPE_NVE_VXLAN) ||
             (decap_entry_p->key.tunnel_type == SX_TUNNEL_TYPE_NVE_VXLAN_IPV6) ||
             (decap_entry_p->key.tunnel_type == SX_TUNNEL_TYPE_NVE_NVGRE) ||
             (decap_entry_p->key.tunnel_type == SX_TUNNEL_TYPE_NVE_NVGRE_IPV6)) &&
            (decap_entry_p->data.tunnel_id == tunnel_id) &&
            ((decap_entry_p->data.action == SX_ROUTER_ACTION_FORWARD) ||
             (decap_entry_p->data.action == SX_ROUTER_ACTION_TRAP_FORWARD))) {
            cl_fmap_insert(&(g_decap_table_db.entries_bound.decap_entry_group),
                           (const void*)&(decap_entry_p->key),
                           &(decap_entry_p->bound_map_item));
        }
    }

out:
    return sx_status;
}

sx_status_t decap_table_db_unbind_acl(sx_port_log_id_t nve_port)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (nve_port != g_decap_table_db.entries_bound.nve_port) {
        sx_status = SX_STATUS_ENTRY_NOT_BOUND;
        SX_LOG_ERR("nve port is not bound.\n");
        goto out;
    }

    if (g_decap_table_db.entries_bound.acl_group_id == FLEX_ACL_INVALID_ACL_ID) {
        sx_status = SX_STATUS_ENTRY_NOT_BOUND;
        SX_LOG_ERR("No acl group bound.\n");
        goto out;
    }

    g_decap_table_db.entries_bound.acl_group_id = FLEX_ACL_INVALID_ACL_ID;

    cl_fmap_remove_all(&(g_decap_table_db.entries_bound.decap_entry_group));

    goto out;
out:
    return sx_status;
}

sx_status_t decap_table_db_get_bound_acl(sx_port_log_id_t nve_port, sx_acl_id_t *acl_group_id_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if ((g_decap_table_db.entries_bound.acl_group_id == FLEX_ACL_INVALID_ACL_ID) ||
        (nve_port != g_decap_table_db.entries_bound.nve_port)) {
        sx_status = SX_STATUS_ENTRY_NOT_BOUND;
        SX_LOG_DBG("nve port 0x%08x is not bound.\n", nve_port);
        goto out;
    }

    *acl_group_id_p = g_decap_table_db.entries_bound.acl_group_id;

out:
    return sx_status;
}

sx_status_t decap_table_db_get_bound_entries(sx_port_log_id_t               nve_port,
                                             sx_tunnel_decap_entry_key_t  **key_p_list_p,
                                             sx_tunnel_decap_entry_data_t **data_p_list_p,
                                             sx_acl_rule_offset_t          *index_list_p,
                                             uint16_t                      *entries_count_p)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    cl_fmap_item_t       *map_item_p = NULL;
    const cl_fmap_item_t *map_item_end_p = NULL;
    decap_table_entry_t  *decap_entry_p = NULL;
    uint32_t              count = 0;

    if (entries_count_p == NULL) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("entries_count_p is NULL\n");
        goto out;
    }

    if ((g_decap_table_db.entries_bound.acl_group_id == FLEX_ACL_INVALID_ACL_ID) ||
        (nve_port != g_decap_table_db.entries_bound.nve_port)) {
        sx_status = SX_STATUS_ENTRY_NOT_BOUND;
        SX_LOG_DBG("nve port 0x%08x is not bound.\n", nve_port);
        goto out;
    }

    if ((key_p_list_p == NULL) || (data_p_list_p == NULL) || (index_list_p == NULL)) {
        *entries_count_p = cl_fmap_count(&(g_decap_table_db.entries_bound.decap_entry_group));
        goto out;
    }

    map_item_p = cl_fmap_head(&(g_decap_table_db.entries_bound.decap_entry_group));
    map_item_end_p = cl_fmap_end(&(g_decap_table_db.entries_bound.decap_entry_group));
    while (map_item_p != map_item_end_p) {
        decap_entry_p = PARENT_STRUCT(map_item_p, decap_table_entry_t, bound_map_item);
        map_item_p = cl_fmap_next(map_item_p);
        index_list_p[count] = decap_entry_p->acl_rule_index;
        key_p_list_p[count] = &(decap_entry_p->key);
        data_p_list_p[count] = &(decap_entry_p->data);
        count++;
    }

    *entries_count_p = count;

out:
    return sx_status;
}

sx_status_t decap_table_db_init(uint32_t region_size)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_status;
    uint32_t          decap_rules_max;

    if (TRUE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_ALREADY_INITIALIZED;
        SX_LOG_ERR("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    SX_MEM_CLR(g_decap_table_db);
    g_decap_table_db.region_id = ACL_INVALID_ID;
    g_decap_table_db.region_id_v6 = ACL_INVALID_ID;

    /* Create DB */
    decap_rules_max = SPECTRUM_TOTAL_TCAM;

    cl_status = CL_QPOOL_INIT(&(g_decap_table_db.free_entries_pool),
                              decap_rules_max, decap_rules_max,
                              0, sizeof(decap_table_entry_t),
                              NULL, NULL, NULL);
    if (cl_status != CL_SUCCESS) {
        sx_status = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("log_port_map_pool init failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    cl_fmap_init(&(g_decap_table_db.key_map),
                 __decap_table_db_acl_map_key_compare);

    cl_qmap_init(&(g_decap_table_db.acl_rule_index_map));
    cl_qmap_init(&(g_decap_table_db.acl_rule_index_map_v6));

    cl_fmap_init(&(g_decap_table_db.entries_bound.decap_entry_group),
                 __decap_table_db_acl_map_key_compare);
    g_decap_table_db.entries_bound.acl_group_id = FLEX_ACL_INVALID_ACL_ID;
    g_decap_table_db.entries_bound.nve_port = SX_INVALID_PORT;

    cl_fmap_init(&(g_decap_table_db.entries_bound.decap_entry_group),
                 __decap_table_db_acl_map_key_compare);
    g_decap_table_db.entries_bound.acl_group_id = FLEX_ACL_INVALID_ACL_ID;
    g_decap_table_db.entries_bound.nve_port = SX_INVALID_PORT;

    g_db_is_initialized = TRUE;
    g_decap_table_db.region_size = region_size;
    g_decap_table_db.region_size_v6 = region_size;

    sx_utils_status = id_allocator_init(ID_ALLOCATOR_MAX_SIZE,
                                        ID_ALLOCATOR_GROW_SIZE,
                                        ID_ALLOCATOR_START_ID,
                                        &g_decap_table_db.id_allocator);
    if (SX_UTILS_CHECK_FAIL(sx_utils_status)) {
        sx_status = sx_utils_status_to_sx_status(sx_utils_status);
        SX_LOG_ERR("Failed to init decap table id allocator.\n");
        goto out;
    }

out:
    return sx_status;
}

sx_status_t decap_table_db_deinit(boolean_t force_deinit)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    /* Verify it's ready to deinit */
    if ((cl_is_qmap_empty(&(g_decap_table_db.acl_rule_index_map)) == FALSE) &&
        (force_deinit == FALSE)) {
        SX_LOG(SX_LOG_INFO, "There are still rules while not force deinit\n");
        sx_status = SX_STATUS_DB_NOT_EMPTY;
        goto out;
    }

    if ((cl_is_qmap_empty(&(g_decap_table_db.acl_rule_index_map_v6)) == FALSE) &&
        (force_deinit == FALSE)) {
        SX_LOG(SX_LOG_INFO, "There are still ipv6 rules while not force deinit\n");
        sx_status = SX_STATUS_DB_NOT_EMPTY;
        goto out;
    }

    sx_utils_status = id_allocator_destroy(&g_decap_table_db.id_allocator);
    if ((FALSE == force_deinit) && SX_UTILS_CHECK_FAIL(sx_utils_status)) {
        sx_status = sx_utils_status_to_sx_status(sx_utils_status);
        SX_LOG_ERR("Failed to deinit decap table id allocator.\n");
        goto out;
    }

    /* Free all entries to pool */
    __decap_table_db_destroy_pool();

    g_db_is_initialized = FALSE;

out:
    return sx_status;
}

sx_status_t decap_table_db_integrity_verification(void)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    decap_table_entry_t *decap_entry = NULL;
    cl_map_item_t       *map_item_p = NULL;

    if ((cl_qmap_count(&(g_decap_table_db.acl_rule_index_map)) +
         cl_qmap_count(&(g_decap_table_db.acl_rule_index_map_v6))) !=
        cl_fmap_count(&(g_decap_table_db.key_map))) {
        SX_LOG(SX_LOG_ERROR, "Decap table index map count NOT equal to key map count\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    map_item_p = INDEX_MAP_HEAD(SX_IP_VERSION_IPV4);

    while (map_item_p != INDEX_MAP_END(SX_IP_VERSION_IPV4)) {
        decap_entry = PARENT_STRUCT(map_item_p, decap_table_entry_t, acl_rule_index_map_item);
        sx_status = __decap_table_db_find_key_item(&(decap_entry->key), NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Fatal Error: Could not find entry in key map which is in index map\n");
            sx_status = SX_STATUS_ERROR;
            goto out;
        }

        map_item_p = cl_qmap_next(map_item_p);
        SX_LOG(SX_LOG_INFO, "decap entry = %p \n", decap_entry);
    }


    map_item_p = INDEX_MAP_HEAD(SX_IP_VERSION_IPV6);

    while (map_item_p != INDEX_MAP_END(SX_IP_VERSION_IPV6)) {
        decap_entry = PARENT_STRUCT(map_item_p, decap_table_entry_t, acl_rule_index_map_item);
        sx_status = __decap_table_db_find_key_item(&(decap_entry->key), NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Fatal Error: Could not find entry in key map which is in index map\n");
            sx_status = SX_STATUS_ERROR;
            goto out;
        }

        map_item_p = cl_qmap_next(map_item_p);
        SX_LOG(SX_LOG_INFO, "decap entry = %p \n", decap_entry);
    }

out:
    return sx_status;
}

sx_status_t decap_table_db_dump_index_map(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    decap_table_entry_t      *decap_entry = NULL;
    cl_map_item_t            *map_item_p = NULL;
    const char               *unknown_ip = "UNKNOWN";
    const char               *empty_space = " ";
    char                      tunnel_id_str[11];
    sx_ip_version_t           version = 0;
    dbg_utils_table_columns_t decap_table_columns[] = {
        {"Index", 5, PARAM_UINT16_E, NULL},
        {"Prio", 5, PARAM_INT_E, NULL},
        {"Tun type", 8, PARAM_STRING_E, NULL},
        {"Type", 7, PARAM_STRING_E, NULL},
        {"Dest IP", 45, PARAM_IPV4_E, NULL},
        {"Dest Mask", 45, PARAM_IPV4_E, NULL},
        {"Src IP", 45, PARAM_IPV4_E, NULL},
        {"Src Mask", 45, PARAM_IPV4_E, NULL},
        {"VRID", 4, PARAM_UINT16_E, NULL},
        {"Decap Entry ID", 10, PARAM_UINT32_E, NULL},
        {"Action", 16, PARAM_STRING_E, NULL},
        {"Trap Prio", 9, PARAM_STRING_E, NULL},
        {"Tunnel ID", 10, PARAM_STRING_E, NULL},
        {"Counter ID", 10, PARAM_UINT32_E, NULL},
        {"Span Session ID", 15, PARAM_UINT8_E, NULL},
        {"Set user token", 16, PARAM_BOOL_E, NULL},
        {"User token data", 16, PARAM_UINT16_E, NULL},
        {"User token mask", 16, PARAM_UINT16_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                     *stream = NULL;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    dbg_utils_pprinter_general_header_print(stream, "Decap Table Entries");
    dbg_utils_pprinter_table_headline_print(stream, decap_table_columns);

    for (version = SX_IP_VERSION_IPV4; version <= SX_IP_VERSION_IPV6; version++) {
        map_item_p = INDEX_MAP_HEAD(version);

        while (map_item_p != INDEX_MAP_END(version)) {
            decap_entry = PARENT_STRUCT(map_item_p, decap_table_entry_t, acl_rule_index_map_item);
            decap_table_columns[DBG_COL_INDEX_E].data = &decap_entry->acl_rule_index;
            decap_table_columns[DBG_COL_PRIORITY_E].data = &decap_entry->acl_rule_priority;
            if (SX_CHECK_MAX(decap_entry->key.tunnel_type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
                decap_table_columns[DBG_COL_TUNNEL_TYPE_E].data = "IPinIP";
            } else if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, decap_entry->key.tunnel_type, SX_TUNNEL_TYPE_NVE_MAX)) {
                decap_table_columns[DBG_COL_TUNNEL_TYPE_E].data = "NVE";
            } else {
                decap_table_columns[DBG_COL_TUNNEL_TYPE_E].data = "UNKNOWN";
            }
            decap_table_columns[DBG_COL_TYPE_E].data = sx_tunnel_decap_key_fields_type_str(decap_entry->key.type);
            if (decap_entry->key.underlay_dip.version == SX_IP_VERSION_IPV4) {
                decap_table_columns[DBG_COL_DIP_E].type = PARAM_IPV4_E;
                decap_table_columns[DBG_COL_DIP_E].data = &decap_entry->key.underlay_dip.addr.ipv4.s_addr;
                if (decap_entry->key.type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET) {
                    decap_table_columns[DBG_COL_DIP_MASK_E].type = PARAM_IPV4_E;
                    decap_table_columns[DBG_COL_DIP_MASK_E].data =
                        &decap_entry->key.underlay_dip_mask.addr.ipv4.s_addr;
                } else {
                    decap_table_columns[DBG_COL_DIP_MASK_E].type = PARAM_STRING_E;
                    decap_table_columns[DBG_COL_DIP_MASK_E].data = empty_space;
                }
            } else if (decap_entry->key.underlay_dip.version == SX_IP_VERSION_IPV6) {
                decap_table_columns[DBG_COL_DIP_E].type = PARAM_IPV6_E;
                decap_table_columns[DBG_COL_DIP_E].data = &decap_entry->key.underlay_dip.addr.ipv6;
                if (decap_entry->key.type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET) {
                    decap_table_columns[DBG_COL_DIP_MASK_E].type = PARAM_IPV6_E;
                    decap_table_columns[DBG_COL_DIP_MASK_E].data = &decap_entry->key.underlay_dip_mask.addr.ipv6;
                } else {
                    decap_table_columns[DBG_COL_DIP_MASK_E].type = PARAM_STRING_E;
                    decap_table_columns[DBG_COL_DIP_MASK_E].data = empty_space;
                }
            } else {
                decap_table_columns[DBG_COL_DIP_E].type = PARAM_STRING_E;
                decap_table_columns[DBG_COL_DIP_E].data = unknown_ip;
                decap_table_columns[DBG_COL_DIP_MASK_E].type = PARAM_STRING_E;
                decap_table_columns[DBG_COL_DIP_MASK_E].data = empty_space;
            }

            if ((decap_entry->key.type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP) ||
                (decap_entry->key.type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET)) {
                if (decap_entry->key.underlay_sip.version == SX_IP_VERSION_IPV4) {
                    decap_table_columns[DBG_COL_SIP_E].type = PARAM_IPV4_E;
                    decap_table_columns[DBG_COL_SIP_E].data = &decap_entry->key.underlay_sip.addr.ipv4.s_addr;
                    if (decap_entry->key.type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET) {
                        decap_table_columns[DBG_COL_SIP_MASK_E].type = PARAM_IPV4_E;
                        decap_table_columns[DBG_COL_SIP_MASK_E].data =
                            &decap_entry->key.underlay_sip_mask.addr.ipv4.s_addr;
                    } else {
                        decap_table_columns[DBG_COL_SIP_MASK_E].type = PARAM_STRING_E;
                        decap_table_columns[DBG_COL_SIP_MASK_E].data = empty_space;
                    }
                } else if (decap_entry->key.underlay_sip.version == SX_IP_VERSION_IPV6) {
                    decap_table_columns[DBG_COL_SIP_E].type = PARAM_IPV6_E;
                    decap_table_columns[DBG_COL_SIP_E].data = &decap_entry->key.underlay_sip.addr.ipv6;
                    if (decap_entry->key.type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET) {
                        decap_table_columns[DBG_COL_SIP_MASK_E].type = PARAM_IPV6_E;
                        decap_table_columns[DBG_COL_SIP_MASK_E].data = &decap_entry->key.underlay_sip_mask.addr.ipv6;
                    } else {
                        decap_table_columns[DBG_COL_SIP_MASK_E].type = PARAM_STRING_E;
                        decap_table_columns[DBG_COL_SIP_MASK_E].data = empty_space;
                    }
                } else {
                    decap_table_columns[DBG_COL_SIP_E].type = PARAM_STRING_E;
                    decap_table_columns[DBG_COL_SIP_E].data = unknown_ip;
                    decap_table_columns[DBG_COL_SIP_MASK_E].type = PARAM_STRING_E;
                    decap_table_columns[DBG_COL_SIP_MASK_E].data = empty_space;
                }
            } else {
                decap_table_columns[DBG_COL_SIP_E].type = PARAM_STRING_E;
                decap_table_columns[DBG_COL_SIP_E].data = empty_space;
                decap_table_columns[DBG_COL_SIP_MASK_E].type = PARAM_STRING_E;
                decap_table_columns[DBG_COL_SIP_MASK_E].data = empty_space;
            }

            decap_table_columns[DBG_COL_VRID_E].data = &decap_entry->key.underlay_vrid;
            decap_table_columns[DBG_COL_ENTRY_ID_E].data = &decap_entry->decap_entry_id;
            decap_table_columns[DBG_COL_ACTION_E].data = sx_router_action_str(decap_entry->data.action);
            decap_table_columns[DBG_COL_TRAP_PRIO_E].data = SX_TRAP_PRIORITY_STR(decap_entry->data.trap_attr.prio);
            snprintf(tunnel_id_str, sizeof(tunnel_id_str), "0x%.8x", decap_entry->data.tunnel_id);
            decap_table_columns[DBG_COL_TUNNEL_ID_E].data = tunnel_id_str;
            decap_table_columns[DBG_COL_COUNTER_ID_E].data = &decap_entry->data.counter_id;
            decap_table_columns[DBG_COL_SPAN_SESSION_ID_E].data = &decap_entry->data.span_session_id;
            decap_table_columns[DBG_COL_SET_USER_TOKEN_ID_E].data = &decap_entry->data.set_user_token;
            decap_table_columns[DBG_COL_USER_TOKEN_DATA_ID_E].data = &decap_entry->data.user_token.user_token;
            decap_table_columns[DBG_COL_USER_TOKEN_MASK_ID_E].data = &decap_entry->data.user_token.mask;

            dbg_utils_pprinter_table_data_line_print(stream, decap_table_columns);

            map_item_p = cl_qmap_next(map_item_p);
        }
    }

    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = SX_STATUS_SUCCESS;
out:
    return M_UTILS_SX_LOG_EXIT(sx_status);
}

uint32_t decap_table_db_key_map_count_get(void)
{
    return cl_fmap_count(&(g_decap_table_db.key_map));
}

/*
 * return success if filter flag is false.
 * if any valid flag is true, return success only if the filter matches.
 * Note: If new filters params are added to the type, add if check below.
 */
static sx_status_t __decap_table_db_rule_filter_check(const sx_tunnel_decap_entry_filter_t *filter_p,
                                                      const sx_tunnel_decap_entry_key_t    *key_p,
                                                      const sx_tunnel_decap_entry_data_t   *data_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    boolean_t   filter_valid = FALSE;
    boolean_t   filter_by_tunnel_id_match = TRUE;
    boolean_t   filter_by_tunnel_type_match = TRUE;

    if (filter_p->filter_by_tunnel_id == SX_TUNNEL_KEY_FILTER_FIELD_VALID) {
        filter_valid = TRUE;
        if (filter_p->tunnel_id != data_p->tunnel_id) {
            filter_by_tunnel_id_match = FALSE;
            SX_LOG(SX_LOG_DEBUG, "[%s]filter tunnel_id = %x but data tunnel_id = %x. No match \n",
                   __func__, filter_p->tunnel_id, data_p->tunnel_id);
        }
    }

    if (filter_p->filter_by_tunnel_type == SX_TUNNEL_KEY_FILTER_FIELD_VALID) {
        filter_valid = TRUE;
        if (filter_p->tunnel_type != key_p->tunnel_type) {
            filter_by_tunnel_type_match = FALSE;
            SX_LOG(SX_LOG_DEBUG, "[%s]filter tunnel_type = %s but data tunnel_type = %s. No match \n",
                   __func__, sx_tunnel_type_str(filter_p->tunnel_type),
                   sx_tunnel_type_str(key_p->tunnel_type));
        }
    }

    if (filter_valid) {
        if (filter_by_tunnel_id_match && filter_by_tunnel_type_match) {
            status = SX_STATUS_SUCCESS;
        } else {
            status = SX_STATUS_ERROR;
        }
    } else {
        status = SX_STATUS_SUCCESS;
    }

    return status;
}

sx_status_t decap_table_db_iter_rule_list_get(const sx_tunnel_decap_entry_key_t    *key_p,
                                              const sx_tunnel_decap_entry_filter_t *filter_p,
                                              sx_tunnel_decap_entry_key_t          *rule_list_p,
                                              uint32_t                             *rule_cnt_p)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    cl_fmap_item_t       *map_item_p = NULL;
    const cl_fmap_item_t *map_end_p = NULL;
    decap_table_entry_t  *decap_entry_p = NULL;
    uint32_t              rules_found = 0;
    uint32_t              max_db_size = 0;
    uint32_t              tmp_rule_num = *rule_cnt_p;

    if (FALSE == g_db_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (filter_p == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("NULL pointers\n");
        goto out;
    }

    /* ensure count is within db limits */
    max_db_size = decap_table_db_key_map_count_get();
    if ((tmp_rule_num > max_db_size) || (tmp_rule_num == 0)) {
        tmp_rule_num = max_db_size;
    }

    /* Lets get the starting point.*/
    if (!key_p) {
        /*if Key is Null, we must start from the head */
        map_item_p = KEY_MAP_HEAD;
        SX_LOG(SX_LOG_DEBUG, "Start from Head of FMAP.\n");
    } else {
        /* get next avail key. If key doesn't exist fmap_get_next will return map->nil
         * which is what fmap_end also returns. This is compared at the beginning
         * of the while loop below and we will return count of 0 in this case */
        map_item_p = cl_fmap_get_next(&(g_decap_table_db.key_map), key_p);
        SX_LOG(SX_LOG_DEBUG, "Start db get from next valid item.\n");
    }

    /* loop until we hit the end or read the number of requested entries.*/
    map_end_p = KEY_MAP_END;
    while ((map_item_p != map_end_p) && (tmp_rule_num != rules_found)) {
        decap_entry_p = PARENT_STRUCT(map_item_p, decap_table_entry_t, key_map_item);

        if (SX_CHECK_PASS(__decap_table_db_rule_filter_check(filter_p,
                                                             &(decap_entry_p->key),
                                                             &(decap_entry_p->data)))) {
            if (*rule_cnt_p > 0) {
                SX_MEM_CPY_TYPE(&(rule_list_p[rules_found]),
                                &(decap_entry_p->key),
                                sx_tunnel_decap_entry_key_t);
            }

            SX_LOG(SX_LOG_DEBUG, "[%s]insert key to index = %d. \n", __func__, rules_found);
            SX_LOG(SX_LOG_DEBUG, " tunnel_type=%u, key type=%u, underlay_vrid=%u, "
                   "underlay_dip=%u, underlay_sip=%u\n",
                   decap_entry_p->key.tunnel_type, decap_entry_p->key.type,
                   decap_entry_p->key.underlay_vrid,
                   decap_entry_p->key.underlay_dip.addr.ipv4.s_addr,
                   decap_entry_p->key.underlay_sip.addr.ipv4.s_addr);

            rules_found++;
        }
        map_item_p = cl_fmap_get_next(&(g_decap_table_db.key_map), &(decap_entry_p->key));
    }

    *rule_cnt_p = rules_found;
    SX_LOG(SX_LOG_DEBUG, "total rules found = %d. \n", rules_found);

out:
    SX_LOG_EXIT();
    return sx_status;
}
