/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWD_DECAP_TABLE_H__
#define __HWD_DECAP_TABLE_H__

#include "bridge_lib/bridge_common.h"
#include <sx/sdk/sx_tunnel.h>
#include <sx/sdk/sx_status.h>
#include "tunnel/hwi/decap_table_impl.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/* set log level */
sx_status_t hwd_decap_table_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
/* Init decap table, init DB and ACL region */
sx_status_t hwd_decap_table_init(void);
/* Deinit decap table, destroy DB and ACL region */
sx_status_t hwd_decap_table_deinit(boolean_t force_deinit);
/* Add a decap entry to decap table */
sx_status_t hwd_decap_table_add_entry(const sx_tunnel_decap_entry_key_t * key,
                                      const sx_tunnel_decap_entry_data_t* data);
/* Edit an existing entry with new data */
sx_status_t hwd_decap_table_edit_entry(const sx_tunnel_decap_entry_key_t * key,
                                       const sx_tunnel_decap_entry_data_t* data);
/* Get data of an existing entry */
sx_status_t hwd_decap_table_get_entry(const sx_tunnel_decap_entry_key_t* key,
                                      sx_tunnel_decap_entry_data_t     * data);
/* Delete an existing entry */
sx_status_t hwd_decap_table_delete_entry(const sx_tunnel_decap_entry_key_t* key);
/* Bind acl */
sx_status_t hwd_decap_table_bind_acl(sx_port_log_id_t nve_port, sx_acl_id_t acl_group_id);
/* Unbind acl */
sx_status_t hwd_decap_table_unbind_acl(sx_port_log_id_t nve_port);
/* Dump the decap table */
sx_status_t hwd_decap_table_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);

/* Assign the decap table ops structure */
sx_status_t hwd_decap_table_assign_ops(hwi_decap_table_ops_t*);
/* Iter Get decap rules data */
sx_status_t hwd_decap_table_rule_iter_get(const sx_access_cmd_t                 cmd,
                                          const sx_tunnel_decap_entry_key_t     key,
                                          const sx_tunnel_decap_entry_filter_t *filter_p,
                                          sx_tunnel_decap_entry_key_t          *rule_list_p,
                                          uint32_t                             *rule_cnt_p);

#endif /* ifndef __HWD_DECAP_TABLE_H__ */
