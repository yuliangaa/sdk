/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <complib/cl_timer.h>
#include <sx/utils/sx_utils_status.h>
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/sx_mem.h"
#include "utils/sx_adviser.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>

#include "resource_manager/resource_manager_sdk_table.h"
#include "include/resource_manager/resource_manager.h"

#include "hwd_tunnel_reg.h"
#include "ethl3/common/router_utils.h"
#include "bridge_lib/bridge_common.h"
#include <ethl2/vlan.h>
#include <ethl2/fdb.h>
#include <ethl2/port_db.h>
#include <ethl2/fid_manager.h>
#include <ethl3/hwi/sdk_router/sdk_router_impl.h>
#include <flow_counter/flow_counter.h>
#include <sx/sxd/sxd_access_register.h>
#include <issu/issu.h>

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ TUNNEL

#define TUNNEL_HWD_INIT_CHECK(operation, err)                                             \
    if (FALSE == g_is_initialized) {                                                      \
        err = SX_STATUS_DB_NOT_INITIALIZED;                                               \
        SX_LOG_ERR("Failed to %s, tunnel HWD module is not initialized.\n", (operation)); \
        goto out;                                                                         \
    }

#define TUNNEL_LBF_MODE_PORT_TO_TUNNEL_CONVERT(port_lbf_mode)                                      \
    (((port_lbf_mode) == SX_LOOPBACK_FILTER_MODE_ENABLED) ? TUNNEL_TNPC_LB_TX_TUNNEL_PORT_FILTER : \
     TUNNEL_TNPC_LB_TX_TUNNEL_PORT_ALLOWED)

#define TUNNEL_RTDP_TABLE_ENTRY_SIZE          1
#define TUNNEL_TNPC_LB_TX_TUNNEL_PORT_FILTER  0  /* enable - packet will be dropped*/
#define TUNNEL_TNPC_LB_TX_TUNNEL_PORT_ALLOWED 1  /* disable - packet will pass*/
#define TUNNEL_TNPC_LB_TX_TUNNEL_PORT_DEFAULT TUNNEL_TNPC_LB_TX_TUNNEL_PORT_FILTER
#define TUNNEL_TTL_VAL_RSVD                   0
#define TUNNEL_RESERVED_TNGEE_ENTRIES_NUM     1

#define NVE_RESERVED_BITS_CHECK_ENABLE  (0)
#define NVE_RESERVED_BITS_CHECK_DISABLE (1)

typedef struct hwd_tunnel_internal_callbacks {
    sx_status_t (*hwd_tunnel_tnpc_defaults_write_pfn)(void);
    sx_status_t (*hwd_tunnel_sffp_defaults_write_pfn)(void);
    void (*hwd_tunnel_tnpc_dump_pfn)(dbg_dump_params_t *dbg_dump_params_p);
    sx_status_t (*hwd_tunnel_zeroed_reserved_tngee_create_pfn)(void);
    sx_status_t (*hwd_tunnel_zeroed_reserved_tngee_delete_pfn)(void);
    sx_status_t (*hwd_tunnel_nve_udp_sport_hash_and_fix_update_pfn)(const sx_tunnel_hash_data_t *hash_data_p,
                                                                    hwd_tngcr_t                 *tngcr_cfg_p);
    sx_status_t (*hwd_tunnel_nve_udp_sport_hash_and_fix_update_get_pfn)(const hwd_tngcr_t     *tngcr_cfg_p,
                                                                        sx_tunnel_hash_data_t *hash_data_p);
} hwd_tunnel_internal_callbacks_t;

/************************************************
 *  Global variables
 ***********************************************/
extern rm_sdk_table_resource_t sdk_table_resources_g[RM_SDK_TABLE_TYPE_NUMBER];

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t                       g_is_initialized = FALSE;
static kvd_linear_manager_handle_t     g_zeroed_reserved_tngee;
static kvd_linear_manager_index_t      g_zeroed_reserved_tngee_index;
static hwd_tunnel_global_config_t      g_global_config;
static hwd_tunnel_internal_callbacks_t g_hwd_tunnel_internal_callbacks;
static boolean_t                       g_trap_nve_options_is_set = FALSE;
static struct ku_hpkt_reg              g_trap_nve_options_hpkt;
static const char                    * nve_type_name_arr[] = {
    "VXLAN",
    "VXLAN GPE",
    "GENEVE",
    "NVGRE"
};

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __hwd_tunnel_zeroed_reserved_tngee_create();
static sx_status_t __hwd_tunnel_zeroed_reserved_tngee_delete();
sx_status_t __hwd_tunnel_tnpc_defaults_write();
static sx_status_t __hwd_tunnel_sffp_defaults_write(void);
static void __hwd_tunnel_tnpc_dump(dbg_dump_params_t *dbg_dump_params_p);
static sx_status_t __hwd_ipinip_tunnel_ttl_get_spc2(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                                    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                                    sx_tunnel_ttl_data_t        *ttl_data_p);
static sx_status_t __hwd_nve_tunnel_ttl_get_spc2(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                                 hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                                 sx_tunnel_ttl_data_t        *ttl_data_p);
static sx_status_t __hwd_tunnel_nve_udp_sport_hash_set(const sx_tunnel_hash_data_t *hash_data_p,
                                                       hwd_tngcr_t                 *tngcr_cfg_p);
static sx_status_t __hwd_tunnel_nve_udp_sport_hash_get(const hwd_tngcr_t     *tngcr_cfg_p,
                                                       sx_tunnel_hash_data_t *hash_data_p);
static sx_status_t __hwd_tunnel_nve_udp_sport_hash_and_fix_update(const sx_tunnel_hash_data_t *hash_data_p,
                                                                  hwd_tngcr_t                 *tngcr_cfg_p);
static sx_status_t __hwd_tunnel_nve_udp_sport_hash_and_fix_update_get(const hwd_tngcr_t     *tngcr_cfg_p,
                                                                      sx_tunnel_hash_data_t *hash_data_p);

static inline void __hwd_tunnel_attr_reserved_bits_unpack(const sx_tunnel_nve_reserved_bits_check_t *reserved_bits_p,
                                                          uint64_t                                   default_mask,
                                                          boolean_t                                 *dis_nve_opt_chk_p,
                                                          uint64_t                                  *hdr_bits_p);

/* Callbacks for SPC */
static hwd_tunnel_internal_callbacks_t g_hwd_tunnel_internal_callbacks_uvrid = {
    NULL, /* hwd_tunnel_tnpc_defaults_write_pfn */
    NULL, /* hwd_tunnel_sffp_defaults_write_pfn */
    NULL, /* hwd_tunnel_tnpc_dump_pfn */
    NULL, /* hwd_tunnel_zeroed_reserved_tngee_create_pfn */
    NULL, /* hwd_tunnel_zeroed_reserved_tngee_delete_pfn */
    __hwd_tunnel_nve_udp_sport_hash_set, /* hwd_tunnel_nve_udp_sport_hash_and_fix_update_pfn */
    __hwd_tunnel_nve_udp_sport_hash_get, /* hwd_tunnel_nve_udp_sport_hash_and_fix_update_get_pfn */
};
/* Callbacks for SPC 2 */
static hwd_tunnel_internal_callbacks_t g_hwd_tunnel_internal_callbacks_urif = {
    __hwd_tunnel_tnpc_defaults_write, /* hwd_tunnel_tnpc_defaults_write_pfn */
    __hwd_tunnel_sffp_defaults_write, /* hwd_tunnel_sffp_defaults_write_pfn */
    __hwd_tunnel_tnpc_dump, /* hwd_tunnel_tnpc_dump_pfn */
    __hwd_tunnel_zeroed_reserved_tngee_create, /* hwd_tunnel_zeroed_reserved_tngee_create_pfn */
    __hwd_tunnel_zeroed_reserved_tngee_delete, /* hwd_tunnel_zeroed_reserved_tngee_delete_pfn */
    __hwd_tunnel_nve_udp_sport_hash_and_fix_update, /* hwd_tunnel_nve_udp_sport_hash_and_fix_update_pfn */
    __hwd_tunnel_nve_udp_sport_hash_and_fix_update_get, /* hwd_tunnel_nve_udp_sport_hash_and_fix_update_get_pfn */
};


sx_status_t __hwd_tunnel_cos_global_attr_get(const hwd_tunnel_qos_tunnel_type_t tunnel_type,
                                             sx_tunnel_cos_data_t              *cos_data_p);
static sx_status_t __hwd_tunnel_nve_port_lbf_mode_get(const sx_port_log_id_t log_port,
                                                      uint8_t               *lbf_mode_p);
static void __hwd_dbg_dump_ecn_to_str(sx_cos_ecn_t         ecn,
                                      boolean_t            trap_en,
                                      sx_trap_attributes_t trap,
                                      char               * str,
                                      uint32_t             size)
{
    char tmp_ecn[32];
    char tmp_trap[32];

    switch (ecn) {
    case SX_COS_ECN_NON_ECT_E:
        strncpy(tmp_ecn, "ecn: NON_ECT(00) ", sizeof(tmp_ecn));
        break;

    case SX_COS_ECN_ECT1_E:
        strncpy(tmp_ecn, "ecn: ECT1(01) ", sizeof(tmp_ecn));
        break;

    case SX_COS_ECN_ECT0_E:
        strncpy(tmp_ecn, "ecn: ECT0(10) ", sizeof(tmp_ecn));
        break;

    case SX_COS_ECN_CE_E:
        strncpy(tmp_ecn, "ecn: CE(11) ", sizeof(tmp_ecn));
        break;

    default:
        strncpy(tmp_ecn, "ecn: Unknown ", sizeof(tmp_ecn));
        break;
    }

    if (trap_en) {
        if (trap.prio == SX_TRAP_PRIORITY_HIGH) {
            strncpy(tmp_trap, "trap: DROP", sizeof(tmp_trap));
        } else if (trap.prio == SX_TRAP_PRIORITY_LOW) {
            strncpy(tmp_trap, "trap: FORWARD", sizeof(tmp_trap));
        } else {
            strncpy(tmp_trap, "trap: UNKNOWN", sizeof(tmp_trap));
        }
    } else {
        strncpy(tmp_trap, "trap: DISABLE", sizeof(tmp_trap));
    }

    snprintf(str, size, "%s%s", tmp_ecn, tmp_trap);

    return;
}
static void __hwd_cos_dbg_dump(dbg_dump_params_t *dbg_dump_params_p, hwd_tunnel_qos_tunnel_type_t type, char *str)
{
    char                      ecn_type_str[32];
    char                      ecn_str[4][32];
    char                      header_str[128];
    uint32_t                  i = 0, j = 0;
    sx_tunnel_cos_data_t      encap_cos_data;
    sx_tunnel_cos_data_t      decap_cos_data;
    dbg_utils_table_columns_t tunnel_decap_cos_data_table[] = {
        { "DSCP value",  15, PARAM_UINT32_E, &decap_cos_data.dscp_value},
        { "Color",  15, PARAM_UINT8_E, &decap_cos_data.prio_color.color},
        { "Switch Priority",  20, PARAM_UINT8_E, &decap_cos_data.prio_color.priority},
        { "Switch Prio set",  20, PARAM_BOOL_E, &decap_cos_data.update_priority_color},
        { "DSCP Rewrite",  15, PARAM_UINT32_E, &decap_cos_data.dscp_rewrite},
        { "DSCP Action",  15, PARAM_UINT32_E, &decap_cos_data.dscp_action},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t tunnel_encap_cos_data_table[] = {
        { "DSCP value",  15, PARAM_UINT32_E, &encap_cos_data.dscp_value},
        { "Color",  15, PARAM_UINT8_E, &encap_cos_data.prio_color.color},
        { "Switch Priority",  20, PARAM_UINT8_E, &encap_cos_data.prio_color.priority},
        { "Switch Prio set",  20, PARAM_BOOL_E, &encap_cos_data.update_priority_color},
        { "DSCP Rewrite",  15, PARAM_UINT32_E, &encap_cos_data.dscp_rewrite},
        { "DSCP Action",  15, PARAM_UINT32_E, &encap_cos_data.dscp_action},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t tunnel_cos_ecn_data_table[] = {
        { "Inner   | Outer",  15, PARAM_STRING_E, ecn_type_str},
        { "NON ECT(00)",  32, PARAM_STRING_E, ecn_str[0]},
        { "ECT1(01)",     32, PARAM_STRING_E, ecn_str[1]},
        { "ECT0(10)",     32, PARAM_STRING_E, ecn_str[2]},
        { "CE(11)",       32, PARAM_STRING_E, ecn_str[3]},
        {NULL, 0, 0, NULL}
    };
    FILE                     *stream = dbg_dump_params_p->stream;

    SX_MEM_CLR(encap_cos_data);
    SX_MEM_CLR(decap_cos_data);
    SX_MEM_CLR(ecn_type_str);
    SX_LOG_ENTER();
    snprintf(header_str, sizeof(header_str), "HWD tunnel module CoS Data type %d %s", type, str);
    dbg_utils_pprinter_general_header_print(stream, header_str);

    dbg_utils_pprinter_secondary_header_print(stream, str, " CoS data");
    dbg_utils_pprinter_secondary_header_print(stream, "Decap");

    SX_MEM_CPY(decap_cos_data, g_global_config.cos_attr[type].decap_cos_data);

    dbg_utils_pprinter_table_headline_print(stream, tunnel_decap_cos_data_table);
    dbg_utils_pprinter_table_data_line_print(stream, tunnel_decap_cos_data_table);

    dbg_utils_pprinter_table_headline_print(stream, tunnel_cos_ecn_data_table);
    for (i = SX_COS_ECN_TYPE_MIN_E; i <= SX_COS_ECN_TYPE_MAX_E; ++i) {
        switch (i) {
        case SX_COS_ECN_NON_ECT_E:
            strncpy(ecn_type_str, "NON_ECT(00)", sizeof(ecn_type_str));
            break;

        case SX_COS_ECN_ECT1_E:
            strncpy(ecn_type_str, "ECT1(01)", sizeof(ecn_type_str));
            break;

        case SX_COS_ECN_ECT0_E:
            strncpy(ecn_type_str, "ECT0(10)", sizeof(ecn_type_str));
            break;

        case SX_COS_ECN_CE_E:
            strncpy(ecn_type_str, "CE(11)", sizeof(ecn_type_str));
            break;

        /* coverity[dead_error_begin] */
        default:
            strncpy(ecn_type_str, "Unknown", sizeof(ecn_type_str));
            break;
        }
        for (j = SX_COS_ECN_TYPE_MIN_E; j <= SX_COS_ECN_TYPE_MAX_E; ++j) {
            SX_MEM_CLR(ecn_str[j]);
            __hwd_dbg_dump_ecn_to_str(decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].egress_ecn,
                                      decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_enable,
                                      decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_attr,
                                      ecn_str[j], sizeof(ecn_str[j]));
        }
        dbg_utils_pprinter_table_data_line_print(stream, tunnel_cos_ecn_data_table);
    }


    dbg_utils_pprinter_secondary_header_print(stream, "Encap");
    SX_MEM_CPY(encap_cos_data, g_global_config.cos_attr[type].encap_cos_data);
    dbg_utils_pprinter_table_headline_print(stream, tunnel_encap_cos_data_table);
    dbg_utils_pprinter_table_data_line_print(stream, tunnel_encap_cos_data_table);

    strncpy(ecn_type_str, "Outer", sizeof(ecn_type_str));
    dbg_utils_pprinter_table_headline_print(stream, tunnel_cos_ecn_data_table);
    for (j = SX_COS_ECN_TYPE_MIN_E; j <= SX_COS_ECN_TYPE_MAX_E; ++j) {
        SX_MEM_CLR(ecn_str[j]);
        __hwd_dbg_dump_ecn_to_str(encap_cos_data.cos_ecn_params.ecn_encap.ecn_encap_map[j].egress_ecn,
                                  FALSE,
                                  decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[0][0].trap_attr,
                                  ecn_str[j], sizeof(ecn_str[j]));
    }
    dbg_utils_pprinter_table_data_line_print(stream, tunnel_cos_ecn_data_table);
}
static void __tunnel_debug_type_name_get(sxd_tunnel_nve_type_t type, char* name, int size)
{
    if (type < (sizeof(nve_type_name_arr) / sizeof(nve_type_name_arr[0]))) {
        strncpy(name, nve_type_name_arr[type], size);
    } else {
        strncpy(name, "UNKNOWN", size);
    }
}

static void __tunnel_debug_encap_ttl_mode_name_get(uint8_t tngcr_encap_ttl_mode, char* name, uint8_t size)
{
    switch ((sxd_tunnel_tngcr_ttlc_t)(tngcr_encap_ttl_mode)) {
    case SXD_TNGCR_TTLC_USE_CONFIG:
        snprintf(name, size, "use config [%2u]", tngcr_encap_ttl_mode);
        break;

    case SXD_TNGCR_TTLC_COPY_FROM_PKT:
        snprintf(name, size, "copy from packet [%2u]", tngcr_encap_ttl_mode);
        break;

    default:
        snprintf(name, size, "unknown [%2u]", tngcr_encap_ttl_mode);
        break;
    }
}
static void __tunnel_debug_decap_ttl_mode_name_get(uint8_t tngcr_decap_ttl_mode, char* name, uint8_t size)
{
    switch ((sxd_tunnel_tngcr_nve_decap_ttl_t)(tngcr_decap_ttl_mode)) {
    case SXD_TNGCR_NVE_DECAP_TTL_PRESERVE_E:
        snprintf(name, size, "Preserve [%2u]", tngcr_decap_ttl_mode);
        break;

    case SXD_TNGCR_NVE_DECAP_TTL_COPY_E:
        snprintf(name, size, "copy from underlay [%2u]", tngcr_decap_ttl_mode);
        break;

    case SXD_TNGCR_NVE_DECAP_TTL_MINIMUM_E:
        snprintf(name, size, "use minimum value [%2u]", tngcr_decap_ttl_mode);
        break;

    default:
        snprintf(name, size, "unknown [%2u]", tngcr_decap_ttl_mode);
        break;
    }
}
/*
 * Callback for KVDL manager.
 * Writes a new copy of RTDP block, and generate adviser TUNNEL_DECAP event.
 *
 * @param [in]     handle     - A handle to the block.
 * @param [in]     size       - block size.
 * @param [in]     offset     - unused.
 * @param [in]     old_index_p - rtdp block old index.
 * @param [in]     new_index  - rtdp block new index.
 */
static sx_status_t __kvd_linear_manager_decap_block_relocate_cb(kvd_linear_manager_handle_t       handle,
                                                                kvd_linear_manager_block_length_t size,
                                                                kvd_linear_manager_block_length_t offset,
                                                                const kvd_linear_manager_index_t* old_index_p,
                                                                kvd_linear_manager_index_t        new_index)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    hwd_rtdp_t        rtdp_entry;
    tunnel_decap_cb_t relocate_context;

    UNUSED_PARAM(size);
    UNUSED_PARAM(offset);

    SX_MEM_CLR(rtdp_entry);
    SX_MEM_CLR(relocate_context);

    SX_LOG_ENTER();
    SX_LOG_DBG("Relocate decap block: handler[0x%" PRIx64 "], index changed from %u to %d.\n",
               handle, *old_index_p, new_index);

    sx_status = hwd_rtdp_db_get(handle, &rtdp_entry);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get RTDP entry from RTDP DB, err = %s.\n", sx_status_str(sx_status));
    }

    rtdp_entry.ku_rtdp.tunnel_index = new_index;

    /* Write to RTDP */
    sx_status = hwd_tunnel_rtdp_reg_write(SXD_ACCESS_CMD_SET, &rtdp_entry.ku_rtdp);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    /* Update DB */
    sx_status = hwd_rtdp_db_update(handle, &rtdp_entry);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update RTDP entry in RTDB DB, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    /* Generate adviser event */
    sx_status = sdk_tunnel_db_tunnel_id_by_hw_decap_get(handle, &relocate_context.tunnel_id);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get tunnel id for decap handler 0x%" PRIx64 ", err = %s.\n",
                   handle, sx_status_str(sx_status));
        goto out;
    }

    relocate_context.old_index = *old_index_p;
    relocate_context.new_index = new_index;
    sx_status = adviser_process_event(ADVISER_EVENT_POST_TUNNEL_DECAP_CHANGE_E, &relocate_context);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Could not process adviser event '%s'.\n",
                   ADVISER_EVENT_STR(ADVISER_EVENT_POST_TUNNEL_DECAP_CHANGE_E));
    }

    SX_LOG_DBG("Relocated decap block successfully\n");
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_create_decap_entry(const sx_tunnel_attribute_t  *tunnel_attr_p,
                                               hwi_tunnel_hw_decap_handle_t *decap_handle_p,
                                               hwd_rtdp_t                   *hwd_rtdp_p)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_status_t                  rb_status = SX_STATUS_SUCCESS;
    uint32_t                     size = TUNNEL_RTDP_TABLE_ENTRY_SIZE;
    boolean_t                    rm_entry_added = FALSE;
    kvd_linear_manager_index_t   rtdp_index = 0;
    hwi_tunnel_hw_decap_handle_t rtdp_handle = SDK_TUNNEL_INVALID_DECAP_HWD_HDL;
    sx_router_interface_t        orif_id = 0;
    sx_router_interface_t        urif_id = 0;
    hwd_rif_id_t                 overlay_rif = 0;
    hwd_rif_id_t                 underlay_rif = 0;

    *decap_handle_p = SDK_TUNNEL_INVALID_DECAP_HWD_HDL;
    SX_MEM_CLR_P(hwd_rtdp_p);

    SX_LOG_ENTER();

    sx_status = kvd_linear_manager_block_add(KVD_LINEAR_MANAGER_USER_TUNNEL_DECAP_E, size, FALSE, &rtdp_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        if (sx_status == SX_STATUS_NO_RESOURCES) {
            SX_LOG_ERR("Tried to allocate a new block but got no resources from KVD.\n");
            goto out;
        } else {
            SX_LOG_ERR("Failed to add RTDP to KVD, err = %s\n", sx_status_str(sx_status));
            goto out;
        }
    }
    SX_LOG_DBG("KVD block was added kvd_handle [0x%" PRIx64 "] \n", rtdp_handle);

    sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E, SX_ACCESS_CMD_ADD, size, NULL);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to add RM entry for tunnel RTDP.\n");
        goto out;
    }
    rm_entry_added = TRUE;

    sx_status = kvd_linear_manager_handle_lock(rtdp_handle, &rtdp_index, &size);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to lock kvd block 0x%" PRIx64 ", err = %s.\n", rtdp_handle, sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    SX_LOG_DBG("KVDL index of new RTDP block is [0x%" PRIx64 "]\n", rtdp_handle);

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        orif_id = tunnel_attr_p->attributes.ipinip_p2p.overlay_rif;
        urif_id = tunnel_attr_p->attributes.ipinip_p2p.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        orif_id = tunnel_attr_p->attributes.ipinip_p2p_gre.overlay_rif;
        urif_id = tunnel_attr_p->attributes.ipinip_p2p_gre.underlay_rif;
        break;

    /* NVE Tunnels */
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        urif_id = tunnel_attr_p->attributes.vxlan.decap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        urif_id = tunnel_attr_p->attributes.vxlan_gpe.decap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        urif_id = tunnel_attr_p->attributes.geneve.decap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        urif_id = tunnel_attr_p->attributes.nvgre.decap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        urif_id = tunnel_attr_p->attributes.l2_flex.decap.underlay_rif;
        break;
    }

    if (SX_CHECK_MAX(tunnel_attr_p->type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
        sx_status = hwd_rif_hw_id_get(orif_id, &overlay_rif);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get RIF %u HW ID, err = [%s] \n",
                       orif_id, sx_status_str(sx_status));
            goto out;
        }
    }

    sx_status = hwd_rif_hw_id_get(urif_id, &underlay_rif);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get RIF %u HW ID, err = [%s] \n",
                   urif_id, sx_status_str(sx_status));
        goto out;
    }

    /* Prepare RTDP */
    sx_status = hwd_tunnel_rtdp_prepare(tunnel_attr_p, overlay_rif, underlay_rif, rtdp_index, hwd_rtdp_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    /* Write to RTDP */
    sx_status = hwd_tunnel_rtdp_reg_write(SXD_ACCESS_CMD_ADD, &(hwd_rtdp_p->ku_rtdp));
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    *decap_handle_p = rtdp_handle;
    SX_LOG_DBG("New decap block created successfully\n");

out:
    if (rtdp_handle != SDK_TUNNEL_INVALID_DECAP_HWD_HDL) {
        rb_status = kvd_linear_manager_handle_release(rtdp_handle);
        if (rb_status) {
            SX_LOG_ERR("Failed to release kvd block 0x%" PRIx64 ", err = %s.\n", rtdp_handle,
                       sx_status_str(rb_status));
        }
    }

    if (SX_CHECK_FAIL(sx_status)) {
        if (rm_entry_added) {
            rb_status = rm_entries_set(RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E, SX_ACCESS_CMD_DELETE, size, NULL);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to roll back RM add entry for tunnel RTDP, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }
        if (rtdp_handle != SDK_TUNNEL_INVALID_DECAP_HWD_HDL) {
            rb_status = kvd_linear_manager_block_delete(rtdp_handle, FALSE);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to delete KVD block 0x%" PRIx64 ", err = %s.\n", rtdp_handle,
                           sx_status_str(rb_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_remove_decap_entry(hwi_tunnel_hw_decap_handle_t decap_handle)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    sx_status_t rb_status = SX_STATUS_SUCCESS;
    boolean_t   rm_deleted = FALSE;

    SX_LOG_ENTER();
    SX_LOG_DBG("Remove decap entry for handle [0x%" PRIx64 "]\n", decap_handle);

    sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E, SX_ACCESS_CMD_DELETE,
                               TUNNEL_RTDP_TABLE_ENTRY_SIZE, NULL);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to delete RM entry for tunnel RTDP, err = %s.\n",
                   sx_status_str(sx_status));
        goto out;
    }
    rm_deleted = TRUE;

    sx_status = kvd_linear_manager_block_delete(decap_handle, FALSE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to release kvd block 0x%" PRIx64 ", err = %s.\n",
                   decap_handle, sx_status_str(sx_status));
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (rm_deleted) {
            rb_status = rm_entries_set(RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E, SX_ACCESS_CMD_ADD, 1, NULL);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to roll back deletion of RM entry for tunnel RTDP, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_create_encap_entry(const sx_tunnel_attribute_t  *tunnel_attr_p,
                                               hwi_tunnel_hw_encap_handle_t *encap_handle_p,
                                               hwd_tunnel_encap_data_t      *encap_data_p)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    sx_router_interface_t rif_id = 0;

    SX_LOG_ENTER();

    SX_LOG_DBG("Create new encap entry for tunnel of type[%s]\n", sx_tunnel_type_str(tunnel_attr_p->type));
    SX_MEM_CLR_P(encap_data_p);
    *encap_handle_p = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;

    encap_data_p->type = tunnel_attr_p->type;
    if (SX_CHECK_MAX(encap_data_p->type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
        switch (encap_data_p->type) {
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
            rif_id = tunnel_attr_p->attributes.ipinip_p2p.overlay_rif;
            break;

        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
        case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
            rif_id = tunnel_attr_p->attributes.ipinip_p2p_gre.overlay_rif;
            break;

        default:
            /* Something went wrong - never should happen */
            sx_status = SX_STATUS_ERROR;
            SX_LOG_ERR("Failed to parse RIF ID from Tunnel IPinIP attributes.\n");
            goto out;
        }

        sx_status = hwd_rif_hw_id_get(rif_id, &encap_data_p->encap_attr.rif_id);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get RIF %u HW ID in hwd_tunnel_create, err = [%s] \n",
                       rif_id, sx_status_str(sx_status));
            goto out;
        }
    }

    sx_status = hwd_encap_db_create(encap_handle_p, encap_data_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to create encap handle in HW DB, err = %s.\n", sx_status_str(sx_status));
    }

    SX_LOG_DBG("Encap entry created successfully\n");

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_tunnel_attr_prepare(const sx_tunnel_attribute_t      *tunnel_attr_p,
                                             sx_tunnel_nve_encap_attributes_t *nve_encap_p,
                                             hwd_rif_id_t                     *hwd_urif_id_p,
                                             sxd_tunnel_nve_type_t            *nve_type_p,
                                             boolean_t                        *hwd_learn_set_p,
                                             uint8_t                          *et_vlan_p,
                                             uint8_t                          *lbf_mode_p,
                                             sx_port_log_id_t                 *log_port,
                                             boolean_t                        *dis_nve_opt_chk_p,
                                             uint64_t                         *hdr_bits_p);


/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t hwd_tunnel_urif_internal_callbacks_register()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = hwd_tunnel_reg_urif_internal_callbacks_register();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register HWD tunnel ops, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    g_hwd_tunnel_internal_callbacks = g_hwd_tunnel_internal_callbacks_urif;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_urif_internal_callbacks_register_spectrum4()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = hwd_tunnel_reg_urif_internal_callbacks_register_spectrum4();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register HWD tunnel ops, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    g_hwd_tunnel_internal_callbacks = g_hwd_tunnel_internal_callbacks_urif;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_uvrid_internal_callbacks_register()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = hwd_tunnel_reg_uvrid_internal_callbacks_register();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register HWD tunnel ops, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    g_hwd_tunnel_internal_callbacks = g_hwd_tunnel_internal_callbacks_uvrid;

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __hwd_tunnel_cos_init()
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    uint32_t                     i = 0, j = 0;
    hwd_tunnel_qos_tunnel_type_t type_index = SX_TUNNEL_QOS_TUNNEL_TYPE_MIN;

    SX_LOG_ENTER();

    /* CoS encap init attributes */
    for (type_index = SX_TUNNEL_QOS_TUNNEL_TYPE_MIN; type_index <= SX_TUNNEL_QOS_TUNNEL_TYPE_MAX; ++type_index) {
        g_global_config.cos_attr[type_index].encap_cos_data.dscp_action = SX_COS_DSCP_ACTION_COPY_E;
        g_global_config.cos_attr[type_index].encap_cos_data.dscp_rewrite = SX_COS_DSCP_REWRITE_PRESERVE_E;
        g_global_config.cos_attr[type_index].encap_cos_data.dscp_value = 0;
        g_global_config.cos_attr[type_index].encap_cos_data.param_type = SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E;
        g_global_config.cos_attr[type_index].encap_cos_data.update_priority_color = FALSE;
        g_global_config.cos_attr[type_index].encap_cos_data.prio_color.color = 0;
        g_global_config.cos_attr[type_index].encap_cos_data.prio_color.priority = 0;

        for (i = SX_COS_ECN_TYPE_MIN_E; i <= SX_COS_ECN_TYPE_MAX_E; ++i) {
            g_global_config.cos_attr[type_index].encap_cos_data.cos_ecn_params.ecn_encap.ecn_encap_map[i].valid = TRUE;
            g_global_config.cos_attr[type_index].encap_cos_data.cos_ecn_params.ecn_encap.ecn_encap_map[i].egress_ecn =
                i;
        }

        /* CoS decap init attributes */
        g_global_config.cos_attr[type_index].decap_cos_data.dscp_action = SX_COS_DSCP_ACTION_COPY_E;
        g_global_config.cos_attr[type_index].decap_cos_data.dscp_rewrite = SX_COS_DSCP_REWRITE_PRESERVE_E;
        g_global_config.cos_attr[type_index].decap_cos_data.dscp_value = 0;
        g_global_config.cos_attr[type_index].decap_cos_data.param_type = SX_TUNNEL_COS_PARAM_TYPE_DECAP_E;
        g_global_config.cos_attr[type_index].decap_cos_data.update_priority_color = FALSE;
        g_global_config.cos_attr[type_index].decap_cos_data.prio_color.color = 0;
        g_global_config.cos_attr[type_index].decap_cos_data.prio_color.priority = 0;

        /* init ecn_decap_array */
        for (i = SX_COS_ECN_TYPE_MIN_E; i <= SX_COS_ECN_TYPE_MAX_E; ++i) {
            for (j = SX_COS_ECN_TYPE_MIN_E; j <= SX_COS_ECN_TYPE_MAX_E; ++j) {
                g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].valid
                    = TRUE;
                g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].
                egress_ecn = i;
                g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].
                trap_enable = FALSE;
                g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].
                trap_attr.prio = 0;
            }
        }

        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_NON_ECT_E
        ][SX_COS_ECN_ECT0_E].trap_enable = TRUE;
        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_NON_ECT_E
        ][SX_COS_ECN_ECT0_E].trap_attr.prio = SX_TRAP_PRIORITY_LOW;
        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_NON_ECT_E
        ][SX_COS_ECN_ECT1_E].trap_enable = TRUE;
        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_NON_ECT_E
        ][SX_COS_ECN_ECT1_E].trap_attr.prio = SX_TRAP_PRIORITY_LOW;
        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_NON_ECT_E
        ][SX_COS_ECN_CE_E].trap_enable = TRUE;
        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_NON_ECT_E
        ][SX_COS_ECN_CE_E].trap_attr.prio = SX_TRAP_PRIORITY_HIGH;

        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_ECT0_E][
            SX_COS_ECN_ECT1_E].egress_ecn = SX_COS_ECN_ECT1_E;
        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_ECT0_E][
            SX_COS_ECN_CE_E].egress_ecn = SX_COS_ECN_CE_E;

        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_ECT1_E][
            SX_COS_ECN_ECT0_E].trap_enable = TRUE;
        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_ECT1_E][
            SX_COS_ECN_ECT0_E].trap_attr.prio = SX_TRAP_PRIORITY_LOW;
        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_ECT1_E][
            SX_COS_ECN_CE_E].egress_ecn = SX_COS_ECN_CE_E;

        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_CE_E][
            SX_COS_ECN_ECT1_E].trap_enable = TRUE;
        g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[SX_COS_ECN_CE_E][
            SX_COS_ECN_ECT1_E].trap_attr.prio = SX_TRAP_PRIORITY_LOW;
    }

    /* the final ecn decap array is filled according to this values
     * (this compound literal will not assign the values to the array this is only for clarification)
     *
     *  g_global_config.cos_attr[type_index].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_array = (sx_tunnel_cos_ecn_decap_data_t [4][4]){
     *   {
     *     Non-ECT
     *       {TRUE, SX_COS_ECN_NON_ECT_E, FALSE, 0,}, {TRUE, SX_COS_ECN_NON_ECT_E, TRUE, SX_TRAP_PRIORITY_LOW},
     *       {TRUE, SX_COS_ECN_NON_ECT_E, TRUE, SX_TRAP_PRIORITY_LOW}, {TRUE, SX_COS_ECN_NON_ECT_E, TRUE, SX_TRAP_PRIORITY_HIGH}
     *   },
     *   {
     *     ECT0
     *       {TRUE, SX_COS_ECN_ECT0_E, FALSE, 0}, {TRUE, SX_COS_ECN_ECT0_E, FALSE, 0},
     *       {TRUE, SX_COS_ECN_ECT1_E, FALSE, 0}, {TRUE, SX_COS_ECN_CE_E, FALSE, 0}
     *   },
     *   {
     *     ECT1
     *       {TRUE, SX_COS_ECN_ECT1_E, FALSE, 0}, {TRUE, SX_COS_ECN_ECT1_E, TRUE, SX_TRAP_PRIORITY_LOW},
     *       {TRUE, SX_COS_ECN_ECT1_E, FALSE, 0}, {TRUE, SX_COS_ECN_CE_E, FALSE, 0}
     *   },
     *   {
     *     CE
     *       {TRUE, SX_COS_ECN_CE_E, FALSE, 0}, {TRUE, SX_COS_ECN_CE_E, FALSE, 0},
     *       {TRUE, SX_COS_ECN_CE_E, TRUE, SX_TRAP_PRIORITY_LOW}, {TRUE, SX_COS_ECN_CE_E, FALSE, 0}
     *   }
     *  };*/

    SX_LOG_EXIT();
    return err;
}
sx_status_t hwd_tunnel_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    hwd_tunnel_db_log_verbosity_level_set(verbosity_level);
    hwd_tunnel_reg_log_verbosity_level_set(verbosity_level);

    return status;
}

sx_status_t hwd_tunnel_init(sdk_tunnel_init_params_t *tunnel_init_params_p)
{
    sx_status_t                      sx_status = SX_STATUS_SUCCESS;
    sx_status_t                      rb_status = SX_STATUS_SUCCESS;
    boolean_t                        kvd_initialized = FALSE;
    boolean_t                        db_initialized = FALSE;
    boolean_t                        rm_rtdp_initialized = FALSE;
    boolean_t                        rm_vni_initialized = FALSE;
    kvd_linear_manager_user_params_t kvd_params;

    KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_ITERATORS;

    SX_MEM_CLR(kvd_params);

    SX_LOG_ENTER();
    SX_LOG(SX_LOG_DEBUG, "Init HWD tunnel module\n");

    if (TRUE == g_is_initialized) {
        sx_status = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Failed to init HWD tunnel module, module is already initialized.\n");
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(tunnel_init_params_p,
                                                      "tunnel_init_params_p"))) {
        goto out;
    }

    sx_status = hwd_tunnel_db_init(rm_resource_global.tunnel_ipinip_num_max +
                                   rm_resource_global.tunnel_nve_num_max +
                                   rm_resource_global.tunnel_l2_flex_num_max);

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to initialize tunnel HWD DB , err = %s\n", sx_status_str(sx_status));
        goto out;
    }
    db_initialized = TRUE;

    sx_status = __hwd_tunnel_cos_init();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to to init CoS decap/encap attr tables hwd, err = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    kvd_params.block_type = LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E;
    kvd_params.block_relocate = __kvd_linear_manager_decap_block_relocate_cb;
    KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_INIT(kvd_params);

    sx_status = kvd_linear_manager_init_user(KVD_LINEAR_MANAGER_USER_TUNNEL_DECAP_E, kvd_params);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to initialize user for KVD linear manager, err = %s\n", sx_status_str(sx_status));
        goto out;
    }
    kvd_initialized = TRUE;

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E].is_initialized = TRUE;
    sx_status = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to initialize RM for TUNNEL_RTDP resource type: %s\n", sx_status_str(sx_status));
        goto out;
    }
    rm_rtdp_initialized = TRUE;

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_VNI_E].is_initialized = TRUE;
    sx_status = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_VNI_E);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to initialize RM for VNI resource type: %s\n", sx_status_str(sx_status));
        goto out;
    }
    rm_vni_initialized = TRUE;

    SX_MEM_CPY(g_global_config.general_params, tunnel_init_params_p->general_param);
    sx_status = hwd_tunnel_default_registers_write(&g_global_config);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to initialize tunnel registers with defaults.\n");
        goto out;
    }

    if (g_hwd_tunnel_internal_callbacks.hwd_tunnel_tnpc_defaults_write_pfn != NULL) {
        sx_status = g_hwd_tunnel_internal_callbacks.hwd_tunnel_tnpc_defaults_write_pfn();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to initialize tunnel registers with defaults.\n");
            goto out;
        }
    }

    if (g_hwd_tunnel_internal_callbacks.hwd_tunnel_sffp_defaults_write_pfn != NULL) {
        sx_status = g_hwd_tunnel_internal_callbacks.hwd_tunnel_sffp_defaults_write_pfn();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to initialize tunnel flooding profile with defaults.\n");
            goto out;
        }
    }

    if (g_hwd_tunnel_internal_callbacks.hwd_tunnel_zeroed_reserved_tngee_create_pfn != NULL) {
        sx_status = g_hwd_tunnel_internal_callbacks.hwd_tunnel_zeroed_reserved_tngee_create_pfn();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to create reserved TNGEE entry.\n");
            goto out;
        }
    }

    g_is_initialized = TRUE;
    SX_LOG_DBG("Tunnel HWD Module initialized successfully.\n");

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (rm_vni_initialized) {
            rb_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_VNI_E, TRUE);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to roll back initialization of RM for VNI resource: %s\n",
                           sx_status_str(rb_status));
            }
        }
        if (rm_rtdp_initialized) {
            rb_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E, TRUE);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to roll back initialization of RM for TUNNEL_RTDP resource: %s\n",
                           sx_status_str(rb_status));
            }
        }
        if (kvd_initialized) {
            rb_status = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_TUNNEL_DECAP_E);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to de initialize tunnel decap user in KVD linear manager, err = %s\n",
                           sx_status_str(rb_status));
            }
        }
        if (db_initialized) {
            rb_status = hwd_tunnel_db_deinit(FALSE);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to de initialize tunnel HWD DB, err = %s\n",
                           sx_status_str(rb_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_deinit(boolean_t is_forced)
{
    sx_status_t                      sx_status = SX_STATUS_SUCCESS;
    sx_status_t                      rb_status = SX_STATUS_SUCCESS;
    boolean_t                        kvd_initialized = TRUE;
    boolean_t                        db_initialized = TRUE;
    uint32_t                         decap_entry_num = 0;
    kvd_linear_manager_user_params_t kvd_params;
    uint32_t                         vni_num = 0;
    uint32_t                         rtdp_num = 0;

    KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_ITERATORS;

    SX_MEM_CLR(kvd_params);

    SX_LOG_ENTER();
    SX_LOG(SX_LOG_DEBUG, "De init tunnel HWD module, is_forced[%d]\n", is_forced);

    if (FALSE == g_is_initialized) {
        if (FALSE == is_forced) {
            sx_status = SX_STATUS_DB_NOT_INITIALIZED;
            SX_LOG_ERR("Failed to de init tunnel HWD module, module is not initialized.\n");
        }
        goto out;
    }

    sx_status = hwd_rtdp_db_total_rtdp_get(&decap_entry_num);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get size of rtdp HW DB, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = hwd_tunnel_db_deinit(is_forced);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to de init tunnel HWD DB, err = %s\n", sx_status_str(sx_status));
        goto out;
    }
    db_initialized = FALSE;

    if (decap_entry_num > 0) {
        sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E, SX_ACCESS_CMD_DELETE,
                                   decap_entry_num, NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to delete RM entries for tunnel RTDP DB, err = %s.\n",
                       sx_status_str(sx_status));
        }
    }

    sx_status = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_TUNNEL_DECAP_E);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to de-initialize user for KVD linear manager, err = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }
    kvd_initialized = FALSE;

    vni_num =
        sdk_table_resources_g[RM_SDK_TABLE_TYPE_VNI_E].table_allocated_size;

    if (vni_num > 0) {
        sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_VNI_E,
                                   SX_ACCESS_CMD_DELETE, vni_num, NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to delete %u VNI entries from RM, err = [%s]\n",
                       vni_num, sx_status_str(sx_status));
            goto out;
        }
    }

    sx_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_VNI_E, is_forced);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to de initialize of RM for VNI resource: %s\n",
                   sx_status_str(sx_status));
    }
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_VNI_E].is_initialized = FALSE;

    rtdp_num = sdk_table_resources_g[RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E].table_allocated_size;
    if (rtdp_num > 0) {
        sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E,
                                   SX_ACCESS_CMD_DELETE, rtdp_num, NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to delete %u RTDP entries from RM, err = [%s]\n",
                       rtdp_num, sx_status_str(sx_status));
            goto out;
        }
    }

    sx_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E, is_forced);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to de initialize of RM for TUNNEL_RTDP resource: %s\n",
                   sx_status_str(sx_status));
    }
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E].is_initialized = FALSE;

    sx_status = hwd_tunnel_deinit_registers(&g_global_config);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to de init tunnel registers, err = %s\n", sx_status_str(sx_status));
        /* No need to do rollback and return error in this case */
        sx_status = SX_STATUS_SUCCESS;
    }

    if (g_hwd_tunnel_internal_callbacks.hwd_tunnel_tnpc_defaults_write_pfn != NULL) {
        sx_status = g_hwd_tunnel_internal_callbacks.hwd_tunnel_tnpc_defaults_write_pfn();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to de init TNPC with defaults.\n");
            /* No need to do rollback and return error in this case */
            sx_status = SX_STATUS_SUCCESS;
        }
    }

    if (g_hwd_tunnel_internal_callbacks.hwd_tunnel_zeroed_reserved_tngee_delete_pfn != NULL) {
        sx_status = g_hwd_tunnel_internal_callbacks.hwd_tunnel_zeroed_reserved_tngee_delete_pfn();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to delete reserved TNGEE entry.\n");
            goto out;
        }
    }

    g_is_initialized = FALSE;
    SX_MEM_CLR(g_global_config);
    SX_LOG_DBG("Tunnel HWD module de-initialized successfully.\n");

out:
    if (SX_CHECK_FAIL(sx_status) && (!is_forced)) {
        if (!kvd_initialized) {
            kvd_params.block_type = LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E;
            kvd_params.block_relocate = __kvd_linear_manager_decap_block_relocate_cb;
            KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_INIT(kvd_params);

            rb_status = kvd_linear_manager_init_user(KVD_LINEAR_MANAGER_USER_TUNNEL_DECAP_E, kvd_params);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to initialize user for KVD linear manager, err = %s\n", sx_status_str(rb_status));
            }
        }
        if (!db_initialized) {
            rb_status = hwd_tunnel_db_init(rm_resource_global.tunnel_ipinip_num_max +
                                           rm_resource_global.tunnel_nve_num_max);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to roll back de init of tunnel HWD DB , err = %s\n", sx_status_str(rb_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_et_vlan_index_get(sx_vlan_tag_mode_t tag_mode, uint8_t* et_vlan_index_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (tag_mode == SX_VLAN_TAG_MODE_802_1AD_E) {
        *et_vlan_index_p = 1;
    } else {
        *et_vlan_index_p = 0;
    }

    return sx_status;
}

static inline sx_status_t __hwd_tunnel_nve_options_trap_impl_set(
    const sx_tunnel_nve_reserved_bits_check_t *reserved_bits_check_p)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    struct ku_hccr_reg ku_hccr;

    SX_MEM_CLR(ku_hccr);

    if (reserved_bits_check_p->mode == SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
        ku_hccr.use_nve_opt_chk = 1;
        sx_status = hwd_tunnel_hccr_reg_write(&ku_hccr);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update HCCR register, error = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        if (g_trap_nve_options_is_set != FALSE) {
            sx_status = hwd_tunnel_hpkt_reg_write(&g_trap_nve_options_hpkt);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to update HPKT register, error = %s.\n", sx_status_str(sx_status));
                goto out;
            }
        }
    } else {
        ku_hccr.use_nve_opt_chk = 0;
        sx_status = hwd_tunnel_hccr_reg_write(&ku_hccr);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update HCCR register, error = %s.\n", sx_status_str(sx_status));
            goto out;
        }
    }

out:
    return sx_status;
}

static sx_status_t __hwd_tunnel_nve_options_trap_set(const sx_tunnel_attribute_t *tunnel_attr_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        sx_status = __hwd_tunnel_nve_options_trap_impl_set(&tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update HCCR register for a VXLAN tunnel, error = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        sx_status = __hwd_tunnel_nve_options_trap_impl_set(
            &tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update HCCR register for a VXLAN GPE tunnel, error = %s.\n",
                       sx_status_str(sx_status));
            goto out;
        }

        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        sx_status =
            __hwd_tunnel_nve_options_trap_impl_set(&tunnel_attr_p->attributes.geneve.decap.reserved_bits_check);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update HCCR register for a GENEVE tunnel, error = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        sx_status = __hwd_tunnel_nve_options_trap_impl_set(&tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update HCCR register for a NVGRE tunnel, error = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        break;

    default:
        break;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

void hwd_tunnel_trap_nve_options_set(const struct ku_hpkt_reg *nve_options_hpkt_p)
{
    SX_LOG_ENTER();

    SX_MEM_CPY_P(&g_trap_nve_options_hpkt, nve_options_hpkt_p);
    g_trap_nve_options_is_set = TRUE;

    SX_LOG_EXIT();
}

sx_status_t hwd_tunnel_create(const sx_tunnel_attribute_t  *tunnel_attr_p,
                              hwi_tunnel_hw_encap_handle_t *tunnel_encap_handle_p,
                              hwi_tunnel_hw_decap_handle_t *tunnel_decap_handle_p)
{
    sx_status_t                      sx_status = SX_STATUS_SUCCESS;
    sx_status_t                      rb_status = SX_STATUS_SUCCESS;
    hwd_rif_id_t                     hw_underlay_rif_id;
    hwd_tunnel_encap_data_t          encap_data;
    hwd_rtdp_t                       rtdp_entry;
    sx_tunnel_nve_encap_attributes_t nve_encap;
    sxd_tunnel_nve_type_t            nve_type = 0;
    hwi_tunnel_hw_encap_handle_t     new_encap_handle = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;
    hwi_tunnel_hw_decap_handle_t     new_decap_handle = SDK_TUNNEL_INVALID_DECAP_HWD_HDL;
    boolean_t                        is_updated_tngcr = FALSE;
    boolean_t                        is_create_decap = FALSE;
    boolean_t                        is_create_encap = FALSE;
    boolean_t                        hw_learn_set = FALSE;
    uint8_t                          et_vlan = 0, rb_et_vlan = 0;
    uint8_t                          lbf_mode = TUNNEL_TNPC_LB_TX_TUNNEL_PORT_DEFAULT;
    sx_port_log_id_t                 log_port = 0;
    boolean_t                        dis_nve_opt_chk = FALSE;
    uint64_t                         hdr_bits = 0;

    SX_MEM_CLR(encap_data);
    SX_MEM_CLR(rtdp_entry);
    SX_MEM_CLR(hw_underlay_rif_id);
    SX_MEM_CLR(nve_encap);

    SX_LOG_ENTER();
    SX_LOG(SX_LOG_DEBUG, "Create HWD Tunnel.\n");

    if (utils_check_pointer(tunnel_attr_p, "tunnel_attr_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(tunnel_encap_handle_p, "tunnel_encap_handle_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(tunnel_decap_handle_p, "tunnel_decap_handle_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    TUNNEL_HWD_INIT_CHECK("create tunnel", sx_status);

    sx_status = __hwd_tunnel_attr_prepare(tunnel_attr_p,
                                          &nve_encap,
                                          &hw_underlay_rif_id,
                                          &nve_type,
                                          &hw_learn_set,
                                          &et_vlan,
                                          &lbf_mode,
                                          &log_port,
                                          &dis_nve_opt_chk,
                                          &hdr_bits);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to parse tunnel attributes, err = %s.\n",
                   sx_status_str(sx_status));
        goto out;
    }

    rb_et_vlan = g_global_config.tngcr_config.ku_tngcr.et_vlan;


    if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, tunnel_attr_p->type, SX_TUNNEL_TYPE_NVE_MAX)) {
        /* update tngcr */
        sx_status = hwd_tunnel_update_tngcr(&g_global_config,
                                            ((tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_ENCAP) ? &nve_encap : NULL),
                                            0,
                                            /* RESERVED */
                                            nve_type,
                                            TRUE,
                                            hw_learn_set,
                                            et_vlan,
                                            dis_nve_opt_chk,
                                            hdr_bits);
        if (sx_status == SX_STATUS_SUCCESS) {
            is_updated_tngcr = TRUE;
        } else {
            SX_LOG_ERR("Failed to create tunnel on HW, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        sx_status = __hwd_tunnel_nve_options_trap_set(tunnel_attr_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to enable extra tunnel traps, error = %s.\n", sx_status_str(sx_status));
            goto out;
        }
    }

    if (tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_DECAP) {
        sx_status = __tunnel_create_decap_entry(tunnel_attr_p, &new_decap_handle, &rtdp_entry);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to create tunnel decap entry on HW, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        sx_status = hwd_rtdp_db_add(new_decap_handle, &rtdp_entry);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to add tunnel decap entry to RTDP DB, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }
        is_create_decap = TRUE;
    }

    sx_status = __tunnel_create_encap_entry(tunnel_attr_p, &new_encap_handle, &encap_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to add tunnel encap entry on HW, err = %s.\n",
                   sx_status_str(sx_status));
        goto out;
    }
    is_create_encap = TRUE;


    *tunnel_encap_handle_p = new_encap_handle;
    *tunnel_decap_handle_p = new_decap_handle;

out:
    if (sx_status) {
        if (new_encap_handle != SDK_TUNNEL_INVALID_ENCAP_HWD_HDL) {
            /* coverity[dead_error_condition] */
            if (is_create_encap) {
                /* coverity[dead_error_begin] */
                rb_status = hwd_encap_db_delete(new_encap_handle);
                if (SX_CHECK_FAIL(rb_status)) {
                    SX_LOG_ERR("Failed to roll back adding encap entry from HW DB, err = %s.\n",
                               sx_status_str(rb_status));
                }
            }
        }

        if (new_decap_handle != SDK_TUNNEL_INVALID_DECAP_HWD_HDL) {
            if (is_create_decap) {
                rb_status = hwd_rtdp_db_delete(new_decap_handle);
                if (SX_CHECK_FAIL(rb_status)) {
                    SX_LOG_ERR("Failed to roll back adding decap entry from RTDP DB, err = %s.\n",
                               sx_status_str(rb_status));
                }
            }
            rb_status = __tunnel_remove_decap_entry(new_decap_handle);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to delete tunnel decap entry on HW, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }

        if (is_updated_tngcr) {
            /* update tngcr */
            rb_status =
                hwd_tunnel_update_tngcr(&g_global_config, NULL, 0, nve_type, FALSE, FALSE, rb_et_vlan, FALSE, 0);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to rollback TNGCR REG state, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_delete(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                              hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                              const sx_tunnel_attribute_t *tunnel_attr_p)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    sx_status_t             rb_status = SX_STATUS_SUCCESS;
    hwd_rtdp_t              rtdp_entry;
    hwd_tunnel_encap_data_t encap_entry;
    hwd_tngcr_t             tngcr_bcp;
    boolean_t               is_encap_delete = FALSE;
    boolean_t               is_decap_delete = FALSE;
    boolean_t               is_tngcr_update = FALSE;
    boolean_t               is_type_nve = FALSE;

    UNUSED_PARAM(tunnel_attr_p);

    SX_MEM_CLR(rtdp_entry);
    SX_MEM_CLR(encap_entry);
    SX_MEM_CLR(tngcr_bcp);
    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("delete tunnel", sx_status);
    if ((tunnel_decap_handle == SDK_TUNNEL_INVALID_DECAP_HWD_HDL) &&
        (tunnel_encap_handle == SDK_TUNNEL_INVALID_ENCAP_HWD_HDL)) {
        sx_status = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to delete tunnel, both handles are invalid.\n");
        goto out;
    }

    /* get rtdp and encap entry for restore in case of error */
    if (tunnel_decap_handle != SDK_TUNNEL_INVALID_DECAP_HWD_HDL) {
        sx_status = hwd_rtdp_db_get(tunnel_decap_handle, &rtdp_entry);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get rtdp entry form RTDP DB, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }
        if (rtdp_entry.ku_rtdp.type == SXD_RTDP_TYPE_NVE_E) {
            is_type_nve = TRUE;
        }
    }

    if (tunnel_encap_handle != SDK_TUNNEL_INVALID_ENCAP_HWD_HDL) {
        sx_status = hwd_encap_db_get(tunnel_encap_handle, &encap_entry);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get encap entry form HW DB, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }
        if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, encap_entry.type, SX_TUNNEL_TYPE_NVE_MAX)) {
            is_type_nve = TRUE;
        }
    }

    if (is_type_nve) {
        SX_MEM_CPY(tngcr_bcp, g_global_config.tngcr_config);
        sx_status = hwd_tunnel_update_tngcr(&g_global_config, NULL, 0,
                                            g_global_config.tngcr_config.ku_tngcr.type,
                                            FALSE, FALSE, TUNNEL_NVE_VLAN_DECAP_ETH_TYPE_INDEX_DEFAULT, FALSE, 0);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update TNGCR REG state, err = %s.\n",
                       sx_status_str(sx_status));
            goto out;
        }
        is_tngcr_update = TRUE;
    }

    if (tunnel_encap_handle != SDK_TUNNEL_INVALID_ENCAP_HWD_HDL) {
        sx_status = hwd_encap_db_delete(tunnel_encap_handle);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to delete encap entry from HW DB, err = %s.\n",
                       sx_status_str(sx_status));
            goto out;
        }
        is_encap_delete = TRUE;
    }

    if (tunnel_decap_handle != SDK_TUNNEL_INVALID_DECAP_HWD_HDL) {
        sx_status = hwd_rtdp_db_delete(tunnel_decap_handle);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to delete decap entry from RTDP DB, err = %s.\n",
                       sx_status_str(sx_status));
            goto out;
        }
        is_decap_delete = TRUE;

        sx_status = __tunnel_remove_decap_entry(tunnel_decap_handle);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to delete tunnel decap entry on HW, err = %s.\n",
                       sx_status_str(sx_status));
        }
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (is_decap_delete) {
            rb_status = hwd_rtdp_db_add(tunnel_decap_handle, &rtdp_entry);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to roll back deleting of rtdp entry from RTDP DB, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }

        if (is_encap_delete) {
            rb_status = hwd_encap_db_add(tunnel_encap_handle, &encap_entry);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to roll back deleting of encap entry form HW DB, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }

        if (is_tngcr_update) {
            rb_status = hwd_tunnel_tngcr_reg_write(&tngcr_bcp.ku_tngcr);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to update TNGCR REG, err = %s.\n", sx_status_str(sx_status));
            }
            SX_MEM_CPY(g_global_config.tngcr_config, tngcr_bcp);
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_edit(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                            hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                            const sx_tunnel_attribute_t *old_tunnel_attr_p,
                            const sx_tunnel_attribute_t *new_tunnel_attr_p)
{
    sx_status_t                             sx_status = SX_STATUS_SUCCESS;
    const sx_tunnel_nve_encap_attributes_t *nve_encap_p = NULL;
    hwd_tunnel_encap_index_t                hw_tunnel_index;
    sxd_tunnel_nve_type_t                   nve_type = 0;
    sx_router_interface_t                   underlay_rif = 0;
    hwd_rif_id_t                            hw_rif_id = 0;
    uint8_t                                 et_vlan = 0;
    boolean_t                               dis_nve_opt_chk = FALSE;
    uint64_t                                hdr_bits = 0;
    sx_tunnel_nve_reserved_bits_mode_e      old_mode = SX_TUNNEL_NVE_RESERVED_BITS_MODE_DROP_E;
    sx_tunnel_nve_reserved_bits_mode_e      new_mode = SX_TUNNEL_NVE_RESERVED_BITS_MODE_DROP_E;

    SX_LOG_ENTER();
    SX_LOG(SX_LOG_DEBUG, "Edit HWD Tunnel.\n");

    /* Edit for decap parameter are not supported. Ignore decap handle. */
    UNUSED_PARAM(tunnel_decap_handle);

    if (utils_check_pointer(new_tunnel_attr_p, "new_tunnel_attr_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, new_tunnel_attr_p->type,
                       SX_TUNNEL_TYPE_NVE_MAX)) {
        switch (new_tunnel_attr_p->type) {
        /* NVE Tunnels */
        case SX_TUNNEL_TYPE_NVE_VXLAN:
        case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
            nve_encap_p = &new_tunnel_attr_p->attributes.vxlan.encap;
            underlay_rif = new_tunnel_attr_p->attributes.vxlan.encap.underlay_rif;
            sx_status = hwd_tunnel_et_vlan_index_get(new_tunnel_attr_p->attributes.vxlan.decap.tag_mode, &et_vlan);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Tunnel : hwd_tunnel_et_vlan_index_get failed , err = %s\n",
                           sx_status_str(sx_status));
                goto out;
            }
            nve_type = SXD_TUNNEL_NVE_VXLAN;

            __hwd_tunnel_attr_reserved_bits_unpack(&new_tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check,
                                                   VXLAN_RESERVED_BITS_DEFAULT_MASK,
                                                   &dis_nve_opt_chk,
                                                   &hdr_bits);

            old_mode = old_tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mode;
            new_mode = new_tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mode;

            break;

        case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
            nve_encap_p = &new_tunnel_attr_p->attributes.vxlan_gpe.encap;
            underlay_rif = new_tunnel_attr_p->attributes.vxlan_gpe.encap.underlay_rif;
            sx_status =
                hwd_tunnel_et_vlan_index_get(new_tunnel_attr_p->attributes.vxlan_gpe.decap.tag_mode, &et_vlan);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Tunnel : hwd_tunnel_et_vlan_index_get failed , err = %s\n",
                           sx_status_str(sx_status));
                goto out;
            }
            nve_type = SXD_TUNNEL_NVE_VXLAN_GPE;

            __hwd_tunnel_attr_reserved_bits_unpack(&new_tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check,
                                                   GPE_RESERVED_BITS_DEFAULT_MASK,
                                                   &dis_nve_opt_chk,
                                                   &hdr_bits);

            old_mode = old_tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mode;
            new_mode = new_tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mode;

            break;

        case SX_TUNNEL_TYPE_NVE_GENEVE:
            nve_encap_p = &new_tunnel_attr_p->attributes.geneve.encap;
            underlay_rif = new_tunnel_attr_p->attributes.geneve.encap.underlay_rif;
            sx_status = hwd_tunnel_et_vlan_index_get(new_tunnel_attr_p->attributes.geneve.decap.tag_mode, &et_vlan);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Tunnel : hwd_tunnel_et_vlan_index_get failed , err = %s\n",
                           sx_status_str(sx_status));
                goto out;
            }
            nve_type = SXD_TUNNEL_NVE_GENEVE;

            __hwd_tunnel_attr_reserved_bits_unpack(&new_tunnel_attr_p->attributes.geneve.decap.reserved_bits_check,
                                                   GENEVE_RESERVED_BITS_DEFAULT_MASK,
                                                   &dis_nve_opt_chk,
                                                   &hdr_bits);

            old_mode = old_tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mode;
            new_mode = new_tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mode;

            break;

        case SX_TUNNEL_TYPE_NVE_NVGRE:
        case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
            nve_encap_p = &new_tunnel_attr_p->attributes.nvgre.encap;
            underlay_rif = new_tunnel_attr_p->attributes.nvgre.encap.underlay_rif;
            sx_status = hwd_tunnel_et_vlan_index_get(new_tunnel_attr_p->attributes.nvgre.decap.tag_mode, &et_vlan);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Tunnel : hwd_tunnel_et_vlan_index_get failed , err = %s\n",
                           sx_status_str(sx_status));
                goto out;
            }
            nve_type = SXD_TUNNEL_NVE_NVGRE;

            __hwd_tunnel_attr_reserved_bits_unpack(&new_tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check,
                                                   NVGRE_RESERVED_BITS_DEFAULT_MASK,
                                                   &dis_nve_opt_chk,
                                                   &hdr_bits);

            old_mode = old_tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mode;
            new_mode = new_tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mode;

            break;

        default:
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid tunnel type %d\n", new_tunnel_attr_p->type);
            goto out;
        }

        /* Validate encap handle */
        sx_status = hwd_encap_db_index_get(tunnel_encap_handle, &hw_tunnel_index);
        if (SX_CHECK_FAIL(sx_status)) {
            goto out;
        }

        sx_status = hwd_rif_hw_id_get(underlay_rif, &hw_rif_id);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get RIF %u HW ID in hwd_tunnel_edit, err = [%s] \n",
                       underlay_rif, sx_status_str(sx_status));
            goto out;
        }

        /* update tngcr */
        /* only for one tunnel */
        sx_status = hwd_tunnel_update_tngcr(&g_global_config, ((new_tunnel_attr_p->direction &
                                                                SX_TUNNEL_DIRECTION_ENCAP) ? nve_encap_p : NULL),
                                            hw_rif_id, nve_type, TRUE,
                                            g_global_config.tngcr_config.ku_tngcr.learn_enable, et_vlan,
                                            dis_nve_opt_chk,
                                            hdr_bits);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to edit tunnel attributes on the HWD layer, error = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        if (old_mode != new_mode) {
            if ((old_mode == SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) ||
                (new_mode == SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E)) {
                sx_status = __hwd_tunnel_nve_options_trap_set(new_tunnel_attr_p);
                if (SX_CHECK_FAIL(sx_status)) {
                    SX_LOG_ERR("Failed to enable extra tunnel traps, error = %s.\n", sx_status_str(sx_status));
                    goto out;
                }
            }
        }
    }

out:

    SX_LOG_EXIT();
    return sx_status;
}

static void __hwd_tunnel_tnpc_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    boolean_t learn_en = FALSE;
    boolean_t lbf_enabled = FALSE;
    FILE     *stream = dbg_dump_params_p->stream;

    learn_en = g_global_config.tnpc_config[SX_PORT_TUNNEL_NVE].ku_tnpc.learn_enable_v4;
    lbf_enabled =
        (g_global_config.tnpc_config[SX_PORT_TUNNEL_NVE].ku_tnpc.lb_tx_uc_tunnel_port ==
         TUNNEL_TNPC_LB_TX_TUNNEL_PORT_FILTER) ? TRUE : FALSE;

    dbg_utils_pprinter_field_print(stream, "NVE Learn Enable", &learn_en, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "NVE Loopback filter enabled", &lbf_enabled, PARAM_BOOL_E);

    learn_en = g_global_config.tnpc_config[SX_PORT_TUNNEL_FLEX0].ku_tnpc.learn_enable_v4;
    lbf_enabled =
        (g_global_config.tnpc_config[SX_PORT_TUNNEL_FLEX0].ku_tnpc.lb_tx_uc_tunnel_port ==
         TUNNEL_TNPC_LB_TX_TUNNEL_PORT_FILTER) ? TRUE : FALSE;

    dbg_utils_pprinter_field_print(stream, "FLEX0 Learn Enable", &learn_en, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "FLEX0 Loopback filter enabled", &lbf_enabled, PARAM_BOOL_E);

    learn_en = g_global_config.tnpc_config[SX_PORT_TUNNEL_FLEX1].ku_tnpc.learn_enable_v4;
    lbf_enabled =
        (g_global_config.tnpc_config[SX_PORT_TUNNEL_FLEX1].ku_tnpc.lb_tx_uc_tunnel_port ==
         TUNNEL_TNPC_LB_TX_TUNNEL_PORT_FILTER) ? TRUE : FALSE;

    dbg_utils_pprinter_field_print(stream, "FLEX1 Learn Enable", &learn_en, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "FLEX1 Loopback filter enabled", &lbf_enabled, PARAM_BOOL_E);
}

sx_status_t hwd_tunnel_debug_dump_common(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    char                tunnel_type_str[32];
    char                buffer[32];
    struct ku_tngcr_reg ku_tngcr;
    struct ku_tigcr_reg ku_tigcr;
    FILE               *stream = NULL;

    SX_MEM_CLR(ku_tngcr);
    SX_MEM_CLR(ku_tigcr);
    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "HWD TUNNEL");

    dbg_utils_pprinter_field_print(stream, "Module initialized", &g_is_initialized, PARAM_BOOL_E);

    if (FALSE == g_is_initialized) {
        /* error stays success */
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    }

    dbg_utils_pprinter_general_header_print(stream, "HWD tunnel module general params");

    dbg_utils_pprinter_secondary_header_print(stream, "TNGCR config");
    SX_MEM_CPY(ku_tngcr, g_global_config.tngcr_config.ku_tngcr);

    __tunnel_debug_type_name_get(ku_tngcr.type, tunnel_type_str, sizeof(tunnel_type_str));

    dbg_utils_pprinter_field_print(stream, "NVE type", &tunnel_type_str, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream, "Valid", &ku_tngcr.nve_valid, PARAM_UINT8_E);

    __tunnel_debug_decap_ttl_mode_name_get(ku_tngcr.nve_decap_ttl, buffer, sizeof(buffer));
    dbg_utils_pprinter_field_print(stream, "Decap TTL cmd", &buffer, PARAM_STRING_E);
    __tunnel_debug_encap_ttl_mode_name_get(ku_tngcr.nve_ttlc, buffer, sizeof(buffer));
    dbg_utils_pprinter_field_print(stream, "Encap TTL cmd", &buffer, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream, "UC TTL", &ku_tngcr.nve_ttl_uc, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "MC TTL", &ku_tngcr.nve_ttl_mc, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Flow Label Copy", &ku_tngcr.nve_flc, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Flow Label Hash", &ku_tngcr.nve_flh, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Flow Label Prefix", &ku_tngcr.nve_fl_prefix, PARAM_UINT16_E);
    dbg_utils_pprinter_field_print(stream, "UDP source port type", &ku_tngcr.nve_udp_sport_type, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "UDP source port prefix", &ku_tngcr.nve_udp_sport_prefix, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "MC group size", &ku_tngcr.nve_group_size_mc, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Disable NVE bits check", &ku_tngcr.dis_nve_opt_chk, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "VXLAN header bits enable", &ku_tngcr.vxlan_hdr_bits_en, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "VXLAN header bits", &ku_tngcr.vxlan_hdr_bits, PARAM_HEX64_E);
    dbg_utils_pprinter_field_print(stream, "GPE header bits enable", &ku_tngcr.gpe_hdr_bits_en, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "GPE header bits", &ku_tngcr.gpe_hdr_bits, PARAM_HEX64_E);
    dbg_utils_pprinter_field_print(stream, "GENEVE header bits enable", &ku_tngcr.geneve_hdr_bits_en, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "GENEVE header bits", &ku_tngcr.geneve_hdr_bits, PARAM_HEX64_E);
    dbg_utils_pprinter_field_print(stream, "NVGRE header bits enable", &ku_tngcr.nvgre_hdr_bits_en, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "NVGRE header bits", &ku_tngcr.nvgre_hdr_bits, PARAM_HEX_E);

    if (g_hwd_tunnel_internal_callbacks.hwd_tunnel_tnpc_dump_pfn != NULL) {
        g_hwd_tunnel_internal_callbacks.hwd_tunnel_tnpc_dump_pfn(dbg_dump_params_p);
    } else {
        dbg_utils_pprinter_field_print(stream, "Learn Enable", &ku_tngcr.learn_enable, PARAM_UINT8_E);
    }
    dbg_utils_pprinter_field_print(stream, "Underlay VRID", &ku_tngcr.underlay_virtual_router, PARAM_UINT16_E);
    dbg_utils_pprinter_field_print(stream, "Underlay RIF", &ku_tngcr.underlay_rif, PARAM_UINT16_E);
    dbg_utils_pprinter_field_print(stream, "Underlay Source IPv4", &ku_tngcr.usipv4, PARAM_IPV4_E);
    dbg_utils_pprinter_field_print(stream, "Underlay Source IPv6", &ku_tngcr.usipv6, PARAM_IPV6_E);
    dbg_utils_pprinter_field_print(stream, "VLAN eth_type idx", &ku_tngcr.et_vlan, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Reserved TNGEE index", &g_zeroed_reserved_tngee_index, PARAM_UINT32_E);

    dbg_utils_pprinter_secondary_header_print(stream, "TIGCR config");
    SX_MEM_CPY(ku_tigcr, g_global_config.tigcr_config.ku_tigcr);

    switch (ku_tigcr.ipip_ttlc) {
    case SXD_TIGCR_TTLC_USE_CONFIG:
        snprintf(buffer, sizeof(buffer), "use config [%2u]", ku_tigcr.ipip_ttlc);
        break;

    case SXD_TIGCR_TTLC_COPY_FROM_PKT:
        snprintf(buffer, sizeof(buffer), "copy from packet [%2u]", ku_tigcr.ipip_ttlc);
        break;

    default:
        snprintf(buffer, sizeof(buffer), "unknown [%2u]", ku_tigcr.ipip_ttlc);
        break;
    }
    dbg_utils_pprinter_field_print(stream, "TTL cmd", &buffer, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream, "TTL value", &ku_tigcr.ipip_ttl_uc, PARAM_UINT8_E);

    switch (ku_tigcr.ipip_flc) {
    case SXD_TUNNEL_FLC_CALCULATE:
        snprintf(buffer, sizeof(buffer), "calculate [%2u]", ku_tigcr.ipip_flc);
        break;

    case SXD_TUNNEL_FLC_COPY_FROM_PKT:
        snprintf(buffer, sizeof(buffer), "copy from packet [%2u]", ku_tigcr.ipip_flc);
        break;

    default:
        snprintf(buffer, sizeof(buffer), "unknown [%2u]", ku_tigcr.ipip_flc);
        break;
    }
    dbg_utils_pprinter_field_print(stream, "Flow cmd", &buffer, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream, "Flow label", &ku_tigcr.ipip_flh, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Flow label prefix", &ku_tigcr.ipip_fl_prefix, PARAM_UINT16_E);
    dbg_utils_pprinter_field_print(stream, "GRE key for HASH", &ku_tigcr.ipip_gre_key_for_hash, PARAM_UINT32_E);

    __hwd_cos_dbg_dump(dbg_dump_params_p, SX_TUNNEL_QOS_TUNNEL_TYPE_NVE_E, "VXLAN");
    __hwd_cos_dbg_dump(dbg_dump_params_p, SX_TUNNEL_QOS_TUNNEL_TYPE_IPINIP_E, "IPINIP");

    hwd_tunnel_db_debug_dump(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
    return sx_status;
}

void __hwd_tunnel_debug_dump_counters(dbg_dump_params_t *dbg_dump_params_p)
{
    boolean_t                 is_clear = FALSE;
    sx_tunnel_counter_items_t counter;
    FILE                     *stream = NULL;

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        return;
    }
    stream = dbg_dump_params_p->stream;

    SX_MEM_CLR(counter);

    dbg_utils_pprinter_secondary_header_print(stream, "NVE general counters");
    hwd_tunnel_counter_get(is_clear, 0, &counter);

    dbg_utils_pprinter_field_print(stream, "NVE Encap packets", &counter.nve.encapsulated_pkts, PARAM_UINT64_E);
    dbg_utils_pprinter_field_print(stream, "NVE Decap packets", &counter.nve.decapsulated_pkts, PARAM_UINT64_E);
    dbg_utils_pprinter_field_print(stream, "NVE Decap errors", &counter.nve.decapsulated_errors, PARAM_UINT64_E);
    dbg_utils_pprinter_field_print(stream, "NVE Decap discards", &counter.nve.decapsulated_discards, PARAM_UINT64_E);
}

void __ulay_default_rif_hwd_tunnel_debug_dump_counters(dbg_dump_params_t *dbg_dump_params_p)
{
    boolean_t                 is_clear = FALSE;
    sx_tunnel_counter_items_t counter;
    FILE                     *stream = NULL;

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        return;
    }
    stream = dbg_dump_params_p->stream;

    SX_MEM_CLR(counter);

    if (dbg_dump_params_p->hw_dump_method == SX_DBG_HW_DUMP_METHOD_NONE_E) {
        return;
    }

    dbg_utils_pprinter_secondary_header_print(stream, "L2 Tunnel general counters");

    ulay_default_rif_hwd_tunnel_counter_get(is_clear, SX_PORT_TUNNEL_NVE, &counter);
    dbg_utils_pprinter_field_print(stream, "NVE Decap discards", &counter.nve.decapsulated_discards, PARAM_UINT64_E);
    dbg_utils_pprinter_field_print(stream, "NVE Encap discards", &counter.nve.encapsulated_discards, PARAM_UINT64_E);

    ulay_default_rif_hwd_tunnel_counter_get(is_clear, SX_PORT_TUNNEL_FLEX0, &counter);
    dbg_utils_pprinter_field_print(stream,
                                   "Flex 0 Decap discards",
                                   &counter.l2_flex.decapsulated_discards,
                                   PARAM_UINT64_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Flex 0 Encap discards",
                                   &counter.l2_flex.encapsulated_discards,
                                   PARAM_UINT64_E);

    ulay_default_rif_hwd_tunnel_counter_get(is_clear, SX_PORT_TUNNEL_FLEX1, &counter);
    dbg_utils_pprinter_field_print(stream,
                                   "Flex 1 Decap discards",
                                   &counter.l2_flex.decapsulated_discards,
                                   PARAM_UINT64_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Flex 1 Encap discards",
                                   &counter.l2_flex.encapsulated_discards,
                                   PARAM_UINT64_E);
}


sx_status_t ulay_default_rif_hwd_tunnel_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    sx_status = hwd_tunnel_debug_dump_common(dbg_dump_params_p);
    __ulay_default_rif_hwd_tunnel_debug_dump_counters(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_hwd_tunnel_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    sx_status = hwd_tunnel_debug_dump_common(dbg_dump_params_p);
    __hwd_tunnel_debug_dump_counters(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
    return sx_status;
}


/* tunnel_hwd_index_p - index in KVDL of RTDP block */
sx_status_t hwd_tunnel_decap_block_lock(hwi_tunnel_hw_decap_handle_t tunnel_decap_block,
                                        hwd_tunnel_decap_index_t    *tunnel_hw_index_p)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    uint32_t                   size = 1;
    kvd_linear_manager_index_t rtdp_index = 0;

    SX_LOG_ENTER();

    if (utils_check_pointer(tunnel_hw_index_p, "tunnel_hw_index_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    TUNNEL_HWD_INIT_CHECK("lock decap block", sx_status);

    sx_status = kvd_linear_manager_handle_lock(tunnel_decap_block, &rtdp_index, &size);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to lock decap HW index, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    *tunnel_hw_index_p = rtdp_index;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_decap_block_unlock(hwi_tunnel_hw_decap_handle_t tunnel_decap_block)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("unlock decap block", sx_status);

    sx_status = kvd_linear_manager_handle_release(tunnel_decap_block);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to unlock decap HW index, err = %s.\n", sx_status_str(sx_status));
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_encap_block_lock(hwi_tunnel_hw_encap_handle_t tunnel_encap_block,
                                        hwd_tunnel_encap_index_t    *tunnel_hw_index_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(tunnel_hw_index_p, "tunnel_hw_index_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    TUNNEL_HWD_INIT_CHECK("lock encap block", sx_status);

    sx_status = hwd_encap_db_index_get(tunnel_encap_block, tunnel_hw_index_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get encap HW index, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_encap_block_unlock(hwi_tunnel_hw_encap_handle_t tunnel_encap_block)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("unlock encap block", sx_status);

    if (SDK_TUNNEL_INVALID_ENCAP_HWD_HDL == tunnel_encap_block) {
        sx_status = SX_STATUS_INVALID_HANDLE;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_nve_group_size_flood_get(uint32_t *nve_group_size_flood_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("hwd_tunnel_nve_group_size_flood_get", sx_status);

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(nve_group_size_flood_p,
                                                      "nve_group_size_flood_p"))) {
        goto out;
    }

    if (g_global_config.general_params.nve.flood_ecmp_enabled) {
        *nve_group_size_flood_p = g_global_config.tngcr_config.ku_tngcr.nve_group_size_flood;
    } else {
        *nve_group_size_flood_p = 0;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_nve_group_size_flood_get_spc2(uint32_t *nve_group_size_flood_p)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_router_resources_param_t *resources_param_p = NULL;
    uint32_t                     max_ecmp_block_sz = 0;

    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("hwd_tunnel_nve_group_size_flood_get_spc2", sx_status);

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(nve_group_size_flood_p,
                                                      "nve_group_size_flood_p"))) {
        goto out;
    }

    /* Check if MAX ECMP size is not bigger than correspondent value in router params */
    sx_status = sdk_router_impl_params_get(NULL, NULL, &resources_param_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get router resources params, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Check if user provided non-zero MAX ECMP block size */
    if (resources_param_p->max_ecmp_block_size != 0) {
        max_ecmp_block_sz = resources_param_p->max_ecmp_block_size;
    } else {
        /* MAX ECMP size 0 means it should be a default value */
        max_ecmp_block_sz = rm_resource_global.router_ecmp_container_tot_weight_max;
    }

    *nve_group_size_flood_p = MIN(rm_resource_global.tunnel_nve_group_size_flood_max,
                                  max_ecmp_block_sz);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_nve_group_size_mc_get(uint32_t *nve_group_size_mc_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("hwd_tunnel_nve_group_size_mc_get", sx_status);

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(nve_group_size_mc_p,
                                                      "nve_group_size_mc_p"))) {
        goto out;
    }

    if (g_global_config.general_params.nve.mc_ecmp_enabled) {
        *nve_group_size_mc_p = g_global_config.tngcr_config.ku_tngcr.nve_group_size_mc;
    } else {
        *nve_group_size_mc_p = 0;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_nve_group_size_mc_get_spc2(uint32_t *nve_group_size_mc_p)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_router_resources_param_t *resources_param_p = NULL;
    uint32_t                     max_ecmp_block_sz = 0;

    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("hwd_tunnel_nve_group_size_mc_get_spc2", sx_status);

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(nve_group_size_mc_p,
                                                      "nve_group_size_mc_p"))) {
        goto out;
    }

    /* Check if MAX ECMP size is not bigger than correspondent value in router params */
    sx_status = sdk_router_impl_params_get(NULL, NULL, &resources_param_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get router resources params, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Check if user provided non-zero MAX ECMP block size */
    if (resources_param_p->max_ecmp_block_size != 0) {
        max_ecmp_block_sz = resources_param_p->max_ecmp_block_size;
    } else {
        /* MAX ECMP size 0 means it should be a default value */
        max_ecmp_block_sz = rm_resource_global.router_ecmp_container_tot_weight_max;
    }

    *nve_group_size_mc_p = MIN(rm_resource_global.tunnel_nve_group_size_mc_max,
                               max_ecmp_block_sz);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_counter_get(const boolean_t               is_clear,
                                   const sx_port_tunnel_phy_id_t phy_tunnel_port,
                                   sx_tunnel_counter_items_t    *counter)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_tncr_reg *tncr_reg_data = NULL;
    uint32_t            idx, dev_cnt = 0;

    SX_LOG_ENTER();

    UNUSED_PARAM(phy_tunnel_port);

    if (utils_check_pointer(counter, "counter")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = hwd_tunnel_tncr_get(is_clear, &tncr_reg_data, &dev_cnt);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Tunnel : Failed to get counters from HW\n");
        goto out;
    }

    if (utils_check_pointer(tncr_reg_data, "tncr_reg_data")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    counter->nve.encapsulated_pkts = 0;
    counter->nve.decapsulated_pkts = 0;
    counter->nve.decapsulated_errors = 0;
    counter->nve.decapsulated_discards = 0;

    for (idx = 0; idx <= dev_cnt; idx++) {
        counter->nve.encapsulated_pkts += tncr_reg_data[idx].count_encap_low |
                                          ((uint64_t)tncr_reg_data[idx].count_encap_high << 32);

        counter->nve.decapsulated_pkts += tncr_reg_data[idx].count_decap_low |
                                          ((uint64_t)tncr_reg_data[idx].count_decap_high << 32);

        counter->nve.decapsulated_errors += tncr_reg_data[idx].count_decap_errors_low |
                                            ((uint64_t)tncr_reg_data[idx].count_decap_errors_high << 32);

        counter->nve.decapsulated_discards += tncr_reg_data[idx].count_decap_discards_low |
                                              ((uint64_t)tncr_reg_data[idx].count_decap_discards_high << 32);
    }

    M_UTILS_MEM_PUT(tncr_reg_data, UTILS_MEM_TYPE_ID_TUNNEL_E, "De alloc of TNCR reg", err);
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t ulay_default_rif_hwd_tunnel_counter_get(const boolean_t               is_clear,
                                                    const sx_port_tunnel_phy_id_t phy_tunnel_port,
                                                    sx_tunnel_counter_items_t    *counter)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    struct ku_tncr_v2_reg *tncr_v2_reg_data = NULL;
    uint32_t               idx, dev_cnt = 0;
    uint64_t               encapsulated_pkts = 0;
    uint64_t               encapsulated_discards = 0;
    uint64_t               decapsulated_pkts = 0;
    uint64_t               decapsulated_errors = 0;
    uint64_t               decapsulated_discards = 0;


    SX_LOG_ENTER();

    if (utils_check_pointer(counter, "counter")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = hwd_tunnel_tncr_v2_get(is_clear, phy_tunnel_port, &tncr_v2_reg_data, &dev_cnt);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Tunnel : Failed to get counters from HW\n");
        goto out;
    }

    if (utils_check_pointer(tncr_v2_reg_data, "tncr_v2_reg_data")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    for (idx = 0; idx <= dev_cnt; idx++) {
        encapsulated_discards += tncr_v2_reg_data[idx].count_encap_discards_low |
                                 ((uint64_t)tncr_v2_reg_data[idx].count_encap_discards_high << 32);
        decapsulated_discards += tncr_v2_reg_data[idx].count_decap_discards_low |
                                 ((uint64_t)tncr_v2_reg_data[idx].count_decap_discards_high << 32);
    }

    switch (phy_tunnel_port) {
    case SX_PORT_TUNNEL_NVE:
        counter->nve.encapsulated_pkts = encapsulated_pkts;
        counter->nve.encapsulated_discards = encapsulated_discards;
        counter->nve.decapsulated_pkts = decapsulated_pkts;
        counter->nve.decapsulated_errors = decapsulated_errors;
        counter->nve.decapsulated_discards = decapsulated_discards;
        break;

    case SX_PORT_TUNNEL_FLEX0:
    case SX_PORT_TUNNEL_FLEX1:
        counter->l2_flex.encapsulated_pkts = encapsulated_pkts;
        counter->l2_flex.encapsulated_discards = encapsulated_discards;
        counter->l2_flex.decapsulated_pkts = decapsulated_pkts;
        counter->l2_flex.decapsulated_errors = decapsulated_errors;
        counter->l2_flex.decapsulated_discards = decapsulated_discards;
        break;

    default:
        SX_LOG_ERR("Unknown tunnel port [%u] for counter get\n", phy_tunnel_port);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
        break;
    }

    M_UTILS_MEM_PUT(tncr_v2_reg_data, UTILS_MEM_TYPE_ID_TUNNEL_E, "De alloc of TNCR reg", err);
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_sync_dev(const sx_dev_id_t dev_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG(SX_LOG_DEBUG, "HWD Tunnel, Sync dev ID %u\n", dev_id);

    TUNNEL_HWD_INIT_CHECK("sync dev", sx_status);

    sx_status = hwd_rtdp_db_apply(hwd_tunnel_write_rtdp_to_dev, &dev_id);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to write rtdp db to dev %u, err = %s.\n",
                   dev_id, sx_status_str(sx_status));
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t hwd_tunnel_nve_learn_set(sx_port_log_id_t log_port, boolean_t learn_enable)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    boolean_t   dis_nve_opt_chk = FALSE;
    uint64_t    hdr_bits = 0;

    SX_LOG_ENTER();

    UNUSED_PARAM(log_port);

    /* when the tunnel isn't initialized skip the hw config */
    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    }

    sx_status = hwd_tunnel_tngcr_to_reserved_bits_unpack(&g_global_config.tngcr_config.ku_tngcr,
                                                         &dis_nve_opt_chk,
                                                         &hdr_bits);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get the reserved bits changing the learn mode, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = hwd_tunnel_update_tngcr(&g_global_config, NULL, g_global_config.tngcr_config.ku_tngcr.underlay_rif,
                                        g_global_config.tngcr_config.ku_tngcr.type,
                                        g_global_config.tngcr_config.ku_tngcr.nve_valid,
                                        learn_enable,
                                        g_global_config.tngcr_config.ku_tngcr.et_vlan,
                                        dis_nve_opt_chk,
                                        hdr_bits);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set learn mode, err = %s.\n", sx_status_str(sx_status));
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_nve_learn_set_spc2(sx_port_log_id_t log_port, boolean_t learn_enable)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* when the tunnel isn't initialized skip the hw config */
    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    }

    sx_status = hwd_tunnel_update_tnpc(SX_PORT_PHY_ID_GET(log_port),
                                       learn_enable,
                                       g_global_config.tnpc_config[SX_PORT_PHY_ID_GET(
                                                                       log_port)].ku_tnpc.lb_tx_uc_tunnel_port);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set learn mode, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    g_global_config.tnpc_config[SX_PORT_PHY_ID_GET(log_port)].ku_tnpc.learn_enable_v4 = learn_enable;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_nve_port_issu_end_set()
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    sx_port_tunnel_phy_id_t tunnel_port = 0;

    for (tunnel_port = SX_PORT_TUNNEL_MIN; tunnel_port <= SX_PORT_TUNNEL_MAX; tunnel_port++) {
        if (tunnel_port == SX_PORT_TUNNEL_RESERVED) {
            continue;
        }
        /* NOTE: This is a workaround that should be remove once the FW is done */
        if ((tunnel_port == SX_PORT_TUNNEL_FLEX0) || (tunnel_port == SX_PORT_TUNNEL_FLEX1)) {
            continue;
        }

        sx_status = hwd_tunnel_update_tnpc(tunnel_port,
                                           g_global_config.tnpc_config[tunnel_port].ku_tnpc.learn_enable_v4,
                                           g_global_config.tnpc_config[tunnel_port].ku_tnpc.lb_tx_uc_tunnel_port);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to set the state of ISSU end to TNPC for %s, error: %s.\n",
                       sx_port_tunnel_phy_id_str(tunnel_port), sx_status_str(sx_status));
            goto out;
        }
    }

out:
    return sx_status;
}

sx_status_t hwd_tunnel_nve_loopback_filter_set(const sx_port_log_id_t         nve_log_port,
                                               sx_port_loopback_filter_mode_t lbf_mode)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     filter_enable = TUNNEL_LBF_MODE_PORT_TO_TUNNEL_CONVERT(lbf_mode);

    SX_LOG_ENTER();

    sx_status = hwd_tunnel_update_tnpc(SX_PORT_PHY_ID_GET(nve_log_port),
                                       g_global_config.tnpc_config[SX_PORT_PHY_ID_GET(
                                                                       nve_log_port)].ku_tnpc.learn_enable_v4,
                                       filter_enable);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set the state of the loopback filter[%u] on a NVE port[0x%x] to TNPC, error: %s.\n",
                   lbf_mode, nve_log_port, sx_status_str(sx_status));
        goto out;
    }

    g_global_config.tnpc_config[SX_PORT_PHY_ID_GET(nve_log_port)].ku_tnpc.lb_tx_uc_tunnel_port = filter_enable;

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_tunnel_counter_info_with_lock_get(sx_flow_counter_id_t counter_id,
                                                           boolean_t           *is_locked_p,
                                                           cm_hw_type_t        *hw_type_p,
                                                           cm_index_t          *index_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *is_locked_p = FALSE;

    if (counter_id != SX_FLOW_COUNTER_ID_INVALID) {
        sx_status = flow_counter_lock(counter_id, NULL, hw_type_p, index_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to lock counter, ID %u [%s]\n",
                       counter_id, sx_status_str(sx_status));
            goto out;
        }
        *is_locked_p = TRUE;
    } else {
        *hw_type_p = SXD_COUNTER_SET_TYPE_NO_COUNT;
        *index_p = 0;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static inline sx_status_t __hwd_tunnel_counter_info_unlock(sx_flow_counter_id_t counter_id)
{
    return flow_counter_unlock(counter_id);
}

sx_status_t hwd_tunnel_tunnel_mapping_add(const sx_tunnel_id_t          tunnel_id,
                                          const hwd_tunnel_map_entry_t *map_entry_p,
                                          const uint32_t                map_entry_cnt)
{
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    sx_status_t      rollback_err = SX_STATUS_SUCCESS;
    u_int32_t        i = 0;
    sx_fm_fid_type_t fid_type = SX_FM_FID_TYPE_INVALID;
    boolean_t        ref_cnt_increased = FALSE;
    cm_hw_type_t     counter_hw_type = 0;
    cm_index_t       counter_hw_index = 0;
    boolean_t        counter_locked = FALSE;

    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("set tunnel mapping", sx_status);

    /* NOTE: tunnel_id should be convert to vtep_id in the future,
     * we have only one vtep currently so don't use it  */
    UNUSED_PARAM(tunnel_id);

    if (utils_check_pointer(map_entry_p, "map_entry")) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("map_entry_p is NULL\n");
        goto out;
    }

    if (map_entry_cnt == 0) {
        SX_LOG_ERR("map_entry_cnt is 0\n");
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    for (i = 0; i < map_entry_cnt; i++) {
        if ((map_entry_p[i].map_entry.type < SX_TUNNEL_TYPE_NVE_MIN) ||
            (map_entry_p[i].map_entry.type > SX_TUNNEL_TYPE_NVE_MAX)) {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("map_entry_p[%u].type is not NVE type\n", i);
            goto out;
        }

        sx_status = sdk_fid_manager_get_fid_type(map_entry_p[i].map_entry.params.nve.bridge_id, &fid_type);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG(SX_LOG_ERROR, "Could not find fid[0x%08x] in the FID manager.\n",
                   map_entry_p[i].map_entry.params.nve.bridge_id);
            goto out;
        }

        if ((fid_type != SX_FM_FID_TYPE_VLAN_REWRITE_E) &&
            (fid_type != SX_FM_FID_TYPE_BRIDGE_REWRITE_E)) {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "FID[0x%08x] has unsupported type[%s]. \n",
                   map_entry_p[i].map_entry.params.nve.bridge_id, sx_fm_fid_type_str(fid_type));
            goto out;
        }

        if (fid_type == SX_FM_FID_TYPE_VLAN_REWRITE_E) {
            sx_status = vlan_ref_cnt_increase(0, map_entry_p[i].map_entry.params.nve.bridge_id);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to increase ref count of vlan id (%u), err = %s.\n",
                           map_entry_p[i].map_entry.params.nve.bridge_id, sx_status_str(sx_status));
                goto out;
            }
        } else {
            sx_status = bridge_ref_cnt_increase(map_entry_p[i].map_entry.params.nve.bridge_id);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to increase ref count of bridge id (%u), err = %s.\n",
                           map_entry_p[i].map_entry.params.nve.bridge_id, sx_status_str(sx_status));
                goto out;
            }
        }
        ref_cnt_increased = TRUE;

        sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_VNI_E, SX_ACCESS_CMD_ADD, 1, NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR_RESOURCE_COND(sx_status, "Failed to add VNI 0x%x to FID %u in RM, err = [%s]\n",
                                     map_entry_p[i].map_entry.params.nve.vni,
                                     map_entry_p[i].map_entry.params.nve.bridge_id,
                                     sx_status_str(sx_status));
            goto out;
        }

        /* Point of no return - all errors from this point on are fatal */

        switch (map_entry_p[i].map_entry.params.nve.direction) {
        case SX_TUNNEL_MAP_DIR_BIDIR:
            sx_status = sdk_fid_manager_hwfid_register_encap_vni_update(SX_ACCESS_CMD_ADD,
                                                                        map_entry_p[i].map_entry.params.nve.bridge_id,
                                                                        map_entry_p[i].map_entry.params.nve.vni);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to set tunnel encap vni (%u) for fid (%u), err = %s.\n",
                           map_entry_p[i].map_entry.params.nve.vni, map_entry_p[i].map_entry.params.nve.bridge_id,
                           sx_status_str(sx_status));
                goto out;
            }

        /* fallthrough */
        case SX_TUNNEL_MAP_DIR_DECAP:
            sx_status =
                __hwd_tunnel_counter_info_with_lock_get(map_entry_p[i].decap_flow_counter_id,
                                                        &counter_locked, &counter_hw_type, &counter_hw_index);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to get counter's info, ID %u [%s]\n",
                           map_entry_p[i].decap_flow_counter_id,
                           sx_status_str(sx_status));
                goto out;
            }

            sx_status = sdk_fid_manager_tunnel_decap_mapping_set(SX_ACCESS_CMD_ADD,
                                                                 map_entry_p[i].map_entry.params.nve.bridge_id,
                                                                 map_entry_p[i].map_entry.params.nve.vni,
                                                                 counter_hw_type, counter_hw_index,
                                                                 map_entry_p[i].v_rif,
                                                                 map_entry_p[i].hw_rif_id);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to set tunnel decap vni (%u) for fid (%u), err = %s.\n",
                           map_entry_p[i].map_entry.params.nve.vni,
                           map_entry_p[i].map_entry.params.nve.bridge_id,
                           sx_status_str(sx_status));
                goto out;
            }

            if (counter_locked == TRUE) {
                counter_locked = FALSE;
                sx_status =
                    __hwd_tunnel_counter_info_unlock(map_entry_p[i].decap_flow_counter_id);
                if (SX_CHECK_FAIL(sx_status)) {
                    SX_LOG_ERR("Failed to unlock counter, ID %u [%s]\n",
                               map_entry_p[i].decap_flow_counter_id,
                               sx_status_str(sx_status));
                    goto out;
                }
            }
            break;

        default:
            SX_LOG_ERR("Unexpected direction (%u), err = %s.\n",
                       map_entry_p[i].map_entry.params.nve.direction, sx_status_str(sx_status));
            goto out;
        }
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (ref_cnt_increased == TRUE) {
            if (fid_type == SX_FM_FID_TYPE_VLAN_REWRITE_E) {
                rollback_err = vlan_ref_cnt_decrease(0, map_entry_p[i].map_entry.params.nve.bridge_id);
                if (SX_CHECK_FAIL(rollback_err)) {
                    SX_LOG_ERR("Failed to decrease ref count of vlan id (%u), err = %s.\n",
                               map_entry_p[i].map_entry.params.nve.bridge_id, sx_status_str(rollback_err));
                }
            } else {
                rollback_err = bridge_ref_cnt_decrease(map_entry_p[i].map_entry.params.nve.bridge_id);
                if (SX_CHECK_FAIL(rollback_err)) {
                    SX_LOG_ERR("Failed to decrease ref count of bridge id (%u), err = %s.\n",
                               map_entry_p[i].map_entry.params.nve.bridge_id, sx_status_str(rollback_err));
                }
            }
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_tunnel_mapping_update(const sx_tunnel_id_t          tunnel_id,
                                             const hwd_tunnel_map_entry_t *map_entry_p,
                                             const uint32_t                map_entry_cnt)
{
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    u_int32_t        i = 0;
    sx_fm_fid_type_t fid_type = SX_FM_FID_TYPE_INVALID;
    cm_hw_type_t     counter_hw_type = 0;
    cm_index_t       counter_hw_index = 0;
    boolean_t        counter_locked = FALSE;

    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("update tunnel mapping", sx_status);

    /* NOTE: tunnel_id should be convert to vtep_id in the future,
     * we have only one vtep currently so don't use it  */
    UNUSED_PARAM(tunnel_id);

    if (utils_check_pointer(map_entry_p, "map_entry")) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("map_entry_p is NULL\n");
        goto out;
    }

    if (map_entry_cnt == 0) {
        SX_LOG_ERR("map_entry_cnt is 0\n");
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    for (i = 0; i < map_entry_cnt; i++) {
        if ((map_entry_p[i].map_entry.type < SX_TUNNEL_TYPE_NVE_MIN) ||
            (map_entry_p[i].map_entry.type > SX_TUNNEL_TYPE_NVE_MAX)) {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("map_entry_p[%u].type is not NVE type\n", i);
            goto out;
        }

        sx_status = sdk_fid_manager_get_fid_type(map_entry_p[i].map_entry.params.nve.bridge_id, &fid_type);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG(SX_LOG_ERROR, "Could not find fid[0x%08x] in the FID manager.\n",
                   map_entry_p[i].map_entry.params.nve.bridge_id);
            goto out;
        }

        if ((fid_type != SX_FM_FID_TYPE_VLAN_REWRITE_E) &&
            (fid_type != SX_FM_FID_TYPE_BRIDGE_REWRITE_E)) {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "FID[0x%08x] has unsupported type[%s]. \n",
                   map_entry_p[i].map_entry.params.nve.bridge_id, sx_fm_fid_type_str(fid_type));
            goto out;
        }

        switch (map_entry_p[i].map_entry.params.nve.direction) {
        case SX_TUNNEL_MAP_DIR_BIDIR:
        /* fallthrough */
        case SX_TUNNEL_MAP_DIR_DECAP:
            sx_status =
                __hwd_tunnel_counter_info_with_lock_get(map_entry_p[i].decap_flow_counter_id,
                                                        &counter_locked, &counter_hw_type, &counter_hw_index);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to get counter's info, ID %u [%s]\n",
                           map_entry_p[i].decap_flow_counter_id,
                           sx_status_str(sx_status));
                goto out;
            }

            sx_status = sdk_fid_manager_tunnel_decap_mapping_set(SX_ACCESS_CMD_EDIT,
                                                                 map_entry_p[i].map_entry.params.nve.bridge_id,
                                                                 map_entry_p[i].map_entry.params.nve.vni,
                                                                 counter_hw_type, counter_hw_index,
                                                                 map_entry_p[i].v_rif,
                                                                 map_entry_p[i].hw_rif_id);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to set tunnel decap vni (%u) for fid (%u), err = %s.\n",
                           map_entry_p[i].map_entry.params.nve.vni,
                           map_entry_p[i].map_entry.params.nve.bridge_id,
                           sx_status_str(sx_status));
                goto out;
            }

            if (counter_locked == TRUE) {
                counter_locked = FALSE;
                sx_status =
                    __hwd_tunnel_counter_info_unlock(map_entry_p[i].decap_flow_counter_id);
                if (SX_CHECK_FAIL(sx_status)) {
                    SX_LOG_ERR("Failed to unlock counter, ID %u [%s]\n",
                               map_entry_p[i].decap_flow_counter_id,
                               sx_status_str(sx_status));
                    goto out;
                }
            }
            break;

        default:
            SX_LOG_ERR("Unexpected direction (%u), err = %s.\n",
                       map_entry_p[i].map_entry.params.nve.direction, sx_status_str(sx_status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_tunnel_mapping_delete(const sx_tunnel_id_t          tunnel_id,
                                             const hwd_tunnel_map_entry_t *map_entry_p,
                                             const uint32_t                map_entry_cnt)
{
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    u_int32_t        i = 0;
    sx_fm_fid_type_t fid_type = SX_FM_FID_TYPE_INVALID;
    cm_hw_type_t     counter_hw_type = 0;
    cm_index_t       counter_hw_index = 0;
    boolean_t        counter_locked = FALSE;

    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("delete tunnel mapping", sx_status);

    /* NOTE: tunnel_id should be convert to vtep_id in the future,
     * we have only one vtep currently so don't use it  */
    UNUSED_PARAM(tunnel_id);

    if (utils_check_pointer(map_entry_p, "map_entry")) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("map_entry_p is NULL\n");
        goto out;
    }

    if (map_entry_cnt == 0) {
        sx_status = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("map_entry_cnt is 0\n");
        goto out;
    }

    for (i = 0; i < map_entry_cnt; i++) {
        if ((map_entry_p[i].map_entry.type < SX_TUNNEL_TYPE_NVE_MIN) ||
            (map_entry_p[i].map_entry.type > SX_TUNNEL_TYPE_NVE_MAX)) {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("map_entry_p[%u].type is not NVE type\n", i);
            goto out;
        }

        sx_status = sdk_fid_manager_get_fid_type(map_entry_p[i].map_entry.params.nve.bridge_id, &fid_type);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG(SX_LOG_ERROR, "Could not find fid[0x%08x] in the FID manager.\n",
                   map_entry_p[i].map_entry.params.nve.bridge_id);
            goto out;
        }

        if ((fid_type != SX_FM_FID_TYPE_VLAN_REWRITE_E) &&
            (fid_type != SX_FM_FID_TYPE_BRIDGE_REWRITE_E)) {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "FID[0x%08x] has unsupported type[%s]. \n",
                   map_entry_p[i].map_entry.params.nve.bridge_id, sx_fm_fid_type_str(fid_type));
            goto out;
        }

        sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_VNI_E, SX_ACCESS_CMD_DELETE, 1, NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR_RESOURCE_COND(sx_status, "Failed to delete VNI 0x%x to FID %u in RM, err = [%s]\n",
                                     map_entry_p[i].map_entry.params.nve.vni,
                                     map_entry_p[i].map_entry.params.nve.bridge_id,
                                     sx_status_str(sx_status));
            goto out;
        }

        /* Point of no return - all errors from this point on are fatal */

        switch (map_entry_p[i].map_entry.params.nve.direction) {
        case SX_TUNNEL_MAP_DIR_BIDIR:
            sx_status = sdk_fid_manager_hwfid_register_encap_vni_update(SX_ACCESS_CMD_DELETE,
                                                                        map_entry_p[i].map_entry.params.nve.bridge_id,
                                                                        map_entry_p[i].map_entry.params.nve.vni);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to set tunnel encap vni (%u) for fid (%u), err = %s.\n",
                           map_entry_p[i].map_entry.params.nve.vni, map_entry_p[i].map_entry.params.nve.bridge_id,
                           sx_status_str(sx_status));
                goto out;
            }

        /* fallthrough */
        case SX_TUNNEL_MAP_DIR_DECAP:
            sx_status =
                __hwd_tunnel_counter_info_with_lock_get(map_entry_p[i].decap_flow_counter_id,
                                                        &counter_locked, &counter_hw_type, &counter_hw_index);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to get counter's info, ID %u [%s]\n",
                           map_entry_p[i].decap_flow_counter_id,
                           sx_status_str(sx_status));
                goto out;
            }

            sx_status = sdk_fid_manager_tunnel_decap_mapping_set(SX_ACCESS_CMD_DELETE,
                                                                 map_entry_p[i].map_entry.params.nve.bridge_id,
                                                                 map_entry_p[i].map_entry.params.nve.vni,
                                                                 counter_hw_type, counter_hw_index,
                                                                 FALSE, 0);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to set tunnel decap vni (%u) for fid (%u), err = %s.\n",
                           map_entry_p[i].map_entry.params.nve.vni, map_entry_p[i].map_entry.params.nve.bridge_id,
                           sx_status_str(sx_status));
                goto out;
            }

            if (counter_locked == TRUE) {
                counter_locked = FALSE;
                sx_status =
                    __hwd_tunnel_counter_info_unlock(map_entry_p[i].decap_flow_counter_id);
                if (SX_CHECK_FAIL(sx_status)) {
                    SX_LOG_ERR("Failed to unlock counter, ID %u [%s]\n",
                               map_entry_p[i].decap_flow_counter_id,
                               sx_status_str(sx_status));
                    goto out;
                }
            }
            break;

        default:
            SX_LOG_ERR("Unexpected direction (%u), err = %s.\n",
                       map_entry_p[i].map_entry.params.nve.direction, sx_status_str(sx_status));
            goto out;
        }

        if (fid_type == SX_FM_FID_TYPE_VLAN_REWRITE_E) {
            sx_status = vlan_ref_cnt_decrease(0, map_entry_p[i].map_entry.params.nve.bridge_id);
        } else {
            sx_status = bridge_ref_cnt_decrease(map_entry_p[i].map_entry.params.nve.bridge_id);
        }

        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to decrease ref count of fid (%u), err = %s.\n",
                       map_entry_p[i].map_entry.params.nve.bridge_id, sx_status_str(sx_status));
            goto out;
        }
    }     /* for (i = 0; i < map_entry_cnt; i++) { */

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_port_isolate_hw_set(const sx_access_cmd_t         cmd,
                                           const sx_swid_t               swid,
                                           const sx_device_id_t          device_id,
                                           const sx_port_log_id_t        log_port,
                                           const sx_port_isolate_table_e isolation_table,
                                           const sx_port_log_id_t      * port_list_p,
                                           const uint32_t                log_port_num)
{
    sx_status_t            sx_status = SX_STATUS_SUCCESS;
    sxd_status_t           sxd_status = SXD_STATUS_SUCCESS;
    struct ku_tnifr_v2_reg tnifr_v2_reg_data;
    sxd_reg_meta_t         tnifr_reg_meta;

    SX_MEM_CLR(tnifr_v2_reg_data);
    SX_MEM_CLR(tnifr_reg_meta);

    SX_LOG_ENTER();

    TUNNEL_HWD_INIT_CHECK("tunnel port isolate set", sx_status);

    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        if (utils_check_pointer(port_list_p, "port_list_p")) {
            sx_status = SX_STATUS_PARAM_NULL;
            goto out;
        }

        if (log_port_num == 0) {
            SX_LOG_ERR("Failed to set nve port isolate, port list is empty\n");
            sx_status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    /* prepare TNIFR */
    if (SX_CHECK_FAIL(sx_status = hwd_tunnel_tnifr_prepare(cmd, swid, device_id, log_port, isolation_table,
                                                           port_list_p, log_port_num, &tnifr_v2_reg_data))) {
        goto out;
    }

    /* tnifr meta */
    tnifr_reg_meta.swid = swid;
    tnifr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    tnifr_reg_meta.dev_id = device_id;

    if (SXD_CHECK_PASS(sxd_status =
                           sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNIFR_V2_E, &tnifr_v2_reg_data,
                                                               &tnifr_reg_meta,
                                                               1, NULL, NULL))) {
        SX_LOG_INF("tnifr_v2: set isolation for tunnel port 0x%08X\n", log_port);
    } else {
        SX_LOG_ERR("Failed to access tnifr_v2 register: err - %s\n", SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_ttl_set(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                               hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                               const sx_tunnel_ttl_data_t  *ttl_data_p,
                               sx_tunnel_type_e             tunnel_type)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    struct ku_tigcr_reg     ku_tigcr_bcp;
    struct ku_tngcr_reg     ku_tngcr_bcp;
    hwd_tigcr_t            *tigcr_cfg = &g_global_config.tigcr_config;
    hwd_tngcr_t            *tngcr_cfg = &g_global_config.tngcr_config;
    hwd_tunnel_encap_data_t encap_data;
    sx_boot_mode_e          boot_mode = SX_BOOT_MODE_DISABLED_E;


    SX_MEM_CLR(encap_data);
    SX_MEM_CPY(ku_tigcr_bcp, g_global_config.tigcr_config.ku_tigcr);
    SX_MEM_CPY(ku_tngcr_bcp, g_global_config.tngcr_config.ku_tngcr);

    SX_LOG_ENTER();

    if (utils_check_pointer(ttl_data_p, "ttl_data_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    TUNNEL_HWD_INIT_CHECK("tunnel ttl set", sx_status);

    if (ttl_data_p->direction == SX_TUNNEL_DIRECTION_DECAP) {
        sx_status = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Configuration for decap TTL is not supported\n");
        goto out;
    }

    UNUSED_PARAM(tunnel_decap_handle);
    UNUSED_PARAM(tunnel_type);

    sx_status = hwd_encap_db_get(tunnel_encap_handle, &encap_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get encap data from HW DB for handle [%u], err - %s\n",
                   tunnel_encap_handle, sx_status_str(sx_status));
        goto out;
    }

    if (SX_CHECK_MAX(encap_data.type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
        switch (ttl_data_p->ttl_cmd) {
        case SX_TUNNEL_TTL_CMD_SET_E:
            tigcr_cfg->ku_tigcr.ipip_ttl_uc = ttl_data_p->ttl_value;
            tigcr_cfg->ku_tigcr.ipip_ttlc = SXD_TIGCR_TTLC_USE_CONFIG;
            break;

        case SX_TUNNEL_TTL_CMD_COPY_E:
            tigcr_cfg->ku_tigcr.ipip_ttlc = SXD_TIGCR_TTLC_COPY_FROM_PKT;
            break;

        default:
            SX_LOG_ERR("TTL command %d is unsupported for the tunnel\n",
                       ttl_data_p->ttl_cmd);
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        sx_status = hwd_tunnel_tigcr_reg_write(SXD_ACCESS_CMD_SET, &tigcr_cfg->ku_tigcr);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update TIGCR REG, err = %s.\n", sx_status_str(sx_status));
            SX_MEM_CPY(g_global_config.tigcr_config.ku_tigcr, ku_tigcr_bcp);
            goto out;
        }
    } else if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, encap_data.type, SX_TUNNEL_TYPE_NVE_MAX)) {
        switch (ttl_data_p->ttl_cmd) {
        case SX_TUNNEL_TTL_CMD_SET_E:
            tngcr_cfg->ku_tngcr.nve_ttl_uc = ttl_data_p->ttl_value;
            tngcr_cfg->ku_tngcr.nve_ttl_mc = ttl_data_p->ttl_value;
            break;

        case SX_TUNNEL_TTL_CMD_COPY_E:
        default:
            SX_LOG_ERR("TTL command %d is unsupported for the tunnel\n",
                       ttl_data_p->ttl_cmd);
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        sx_status = issu_boot_mode_get(&boot_mode);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get boot mode, err = %s.\n", sx_status_str(sx_status));
            SX_MEM_CPY(g_global_config.tngcr_config.ku_tngcr, ku_tngcr_bcp);
            goto out;
        }

        if (boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
            sx_status = hwd_tunnel_tngcr_reg_write(&tngcr_cfg->ku_tngcr);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to update TNGCR REG, err = %s.\n", sx_status_str(sx_status));
                SX_MEM_CPY(g_global_config.tngcr_config.ku_tngcr, ku_tngcr_bcp);
                goto out;
            }
        }
    } else {
        SX_LOG_ERR("Unsupported tunnel type [%u]\n", encap_data.type);
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
static sx_status_t __hwd_ipinip_tunnel_ttl_set_spc2(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                                    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                                    const sx_tunnel_ttl_data_t  *ttl_data_p)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    struct ku_tigcr_reg     ku_tigcr_bcp;
    hwd_tigcr_t            *tigcr_cfg = &g_global_config.tigcr_config;
    hwd_tunnel_encap_data_t encap_data;

    SX_MEM_CLR(encap_data);
    SX_MEM_CPY(ku_tigcr_bcp, g_global_config.tigcr_config.ku_tigcr);

    SX_LOG_ENTER();
    UNUSED_PARAM(tunnel_decap_handle);

    if (ttl_data_p->direction == SX_TUNNEL_DIRECTION_DECAP) {
        /* For IPinIP Tunnels we do not yet support configuring TTL in Decap Dir */
        sx_status = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Configuration for decap TTL is not supported for IPinIP Tunnels\n");
        goto out;
    } else if (ttl_data_p->direction == SX_TUNNEL_DIRECTION_ENCAP) {
        sx_status = hwd_encap_db_get(tunnel_encap_handle, &encap_data);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get encap data from HW DB, err - %s\n", sx_status_str(sx_status));
            goto out;
        }

        switch (ttl_data_p->ttl_cmd) {
        case SX_TUNNEL_TTL_CMD_SET_E:
            tigcr_cfg->ku_tigcr.ipip_ttl_uc = ttl_data_p->ttl_value;
            tigcr_cfg->ku_tigcr.ipip_ttlc = SXD_TIGCR_TTLC_USE_CONFIG;
            break;

        case SX_TUNNEL_TTL_CMD_COPY_E:
            tigcr_cfg->ku_tigcr.ipip_ttlc = SXD_TIGCR_TTLC_COPY_FROM_PKT;
            if (ttl_data_p->ttl_value != TUNNEL_TTL_VAL_RSVD) {
                tigcr_cfg->ku_tigcr.ipip_ttl_uc = ttl_data_p->ttl_value;
            } else {
                tigcr_cfg->ku_tigcr.ipip_ttl_uc = TUNNEL_IPINIP_UC_TTL_DEFAULT;
            }
            break;

        default:
            SX_LOG_ERR("TTL command %d is unsupported for IPinIP Tunnels\n",
                       ttl_data_p->ttl_cmd);
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }
    } else {
        sx_status = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Invalid direction [%u, %s] for TTL Set\n",
                   ttl_data_p->direction, sx_tunnel_direction_str(ttl_data_p->direction));
        goto out;
    }

    /* Write to TIGCR Register.
     * In IPinIP tunnels issu is set on set and doesn't require for special care */
    sx_status = hwd_tunnel_tigcr_reg_write(SXD_ACCESS_CMD_SET, &tigcr_cfg->ku_tigcr);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update TIGCR REG, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        /* revert the TIGCR cache with backup copy */
        SX_MEM_CPY(g_global_config.tigcr_config.ku_tigcr, ku_tigcr_bcp);
    }
    SX_LOG_EXIT();
    return sx_status;
}
static sx_status_t __hwd_nve_tunnel_ttl_set_spc2(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                                 hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                                 const sx_tunnel_ttl_data_t  *ttl_data_p)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    struct ku_tngcr_reg     ku_tngcr_bcp;
    hwd_tngcr_t            *tngcr_cfg = &g_global_config.tngcr_config;
    hwd_tunnel_encap_data_t encap_data;
    sx_boot_mode_e          boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_MEM_CLR(encap_data);
    SX_MEM_CPY(ku_tngcr_bcp, g_global_config.tngcr_config.ku_tngcr);

    SX_LOG_ENTER();
    UNUSED_PARAM(tunnel_decap_handle);

    if (ttl_data_p->direction == SX_TUNNEL_DIRECTION_DECAP) {
        switch (ttl_data_p->ttl_cmd) {
        case SX_TUNNEL_TTL_CMD_COPY_E:
            tngcr_cfg->ku_tngcr.nve_decap_ttl = SXD_TNGCR_NVE_DECAP_TTL_COPY_E;
            break;

        case SX_TUNNEL_TTL_CMD_PRESERVE_E:
            tngcr_cfg->ku_tngcr.nve_decap_ttl = SXD_TNGCR_NVE_DECAP_TTL_PRESERVE_E;
            break;

        case SX_TUNNEL_TTL_CMD_MINIMUM_E:
            tngcr_cfg->ku_tngcr.nve_decap_ttl = SXD_TNGCR_NVE_DECAP_TTL_MINIMUM_E;
            break;

        default:
            SX_LOG_ERR("TTL command %d is unsupported for NVE tunnels in Decap Direction \n",
                       ttl_data_p->ttl_cmd);
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }
    } else if (ttl_data_p->direction == SX_TUNNEL_DIRECTION_ENCAP) {
        sx_status = hwd_encap_db_get(tunnel_encap_handle, &encap_data);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get encap data from HW DB for handle [%u], err - %s\n",
                       tunnel_encap_handle, sx_status_str(sx_status));
            goto out;
        }
        switch (ttl_data_p->ttl_cmd) {
        case SX_TUNNEL_TTL_CMD_SET_E:
            tngcr_cfg->ku_tngcr.nve_ttlc = SXD_TNGCR_TTLC_USE_CONFIG;
            tngcr_cfg->ku_tngcr.nve_ttl_uc = ttl_data_p->ttl_value;
            tngcr_cfg->ku_tngcr.nve_ttl_mc = ttl_data_p->ttl_value;
            break;

        case SX_TUNNEL_TTL_CMD_COPY_E:
            tngcr_cfg->ku_tngcr.nve_ttlc = SXD_TNGCR_TTLC_COPY_FROM_PKT;
            if (ttl_data_p->ttl_value != TUNNEL_TTL_VAL_RSVD) {
                tngcr_cfg->ku_tngcr.nve_ttl_uc = ttl_data_p->ttl_value;
                tngcr_cfg->ku_tngcr.nve_ttl_mc = ttl_data_p->ttl_value;
            } else {
                tngcr_cfg->ku_tngcr.nve_ttl_uc = TUNNEL_NVE_UC_TTL_DEFAULT;
                tngcr_cfg->ku_tngcr.nve_ttl_mc = TUNNEL_NVE_MC_TTL_DEFAULT;
            }

            break;

        default:
            SX_LOG_ERR("TTL command %d is unsupported for NVE tunnels in Encap Direction \n",
                       ttl_data_p->ttl_cmd);
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }
    } else {
        sx_status = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Invalid direction [%u, %s] for TTL Set\n",
                   ttl_data_p->direction, sx_tunnel_direction_str(ttl_data_p->direction));
        goto out;
    }
    /* Write to TNGCR
     * issu needs to have special handling of  NVE tunnels due to the underlay rif/vrid.
     */
    sx_status = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get boot mode, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
        sx_status = hwd_tunnel_tngcr_reg_write(&tngcr_cfg->ku_tngcr);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update TNGCR REG, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }
    }
out:
    if (SX_CHECK_FAIL(sx_status)) {
        /* Revert the TNGCR cached value to the backup copy */
        SX_MEM_CPY(g_global_config.tngcr_config.ku_tngcr, ku_tngcr_bcp);
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_ttl_set_spc2(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                    const sx_tunnel_ttl_data_t  *ttl_data_p,
                                    sx_tunnel_type_e             tunnel_type)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(ttl_data_p, "ttl_data_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    TUNNEL_HWD_INIT_CHECK("tunnel ttl set", sx_status);

    if (SX_CHECK_MAX(tunnel_type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
        sx_status = __hwd_ipinip_tunnel_ttl_set_spc2(tunnel_encap_handle, tunnel_decap_handle, ttl_data_p);
    } else if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, tunnel_type, SX_TUNNEL_TYPE_NVE_MAX)) {
        sx_status = __hwd_nve_tunnel_ttl_set_spc2(tunnel_encap_handle, tunnel_decap_handle, ttl_data_p);
    } else {
        SX_LOG_ERR("Unsupported tunnel type [%u, %s]\n", tunnel_type, sx_tunnel_type_str(tunnel_type));
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_ttl_get(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                               hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                               sx_tunnel_ttl_data_t        *ttl_data_p,
                               sx_tunnel_type_e             tunnel_type)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    hwd_tigcr_t            *tigcr_cfg = &g_global_config.tigcr_config;
    hwd_tngcr_t            *tngcr_cfg = &g_global_config.tngcr_config;
    hwd_tunnel_encap_data_t encap_data;

    SX_MEM_CLR(encap_data);

    SX_LOG_ENTER();

    if (utils_check_pointer(ttl_data_p, "ttl_data_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    TUNNEL_HWD_INIT_CHECK("tunnel ttl get", sx_status);

    if (ttl_data_p->direction == SX_TUNNEL_DIRECTION_DECAP) {
        /* Configuration for decap TTL is not supported, so return default config. */
        ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_COPY_E;
        goto out;
    }

    UNUSED_PARAM(tunnel_decap_handle);
    UNUSED_PARAM(tunnel_type);

    sx_status = hwd_encap_db_get(tunnel_encap_handle, &encap_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get encap data from HW DB for handle [%u], err - %s\n",
                   tunnel_encap_handle, sx_status_str(sx_status));
        goto out;
    }

    if (SX_CHECK_MAX(encap_data.type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
        switch (tigcr_cfg->ku_tigcr.ipip_ttlc) {
        case SXD_TIGCR_TTLC_USE_CONFIG:
            ttl_data_p->ttl_value = tigcr_cfg->ku_tigcr.ipip_ttl_uc;
            ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_SET_E;
            break;

        case SXD_TIGCR_TTLC_COPY_FROM_PKT:
            ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_COPY_E;
            break;

        default:
            SX_LOG_ERR("Unknown TTL cmd [%u]\n", tigcr_cfg->ku_tigcr.ipip_ttlc);
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
    } else if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, encap_data.type, SX_TUNNEL_TYPE_NVE_MAX)) {
        ttl_data_p->ttl_value = tngcr_cfg->ku_tngcr.nve_ttl_uc;
        ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_SET_E;
    } else {
        SX_LOG_ERR("Unsupported tunnel type [%u]\n", encap_data.type);
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_ipinip_tunnel_ttl_get_spc2(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                                    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                                    sx_tunnel_ttl_data_t        *ttl_data_p)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    hwd_tigcr_t            *tigcr_cfg = &g_global_config.tigcr_config;
    hwd_tunnel_encap_data_t encap_data;

    SX_MEM_CLR(encap_data);
    UNUSED_PARAM(tunnel_decap_handle);

    SX_LOG_ENTER();

    if (ttl_data_p->direction == SX_TUNNEL_DIRECTION_DECAP) {
        /* Configuration for decap TTL is not supported for IPinIP, so return default config. */
        ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_COPY_E;
        ttl_data_p->ttl_value = TUNNEL_TTL_VAL_RSVD;     /* TIGCR field is reserved so return 0 */
        goto out;
    } else if (ttl_data_p->direction == SX_TUNNEL_DIRECTION_ENCAP) {
        sx_status = hwd_encap_db_get(tunnel_encap_handle, &encap_data);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get encap data from HW DB for handle [%u], err - %s\n",
                       tunnel_encap_handle, sx_status_str(sx_status));
            goto out;
        }

        switch (tigcr_cfg->ku_tigcr.ipip_ttlc) {
        case SXD_TIGCR_TTLC_USE_CONFIG:
            ttl_data_p->ttl_value = tigcr_cfg->ku_tigcr.ipip_ttl_uc;
            ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_SET_E;
            break;

        case SXD_TIGCR_TTLC_COPY_FROM_PKT:
            ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_COPY_E;
            ttl_data_p->ttl_value = TUNNEL_TTL_VAL_RSVD;         /* TIGCR field is reserved so return 0 */
            break;

        default:
            SX_LOG_ERR("Unknown TTL cmd [%u] for IPinIP Tunnels \n", tigcr_cfg->ku_tigcr.ipip_ttlc);
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
    } else {
        sx_status = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Invalid direction [%u, %s] for IPinIP TTL Get\n",
                   ttl_data_p->direction, sx_tunnel_direction_str(ttl_data_p->direction));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_nve_tunnel_ttl_get_spc2(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                                 hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                                 sx_tunnel_ttl_data_t        *ttl_data_p)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    hwd_tngcr_t            *tngcr_cfg = &g_global_config.tngcr_config;
    hwd_tunnel_encap_data_t encap_data;

    SX_MEM_CLR(encap_data);
    UNUSED_PARAM(tunnel_encap_handle);
    UNUSED_PARAM(tunnel_decap_handle);

    SX_LOG_ENTER();

    if (ttl_data_p->direction == SX_TUNNEL_DIRECTION_DECAP) {
        /* in all cases the ttl value is reserved */
        ttl_data_p->ttl_value = TUNNEL_TTL_VAL_RSVD;

        switch (tngcr_cfg->ku_tngcr.nve_decap_ttl) {
        case SXD_TNGCR_NVE_DECAP_TTL_COPY_E:
            ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_COPY_E;
            break;

        case SXD_TNGCR_NVE_DECAP_TTL_PRESERVE_E:
            ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_PRESERVE_E;
            break;

        case SXD_TNGCR_NVE_DECAP_TTL_MINIMUM_E:
            ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_MINIMUM_E;
            break;

        default:
            SX_LOG_ERR("Unknown TTL command %d for NVE tunnels in Decap Direction \n",
                       tngcr_cfg->ku_tngcr.nve_decap_ttl);
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
    } else if (ttl_data_p->direction == SX_TUNNEL_DIRECTION_ENCAP) {
        switch (tngcr_cfg->ku_tngcr.nve_ttlc) {
        case SXD_TNGCR_TTLC_USE_CONFIG:
            ttl_data_p->ttl_value = tngcr_cfg->ku_tngcr.nve_ttl_uc;
            ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_SET_E;
            break;

        case SXD_TNGCR_TTLC_COPY_FROM_PKT:
            ttl_data_p->ttl_cmd = SX_TUNNEL_TTL_CMD_COPY_E;
            ttl_data_p->ttl_value = TUNNEL_TTL_VAL_RSVD;         /* TNGCR field is reserved so return 0 */
            break;

        default:
            SX_LOG_ERR("Unknown TTL cmd  [%u] for NVE Tunnels \n", tngcr_cfg->ku_tngcr.nve_ttlc);
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
    } else {
        sx_status = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Invalid direction [%u, %s] for NVE TTL Get\n",
                   ttl_data_p->direction, sx_tunnel_direction_str(ttl_data_p->direction));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}
sx_status_t hwd_tunnel_ttl_get_spc2(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                    sx_tunnel_ttl_data_t        *ttl_data_p,
                                    sx_tunnel_type_e             tunnel_type)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(ttl_data_p, "ttl_data_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    TUNNEL_HWD_INIT_CHECK("tunnel ttl get", sx_status);

    if (SX_CHECK_MAX(tunnel_type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
        sx_status = __hwd_ipinip_tunnel_ttl_get_spc2(tunnel_encap_handle,
                                                     tunnel_decap_handle,
                                                     ttl_data_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get HWD TTL Configuration for IPinIP Tunnels\n");
            goto out;
        }
    } else if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, tunnel_type, SX_TUNNEL_TYPE_NVE_MAX)) {
        sx_status = __hwd_nve_tunnel_ttl_get_spc2(tunnel_encap_handle,
                                                  tunnel_decap_handle,
                                                  ttl_data_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get HWD TTL Configuration for NVE Tunnels\n");
            goto out;
        }
    } else {
        SX_LOG_ERR("Unsupported tunnel type [%u, %s]\n", tunnel_type, sx_tunnel_type_str(tunnel_type));
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
static sx_status_t parse_hash_data_ipinip(sx_tunnel_type_e             tun_type,
                                          const sx_tunnel_hash_data_t *hash_data_p,
                                          hwd_tigcr_t                 *tigcr_cfg)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (hash_data_p->hash_field_type) {
    case SX_TUNNEL_HASH_FIELD_TYPE_IPV6_FLOW_LABEL_E:
        /* Suppose use this case when IPv6 support is added */
        if ((tun_type == SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4) ||
            (tun_type == SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE)) {
            SX_LOG_ERR("Hash field %d is unsupported for the tunnel\n",
                       hash_data_p->hash_field_type);
            sx_status = SX_STATUS_UNSUPPORTED;
            break;
        }

        tigcr_cfg->ku_tigcr.ipip_flh = SXD_TUNNEL_FLH_NO_LABEL;

        switch (hash_data_p->hash_cmd) {
        case SX_TUNNEL_HASH_CMD_SET_ZERO_E:
            tigcr_cfg->ku_tigcr.ipip_flc = SXD_TUNNEL_FLC_COPY_FROM_PKT;
            break;

        case SX_TUNNEL_HASH_CMD_CALCULATE_E:
            tigcr_cfg->ku_tigcr.ipip_flc = SXD_TUNNEL_FLC_CALCULATE;
            if (g_global_config.general_params.ipinip.encap_flowlabel) {
                tigcr_cfg->ku_tigcr.ipip_flh = SXD_TUNNEL_FLH_CALCULATE;
                tigcr_cfg->ku_tigcr.ipip_fl_prefix = g_global_config.general_params.ipinip.encap_flowlabel;
            }
            break;

        default:
            SX_LOG_ERR("Hash cmd %d is unsupported for the tunnel\n",
                       hash_data_p->hash_cmd);
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        break;

    case SX_TUNNEL_HASH_FIELD_TYPE_UDP_SPORT_E:
    default:
        SX_LOG_ERR("Hash field %d is unsupported for the tunnel\n",
                   hash_data_p->hash_field_type);
        sx_status = SX_STATUS_UNSUPPORTED;
        break;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t parse_hash_data_nve(sx_tunnel_type_e             tun_type,
                                       const sx_tunnel_hash_data_t *hash_data_p,
                                       hwd_tngcr_t                 *tngcr_cfg_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (hash_data_p->hash_field_type) {
    case SX_TUNNEL_HASH_FIELD_TYPE_IPV6_FLOW_LABEL_E:

        tngcr_cfg_p->ku_tngcr.nve_flh = SXD_TUNNEL_FLH_NO_LABEL;

        switch (hash_data_p->hash_cmd) {
        case SX_TUNNEL_HASH_CMD_SET_ZERO_E:
            tngcr_cfg_p->ku_tngcr.nve_flc = SXD_TUNNEL_FLC_COPY_FROM_PKT;
            break;

        case SX_TUNNEL_HASH_CMD_CALCULATE_E:
            tngcr_cfg_p->ku_tngcr.nve_flc = SXD_TUNNEL_FLC_CALCULATE;
            if (g_global_config.general_params.nve.encap_flowlabel) {
                tngcr_cfg_p->ku_tngcr.nve_flh = SXD_TUNNEL_FLH_CALCULATE;
                tngcr_cfg_p->ku_tngcr.nve_fl_prefix = g_global_config.general_params.nve.encap_flowlabel;
            }
            break;

        default:
            SX_LOG_ERR("Hash cmd %d is unsupported for the tunnel\n",
                       hash_data_p->hash_cmd);
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        break;

    case SX_TUNNEL_HASH_FIELD_TYPE_UDP_SPORT_E:

        if ((tun_type == SX_TUNNEL_TYPE_NVE_NVGRE) || (tun_type == SX_TUNNEL_TYPE_NVE_NVGRE_IPV6)) {
            SX_LOG_ERR("Hash field sport is not supported for NVGRE.\n");
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix = 0;
        if (utils_check_pointer(g_hwd_tunnel_internal_callbacks.hwd_tunnel_nve_udp_sport_hash_and_fix_update_pfn,
                                "hwd_tunnel_nve_udp_sport_hash_and_fix_update_pfn")) {
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        sx_status = g_hwd_tunnel_internal_callbacks.hwd_tunnel_nve_udp_sport_hash_and_fix_update_pfn(hash_data_p,
                                                                                                     tngcr_cfg_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update nve_udp sport hash and fix bits, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Hash field %d is unsupported for the tunnel\n",
                   hash_data_p->hash_field_type);
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_hash_set(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                const sx_tunnel_hash_data_t *hash_data_p)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    struct ku_tigcr_reg     ku_tigcr_bcp;
    struct ku_tngcr_reg     ku_tngcr_bcp;
    hwd_tigcr_t            *tigcr_cfg = &g_global_config.tigcr_config;
    hwd_tngcr_t            *tngcr_cfg_p = &g_global_config.tngcr_config;
    hwd_tunnel_encap_data_t encap_data;
    sx_boot_mode_e          boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_MEM_CLR(encap_data);
    SX_MEM_CPY(ku_tigcr_bcp, tigcr_cfg->ku_tigcr);
    SX_MEM_CPY(ku_tngcr_bcp, tngcr_cfg_p->ku_tngcr);

    SX_LOG_ENTER();

    if (utils_check_pointer(hash_data_p, "hash_data_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    TUNNEL_HWD_INIT_CHECK("tunnel hash set", sx_status);

    UNUSED_PARAM(tunnel_decap_handle);

    sx_status = hwd_encap_db_get(tunnel_encap_handle, &encap_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get encap data from HW DB for handle [%u], err - %s\n",
                   tunnel_encap_handle, sx_status_str(sx_status));
        goto out;
    }

    if (SX_CHECK_MAX(encap_data.type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
        sx_status = parse_hash_data_ipinip(encap_data.type, hash_data_p, tigcr_cfg);
        if (SX_CHECK_FAIL(sx_status)) {
            goto out;
        }

        sx_status = hwd_tunnel_tigcr_reg_write(SXD_ACCESS_CMD_SET, &tigcr_cfg->ku_tigcr);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update TIGCR REG, err = %s.\n", sx_status_str(sx_status));
            SX_MEM_CPY(g_global_config.tigcr_config.ku_tigcr, ku_tigcr_bcp);
            goto out;
        }
    } else if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, encap_data.type, SX_TUNNEL_TYPE_NVE_MAX)) {
        sx_status = parse_hash_data_nve(encap_data.type, hash_data_p, tngcr_cfg_p);
        if (SX_CHECK_FAIL(sx_status)) {
            goto out;
        }

        sx_status = issu_boot_mode_get(&boot_mode);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get boot mode, err = %s.\n", sx_status_str(sx_status));
            SX_MEM_CPY(g_global_config.tngcr_config.ku_tngcr, ku_tngcr_bcp);
            goto out;
        }

        if (boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
            sx_status = hwd_tunnel_tngcr_reg_write(&tngcr_cfg_p->ku_tngcr);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to update TNGCR REG, err = %s.\n", sx_status_str(sx_status));
                SX_MEM_CPY(g_global_config.tngcr_config.ku_tngcr, ku_tngcr_bcp);
                goto out;
            }
        }
    } else {
        SX_LOG_ERR("Unsupported tunnel type [%u]\n", encap_data.type);
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_hash_get(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                sx_tunnel_hash_data_t       *hash_data_p)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    hwd_tigcr_t            *tigcr_cfg = &g_global_config.tigcr_config;
    hwd_tngcr_t            *tngcr_cfg_p = &g_global_config.tngcr_config;
    hwd_tunnel_encap_data_t encap_data;

    SX_MEM_CLR(encap_data);

    SX_LOG_ENTER();

    if (utils_check_pointer(hash_data_p, "hash_data_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    TUNNEL_HWD_INIT_CHECK("tunnel hash get", sx_status);

    UNUSED_PARAM(tunnel_decap_handle);

    sx_status = hwd_encap_db_get(tunnel_encap_handle, &encap_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get encap data from HW DB for handle [%u], err - %s\n",
                   tunnel_encap_handle, sx_status_str(sx_status));
        goto out;
    }

    if (SX_CHECK_MAX(encap_data.type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
        switch (hash_data_p->hash_field_type) {
        case SX_TUNNEL_HASH_FIELD_TYPE_IPV6_FLOW_LABEL_E:
            /* Suppose use this case when IPv6 support is added */
            if ((encap_data.type == SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4) ||
                (encap_data.type == SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE)) {
                SX_LOG_ERR("Hash field %d is unsupported for the tunnel\n",
                           hash_data_p->hash_field_type);
                sx_status = SX_STATUS_UNSUPPORTED;
                goto out;
            }

            switch (tigcr_cfg->ku_tigcr.ipip_flc) {
            case SXD_TUNNEL_FLC_COPY_FROM_PKT:
                hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_SET_ZERO_E;
                break;

            case SXD_TUNNEL_FLC_CALCULATE:
                hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_CALCULATE_E;
                break;

            default:
                SX_LOG_ERR("Unknown flow command [%u]\n", tigcr_cfg->ku_tigcr.ipip_flc);
                sx_status = SX_STATUS_ERROR;
                goto out;
            }
            break;

        case SX_TUNNEL_HASH_FIELD_TYPE_UDP_SPORT_E:
        default:
            SX_LOG_ERR("Hash field %d is unsupported for the tunnel\n",
                       hash_data_p->hash_field_type);
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }
    } else if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, encap_data.type, SX_TUNNEL_TYPE_NVE_MAX)) {
        switch (hash_data_p->hash_field_type) {
        case SX_TUNNEL_HASH_FIELD_TYPE_IPV6_FLOW_LABEL_E:

            switch (tngcr_cfg_p->ku_tngcr.nve_flc) {
            case SXD_TUNNEL_FLC_COPY_FROM_PKT:
                hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_SET_ZERO_E;
                break;

            case SXD_TUNNEL_FLC_CALCULATE:
                hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_CALCULATE_E;
                break;

            default:
                SX_LOG_ERR("Unknown flow command [%u]\n", tngcr_cfg_p->ku_tngcr.nve_flc);
                sx_status = SX_STATUS_ERROR;
                goto out;
            }
            break;

        case SX_TUNNEL_HASH_FIELD_TYPE_UDP_SPORT_E:
            if ((encap_data.type == SX_TUNNEL_TYPE_NVE_NVGRE) || (encap_data.type == SX_TUNNEL_TYPE_NVE_NVGRE_IPV6)) {
                SX_LOG_ERR("Hash field sport is not supported for NVGRE.\n");
                sx_status = SX_STATUS_UNSUPPORTED;
                goto out;
            }

            sx_status = g_hwd_tunnel_internal_callbacks.hwd_tunnel_nve_udp_sport_hash_and_fix_update_get_pfn(
                tngcr_cfg_p,
                hash_data_p);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to update nve_udp sport hash and fix bits, err = %s.\n", sx_status_str(sx_status));
                goto out;
            }

            break;

        default:
            SX_LOG_ERR("Hash field %d is unsupported for the tunnel\n",
                       hash_data_p->hash_field_type);
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }
    } else {
        SX_LOG_ERR("Unsupported tunnel type [%u]\n", encap_data.type);
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_tunnel_cos_global_attr_set(const hwd_tunnel_qos_tunnel_type_t tunnel_type,
                                                    const sx_tunnel_cos_data_t        *cos_data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0, j = 0;

    SX_LOG_ENTER();

    switch (cos_data_p->param_type) {
    case SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E:
        g_global_config.cos_attr[tunnel_type].encap_cos_data.dscp_action = cos_data_p->dscp_action;
        g_global_config.cos_attr[tunnel_type].encap_cos_data.dscp_rewrite = cos_data_p->dscp_rewrite;
        g_global_config.cos_attr[tunnel_type].encap_cos_data.dscp_value = cos_data_p->dscp_value;
        g_global_config.cos_attr[tunnel_type].encap_cos_data.param_type = cos_data_p->param_type;
        g_global_config.cos_attr[tunnel_type].encap_cos_data.update_priority_color = cos_data_p->update_priority_color;
        g_global_config.cos_attr[tunnel_type].encap_cos_data.prio_color = cos_data_p->prio_color;
        for (i = 0; i <= COS_ECN_MAX_NUM; ++i) {
            if (cos_data_p->cos_ecn_params.ecn_encap.ecn_encap_map[i].valid) {
                g_global_config.cos_attr[tunnel_type].encap_cos_data.cos_ecn_params.ecn_encap.ecn_encap_map[i].
                egress_ecn =
                    cos_data_p->cos_ecn_params.ecn_encap.ecn_encap_map[i].egress_ecn;
            }
        }
        break;

    case SX_TUNNEL_COS_PARAM_TYPE_DECAP_E:
        g_global_config.cos_attr[tunnel_type].decap_cos_data.dscp_action = cos_data_p->dscp_action;
        g_global_config.cos_attr[tunnel_type].decap_cos_data.dscp_rewrite = cos_data_p->dscp_rewrite;
        g_global_config.cos_attr[tunnel_type].decap_cos_data.dscp_value = cos_data_p->dscp_value;
        g_global_config.cos_attr[tunnel_type].decap_cos_data.param_type = cos_data_p->param_type;
        g_global_config.cos_attr[tunnel_type].decap_cos_data.update_priority_color = cos_data_p->update_priority_color;
        g_global_config.cos_attr[tunnel_type].decap_cos_data.prio_color = cos_data_p->prio_color;
        for (i = 0; i <= COS_ECN_MAX_NUM; ++i) {
            for (j = 0; j <= COS_ECN_MAX_NUM; ++j) {
                if (cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].valid) {
                    g_global_config.cos_attr[tunnel_type].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].
                    egress_ecn =
                        cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].egress_ecn;

                    g_global_config.cos_attr[tunnel_type].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].
                    trap_enable =
                        cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_enable;

                    if (cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_enable) {
                        g_global_config.cos_attr[tunnel_type].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][
                            j].trap_attr =
                            cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_attr;
                    }
                }
            }
        }
        break;

    default:
        SX_LOG_ERR("Can't set CoS attribute. Invalid CoS param type (need to be encap or decap) \n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_tunnel_cos_default_reg_set(const sx_tunnel_type_e      tunnel_type,
                                                    const sx_tunnel_cos_data_t *cos_data_p)
{
    struct ku_tnqdr_reg   ku_tnqdr_reg;
    struct ku_tiqdr_reg   ku_tiqdr_reg;
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_status_t           sx_status_free = SX_STATUS_SUCCESS;
    sx_device_id_t        device_id = 1;
    sx_swid_id_t          swid = 0;
    uint32_t              port_num = 0;
    sx_port_attributes_t *port_attributes_p = NULL;
    uint32_t              device_index = 0, dev_num = 0, port_index = 0;
    sx_device_info_t     *device_info_list_p = NULL;

    SX_LOG_ENTER();
    SX_MEM_CLR(ku_tnqdr_reg);
    SX_MEM_CLR(ku_tiqdr_reg);

    /*get number of devices*/
    err = port_device_list_get(SX_ACCESS_CMD_COUNT, NULL, &dev_num);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve number of devices  (%s).\n",
                   sx_status_str(err));
        goto out;
    }
    /*allocate memory and get device list*/
    err = utils_clr_memory_get((void**)(&device_info_list_p), 1,
                               dev_num * sizeof(sx_device_info_t), UTILS_MEM_TYPE_ID_TUNNEL_E);
    if (device_info_list_p == NULL) {
        SX_LOG_ERR("Failed in memory allocation (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    err = port_device_list_get(SX_ACCESS_CMD_GET, device_info_list_p, &dev_num);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve device info (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    for (device_index = 0; device_index < dev_num; device_index++) {
        device_id = device_info_list_p[device_index].dev_id;
        /*get device's number of ports*/
        err = port_device_get(SX_ACCESS_CMD_COUNT, device_id, swid, NULL, &port_num);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" Failed to retrieve number of ports on device (%u)"
                       "and swid (%u)  (%s).\n",
                       device_id, swid, sx_status_str(err));
            goto out;
        }

        if (port_num == 0) {
            continue;
        }
        err = utils_clr_memory_get((void**)(&port_attributes_p), 1,
                                   port_num * sizeof(sx_port_attributes_t), UTILS_MEM_TYPE_ID_TUNNEL_E);
        if (port_attributes_p == NULL) {
            SX_LOG_ERR("Failed in memory allocation (%s).\n", sx_status_str(err));
            goto out;
        }

        /*get device logical ports list*/
        err = port_device_get(SX_ACCESS_CMD_GET, device_id, swid, port_attributes_p, &port_num);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" Failed to retrieve ports info on device (%u) and swid (%u)  (%s).\n",
                       device_id, swid, sx_status_str(err));
            goto out;
        }

        /*default param TIQDR*/
        ku_tiqdr_reg.dscp = cos_data_p->dscp_value;
        ku_tiqdr_reg.switch_prio = cos_data_p->prio_color.priority;
        ku_tiqdr_reg.color = cos_data_p->prio_color.color;

        /*default param TNQDR*/
        ku_tnqdr_reg.dscp = cos_data_p->dscp_value;
        ku_tnqdr_reg.switch_prio = cos_data_p->prio_color.priority;
        ku_tnqdr_reg.color = cos_data_p->prio_color.color;

        /*for each port update tnqdr and tiqdr*/
        for (port_index = 0; port_index < port_num; port_index++) {
            if (SX_PORT_TYPE_ID_GET(port_attributes_p[port_index].log_port) != SX_PORT_TYPE_NETWORK) {
                continue;
            }
            switch (tunnel_type) {
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
                SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(ku_tiqdr_reg.local_port, ku_tiqdr_reg.lp_msb,
                                                    SX_PORT_PHY_ID_GET(port_attributes_p[port_index].log_port));

                err = hwd_tunnel_tiqdr_reg_write(SXD_ACCESS_CMD_SET, &ku_tiqdr_reg);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Can't set CoS IPinIP default attribute. hwd_tunnel_tiqdr_reg_write failed  %s\n",
                               sx_status_str(err));
                    goto out;
                }
                break;

            case SX_TUNNEL_TYPE_NVE_VXLAN:
            case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
            case SX_TUNNEL_TYPE_NVE_GENEVE:
            case SX_TUNNEL_TYPE_NVE_NVGRE:
            case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
            case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
                SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(ku_tnqdr_reg.local_port,
                                                    ku_tnqdr_reg.lp_msb,
                                                    SX_PORT_PHY_ID_GET(port_attributes_p[port_index].log_port));

                err = hwd_tunnel_tnqdr_reg_write(SXD_ACCESS_CMD_SET, &ku_tnqdr_reg);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Can't set CoS VXLAN default attribute. hwd_tunnel_tnqdr_reg_write failed  %s\n",
                               sx_status_str(err));
                    goto out;
                }
                break;

            default:
                SX_LOG_ERR("Can't set CoS default attribute. tunnel type not supported for CoS attribute hwd\n");
                err = SX_STATUS_UNSUPPORTED;
                goto out;
            }
        }

        if (port_attributes_p != NULL) {
            err = utils_memory_put(port_attributes_p, UTILS_MEM_TYPE_ID_TUNNEL_E);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("failed to free port list  %s\n", sx_status_str(err));
                goto out;
            }
            port_attributes_p = NULL;
        }
    } /*Device for loop*/

out:
    if (port_attributes_p != NULL) {
        sx_status_free = utils_memory_put(port_attributes_p, UTILS_MEM_TYPE_ID_TUNNEL_E);
        if (SX_CHECK_FAIL(sx_status_free)) {
            SX_LOG_ERR("failed to free port list  %s\n", sx_status_str(sx_status_free));
            return sx_status_free;
        }
    }
    if (device_info_list_p != NULL) {
        sx_status_free = utils_memory_put(device_info_list_p, UTILS_MEM_TYPE_ID_TUNNEL_E);
        if (SX_CHECK_FAIL(sx_status_free)) {
            SX_LOG_ERR("failed to free device list  %s\n", sx_status_str(sx_status_free));
            return sx_status_free;
        }
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_tunnel_cos_ipinip_set(const hwd_tunnel_qos_tunnel_type_t tunnel_type,
                                               const sx_tunnel_cos_data_t        *cos_data_p)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    struct ku_tiqcr_reg  ku_tiqcr_reg;
    struct ku_tieem_reg  ku_tieem;
    struct ku_tidem_reg  ku_tidem;
    uint32_t             i = 0, j = 0;
    sx_tunnel_cos_data_t cos_global_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(ku_tiqcr_reg);
    SX_MEM_CLR(ku_tieem);
    SX_MEM_CLR(ku_tidem);
    SX_MEM_CLR(cos_global_attr);

    switch (cos_data_p->param_type) {
    case SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E:

        /* set the values of DECAP cos from db */
        cos_global_attr.param_type = SX_TUNNEL_COS_PARAM_TYPE_DECAP_E;
        err = __hwd_tunnel_cos_global_attr_get(tunnel_type, &cos_global_attr);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Can't get CoS global attribute. __hwd_tunnel_cos_global_attr_get failed  %s\n",
                       sx_status_str(err));
            goto out;
        }
        ku_tiqcr_reg.dec_dscp_rw = cos_global_attr.dscp_rewrite;
        ku_tiqcr_reg.dec_set_dscp =
            (cos_global_attr.dscp_action == SX_COS_DSCP_ACTION_COPY_E) ? SXD_TUNNEL_DEC_DSCP_COPY :
            SXD_TUNNEL_DEC_DSCP_PRESERVE;
        ku_tiqcr_reg.dec_set_sp = (cos_global_attr.update_priority_color == TRUE) ? SXD_TUNNEL_DEC_SP_SET :
                                  SXD_TUNNEL_DEC_SP_PRESERVE;

        /*TIQCR update*/
        ku_tiqcr_reg.enc_dscp_rw = cos_data_p->dscp_rewrite;
        ku_tiqcr_reg.enc_set_dscp = (cos_data_p->dscp_action == SX_COS_DSCP_ACTION_COPY_E) ? SXD_TUNNEL_ENC_DSCP_COPY :
                                    SXD_TUNNEL_ENC_DSCP_SET;
        ku_tiqcr_reg.enc_set_sp = (cos_data_p->update_priority_color == TRUE) ? SXD_TUNNEL_ENC_SP_SET :
                                  SXD_TUNNEL_ENC_SP_PRESERVE;

        /*TIEEM update*/
        for (i = 0; i <= COS_ECN_MAX_NUM; i++) {
            if (!cos_data_p->cos_ecn_params.ecn_encap.ecn_encap_map[i].valid) {
                continue;
            }

            ku_tieem.overlay_ecn = i;
            ku_tieem.underlay_ecn = cos_data_p->cos_ecn_params.ecn_encap.ecn_encap_map[i].egress_ecn;
            err = hwd_tunnel_tieem_reg_write(SXD_ACCESS_CMD_SET, &ku_tieem);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set TIEEM REG for overlay ecn [%u].\n", i);
                goto out;
            }
        }
        break;

    case SX_TUNNEL_COS_PARAM_TYPE_DECAP_E:

        /* set the values of ENCAP cos from db */
        cos_global_attr.param_type = SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E;
        err = __hwd_tunnel_cos_global_attr_get(tunnel_type, &cos_global_attr);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Can't get CoS global attribute. __hwd_tunnel_cos_global_attr_get failed  %s\n",
                       sx_status_str(err));
            goto out;
        }
        ku_tiqcr_reg.enc_dscp_rw = cos_global_attr.dscp_rewrite;
        ku_tiqcr_reg.enc_set_dscp =
            (cos_global_attr.dscp_action == SX_COS_DSCP_ACTION_COPY_E) ? SXD_TUNNEL_ENC_DSCP_COPY :
            SXD_TUNNEL_ENC_DSCP_SET;
        ku_tiqcr_reg.enc_set_sp = (cos_global_attr.update_priority_color == TRUE) ? SXD_TUNNEL_ENC_SP_SET :
                                  SXD_TUNNEL_ENC_SP_PRESERVE;

        /* tiqcr update DECAP value with new configuration */
        ku_tiqcr_reg.dec_dscp_rw = cos_data_p->dscp_rewrite;
        ku_tiqcr_reg.dec_set_dscp = (cos_data_p->dscp_action == SX_COS_DSCP_ACTION_COPY_E) ? SXD_TUNNEL_DEC_DSCP_COPY :
                                    SXD_TUNNEL_DEC_DSCP_PRESERVE;
        ku_tiqcr_reg.dec_set_sp = (cos_data_p->update_priority_color == TRUE) ? SXD_TUNNEL_DEC_SP_SET :
                                  SXD_TUNNEL_DEC_SP_PRESERVE;

        /*TIDEM update*/
        for (i = 0; i <= COS_ECN_MAX_NUM; i++) {
            for (j = 0; j <= COS_ECN_MAX_NUM; ++j) {
                if (!cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].valid) {
                    continue;
                }

                ku_tidem.overlay_ecn = i;
                ku_tidem.underlay_ecn = j;
                ku_tidem.eip_ecn = cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].egress_ecn;
                if (cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_enable) {
                    ku_tidem.trap_en = 1;
                    ku_tidem.trap_id =
                        (cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_attr.prio ==
                         SX_TRAP_PRIORITY_LOW)
                        ? SXD_TRAP_ID_DECAP_ECN0 : SXD_TRAP_ID_DECAP_ECN1;
                } else {
                    ku_tidem.trap_en = 0;
                    ku_tidem.trap_id = 0;
                }
                err = hwd_tunnel_tidem_reg_write(SXD_ACCESS_CMD_SET, &ku_tidem);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to set TIDEM REG for overlay ecn [%u] and underlay ecn [%u].\n", i, j);
                    goto out;
                }
            }
        }
        break;

    default:
        SX_LOG_ERR("Can't set CoS attribute. Invalid CoS param type (need to be encap or decap) hwd \n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    err = hwd_tunnel_tiqcr_reg_write(SXD_ACCESS_CMD_SET, &ku_tiqcr_reg);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't set CoS IPinIP attribute. hwd_tunnel_tiqcr_reg_write failed  %s\n", sx_status_str(err));
        goto out;
    }

out: /*no rollback every failure is fatal error*/
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_tunnel_cos_nve_vxlan_set(const hwd_tunnel_qos_tunnel_type_t tunnel_type,
                                                  const sx_tunnel_cos_data_t        *cos_data_p)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    struct ku_tnqcr_reg  ku_tnqcr_reg;
    struct ku_tneem_reg  ku_tneem;
    struct ku_tndem_reg  ku_tndem;
    uint32_t             i = 0, j = 0;
    sx_tunnel_cos_data_t cos_global_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(ku_tnqcr_reg);
    SX_MEM_CLR(ku_tneem);
    SX_MEM_CLR(ku_tndem);
    SX_MEM_CLR(cos_global_attr);

    /*TNQCR and TIEEM and TIDEM update*/
    switch (cos_data_p->param_type) {
    case SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E:

        /* set the values of decap cos from db */
        cos_global_attr.param_type = SX_TUNNEL_COS_PARAM_TYPE_DECAP_E;
        err = __hwd_tunnel_cos_global_attr_get(tunnel_type, &cos_global_attr);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Can't get CoS global attribute. __hwd_tunnel_cos_global_attr_get failed  %s\n",
                       sx_status_str(err));
            goto out;
        }
        ku_tnqcr_reg.dec_dscp_rw = cos_global_attr.dscp_rewrite;
        ku_tnqcr_reg.dec_set_dscp =
            (cos_global_attr.dscp_action == SX_COS_DSCP_ACTION_COPY_E) ? SXD_TUNNEL_DEC_DSCP_COPY :
            SXD_TUNNEL_DEC_DSCP_PRESERVE;
        ku_tnqcr_reg.dec_set_sp = (cos_global_attr.update_priority_color == TRUE) ? SXD_TUNNEL_DEC_SP_SET :
                                  SXD_TUNNEL_DEC_SP_PRESERVE;

        /*tnqcr update*/
        ku_tnqcr_reg.enc_dscp_rw = cos_data_p->dscp_rewrite;
        ku_tnqcr_reg.enc_set_dscp = (cos_data_p->dscp_action == SX_COS_DSCP_ACTION_COPY_E) ? SXD_TUNNEL_ENC_DSCP_COPY :
                                    SXD_TUNNEL_ENC_DSCP_SET;
        ku_tnqcr_reg.enc_set_sp = (cos_data_p->update_priority_color == TRUE) ? SXD_TUNNEL_ENC_SP_SET :
                                  SXD_TUNNEL_ENC_SP_PRESERVE;

        /*tieem update*/
        for (i = 0; i <= COS_ECN_MAX_NUM; i++) {
            if (!cos_data_p->cos_ecn_params.ecn_encap.ecn_encap_map[i].valid) {
                continue;
            }

            ku_tneem.overlay_ecn = i;
            ku_tneem.underlay_ecn = cos_data_p->cos_ecn_params.ecn_encap.ecn_encap_map[i].egress_ecn;
            err = hwd_tunnel_tneem_reg_write(SXD_ACCESS_CMD_SET, &ku_tneem);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set TIEEM REG for overlay ecn [%u].\n", i);
                goto out;
            }
        }
        break;

    case SX_TUNNEL_COS_PARAM_TYPE_DECAP_E:

        /* set the values of ENCAP cos from db */
        cos_global_attr.param_type = SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E;
        err = __hwd_tunnel_cos_global_attr_get(tunnel_type, &cos_global_attr);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Can't get CoS global attribute. __hwd_tunnel_cos_global_attr_get failed  %s\n",
                       sx_status_str(err));
            goto out;
        }
        ku_tnqcr_reg.enc_dscp_rw = cos_global_attr.dscp_rewrite;
        ku_tnqcr_reg.enc_set_dscp =
            (cos_global_attr.dscp_action == SX_COS_DSCP_ACTION_COPY_E) ? SXD_TUNNEL_ENC_DSCP_COPY :
            SXD_TUNNEL_ENC_DSCP_SET;
        ku_tnqcr_reg.enc_set_sp = (cos_global_attr.update_priority_color == TRUE) ? SXD_TUNNEL_ENC_SP_SET :
                                  SXD_TUNNEL_ENC_SP_PRESERVE;

        /* tnqcr update DECAP values from new configuration */
        ku_tnqcr_reg.dec_dscp_rw = cos_data_p->dscp_rewrite;
        ku_tnqcr_reg.dec_set_dscp = (cos_data_p->dscp_action == SX_COS_DSCP_ACTION_COPY_E) ? SXD_TUNNEL_DEC_DSCP_COPY :
                                    SXD_TUNNEL_DEC_DSCP_PRESERVE;
        ku_tnqcr_reg.dec_set_sp = (cos_data_p->update_priority_color == TRUE) ? SXD_TUNNEL_DEC_SP_SET :
                                  SXD_TUNNEL_DEC_SP_PRESERVE;

        /* Temporarily we need to set dec_set_pcp field in TNQCR register to 1 anyway.
         * This field is SPC-2 (Phoenix) specific and not supported by SPC-1 (Condor).
         * Field configures switch behaviour at NVE decapsulation stage:
         *     0 - PCP (Priority) tag in overlay packet should not be changed.
         *     1 - PCP (Priority) tag should be copied from underlay packet to overlay.
         * Currently there are no SDK flows, that configure this field.
         * Until SDK won`t be able to configure this field, put value 1 there. */
        ku_tnqcr_reg.dec_set_pcp = SXD_TUNNEL_DEC_PCP_COPY;

        /*tidem update*/
        for (i = 0; i <= COS_ECN_MAX_NUM; i++) {
            for (j = 0; j <= COS_ECN_MAX_NUM; ++j) {
                if (!cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].valid) {
                    continue;
                }

                ku_tndem.overlay_ecn = i;
                ku_tndem.underlay_ecn = j;
                ku_tndem.eip_ecn = cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].egress_ecn;
                if (cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_enable) {
                    ku_tndem.trap_en = 1;
                    ku_tndem.trap_id =
                        (cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_attr.prio ==
                         SX_TRAP_PRIORITY_LOW)
                        ? SXD_TRAP_ID_DECAP_ECN0 : SXD_TRAP_ID_DECAP_ECN1;
                } else {
                    ku_tndem.trap_en = 0;
                    ku_tndem.trap_id = 0;
                }

                err = hwd_tunnel_tndem_reg_write(SXD_ACCESS_CMD_SET, &ku_tndem);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to set TIDEM REG for overlay ecn [%u] and underlay ecn [%u].\n", i, j);
                    goto out;
                }
            }
        }
        break;

    default:
        SX_LOG_ERR("Can't set CoS attribute. Invalid CoS param type (need to be encap or decap) hwd \n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    err = hwd_tunnel_tnqcr_reg_write(SXD_ACCESS_CMD_SET, &ku_tnqcr_reg);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't set CoS attribute. hwd_tunnel_tnqcr_reg_write failed  %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_cos_set(const sx_tunnel_type_e tunnel_type, const sx_tunnel_cos_data_t   *cos_data_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    hwd_tunnel_qos_tunnel_type_t qos_tunnel_type = SX_TUNNEL_QOS_TUNNEL_TYPE_MIN;

    SX_LOG_ENTER();
    SX_LOG_DBG("hwd_tunnel_cos_set \n");

    if (utils_check_pointer(cos_data_p, "cos_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* setting the default cos reg*/
    if (cos_data_p->param_type == SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E) {
        err = __hwd_tunnel_cos_default_reg_set(tunnel_type, cos_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Can't set CoS default attribute. __hwd_tunnel_cos_default_reg_set failed  %s\n",
                       sx_status_str(err));
            goto out;
        }
    }

    /* setting the cos reg per type*/
    switch (tunnel_type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
    case SX_TUNNEL_TYPE_NVE_GENEVE:
    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        qos_tunnel_type = SX_TUNNEL_QOS_TUNNEL_TYPE_NVE_E;
        err = __hwd_tunnel_cos_nve_vxlan_set(qos_tunnel_type, cos_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Can't set CoS VXLAN attribute. hwd_tunnel_cos_nve_vxlan_set failed  %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        qos_tunnel_type = SX_TUNNEL_QOS_TUNNEL_TYPE_IPINIP_E;
        err = __hwd_tunnel_cos_ipinip_set(qos_tunnel_type, cos_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Can't set CoS IPinIP attribute. hwd_tunnel_cos_ipinip_set failed  %s\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Can't set CoS attribute. tunnel type not supported for CoS attribute hwd\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    /* setting the cos DB per type*/
    err = __hwd_tunnel_cos_global_attr_set(qos_tunnel_type, cos_data_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't set CoS global attribute. __hwd_tunnel_cos_global_attr_set failed  %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __hwd_tunnel_cos_global_attr_get(const hwd_tunnel_qos_tunnel_type_t tunnel_type,
                                             sx_tunnel_cos_data_t              *cos_data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("hwd_tunnel_cos_get \n");

    if (utils_check_pointer(cos_data_p, "cos_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cos_data_p->param_type) {
    case SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E:
        SX_MEM_CPY(*cos_data_p, g_global_config.cos_attr[tunnel_type].encap_cos_data);

        break;

    case SX_TUNNEL_COS_PARAM_TYPE_DECAP_E:
        SX_MEM_CPY(*cos_data_p, g_global_config.cos_attr[tunnel_type].decap_cos_data);

        break;

    default:
        SX_LOG_ERR("Can't get CoS attribute. Invalid tunnel direction\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t hwd_tunnel_cos_get(const sx_tunnel_id_t tunnel_id, sx_tunnel_cos_data_t         *cos_data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (SX_TUNNEL_TYPE_ID_GET(tunnel_id)) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
    case SX_TUNNEL_TYPE_NVE_GENEVE:
    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        err = __hwd_tunnel_cos_global_attr_get(SX_TUNNEL_QOS_TUNNEL_TYPE_NVE_E, cos_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Can't get CoS IPINIP attributes: %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        err = __hwd_tunnel_cos_global_attr_get(SX_TUNNEL_QOS_TUNNEL_TYPE_IPINIP_E, cos_data_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Can't get CoS NVE attribute: %s\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Can't get CoS attribute. Tunnel type not supported for CoS attribute hwd\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_hwd_tunnel_counter_clear(sx_port_tunnel_phy_id_t phy_tunnel_port)
{
    if (phy_tunnel_port == SX_PORT_TUNNEL_NVE) {
        return hwd_tunnel_tncr_clear(phy_tunnel_port);
    } else {
        return SX_STATUS_SUCCESS;
    }
}

sx_status_t ulay_default_rif_hwd_tunnel_counter_clear(sx_port_tunnel_phy_id_t phy_tunnel_port)
{
    return hwd_tunnel_tncr_v2_clear(phy_tunnel_port);
}

/**
 * This function is used for NVE ports to specify whether we want to determine
 * the packet VLAN Ethertype based on the egress port.
 */
sx_status_t __ulay_default_rif_hwd_tunnel_eport_et_vlan_set(const sx_tunnel_attribute_t *tunnel_attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_port_log_id_t    log_port = 0;
    struct ku_spvid_reg spvid_reg_data;
    sxd_reg_meta_t      spvid_reg_meta;
    sx_vlan_tag_mode_t  tag_mode = SX_VLAN_TAG_MODE_802_1Q_E;
    boolean_t           egress_et_set = FALSE;

    SX_MEM_CLR(spvid_reg_data);
    SX_MEM_CLR(spvid_reg_meta);

    SX_LOG_ENTER();

    if (utils_check_pointer(tunnel_attr_p, "tunnel_attr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        log_port = tunnel_attr_p->attributes.vxlan.nve_log_port;
        tag_mode = tunnel_attr_p->attributes.vxlan.decap.tag_mode;
        egress_et_set = tunnel_attr_p->attributes.vxlan.decap.egress_et_set;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        log_port = tunnel_attr_p->attributes.nvgre.nve_log_port;
        tag_mode = tunnel_attr_p->attributes.nvgre.decap.tag_mode;
        egress_et_set = tunnel_attr_p->attributes.nvgre.decap.egress_et_set;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        log_port = tunnel_attr_p->attributes.vxlan_gpe.nve_log_port;
        tag_mode = tunnel_attr_p->attributes.vxlan_gpe.decap.tag_mode;
        egress_et_set = tunnel_attr_p->attributes.vxlan_gpe.decap.egress_et_set;
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        log_port = tunnel_attr_p->attributes.l2_flex.log_port;
        tag_mode = tunnel_attr_p->attributes.l2_flex.decap.tag_mode;
        egress_et_set = tunnel_attr_p->attributes.l2_flex.decap.egress_et_set;
        break;

    default:
        SX_LOG_DBG("No need to update SPVID register for the '%s' type.\n", sx_tunnel_type_str(tunnel_attr_p->type));
        goto out;
    }

    spvid_reg_meta.swid = 0;
    spvid_reg_meta.dev_id = SX_PORT_DEV_ID_GET(log_port);
    spvid_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    spvid_reg_data.tport = TRUE;
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(spvid_reg_data.local_port, spvid_reg_data.lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));
    spvid_reg_data.port_default_vid = 0;

    if (egress_et_set != FALSE) {
        spvid_reg_data.egr_et_set = 1;
        spvid_reg_data.et_vlan = 0;  /* doesn't matter - we will use egress port et_vlan */
    } else {
        spvid_reg_data.egr_et_set = 0;

        if (tag_mode == SX_VLAN_TAG_MODE_802_1AD_E) {
            spvid_reg_data.et_vlan = 1;
        } else {
            spvid_reg_data.et_vlan = 0;
        }
    }

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SPVID_E,
                                                     &spvid_reg_data,
                                                     &spvid_reg_meta,
                                                     1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to access SPVID register: err - %s\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t ulay_default_rif_hwd_tunnel_rif_ref_update(const sx_tunnel_attribute_t *tunnel_attr_p,
                                                              boolean_t                    is_increase)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    hwd_rif_id_t          hwd_rif_id = 0;
    sx_router_interface_t urif_id = 0;

    SX_LOG_ENTER();

    if (tunnel_attr_p->direction != SX_TUNNEL_DIRECTION_DECAP) {
        err = tunnel_impl_get_underlay_rif(tunnel_attr_p, &urif_id);
    } else {
        err = tunnel_impl_get_underlay_decap_rif(tunnel_attr_p, &urif_id);
    }
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel underlay RIF, err = %s\n", sx_status_str(err));
        goto out;
    }

    err = hwd_rif_hw_id_get(urif_id, &hwd_rif_id);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get HW RIF ID of RIF %u , err = %s\n",
                   urif_id, sx_status_str(err));
        goto out;
    }

    err = hwd_rif_ref_count_set(hwd_rif_id, is_increase);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("hwd_rif_ref_count_set failed, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t ulay_default_rif_hwd_tunnel_create(const sx_tunnel_attribute_t  *tunnel_attr_p,
                                               hwi_tunnel_hw_encap_handle_t *tunnel_encap_handle_p,
                                               hwi_tunnel_hw_decap_handle_t *tunnel_decap_handle_p)
{
    sx_status_t                      sx_status = SX_STATUS_SUCCESS;
    sx_status_t                      rb_status = SX_STATUS_SUCCESS;
    hwd_rif_id_t                     hw_underlay_rif_id;
    hwd_tunnel_encap_data_t          encap_data;
    hwd_rtdp_t                       rtdp_entry;
    sx_tunnel_nve_encap_attributes_t nve_encap;
    sxd_tunnel_nve_type_t            nve_type = 0;
    hwi_tunnel_hw_encap_handle_t     new_encap_handle = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;
    hwi_tunnel_hw_decap_handle_t     new_decap_handle = SDK_TUNNEL_INVALID_DECAP_HWD_HDL;
    boolean_t                        is_updated_tngcr = FALSE;
    boolean_t                        is_updated_tnpc = FALSE;
    boolean_t                        is_create_decap = FALSE;
    boolean_t                        is_create_encap = FALSE;
    boolean_t                        is_urif_ref_updated = FALSE;
    boolean_t                        hw_learn_set = FALSE;
    uint8_t                          et_vlan = 0, rb_et_vlan = 0;
    sx_router_interface_state_t      rif_state;
    sx_router_general_param_t       *general_param_p = NULL;
    uint8_t                          lbf_mode = TUNNEL_TNPC_LB_TX_TUNNEL_PORT_DEFAULT;
    sx_port_log_id_t                 log_port = 0;
    boolean_t                        dis_nve_opt_chk = FALSE;
    uint64_t                         hdr_bits = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(rif_state);
    SX_MEM_CLR(encap_data);
    SX_MEM_CLR(rtdp_entry);
    SX_MEM_CLR(hw_underlay_rif_id);
    SX_MEM_CLR(nve_encap);

    if (utils_check_pointer(tunnel_attr_p, "tunnel_attr_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(tunnel_encap_handle_p, "tunnel_encap_handle_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(tunnel_decap_handle_p, "tunnel_decap_handle_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    TUNNEL_HWD_INIT_CHECK("create tunnel", sx_status);

    sx_status = __hwd_tunnel_attr_prepare(tunnel_attr_p,
                                          &nve_encap,
                                          &hw_underlay_rif_id,
                                          &nve_type,
                                          &hw_learn_set,
                                          &et_vlan,
                                          &lbf_mode,
                                          &log_port,
                                          &dis_nve_opt_chk,
                                          &hdr_bits);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to parse tunnel attributes, err = %s.\n",
                   sx_status_str(sx_status));
        goto out;
    }

    rb_et_vlan = g_global_config.tngcr_config.ku_tngcr.et_vlan;

    /* For NVE tunnels */
    if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, tunnel_attr_p->type, SX_TUNNEL_TYPE_NVE_MAX)) {
        /* update tngcr - relevant only for NVE tunnel*/
        sx_status = hwd_tunnel_update_tngcr(&g_global_config,
                                            ((tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_ENCAP) ? &nve_encap : NULL),
                                            hw_underlay_rif_id,
                                            nve_type,
                                            TRUE,
                                            0,
                                            /* RESERVED */
                                            et_vlan,
                                            dis_nve_opt_chk,
                                            hdr_bits);
        if (sx_status == SX_STATUS_SUCCESS) {
            is_updated_tngcr = TRUE;
        } else {
            SX_LOG_ERR("Failed to create tunnel on HW, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        sx_status = __hwd_tunnel_nve_options_trap_set(tunnel_attr_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to enable extra tunnel traps, error = %s.\n", sx_status_str(sx_status));
            goto out;
        }
    }

    /* For NVE & L2 Flex tunnels */
    if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, tunnel_attr_p->type, SX_TUNNEL_TYPE_NVE_MAX) ||
        SX_CHECK_RANGE(SX_TUNNEL_TYPE_L2_FLEX_MIN, tunnel_attr_p->type, SX_TUNNEL_TYPE_L2_FLEX_MAX)) {
        sx_status = hwd_tunnel_update_tnpc(SX_PORT_PHY_ID_GET(log_port), hw_learn_set, lbf_mode);
        if (sx_status == SX_STATUS_SUCCESS) {
            is_updated_tnpc = TRUE;
            g_global_config.tnpc_config[SX_PORT_PHY_ID_GET(log_port)].ku_tnpc.learn_enable_v4 = hw_learn_set;
            g_global_config.tnpc_config[SX_PORT_PHY_ID_GET(log_port)].ku_tnpc.lb_tx_uc_tunnel_port = lbf_mode;
        } else {
            SX_LOG_ERR("Failed to create tunnel on HW, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }
    }

    if (tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_DECAP) {
        sx_status = __tunnel_create_decap_entry(tunnel_attr_p, &new_decap_handle, &rtdp_entry);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to create tunnel decap entry on HW, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        sx_status = hwd_rtdp_db_add(new_decap_handle, &rtdp_entry);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to add tunnel decap entry to RTDP DB, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }
        is_create_decap = TRUE;
    }

    sx_status = __tunnel_create_encap_entry(tunnel_attr_p, &new_encap_handle, &encap_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to add tunnel encap entry on HW, err = %s.\n",
                   sx_status_str(sx_status));
        goto out;
    }
    is_create_encap = TRUE;


    *tunnel_encap_handle_p = new_encap_handle;
    *tunnel_decap_handle_p = new_decap_handle;

    sx_status = ulay_default_rif_hwd_tunnel_rif_ref_update(tunnel_attr_p, TRUE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to increase tunnel RIF reference on HW, err = %s.\n",
                   sx_status_str(sx_status));
        goto out;
    }
    is_urif_ref_updated = TRUE;

    sx_status = __ulay_default_rif_hwd_tunnel_eport_et_vlan_set(tunnel_attr_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("__ulay_default_rif_hwd_tunnel_eport_et_vlan_set failed, err = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = vlan_tunnel_ulay_rif_qinq_mode_set(tunnel_attr_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("vlan_tunnel_ulay_rif_qinq_mode_set failed, err = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    /* In case of VRID domain type we should handle uRIF state since it was created by default */
    if (tunnel_impl_get_underlay_domain_type(tunnel_attr_p) == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        sx_status = sdk_router_impl_params_get(NULL, &general_param_p, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get params from router (rc=%s)\n", sx_status_str(sx_status));
            goto out;
        }

        rif_state.ipv4_enable = general_param_p->ipv4_enable;
        rif_state.ipv6_enable = general_param_p->ipv6_enable;
        rif_state.ipv4_mc_enable = general_param_p->ipv4_mc_enable;
        rif_state.ipv6_mc_enable = general_param_p->ipv6_mc_enable;

        sx_status = sdk_rif_impl_state_set(hw_underlay_rif_id, &rif_state);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("sdk_rif_impl_state_set failed, err = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }
    }


out:
    if (sx_status) {
        if (new_encap_handle != SDK_TUNNEL_INVALID_ENCAP_HWD_HDL) {
            if (is_urif_ref_updated) {
                rb_status = ulay_default_rif_hwd_tunnel_rif_ref_update(tunnel_attr_p, FALSE);
                if (SX_CHECK_FAIL(rb_status)) {
                    SX_LOG_ERR("Failed to decrease tunnel RIF reference on HW, err = %s.\n",
                               sx_status_str(rb_status));
                }
            }

            if (is_create_encap) {
                rb_status = hwd_encap_db_delete(new_encap_handle);
                if (SX_CHECK_FAIL(rb_status)) {
                    SX_LOG_ERR("Failed to roll back adding encap entry from HW DB, err = %s.\n",
                               sx_status_str(rb_status));
                }
            }
        }

        if (new_decap_handle != SDK_TUNNEL_INVALID_DECAP_HWD_HDL) {
            if (is_create_decap) {
                rb_status = hwd_rtdp_db_delete(new_decap_handle);
                if (SX_CHECK_FAIL(rb_status)) {
                    SX_LOG_ERR("Failed to roll back adding decap entry from RTDP DB, err = %s.\n",
                               sx_status_str(rb_status));
                }
            }
            rb_status = __tunnel_remove_decap_entry(new_decap_handle);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to delete tunnel decap entry on HW, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }

        if (is_updated_tnpc) {
            g_global_config.tnpc_config[SX_PORT_PHY_ID_GET(log_port)].ku_tnpc.learn_enable_v4 = FALSE;
            g_global_config.tnpc_config[SX_PORT_PHY_ID_GET(log_port)].ku_tnpc.lb_tx_uc_tunnel_port =
                TUNNEL_TNPC_LB_TX_TUNNEL_PORT_DEFAULT;
            rb_status = hwd_tunnel_update_tnpc(SX_PORT_PHY_ID_GET(log_port),
                                               FALSE,
                                               g_global_config.tnpc_config[SX_PORT_PHY_ID_GET(
                                                                               log_port)].ku_tnpc.lb_tx_uc_tunnel_port);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to rollback TNPC REG state, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }

        if (is_updated_tngcr) {
            /* update tngcr */
            rb_status =
                hwd_tunnel_update_tngcr(&g_global_config, NULL, 0, nve_type, FALSE, FALSE, rb_et_vlan, FALSE, 0);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to rollback TNGCR REG state, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t ulay_default_rif_hwd_tunnel_edit(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                             hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                             const sx_tunnel_attribute_t *old_tunnel_attr_p,
                                             const sx_tunnel_attribute_t *new_tunnel_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_status_t rb_status = SX_STATUS_SUCCESS;
    boolean_t   is_old_urif_ref_updated = FALSE;
    boolean_t   is_new_urif_ref_updated = FALSE;

    SX_LOG_ENTER();

    if (utils_check_pointer(old_tunnel_attr_p, "old_tunnel_attr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(new_tunnel_attr_p, "new_tunnel_attr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = hwd_tunnel_edit(tunnel_encap_handle, tunnel_decap_handle, old_tunnel_attr_p, new_tunnel_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("hwd_tunnel_create failed, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = ulay_default_rif_hwd_tunnel_rif_ref_update(old_tunnel_attr_p, FALSE);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to decrease tunnel RIF reference on HW, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }
    is_old_urif_ref_updated = TRUE;

    err = ulay_default_rif_hwd_tunnel_rif_ref_update(new_tunnel_attr_p, TRUE);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to increase tunnel RIF reference on HW, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }
    is_new_urif_ref_updated = TRUE;

    err = __ulay_default_rif_hwd_tunnel_eport_et_vlan_set(new_tunnel_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__ulay_default_rif_hwd_tunnel_eport_et_vlan_set failed, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = vlan_tunnel_ulay_rif_qinq_mode_set(new_tunnel_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("vlan_tunnel_ulay_rif_qinq_mode_set failed, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    if (err) {
        if (is_old_urif_ref_updated) {
            rb_status = ulay_default_rif_hwd_tunnel_rif_ref_update(old_tunnel_attr_p, TRUE);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Rollback: Failed to increase tunnel RIF reference on HW, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }
        if (is_new_urif_ref_updated) {
            rb_status = ulay_default_rif_hwd_tunnel_rif_ref_update(new_tunnel_attr_p, FALSE);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Rollback: Failed to decrease tunnel RIF reference on HW, err = %s.\n",
                           sx_status_str(rb_status));
            }
        }
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t ulay_default_rif_hwd_tunnel_delete(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                               hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                               const sx_tunnel_attribute_t *tunnel_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = hwd_tunnel_delete(tunnel_encap_handle, tunnel_decap_handle, tunnel_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("hwd_tunnel_delete failed, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = ulay_default_rif_hwd_tunnel_rif_ref_update(tunnel_attr_p, FALSE);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("hwd_tunnel_delete failed, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static inline void __hwd_tunnel_attr_reserved_bits_unpack(const sx_tunnel_nve_reserved_bits_check_t *reserved_bits_p,
                                                          uint64_t                                   default_mask,
                                                          boolean_t                                 *dis_nve_opt_chk_p,
                                                          uint64_t                                  *hdr_bits_p)
{
    switch (reserved_bits_p->mode) {
    case SX_TUNNEL_NVE_RESERVED_BITS_MODE_DROP_E:
        *dis_nve_opt_chk_p = NVE_RESERVED_BITS_CHECK_ENABLE;
        *hdr_bits_p = default_mask;
        break;

    case SX_TUNNEL_NVE_RESERVED_BITS_MODE_IGNORE_E:
        *dis_nve_opt_chk_p = NVE_RESERVED_BITS_CHECK_DISABLE;
        *hdr_bits_p = 0;
        break;

    case SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E:
        *dis_nve_opt_chk_p = NVE_RESERVED_BITS_CHECK_ENABLE;
        *hdr_bits_p = reserved_bits_p->mask;
        break;

    default:
        break;
    }
}

static sx_status_t __hwd_tunnel_attr_prepare(const sx_tunnel_attribute_t      *tunnel_attr_p,
                                             sx_tunnel_nve_encap_attributes_t *nve_encap_p,
                                             hwd_rif_id_t                     *hwd_urif_id_p,
                                             sxd_tunnel_nve_type_t            *nve_type_p,
                                             boolean_t                        *hwd_learn_set_p,
                                             uint8_t                          *et_vlan_p,
                                             uint8_t                          *lbf_mode_p,
                                             sx_port_log_id_t                 *log_port,
                                             boolean_t                        *dis_nve_opt_chk_p,
                                             uint64_t                         *hdr_bits_p)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    sx_router_interface_t urif_id = 0;
    sx_swid_t             swid = 0;
    sx_fdb_learn_mode_t   learn_mode = SX_FDB_LEARN_MODE_DONT_LEARN;
    sx_fdb_learn_mode_t   learn_global_mode = SX_FDB_LEARN_MODE_DONT_LEARN;

    SX_LOG_ENTER();

    *dis_nve_opt_chk_p = 0;
    *hdr_bits_p = 0;

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        urif_id = tunnel_attr_p->attributes.ipinip_p2p.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        urif_id = tunnel_attr_p->attributes.ipinip_p2p_gre.underlay_rif;
        break;

    /* NVE Tunnels */
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        urif_id = tunnel_attr_p->attributes.vxlan.encap.underlay_rif;
        *log_port = tunnel_attr_p->attributes.vxlan.nve_log_port;
        *nve_type_p = SXD_TUNNEL_NVE_VXLAN;
        SX_MEM_CPY(*nve_encap_p, tunnel_attr_p->attributes.vxlan.encap);

        sx_status = hwd_tunnel_et_vlan_index_get(tunnel_attr_p->attributes.vxlan.decap.tag_mode, et_vlan_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("hwd_tunnel_et_vlan_index_get failed , err = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }

        __hwd_tunnel_attr_reserved_bits_unpack(&tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check,
                                               VXLAN_RESERVED_BITS_DEFAULT_MASK,
                                               dis_nve_opt_chk_p,
                                               hdr_bits_p);
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        urif_id = tunnel_attr_p->attributes.vxlan_gpe.encap.underlay_rif;
        *log_port = tunnel_attr_p->attributes.vxlan_gpe.nve_log_port;
        *nve_type_p = SXD_TUNNEL_NVE_VXLAN_GPE;
        SX_MEM_CPY(*nve_encap_p, tunnel_attr_p->attributes.vxlan_gpe.encap);

        sx_status = hwd_tunnel_et_vlan_index_get(tunnel_attr_p->attributes.vxlan_gpe.decap.tag_mode, et_vlan_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Tunnel : hwd_tunnel_et_vlan_index_get failed , err = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }

        __hwd_tunnel_attr_reserved_bits_unpack(&tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check,
                                               GPE_RESERVED_BITS_DEFAULT_MASK,
                                               dis_nve_opt_chk_p,
                                               hdr_bits_p);
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        urif_id = tunnel_attr_p->attributes.geneve.encap.underlay_rif;
        *log_port = tunnel_attr_p->attributes.geneve.nve_log_port;
        *nve_type_p = SXD_TUNNEL_NVE_GENEVE;
        SX_MEM_CPY(*nve_encap_p, tunnel_attr_p->attributes.geneve.encap);
        sx_status = hwd_tunnel_et_vlan_index_get(tunnel_attr_p->attributes.geneve.decap.tag_mode, et_vlan_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Tunnel : hwd_tunnel_et_vlan_index_get failed , err = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }

        __hwd_tunnel_attr_reserved_bits_unpack(&tunnel_attr_p->attributes.geneve.decap.reserved_bits_check,
                                               GENEVE_RESERVED_BITS_DEFAULT_MASK,
                                               dis_nve_opt_chk_p,
                                               hdr_bits_p);
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        urif_id = tunnel_attr_p->attributes.nvgre.encap.underlay_rif;
        *log_port = tunnel_attr_p->attributes.nvgre.nve_log_port;
        *nve_type_p = SXD_TUNNEL_NVE_NVGRE;
        SX_MEM_CPY(*nve_encap_p, tunnel_attr_p->attributes.nvgre.encap);
        sx_status = hwd_tunnel_et_vlan_index_get(tunnel_attr_p->attributes.nvgre.decap.tag_mode, et_vlan_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Tunnel : hwd_tunnel_et_vlan_index_get failed , err = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }

        __hwd_tunnel_attr_reserved_bits_unpack(&tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check,
                                               NVGRE_RESERVED_BITS_DEFAULT_MASK,
                                               dis_nve_opt_chk_p,
                                               hdr_bits_p);
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        urif_id = tunnel_attr_p->attributes.l2_flex.encap.underlay_rif;
        *log_port = tunnel_attr_p->attributes.l2_flex.log_port;
        sx_status = hwd_tunnel_et_vlan_index_get(tunnel_attr_p->attributes.l2_flex.decap.tag_mode, et_vlan_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Tunnel : hwd_tunnel_et_vlan_index_get failed , err = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }
        break;
    }
    if ((tunnel_attr_p->direction != SX_TUNNEL_DIRECTION_DECAP)
        || (tunnel_impl_get_underlay_domain_type(tunnel_attr_p) == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID)) {
        sx_status = hwd_rif_hw_id_get(urif_id, hwd_urif_id_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get RIF %u HW ID in hwd_tunnel_create, err = [%s] \n",
                       urif_id, sx_status_str(sx_status));
            goto out;
        }
    } else {
        *hwd_urif_id_p = 0;
    }

    if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, tunnel_attr_p->type, SX_TUNNEL_TYPE_NVE_MAX)) {
        sx_status = port_swid_alloc_get(SX_ACCESS_CMD_GET, *log_port, &swid);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get swid for nve log_port[%u] err = %s\n",
                       *log_port, sx_status_str(sx_status));
            goto out;
        }

        sx_status = fdb_learn_mode_get(swid, &learn_global_mode);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get learning for swid[%u] err = %s\n",
                       swid, sx_status_str(sx_status));
            goto out;
        }

        sx_status = fdb_port_learn_mode_get(*log_port, &learn_mode);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get learning for nve log_port[%u] err = %s\n",
                       *log_port, sx_status_str(sx_status));
            goto out;
        }

        *hwd_learn_set_p = ((learn_mode != SX_FDB_LEARN_MODE_DONT_LEARN) &&
                            (learn_global_mode != SX_FDB_LEARN_MODE_DONT_LEARN)) ? TRUE : FALSE;

        sx_status = __hwd_tunnel_nve_port_lbf_mode_get(*log_port, lbf_mode_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get the state of the loopback filter for the NVE port [%u] err = %s\n",
                       *log_port, sx_status_str(sx_status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t __hwd_tunnel_nve_port_lbf_mode_get(const sx_port_log_id_t log_port, uint8_t *lbf_mode_p)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sx_port_info_t info_item;

    SX_MEM_CLR(info_item);

    sx_status = port_db_info_get(log_port, &info_item);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get the state of the loopback filter for the NVE port [%u] from PORT DB err = %s\n",
                   log_port, sx_status_str(sx_status));
        goto out;
    }

    *lbf_mode_p = TUNNEL_LBF_MODE_PORT_TO_TUNNEL_CONVERT(info_item.loopback_filter_mode);

out:
    return sx_status;
}

sx_status_t hwd_tunnel_issu_vni_set(hwd_tunnel_map_entry_t *map_entry_p, boolean_t encap)
{
    sx_status_t  sx_status = SX_STATUS_SUCCESS;
    boolean_t    counter_locked;
    cm_hw_type_t counter_hw_type;
    cm_index_t   counter_hw_index;

    SX_LOG_ENTER();


    switch (map_entry_p->map_entry.params.nve.direction) {
    case SX_TUNNEL_MAP_DIR_BIDIR:
        if (encap) {
            sx_status = sdk_fid_manager_hwfid_register_encap_vni_update(SX_ACCESS_CMD_ADD,
                                                                        map_entry_p->map_entry.params.nve.bridge_id,
                                                                        map_entry_p->map_entry.params.nve.vni);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to set tunnel encap vni (%u) for fid (%u), err = %s.\n",
                           map_entry_p->map_entry.params.nve.vni, map_entry_p->map_entry.params.nve.bridge_id,
                           sx_status_str(sx_status));
                goto out;
            }
            break;
        }

    /* fallthrough */
    case SX_TUNNEL_MAP_DIR_DECAP:
        if (encap) {
            break;
        }

        sx_status =
            __hwd_tunnel_counter_info_with_lock_get(map_entry_p->decap_flow_counter_id,
                                                    &counter_locked, &counter_hw_type, &counter_hw_index);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get counter's info, ID %u [%s]\n",
                       map_entry_p->decap_flow_counter_id,
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = sdk_fid_manager_tunnel_decap_mapping_set(SX_ACCESS_CMD_ADD,
                                                             map_entry_p->map_entry.params.nve.bridge_id,
                                                             map_entry_p->map_entry.params.nve.vni,
                                                             counter_hw_type, counter_hw_index,
                                                             map_entry_p->v_rif,
                                                             map_entry_p->hw_rif_id);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to set tunnel decap vni (%u) for fid (%u), err = %s.\n",
                       map_entry_p->map_entry.params.nve.vni,
                       map_entry_p->map_entry.params.nve.bridge_id,
                       sx_status_str(sx_status));
            goto out;
        }

        if (counter_locked == TRUE) {
            counter_locked = FALSE;
            sx_status =
                __hwd_tunnel_counter_info_unlock(map_entry_p->decap_flow_counter_id);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to unlock counter, ID %u [%s]\n",
                           map_entry_p->decap_flow_counter_id,
                           sx_status_str(sx_status));
                goto out;
            }
        }
        break;

    default:
        SX_LOG_ERR("Unexpected direction (%u), err = %s.\n",
                   map_entry_p->map_entry.params.nve.direction, sx_status_str(sx_status));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}
sx_status_t hwd_tunnel_nve_reg_deinit()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = hwd_tunnel_deinit_registers(&g_global_config);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to de init tunnel registers, err = %s\n", sx_status_str(sx_status));
        /* No need to do rollback and return error in this case */
        sx_status = SX_STATUS_SUCCESS;
    }

    if (g_hwd_tunnel_internal_callbacks.hwd_tunnel_tnpc_defaults_write_pfn != NULL) {
        sx_status = g_hwd_tunnel_internal_callbacks.hwd_tunnel_tnpc_defaults_write_pfn();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to de init TNPC with defaults.\n");
            /* No need to do rollback and return error in this case */
            sx_status = SX_STATUS_SUCCESS;
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t __hwd_tunnel_tnpc_defaults_write()
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    sx_port_tunnel_phy_id_t tunnel_port = 0;

    SX_LOG_ENTER();

    for (tunnel_port = SX_PORT_TUNNEL_MIN; tunnel_port <= SX_PORT_TUNNEL_MAX; tunnel_port++) {
        if (tunnel_port == SX_PORT_TUNNEL_RESERVED) {
            continue;
        }

        g_global_config.tnpc_config[tunnel_port].ku_tnpc.learn_enable_v4 = FALSE;
        g_global_config.tnpc_config[tunnel_port].ku_tnpc.lb_tx_uc_tunnel_port = TUNNEL_TNPC_LB_TX_TUNNEL_PORT_DEFAULT;

        sx_status = hwd_tunnel_update_tnpc(tunnel_port,
                                           g_global_config.tnpc_config[tunnel_port].ku_tnpc.learn_enable_v4,
                                           g_global_config.tnpc_config[tunnel_port].ku_tnpc.lb_tx_uc_tunnel_port);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to set default values to TNPC tunnel port %s, err = %s.\n",
                       sx_port_tunnel_phy_id_str(tunnel_port),
                       sx_status_str(sx_status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_tunnel_sffp_reg_write(uint8_t profile_id, sxd_sffp_type_t type, uint8_t flood_offset)
{
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_sffp_reg sffp_reg_data;
    sxd_reg_meta_t     reg_meta;

    SX_LOG_ENTER();

    SX_MEM_CLR(sffp_reg_data);
    SX_MEM_CLR(reg_meta);

    reg_meta.dev_id = 1;
    reg_meta.swid = 0;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sffp_reg_data.profile_id = profile_id;
    sffp_reg_data.type = type;
    sffp_reg_data.flood_offset = flood_offset;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SFFP_E,
                                                     &sffp_reg_data,
                                                     &reg_meta,
                                                     1,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("The SFFP register with the SET command fail: [%s]\n", SXD_STATUS_MSG(sxd_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sxd_status_to_sx_status(sxd_status);
}

sx_status_t hwd_tunnel_zeroed_reserved_tngee_index_get(kvd_linear_manager_index_t *kvd_index_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(kvd_index_p, "kvd_index_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *kvd_index_p = g_zeroed_reserved_tngee_index;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_tunnel_zeroed_reserved_tngee_create()
{
    sx_status_t                       sx_status = SX_STATUS_SUCCESS;
    sx_status_t                       rb_sx_status = SX_STATUS_SUCCESS;
    sxd_status_t                      sxd_status = SXD_STATUS_SUCCESS;
    boolean_t                         rm_set = FALSE;
    boolean_t                         kvd_added = FALSE;
    boolean_t                         kvd_locked = FALSE;
    uint32_t                          num_of_entries = TUNNEL_RESERVED_TNGEE_ENTRIES_NUM;
    kvd_linear_manager_block_length_t size = TUNNEL_RESERVED_TNGEE_ENTRIES_NUM;
    sxd_reg_meta_t                    tngee_reg_meta;
    struct ku_tngee_reg               tngee_reg_data;

    SX_LOG_ENTER();

    SX_MEM_CLR(tngee_reg_meta);
    SX_MEM_CLR(tngee_reg_data);

    sx_status = rm_system_entries_set(RM_SDK_TABLE_TYPE_NVE_MC_LIST_E, SX_ACCESS_CMD_ADD, num_of_entries, NULL);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed on RM entry set, error: %s\n", sx_status_str(sx_status));
        goto out;
    }
    rm_set = TRUE;

    /* KVD_LINEAR_MANAGER_USER_TNUMT_E instead of KVD_LINEAR_MANAGER_USER_TNGEE_E as a temporary workaround for
     *  Bug SW #1971750 */
    sx_status =
        kvd_linear_manager_block_add(KVD_LINEAR_MANAGER_USER_TNUMT_E, num_of_entries, FALSE, &g_zeroed_reserved_tngee);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed allocating kvd block, error: %s\n", sx_status_str(sx_status));
        goto out;
    }
    kvd_added = TRUE;

    /* Do not unlock to prevent a relocation */
    sx_status = kvd_linear_manager_handle_lock(g_zeroed_reserved_tngee, &g_zeroed_reserved_tngee_index, &size);
    if ((SX_STATUS_SUCCESS != sx_status) || (size < num_of_entries)) {
        SX_LOG_ERR("Failed to lock a kvd block, kvd_handle: %" PRIu64 ".\n", g_zeroed_reserved_tngee);
        goto out;
    }
    kvd_locked = TRUE;

    tngee_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    tngee_reg_meta.dev_id = 1;
    tngee_reg_meta.swid = 0;

    tngee_reg_data.l2_enc_index = g_zeroed_reserved_tngee_index;

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNGEE_E,
                                            &tngee_reg_data,
                                            &tngee_reg_meta,
                                            num_of_entries,
                                            NULL,
                                            NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to reset reserved TNGEE entry, sxd_err = %u\n", sxd_status);
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (kvd_locked == TRUE) {
            rb_sx_status = kvd_linear_manager_handle_release(g_zeroed_reserved_tngee);
            if (SX_CHECK_FAIL(rb_sx_status)) {
                SX_LOG_ERR("Failed releasing the KVD TNGEE lock at rollback, kvd_handle: %" PRIu64 "\n",
                           g_zeroed_reserved_tngee);
            }
        }

        if (kvd_added == TRUE) {
            rb_sx_status = kvd_linear_manager_block_delete(g_zeroed_reserved_tngee, FALSE);
            if (SX_CHECK_FAIL(rb_sx_status)) {
                SX_LOG_ERR("Failed to delete a KVD TNGEE block during rollback, error: %s\n",
                           sx_status_str(rb_sx_status));
            }
            g_zeroed_reserved_tngee = 0;
            g_zeroed_reserved_tngee_index = 0;
        }

        if (rm_set == TRUE) {
            rb_sx_status = rm_system_entries_set(RM_SDK_TABLE_TYPE_NVE_MC_LIST_E,
                                                 SX_ACCESS_CMD_DELETE,
                                                 num_of_entries,
                                                 NULL);
            if (SX_CHECK_FAIL(rb_sx_status)) {
                SX_LOG_ERR("Failed to release RM TNGEE entry at rollback, error [%s]\n", sx_status_str(rb_sx_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_tunnel_zeroed_reserved_tngee_delete()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    num_of_entries = TUNNEL_RESERVED_TNGEE_ENTRIES_NUM;

    SX_LOG_ENTER();

    sx_status = kvd_linear_manager_handle_release(g_zeroed_reserved_tngee);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed releasing the KVD TNGEE lock, kvd_handle: %" PRIu64 "\n", g_zeroed_reserved_tngee);
        goto out;
    }

    sx_status = kvd_linear_manager_block_delete(g_zeroed_reserved_tngee, FALSE);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed deleting KVD TNGEE block, error: %s\n", sx_status_str(sx_status));
        goto out;
    }
    g_zeroed_reserved_tngee = 0;
    g_zeroed_reserved_tngee_index = 0;

    sx_status = rm_system_entries_set(RM_SDK_TABLE_TYPE_NVE_MC_LIST_E, SX_ACCESS_CMD_DELETE, num_of_entries, NULL);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to delete RM TNGEE entry, error: %s\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_tunnel_nve_udp_sport_hash_set(const sx_tunnel_hash_data_t *hash_data_p,
                                                       hwd_tngcr_t                 *tngcr_cfg_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    switch (hash_data_p->hash_cmd) {
    case SX_TUNNEL_HASH_CMD_SET_ZERO_E:
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_type = SXD_TUNNEL_SPORT_SET_FIX_BITS_E;
        break;

    case SX_TUNNEL_HASH_CMD_CALCULATE_E:
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_type = SXD_TUNNEL_SPORT_USE_HASH_TO_CALCULATE_E;
        if (hash_data_p->nve_data.nve_udp_value_msb_valid) {
            tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix = hash_data_p->nve_data.nve_udp_value_msb;
        } else if (g_global_config.general_params.nve.encap_sport) {
            tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix = g_global_config.general_params.nve.encap_sport;
        }
        break;

    case SX_TUNNEL_HASH_CMD_FIXED_VALUE_E:
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_type = SXD_TUNNEL_SPORT_SET_FIX_BITS_E;
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_suffix = 0; /* 8 LSB of udp sport[0] */
        if (hash_data_p->nve_data.nve_udp_value_msb_valid) {
            tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix = hash_data_p->nve_data.nve_udp_value_msb;
        } else if (g_global_config.general_params.nve.encap_sport) {
            tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix = g_global_config.general_params.nve.encap_sport;
        }
        break;

    default:
        SX_LOG_ERR("Hash cmd %d is unsupported for the tunnel\n",
                   hash_data_p->hash_cmd);
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_tunnel_nve_udp_sport_hash_get(const hwd_tngcr_t     *tngcr_cfg_p,
                                                       sx_tunnel_hash_data_t *hash_data_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    switch (tngcr_cfg_p->ku_tngcr.nve_udp_sport_type) {
    case SXD_TUNNEL_SPORT_SET_FIX_BITS_E:
        if (tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix) {
            hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_FIXED_VALUE_E;
            hash_data_p->nve_data.nve_udp_value_msb_valid = TRUE;
            hash_data_p->nve_data.nve_udp_value_msb = tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix;
        } else {
            hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_SET_ZERO_E;
        }
        break;

    case SXD_TUNNEL_SPORT_USE_HASH_TO_CALCULATE_E:
        hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_CALCULATE_E;
        break;

    default:
        SX_LOG_ERR("Unknown sport type [%u]\n", tngcr_cfg_p->ku_tngcr.nve_udp_sport_type);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_tunnel_nve_udp_sport_hash_and_fix_update(const sx_tunnel_hash_data_t *hash_data_p,
                                                                  hwd_tngcr_t                 *tngcr_cfg_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    switch (hash_data_p->hash_cmd) {
    case SX_TUNNEL_HASH_CMD_SET_ZERO_E:
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_type = SXD_TUNNEL_SPORT_SET_FIX_BITS_E;
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_suffix = 0; /* 8 LSB of udp sport[0] */
        break;

    case SX_TUNNEL_HASH_CMD_CALCULATE_E:
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_type = SXD_TUNNEL_SPORT_USE_HASH_TO_CALCULATE_E;
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_suffix = 0; /* 8 LSB of udp sport[0|hash] */
        break;

    case SX_TUNNEL_HASH_CMD_FIXED_VALUE_E:
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_type = SXD_TUNNEL_SPORT_SET_FIX_BITS_E;
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_suffix = hash_data_p->nve_data.nve_udp_value_lsb; /* 8 LSB of udp sport[nve_udp_value_lsb] */
        break;

    case SX_TUNNEL_HASH_CMD_MODIFIED_HASH_E:
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_type = SXD_TUNNEL_SPORT_USE_HASH_TO_CALCULATE_E;
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_suffix = hash_data_p->nve_data.nve_udp_value_lsb; /* 8 LSB of udp sport[nve_udp_value_lsb|hash] */
        break;

    default:

        SX_LOG_ERR("Hash cmd %d is unsupported for the tunnel\n",
                   hash_data_p->hash_cmd);
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if (SX_TUNNEL_HASH_CMD_SET_ZERO_E != hash_data_p->hash_cmd) {
        if (hash_data_p->nve_data.nve_udp_value_msb_valid) {
            tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix = hash_data_p->nve_data.nve_udp_value_msb;
        } else if (g_global_config.general_params.nve.encap_sport) {
            tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix = g_global_config.general_params.nve.encap_sport;
        }
    } else { /* hash_cmd = SX_TUNNEL_HASH_CMD_SET_ZERO_E */
        tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix = 0;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_tunnel_nve_udp_sport_hash_and_fix_update_get(const hwd_tngcr_t     *tngcr_cfg_p,
                                                                      sx_tunnel_hash_data_t *hash_data_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    switch (tngcr_cfg_p->ku_tngcr.nve_udp_sport_type) {
    case SXD_TUNNEL_SPORT_SET_FIX_BITS_E:
        if (tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix) {
            hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_FIXED_VALUE_E;
            hash_data_p->nve_data.nve_udp_value_msb_valid = TRUE;
            hash_data_p->nve_data.nve_udp_value_msb = tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix;
        } else {
            hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_SET_ZERO_E;
        }
        break;

    case SXD_TUNNEL_SPORT_USE_HASH_TO_CALCULATE_E:
        if (tngcr_cfg_p->ku_tngcr.nve_udp_sport_suffix == 0) {
            hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_CALCULATE_E;
        } else {
            hash_data_p->hash_cmd = SX_TUNNEL_HASH_CMD_MODIFIED_HASH_E;
        }
        if (tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix) {
            hash_data_p->nve_data.nve_udp_value_msb_valid = TRUE;
            hash_data_p->nve_data.nve_udp_value_msb = tngcr_cfg_p->ku_tngcr.nve_udp_sport_prefix;
        }
        break;

    default:
        SX_LOG_ERR("Unknown sport type [%u]\n", tngcr_cfg_p->ku_tngcr.nve_udp_sport_type);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __hwd_tunnel_sffp_defaults_write(void)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     profile_id = TUNNEL_NVE_FLOOD_PROFILE_ID;
    uint8_t     flood_offset = TUNNEL_NVE_FLOOD_OFFSET;

    SX_LOG_ENTER();

    sx_status = __hwd_tunnel_sffp_reg_write(profile_id, SXD_SFFP_TYPE_BROADCAST_E, flood_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set flood offset[%u] for broadcast for profile id %u error: %s \n",
                   flood_offset, profile_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = __hwd_tunnel_sffp_reg_write(profile_id, SXD_SFFP_TYPE_UNKNOWN_UNICAST_E, flood_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set flood offset[%u] for unknown unicast for profile id %u error: %s \n",
                   flood_offset, profile_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = __hwd_tunnel_sffp_reg_write(profile_id, SXD_SFFP_TYPE_UNREGISTERED_MULTICAST_IPV4_E, flood_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set flood offset[%u] for unregistered multicast IPv4 for profile id %u error: %s \n",
                   flood_offset, profile_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = __hwd_tunnel_sffp_reg_write(profile_id, SXD_SFFP_TYPE_UNREGISTERED_MULTICAST_IPV6_E, flood_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set flood offset[%u] for unregistered multicast IPv6 for profile id %u error: %s \n",
                   flood_offset, profile_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = __hwd_tunnel_sffp_reg_write(profile_id, SXD_SFFP_TYPE_UNREGISTERED_MULTICAST_NON_IP_E, flood_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set flood offset[%u] for unregistered multicast non IP for profile id %u error: %s \n",
                   flood_offset, profile_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = __hwd_tunnel_sffp_reg_write(profile_id, SXD_SFFP_TYPE_IPV4_LINK_LOCAL_E, flood_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set flood offset[%u] for IPv4 link local for profile id %u error: %s \n",
                   flood_offset, profile_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = __hwd_tunnel_sffp_reg_write(profile_id, SXD_SFFP_TYPE_IPV6_ALL_HOSTS_E, flood_offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set flood offset[%u] for IPv6 all hosts for profile id %u error: %s \n",
                   flood_offset, profile_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
