/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "hwd_tunnel_db.h"

#include "complib/cl_qpool.h"
#include <complib/cl_dbg.h>
#include "complib/cl_qmap.h"
#include "complib/cl_timer.h"
#include "complib/sx_log.h"
#include "complib/cl_mem.h"
#include "sx/sxd/sxd_emad_tunnel.h"

#include "sx/utils/sx_utils_status.h"

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/sx_mem.h"
#include "sx/utils/dbg_utils.h"
#include "sx/utils/dbg_utils_pretty_printer.h"
#include <sx/sdk/sx_status_convertor.h>

#include <sx/sdk/sx_status_convertor.h>
#include "resource_manager/resource_manager_sdk_table.h"
#include <include/resource_manager/resource_manager.h>

#undef  __MODULE__
#define __MODULE__ TUNNEL

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

typedef enum dgb_hw_decap_ipip_tunnel_db {
    DBG_TUNNEL_DECAP_IPIP_HANDLE_E,
    DBG_TUNNEL_DECAP_IPIP_TYPE_E,
    DBG_TUNNEL_DECAP_IPIP_INDEX_E,
    DBG_TUNNEL_DECAP_IPIP_RIF_E,
    DBG_TUNNEL_DECAP_IPIP_SIP_CH_E,
    DBG_TUNNEL_DECAP_IPIP_TYPE_CH_E,
    DBG_TUNNEL_DECAP_IPIP_GRE_CH_E,
    DBG_TUNNEL_DECAP_IPIP_USIP4_E,
    DBG_TUNNEL_DECAP_IPIP_USIP6_E,
    DBG_TUNNEL_DECAP_IPIP_EXP_KEY_E
} dgb_hw_decap_ipip_tunnel_db_e;

typedef enum dbg_encap_tunnel_db {
    DBG_TUNNEL_ENCAP_HANDLE_E,
    DBG_TUNNEL_ENCAP_INDEX_E,
    DBG_TUNNEL_ENCAP_TYPE_E,
    DBG_TUNNEL_ENCAP_HW_ID_E
} dbg_encap_tunnel_db_e;

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static hwd_tunnel_db_t g_hw_tunnel_db;
static boolean_t       g_db_initialized = FALSE;

#define TUNNEL_HWD_DB_INIT_CHECK()                         \
    if (FALSE == g_db_initialized) {                       \
        err = SX_STATUS_DB_NOT_INITIALIZED;                \
        SX_LOG_ERR("Tunnel HWD DB is not initialized.\n"); \
        goto out;                                          \
    }

/************************************************
 *  Local function declarations
 ***********************************************/
static char* __get_rtdp_name(sxd_rtdp_type_t type)
{
    switch (type) {
    case SXD_RTDP_TYPE_NVE_E:
        return "NVE";

    case SXD_RTDP_TYPE_IPINIP_E:
        return "IPinIP";

    case SXD_RTDP_TYPE_GENERIC_DECAP_E:
        return "Generic";

    default:
        return "UNKNOWN";
    }
}

static sx_status_t __hwd_tunnel_rtdp_db_entry_get(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle,
                                                  hwd_tunnel_decap_entry_t         **hwd_tunnel_rtdp_p)
{
    cl_map_item_t *map_item_p = NULL;
    sx_status_t    err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: Get RTDP entry for handle [0x%" PRIx64 "] from DB.\n", tunnel_block_handle);

    map_item_p = cl_qmap_get(&g_hw_tunnel_db.rtdp_map, tunnel_block_handle);
    if (map_item_p == cl_qmap_end(&g_hw_tunnel_db.rtdp_map)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("Entry for RTDP handle 0x%" PRIx64 " not exists.\n", tunnel_block_handle);
        goto out;
    }
    *hwd_tunnel_rtdp_p = PARENT_STRUCT(map_item_p, hwd_tunnel_decap_entry_t, map_item);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_tunnel_encap_db_entry_get(const hwi_tunnel_hw_encap_handle_t tunnel_encap_key,
                                                   hwd_tunnel_encap_entry_t         **hwd_tunnel_encap_p)
{
    cl_map_item_t *map_item_p = NULL;
    sx_status_t    err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: Get encap entry for handle [%u] from DB.\n", tunnel_encap_key);

    map_item_p = cl_qmap_get(&g_hw_tunnel_db.encap_map, tunnel_encap_key);
    if (map_item_p == cl_qmap_end(&g_hw_tunnel_db.encap_map)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("Failed to get encap entry for handle %u, err = %s\n", tunnel_encap_key,
                   sx_status_str(err));
        goto out;
    }
    *hwd_tunnel_encap_p = PARENT_STRUCT(map_item_p, hwd_tunnel_encap_entry_t, map_item);

out:
    SX_LOG_EXIT();
    return err;
}

static cl_status_t __tunnel_encap_entry_init(void *const p_object, void *context __attribute__(
                                                 (unused)), cl_pool_item_t ** const pp_pool_item)
{
    cl_status_t               err = CL_SUCCESS;
    hwd_tunnel_encap_entry_t *encap_entry = (hwd_tunnel_encap_entry_t*)p_object;

    SX_LOG_ENTER();

    SX_MEM_CLR(encap_entry->data);
    encap_entry->data.hw_tunnel_index = g_hw_tunnel_db.encap_index_last++;
    *pp_pool_item = &(encap_entry->pool_item);
    SX_LOG_EXIT();
    return err;
}

static cl_status_t __tunnel_vtep_entry_init(void *const p_object, void *context __attribute__(
                                                (unused)), cl_pool_item_t ** const pp_pool_item)
{
    cl_status_t              err = CL_SUCCESS;
    hwd_tunnel_vtep_entry_t *vtep_entry_p = (hwd_tunnel_vtep_entry_t*)p_object;

    SX_LOG_ENTER();

    vtep_entry_p->vtep_id = g_hw_tunnel_db.next_vtep_index++;
    *pp_pool_item = &(vtep_entry_p->pool_item);
    SX_LOG_EXIT();
    return err;
}

static void __hwd_tunnel_db_remove_decap_entry(hwi_tunnel_hw_decap_handle_t tunnel_block_handle)
{
    hwd_tunnel_decap_entry_t *tunnel_rtdp_entry_p = NULL;
    cl_map_item_t            *map_item_p = NULL;

    map_item_p = cl_qmap_remove(&g_hw_tunnel_db.rtdp_map, tunnel_block_handle);
    tunnel_rtdp_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_decap_entry_t, map_item);
    cl_qpool_put(&g_hw_tunnel_db.rtdp_pool, &(tunnel_rtdp_entry_p->pool_item));
}

static sx_status_t __hwd_tunnel_db_remove_encap_entry(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    hwd_tunnel_encap_entry_t *hwd_tunnel_encap_entry_p = NULL;
    cl_map_item_t            *map_item_p = NULL;
    cl_pool_item_t           *pool_item;

    SX_LOG_DBG("Remove encap entry for handle [%u]\n", tunnel_encap_handle);
    map_item_p = cl_qmap_remove(&g_hw_tunnel_db.encap_map, tunnel_encap_handle);
    hwd_tunnel_encap_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_encap_entry_t, map_item);

    if ((SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, hwd_tunnel_encap_entry_p->data.type, SX_TUNNEL_TYPE_NVE_MAX)) ||
        (SX_CHECK_RANGE(SX_TUNNEL_TYPE_L2_FLEX_MIN, hwd_tunnel_encap_entry_p->data.type,
                        SX_TUNNEL_TYPE_L2_FLEX_MAX))) {
        pool_item = &hwd_tunnel_encap_entry_p->data.encap_attr.vtep_entry->pool_item;
        if (SX_CHECK_FAIL(err = utils_check_pointer(pool_item, "pool_item"))) {
            goto out;
        }
        cl_qpool_put(&g_hw_tunnel_db.free_vtep_id_pool, pool_item);
        SX_LOG_DBG("Free vtep entry for vtep_id [%u]\n",
                   hwd_tunnel_encap_entry_p->data.encap_attr.vtep_entry->vtep_id);
    }
    cl_qpool_put(&g_hw_tunnel_db.encap_pool, &(hwd_tunnel_encap_entry_p->pool_item));
out:
    return err;
}

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t hwd_tunnel_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    return SX_STATUS_SUCCESS;
}

sx_status_t hwd_tunnel_db_init(const uint32_t tunnel_max_count)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    cl_status_t cl_status = CL_SUCCESS;
    boolean_t   encap_pool_init = FALSE;
    boolean_t   decap_pool_init = FALSE;
    boolean_t   vtep_pool_init = FALSE;

    SX_LOG_ENTER();
    SX_LOG_DBG("Init tunnel HWD DB, the maximum number of tunnels: [%u].\n", tunnel_max_count);

    if (TRUE == g_db_initialized) {
        err = SX_STATUS_DB_ALREADY_INITIALIZED;
        SX_LOG_ERR("Tunnel HWD DB is already initialized.\n");
        goto out;
    }

    g_hw_tunnel_db.encap_index_last = 0;
    cl_status = CL_QPOOL_INIT(&g_hw_tunnel_db.encap_pool, tunnel_max_count,
                              tunnel_max_count, 0, sizeof(hwd_tunnel_encap_entry_t),
                              __tunnel_encap_entry_init, NULL, NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG(SX_LOG_ERROR, "No resources to allocate new tunnel encap pool entry.\n");
        goto out;
    }
    encap_pool_init = TRUE;

    cl_status = CL_QPOOL_INIT(&g_hw_tunnel_db.rtdp_pool, tunnel_max_count,
                              tunnel_max_count, 0, sizeof(hwd_tunnel_decap_entry_t),
                              NULL, NULL, NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG(SX_LOG_ERROR, "No resources to allocate new tunnel decap pool entry.\n");
        goto out;
    }
    decap_pool_init = TRUE;

    g_hw_tunnel_db.next_vtep_index = 0;
    cl_status = CL_QPOOL_INIT(&g_hw_tunnel_db.free_vtep_id_pool,
                              rm_resource_global.tunnel_nve_num_max + rm_resource_global.tunnel_l2_flex_num_max,
                              rm_resource_global.tunnel_nve_num_max + rm_resource_global.tunnel_l2_flex_num_max,
                              0,
                              sizeof(hwd_tunnel_vtep_entry_t),
                              __tunnel_vtep_entry_init, NULL, NULL);
    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG(SX_LOG_ERROR, "No resources to allocate new vtep pool entry.\n");
        goto out;
    }
    vtep_pool_init = TRUE;

    cl_qmap_init(&g_hw_tunnel_db.encap_map);
    cl_qmap_init(&g_hw_tunnel_db.rtdp_map);

    g_db_initialized = TRUE;
out:
    if ((SX_STATUS_SUCCESS != err) && (SX_STATUS_DB_ALREADY_INITIALIZED != err)) {
        /* coverity[dead_error_condition] */
        if (vtep_pool_init) {
            /* coverity[dead_error_line] */
            CL_QPOOL_DESTROY(&g_hw_tunnel_db.free_vtep_id_pool);
        }
        if (decap_pool_init) {
            CL_QPOOL_DESTROY(&g_hw_tunnel_db.rtdp_pool);
        }

        if (encap_pool_init) {
            CL_QPOOL_DESTROY(&g_hw_tunnel_db.encap_pool);
            g_hw_tunnel_db.encap_index_last = 0;
        }
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_db_deinit(boolean_t is_forced)
{
    cl_map_item_t *map_item_p = NULL;
    sx_status_t    err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Deinit tunnel HWD DB, is forced[%u]\n", is_forced);

    if (FALSE == g_db_initialized) {
        if (FALSE == is_forced) {
            err = SX_STATUS_DB_NOT_INITIALIZED;
            SX_LOG_ERR("Tunnel HWD DB is not initialized.\n");
        }
        goto out;
    }

    if (FALSE == is_forced) {
        if ((cl_qmap_count(&g_hw_tunnel_db.encap_map) != 0) ||
            (cl_qmap_count(&g_hw_tunnel_db.rtdp_map) != 0)) {
            err = SX_STATUS_DB_NOT_EMPTY;
            SX_LOG_ERR("Failed to deinit, found used tunnel interface, err: %s.\n", sx_status_str(err));
            goto out;
        }
    }

    map_item_p = cl_qmap_head(&g_hw_tunnel_db.encap_map);
    while (map_item_p != cl_qmap_end(&g_hw_tunnel_db.encap_map)) {
        err = __hwd_tunnel_db_remove_encap_entry(cl_qmap_key(map_item_p));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to remove encap entry err = %s.\n",
                       sx_status_str(err));
        }
        map_item_p = cl_qmap_get_next(&g_hw_tunnel_db.encap_map, cl_qmap_key(map_item_p));
    }
    CL_QPOOL_DESTROY(&g_hw_tunnel_db.free_vtep_id_pool);
    CL_QPOOL_DESTROY(&g_hw_tunnel_db.encap_pool);

    map_item_p = cl_qmap_head(&g_hw_tunnel_db.rtdp_map);
    while (map_item_p != cl_qmap_end(&g_hw_tunnel_db.rtdp_map)) {
        err = kvd_linear_manager_block_delete(cl_qmap_key(map_item_p), FALSE);
        /* coverity[check_return] */
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to release kvd block err = %s.\n",
                       sx_status_str(err));
        }
        __hwd_tunnel_db_remove_decap_entry(cl_qmap_key(map_item_p));
        map_item_p = cl_qmap_get_next(&g_hw_tunnel_db.rtdp_map, cl_qmap_key(map_item_p));
    }
    CL_QPOOL_DESTROY(&g_hw_tunnel_db.rtdp_pool);

    g_db_initialized = FALSE;
    g_hw_tunnel_db.encap_index_last = 0;
out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t hwd_rtdp_db_get(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle, hwd_rtdp_t *hwd_rtdp_p)
{
    hwd_tunnel_decap_entry_t *hwd_tunnel_rtdp_entry_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: get RTDP entry from DB for decap handle [0x%" PRIx64 "]\n", tunnel_block_handle);

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_rtdp_p, "hwd_rtdp_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    err = __hwd_tunnel_rtdp_db_entry_get(tunnel_block_handle, &hwd_tunnel_rtdp_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get RTDP entry from tunnel HWD DB for decap handle [0x%" PRIx64 "],"
                   " err = %s\n", tunnel_block_handle, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(hwd_rtdp_p, &hwd_tunnel_rtdp_entry_p->data);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rtdp_db_get_first(hwd_rtdp_t *hwd_rtdp_p)
{
    hwd_tunnel_decap_entry_t *hwd_tunnel_rtdp_entry_p = NULL;
    cl_map_item_t            *map_item_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: get first RTDP in DB.\n");

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_rtdp_p, "hwd_rtdp_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    map_item_p = cl_qmap_head(&g_hw_tunnel_db.rtdp_map);
    if (map_item_p == cl_qmap_end(&g_hw_tunnel_db.rtdp_map)) {
        err = SX_STATUS_END_OF_DB;
        SX_LOG_DBG("Tunnel HWD RTDP DB is empty.\n");
        goto out;
    }
    hwd_tunnel_rtdp_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_decap_entry_t, map_item);
    SX_MEM_CPY_P(hwd_rtdp_p, &(hwd_tunnel_rtdp_entry_p->data));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rtdp_db_get_next(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle, hwd_rtdp_t *hwd_rtdp_p)
{
    hwd_tunnel_decap_entry_t *hwd_tunnel_rtdp_entry_p = NULL;
    cl_map_item_t            *map_item_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: get next RTDP in DB.\n");

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_rtdp_p, "hwd_rtdp_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    map_item_p = cl_qmap_get_next(&g_hw_tunnel_db.rtdp_map, tunnel_block_handle);
    if (map_item_p == cl_qmap_end(&g_hw_tunnel_db.rtdp_map)) {
        err = SX_STATUS_END_OF_DB;
        SX_LOG_DBG("Reached the last RTDP entry in DB.\n");
        goto out;
    }
    hwd_tunnel_rtdp_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_decap_entry_t, map_item);
    SX_MEM_CPY_P(hwd_rtdp_p, &(hwd_tunnel_rtdp_entry_p->data));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rtdp_db_add(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle, const hwd_rtdp_t *hwd_rtdp_p)
{
    hwd_tunnel_decap_entry_t *tunnel_rtdp_entry_p = NULL;
    cl_pool_item_t           *pool_item_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: add new RTDP entry to DB for decap handle [0x%" PRIx64 "].\n", tunnel_block_handle);

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_rtdp_p, "hwd_rtdp_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    err = __hwd_tunnel_rtdp_db_entry_get(tunnel_block_handle, &tunnel_rtdp_entry_p);
    if (SX_STATUS_SUCCESS == err) {
        err = SX_STATUS_ENTRY_ALREADY_EXISTS;
        SX_LOG_ERR("RTDP entry for handle [0x%" PRIx64 "] already exists in tunnel HWD DB , err = %s\n",
                   tunnel_block_handle, sx_status_str(err));
        goto out;
    } else if (SX_STATUS_ENTRY_NOT_FOUND != err) {
        SX_LOG_ERR("Failed to get RTDP entry for decap handle 0x%" PRIx64 " from tunnel HWD DB , err = %s.\n",
                   tunnel_block_handle, sx_status_str(err));
        goto out;
    }

    pool_item_p = cl_qpool_get(&g_hw_tunnel_db.rtdp_pool);
    if (NULL == pool_item_p) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Out of resources in tunnel HWD RTDP DB, err = %s.\n", sx_status_str(err));
        goto out;
    }
    tunnel_rtdp_entry_p = PARENT_STRUCT(pool_item_p, hwd_tunnel_decap_entry_t, pool_item);
    tunnel_rtdp_entry_p->data.ku_rtdp = hwd_rtdp_p->ku_rtdp;
    cl_qmap_insert(&g_hw_tunnel_db.rtdp_map, tunnel_block_handle, &(tunnel_rtdp_entry_p->map_item));
    err = SX_STATUS_SUCCESS;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rtdp_db_update(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle, const hwd_rtdp_t *hwd_rtdp_p)
{
    hwd_tunnel_decap_entry_t *tunnel_rtdp_entry_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: update RTDP for decap handle [0x%" PRIx64 "] in DB.\n", tunnel_block_handle);

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_rtdp_p, "hwd_rtdp_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    err = __hwd_tunnel_rtdp_db_entry_get(tunnel_block_handle, &tunnel_rtdp_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("RTDP entry for decap handle [0x%" PRIx64 "] doesn't exist in HW DB, err = %s.\n",
                   tunnel_block_handle, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(&(tunnel_rtdp_entry_p->data), hwd_rtdp_p);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rtdp_db_delete(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle)
{
    cl_map_item_t *map_item_p = NULL;
    sx_status_t    err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: delete RTDP entry for decap handle [0x%" PRIx64 "] from HW DB.\n", tunnel_block_handle);

    TUNNEL_HWD_DB_INIT_CHECK();

    map_item_p = cl_qmap_get(&g_hw_tunnel_db.rtdp_map, tunnel_block_handle);
    if (cl_qmap_end(&g_hw_tunnel_db.rtdp_map) == map_item_p) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to delete RTDP entry for decap handle [0x%" PRIx64 "] from HW DB, err = %s.\n",
                   tunnel_block_handle,  sx_status_str(err));
        goto out;
    }

    __hwd_tunnel_db_remove_decap_entry(tunnel_block_handle);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rtdp_db_apply(hwd_rtdp_db_apply_pfn_t pfn, const void *params_p)
{
    hwd_tunnel_decap_entry_t *tunnel_rtdp_entry_p = NULL;
    cl_map_item_t            *map_item_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    TUNNEL_HWD_DB_INIT_CHECK();

    if (NULL == pfn) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Function callback parameter is NULL, err = %s\n", sx_status_str(err));
        goto out;
    }

    map_item_p = cl_qmap_head(&g_hw_tunnel_db.rtdp_map);
    while (map_item_p != cl_qmap_end(&g_hw_tunnel_db.rtdp_map)) {
        tunnel_rtdp_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_decap_entry_t, map_item);
        err = pfn(&tunnel_rtdp_entry_p->data, params_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to apply func on tunnel, err = %s\n", sx_status_str(err));
            goto out;
        }

        map_item_p = cl_qmap_get_next(&g_hw_tunnel_db.rtdp_map, cl_qmap_key(map_item_p));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rtdp_db_index_get(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle,
                                  hwd_tunnel_decap_index_t          *hw_tunnel_index_p)
{
    hwd_tunnel_decap_entry_t *hwd_tunnel_rtdp_entry_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: get rtdp index for decap handle [0x%" PRIx64 "].\n", tunnel_block_handle);

    if (SX_CHECK_FAIL(err = utils_check_pointer(hw_tunnel_index_p, "hw_tunnel_index_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    err = __hwd_tunnel_rtdp_db_entry_get(tunnel_block_handle, &hwd_tunnel_rtdp_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("RTDP entry for decap handle [0x%" PRIx64 "] doesn't exist in HW DB, err = %s\n",
                   tunnel_block_handle, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(hw_tunnel_index_p, &hwd_tunnel_rtdp_entry_p->data.ku_rtdp.tunnel_index);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_rtdp_db_total_rtdp_get(uint32_t *rtdp_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD : Get total number of RTDP entry in DB.\n");

    TUNNEL_HWD_DB_INIT_CHECK();

    if (SX_CHECK_FAIL(err = utils_check_pointer(rtdp_cnt_p, "rtdp_cnt_p"))) {
        goto out;
    }

    *rtdp_cnt_p = cl_qmap_count(&g_hw_tunnel_db.rtdp_map);
    SX_LOG_DBG("Tunnel HWD: total RTDP count is %u.\n", *rtdp_cnt_p);
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_encap_db_add(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                             const hwd_tunnel_encap_data_t     *hwd_encap_p)
{
    hwd_tunnel_encap_entry_t *tunnel_encap_entry_p = NULL;
    cl_pool_item_t           *pool_item_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    TUNNEL_HWD_DB_INIT_CHECK();

    SX_LOG_DBG("Tunnel HWD: add encap entry to DB for handle [%u].\n", tunnel_encap_handle);

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_encap_p, "hwd_encap_p"))) {
        goto out;
    }

    err = __hwd_tunnel_encap_db_entry_get(tunnel_encap_handle, &tunnel_encap_entry_p);
    if (SX_STATUS_SUCCESS == err) {
        err = SX_STATUS_ENTRY_ALREADY_EXISTS;
        SX_LOG_ERR("Tunnel %u already exists in HWD DB , err = %s\n",
                   tunnel_encap_handle, sx_status_str(err));
        goto out;
    } else if (SX_STATUS_ENTRY_NOT_FOUND != err) {
        SX_LOG_ERR("Failed to get encap entry for handle %u from HWD DB , err = %s\n",
                   tunnel_encap_handle, sx_status_str(err));
        goto out;
    }
    err = SX_STATUS_SUCCESS;

    pool_item_p = cl_qpool_get(&g_hw_tunnel_db.encap_pool);
    if (NULL == pool_item_p) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Out of resources in HWD encap DB, err = %s\n", sx_status_str(err));
        goto out;
    }
    tunnel_encap_entry_p = PARENT_STRUCT(pool_item_p, hwd_tunnel_encap_entry_t, pool_item);
    tunnel_encap_entry_p->data.type = hwd_encap_p->type;
    SX_MEM_CPY(tunnel_encap_entry_p->data.encap_attr, hwd_encap_p->encap_attr);
    cl_qmap_insert(&g_hw_tunnel_db.encap_map, tunnel_encap_handle, &(tunnel_encap_entry_p->map_item));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_encap_db_create(hwi_tunnel_hw_encap_handle_t *tunnel_encap_handle_p,
                                hwd_tunnel_encap_data_t      *hwd_encap_p)
{
    hwd_tunnel_encap_entry_t    *tunnel_encap_entry_p = NULL;
    hwi_tunnel_hw_encap_handle_t new_encap_handle = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;
    cl_pool_item_t              *pool_item_p = NULL;
    cl_pool_item_t              *vtep_pool_item_p = NULL;
    hwd_tunnel_vtep_entry_t     *vtep_entry_p = NULL;
    sx_status_t                  err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    TUNNEL_HWD_DB_INIT_CHECK();

    SX_LOG_DBG("Tunnel HWD: create encap entry in DB\n");

    if (SX_CHECK_FAIL(err = utils_check_pointer(tunnel_encap_handle_p, "tunnel_encap_handle_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_encap_p, "hwd_encap_p"))) {
        goto out;
    }

    pool_item_p = cl_qpool_get(&g_hw_tunnel_db.encap_pool);
    if (NULL == pool_item_p) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Out of resources in HWD encap DB, err = %s\n", sx_status_str(err));
        goto out;
    }
    tunnel_encap_entry_p = PARENT_STRUCT(pool_item_p, hwd_tunnel_encap_entry_t, pool_item);

    new_encap_handle = (hwi_tunnel_hw_encap_handle_t)tunnel_encap_entry_p->data.hw_tunnel_index;
    SX_LOG_DBG("Get new encap handle [%u] form the pool\n", new_encap_handle);

    switch (hwd_encap_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        tunnel_encap_entry_p->data.encap_attr.rif_id = hwd_encap_p->encap_attr.rif_id;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
    case SX_TUNNEL_TYPE_NVE_GENEVE:
    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:

        /* get vtep id from pool; */
        vtep_pool_item_p = cl_qpool_get(&g_hw_tunnel_db.free_vtep_id_pool);
        if (NULL == vtep_pool_item_p) {
            err = SX_STATUS_NO_RESOURCES;
            SX_LOG_ERR("Out of resources in free vtep id DB\n");
            goto out;
        }
        vtep_entry_p = PARENT_STRUCT(vtep_pool_item_p, hwd_tunnel_vtep_entry_t, pool_item);
        SX_LOG_DBG("Got vtep id [%u] from pool \n", vtep_entry_p->vtep_id);
        tunnel_encap_entry_p->data.encap_attr.vtep_entry = vtep_entry_p;
        break;
    }
    tunnel_encap_entry_p->data.type = hwd_encap_p->type;
    cl_qmap_insert(&g_hw_tunnel_db.encap_map, new_encap_handle, &(tunnel_encap_entry_p->map_item));
    *tunnel_encap_handle_p = new_encap_handle;
    SX_LOG_DBG("Tunnel HWD: Created new encap entry in DB successfully\n");

out:
    if (SX_CHECK_FAIL(err)) {
        if (NULL != pool_item_p) {
            cl_qpool_put(&g_hw_tunnel_db.encap_pool, pool_item_p);
        }
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_encap_db_delete(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle)
{
    cl_map_item_t *map_item_p = NULL;
    sx_status_t    err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: delete encap entry for handle [%u] from HW DB.\n", tunnel_encap_handle);

    TUNNEL_HWD_DB_INIT_CHECK();

    map_item_p = cl_qmap_get(&g_hw_tunnel_db.encap_map, tunnel_encap_handle);
    if (cl_qmap_end(&g_hw_tunnel_db.encap_map) == map_item_p) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to delete encap entry for handle [%u] from HW DB, err = %s.\n",
                   tunnel_encap_handle,  sx_status_str(err));
        goto out;
    }

    __hwd_tunnel_db_remove_encap_entry(tunnel_encap_handle);
    SX_LOG_DBG("Tunnel HWD: Deleted encap entry successfully\n");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_encap_db_update(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                hwd_tunnel_encap_data_t           *hwd_encap_p)
{
    hwd_tunnel_encap_entry_t *tunnel_encap_entry_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: update encap for handle [%u] in HW DB\n", tunnel_encap_handle);

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_encap_p, "hwd_encap_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    err = __hwd_tunnel_encap_db_entry_get(tunnel_encap_handle, &tunnel_encap_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Encap entry for handle [%u] doesn't exist in HW DB, err = %s\n",
                   tunnel_encap_handle, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY(tunnel_encap_entry_p->data.encap_attr, hwd_encap_p->encap_attr);
    tunnel_encap_entry_p->data.type = hwd_encap_p->type;
    SX_LOG_DBG("Tunnel HWD: updated encap entry in DB successfully\n");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_encap_db_get(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                             hwd_tunnel_encap_data_t           *hwd_encap_p)
{
    hwd_tunnel_encap_entry_t *hwd_tunnel_encap_entry_p;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: get encap attributes from DB for handle [%u].\n", tunnel_encap_handle);

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_encap_p, "hwd_encap_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    err = __hwd_tunnel_encap_db_entry_get(tunnel_encap_handle, &hwd_tunnel_encap_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Encap entry for handle [%u] doesn't exist in HW DB, err = %s\n",
                   tunnel_encap_handle, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(hwd_encap_p, &hwd_tunnel_encap_entry_p->data);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_encap_db_get_first(hwd_tunnel_encap_data_t *hwd_encap_p)
{
    hwd_tunnel_encap_entry_t *hwd_tunnel_encap_entry_p = NULL;
    cl_map_item_t            *map_item_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: get first encap entry from HW DB.\n");

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_encap_p, "hwd_encap_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    SX_MEM_CLR_P(hwd_encap_p);

    map_item_p = cl_qmap_head(&g_hw_tunnel_db.encap_map);
    if (map_item_p == cl_qmap_end(&g_hw_tunnel_db.encap_map)) {
        err = SX_STATUS_END_OF_DB;
        SX_LOG_DBG("Tunnel encap HW DB is empty.\n");
        goto out;
    }
    hwd_tunnel_encap_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_encap_entry_t, map_item);
    SX_MEM_CPY_P(hwd_encap_p, &(hwd_tunnel_encap_entry_p->data));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_encap_db_get_next(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                  hwd_tunnel_encap_data_t           *hwd_encap_p)
{
    hwd_tunnel_encap_entry_t *hwd_tunnel_encap_entry_p;
    cl_map_item_t            *map_item_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: get next encap entry in HW DB.\n");

    if (SX_CHECK_FAIL(err = utils_check_pointer(hwd_encap_p, "hwd_encap_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    SX_MEM_CLR_P(hwd_encap_p);

    map_item_p = cl_qmap_get_next(&g_hw_tunnel_db.encap_map, tunnel_encap_handle);
    if (map_item_p == cl_qmap_end(&g_hw_tunnel_db.encap_map)) {
        err = SX_STATUS_END_OF_DB;
        SX_LOG_DBG("Reached the last encap entry in HW DB.\n");
        goto out;
    }
    hwd_tunnel_encap_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_encap_entry_t, map_item);
    SX_MEM_CPY_P(hwd_encap_p, &(hwd_tunnel_encap_entry_p->data));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_encap_db_index_get(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                   hwd_tunnel_encap_index_t          *hw_tunnel_index_p)
{
    hwd_tunnel_encap_entry_t *hwd_tunnel_encap_entry_p = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel HWD: get encap index for handle [%u].\n", tunnel_encap_handle);

    if (SX_CHECK_FAIL(err = utils_check_pointer(hw_tunnel_index_p, "hw_tunnel_index_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    err = __hwd_tunnel_encap_db_entry_get(tunnel_encap_handle, &hwd_tunnel_encap_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Encap entry for handle [%u] doesn't exist in HW DB, err = %s\n",
                   tunnel_encap_handle, sx_status_str(err));
        goto out;
    }

    switch (hwd_tunnel_encap_entry_p->data.type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        SX_MEM_CPY_P(hw_tunnel_index_p, &hwd_tunnel_encap_entry_p->data.encap_attr.rif_id);
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
    case SX_TUNNEL_TYPE_NVE_GENEVE:
    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        SX_MEM_CPY_P(hw_tunnel_index_p, &hwd_tunnel_encap_entry_p->data.encap_attr.vtep_entry->vtep_id);
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_encap_db_total_count_get(uint32_t *encap_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get total number of encap entry in HWD DB.\n");

    if (SX_CHECK_FAIL(err = utils_check_pointer(encap_cnt_p, "encap_cnt_p"))) {
        goto out;
    }

    TUNNEL_HWD_DB_INIT_CHECK();

    *encap_cnt_p = cl_qmap_count(&g_hw_tunnel_db.encap_map);
    SX_LOG_DBG("HWD total encap count is %u\n", *encap_cnt_p);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t            *map_item_p = NULL;
    hwd_tunnel_encap_entry_t *encap_entry_p = NULL;
    hwd_tunnel_encap_data_t  *encap_data_p = NULL;
    hwd_tunnel_decap_entry_t *decap_entry_p = NULL;
    hwd_rtdp_t               *decap_data_p = NULL;
    uint32_t                  total_count = 0;
    uint32_t                  hw_handle = 0;
    char                      type_str[16] = {0};
    dbg_utils_table_columns_t tunnel_decap_entry_table[] = {
        {"Handle", 10, PARAM_UINT32_E, NULL},
        {"Type", 6, PARAM_STRING_E, NULL},
        {"RTDP Index", 11, PARAM_UINT32_E, NULL},
        {"IRIF", 6, PARAM_UINT16_E, NULL},
        {"SIP check", 9, PARAM_UINT8_E, NULL},
        {"TYPE check", 10, PARAM_UINT8_E, NULL},
        {"GRE key check", 13, PARAM_UINT8_E, NULL},
        {"USIP4", 16, PARAM_IPV4_E, NULL},
        {"USIP6 PTR", 11, PARAM_UINT32_E, NULL},
        {"Exp GRE key", 11, PARAM_UINT32_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    dbg_utils_table_columns_t tunnel_nve_decap_entry_table[] = {
        {"Handle", 10, PARAM_UINT32_E, NULL},
        {"Type", 6, PARAM_STRING_E, NULL},
        {"HW Index", 11, PARAM_UINT32_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    dbg_utils_table_columns_t tunnel_encap_entry_table[] = {
        {"Handle", 11, PARAM_UINT32_E, NULL},
        {"Index", 11, PARAM_UINT32_E, NULL},
        {"Type", 15, PARAM_STRING_E, NULL},
        {"HW ID", 10, PARAM_UINT32_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                     *stream = NULL;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "HWD TUNNEL DB");
    dbg_utils_pprinter_field_print(stream, "DB initialized", &g_db_initialized, PARAM_BOOL_E);

    if (g_db_initialized != TRUE) {
        goto out;
    }

    dbg_utils_pprinter_general_header_print(stream, "TUNNEL DECAP DB");
    total_count = cl_qmap_count(&g_hw_tunnel_db.rtdp_map);
    dbg_utils_pprinter_field_print(stream, "Total count:", &total_count, PARAM_UINT32_E);

    dbg_utils_pprinter_print(stream, "\n");
    dbg_utils_pprinter_table_headline_print(stream, tunnel_decap_entry_table);

    if (!cl_is_qmap_empty(&g_hw_tunnel_db.rtdp_map)) {
        map_item_p = cl_qmap_head(&g_hw_tunnel_db.rtdp_map);
        while (cl_qmap_end(&g_hw_tunnel_db.rtdp_map) != map_item_p) {
            decap_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_decap_entry_t, map_item);

            decap_data_p = &decap_entry_p->data;
            if (decap_data_p->ku_rtdp.type == SXD_RTDP_TYPE_IPINIP_E) {
                hw_handle = (uint32_t)cl_qmap_key(map_item_p);
                tunnel_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_HANDLE_E].data = &hw_handle;
                tunnel_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_TYPE_E].data =
                    __get_rtdp_name(decap_data_p->ku_rtdp.type);
                tunnel_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_INDEX_E].data = &decap_data_p->ku_rtdp.tunnel_index;

                tunnel_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_RIF_E].data =
                    &decap_data_p->ku_rtdp.rtdp_entry.rtdp_ipinip.irif;
                tunnel_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_SIP_CH_E].data =
                    &decap_data_p->ku_rtdp.rtdp_entry.rtdp_ipinip.sip_check;
                tunnel_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_TYPE_CH_E].data =
                    &decap_data_p->ku_rtdp.rtdp_entry.rtdp_ipinip.type_check;
                tunnel_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_GRE_CH_E].data =
                    &decap_data_p->ku_rtdp.rtdp_entry.rtdp_ipinip.gre_key_check;
                tunnel_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_USIP4_E].data =
                    &decap_data_p->ku_rtdp.rtdp_entry.rtdp_ipinip.ipv4_usip;
                tunnel_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_USIP6_E].data =
                    &decap_data_p->ku_rtdp.rtdp_entry.rtdp_ipinip.ipv6_usip_ptr;
                tunnel_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_EXP_KEY_E].data =
                    &decap_data_p->ku_rtdp.rtdp_entry.rtdp_ipinip.expected_gre_key;

                dbg_utils_pprinter_table_data_line_print(stream, tunnel_decap_entry_table);
            }
            map_item_p = cl_qmap_next(map_item_p);
        }

        map_item_p = cl_qmap_head(&g_hw_tunnel_db.rtdp_map);
        while (cl_qmap_end(&g_hw_tunnel_db.rtdp_map) != map_item_p) {
            decap_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_decap_entry_t, map_item);

            /* Use same table for IPinIP and NVE RTDP although for NVE only type and hw index fields are valid.
             * Anyway until only one NVE supported - no need add additional table.
             * However when more NVE will be supported - it's better to add new debug table for them. */
            decap_data_p = &decap_entry_p->data;
            if (decap_data_p->ku_rtdp.type == SXD_RTDP_TYPE_NVE_E) {
                hw_handle = (uint32_t)cl_qmap_key(map_item_p);
                tunnel_nve_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_HANDLE_E].data = &hw_handle;
                tunnel_nve_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_TYPE_E].data =
                    __get_rtdp_name(decap_data_p->ku_rtdp.type);
                tunnel_nve_decap_entry_table[DBG_TUNNEL_DECAP_IPIP_INDEX_E].data = &decap_data_p->ku_rtdp.tunnel_index;
                dbg_utils_pprinter_table_data_line_print(stream, tunnel_nve_decap_entry_table);
            }

            map_item_p = cl_qmap_next(map_item_p);
        }

        dbg_utils_pprinter_general_header_print(stream, "FLEX TUNNEL DECAP DB");
        dbg_utils_pprinter_print(stream, "\n");

        map_item_p = cl_qmap_head(&g_hw_tunnel_db.rtdp_map);
        while (cl_qmap_end(&g_hw_tunnel_db.rtdp_map) != map_item_p) {
            decap_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_decap_entry_t, map_item);

            decap_data_p = &decap_entry_p->data;
            if (decap_data_p->ku_rtdp.type == SXD_RTDP_TYPE_GENERIC_DECAP_E) {
                hw_handle = (uint32_t)cl_qmap_key(map_item_p);

                dbg_utils_pprinter_secondary_header_print(stream, "Handle  %d:", hw_handle);
                dbg_utils_pprinter_field_print(stream, "Type                     :", &decap_data_p->ku_rtdp.type,
                                               PARAM_UINT32_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Tunnel index             :",
                                               &decap_data_p->ku_rtdp.tunnel_index,
                                               PARAM_UINT32_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Checks mode              :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.checks_mode,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Allow decap              :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.allow_decap,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Tqos profile L2          :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.tqos_profile_l2,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Tqos profile L3          :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.tqos_profile_l3,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Tunnel port              :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.tunnel_port,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Checks NVE decap disable :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.checks_nve_decap_disable,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream,
                                               "IRIF                     :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.irif,
                                               PARAM_UINT16_E);
                dbg_utils_pprinter_field_print(stream,
                                               "GRE key check            :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.gre_key_check,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Type check               :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.type_check,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream,
                                               "SIP check                :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.sip_check,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream,
                                               "IPv4 usip                :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.ipv4_usip,
                                               PARAM_UINT32_E);
                dbg_utils_pprinter_field_print(stream,
                                               "IPv6 usip ptr            :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.ipv6_usip_ptr,
                                               PARAM_UINT32_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Expected GRE key         :",
                                               &decap_data_p->ku_rtdp.rtdp_entry.rtdp_generic.expected_gre_key,
                                               PARAM_UINT32_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Egress router interface  :",
                                               &decap_data_p->ku_rtdp.egress_router_interface,
                                               PARAM_UINT16_E);
                dbg_utils_pprinter_print(stream, "\n");
            }

            map_item_p = cl_qmap_next(map_item_p);
        }
    }


    dbg_utils_pprinter_general_header_print(stream, "TUNNEL ENCAP DB");
    total_count = cl_qmap_count(&g_hw_tunnel_db.encap_map);
    dbg_utils_pprinter_field_print(stream, "Total count:", &total_count, PARAM_UINT32_E);
    dbg_utils_pprinter_print(stream, "\n");
    dbg_utils_pprinter_table_headline_print(stream, tunnel_encap_entry_table);

    if (!cl_is_qmap_empty(&g_hw_tunnel_db.encap_map)) {
        map_item_p = cl_qmap_head(&g_hw_tunnel_db.encap_map);
        while (cl_qmap_end(&g_hw_tunnel_db.encap_map) != map_item_p) {
            encap_entry_p = PARENT_STRUCT(map_item_p, hwd_tunnel_encap_entry_t, map_item);
            encap_data_p = &encap_entry_p->data;

            hw_handle = (uint32_t)cl_qmap_key(map_item_p);
            tunnel_encap_entry_table[DBG_TUNNEL_ENCAP_HANDLE_E].data = &hw_handle;
            tunnel_encap_entry_table[DBG_TUNNEL_ENCAP_INDEX_E].data = &encap_data_p->hw_tunnel_index;
            switch (encap_data_p->type) {
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
                snprintf(type_str, sizeof(type_str), "IPINIP_IPV4");
                break;

            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
                snprintf(type_str, sizeof(type_str), "IPINIP_GRE");
                break;

            case SX_TUNNEL_TYPE_NVE_VXLAN:
                snprintf(type_str, sizeof(type_str), "NVE_VXLAN");
                break;

            case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
                snprintf(type_str, sizeof(type_str), "NVE_VXLAN_IPV6");
                break;

            case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
                snprintf(type_str, sizeof(type_str), "NVE_VXLAN_GPE");
                break;

            case SX_TUNNEL_TYPE_NVE_GENEVE:
                snprintf(type_str, sizeof(type_str), "NVE_GENEVE");
                break;

            case SX_TUNNEL_TYPE_NVE_NVGRE:
                snprintf(type_str, sizeof(type_str), "NVE_NVGRE");
                break;

            case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
                snprintf(type_str, sizeof(type_str), "NVE_NVGRE_IPV6");
                break;

            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
                snprintf(type_str, sizeof(type_str), "IPINIP_6IN4");
                break;

            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
                snprintf(type_str, sizeof(type_str), "IPINIP_6IN4_GRE");
                break;

            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
                snprintf(type_str, sizeof(type_str), "IPINIP_4IN6");
                break;

            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
                snprintf(type_str, sizeof(type_str), "IPINIP_4IN6_GRE");
                break;

            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
                snprintf(type_str, sizeof(type_str), "IPINIP_6IN6");
                break;

            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
                snprintf(type_str, sizeof(type_str), "IPINIP_6IN6_GRE");
                break;

            case SX_TUNNEL_TYPE_L2_FLEX:
                snprintf(type_str, sizeof(type_str), "L2_FLEX");
                break;

            case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
                snprintf(type_str, sizeof(type_str), "L2_FLEX_IPV6");
                break;

            default:
                snprintf(type_str, sizeof(type_str), "UNKNOWN");
                break;
            }
            tunnel_encap_entry_table[DBG_TUNNEL_ENCAP_TYPE_E].data = type_str;
            if (SX_CHECK_MAX(encap_data_p->type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
                tunnel_encap_entry_table[DBG_TUNNEL_ENCAP_HW_ID_E].data = &encap_data_p->encap_attr.rif_id;
            } else if ((SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, encap_data_p->type, SX_TUNNEL_TYPE_NVE_MAX)) ||
                       (SX_CHECK_RANGE(SX_TUNNEL_TYPE_L2_FLEX_MIN, encap_data_p->type, SX_TUNNEL_TYPE_L2_FLEX_MAX))) {
                tunnel_encap_entry_table[DBG_TUNNEL_ENCAP_HW_ID_E].data =
                    &encap_data_p->encap_attr.vtep_entry->vtep_id;
            }

            dbg_utils_pprinter_table_data_line_print(stream, tunnel_encap_entry_table);
            map_item_p = cl_qmap_next(map_item_p);
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}
