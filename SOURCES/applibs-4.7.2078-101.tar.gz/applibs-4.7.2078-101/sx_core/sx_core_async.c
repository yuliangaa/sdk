/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <complib/cl_math.h>
#include <complib/cl_map.h>
#include <complib/cl_pool.h>
#include <complib/cl_dbg.h>
#include <complib/cl_list.h>
#include <complib/sx_log.h>

#include <sx/utils/debug_cmd.h>

#include "host_ifc/host_ifc.h"
#include "sx_core_async.h"
#include "sx_core_api.h"
#include "tid_manager/sx_tid_manager.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "sx/sdk/sx_status_convertor.h"

#include "sx_core/sx_core_async.h"

#undef __MODULE__
#define __MODULE__ CORE_ASYNC

/************************************************
 *  Local variables
 ***********************************************/

#define MAX_WORK_QUEUEP_MODULES_NUM 100
#define MAX_SX_API_NUM_PER_MODULE   100

/* Minimum space for async job data item required to work in async mode */
#define MIN_ASYNC_JOB_DATA_CNT_THRESHOLD 2
/* Maximum prio buff occupancy to work async mode */
#define MAX_PRIO_BUFF_ASYNC_THRESHOLD 90

typedef struct sx_core_async_module_entry {
    cl_pool_item_t            pool_item;
    cl_map_item_t             map_item;
    sx_work_queuep_module_e   module;
    cl_qlist_t                api_cmd_list;
    sx_work_queue_pair_info_t dest_queue_pair;
    sx_core_async_pre_send_cb pre_send_cb;
    void                     *pre_send_context;
    sx_work_queuep_job_cb     job_handler_cb;
    void                     *job_handler_context;
    boolean_t                 is_synced;
    boolean_t                 is_internal_cmd;  /* is internal command */
    cl_qpool_t                sx_core_async_job_data_poll;     /* job data poll */
    cl_spinlock_t             sx_core_async_job_data_poll_lock;     /* job data poll lock */
    uint32_t                  sx_core_async_job_data_put_cnt; /* debug counters */
    uint32_t                  sx_core_async_job_data_get_cnt;  /* debug counters */
} sx_core_async_module_entry_t;

typedef struct sx_core_async_api_cmd_entry {
    cl_pool_item_t                pool_item;
    cl_map_item_t                 map_item;
    cl_list_item_t                list_item;
    sx_api_int_cmd_e              api_cmd_id;
    sx_core_async_module_entry_t *module_entry_p;
} sx_core_async_api_cmd_entry_t;

typedef struct sx_core_async_db {
    cl_qpool_t module_pool;
    cl_qpool_t api_cmd_pool;
    cl_qmap_t  module_lookup;
    cl_qmap_t  api_cmd_id_lookup;
    cl_qlist_t api_cmd_cache;
} sx_core_async_db_t;

typedef struct sx_core_async_api_cmd_data {
    cl_list_item_t            list_item;
    sx_api_command_t          api_cmd;
    uint8_t                  *cmd_body_p;
    uint32_t                  cmd_body_size;
    sx_core_prio_buffer_num_e buffer_type;
} sx_core_async_api_cmd_data_t;

/* max jobs  */
#define   SX_CORE_ASYNC_JOB_DATA_POLL_ITEM_MAX 10000


/* async job data poll item */
typedef struct {
    cl_pool_item_t                pool_item;
    sx_core_async_job_data_t      data;          /* job data */
    sx_work_queuep_job_type_id_t  job_type_id;   /* job type id. */
    sx_core_async_module_entry_t *module_entry_p;
    sx_core_prio_buffer_num_e     buffer_type;   /* prio buff type */
} sx_core_async_job_data_poll_item_t;

typedef struct {
    sx_work_queuep_module_e         module_id;
    sx_tid_manager_transaction_id_t tid;
    sx_api_int_cmd_e                cmd_id;
} tid_dbg_tmp;

boolean_t                            g_core_sdk_paused = FALSE;
sx_core_async_fd_t                   core_async_fds;
static boolean_t                     g_core_async_initialized_s = FALSE;
static boolean_t                     g_core_async_issu_in_progress = FALSE;
static sx_core_async_db_t            g_core_async_db_s;
static boolean_t                     command_replied_s = FALSE;
static sx_core_async_module_entry_t *default_module_entry_p_s = NULL;
static cl_spinlock_t                 global_db_mutex_s;
static cl_spinlock_t                 async_db_job_data_mutex_s;
static tid_dbg_tmp                   tid_dbg_s[100];
static uint32_t                      tid_dbg_idx = 0;
static uint32_t                      tid_dbg_init_s = 0;
static uint32_t                      async_completion_trap_cnt_s = 0;
/* counter that count number of time that async module didn't send reply to user during completion queue completion job handler */
static uint32_t                err_cnt_async_module_in_synced_no_reply_s = 0;
static sx_work_queuep_module_e global_module_id_s = SX_WORK_QUEUEP_MODULE_DEFAULT_E;

/* global variable because there is no API to control this variable */
sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

static async_infra_data_t *async_infra_data_p_g = NULL;

/* SX Async parameters */
static sx_async_params_t sx_async_params_g;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_work_queuep_status_t sx_core_async_default_job_handler_cb(sx_work_queuep_job_cb_info_t *job_cb_info_p);
static sx_core_async_job_data_poll_item_t * sx_core_async_obtain_job_data_item(
    sx_core_async_module_entry_t *module_entry_p);
static sx_status_t sx_core_async_job_data_count_get(sx_core_async_module_entry_t *module_entry_p,
                                                    uint32_t                     *cnt_p);
static sx_status_t sx_core_async_completion_trap_send(sx_work_queuep_job_info_t *job_info_p);

/*
 * Get module entry which registered to API Command
 *
 * @param[in] cmd_id - Operation code of an SX-API command
 * @param[out] module_entry_p - Module entry
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
static sx_status_t __core_async_api_module_entry_get(sx_api_int_cmd_e               cmd_id,
                                                     sx_core_async_module_entry_t **module_entry_p);

/*
 * Call completion job callback
 *
 * @param[in] completion_job_info_p - completion job info
 * @param[in] module_id - module ID
 * @param[in] module_id - completion queue ID
 * @param[in] module_id - completion context, if any
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_NULL if callback function is not defined.
 * @return SX_STATUS_ERROR general error.
 */
static sx_status_t __sx_core_async_api_call_completion(sx_work_queuep_job_info_t *completion_job_info_p,
                                                       sx_work_queuep_module_id_t module_id,
                                                       sx_work_queue_id_t         completion_queue_id,
                                                       void                      *completion_ctx_p);

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sx_core_async_log_verbosity_level_set(sx_verbosity_level_t level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = level;

    return err;
}

sx_status_t sx_core_async_init(const sx_core_async_params_t *params)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    cl_status_t             cl_err = CL_SUCCESS;
    boolean_t               module_pool_initialized = FALSE;
    sx_tid_manager_params_t tid_manager_params;

    async_infra_data_p_g = (async_infra_data_t*)params->g_ctx;

    if (g_core_async_initialized_s == TRUE) {
        sx_status = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("core async is already initialized.\n");
        goto out;
    }

    SX_MEM_CLR(core_async_fds);
    SX_MEM_CLR(tid_manager_params);
    FD_ZERO(&core_async_fds.fds);
    FD_ZERO(&core_async_fds.fds_err);
    default_module_entry_p_s = NULL;

    sx_status = sx_tid_manager_init(&tid_manager_params);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at tid manager init.\n");
        goto out;
    }

    cl_err = cl_spinlock_init(&global_db_mutex_s);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Could not open global db mutex.\n");
        goto out;
    }

    cl_err = CL_QPOOL_INIT(&g_core_async_db_s.module_pool,
                           MAX_WORK_QUEUEP_MODULES_NUM,
                           MAX_WORK_QUEUEP_MODULES_NUM,
                           0, sizeof(sx_core_async_module_entry_t), NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Failed to initialize sx_core_async db module pool: %s\n", CL_STATUS_MSG(cl_err));
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }
    module_pool_initialized = TRUE;

    cl_err = CL_QPOOL_INIT(&g_core_async_db_s.api_cmd_pool,
                           MAX_WORK_QUEUEP_MODULES_NUM * MAX_SX_API_NUM_PER_MODULE,
                           MAX_WORK_QUEUEP_MODULES_NUM * MAX_SX_API_NUM_PER_MODULE,
                           0, sizeof(sx_core_async_api_cmd_entry_t), NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Failed to initialize sx_core_async db module pool: %s\n", CL_STATUS_MSG(cl_err));
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cl_qmap_init(&g_core_async_db_s.module_lookup);
    cl_qmap_init(&g_core_async_db_s.api_cmd_id_lookup);
    cl_qlist_init(&g_core_async_db_s.api_cmd_cache);

    g_core_async_initialized_s = TRUE;

out:
    if (sx_status != SX_STATUS_SUCCESS) {
        if (module_pool_initialized) {
            CL_QPOOL_DESTROY(&g_core_async_db_s.module_pool);
        }
    }

    return sx_status;
}

sx_status_t sx_core_async_deinit(void)
{
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t                 *map_item_p = NULL;
    sx_core_async_module_entry_t  *module_entry_p = NULL;
    sx_core_async_api_cmd_entry_t *api_cmd_entry_p = NULL;

    if (g_core_async_initialized_s == FALSE) {
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("core async is not initialized.\n");
        goto out;
    }

    sx_status = sx_tid_manager_deinit();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at tid manager deinit.\n");
    }

    map_item_p = cl_qmap_head(&(g_core_async_db_s.module_lookup));
    while (map_item_p != cl_qmap_end(&(g_core_async_db_s.module_lookup))) {
        module_entry_p = PARENT_STRUCT(map_item_p, sx_core_async_module_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);
        FD_CLR(module_entry_p->dest_queue_pair.completion_queue_fd[0], &core_async_fds.fds);
        FD_CLR(module_entry_p->dest_queue_pair.completion_queue_fd[0], &core_async_fds.fds_err);
        cl_qlist_remove_all(&module_entry_p->api_cmd_list);
        cl_qpool_put(&g_core_async_db_s.module_pool, &module_entry_p->pool_item);
    }

    map_item_p = cl_qmap_head(&(g_core_async_db_s.api_cmd_id_lookup));
    while (map_item_p != cl_qmap_end(&(g_core_async_db_s.api_cmd_id_lookup))) {
        api_cmd_entry_p = PARENT_STRUCT(map_item_p, sx_core_async_api_cmd_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);
        cl_qpool_put(&g_core_async_db_s.api_cmd_pool, &api_cmd_entry_p->pool_item);
    }

    cl_qlist_remove_all(&g_core_async_db_s.api_cmd_cache);
    cl_qmap_remove_all(&g_core_async_db_s.api_cmd_id_lookup);
    cl_qmap_remove_all(&g_core_async_db_s.module_lookup);
    CL_QPOOL_DESTROY(&g_core_async_db_s.api_cmd_pool);
    CL_QPOOL_DESTROY(&g_core_async_db_s.module_pool);
    default_module_entry_p_s = NULL;

    cl_spinlock_destroy(&global_db_mutex_s);
    g_core_async_initialized_s = FALSE;

out:
    return sx_status;
}

sx_status_t sx_core_async_params_set(const sx_async_params_t *params)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if ((params->accepted_return_status != SX_STATUS_SUCCESS) &&
        (params->accepted_return_status != SX_STATUS_ACCEPTED)) {
        sx_status = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("SX Async Accepted return status error . can be only SX_STATUS_SUCCESS or SX_STATUS_ACCEPTED\n");
        goto out;
    }
    /* Validate */
    sx_async_params_g = *params;

out:
    return sx_status;
}

sx_status_t sx_core_async_params_get(sx_async_params_t *params)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (params == NULL) {
        /* ERROR */
        SX_LOG_ERR("Input params is NULL\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    *params = sx_async_params_g;

out:
    return sx_status;
}

sx_status_t sx_core_async_module_register(const sx_access_cmd_t                   cmd,
                                          sx_work_queuep_module_e                 module,
                                          sx_core_async_module_register_params_t *params)
{
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    cl_pool_item_t                *pool_item_p = NULL;
    cl_map_item_t                 *map_item_p = NULL;
    const cl_list_item_t          *list_item_p = NULL;
    sx_core_async_module_entry_t  *module_entry_p = NULL;
    sx_core_async_api_cmd_entry_t *api_cmd_entry_p = NULL;
    uint32_t                       idx = 0;
    sx_api_int_cmd_e              *api_cmd_id = params->api_cmd_id;
    uint32_t                       num_of_api_commands = params->num_of_api_commands;
    sx_work_queue_pair_info_t     *dest_queue_pair_p = params->dest_queue_pair_p;
    sx_core_async_pre_send_cb      pre_send_cb = params->pre_send_cb;
    void                          *pre_send_context = params->pre_send_context;
    sx_work_queuep_job_cb          job_handler_cb = params->job_handler_cb;
    void                          *job_handler_context = params->job_handler_context;
    boolean_t                      is_synced = params->is_synced;
    sx_work_queuep_status_t        wq_err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    uint32_t                       queue_size = 0;
    cl_status_t                    cl_err;

    if (g_core_async_initialized_s != TRUE) {
        SX_LOG_ERR("sx_core_async is not initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }
    if (!WORK_QUEUEP_MODULE_CHECK_RANGE(module)) {
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Module %u is out of range.\n", module);
    }
    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        if (cl_qmap_contains(&g_core_async_db_s.module_lookup, module)) {
            sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
            SX_LOG_ERR("Module %u is already registered.\n", module);
            goto out;
        }

        for (idx = 0; idx < num_of_api_commands; idx++) {
            if (!SX_CHECK_RANGE(SX_API_INT_CMD_MIN_E, (int)api_cmd_id[idx], SX_API_INT_CMD_MAX_E)) {
                sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
                SX_LOG_ERR("Command %u is out of range.\n", api_cmd_id[idx]);
            }
            if (cl_qmap_contains(&g_core_async_db_s.api_cmd_id_lookup, api_cmd_id[idx])) {
                sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
                SX_LOG_ERR("Command %u already registered.\n", api_cmd_id[idx]);
                goto out;
            }
        }

        /* Build module entry and insert to global module entry map */
        pool_item_p = cl_qpool_get(&g_core_async_db_s.module_pool);
        if (pool_item_p == NULL) {
            SX_LOG_ERR("Failed to allocate resource for module %u.\n", module);
            sx_status = SX_STATUS_NO_RESOURCES;
            goto out;
        }
        module_entry_p = PARENT_STRUCT(pool_item_p, sx_core_async_module_entry_t, pool_item);
        module_entry_p->module = module;
        cl_qlist_init(&module_entry_p->api_cmd_list);
        cl_qmap_insert(&g_core_async_db_s.module_lookup, module, &module_entry_p->map_item);

        SX_MEM_CPY_P(&module_entry_p->dest_queue_pair, dest_queue_pair_p);
        module_entry_p->pre_send_cb = pre_send_cb;
        module_entry_p->pre_send_context = pre_send_context;
        module_entry_p->job_handler_context = job_handler_context;
        module_entry_p->is_synced = is_synced;
        module_entry_p->is_internal_cmd = params->is_internal_cmd;


        if (module == SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
            default_module_entry_p_s = module_entry_p;
            module_entry_p->job_handler_cb = sx_core_async_default_job_handler_cb;
            /* for default module job data pool queue size is 0 */
        } else {
            wq_err = sx_work_queue_size_get(module_entry_p->dest_queue_pair.queue_id, &queue_size);
            if (wq_err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
                SX_LOG_ERR("SX core async module [%u] register failed. sx_work_queue_size_get wq_err=[%d]\n",
                           module,
                           wq_err);
                goto out;
            }

            if (CL_SUCCESS != CL_QPOOL_INIT(&module_entry_p->sx_core_async_job_data_poll,
                                            queue_size,
                                            queue_size,
                                            0,
                                            sizeof(sx_core_async_job_data_poll_item_t),
                                            NULL,
                                            NULL,
                                            NULL)) {
                SX_LOG_ERR("SX core async module [%u] register failed to init sx core async job data pool\n", module);
                sx_status = SX_STATUS_NO_RESOURCES;
                goto out;
            }
            cl_spinlock_init(&(module_entry_p->sx_core_async_job_data_poll_lock));

            module_entry_p->sx_core_async_job_data_get_cnt = 0;
            module_entry_p->sx_core_async_job_data_put_cnt = 0;
            cl_err = cl_spinlock_init(&async_db_job_data_mutex_s);
            if (cl_err != CL_SUCCESS) {
                SX_LOG_ERR("Could not open async db job data mutex.\n");
                CL_QPOOL_DESTROY(&module_entry_p->sx_core_async_job_data_poll);
                goto out;
            }

            module_entry_p->job_handler_cb = job_handler_cb;
        }

        /* Build api entry and insert to api list of module and global api map */
        for (idx = 0; idx < num_of_api_commands; idx++) {
            if (cl_qmap_contains(&g_core_async_db_s.api_cmd_id_lookup, api_cmd_id[idx])) {
                SX_LOG_DBG("Command %u already added.\n", api_cmd_id[idx]);
                continue;
            }
            pool_item_p = cl_qpool_get(&g_core_async_db_s.api_cmd_pool);
            if (pool_item_p == NULL) {
                SX_LOG_ERR("Failed to allocate resource for API command %u.\n", api_cmd_id[idx]);
                sx_status = SX_STATUS_NO_RESOURCES;
                goto out;
            }
            api_cmd_entry_p = PARENT_STRUCT(pool_item_p, sx_core_async_api_cmd_entry_t, pool_item);
            api_cmd_entry_p->api_cmd_id = api_cmd_id[idx];
            api_cmd_entry_p->module_entry_p = module_entry_p;
            cl_qmap_insert(&g_core_async_db_s.api_cmd_id_lookup,
                           api_cmd_entry_p->api_cmd_id,
                           &api_cmd_entry_p->map_item);
            cl_qlist_insert_tail(&module_entry_p->api_cmd_list, &api_cmd_entry_p->list_item);
        }

        break;

    case SX_ACCESS_CMD_UNSET:
        map_item_p = cl_qmap_get(&g_core_async_db_s.module_lookup, module);
        if (map_item_p == cl_qmap_end(&g_core_async_db_s.module_lookup)) {
            sx_status = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        module_entry_p = PARENT_STRUCT(map_item_p, sx_core_async_module_entry_t, map_item);
        FD_CLR(module_entry_p->dest_queue_pair.completion_queue_fd[0], &core_async_fds.fds);
        FD_CLR(module_entry_p->dest_queue_pair.completion_queue_fd[0], &core_async_fds.fds_err);
        SX_MEM_CLR(module_entry_p->dest_queue_pair);
        module_entry_p->pre_send_cb = NULL;
        module_entry_p->pre_send_context = NULL;
        module_entry_p->job_handler_cb = NULL;
        module_entry_p->job_handler_context = NULL;
        module_entry_p->is_synced = FALSE;

        if (module == SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
            default_module_entry_p_s = NULL;
        } else {
            if (cl_is_state_valid(module_entry_p->sx_core_async_job_data_poll.qcpool.state)) {
                cl_spinlock_acquire(&(module_entry_p->sx_core_async_job_data_poll_lock));
                CL_QPOOL_DESTROY(&module_entry_p->sx_core_async_job_data_poll);
                cl_spinlock_release(&(module_entry_p->sx_core_async_job_data_poll_lock));
                cl_spinlock_destroy(&(module_entry_p->sx_core_async_job_data_poll_lock));
            }

            cl_spinlock_destroy(&async_db_job_data_mutex_s);
        }

        list_item_p = cl_qlist_head(&module_entry_p->api_cmd_list);
        while (list_item_p != cl_qlist_end(&module_entry_p->api_cmd_list)) {
            api_cmd_entry_p = PARENT_STRUCT(list_item_p, sx_core_async_api_cmd_entry_t, list_item);
            list_item_p = cl_qlist_next(list_item_p);
            cl_qmap_remove(&g_core_async_db_s.api_cmd_id_lookup, api_cmd_entry_p->api_cmd_id);
            cl_qpool_put(&g_core_async_db_s.api_cmd_pool, &api_cmd_entry_p->pool_item);
        }

        cl_qlist_remove_all(&module_entry_p->api_cmd_list);
        cl_qmap_remove(&g_core_async_db_s.module_lookup, module);
        cl_qpool_put(&g_core_async_db_s.module_pool, &module_entry_p->pool_item);


        break;

    default:
        SX_LOG_ERR("Unsupported access cmd %u\n", cmd);
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

out:
    return sx_status;
}

sx_work_queuep_status_t sx_core_async_default_job_handler_cb(sx_work_queuep_job_cb_info_t *job_cb_info_p)
{
    sx_work_queuep_status_t   sx_work_queuep_status = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    sx_core_async_job_data_t *logic_job_data_p = NULL;

    if (job_cb_info_p == NULL) {
        goto out;
    }
    if (job_cb_info_p->job_data == NULL) {
        goto out;
    }


    /* Call API function directly for default module */
    logic_job_data_p = (sx_core_async_job_data_t*)job_cb_info_p->job_data;
    logic_job_data_p->tid_state = SX_TID_MANAGER_TRANSACTION_ID_STATE_IN_EXECUTE;
    sx_status = logic_job_data_p->cmd.func((sx_core_td_event_src_t*)logic_job_data_p->cookie,
                                           (uint8_t*)logic_job_data_p->cmd_body,
                                           logic_job_data_p->cmd_body_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to to call handler func of API.\n");
        sx_work_queuep_status = SX_WORK_QUEUEP_STATUS_ERROR;
    }
    logic_job_data_p->cmd_sx_status = sx_status;

    /* Already replied to API client in API function, mark it */
    command_replied_s = TRUE;

out:
    return sx_work_queuep_status;
}

/* get sx core async job data free space */
static sx_status_t sx_core_async_job_data_count_get(sx_core_async_module_entry_t *module_entry_p,
                                                    uint32_t                     *cnt_p)
{
    uint32_t    num = 0;
    sx_status_t sx_status = SX_STATUS_SUCCESS;


    num = cl_qpool_count(&module_entry_p->sx_core_async_job_data_poll);

    *cnt_p = num;

    return sx_status;
}

static sx_core_async_job_data_poll_item_t * sx_core_async_obtain_job_data_item(
    sx_core_async_module_entry_t *module_entry_p)
{
    cl_pool_item_t                     *pool_item_p = NULL;
    sx_core_async_job_data_poll_item_t *item_p = NULL;

    cl_spinlock_acquire(&(module_entry_p->sx_core_async_job_data_poll_lock));
    pool_item_p = cl_qpool_get(&module_entry_p->sx_core_async_job_data_poll);

    if (!pool_item_p) {
        SX_LOG_ERR("sx core async job data pool returned nothing (no free item left)\n");
        goto out;
    }

    item_p = PARENT_STRUCT(pool_item_p, sx_core_async_job_data_poll_item_t, pool_item);

    module_entry_p->sx_core_async_job_data_get_cnt++;

out:
    cl_spinlock_release(&(module_entry_p->sx_core_async_job_data_poll_lock));
    return item_p;
}

/* Delete queue item and return it to the pool */
sx_status_t sx_core_async_delete_job_data_item(void *sx_core_async_job_ctx)
{
    sx_core_async_job_data_poll_item_t *job_data_poll_item_p =
        (sx_core_async_job_data_poll_item_t*)sx_core_async_job_ctx;
    sx_core_async_module_entry_t *module_entry_p = job_data_poll_item_p->module_entry_p;

    cl_spinlock_acquire(&(module_entry_p->sx_core_async_job_data_poll_lock));
    cl_qpool_put(&module_entry_p->sx_core_async_job_data_poll,
                 &job_data_poll_item_p->pool_item);
    cl_spinlock_release(&(module_entry_p->sx_core_async_job_data_poll_lock));

    module_entry_p->sx_core_async_job_data_put_cnt++;

    return SX_STATUS_SUCCESS;
}


/* check if API Command is registered to async infra */
sx_status_t sx_core_is_api_command_async(sx_api_int_cmd_e cmd_id, boolean_t     *is_async_api_p)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t *map_item_p = NULL;

    *is_async_api_p = FALSE;

    map_item_p = cl_qmap_get(&g_core_async_db_s.api_cmd_id_lookup, cmd_id);
    if (map_item_p != cl_qmap_end(&g_core_async_db_s.api_cmd_id_lookup)) {
        /* API is registered to async infra */
        *is_async_api_p = TRUE;
    }

    return sx_status;
}

/* Get module entry which registered to API Command */
sx_status_t __core_async_api_module_entry_get(sx_api_int_cmd_e cmd_id, sx_core_async_module_entry_t **module_entry_p)
{
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t                 *map_item_p = NULL;
    sx_core_async_api_cmd_entry_t *api_cmd_entry_p = NULL;

    map_item_p = cl_qmap_get(&g_core_async_db_s.api_cmd_id_lookup, cmd_id);
    if (map_item_p != cl_qmap_end(&g_core_async_db_s.api_cmd_id_lookup)) {
        /* API is registered to async infra */
        api_cmd_entry_p = PARENT_STRUCT(map_item_p, sx_core_async_api_cmd_entry_t, map_item);
        *module_entry_p = api_cmd_entry_p->module_entry_p;
    } else {
        /* API is not registered, use Default module to process it */
        if (default_module_entry_p_s == NULL) {
            SX_LOG_ERR("__core_async_api_module_entry_get Default module is not registered.\n");
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
        *module_entry_p = default_module_entry_p_s;
    }

out:
    return sx_status;
}


sx_status_t sx_core_async_api_command_process(sx_api_command_t         *cmd_p,
                                              sx_core_td_event_src_t   *event_p,
                                              uint8_t                  *cmd_body_p,
                                              uint32_t                  cmd_body_size,
                                              sx_core_prio_buffer_num_e buffer_type)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    sx_status_t                            sx_status_rollback = SX_STATUS_SUCCESS;
    sx_status_t                            cmd_sx_status = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t                work_queuep_rc = SX_WORK_QUEUEP_STATUS_SUCCESS;
    cl_map_item_t                         *map_item_p = NULL;
    sx_core_async_api_cmd_entry_t         *api_cmd_entry_p = NULL;
    sx_work_queuep_module_e                module_id = SX_WORK_QUEUEP_MODULE_DEFAULT_E;
    sx_core_async_module_entry_t          *module_entry_p = NULL;
    sx_work_queue_pair_info_t             *dest_queue_pair_p = NULL;
    sx_core_async_pre_send_cb              pre_send_cb = NULL;
    sx_core_async_api_data_t               api_data;
    boolean_t                              is_synced = TRUE;
    sx_tid_manager_transaction_id_params_t tid_params;
    sx_tid_manager_transaction_id_t        tid = 0;
    sx_work_queuep_job_info_t              job_info;
    sx_core_async_job_data_t               job_data;
    sx_core_async_job_data_t              *job_data_p = &job_data;
    sx_core_prio_buffer_num_e              job_data_buffer_type = 0;
    sx_core_async_job_data_t              *completion_job_data_p = NULL;
    sx_work_queuep_job_info_t              completion_job_info;
    sx_work_queuep_job_info_t             *completion_job_info_p = &completion_job_info;
    sx_core_async_job_data_poll_item_t    *sx_core_async_job_data_poll_item_p = NULL;
    sx_core_async_job_data_poll_item_t    *sx_core_async_completion_job_data_poll_item_p = NULL;
    boolean_t                              is_global_lock = FALSE;
    uint32_t                               job_data_cnt = 0;
    sx_core_async_pre_send_output_t        async_pre_send_output = {0};
    sx_work_queuep_job_type_id_t           job_type_id;
    sx_work_queuep_job_cb_info_t           job_cb_info;
    boolean_t                              cont_pop = TRUE;
    sx_boot_mode_e                         utils_boot_mode = SX_BOOT_MODE_DISABLED_E;
    sx_core_async_api_cmd_data_t          *cmd_data_p = NULL;
    cl_list_item_t                        *list_item_p = NULL;
    boolean_t                              pre_send_err = FALSE;
    boolean_t                              default_tid_get = FALSE;
    boolean_t                              reg_bulk_stage_set = FALSE;


    if (g_core_async_initialized_s != TRUE) {
        SX_LOG_ERR("sx_core_async is not initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    command_replied_s = FALSE;

    if ((g_core_sdk_paused == TRUE) && (cmd_p->cmd_id == SX_API_INT_CMD_ISSU_PAUSE_SET_E)) {
        SX_LOG_ERR("sx sdk is already paused, cannot pause it again.\n");
        sx_status = SX_STATUS_CMD_UNPERMITTED;
        goto out;
    }

    if ((g_core_sdk_paused == FALSE) && (cmd_p->cmd_id == SX_API_INT_CMD_ISSU_RESUME_SET_E)) {
        SX_LOG_ERR("sx sdk is not paused, cannot resume it.\n");
        sx_status = SX_STATUS_CMD_UNPERMITTED;
        goto out;
    }

    if ((g_core_sdk_paused == TRUE) && (cmd_p->cmd_id != SX_API_INT_CMD_ISSU_RESUME_SET_E)) {
        switch (cmd_p->cmd_id) {
        case SX_API_INT_CMD_GC_ACTIVATE_BACKGROUND_SET_E:
            cmd_data_p = cl_malloc(sizeof(sx_core_async_api_cmd_data_t));
            if (cmd_data_p == NULL) {
                sx_status = SX_STATUS_NO_MEMORY;
                goto out;
            }
            SX_MEM_CLR_BUF(cmd_data_p, sizeof(sx_core_async_api_cmd_data_t));
            cmd_data_p->api_cmd = *cmd_p;
            cmd_data_p->buffer_type = buffer_type;
            if (cmd_body_size > 0) {
                cmd_data_p->cmd_body_p = cmd_body_p;
            }
            cl_qlist_insert_tail(&g_core_async_db_s.api_cmd_cache, &cmd_data_p->list_item);
            break;

        default:
            break;
        }
        goto out;
    }

    switch (cmd_p->cmd_id) {
    case SX_API_INT_CMD_ISSU_PAUSE_SET_E:
        g_core_sdk_paused = TRUE;
        break;

    case SX_API_INT_CMD_ISSU_RESUME_SET_E:
        break;

    default:
        break;
    }

    map_item_p = cl_qmap_get(&g_core_async_db_s.api_cmd_id_lookup, cmd_p->cmd_id);
    if (map_item_p != cl_qmap_end(&g_core_async_db_s.api_cmd_id_lookup)) {
        /* API is registered, use parent module to process it */
        api_cmd_entry_p = PARENT_STRUCT(map_item_p, sx_core_async_api_cmd_entry_t, map_item);
        module_entry_p = api_cmd_entry_p->module_entry_p;
    } else {
        /* API is not registered, use Default module to process it */
        if (default_module_entry_p_s == NULL) {
            SX_LOG_ERR("Default module is not registered.\n");
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
        module_entry_p = default_module_entry_p_s;
    }

    /* When ISSU is in progress ALL commands are rejected */

    if (sx_core_async_issu_in_progress_get() == TRUE) {
        SX_LOG_NTC("API rejected, ISSU in progress.\n");
        sx_status = SX_STATUS_ISSU_IN_PROGRESS;
        goto out;
    }

    if (cmd_p->cmd_id == SX_API_INT_CMD_ISSU_START_SET_E) {
        sx_status = utils_boot_mode_get(&utils_boot_mode);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR(" failed to get utils boot mode err = %s\n", sx_status_str(sx_status));
            goto out;
        }
        if ((utils_boot_mode == SX_BOOT_MODE_ISSU_NORMAL_E) ||
            (utils_boot_mode == SX_BOOT_MODE_ISSU_FAST_E)) {
            sx_core_async_issu_in_progress_enable();
        }
    }


    pre_send_cb = module_entry_p->pre_send_cb;
    is_synced = module_entry_p->is_synced;
    module_id = module_entry_p->module;
    job_type_id = cmd_p->cmd_id;
    dest_queue_pair_p = &module_entry_p->dest_queue_pair;
    global_module_id_s = module_id;

    if (module_id != SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
        sx_status = sx_core_async_job_data_count_get(module_entry_p, &job_data_cnt);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("sx_core_async_api_command_process Failed to get async job data count. tid [%" PRIX64 "]\n",
                       tid);
            goto out;
        }

        /* get job data item from poll */
        sx_core_async_job_data_poll_item_p = sx_core_async_obtain_job_data_item(module_entry_p);
        if (sx_core_async_job_data_poll_item_p == NULL) {
            /* Failed to get async job data item. Move to synced. */
            SX_LOG_ERR("sx_core_async_api_command_process Failed to get async job data item. tid [%" PRIX64 "].\n",
                       tid);
            goto out;
        }

        /* Build job data and info */
        /* free job data will be upon completion. */
        job_data_p = &sx_core_async_job_data_poll_item_p->data;
        sx_core_async_job_data_poll_item_p->module_entry_p = module_entry_p;
        sx_core_async_job_data_poll_item_p->job_type_id = job_type_id;
        sx_core_async_job_data_poll_item_p->buffer_type = buffer_type;
    }

    /* Skip memory clear to improve performance */
    SX_MEM_CPY(job_data_p->cmd, *cmd_p);
    job_data_p->cmd_body = (void*)cmd_body_p;

    if (pre_send_cb) {
        api_data.cmd_body_p = cmd_body_p;
        api_data.cmd_body_size = cmd_body_size;
        api_data.cmd_p = cmd_p;

        if (module_id != SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
            sx_status = sx_reg_bulk_stage_set(SX_REG_BULK_STAGE_ASYNC_PRE_SEND_E);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("sx_core_async_api_command_process - failed to set Reg Bulk stage, rc = [%d]-[%s]\n",
                           sx_status, sx_status_str(sx_status));
                goto out;
            }
            reg_bulk_stage_set = TRUE;
        }

        sx_status = pre_send_cb(module_entry_p->pre_send_context, &api_data, &async_pre_send_output);
        if (sx_status != SX_STATUS_SUCCESS) {
            cmd_sx_status = sx_status;
            SX_LOG_NTC("Error at pre send callback status [%s]\n", SX_STATUS_MSG(sx_status));
            pre_send_err = TRUE;
            goto out;
        }

        if (module_id != SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
            sx_status = sx_reg_bulk_stage_reset();
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("sx_core_async_api_command_process - failed to reset Reg Bulk stage, rc = [%d]-[%s]\n",
                           sx_status, sx_status_str(sx_status));
                goto out;
            }
            reg_bulk_stage_set = FALSE;
        }

        is_synced = async_pre_send_output.synced;
    }

    /* Check if asynchronous API behavior is enabled. This is set by the user on init */
    if (sx_async_params_g.enabled == FALSE) {
        is_synced = TRUE;
    }

    if ((is_synced != TRUE) && (job_data_cnt <= MIN_ASYNC_JOB_DATA_CNT_THRESHOLD)) {
        /* Job is async and the queue is full. Move to sync */
        SX_LOG_ERR(
            "sx_core_async_api_command_process job data count < [%d] move to synced. job_data_cnt [%u] tid [%" PRIX64 "]\n",
            MIN_ASYNC_JOB_DATA_CNT_THRESHOLD,
            job_data_cnt,
            tid);
        is_synced = TRUE;
    }

    if (is_synced != TRUE) {
        cmd_sx_status = sx_async_params_g.accepted_return_status;
        /* The job will be Async, respond to the API now */
        if (cl_is_commchnl_inited(&(event_p->commchnl))) {
            sx_api_send_reply_wrapper(&(event_p->commchnl), cmd_sx_status, NULL, 0);
        }
        command_replied_s = TRUE;
        /*  All API related information has been copied to Async context.
         *   E.g. uc_route_set_async_job_ctx_t for Async Router for this Async job
         *   or fdb_uc_mac_addr_set_async_job_ctx_t for FDB. We can safely free
         *   the Prio Buffer
         */
        sx_core_td_increase_consumer(buffer_type);
    }

    if (module_id == SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
        sx_core_async_lock_global_db();
        is_global_lock = TRUE;
    }

    /* assign tid */
    tid_params.context = NULL;
    tid_params.owner = module_id;
    tid_params.source = TID_SOURCE_API_EXTERNAL;

    sx_status = sx_tid_manager_transaction_id_get(&tid_params, &tid);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get tid for API call %u.\n", cmd_p->cmd_id);
        goto out;
    }
    if (tid_dbg_init_s == 0) {
        SX_MEM_CLR(tid_dbg_s);
        tid_dbg_init_s = 1;
    }
    if (tid_dbg_idx >= 100) {
        tid_dbg_idx = 0;
    }
    tid_dbg_s[tid_dbg_idx].module_id = module_id;
    tid_dbg_s[tid_dbg_idx].tid = tid;
    tid_dbg_s[tid_dbg_idx].cmd_id = cmd_p->cmd_id;
    tid_dbg_idx++;


#ifdef SX_CORE_ASYNC_DEBUG
    SX_LOG_ERR("sx_core_async_api_command_process push synced job with tid [%" PRIX64 "]\n", tid);
#endif


    job_data_p->cmd_body_size = cmd_body_size;
    job_data_p->tid = SX_TID_MANAGER_TID_GET(tid);
    job_data_p->tid_state = SX_TID_MANAGER_TRANSACTION_ID_STATE_PENDING;

    job_data_p->is_sync = is_synced;
    job_data_p->tid_end = TRUE;

    if (module_id == SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
        /* Make sure Default module is always synced */
        if (job_data_p->is_sync != TRUE) {
            sx_status = SX_STATUS_ERROR;
            /* Error default module job must be synced ! */
            SX_LOG_ERR("Error default module job must be synced\n");
            goto out;
        }
        /* save current tid */
        async_infra_data_p_g->default_module_tid = SX_TID_MANAGER_TID_GET(tid);
    }
    if (is_synced == TRUE) {
        job_data_p->cookie = event_p;
    }
    job_data_p->job_data_ctx = async_pre_send_output.job_data_ctx; /* This is uc_route_set_item for Async route for example*/
    job_data_p->sx_core_async_ctx = (void*)sx_core_async_job_data_poll_item_p;

    SX_MEM_CLR(job_info);
    /* sender is sx core async module */
    job_info.module_id = SX_WORK_QUEUEP_MODULE_SX_CORE_ASYNC_LAYER_E; /* module_id;*/
    job_info.job_type_id = job_type_id;
    job_info.job_data = (void*)(job_data_p);
    if (is_synced) {
        if (module_id == SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
            job_info.should_push_post_completion = TRUE;
        } /* for non default module push to post completion is done at sx_core_async_notify_job_completion function */
        job_info.should_call_post_completion_cb = TRUE;
    }
    job_info.job_handler_cb = module_entry_p->job_handler_cb;
    job_info.job_handler_cb_context = module_entry_p->job_handler_context;

    /* Push job to logic layer */
    work_queuep_rc = sx_work_queue_push_job(dest_queue_pair_p->queue_id, &job_info);
    sx_status = wqp_status_to_sx_status(work_queuep_rc);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to push job to queue %u.\n", dest_queue_pair_p->queue_id);
        goto out;
    }
    if (is_synced) {
        /* Wait on completion in case it's sync job */
        SX_MEM_CLR(completion_job_info);
        work_queuep_rc = sx_work_queuep_wait_on_queue(dest_queue_pair_p->completion_queue_id);
        sx_status = wqp_status_to_sx_status(work_queuep_rc);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at waiting on completion queue %u.\n",
                       dest_queue_pair_p->completion_queue_id);
            goto out;
        }

        if (module_id == SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
            sx_status = sx_reg_layer_default_tid_end_set(async_infra_data_p_g->default_module_tid);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("SX Core async Layer - error set transaction id end rc = [%d]-[%s]\n",
                           sx_status,
                           sx_status_str(sx_status));
                goto out;
            }

            sx_core_async_unlock_global_db();
            is_global_lock = FALSE;
        }

        cont_pop = TRUE;
        while (cont_pop) {
            work_queuep_rc = sx_work_queue_pop(dest_queue_pair_p->completion_queue_id,
                                               completion_job_info_p);
            if (work_queuep_rc == SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND) {
                cont_pop = FALSE;
                break;
            }
            sx_status = wqp_status_to_sx_status(work_queuep_rc);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("SX Core async Layer Error pop from completion queue %u .\n",
                           dest_queue_pair_p->completion_queue_id);
                goto out;
            }
            completion_job_data_p = (sx_core_async_job_data_t*)completion_job_info_p->job_data;
            completion_job_data_p->tid_state = SX_TID_MANAGER_TRANSACTION_ID_STATE_STATE_COMPLETED;


            cmd_sx_status = completion_job_data_p->cmd_sx_status;
            if (cmd_sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error got in completion data.\n");
            }

            if (module_id != SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
                /* only if async */
                if (completion_job_data_p->is_sync == FALSE) {
                    sx_status = sx_core_async_completion_trap_send(completion_job_info_p);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("SX Core async Layer Error at sx_core_async_completion_trap_send err [%s].\n",
                                   SX_STATUS_MSG(sx_status));
                        goto out;
                    }
                }

                sx_status = sx_core_async_default_module_tid_get();
                if (SX_CHECK_FAIL(sx_status)) {
                    SX_LOG(SX_LOG_ERROR,
                           "sx_core_async_api_command_process failed during SX SDK core async default module tid get failed err [%s].\n",
                           SX_STATUS_MSG(sx_status));
                    goto out;
                }
                default_tid_get = TRUE;

                /* Call completion CB Function. */
                if (completion_job_info_p->job_handler_cb != NULL) {
                    SX_MEM_CLR(job_cb_info);
                    job_cb_info.context = completion_job_info_p->job_handler_cb_context;
                    job_cb_info.job_data = completion_job_info_p->job_data;
                    job_cb_info.module_id = module_id;
                    job_cb_info.trigerred_queue_id_p = dest_queue_pair_p->completion_queue_id;
                    work_queuep_rc = completion_job_info_p->job_handler_cb(&job_cb_info);
                    sx_status = wqp_status_to_sx_status(work_queuep_rc);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("sx_core_async_api_command_process error calling completion queue job handler tid [%" PRIX64 "] err [%d]-[%s]!.\n"
                                   ,
                                   job_data_p->tid,
                                   sx_status,
                                   sx_status_str(
                                       sx_status));
                    }
                }

                sx_status = sx_core_async_default_module_tid_end_set();
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("sx_core_async_api_command_process - error set transaction id end rc = [%d]-[%s]\n",
                               sx_status,
                               sx_status_str(sx_status));
                    goto out;
                }
                default_tid_get = FALSE;

                if ((async_infra_data_p_g->default_module_tid == completion_job_data_p->tid) &&
                    (command_replied_s == FALSE)) {
                    SX_LOG_ERR(
                        "sx_core_async_api_command_process error async module didn't reply on completion in synced mode tid [%" PRIX64 "] module_id [%d] cmd_id [%d]\n",
                        tid,
                        module_id,
                        cmd_p->cmd_id);
                    err_cnt_async_module_in_synced_no_reply_s++;
                    CL_ASSERT(FALSE);
                }

                sx_core_async_completion_job_data_poll_item_p =
                    (sx_core_async_job_data_poll_item_t*)completion_job_data_p->sx_core_async_ctx;
                job_data_buffer_type = sx_core_async_completion_job_data_poll_item_p->buffer_type;

                /* Delete data item which is allocate at sx core async layer */
                sx_status = sx_core_async_delete_job_data_item(sx_core_async_completion_job_data_poll_item_p);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("sx_core_async_api_command_process error deleting job data item job tid [%" PRIX64 "] sx_status [%d]-[%s]!.\n"
                               ,
                               job_data_p->tid,
                               sx_status,
                               sx_status_str(
                                   sx_status));
                }

                /* Async job in sync mode is handled at this point, increase the consumer */
                sx_status = sx_core_td_increase_consumer(job_data_buffer_type);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to increase consumer for prio buff [idx=%u] n\n", job_data_buffer_type);
                }
            } else {
                /* for default module we can pop only once */
                cont_pop = FALSE;
            }
        }
    } else {
        /* Return ACCEPTED or SUCCESS in case it's async job according to user preference */
        cmd_sx_status = sx_async_params_g.accepted_return_status;
    }

    switch (cmd_p->cmd_id) {
    case SX_API_INT_CMD_ISSU_PAUSE_SET_E:
        break;

    case SX_API_INT_CMD_ISSU_RESUME_SET_E:
        list_item_p = cl_qlist_head(&g_core_async_db_s.api_cmd_cache);
        while (list_item_p != cl_qlist_end(&g_core_async_db_s.api_cmd_cache)) {
            cmd_data_p = PARENT_STRUCT(list_item_p, sx_core_async_api_cmd_data_t, list_item);
            if (cmd_data_p == NULL) {
                sx_status = SX_STATUS_ERROR;
                goto out;
            }
            sx_core_api_add_internal_job(cmd_data_p->api_cmd.cmd_id, cmd_data_p->cmd_body_p,
                                         cmd_data_p->cmd_body_size, cmd_data_p->buffer_type);
            list_item_p = cl_qlist_next(list_item_p);
            if (cmd_data_p->cmd_body_p) {
                CL_FREE_N_NULL(cmd_data_p->cmd_body_p);
            }
            CL_FREE_N_NULL(cmd_data_p);
        }
        cl_qlist_remove_all(&g_core_async_db_s.api_cmd_cache);
        g_core_sdk_paused = FALSE;
        break;

    default:
        break;
    }

out:

    if (pre_send_err) {
        /* Delete data item which is allocate at sx core async layer */
        if (sx_core_async_job_data_poll_item_p != NULL) {
            job_data_buffer_type = sx_core_async_job_data_poll_item_p->buffer_type;

            sx_status_rollback = sx_core_async_delete_job_data_item(sx_core_async_job_data_poll_item_p);
            if (sx_status_rollback != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "sx_core_async_api_command_process error during rollback - failed to delete job data item job sx_status [%d]-[%s]!.\n",
                    sx_status_rollback,
                    sx_status_str(
                        sx_status_rollback));
            }

            /* Async job failed, try to increase the consumer */
            sx_status_rollback = sx_core_td_increase_consumer(job_data_buffer_type);
            if (sx_status_rollback != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to increase consumer for prio buff [idx=%u] n\n", job_data_buffer_type);
            }
        }
    }

    if ((sx_status != SX_STATUS_ACCEPTED) && (sx_status != SX_STATUS_SUCCESS)) {
        /* error. rollback */
        if (is_global_lock) {
            sx_core_async_unlock_global_db();
        }
        if (TRUE == reg_bulk_stage_set) {
            sx_status = sx_reg_bulk_stage_reset();
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("sx_core_async_api_command_process - failed to reset Reg Bulk stage, rc = [%d]-[%s]\n",
                           sx_status, sx_status_str(sx_status));
            }
        }
        if (TRUE == default_tid_get) {
            sx_status_rollback = sx_core_async_default_module_tid_end_set();
            if (sx_status_rollback != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("sx_core_async_api_command_process - error set transaction id end rc = [%d]-[%s]\n",
                           sx_status_rollback,
                           sx_status_str(sx_status_rollback));
            }
        }
        /* Overwrite return status in case the error was due to async internal job not getting processed this turn*/
        if (pre_send_cb && (sx_status == SX_STATUS_RESOURCE_IN_USE)) {
            sx_status = SX_STATUS_SUCCESS;
        }
    }
    if (command_replied_s == FALSE) {
        /* Reply to API client in case it's not replied */
        if (cl_is_commchnl_inited(&(event_p->commchnl))) {
            sx_status = sx_api_send_reply_wrapper(&(event_p->commchnl), cmd_sx_status, NULL, 0);
        }
    }

    return sx_status;
}


sx_status_t sx_core_async_api_send_reply_wrapper(sx_core_async_job_data_t* job_data_p,
                                                 sx_status_t               retcode,
                                                 uint8_t                  *reply_body,
                                                 uint32_t                  reply_body_size)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    sx_core_td_event_src_t *event_p = (sx_core_td_event_src_t*)job_data_p->cookie;

    sx_status = sx_api_send_reply_wrapper(&(event_p->commchnl), retcode, reply_body, reply_body_size);
    command_replied_s = TRUE;

    return sx_status;
}

sx_status_t sx_core_async_pre_sxd_access_reg_action(void)
{
    return sx_core_async_default_module_tid_get();
}

sx_status_t sx_core_async_post_sxd_access_reg_action(void)
{
    return sx_core_async_default_module_tid_end_set();
}

sx_status_t sx_core_async_default_module_tid_get(void)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    sx_tid_manager_transaction_id_t        tid = 0;
    sx_tid_manager_transaction_id_params_t tid_params;

    SX_LOG_ENTER();

    /* assign tid */
    SX_MEM_CLR(tid_params);
    tid_params.context = NULL;
    tid_params.owner = SX_WORK_QUEUEP_MODULE_DEFAULT_E;
    tid_params.source = TID_SOURCE_INTERNAL;

    sx_status = sx_tid_manager_transaction_id_get(&tid_params, &tid);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("sx_core_async_default_module_tid_inc Failed to get tid .\n");
        goto out;
    }

    async_infra_data_p_g->default_module_tid = SX_TID_MANAGER_TID_GET(tid);

    SX_LOG_EXIT();
out:
    return sx_status;
}


sx_status_t sx_core_async_current_module_get(sx_work_queuep_module_e *module_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    *module_p = global_module_id_s;
    return sx_status;
}


sx_status_t sx_core_async_default_module_tid_end_set(void)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = sx_reg_layer_default_tid_end_set(async_infra_data_p_g->default_module_tid);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SX Core async Layer default module tid end set - error set transaction id end rc = [%d]-[%s]\n",
                   sx_status,
                   sx_status_str(sx_status));
        goto out;
    }

    SX_LOG_EXIT();
out:
    return sx_status;
}

sx_status_t sx_core_async_default_module_tid_peak(sx_tid_manager_transaction_id_t *default_module_tid_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *default_module_tid_p = SX_TID_MANAGER_TID_GET(async_infra_data_p_g->default_module_tid);


    SX_LOG_EXIT();
    return sx_status;
}

/* Set work queue fd to fd set of core async to handle api call and completion together */
sx_status_t sx_core_async_set_fds(int *work_queue_fd_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    cl_map_item_t                *map_item_p = NULL;
    sx_core_async_module_entry_t *module_entry_p = NULL;
    int                           fd = 0;
    int                           max_fd = -1;

    FD_ZERO(&core_async_fds.fds);
    FD_ZERO(&core_async_fds.fds_err);

    fd = work_queue_fd_p[0];
    FD_SET(fd, &core_async_fds.fds);
    FD_SET(fd, &core_async_fds.fds_err);

    if (max_fd < fd) {
        max_fd = fd;
    }

    /* Loop all modules to check if completion queue fd of them are set */
    map_item_p = cl_qmap_head(&(g_core_async_db_s.module_lookup));
    while (map_item_p != cl_qmap_end(&(g_core_async_db_s.module_lookup))) {
        module_entry_p = PARENT_STRUCT(map_item_p, sx_core_async_module_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        if (module_entry_p->module == SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
            /* Don't listen to default (legacy) modules completion as they are synced */
            continue;
        }
        /* if the module is handling internal cmd we don't care about it completion queue*/
        if (module_entry_p->is_internal_cmd == FALSE) {
            /* If this is a user API command we should send trap to user upon completion */
            fd = module_entry_p->dest_queue_pair.completion_queue_fd[0];
            FD_SET(fd, &core_async_fds.fds);
            FD_SET(fd, &core_async_fds.fds_err);
            if (max_fd < fd) {
                max_fd = fd;
            }
        }
    }
    core_async_fds.max_fd = max_fd;

    SX_LOG_EXIT();
    return err;
}


sx_status_t sx_core_async_completion_trap_send(sx_work_queuep_job_info_t *job_info_p)
{
    sx_status_t                          err = SX_STATUS_SUCCESS;
    uint32_t                             size = 0;
    sx_async_api_complete_notification_t event_info;

    SX_LOG_ENTER();

    /* Notify user of of completion event with information */
    SX_MEM_CLR(event_info);
    /* Currently host ifc send event is disabled on async completion. This is the reason for size = 0 to skip send event */
    size = 0; /*sizeof(sx_async_api_complete_notification_t); */
    switch (job_info_p->job_type_id) {
    case SX_API_INT_CMD_FDB_UC_MAC_ADDR_SET_E:
        event_info.type = SX_ASYNC_API_NOTIFY_TYPE_FDB_MAC_ADDR_SET_E;
        break;

    default:
        size = 0;
        break;
    }
    if (size > 0) {
        err = host_ifc_send_event(SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT,
                                  &event_info,
                                  size,
                                  SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("sx_core_async_handle_completion_fds Error at sending completion notify data.\n");
            goto out;
        }

        async_completion_trap_cnt_s++;
    }

out:
    SX_LOG_EXIT();
    return err;
}

void sx_core_async_issu_in_progress_enable(void)
{
    g_core_async_issu_in_progress = TRUE;
}

void sx_core_async_issu_in_progress_disable(void)
{
    g_core_async_issu_in_progress = FALSE;
}

boolean_t sx_core_async_issu_in_progress_get(void)
{
    return g_core_async_issu_in_progress;
}

sx_status_t __sx_core_async_api_call_completion(sx_work_queuep_job_info_t *completion_job_info_p,
                                                sx_work_queuep_module_id_t module_id,
                                                sx_work_queue_id_t         completion_queue_id,
                                                void                      *completion_ctx_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t      work_qp_status = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queuep_job_cb_info_t job_cb_info;

    SX_LOG_ENTER();

    err = sx_reg_bulk_stage_set(SX_REG_BULK_STAGE_ASYNC_COMPLETION_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__sx_core_async_api_call_completion - failed to set Reg Bulk stage, rc = [%d]-[%s]\n",
                   err, sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR(job_cb_info);

    job_cb_info.context = completion_job_info_p->job_handler_cb_context;
    job_cb_info.job_data = completion_job_info_p->job_data;
    job_cb_info.module_id = module_id;
    job_cb_info.trigerred_queue_id_p = completion_queue_id;
    job_cb_info.completion_context = completion_ctx_p;

    work_qp_status = completion_job_info_p->job_handler_cb(&job_cb_info);
    err = wqp_status_to_sx_status(work_qp_status);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__sx_core_async_api_call_completion error calling completion queue job handler, err [%d]-[%s]!.\n",
                   err, sx_status_str(err));
    }

    err = sx_reg_bulk_stage_reset();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__sx_core_async_api_call_completion - failed to reset Reg Bulk stage, rc = [%d]-[%s]\n",
                   err, sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_core_async_handle_completion(boolean_t read_fd_set)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t             work_qp_status = SX_WORK_QUEUEP_STATUS_SUCCESS;
    cl_map_item_t                      *map_item_p = NULL;
    sx_core_async_module_entry_t       *module_entry_p = NULL;
    sx_work_queuep_job_info_t           job_info;
    sx_work_queuep_job_info_t          *job_info_p = &job_info;
    int                                 fd = 0;
    sx_core_async_job_data_t           *job_data_p = NULL;
    sx_core_async_job_data_poll_item_t *sx_core_async_job_data_poll_item_p = NULL;
    boolean_t                           cont_pop = TRUE;

#ifdef TIME_DEBUG_ASYNC
    struct timespec tms_end = {0};
    uint64_t        time_diff = 0;
#endif

    if (g_core_async_initialized_s != TRUE) {
        SX_LOG_ERR("sx_core_async is not initialized.\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (g_core_sdk_paused == TRUE) {
        goto out;
    }

    /* Loop all modules to check if completion queue fd of them are set */
    map_item_p = cl_qmap_head(&(g_core_async_db_s.module_lookup));
    while (map_item_p != cl_qmap_end(&(g_core_async_db_s.module_lookup))) {
        module_entry_p = PARENT_STRUCT(map_item_p, sx_core_async_module_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);
        if (module_entry_p->is_internal_cmd == TRUE) {
            /* Internal SDK Command don't send trap to user */
            continue;
        }
        fd = module_entry_p->dest_queue_pair.completion_queue_fd[0];
        if ((read_fd_set == FALSE) || FD_ISSET(fd,
                                               &(core_async_fds.fds))) {
            /* Skip memory clear to improve performance */
            /*SX_MEM_CLR(*job_info_p);*/
            cont_pop = TRUE;
            while (cont_pop) {
                work_qp_status = sx_work_queue_pop(module_entry_p->dest_queue_pair.completion_queue_id,
                                                   job_info_p);
                if (work_qp_status == SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND) {
                    cont_pop = FALSE;
                    break;
                }
                err = wqp_status_to_sx_status(work_qp_status);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("sx_core_async_handle_completion_fds Error at pop completion queue %u err [%s].\n",
                               module_entry_p->dest_queue_pair.completion_queue_id, SX_STATUS_MSG(err));
                    goto out;
                }

                if (module_entry_p->module != SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
                    err = sx_core_async_completion_trap_send(job_info_p);
                    if (err != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR(
                            "sx_core_async_handle_completion_fds Error at sx_core_async_completion_trap_send err [%s].\n",
                            SX_STATUS_MSG(err));
                        goto out;
                    }

                    job_data_p = (sx_core_async_job_data_t*)job_info_p->job_data;
                    if (job_data_p == NULL) {
                        err = SX_STATUS_ERROR;
                        SX_LOG_ERR("sx_core_async_handle_completion_fds Error job_data_p is NULL\n");
                        goto out;
                    }

                    job_data_p->tid_state = SX_TID_MANAGER_TRANSACTION_ID_STATE_STATE_COMPLETED;

                    /* Call completion CB Function. */
                    if (job_info_p->job_handler_cb != NULL) {
                        err = __sx_core_async_api_call_completion(job_info_p,
                                                                  module_entry_p->module,
                                                                  module_entry_p->dest_queue_pair.completion_queue_id,
                                                                  NULL);
                        if (err != SX_STATUS_SUCCESS) {
                            SX_LOG_ERR(
                                "sx_core_async_handle_completion_fds error calling completion queue job handler tid [%" PRIX64 "] err [%d]-[%s]!.\n",
                                job_data_p->tid,
                                err,
                                sx_status_str(err));
                        }
                    }

                    sx_core_async_job_data_poll_item_p =
                        (sx_core_async_job_data_poll_item_t*)job_data_p->sx_core_async_ctx;

                    /* Delete data item which is allocate at sx core async layer */
                    err = sx_core_async_delete_job_data_item(sx_core_async_job_data_poll_item_p);
                    if (err != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("sx_core_async_handle_completion_fds error deleting job data item job tid [%" PRIX64 "] err [%d]-[%s]!.\n"
                                   ,
                                   job_data_p->tid,
                                   err,
                                   sx_status_str(
                                       err));
                    }

                    work_qp_status = sx_work_queue_peak(module_entry_p->dest_queue_pair.completion_queue_id,
                                                        job_info_p);
                    if (work_qp_status == SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND) {
                        cont_pop = FALSE;
                        break;
                    }
                    job_data_p = (sx_core_async_job_data_t*)job_info_p->job_data;
                    if (job_data_p == NULL) {
                        cont_pop = FALSE;
                        break;
                    }
                    if (job_data_p->is_sync == TRUE) {
                        cont_pop = FALSE;
                        break;
                    }
                }
            }
        } else if ((read_fd_set == TRUE) && FD_ISSET(fd,
                                                     &(core_async_fds.fds_err))) {
            SX_LOG(SX_LOG_ERROR, "sx_core_async_handle_completion_fds Receive error on fd %d: %s\n",
                   fd,
                   strerror(errno));
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

void sx_core_async_lock_global_db(void)
{
    cl_spinlock_acquire(&global_db_mutex_s);
}

void sx_core_async_unlock_global_db(void)
{
    cl_spinlock_release(&global_db_mutex_s);
}

sx_status_t sx_core_async_notify_job_completion(void                 *sx_core_async_ctx_p,
                                                sx_work_queuep_job_cb job_handler_cb,
                                                void                 *job_handler_cb_context)
{
    sx_status_t                         sx_status = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t             wq_err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_core_async_job_data_t           *job_data_p = NULL;
    sx_core_async_job_data_poll_item_t *sx_core_async_job_data_poll_item_p = NULL;
    sx_work_queue_id_t                  completion_queue_id;
    sx_work_queuep_module_e             module_id;
    sx_work_queuep_job_info_t           job_info;

    SX_LOG_ENTER();

    sx_core_async_job_data_poll_item_p = (sx_core_async_job_data_poll_item_t*)sx_core_async_ctx_p;
    if (sx_core_async_job_data_poll_item_p == NULL) {
        SX_LOG(SX_LOG_ERROR,
               "Error sx_core_async_notify_job_completion sx_core_async_job_data_poll_item_p is NULL!\n");
        CL_ASSERT(FALSE);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    job_data_p = &sx_core_async_job_data_poll_item_p->data;
    completion_queue_id = sx_core_async_job_data_poll_item_p->module_entry_p->dest_queue_pair.completion_queue_id;

    module_id = sx_core_async_job_data_poll_item_p->module_entry_p->module;

    SX_MEM_CLR(job_info);

    job_info.job_type_id = sx_core_async_job_data_poll_item_p->job_type_id;
    job_info.job_handler_cb = job_handler_cb; /*sx_core_async_job_data_poll_item_p->module_entry_p->job_handler_cb; */
    job_info.job_handler_cb_context = job_handler_cb_context; /*sx_core_async_job_data_poll_item_p->module_entry_p->job_handler_context;*/
    job_info.job_data = job_data_p;
    job_info.completion_notif_type = SX_WORK_QUEUEP_COMPLETION_TYPE_POST_E;
    job_info.module_id = module_id;

    wq_err = sx_work_queue_push_job(completion_queue_id, &job_info);
    if (wq_err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR,
               "sx_core_async_notify_job_completion Error Push completion job to completion queue module_id [%d] queue id [%d]\n",
               module_id,
               completion_queue_id);
    }

    if (job_data_p->is_sync == TRUE) {
        /* wake up completion queue */
        wq_err = sx_work_queuep_wake_up_queue(completion_queue_id);
        if (wq_err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "sx_core_async_notify_job_completion - error wake up completion queue of module %u failed, rc = %d\n",
                module_id,
                wq_err);
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sx_core_async_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t        work_queuep_rc = SX_WORK_QUEUEP_STATUS_SUCCESS;
    cl_map_item_t                 *map_item_p = NULL;
    cl_list_item_t                *list_item_p = NULL;
    sx_core_async_module_entry_t  *module_entry_p = NULL;
    sx_core_async_api_cmd_entry_t *api_entry_p = NULL;
    const char                    *cmd_name = NULL;
    const char                    *empty_space = "N/A";
    const char                    *unknown = "Unknown";
    const char                    *module_str = NULL;
    char                           module_name[100];
    char                           api_name[100];
    uint32_t                       tid;
    uint16_t                       job_type_id;
    char                           status[100];
    sx_work_queue_id_t             default_module_queue_id = 1;
    uint32_t                       queue_id = 0;
    uint32_t                       completion_queue_id = 0;
    int32_t                        queue_fd[2];
    int32_t                        completion_queue_fd[2];
    boolean_t                      is_syncd = FALSE;
    dbg_utils_table_columns_t      core_async_columns[] = {
        {"Module",      30, PARAM_STRING_E, module_name},
        {"API",         60, PARAM_STRING_E, api_name},
        {"Dest Queue Id",  12, PARAM_UINT32_E, &queue_id},
        {"Dest Queue Pipe Fd[0]",  12, PARAM_UINT32_E, &queue_fd[0]},
        {"Dest Queue Pipe Fd[1]",  12, PARAM_UINT32_E, &queue_fd[1]},
        {"Dest Completion Queue Id",  12, PARAM_UINT32_E, &completion_queue_id},
        {"Dest Completion Queue Pipe Fd[0]",  12, PARAM_UINT32_E, &completion_queue_fd[0]},
        {"Dest Completion Queue Pipe Fd[1]",  12, PARAM_UINT32_E, &completion_queue_fd[1]},

        {"Is Sync",     7,  PARAM_BOOL_E,   &is_syncd},
        {NULL,          0,  PARAM_LAST_E,   NULL}
    };
    sx_core_async_job_data_t      *logic_job_data_p = NULL;
    boolean_t                      should_push_pre = FALSE;
    boolean_t                      should_call_pre = FALSE;
    boolean_t                      should_push_post = FALSE;
    boolean_t                      should_call_post = FALSE;
    dbg_utils_table_columns_t      core_async_logic_queue_columns[] = {
        {"TID",      30, PARAM_UINT32_E, &tid},
        {"API",         60, PARAM_STRING_E, api_name},
        {"Module",  12, PARAM_STRING_E, &module_name},
        {"JobId",         60, PARAM_UINT16_E, &job_type_id},
        {"Tid Status",         60, PARAM_STRING_E, status},
        {"Is Sync",     7,  PARAM_BOOL_E,   &is_syncd},
        {"Push pre exec",     16,  PARAM_BOOL_E,   &should_push_pre},
        {"Call pre exec cb",     17,  PARAM_BOOL_E,   &should_call_pre},
        {"Push post exec",     16,  PARAM_BOOL_E,   &should_push_post},
        {"Call post exec cb",     17,  PARAM_BOOL_E,   &should_call_post},
        {NULL,          0,  PARAM_LAST_E,   NULL}
    };
    uint32_t                       job_info_cnt = 0;
    uint32_t                       i = 0;
    sx_work_queuep_job_info_t      job_info_list[2000];
    FILE                          *stream = NULL;
    char                           buf[256] = {0};

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    SX_MEM_CLR(queue_fd);
    SX_MEM_CLR(completion_queue_fd);

    if (g_core_async_initialized_s != TRUE) {
        SX_LOG_ERR("sx_core_async is not initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    dbg_utils_pprinter_module_header_print(stream, "Async Infrastructure");


    dbg_utils_pprinter_field_print(stream, "Async Enabled:",  &(sx_async_params_g.enabled), PARAM_BOOL_E);
    snprintf(buf, sizeof(buf) - 1, "%s", sx_status_str(sx_async_params_g.accepted_return_status));
    dbg_utils_pprinter_field_print(stream,
                                   "Async API Return Status On Accepted Request (although Not Done):",
                                   buf,
                                   PARAM_STRING_E);
    snprintf(buf, sizeof(buf) - 1, "%s",
             (sx_async_params_g.async_policy ==
              SX_API_ASYNC_MODE_HIGH_THRESHOLD_SWITCH_TO_SYNC) ? "Enabled" : "Disabled");
    dbg_utils_pprinter_field_print(stream, "Async Switch To Sync Policy:", buf, PARAM_STRING_E);

    dbg_utils_pprinter_general_header_print(stream, "Core Async Modules");
    dbg_utils_pprinter_table_headline_print(stream, core_async_columns);

    map_item_p = cl_qmap_head(&g_core_async_db_s.module_lookup);
    while (map_item_p != cl_qmap_end(&g_core_async_db_s.module_lookup)) {
        SX_MEM_CLR(module_name);
        SX_MEM_CLR(api_name);
        module_entry_p = PARENT_STRUCT(map_item_p, sx_core_async_module_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);
        module_str = WORK_QUEUEP_MODULE_MSG(module_entry_p->module);
        snprintf(module_name, sizeof(module_name), "%s", module_str);
        queue_id = module_entry_p->dest_queue_pair.queue_id;
        completion_queue_id = module_entry_p->dest_queue_pair.completion_queue_id;

        SX_MEM_CPY(queue_fd, module_entry_p->dest_queue_pair.queue_fd);
        SX_MEM_CPY(completion_queue_fd, module_entry_p->dest_queue_pair.completion_queue_fd);

        if (module_entry_p->module == SX_WORK_QUEUEP_MODULE_DEFAULT_E) {
            default_module_queue_id = queue_id;
        }
        is_syncd = module_entry_p->is_synced;
        if (cl_is_qlist_empty(&module_entry_p->api_cmd_list)) {
            snprintf(api_name, sizeof(api_name), "%s", empty_space);
            dbg_utils_pprinter_table_data_line_print(stream, core_async_columns);
            continue;
        }
        list_item_p = cl_qlist_head(&module_entry_p->api_cmd_list);
        while (list_item_p != cl_qlist_end(&module_entry_p->api_cmd_list)) {
            api_entry_p = PARENT_STRUCT(list_item_p, sx_core_async_api_cmd_entry_t, list_item);
            list_item_p = cl_qlist_next(list_item_p);
            sx_status = sx_core_get_api_command_name(api_entry_p->api_cmd_id, &cmd_name);
            if (sx_status != SX_STATUS_SUCCESS) {
                snprintf(api_name, sizeof(api_name), "%s", unknown);
                continue;
            }
            snprintf(api_name, sizeof(api_name), "%s", cmd_name);
            dbg_utils_pprinter_table_data_line_print(stream, core_async_columns);
        }
    }


    dbg_utils_pprinter_field_with_level_print(stream,
                                              "Async Completion Trap Sent:",
                                              &async_completion_trap_cnt_s,
                                              PARAM_UINT32_E,
                                              DBG_UTILS_LEVEL_HEADER_E);

    dbg_utils_pprinter_general_header_print(stream, "Default logic queue");
    dbg_utils_pprinter_table_headline_print(stream, core_async_logic_queue_columns);

    /* Iterate queue */
    work_queuep_rc = sx_work_queue_iter_get(SX_WORK_QUEUEP_CMD_GET,
                                            default_module_queue_id,
                                            0,
                                            NULL,
                                            &job_info_cnt);
    sx_status = wqp_status_to_sx_status(work_queuep_rc);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at debug dump of sc core async Failed to get count of default module queue\n");
        goto out;
    }

    SX_MEM_CLR(job_info_list);

    if (job_info_cnt > 2000) {
        job_info_cnt = 2000;
    }
    work_queuep_rc = sx_work_queue_iter_get(SX_WORK_QUEUEP_CMD_GET_FIRST,
                                            default_module_queue_id,
                                            0,
                                            job_info_list,
                                            &job_info_cnt);
    sx_status = wqp_status_to_sx_status(work_queuep_rc);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at debug dump of sc core async Failed to iterate items of default module queue\n");
        goto out;
    }

    for (i = 0; i < job_info_cnt; i++) {
        logic_job_data_p = (sx_core_async_job_data_t*)job_info_list[i].job_data;

        tid = SX_TID_MANAGER_TID_GET(logic_job_data_p->tid);
        snprintf(api_name, sizeof(api_name), "%s", logic_job_data_p->cmd.name);
        module_str = "Default";
        snprintf(module_name, sizeof(module_name), "%s", module_str);
        job_type_id = job_info_list[i].job_type_id;
        is_syncd = logic_job_data_p->is_sync;

        snprintf(status, sizeof(status), "%s", TID_MANAGER_TRANSACTION_ID_STATE_STR(logic_job_data_p->tid_state));

        /*job_info_list[i].completion_notif_type*/
        /*(job_info_list[i].job_handler_cb;*/
        /*job_info_list[i].job_handler_cb_context;*/
        should_push_post = job_info_list[i].should_push_post_completion;
        should_push_pre = job_info_list[i].should_push_pre_completion;
        should_call_pre = job_info_list[i].should_call_pre_completion_cb;
        should_call_post = job_info_list[i].should_call_post_completion_cb;

        dbg_utils_pprinter_table_data_line_print(stream, core_async_logic_queue_columns);
    }

    /* Print lasts job id */

    dbg_utils_pprinter_print(stream, "Error counters:");
    dbg_utils_pprinter_print(stream,
                             "Number of synced job that didn't send reply: %u\n",
                             err_cnt_async_module_in_synced_no_reply_s);

out:
    SX_LOG_EXIT();
    return sx_status;
}


void sx_core_async_debug_cmd_handler(void)
{
    sx_core_async_default_module_tid_get();
    sx_utils_debug_cmd_handle_command();
    sx_reg_layer_default_tid_end_set(async_infra_data_p_g->default_module_tid);
}


/* send synced job to logic layer thread */
sx_status_t sx_core_async_send_synced_job(sx_api_int_cmd_e                cmd_id,
                                          sx_tid_manager_transaction_id_t tid,
                                          sx_work_queuep_module_id_t      module_id,
                                          sx_work_queue_pair_info_t       queue_pair,
                                          sx_work_queuep_job_cb           job_handler_cb,
                                          void                           *job_data_ctx_p,
                                          void                           *completion_ctx_p)
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t            wq_err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queuep_job_info_t          job_info;
    sx_work_queue_id_t                 queue_id = 0;
    sx_core_async_job_data_t          *job_data_p = NULL;
    sx_core_async_job_data_poll_item_t sx_core_async_job_data_poll_item;
    sx_core_async_module_entry_t      *module_entry_p = NULL;

    SX_LOG_ENTER();

    SX_MEM_CLR(job_info);
    SX_MEM_CLR(job_data_p);
    SX_MEM_CLR(sx_core_async_job_data_poll_item);

    job_data_p = &sx_core_async_job_data_poll_item.data;
    job_data_p->cmd.cmd_id = cmd_id;

    job_data_p->tid = SX_TID_MANAGER_TID_GET(tid);
    job_data_p->tid_state = SX_TID_MANAGER_TRANSACTION_ID_STATE_PENDING;
    job_data_p->is_sync = TRUE;
    job_data_p->job_data_ctx = job_data_ctx_p;
    job_data_p->sx_core_async_ctx = (void*)&sx_core_async_job_data_poll_item;

    sx_status = __core_async_api_module_entry_get(cmd_id,
                                                  &module_entry_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("sx_core_async_send_synced_job - sx_core_async_api_module_entry_get failed, sx_status [%s]\n",
                   SX_STATUS_MSG(sx_status));
        goto out;
    }

    sx_core_async_job_data_poll_item.job_type_id = cmd_id;
    sx_core_async_job_data_poll_item.module_entry_p = module_entry_p;


    job_info.module_id = module_id;
    job_info.job_data = (void*)job_data_p;
    job_info.job_handler_cb = job_handler_cb;
    job_info.job_handler_cb_context = NULL;

    queue_id = queue_pair.queue_id;

    /* push synced job */
    wq_err = sx_work_queue_push_job(queue_id, &job_info);
    sx_status = wqp_status_to_sx_status(wq_err);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("sx_core_async_send_synced_job - sx_work_queue_push_job failed, rc [%d] sx_status [%s]\n",
                   wq_err,
                   SX_STATUS_MSG(sx_status));
        goto out;
    }

    /* Synced operation. Wait for completion queue */
    /* Wait on the completion queue and process the command (same as sx core async thread is doing */
    sx_status = sx_core_async_wait_on_completion(tid, &queue_pair, completion_ctx_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("sx_core_async_send_synced_job - Failed On wait on completion\n");
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


/* Wait on completion of logic layer. This function should work together with sx_core_async_send_synced_job which send synced job */
sx_status_t sx_core_async_wait_on_completion(sx_tid_manager_transaction_id_t tid,
                                             sx_work_queue_pair_info_t      *queue_pair_p,
                                             void                           *completion_ctx_p)
{
    sx_status_t                         sx_status = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t             work_queuep_rc = SX_WORK_QUEUEP_STATUS_SUCCESS;
    boolean_t                           cont_pop = TRUE;
    sx_work_queuep_job_info_t           completion_job_info;
    sx_core_async_job_data_t          * completion_job_data_p = NULL;
    sx_status_t                         cmd_sx_status = SX_STATUS_SUCCESS;
    sx_core_async_job_data_poll_item_t *sx_core_async_job_data_poll_item_p = NULL;


    SX_MEM_CLR(completion_job_info);

    /* Wait on completion in case it's sync job */
    work_queuep_rc = sx_work_queuep_wait_on_queue(queue_pair_p->completion_queue_id);
    sx_status = wqp_status_to_sx_status(work_queuep_rc);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at waiting on completion queue %u.\n",
                   queue_pair_p->completion_queue_id);
        goto out;
    }

    cont_pop = TRUE;
    while (cont_pop) {
        work_queuep_rc = sx_work_queue_pop(queue_pair_p->completion_queue_id,
                                           &completion_job_info);
        if (work_queuep_rc == SX_WORK_QUEUEP_STATUS_ENTRY_NOT_FOUND) {
            /* We have not yet handled the sync job for which this tid was pushed, wait until we get the completion*/
            SX_LOG_DBG("Continue polling completion queue [%u] for tid [%" PRIX64 "]\n",
                       queue_pair_p->completion_queue_id,
                       tid);
            cont_pop = TRUE;
            continue;
        } else {
            sx_status = wqp_status_to_sx_status(work_queuep_rc);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("SX Core async Layer Error pop from completion queue %u .\n",
                           queue_pair_p->completion_queue_id);
                goto out;
            }
        }
        completion_job_data_p = (sx_core_async_job_data_t*)completion_job_info.job_data;
        completion_job_data_p->tid_state = SX_TID_MANAGER_TRANSACTION_ID_STATE_STATE_COMPLETED;

        cmd_sx_status = completion_job_data_p->cmd_sx_status;
        if (cmd_sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("sx_core_async_wait_on_completion Error got in completion data.\n");
        }

        /* Call completion CB Function. */
        if (completion_job_info.job_handler_cb != NULL) {
            sx_status = __sx_core_async_api_call_completion(&completion_job_info,
                                                            completion_job_info.module_id,
                                                            queue_pair_p->completion_queue_id,
                                                            completion_ctx_p);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "sx_core_async_api_command_process error calling completion queue job handler tid [%" PRIX64 "] err [%d]-[%s]!.\n",
                    completion_job_data_p->tid,
                    sx_status,
                    sx_status_str(sx_status));
            }
            if (completion_job_data_p->is_sync) {
                if (completion_job_data_p->tid == tid) {
                    break;
                } else {
                    SX_LOG_WRN(
                        "Unexpected TID in completion queue [%u] expected tid [%" PRIX64 "] received  [%" PRIX64 "]\n",
                        queue_pair_p->completion_queue_id,
                        tid,
                        completion_job_data_p->tid);
                }
            } else {
                /* It can happen on occasion that an Async job will be captured here
                 * instead of the regular Async completion if there was a sync job
                 * that was pushed to the same queue id after it. Make sure we are
                 * handling that case
                 */
                sx_status = sx_core_async_completion_trap_send(&completion_job_info);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "sx_core_async_handle_completion_fds Error at sx_core_async_completion_trap_send err [%s].\n",
                        SX_STATUS_MSG(sx_status));
                    goto out;
                }
                sx_core_async_job_data_poll_item_p =
                    (sx_core_async_job_data_poll_item_t*)completion_job_data_p->sx_core_async_ctx;
                /* Delete data item which is allocate at sx core async layer */
                sx_status = sx_core_async_delete_job_data_item(sx_core_async_job_data_poll_item_p);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("sx_core_async_wait_on_completion error deleting job data item job tid [%" PRIX64 "] err [%d]-[%s]!.\n"
                               ,
                               completion_job_data_p->tid,
                               sx_status,
                               sx_status_str(
                                   sx_status));
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
