/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <getopt.h>
#include <signal.h>
#include <dlfcn.h>
#include <complib/cl_init.h>
#include <complib/cl_timer.h>
#include <complib/sx_log.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_fcntl.h>
#include <sx/utils/debug_cmd.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/sxd_emad_parser.h>
#include <unistd.h>
#include "sx_core_td.h"
#include "sx_core_api.h"
#include "sx_core_async.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "ethl2/la_db.h"
#include "config.h"
#include <systemd/sd-daemon.h>

/* cmd db lib */
#include "sx_core_cmd_db.h"
/* dynamic libraries */
#include <sx/sdk/sx_internal_dbg_if.h>

#include "ethl2/brg.h"
#include "ethl2/cos.h"
#include "ethl2/fdb.h"
#include "ethl2/fdb_uc_impl.h"
#include "ethl2/lag.h"
#include "ethl2/mstp.h"
#include "ethl2/port.h"
#include "ethl2/topo.h"
#include "ethl2/vlan.h"
#include "ethl3/sx/router.h"
#include "ethl3/router_common.h"
#include "acl/acl.h"
#include "flow_counter/flow_counter.h"
#include "host_ifc/host_ifc.h"
#include "fuse_dbg/fuse_dbg.h"
#include "policer_lib/policer_common.h"
#include "span/span.h"
#include "bridge_lib/bridge_common.h"
#include "sx/sxd/sxd_emad.h"
#include "sx/sxd/sxd_dpt.h"

#include "sx/sxd/sxdev.h"
#include "timer/timer.h"
#include "sx/utils/sdk_timer.h"
#include "sx_api_utils/sniffer/sniffer.h"
#include <complib/cl_dbg.h>


#undef  __MODULE__
#define __MODULE__ CORE


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_CORE_SIGNALS_NUM (sizeof(sx_core_signals) / sizeof(sx_core_signals[0]))
#define DUMMY_BUF_SIZE      1600

enum {
    SX_CORE_ARG_LOGGER               = 1000,
    SX_CORE_ARG_VERSION              = 1001,
    SX_CORE_ARG_CONNECTOR            = 1002,
    SX_CORE_ARG_HIDE_DEPRECATION_ERR = 1003,
    SX_CORE_ARG_INFO                 = 1004,
};


#define   RX_THREAD_TERMINATION_USLEEP_TIME             50000
#define   RCV_EVNT_HNDLR_THREAD_TERMINATION_USLEEP_TIME 50000
#define   SDK_READY_FILENAME                            "/tmp/sdk_ready"
#define   SDK_PID_PATH                                  "/var/run/sx_sdk.pid"

#define   DEFAULT_MODULE_QUEUE_SIZE 2
/************************************************
 *  Global variables
 ***********************************************/

sx_core_cli_settings_t   cli_settings;
sx_api_sx_sdk_versions_t sx_core_versions;
/* global variable because there is no API to control this variable */
sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
void            *logger_dll = NULL;
void            *sdk_connector_dll = NULL;
static FILE     *__g_sdk_log_file = NULL;
static boolean_t __g_use_syslog;


/************************************************
 *  Local variables
 ***********************************************/
static int sx_core_signals[] = {SIGINT, SIGTERM, SIGQUIT, SIGHUP, SIGABRT, SIGUSR1};

/* static boolean_t sx_core_exiting = FALSE;*/
static struct option sx_core_long_options[] = {
    {"logger",      required_argument,      NULL,   SX_CORE_ARG_LOGGER      },
    {"connector",   required_argument,      NULL,   SX_CORE_ARG_CONNECTOR   },
    {"logfile",     required_argument,      NULL,   'l'                     },
    {"syslog",      no_argument,            NULL,   's'                     },
    {"help",        no_argument,            NULL,   'h'             },
    {"verbose",     required_argument,      NULL,   'v'             },
    {"version",     no_argument,        NULL,   SX_CORE_ARG_VERSION     },
    {"info",        no_argument,        NULL,   SX_CORE_ARG_INFO },
    {"hide_deprecation_err",     no_argument,        NULL,   SX_CORE_ARG_HIDE_DEPRECATION_ERR     },
    {0,         0,              0,      0               }
};


typedef struct {
    /* queue and completion queue of sx core async infra */
    sx_work_queue_pair_info_t logic_queue_pair;
} async_sx_core_data_t;

/* async sx core global context */
static async_sx_core_data_t async_sx_core_g_ctx;
static async_infra_data_t   async_infra_data_g;

/************************************************
 *  Function declarations
 ***********************************************/
static void __sx_sdk_terminate(void);
static void __signal_handler(int signum);
static sx_status_t __catch_signals(void);
static sx_status_t __get_versions(sx_api_sx_sdk_versions_t *versions);
static inline void __show_help(void);
static inline void __show_error(void);
static sx_status_t __parse_args(int                     argc,
                                char                  **argv,
                                sx_core_cli_settings_t *cli_settings);
static sx_status_t __async_infra_init(void);
static sx_status_t __async_infra_deinit(void);

/* set the DPT access control to read only */
static sx_status_t __dpt_set_access_control_read_only(void);

/************************************************
 *  Function implementations
 ***********************************************/
static int __load_dbg_library(const char* dlib_path)
{
    void *lib_handle;

    int               (*vista_dbg_lib_init_fn)(sx_api_dbg_info_t *);
    char             *error;
    sx_api_dbg_info_t dbg_params;
    static int        dbg_lib_is_loaded = 0;

    if (0 != dbg_lib_is_loaded) {
        fprintf(stderr, "lib %s is still loaded\n", dlib_path);
        return 0;
    }

    lib_handle = dlopen(dlib_path, RTLD_LAZY);
    if (!lib_handle) {
        fprintf(stderr, "%s\n", dlerror());
        return -1;
    }

    vista_dbg_lib_init_fn = dlsym(lib_handle, VISTA_DBG_LIB_INIT);
    if ((error = dlerror()) != NULL) {
        dlclose(lib_handle);
        vista_dbg_lib_init_fn = NULL;
        fprintf(stderr, "%s\n", error);
        return -1;
    }

    /* prepare debug info */
    dbg_params.version = DBG_LIB_VERSION;
    (*vista_dbg_lib_init_fn)(&dbg_params);
    printf("dbg_params=0x%x\n", dbg_params.version);
    dbg_lib_is_loaded = 1;
    dlclose(lib_handle);
    return 0;
}

static void __sx_sdk_terminate()
{
    int          err;
    sx_swid_t    swid;
    int          threads_created = 0;
    cl_thread_t* obj = NULL;
    boolean_t    issu_start_flag = FALSE;

    SX_LOG(SX_LOG_NOTICE, "Starting sx_sdk termination...\n");

    cl_dbg_pool_db_disable();

    /* *********************************** */
    /* Gracefully try to end all threads   */
    /* *********************************** */

    /****************************************/
    /* signal __fdb_uc_polling_timer_thread */
    /****************************************/
    SX_LOG(SX_LOG_INFO, "sx_sdk_terminate - terminating polling timer threads...\n");
    for (swid = SX_SWID_ID_MIN; swid <= SX_SWID_ID_MAX; swid++) {
        obj = fdb_uc_impl_get_polling_timer_thread_object(swid);

        /* Per every thread that is alive */
        if ((obj != NULL) && (obj->osd.id != (pthread_t)NULL)) {
            SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - terminating polling timer thread, swid %u, tid %u...\n", swid,
                   (unsigned int)obj->osd.id);

            /* raise the termination flag */
            fdb_uc_impl_set_polling_timer_exit_signal_issued(swid, TRUE);

            /* thread will wake up as it is using usleep() broken to 100 millisecond periods */
            SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - waiting for thread %u to end...\n", (unsigned int)obj->osd.id);
            cl_thread_destroy(obj);
            SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - thread %u has ended. cl_thread_destroy\n\n",
                   (unsigned int)obj->osd.id);
        } else {
            SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - polling timer thread for swid %u is ended or not created.\n",
                   (unsigned int)swid);
        }
    } /* for swid */

    /**********************************************/
    /* signal router_async_completion_timer_thread */
    /***********************************************/

    obj = NULL;
    obj = sdk_router_cmn_async_get_completion_object();
    if ((obj != NULL) && (obj->osd.id != (pthread_t)NULL)) {
        sdk_router_cmn_completion_timer_exit_signal_issued();
        /* destroy the completion info processing thread if it was created */
        cl_thread_destroy(obj);
    }


    /****************************************/
    /* signal sx_timer_thread and SDK timer */
    /****************************************/
    SX_LOG(SX_LOG_INFO, "sx_sdk_terminate - terminating sx timer thread...\n");

    obj = sx_timer_get_thread_obj();

    /* Check that thread that is alive */
    if ((obj != NULL) && (obj->osd.id != (pthread_t)NULL)) {
        SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - terminating timer thread, tid %u...\n", (unsigned int)obj->osd.id);

        /* raise the termination flag */
        sx_timer_set_exit_signal_issued(TRUE);

        /* thread will wake up as it is using usleep() broken to 100 millisecond periods */
        SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - waiting for thread %u to end...\n", (unsigned int)obj->osd.id);
        cl_thread_destroy(obj);
        SX_LOG(SX_LOG_DEBUG,
               "sx_sdk_terminate - thread %u has ended. cl_thread_destroy\n\n",
               (unsigned int)obj->osd.id);
    } else {
        SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - sx timer thread is ended or not created.\n");
    }

    /* No need to signal SDK timer - it's enough to set the callback to NULL, and
     * it will stop adding jobs to the queue.
     */
    sdk_timer_register_cb(NULL);
#ifdef FUSE_DUMP
    /****************************************/
    /* signal sx_fuse_thread  */
    /****************************************/
    SX_LOG(SX_LOG_INFO, "sx_sdk_terminate - terminating sx fuse thread...\n");
    /* raise the termination flag */
    sx_fuse_exit();

#endif
    /************************************************/
    /* signal host ifc __event_timer_handler thread */
    /************************************************/

    SX_LOG(SX_LOG_INFO, "sx_sdk_terminate - terminating [host_ifc] __event_timer_handler thread.\n");
    err = host_ifc_timer_threads_end_event_created_get(&threads_created);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "timer_threads_end_event_created_get failed.\n");
    }

    if (threads_created != 0) {
        obj = host_ifc_get_event_timer_handler_thread_obj();
        if ((obj != NULL) && (obj->osd.id != (pthread_t)NULL)) {
            SX_LOG(SX_LOG_DEBUG,
                   "sx_sdk_terminate - terminating __event_timer_handler thread (tid %u)...\n",
                   (unsigned int)obj->osd.id);

            /* raise the termination flag */
            host_ifc_set_event_timer_handler_exit_signal_issue(TRUE);

            /* send a signal to wake __event_timer_handler */
            host_ifc_event_timer_handler_wakeup();

            SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - waiting for __event_timer_handler thread (tid %u) to end...\n",
                   (unsigned int)obj->osd.id);

            if (host_ifc_event_timer_handler_thread_init_was_called() == TRUE) {
                cl_thread_destroy(obj);
                SX_LOG(SX_LOG_DEBUG,
                       "sx_sdk_terminate - __event_timer_handler thread (tid %u) has ended. cl_thread_destroy\n\n",
                       (unsigned int)obj->osd.id);
            } else {
                SX_LOG(SX_LOG_DEBUG,
                       "sx_sdk_terminate - host ifc init was not called - skipping __event_timer_handler thread\n\n");
            }
        }

        /*********************************************************/
        /* signal host ifc __host_ifc_recv_events_handler thread */
        /*********************************************************/

        SX_LOG(SX_LOG_INFO, "sx_sdk_terminate - terminating __host_ifc_recv_events_handler thread.\n");

        obj = host_ifc_get_recv_events_handler_thread_obj();
        if ((obj != NULL) && (obj->osd.id != (pthread_t)NULL)) {
            SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - terminating __host_ifc_recv_events_handler thread (tid %u)...\n",
                   (unsigned int)obj->osd.id);
            /* raise the termination flag */
            host_ifc_set_recv_events_handler_exit_signal_issue(TRUE);
            /* send a signal to wake __host_ifc_recv_events_handler */
            host_ifc_recv_events_handler_wakeup();

            SX_LOG(SX_LOG_INFO,
                   "sx_sdk_terminate - waiting for __host_ifc_recv_events_handler thread (tid %u) to end...\n",
                   (unsigned int)obj->osd.id);

            cl_thread_destroy(obj);
            SX_LOG(SX_LOG_INFO,
                   "sx_sdk_terminate - __host_ifc_recv_events_handler thread (tid %u) has ended. cl_thread_destroy\n",
                   (unsigned int)obj->osd.id);
        }
    }

    /*********************************************************/
    /* signal GC __gc_post_queue_timer_thread to stop */
    /*********************************************************/
    SX_LOG(SX_LOG_INFO, "sx_sdk_terminate - terminating GC timer threads...\n");
    obj = gc_post_queue_timer_thread_obj();
    if ((obj != NULL) && (obj->osd.id != (pthread_t)NULL)) {
        SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - terminating __gc_post_queue_timer_thread thread (tid %u)...\n",
               (unsigned int)obj->osd.id);

        /* raise the termination flag */
        gc_post_queue_timer_thread_exit_signal_issued(TRUE);

        /* thread will wake up as it is using usleep() broken to 20 microsecond periods */
        SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - waiting for thread %u to end...\n", (unsigned int)obj->osd.id);
        cl_thread_destroy(obj);
        SX_LOG(SX_LOG_DEBUG, "sx_sdk_terminate - thread %u has ended. cl_thread_destroy\n\n",
               (unsigned int)obj->osd.id);
    }

    /**************************/
    /* Change DPT access control to  read Only    */
    /**************************/

    err = __dpt_set_access_control_read_only();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Set DPT Access control to read only failed.\n");
    }

    /**************************/
    /* Deinit Core Threads    */
    /**************************/
    SX_LOG(SX_LOG_INFO, "sx_sdk_terminate - terminating worker threads.\n");

    err = sx_core_td_deinit();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "SX SDK Worker Threads deinit failed.\n");
    }

    /**************************/
    /* Deinit Sniffer         */
    /**************************/
    err = sdk_sniffer_stop_if_needed();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to deinit the API sniffer.\n");
    }

    /**********************************/
    /* Deinit modules                 */
    /**********************************/

    SX_LOG(SX_LOG_INFO, "sx_sdk_terminate - deinit modules.\n");
    /* Increment TID */
    err = sx_core_async_default_module_tid_get();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "SX SDK core async default module tid get failed.\n");
    }

    sx_core_api_deinit();


    /**************************/
    /* Deinit Async Infra    */
    /**************************/

    SX_LOG(SX_LOG_INFO, "sx_sdk_terminate - deinit command DB.\n");
    sx_core_deinit_command_db();

    err = __async_infra_deinit();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed deinit async infra.\n");
    }

    dbg_utils_pprinter_deinit();

    /* only after the worker thread is dead, it is safe to deinitialize debug_cmd and close its fd */
    sx_utils_debug_cmd_deinit();

    err = utils_issue_start_flag_get(&issu_start_flag);
    if (err) {
        SX_LOG_ERR("Failed to get boot mode err = %s\n",
                   sx_status_str(err));
        err = SX_STATUS_ERROR;
        return;
    }

    if (!issu_start_flag) {
        complib_exit();
    }
}

static int __set_signal_handler(int sig, void (*handler_cb)(int))
{
    struct sigaction action;

    memset(&action, 0, sizeof(action));
    action.sa_handler = handler_cb;
    sigemptyset(&action.sa_mask);

    return sigaction(sig, &action, NULL);
}

static void __signal_handler(int signum)
{
    SX_LOG(SX_LOG_INFO, "Signal %u caught.\n", (unsigned int)signum);

    if (SIGHUP == signum) {
        SX_LOG_NTC("Got SIGHUP, ignoring\n");
        return;
    }

    if (SIGUSR1 == signum) {
        /* load debug lib */
        __load_dbg_library(SX_DBG_LIB_NAME);
        return;
    }

    if (SIGABRT == signum) {
        /* this hack is for verification: when they load SDK with --fatal_error_mode
         * (will make SDK process crash in the first error log message) and then run
         * a suite of tests, they don't want to stop if SDK crashes in the middle because
         * of an error message. If SDK crashes, they will run dvs_start.sh again and
         * continue the test suite from the next test in the suite.
         * There is a little problem if they load SDK again and the python process that holds
         * the test suite and the sx-lib instance is still alive: sx-lib holds a reference to the
         * LAG shared memory (/dev/shm/lag) and this shared memory is recreated when SDK
         * restarts. Therefore, the python process holds a reference to the old (and invalid)
         * memory. The solution is to invalidate this shared memory when SDK crashes. In this case,
         * when there is an access to the LAG shared memory in sx-lib and the shared memory is
         * marked at 'invalid', the library will reload the shared memory to a fresh copy that
         * the new SDK has just created.
         */
        sx_la_port_indices_db_invalidate();

        __set_signal_handler(SIGABRT, SIG_DFL); /* set handler of SIGABRT to the default (generate core dump) */
        abort(); /* will send SIGABRT again, this time it will generate the core dump */
        return;
    }

    sx_core_td_exit_loop();
}

static sx_status_t __catch_signals(void)
{
    unsigned int i = 0;
    int          ret = 0;
    sx_status_t  err = SX_STATUS_SUCCESS;

    for (i = 0; i < SX_CORE_SIGNALS_NUM; ++i) {
        ret = __set_signal_handler(sx_core_signals[i], __signal_handler);
        if (ret == -1) {
            SX_LOG(SX_LOG_ERROR, "Failed to set signal handler [sig=%d, error=%d]\n",
                   sx_core_signals[i], errno);
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

    ret = __set_signal_handler(SIGPIPE, SIG_IGN); /* ignore SIGPIPE */
    if (ret == -1) {
        SX_LOG(SX_LOG_ERROR, "Failed to ignore SIGPIPE [error=%d]\n", errno);
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __get_versions(sx_api_sx_sdk_versions_t *versions)
{
    strncpy(versions->sx_sdk, PACKAGE_VERSION, SX_API_VERSION_MAX_LEN - 1);
    versions->sx_sdk[SX_API_VERSION_MAX_LEN - 1] = '\0';
    strncpy(versions->sx_api, SX_API_VERSION, SX_API_VERSION_MAX_LEN - 1);
    versions->sx_api[SX_API_VERSION_MAX_LEN - 1] = '\0';
    strncpy(versions->sx_sxd, sxd_get_driver_version(), SX_API_VERSION_MAX_LEN - 1);
    versions->sx_sxd[SX_API_VERSION_MAX_LEN - 1] = '\0';
    strncpy(versions->sx_issu, ISSU_VER, SX_ISSU_VERSION_MAX_LEN - 1);
    versions->sx_issu[SX_ISSU_VERSION_MAX_LEN - 1] = '\0';
    return SX_STATUS_SUCCESS;
}

static inline void __show_help()
{
    printf("\tNVIDIA Switch SDK Process.\n"
           "\t=============================\n"
           "\tUsage: sx_sdk [options]\n\n"
           "\tOptions:\n"
           "\t(-v<level>|--verbose=<level>)       Set Verbosity (dependent) level (default = 3):\n"
           "\t                                    0 = None.\n"
           "\t                                    1 = Error messages only.\n"
           "\t                                    2 = Error & Warning messages.\n"
           "\t                                    3 = Error, Warning & Info messages.\n"
           "\t                                    4 = Error, Warning, Info & Verbose messages.\n"
           "\t                                    5 = Error, Warning, Info, Verbose & Debug messages.\n"
           "\t--version                           Report version & exit normally.\n"
           "\t(-l<filename>|--logfile=<filename>) Send log messages to filename\n"
           "\t(-s|--syslog)                       Send log messages to syslog, -l and -s are mutually exclusive\n"
           "\t(-h|--help)                         Show this help message & exit normally.\n");
    exit(0);
}

static inline void __show_error()
{
    fprintf(stderr, "Bad parameter(s). Use --help to get parameters summary\n");
    exit(1);
}

static void __sdk_info(void)
{
    printf("SX-SDK Version ............... : %s %s\n"
           "SX-API Version ............... : %s\n"
           "ISSU Version ................. : %s\n"
           "Toolchain .................... : %s\n"
           "Palladium (PLD) .............. : %s\n"
           "Debug Version ................ : %s\n"
           "Optimization ................. : %s\n"
           "Memtrack ..................... : %s\n"
           "Python API ................... : %s\n"
           "Python Interpreters .......... : %s\n"
           "Build Time ................... : %s\n"
           "Address Sanitizer Options .... : %s\n",
           SWITCHX_SDK_MODE_STRING, sx_core_versions.sx_sdk,
           sx_core_versions.sx_api,
           sx_core_versions.sx_issu,
#if defined(CMAKE_SOURCE_DIR)
           "CMake",
#else
           "Automake",
#endif
#if defined(PD_BU)
           "Yes",
#else
           "No",
#endif
#if defined(_DEBUG_)
           "Yes",
#else
           "No",
#endif
#if defined(__OPTIMIZE__)
           "Yes",
#else
           "No",
#endif
#if defined(MEMTRACK)
           "Yes",
#else
           "No",
#endif
#if defined(USE_PYTHON_SDK_API)
           USE_PYTHON_SDK_API,
#else
           "N/A",
#endif
#if defined(PYTHON_INTERPRETERS)
           PYTHON_INTERPRETERS,
#else
           "N/A",
#endif
#if defined(SDK_BUILD_TIME)
           SDK_BUILD_TIME,
#else
           "N/A",
#endif
#if defined(CMAKE_BUILD_TYPE)
           (strcmp(CMAKE_BUILD_TYPE, "asan") == 0) ? CMAKE_C_FLAGS_ASAN : "N/A"
#else
           "N/A"
#endif
           );

#if defined(SDK_BUILD_PRIVATE)
    #if defined(SDK_BUILD_HOSTNAME)
    printf("Build Host ................ : %s\n", SDK_BUILD_HOSTNAME);
    #endif
    #if defined(SDK_BUILD_USERNAME)
    printf("Build User ................ : %s\n", SDK_BUILD_USERNAME);
    #endif
    #if defined(CMAKE_SOURCE_DIR)
    printf("Build Directory............ : %s\n", CMAKE_SOURCE_DIR);
    #endif
    #if defined(SDK_BUILD_GIT_BRANCH)
    printf("Build GIT Branch .......... : %s\n", SDK_BUILD_GIT_BRANCH);
    #endif
    #if defined(SDK_BUILD_GIT_COMMIT)
    printf("Build GIT Commit .......... : %s", SDK_BUILD_GIT_COMMIT);
    #endif
    #if defined(SDK_BUILD_GIT_DIRTY)
    printf("-dirty\n");
    #else
    printf("\n");
    #endif
    #if defined(SDK_BUILD_GIT_LATEST_TAG)
    printf("Build GIT Latest Tag....... : %s\n", SDK_BUILD_GIT_LATEST_TAG);
    #endif
#endif /* SDK_BUILD_PRIVATE */
}

static sx_status_t __parse_args(int argc, char **argv, sx_core_cli_settings_t *cli_settings)
{
    sx_verbosity_level_t verbosity = SX_VERBOSITY_LEVEL_NOTICE;
    int                  ret, c, verbose_flag = 0;
    char                *errmsg = NULL;
    sx_status_t          err = SX_STATUS_SUCCESS;

    SX_MEM_CLR_P(cli_settings);

    /*set default verbosity*/
    cli_settings->verbosity_level = SX_VERBOSITY_LEVEL_NOTICE;

    while (1) {
        int option_index = 0;

        c = getopt_long(argc, argv, "hsv:l:", sx_core_long_options, &option_index);

        /* Detect the end of the options. */
        if (c == -1) {
            break;
        }

        switch (c) {
        case SX_CORE_ARG_LOGGER:
            if (__g_use_syslog || __g_sdk_log_file) {
                fprintf(stderr, "syslog or logfile already specified; "
                        "logger is ignored\n");
                break;
            }

            /* The check below is for safety. If user provided more than one logger
             * only the last will be valid
             */
            if (logger_dll != NULL) {
                dlclose(logger_dll);
                logger_dll = NULL;
            }
            logger_dll = dlopen(optarg, RTLD_LAZY);
            errmsg = dlerror();
            if (errmsg) {
                fprintf(stderr, "Could not load logger library: %s.\n", errmsg);
                exit(1);
            }
            *(void**)(&(cli_settings->log_cb)) = dlsym(logger_dll, "log_cb");
            errmsg = dlerror();
            if (errmsg) {
                dlclose(logger_dll);
                *(void**)(&(cli_settings->log_cb)) = NULL;
                fprintf(stderr, "Could not find symbol log_cb: %s.\n", errmsg);
                exit(1);
            }
            *(void**)(&(cli_settings->log_pause_cb)) = dlsym(logger_dll, "log_pause_cb");
            errmsg = dlerror();
            if (errmsg) {
                *(void**)(&(cli_settings->log_pause_cb)) = NULL;
            }
            *(void**)(&(cli_settings->log_resume_cb)) = dlsym(logger_dll, "log_resume_cb");
            errmsg = dlerror();
            if (errmsg) {
                *(void**)(&(cli_settings->log_resume_cb)) = NULL;
            }
            break;

        case SX_CORE_ARG_CONNECTOR:
            /* The check below is for safety. If user provided more than one connector
             * only the last will be valid
             */
            if (sdk_connector_dll != NULL) {
                dlclose(sdk_connector_dll);
                sdk_connector_dll = NULL;
            }
            sdk_connector_dll = dlopen(optarg, RTLD_LAZY);
            errmsg = dlerror();
            if (errmsg) {
                fprintf(stderr, "Could not load SDK connector library: %s.\n", errmsg);
                exit(1);
            }
            *(void**)(&(cli_settings->connector_cb)) = dlsym(
                sdk_connector_dll, "sdkd_init");
            errmsg = dlerror();
            if (errmsg) {
                dlclose(sdk_connector_dll);
                *(void**)(&(cli_settings->connector_cb)) = NULL;
                fprintf(stderr, "Could not find symbol sdkd_init: %s.\n", errmsg);
                exit(1);
            }
            *(void**)(&(cli_settings->connector_deinit_cb)) = dlsym(
                sdk_connector_dll, "sdkd_deinit");
            errmsg = dlerror();
            if (errmsg) {
                dlclose(sdk_connector_dll);
                *(void**)(&(cli_settings->connector_deinit_cb)) = NULL;
                fprintf(stderr, "Could not find symbol sdkd_deinit: %s.\n", errmsg);
                exit(1);
            }
            *(void**)(&(cli_settings->connector_pause_cb)) = dlsym(
                sdk_connector_dll, "sdkd_pause");
            errmsg = dlerror();
            if (errmsg) {
                *(void**)(&(cli_settings->connector_pause_cb)) = NULL;
            }
            *(void**)(&(cli_settings->connector_resume_cb)) = dlsym(
                sdk_connector_dll, "sdkd_resume");
            errmsg = dlerror();
            if (errmsg) {
                *(void**)(&(cli_settings->connector_resume_cb)) = NULL;
            }
            break;

        case SX_CORE_ARG_HIDE_DEPRECATION_ERR:
            sx_log_hide_deprecation_err_set();
            break;

        case SX_CORE_ARG_VERSION:
            printf("SX-SDK %s %s, SX-API %s, SXD %s, ISSU %s\n",
                   SWITCHX_SDK_MODE_STRING,
                   sx_core_versions.sx_sdk,
                   sx_core_versions.sx_api,
                   sx_core_versions.sx_sxd,
                   sx_core_versions.sx_issu);
            exit(0);

        case SX_CORE_ARG_INFO:
            __sdk_info();
            exit(0);

        case 'v':
            verbose_flag++;
            ret = sscanf(optarg, "%u", &verbosity);
            /**
             * MGMT allow a Range of verbosity level
             */
            if (ret != 1) {
                __show_error();
            }
            cli_settings->verbosity_level = verbosity;
            break;

        case 'l':
            if (__g_use_syslog || cli_settings->log_cb || __g_sdk_log_file) {
                fprintf(stderr, "syslog or logger already specified; "
                        "logfile is ignored\n");
                break;
            }

            __g_sdk_log_file = fopen(optarg, "w");
            break;

        case 's':
            if (__g_sdk_log_file || cli_settings->log_cb) {
                fprintf(stderr, "logfile or logger already specified; "
                        "syslog is ignored\n");
                break;
            }
            __g_use_syslog = TRUE;
            sx_log_g_use_syslog_set(__g_use_syslog);
            break;

        case 'h':
            __show_help();

        /* fall through */
        case '?':
        default:
            /* getopt_long already printed an error message. */
            __show_error();
        }
    }

    /* Print any remaining command line arguments (not options). */
    if (optind < argc) {
        fprintf(stderr, "Non-option ARGV-elements: ");
        while (optind < argc) {
            fprintf(stderr, "%s ", argv[optind++]);
        }
        fprintf(stderr, "\n");
        __show_error();
    }

    return err;
}

sx_status_t __dpt_set_access_control_read_only(void)
{
    sx_status_t   sx_status = SX_STATUS_SUCCESS;
    length_t      dev_info_arr_size = SX_DEV_ID_MAX;
    sx_dev_info_t dev_info_arr[SX_DEV_NUM_MAX];
    uint32_t      dev_idx = 0;
    sxd_status_t  sxd_status;

    /* dev id */
    sx_status = topo_device_tbl_bulk_get(SX_ACCESS_CMD_GET, &leaf_filter, dev_info_arr, &dev_info_arr_size);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Cannot retrieve devices list, err[%s]\n", sx_status_str(sx_status));
        goto lbl_exit;
    }

    for (dev_idx = 0; dev_idx < dev_info_arr_size; dev_idx++) {
        sxd_status = sxd_dpt_set_access_control(dev_info_arr[dev_idx].dev_id, READ_ONLY);
        if (SXD_CHECK_FAIL(sxd_status)) {
            printf("failed to set access control in user space DPT, "
                   "for device %d. error: %s\n",  dev_info_arr[dev_idx].dev_id,
                   SXD_STATUS_MSG(sxd_status));
            sx_status = sxd_status_to_sx_status(sxd_status);
            goto lbl_exit;
        }
    }


lbl_exit:

    return sx_status;
}

static sx_work_queuep_status_t __async_pre_completion_cb(const sx_work_queuep_completion_cb_params_t *params,
                                                         void                                        *context)
{
    sx_work_queuep_status_t status = SX_WORK_QUEUEP_STATUS_SUCCESS;

    UNUSED_PARAM(context);
    UNUSED_PARAM(params);

    /* pop queue */
    /* change state to pre execute */

    return status;
}

static sx_work_queuep_status_t __async_default_post_completion_cb(const sx_work_queuep_completion_cb_params_t *params,
                                                                  void                                        *context)
{
    sx_work_queuep_status_t status = SX_WORK_QUEUEP_STATUS_SUCCESS;
    async_sx_core_data_t  * async_sx_core_data_p = (async_sx_core_data_t*)context;

    UNUSED_PARAM(params);

    status = sx_work_queuep_wake_up_queue(async_sx_core_data_p->logic_queue_pair.completion_queue_id);
    if (status != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG_ERR("Error wake up sx core async completion queue %u.\n",
                   async_sx_core_data_p->logic_queue_pair.completion_queue_id);
    }

    /* peak queue */
    /* change state to complete execute */

    return status;
}

static sx_status_t __async_register_default_module(void)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t                work_queuep_rc = SX_WORK_QUEUEP_STATUS_SUCCESS;
    uint32_t                               queue_size = DEFAULT_MODULE_QUEUE_SIZE;
    sx_work_queue_pair_info_t              reg_queue_pair;
    sx_work_queue_pair_info_t              logic_queue_pair;
    sx_work_queuep_module_params_t         module_params;
    sx_core_async_module_register_params_t params;

    UNUSED_PARAM(reg_queue_pair);
    SX_MEM_CLR(async_sx_core_g_ctx);
    SX_MEM_CLR(module_params);
    SX_MEM_CLR(params);

    module_params.pre_completion_cb = __async_pre_completion_cb;
    module_params.post_completion_cb = __async_default_post_completion_cb;
    module_params.post_completion_cb_context = &async_sx_core_g_ctx;

    work_queuep_rc = sx_work_queuep_module_init(SX_WORK_QUEUEP_MODULE_SX_CORE_ASYNC_LAYER_E,
                                                "sxCoreAsync",
                                                &module_params);
    sx_status = wqp_status_to_sx_status(work_queuep_rc);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialized sx core async layer module.\n");
        goto out;
    }

    work_queuep_rc = sx_work_queuep_module_register(SX_WORK_QUEUEP_MODULE_SX_CORE_ASYNC_LAYER_E,
                                                    SX_WORK_QUEUE_TYPE_PRIVATE_WITH_THREAD_E,
                                                    queue_size,
                                                    &logic_queue_pair);
    sx_status = wqp_status_to_sx_status(work_queuep_rc);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register sx core async layer module.\n");
        goto out;
    }

    async_sx_core_g_ctx.logic_queue_pair = logic_queue_pair;

    params.dest_queue_pair_p = &logic_queue_pair;
    params.is_synced = TRUE;

    sx_status = sx_core_async_module_register(SX_ACCESS_CMD_SET, SX_WORK_QUEUEP_MODULE_DEFAULT_E, &params);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register default module to core async layer.\n");
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __async_unregister_default_module(void)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t                work_queuep_rc = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_core_async_module_register_params_t params;

    SX_MEM_CLR(params);
    params.is_synced = TRUE;

    sx_status = sx_core_async_module_register(SX_ACCESS_CMD_UNSET, SX_WORK_QUEUEP_MODULE_DEFAULT_E, &params);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to unregister default module from core async layer.\n");
        goto out;
    }

    work_queuep_rc = sx_work_queuep_unregister_module(SX_WORK_QUEUEP_MODULE_SX_CORE_ASYNC_LAYER_E);
    sx_status = wqp_status_to_sx_status(work_queuep_rc);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register default module.\n");
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __async_infra_init(void)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    uint32_t                max_thread_cnt = 10;
    sx_work_queuep_params_t work_queuep_params;
    void                   *g_ctx = NULL;
    sx_reg_bulk_params_t    reg_bulk_params;
    sx_core_async_params_t  core_async_params;

    SX_MEM_CLR(core_async_params);
    SX_MEM_CLR(reg_bulk_params);
    SX_MEM_CLR(async_infra_data_g);
    SX_MEM_CLR(work_queuep_params);

    async_infra_data_g.pre_sxd_access_reg_wrapper_cb = sx_core_async_pre_sxd_access_reg_action;
    async_infra_data_g.post_sxd_access_reg_wrapper_cb = sx_core_async_post_sxd_access_reg_action;
    g_ctx = (void*)&async_infra_data_g;

    reg_bulk_params.g_ctx = g_ctx;
    core_async_params.g_ctx = g_ctx;

    sx_status = wqp_status_to_sx_status(sx_work_queuep_init(max_thread_cnt, &work_queuep_params, g_ctx));
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init work queuep.\n");
        goto out;
    }

    sx_status = sx_reg_bulk_init(&reg_bulk_params);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init reg bulk layer.\n");
        goto out;
    }

    sx_status = sx_core_async_init(&core_async_params);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init core async layer.\n");
        goto out;
    }
    sx_status = __async_register_default_module();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init default module logic layer.\n");
        goto out;
    }
out:
    return sx_status;
}

static sx_status_t __async_infra_deinit(void)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    boolean_t   issu_start_flag = FALSE;

    sx_status = __async_unregister_default_module();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinit default module logic layer.\n");
        goto out;
    }
    sx_status = sx_core_async_deinit();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinit core async layer.\n");
        goto out;
    }

    sx_status = sx_reg_bulk_deinit();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinit reg bulk layer.\n");
        goto out;
    }

    sx_status = utils_issue_start_flag_get(&issu_start_flag);
    if (sx_status) {
        SX_LOG_ERR("Failed to get boot mode err = %s\n",
                   sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (!issu_start_flag) {
        sx_status = wqp_status_to_sx_status(sx_work_queuep_deinit());
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to deinit work queuep.\n");
            goto out;
        }
    }
out:
    return sx_status;
}

static sx_status_t __pid_file_create(void)
{
    FILE *fp = NULL;
    int   other_pid = 0;
    int   self_pid = getpid();
    char  other_procpath[512];
    char  other_exe[512];
    char  us_exe[512];

    memset(other_procpath, 0, sizeof(other_procpath));
    memset(other_exe, 0, sizeof(other_exe));
    memset(us_exe, 0, sizeof(us_exe));

    /*
     * Check to see if another SDK is running.
     */
    if ((fp = fopen(SDK_PID_PATH, "r")) != NULL) {
        if ((fscanf(fp, "%d\n", &other_pid) == 1) && (self_pid != other_pid)) {
            snprintf(other_procpath, sizeof(other_procpath) - 1, "/proc/%d/exe", other_pid);
            other_procpath[sizeof(other_procpath) - 1] = '\0';
            if ((readlink(other_procpath, other_exe, sizeof(other_exe) - 1) > 0) &&
                (readlink("/proc/self/exe", us_exe, sizeof(us_exe) - 1) > 0) &&
                (strcmp(us_exe, other_exe) == 0)) { /* Another SDK */
                fprintf(stderr, "%s (%d) is already running, aborting.\n", us_exe, other_pid);
                fclose(fp);
                return SX_STATUS_ERROR;
            }
        }
        fclose(fp);
    }

    /*
     * Create PID file for this instance
     */
    if ((fp = fopen(SDK_PID_PATH, "w")) == NULL) {
        fprintf(stderr, "Couldn't write pid file %s\n", SDK_PID_PATH);
    } else {
        fprintf(fp, "%d\n", self_pid);
        fclose(fp);
    }
    return SX_STATUS_SUCCESS;
}

static void __pid_file_destroy(boolean_t destroy)
{
    if (destroy) {
        unlink(SDK_PID_PATH);
    }
}

static void __sx_syslog_cb(sx_log_severity_t severity, const char *module_name, char *msg)
{
    sx_verbosity_level_t verbosity_level = 0;

    SEVERITY_LEVEL_TO_VERBOSITY_LEVEL(severity, verbosity_level);
    if ((verbosity_level == SX_VERBOSITY_LEVEL_NONE) ||
        (verbosity_level >= SX_VERBOSITY_LEVEL_ALL)) {
        return;
    }

    syslog((int)VERBOSITY_LEVEL_TO_SYSLOG_LEVEL(verbosity_level), "%s %s: %s",
           SX_VERBOSITY_LEVEL_STR(verbosity_level), module_name, msg);
}

static void __sx_syslog_init(void)
{
    if (__g_sdk_log_file || cli_settings.log_cb) {
        return;
    }

    if (__g_use_syslog) {
        openlog("sx_sdk", LOG_NDELAY | LOG_PID, LOG_DAEMON);
        cli_settings.log_cb = __sx_syslog_cb;
    }
}

static void __sx_syslog_deinit(void)
{
    if (__g_use_syslog) {
        closelog();
        cli_settings.log_cb = NULL;
    }
}

static sx_status_t __sdk_sniffer_legacy_enable()
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sx_dbg_api_logger_params_t params;

    SX_MEM_CLR(params);

    status = sdk_sniffer_legacy_param_get(&params);
    if (status != SX_STATUS_SUCCESS) {
        return status;
    }

    status = sdk_sniffer_params_set(SX_ACCESS_CMD_ENABLE, &params, TRUE);

    return status;
}


int sx_core_main(int argc, char **argv)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_st = SX_UTILS_STATUS_SUCCESS;
    FILE             *fd_p = NULL;
    char             *sdk_ready_file = NULL;
    boolean_t         pid_destroy_on_exit = TRUE;

    __get_versions(&sx_core_versions);
    __parse_args(argc, argv, &cli_settings);

    __sx_syslog_init();
    sx_log_init(TRUE, __g_sdk_log_file, cli_settings.log_cb);

    err = __pid_file_create();
    if (err != SX_STATUS_SUCCESS) {
        pid_destroy_on_exit = FALSE;
        goto out;
    }
    /*SET MODULES LOG VERBOSITY LEVEL */
    err = set_sdk_verbosity(cli_settings.verbosity_level);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_INFO, "Could not set all SDK modules verbosity level\n");
        goto out;
    }

    SX_LOG(SX_LOG_INFO, "SX-SDK %s, SX-API %s, SXD %s\n",
           sx_core_versions.sx_sdk, sx_core_versions.sx_api, sx_core_versions.sx_sxd);


    complib_init();

    utils_st = sx_utils_debug_cmd_init();
    if (utils_st != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Debug Dump init failed\n");
        goto out;
    }

    utils_st = dbg_utils_pprinter_init();
    if (utils_st != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Debug utils printer init failed\n");
        goto out;
    }

    /* Initialize signals handling */
    err = __catch_signals();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not register signal handler\n");
        goto out;
    }

    err = sx_core_init_command_db();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "SX SDK CMD DB initialization failed\n");
        complib_exit();
        goto out;
    }

    err = __async_infra_init();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed Init async infra.\n");
        goto out;
    }

    if (sdk_sniffer_legacy_enable_check()) {
        err = __sdk_sniffer_legacy_enable();
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to enable the API logger in a legacy mode.\n");
            goto out;
        }
        SX_LOG(SX_LOG_NOTICE, "the API logger was enabled in a legacy mode.\n");
    }

    err = sx_core_td_init();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "SX SDK Threads initialization failed\n");
        complib_exit();
        goto out;
    }

    /* call connector callback before main loop */
    if (cli_settings.connector_cb != NULL) {
        cli_settings.connector_cb();
    }

    sdk_ready_file = getenv("SDK_READY_FILE");
    if (sdk_ready_file == NULL) {
        sdk_ready_file = SDK_READY_FILENAME;
    }

    /* Create a file to indicate SDK is ready for configuration. */
    fd_p = cl_fopen(sdk_ready_file, "w");
    if (fd_p == NULL) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("cl_fopen failed (%s) - failed to open file (%s).\n",
                   strerror(errno), sdk_ready_file);
        goto out;
    }
    cl_fclose(fd_p);
    SX_LOG_NTC("%s file created\n", sdk_ready_file);

    sd_notify(0, "READY=1"); /*  Notify systemd that we are ready */


    sx_core_td_start_loop();

    /* termination flow */
    err = SX_STATUS_SUCCESS;

    if (cli_settings.connector_deinit_cb != NULL) {
        cli_settings.connector_deinit_cb();
    }

    __sx_sdk_terminate();

out:
    if (sdk_ready_file != NULL) {
        cl_remove(sdk_ready_file);
    }

    sx_log_close();
    /*This call removed sue to bug 1132950, mlnx os link a package that register to run on exit.
     *  enable it will cause a crash on exit*/
    /*
     *  if (sdk_connector_dll) {
     *   dlclose(sdk_connector_dll);
     *  }
     *
     *  if (logger_dll) {
     *   dlclose(logger_dll);
     *  }
     */

    __sx_syslog_deinit();

    sd_notify(0, "STOPPING=1"); /*  Notify systemd that we are stopping */
    __pid_file_destroy(pid_destroy_on_exit);

    return err;
}
