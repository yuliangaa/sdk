/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_CORE_ASYNC_H__
#define __SX_CORE_ASYNC_H__

#include <sx/sdk/sx_types.h>
#include "sx_core_cmd_db.h"
#include "sx_core_td.h"
#include <complib/sx_work_queuep.h>
#include "tid_manager/sx_tid_manager.h"
#include <sx/sdk/sx_dev.h>
#include <sx/sxd/sxd_access_register.h>

#ifdef TIME_DEBUG_ASYNC
#include <time.h>
#endif

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/
typedef struct sx_core_async_fd {
    fd_set fds;
    fd_set fds_err;
    int    max_fd;
} sx_core_async_fd_t;

/* g context for async_infra */
typedef struct {
    sx_tid_manager_transaction_id_t default_module_tid;
    /* Purpose of this cb to perform action prior to the sxd_access_reg_wrapper */
    sx_status_t (*pre_sxd_access_reg_wrapper_cb)(void);
    /* Purpose of this cb to perform action after the sxd_access_reg_wrapper */
    sx_status_t (*post_sxd_access_reg_wrapper_cb)(void);
} async_infra_data_t;

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct sx_core_async_params {
    uint32_t reserved1;
    void    *g_ctx;  /* global context */
} sx_core_async_params_t;

typedef struct sx_core_async_job_data {
    sx_api_command_t                      cmd;
    void                                 *cmd_body;
    uint32_t                              cmd_body_size;
    sx_status_t                           cmd_sx_status;     /* command sx_status */
    sx_tid_manager_transaction_id_t       tid;                  /*  transaction Id */
    sx_tid_manager_transaction_id_state_e tid_state;            /*  transaction Id state*/
    boolean_t                             tid_end;              /*  Indication that this is the last job in a transaction Id */
    boolean_t                             is_sync;              /*  Indication that this job should be synced */
    void                                 *cookie;
    void                                 *job_data_ctx;
    void                                 *sx_core_async_ctx;     /* sx core async context. For Internal usage */
#ifdef TIME_DEBUG_ASYNC
    struct timespec tms_start;
#endif
} sx_core_async_job_data_t;

typedef struct sx_core_async_api_data {
    sx_api_command_t *cmd_p;
    uint8_t          *cmd_body_p;
    uint32_t          cmd_body_size;
} sx_core_async_api_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
static __attribute__((__used__)) const char *work_queuep_module2str_arr[SX_WORK_QUEUEP_MODULE_MAX_E + 1] = {
    /*SX_WORK_QUEUEP_MODULE_DEFAULT_E = 0*/
    "Default",

    /*SX_WORK_QUEUEP_MODULE_VLAN_E = 1*/
    "VLAN",

    /*SX_WORK_QUEUEP_MODULE_VLAN_SUPRESSION_E = 2*/
    "VLAN SUPPRESSION",

    /*SX_WORK_QUEUEP_MODULE_FDB_POLL_E = 3*/
    "FDB POLL",

    /*SX_WORK_QUEUEP_MODULE_FDB_UPDATE_E = 4*/
    "FDB UPDATE",

    /*SX_WORK_QUEUEP_MODULE_FDB_MAC_ADDR_E = 4*/
    "FDB MAC ADDR",

    /*SX_WORK_QUEUEP_MODULE_ROUTER_E = 5*/
    "ROUTER",

    /*SX_WORK_QUEUEP_MODULE_ATCAM_E = 6*/
    "ATCAM",

    /*SX_WORK_QUEUEP_MODULE_ATCAM_ERP_E = 7*/
    "ATCAM ERP",

    /*SX_WORK_QUEUEP_MODULE_ATCAM_BF_E = 8*/
    "ATCAM BF",

    /*SX_WORK_QUEUEP_MODULE_ATCAM_PRUNE_E = 9*/
    "ATCAM PRUNE",

    /*SX_WORK_QUEUEP_MODULE_LINEAR_MANAGER_E = 10*/
    "LINEAR MANAGER",

    /*SX_WORK_QUEUEP_MODULE_GC_E = 11*/
    "GC",

    /*SX_WORK_QUEUEP_MODULE_SX_CORE_ASYNC_LAYER_E = 12*/
    "SX CORE ASYNC LAYER",

    /*SX_WORK_QUEUEP_MODULE_SX_REGISTER_BULK_LAYER_E = 13*/
    "SX REGISTER BULK LAYER",
};

#define WORK_QUEUEP_MODULE_CHECK_RANGE(MODULE)  \
    SX_CHECK_RANGE(SX_WORK_QUEUEP_MODULE_MIN_E, \
                   (int)MODULE,                 \
                   (SX_WORK_QUEUEP_MODULE_MAX_E))

#define WORK_QUEUEP_MODULE_MSG(MODULE)                                            \
    WORK_QUEUEP_MODULE_CHECK_RANGE(MODULE) ? work_queuep_module2str_arr[MODULE] : \
    "Unknown module"

typedef struct sx_core_async_pre_send_output {
    boolean_t synced;                  /* is synced operation or not */
    void     *job_data_ctx;                  /* job data context. pre send cb can prepare data that will be pass to job handler */
} sx_core_async_pre_send_output_t;

/*
 * Pre send function callback.
 *
 * @param[in] context - pre send context
 * @param[out] output_p - pre send output
 *             synced - is synced operation or not/
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */

typedef sx_status_t (*sx_core_async_pre_send_cb) (void                            *context,
                                                  sx_core_async_api_data_t        *api_data,
                                                  sx_core_async_pre_send_output_t *output_p);

typedef struct sx_core_async_module_register_params {
    sx_api_int_cmd_e          *api_cmd_id;          /* api commands array */
    uint32_t                   num_of_api_commands; /* num of api commands */
    sx_work_queue_pair_info_t *dest_queue_pair_p; /* Destination queue pair */
    sx_core_async_pre_send_cb  pre_send_cb;       /* pre send callback called from core async layer */
    void                      *pre_send_context;  /* pre send context */
    sx_work_queuep_job_cb      job_handler_cb;    /* job data is filled with sx_core_async_job_data_t */
    void                      *job_handler_context; /* job handler context */
    boolean_t                  is_synced;       /* is the registered apis are synced/asynced */
    boolean_t                  is_internal_cmd; /* is internal command */
} sx_core_async_module_register_params_t;

/**
 * Set the log verbosity level for this module
 * @param[in] level - A log level to set
 */
sx_status_t sx_core_async_log_verbosity_level_set(sx_verbosity_level_t level);


/*
 * This function initializes the sx core async layer.
 *
 * @param[in] params - sx core layer init parameters
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_STATUS_NO_MEMORY if no memory is available.
 * @return SX_STATUS_ALREADY_INITIALIZED if the module has already been
 *      initialized.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_init(const sx_core_async_params_t *params);

/*
 * This function deinitializes the sx core async layer
 * threads.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_MODULE_UNINITIALIZED if the module hasn't been
 * initialized.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_deinit(void);

/*
 * This function set sx core async layer parameters.
 *
 * @param[in] params - sx async parameters configure at sx_api_sx_sdk_init_t
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_STATUS_NO_MEMORY if no memory is available.
 * @return SX_STATUS_ALREADY_INITIALIZED if the module has already been
 *      initialized.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_params_set(const sx_async_params_t *params);

/*
 * This function gets sx core async layer parameters.
 *
 * @param[out] params - sx async parameters configured at sx_api_sx_sdk_init_t
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_STATUS_NO_MEMORY if no memory is available.
 * @return SX_STATUS_ALREADY_INITIALIZED if the module has already been
 *      initialized.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_params_get(sx_async_params_t *params);

/*
 * This function registers/unregister module api commands to the sx core async layer.
 *
 * @param[in] command - SX_ACCESS_CMD_SET/SX_ACCESS_CMD_UNSET
 * @param[in] module -  module to be registered
 * @param[in] params - registration parameters:
 *      api_commands_p -array of api commands
 *      num_of_api_commands - size of api_commands_p
 *      queue_id_p - destination queue id in logic layer to send the commands
 *      pre_send_cb - will be called before job is send to the destination queue
 *      context - pre send cb context
 *      is_synced -sync/async operation
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_STATUS_NO_MEMORY if no memory is available.
 * @return SX_STATUS_ALREADY_INITIALIZED if the module has already been
 *      initialized.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_module_register(const sx_access_cmd_t cmd, sx_work_queuep_module_e module,
                                          sx_core_async_module_register_params_t *params);

/*
 * This function notify sx core async for job completion
 * The function does the following:
 *          1. push job info to completion queue
 *          2. If job is synced Wake up completion queue
 *
 * The module should call this function in the following scenarios:
 *          1. If job is synced the function should be called at post completion of function
 *          2. If job is asynced the function should be called after reg bulk layer completion(HW is written)
 *
 * In Synced job the SDK will returned to the user.
 * In Async job the SDK may send trap to the user (if implemented)
 *
 * @param[in] sx_core_async_ctx_p - pointer to sx core async context
 * @param[in] job_handler_cb - completion job handler cb
 * @param[in] job_handler_cb_context - completion job handler context
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_NULL if an invalid NULL parameter is passed.
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_STATUS_NO_MEMORY if no memory is available.
 * @return SX_STATUS_ALREADY_INITIALIZED if the module has already been
 *      initialized.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_notify_job_completion(void                 *sx_core_async_ctx_p,
                                                sx_work_queuep_job_cb job_handler_cb,
                                                void                 *job_handler_cb_context);

/*
 * Handle completion fds.
 *
 * @param[in] read_fd_set - read from fd
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_handle_completion(boolean_t read_fd_set);

/*
 * Build fd array contain td worker thread and completion queue.
 * Add work queue fd to fd set of core async to handle api call and completion together
 *
 * @param[in] td_worker_p - API command
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_set_fds(int *work_queue_fd_p);

/*
 * Process API commands.
 *
 * @param[in] cmd_p - API command
 * @param[in] event_p - core td event
 * @param[in] cmd_body - API command body
 * @param[in] cmd_body_size - API command body size
 * @param[in] buffer_type - buffer_type where API command is from
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_api_command_process(sx_api_command_t         *cmd_p,
                                              sx_core_td_event_src_t   *event_p,
                                              uint8_t                  *cmd_body,
                                              uint32_t                  cmd_body_size,
                                              sx_core_prio_buffer_num_e buffer_type);


/*
 * Check if API Command is registered to async infra
 *
 * @param[in] cmd_id - Operation code of an SX-API command
 * @param[out] is_async_api_p - True if the API is register to async infra, otherwise FALSE
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_is_api_command_async(sx_api_int_cmd_e cmd_id,
                                         boolean_t       *is_async_api_p);

/*
 * Send API reply.
 * This function is a wrapper for sx_api_send_reply_wrapper function.
 * The "reply-head" structure is replaced with return code of
 *
 * @param[in] job_data_p - async job data
 * @param[in] retcode - client operation's return code.
 * @param[in] reply_body - reply body buffer.
 * @param[in] reply_body_size - reply body size
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_api_send_reply_wrapper(sx_core_async_job_data_t* job_data_p,
                                                 sx_status_t               retcode,
                                                 uint8_t                  *reply_body,
                                                 uint32_t                  reply_body_size);

/*
 * Action to be performed before accessing SXD layer
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_pre_sxd_access_reg_action(void);

/*
 * Action to be performed after accessing SXD layer
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_post_sxd_access_reg_action(void);

/*
 * Get default module new tid
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_default_module_tid_get(void);

/*
 * Set default module tid end
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_default_module_tid_end_set(void);

/*
 * Get current module in the SX Core.
 * *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_current_module_get(sx_work_queuep_module_e *module_p);


/*
 * Peak the current default module new tid
 *
 * @param[out] default_module_tid_p - Current default module tid
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_default_module_tid_peak(sx_tid_manager_transaction_id_t *default_module_tid_p);


/*
 * Send synced job to logic layer thread
 *
 * @param[in] cmd_id - API Command ID to send
 * @param[in] cmd_body - API Command body
 * @param[in] tid - Transaction ID
 * @param[in] module_id - Module ID
 * @param[in] queue_pair - queue pair to send the command to
 * @param[in] job_handler_cb - Job handler to be executed on the thread
 * @param[in] job_data_ctx_p - Job data context pass to the job handler cb
 * @param[in] completion_ctx_p - Job completion context pass to the job handler cb
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_send_synced_job(sx_api_int_cmd_e                cmd_id,
                                          sx_tid_manager_transaction_id_t tid,
                                          sx_work_queuep_module_id_t      module_id,
                                          sx_work_queue_pair_info_t       queue_pair,
                                          sx_work_queuep_job_cb           job_handler_cb,
                                          void                           *job_data_ctx_p,
                                          void                           *completion_ctx_p);

/*
 * Wait on completion of logic layer.
 * This function should work together with sx_core_async_send_synced_job which send synced job
 *
 * @param[in] tid - tid to wait on
 * @param[in] queue_pair_p - queue pair to wait on
 * @param[in] completion_ctx_p - completion context
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_wait_on_completion(sx_tid_manager_transaction_id_t tid,
                                             sx_work_queue_pair_info_t      *queue_pair_p,
                                             void                           *completion_ctx_p);


/*
 * Lock global db.
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
void sx_core_async_lock_global_db(void);

/*
 * Unlock global db.
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
void sx_core_async_unlock_global_db(void);

/*
 * Delete sx core async job data item and return it to the pool
 *
 * @param[in] sx_core_async_job_ctx - sx core async job context
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_core_async_delete_job_data_item(void *sx_core_async_job_ctx);

/* Debug Dump */
sx_status_t sx_core_async_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

/* Enable ISSU in progress flag */
void sx_core_async_issu_in_progress_enable(void);

/* Disable ISSU in progress flag */
void sx_core_async_issu_in_progress_disable(void);

/* Get ISSU in progress flag */
boolean_t sx_core_async_issu_in_progress_get(void);

#endif /* __SX_CORE_ASYNC_H__ */
