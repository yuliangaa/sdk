/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include "ethl2/port_db.h"
#include "utils/port_type_validate.h"
#include "resource_manager/resource_manager_sdk_table.h"
#include "flex_modifier_db.h"
#include "flex_modifier.h"
#include "hwd_flex_modifier.h"


#undef __MODULE__
#define __MODULE__ FLEX_MODIFIER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local definitions
 ***********************************************/
#define PORT_MODIFIER_PAYLOAD_OFFSET_MOV_GRAN_SHIFT 1
#define PORT_MODIFIER_PAYLOAD_OFFSET_MOV_MAX_SHIFT  9
#define PORT_MODIFIER_PAYLOAD_OFFSET_MOV_MAX_BYTES  (1 << PORT_MODIFIER_PAYLOAD_OFFSET_MOV_MAX_SHIFT)
#define PORT_MODIFIER_PAYLOAD_OFFSET_MOV_GRAN_BYTES (1 << PORT_MODIFIER_PAYLOAD_OFFSET_MOV_GRAN_SHIFT)
#define PORT_MODIFIER_PAYLOAD_CHECK_GRAN(x) ((x & 0x1) != 0)

#define FLEX_MODIFIER_DEFAULT_RAM_SECONDARY_OFFSET 8

#define MAX_DYNAMIC_LEN_SHIFT (7)     /* The maximum value of the shift to apply to the header length field */
#define MIN_DYNAMIC_LEN_SHIFT (-7)    /* The minimum value of the shift to apply to the header length field */
#define MAX_DYNAMIC_LEN_CONST (126)   /* The maximum value of the add to apply to the header length field */
#define MIN_DYNAMIC_LEN_CONST (0)     /* The minimum value of the add to apply to the header length field */

/************************************************
 *  Local function declarations
 ***********************************************/

typedef sx_status_t (*is_emt_cmd_valid_t)(const sx_flex_modifier_emt_id_e   emt_id,
                                          const sx_flex_modifier_emt_cfg_t *emt_cfg_p);

typedef uint16_t (*emt_to_ram_map_t)(const sx_flex_modifier_emt_id_e emt_id);

static sx_status_t __flex_modifier_device_ready_callback(adviser_event_e event_type, void *param_p);

static sx_status_t __is_emt_cmd_valid(const sx_flex_modifier_emt_id_e   emt_id,
                                      const sx_flex_modifier_emt_cfg_t *emt_cfg_p);

static sx_status_t __is_emt_cmd_valid_spc4(const sx_flex_modifier_emt_id_e   emt_id,
                                           const sx_flex_modifier_emt_cfg_t *emt_cfg_p);

static uint16_t __emt_to_ram_map(const sx_flex_modifier_emt_id_e emt_id);

static uint16_t __emt_to_ram_map_spc4(const sx_flex_modifier_emt_id_e emt_id);

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

static boolean_t __flex_modifier_init_done_s = FALSE;

static ram_offset_t __secondary_ram_offset = 0;

static is_emt_cmd_valid_t __is_emt_cmd_valid_cb = NULL;

static emt_to_ram_map_t __emt_to_ram_map_cb = NULL;

static boolean_t __secondary_ram_in_use = FALSE;

/************************************************
 *  Function implementations
 ***********************************************/

const char* get_emt_id_name(char *name_buf, size_t name_size, void *emt_id)
{
    snprintf(name_buf, name_size, "%s", sx_flex_modifier_emt_id_str(*(sx_flex_modifier_emt_id_e*)emt_id));
    return name_buf;
}

sx_status_t flex_modifier_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    flex_modifier_db_log_verbosity_level_set(verbosity_level);
    hwd_flex_modifier_log_verbosity_level_set(verbosity_level);

    SX_LOG_EXIT();

    return rc;
}


sx_status_t flex_modifier_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    SX_LOG_EXIT();

    return rc;
}

static sx_status_t __flex_modifier_init_common()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == TRUE) {
        rc = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Flex modifier init Failure. %s\n", sx_status_str(rc));
        goto out;
    }

    rc = flex_modifier_db_init();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to initialize flex modifier DB, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FLEX_MODIFIER_EMT_E].is_initialized = TRUE;
    rc = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_FLEX_MODIFIER_EMT_E);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init RM for %s\n", SX_RESOURCE_MSG(RM_SDK_TABLE_TYPE_FLEX_MODIFIER_EMT_E));
        goto out;
    }

    rc = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                __flex_modifier_device_ready_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in adviser register event for flex modifier, error: %s \n", sx_status_str(rc));
        goto out;
    }

    __flex_modifier_init_done_s = TRUE;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_init()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = __flex_modifier_init_common();
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }
    __is_emt_cmd_valid_cb = __is_emt_cmd_valid;
    __emt_to_ram_map_cb = __emt_to_ram_map;
    __flex_modifier_init_done_s = TRUE;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_init_spc4()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_modifier_secondary_ram_offset_set_internal(FLEX_MODIFIER_DEFAULT_RAM_SECONDARY_OFFSET);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex modifier init: failed to set default RAM secondary offset\n");
        goto out;
    }

    rc = __flex_modifier_init_common();
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }
    __is_emt_cmd_valid_cb = __is_emt_cmd_valid_spc4;
    __emt_to_ram_map_cb = __emt_to_ram_map_spc4;
    __flex_modifier_init_done_s = TRUE;
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_modifier_deinit(boolean_t is_forced)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier deinit Failure. %s\n", sx_status_str(rc));
        goto out;
    }

    rc = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                                __flex_modifier_device_ready_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in adviser delete event for flex modifier, error: %s \n", sx_status_str(rc));
        goto out;
    }

    rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_FLEX_MODIFIER_EMT_E, is_forced);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to de-init RM for %s\n", SX_RESOURCE_MSG(RM_SDK_TABLE_TYPE_FLEX_MODIFIER_EMT_E));
        goto out;
    }

    rc = flex_modifier_db_deinit(is_forced);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to de-init flex modifier DB, error: [%s]\n", sx_status_str(rc));
        goto out;
    }
    __secondary_ram_in_use = FALSE;
    __flex_modifier_init_done_s = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __is_emt_cmd_valid(const sx_flex_modifier_emt_id_e   emt_id,
                                      const sx_flex_modifier_emt_cfg_t *emt_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;


    if (emt_cfg_p->emt_data_length_type != SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_FIXED_E) {
        rc = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Flex modifier EMT [%u] length type [%s] for is not supported on this chip\n",
                   emt_id,
                   sx_flex_modifier_emt_data_length_type_str(emt_cfg_p->emt_data_length_type));
        goto out;
    }

    if (emt_cfg_p->emt_data_cnt > FLEX_MODIFIER_MAX_EMT_CFG) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Flex modifier EMT [%u] data count [%u] exceeds limit [%u]\n",
                   emt_id, emt_cfg_p->emt_data_cnt, FLEX_MODIFIER_MAX_EMT_CFG);
        goto out;
    }

    /* Go over all the fields and make sure they are legal - some commands are not supported only for Spectrum 4*/
    for (i = 0; i < emt_cfg_p->emt_data_cnt; i++) {
        if ((emt_cfg_p->emt_data_list[i].cmd_id >= SX_FLEX_MODIFIER_EMT_COMMAND_LAST_E) ||
            ((emt_cfg_p->emt_data_list[i].cmd_id >= SX_FLEX_MODIFIER_EMT_COMMAND_RAM0_WORD_0_E) &&
             (emt_cfg_p->emt_data_list[i].cmd_id <= SX_FLEX_MODIFIER_EMT_COMMAND_RAM1_WORD_3_E))) {
            rc = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Flex modifier EMT [%u] command [%s] index [%u] is not supported\n",
                       emt_id,
                       sx_flex_modifier_emt_command_str(emt_cfg_p->emt_data_list[i].cmd_id),
                       i);
            goto out;
        }
        if (emt_cfg_p->emt_data_list[i].immediate_is_mask != FALSE) {
            rc = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Flex modifier EMT [%u] immediate mask is not supported\n", emt_id);
            goto out;
        }
    }

    for (i = 0; i < emt_cfg_p->emt_update_cnt; i++) {
        if ((emt_cfg_p->emt_update_list[i] >= SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_LAST_E) ||
            (emt_cfg_p->emt_update_list[i] == SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_IPV4_IHL_E) ||
            (emt_cfg_p->emt_update_list[i] == SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_IPV4_CHECKSUM_E)) {
            rc = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Flex modifier EMT [%u] update [%u] index [%u] is not supported\n",
                       emt_id, emt_cfg_p->emt_update_list[i], i);
            goto out;
        }
    }

out:
    return rc;
}

static sx_status_t __is_emt_cmd_valid_spc4(const sx_flex_modifier_emt_id_e   emt_id,
                                           const sx_flex_modifier_emt_cfg_t *emt_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    boolean_t   gp_allocated = FALSE;

    if (emt_cfg_p->emt_data_length_type == SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_FIXED_E) {
        if (emt_cfg_p->emt_data_cnt > FLEX_MODIFIER_MAX_EMT_CFG) {
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Flex modifier EMT [%u] data count [%u] exceeds limit [%u]\n",
                       emt_id, emt_cfg_p->emt_data_cnt, FLEX_MODIFIER_MAX_EMT_CFG);
            goto out;
        }
        /* Go over all the fields and make sure they are legal */
        for (i = 0; i < emt_cfg_p->emt_data_cnt; i++) {
            if (emt_cfg_p->emt_data_list[i].cmd_id >= SX_FLEX_MODIFIER_EMT_COMMAND_LAST_E) {
                rc = SX_STATUS_UNSUPPORTED;
                SX_LOG_ERR("Flex modifier EMT [%u] command [%s] index [%u] is not supported\n",
                           emt_id,
                           sx_flex_modifier_emt_command_str(emt_cfg_p->emt_data_list[i].cmd_id),
                           i);
                goto out;
            }
            if ((emt_cfg_p->emt_data_list[i].cmd_id == SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E) &&
                (emt_cfg_p->emt_data_list[i].immediate_is_mask != FALSE)) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR(
                    "Flex modifier EMT [%u] index [%u] immediate command and immediate mask cannot be used together\n",
                    emt_id,
                    i);
                goto out;
            }
        }
    } else { /* Dynamic length */
        /* Check the register is valid */
        rc = sdk_register_impl_is_allocated(emt_cfg_p->emt_data_dynamic_length.gp_register, &gp_allocated);
        if (SX_CHECK_FAIL(rc) || (gp_allocated == FALSE) ||
            (emt_cfg_p->emt_data_dynamic_length.gp_register.key.gp_reg.reg_id >=
             rm_resource_global.gp_register_num_max)) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Flex modifier EMT [%u] gp register [%u] is not configured\n", emt_id,
                       emt_cfg_p->emt_data_dynamic_length.gp_register.key.gp_reg.reg_id);
            goto out;
        }
        if (emt_cfg_p->emt_data_dynamic_length.gp_register_byte > 1) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Flex modifier EMT [%u] gp register [%u] byte should be 0 or 1\n", emt_id,
                       emt_cfg_p->emt_data_dynamic_length.gp_register.key.gp_reg.reg_id);
            goto out;
        }
        if (!SX_CHECK_RANGE(MIN_DYNAMIC_LEN_SHIFT, emt_cfg_p->emt_data_dynamic_length.shift, MAX_DYNAMIC_LEN_SHIFT)) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Flex modifier EMT [%u] gp register [%u] shift [%d] should be between [%d]-[%d]\n", emt_id,
                       emt_cfg_p->emt_data_dynamic_length.gp_register.key.gp_reg.reg_id,
                       emt_cfg_p->emt_data_dynamic_length.shift,
                       MIN_DYNAMIC_LEN_SHIFT, MAX_DYNAMIC_LEN_SHIFT);
            goto out;
        }
        if (!SX_CHECK_RANGE(MIN_DYNAMIC_LEN_CONST, emt_cfg_p->emt_data_dynamic_length.constant,
                            MAX_DYNAMIC_LEN_CONST) ||
            ((emt_cfg_p->emt_data_dynamic_length.constant & 0x1) == 0x1)) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Flex modifier EMT [%u] gp register [%u] constant [%u] should be between [%u]-[%u] and even.\n",
                       emt_id,
                       emt_cfg_p->emt_data_dynamic_length.gp_register.key.gp_reg.reg_id,
                       emt_cfg_p->emt_data_dynamic_length.constant,
                       MIN_DYNAMIC_LEN_CONST,
                       MAX_DYNAMIC_LEN_CONST);
            goto out;
        }
    }

    for (i = 0; i < emt_cfg_p->emt_update_cnt; i++) {
        if (emt_cfg_p->emt_update_list[i] >= SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_LAST_E) {
            rc = SX_STATUS_CMD_UNSUPPORTED;
            SX_LOG_ERR("Flex modifier EMT [%u] update [%u] index [%u] is not supported\n",
                       emt_id, emt_cfg_p->emt_update_list[i], i);
            goto out;
        }
    }

out:
    return rc;
}

/* This is a utility function to validate the configuration provided by the user */
static sx_status_t __validate_emt_config(const sx_flex_modifier_emt_id_e   emt_id,
                                         const sx_flex_modifier_emt_cfg_t *emt_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (emt_cfg_p->emt_data_length_type >= SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_LAST_E) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Flex modifier EMT [%u] data length type [%u] exceeds limit [%u]\n",
                   emt_id, emt_cfg_p->emt_data_length_type, SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_LAST_E);
        goto out;
    }

    if (emt_cfg_p->emt_update_cnt > SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_LAST_E) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Flex modifier EMT [%u] update count [%u] exceeds limit [%u]\n",
                   emt_id, emt_cfg_p->emt_update_cnt, SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_LAST_E);
        goto out;
    }

    /* Go over all the fields and make sure they are legal */
    rc = __is_emt_cmd_valid_cb(emt_id, emt_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __emt_at_device_ready(emt_db_entry_t *entry_p, void *param_p)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    ram_offset_t ram_offset = 0;

    SX_LOG_ENTER();

    UNUSED_PARAM(param_p);

    if (entry_p->configured) {
        ram_offset = __emt_to_ram_map_cb(entry_p->emt_id);
        rc = hwd_flex_modifier_reg_fmtc_set(entry_p->emt_id,
                                            &entry_p->emt_cfg,
                                            (entry_p->is_tunnel) ? &entry_p->tunnel_cfg : NULL,
                                            (entry_p->is_tunnel) ? entry_p->uirif : 0,
                                            ram_offset);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed setting EMT [%u] template register at device ready.\n", entry_p->emt_id);
            goto out;
        }
        rc = hwd_flex_modifier_reg_fmte_set(entry_p->emt_id, &entry_p->emt_cfg);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed setting EMT [%u] template entries registers at device ready.\n", entry_p->emt_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_modifier_device_ready_callback(adviser_event_e event_type, void *param_p)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_dev_info_t *dev_info_p = (sx_dev_info_t*)(param_p);

    SX_LOG_ENTER();

    if (event_type != ADVISER_EVENT_POST_DEVICE_READY_E) {
        SX_LOG_ERR("Wrong event type - expected event type is ADVISER_EVENT_POST_DEVICE_READY, "
                   "received event type: [%s]\n", ADVISER_EVENT_STR(event_type));
        rc = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    rc = flex_modifier_db_emt_foreach(__emt_at_device_ready, &dev_info_p->dev_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in set EMT zero device configuration upon device ready, error: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* RAM is not supported for Spectrum 2 & 3 so we just return zero. */
static uint16_t __emt_to_ram_map(const sx_flex_modifier_emt_id_e emt_id)
{
    UNUSED_PARAM(emt_id);

    return 0;
}

/* Currently we use EMT as the RAM index */
static uint16_t __emt_to_ram_map_spc4(const sx_flex_modifier_emt_id_e emt_id)
{
    return (uint16_t)emt_id;
}

static sx_status_t __flex_modifier_hw_set(const sx_flex_modifier_emt_id_e    emt_id,
                                          const boolean_t                    emt_in_use,
                                          const sx_flex_modifier_emt_cfg_t  *emt_cfg_p,
                                          const sx_tunnel_flex_header_cfg_t *tunnel_cfg_p,
                                          const sx_router_interface_t        uirif,
                                          boolean_t                         *fence_needed)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_emt_id_e free_emt_id = 0;
    sx_utils_status_t         utils_err = SX_UTILS_STATUS_SUCCESS;
    ram_offset_t              ram_offset = __emt_to_ram_map_cb(emt_id);

    SX_LOG_ENTER();

    if (emt_in_use) {
        /* If the current EMT is in use we can try to use another EMT to do an edit on-the-fly.
         * We find a free EMT, write the data to it first change the pointer to it and than configure the original EMT.
         */
        rc = flex_modifier_db_find_free_emt(&free_emt_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("EMT [%u] is used by clients and cannot be modified on-the-fly.\n", emt_id);
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
        /* Configure the free EMT first */
        rc = hwd_flex_modifier_reg_fmtc_set(free_emt_id, emt_cfg_p, tunnel_cfg_p, uirif, ram_offset);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed setting free EMT [%u] template register.\n", emt_id);
            goto out;
        }
        rc = hwd_flex_modifier_reg_fmte_set(free_emt_id, emt_cfg_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed setting free EMT [%u] template entries registers.\n", emt_id);
            goto out;
        }
        /* Map the original EMT to point to the free EMT */
        rc = hwd_flex_modifier_reg_fmtm_set(emt_id, free_emt_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed mapping EMT [%u] to EMT [%u].\n", emt_id, free_emt_id);
            goto out;
        }
    } else {
        /* If we're trying to modify an EMT that once has been used we want to make sure
         * no packets are still in the pipeline using the old configuration.
         */
        if (*fence_needed) {
            utils_err = gc_object_fence(GC_FENCE_TYPE_SLOW);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                rc = sx_utils_status_to_sx_status(utils_err);
                SX_LOG_ERR("Failed to perform slow fence for EMT [%u] modify, utils_err = [%s]\n",
                           emt_id, SX_UTILS_STATUS_MSG(utils_err));
                goto out;
            }
            *fence_needed = FALSE;
        }
    }

    /* Configure the EMT first */
    rc = hwd_flex_modifier_reg_fmtc_set(emt_id, emt_cfg_p, tunnel_cfg_p, uirif, ram_offset);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed setting EMT [%u] template register.\n", emt_id);
        goto out;
    }
    rc = hwd_flex_modifier_reg_fmte_set(emt_id, emt_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed setting EMT [%u] template entries registers.\n", emt_id);
        goto out;
    }
    if (emt_in_use) {
        /* Return the original mapping of the EMT. */
        rc = hwd_flex_modifier_reg_fmtm_set(emt_id, emt_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed mapping EMT [%u] to EMT [%u].\n", emt_id, emt_id);
            goto out;
        }
    }


out:
    SX_LOG_EXIT();

    return rc;
}


sx_status_t flex_modifier_set(const sx_access_cmd_t             cmd,
                              const sx_flex_modifier_emt_id_e   emt_id,
                              const sx_flex_modifier_emt_cfg_t *emt_cfg_p)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_utils_status_t         utils_err = SX_UTILS_STATUS_SUCCESS;
    emt_db_entry_t           *emt_entry_p = NULL;
    sx_utils_status_t         utils_rc = SX_UTILS_STATUS_SUCCESS;
    int                       ref_count = 0;
    sx_flex_modifier_emt_id_e ref_emt_id = emt_id;
    ref_name_data_t           ref_name_data = {.print_func_p = get_emt_id_name,
                                               .ref_data_p = &ref_emt_id,
                                               .data_size = sizeof(ref_emt_id)};


    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier EMT set failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        if (SX_CHECK_FAIL(rc = utils_check_pointer(emt_cfg_p, "emt_cfg_p"))) {
            goto out;
        }
    }

    /* Check if the command is correct here. */
    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex modifier EMT set failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = flex_modifierr_db_emt_get(emt_id, &emt_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving EMT [%u] from DB.\n", emt_id);
        goto out;
    }

    /* If we just create the entry validate it's not already defined */
    if (cmd == SX_ACCESS_CMD_CREATE) {
        if (emt_entry_p->valid) {
            SX_LOG_ERR("Flex modifier EMT [%u] is already created and cannot be created again.\n", emt_id);
            rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
            goto out;
        }
        rc = rm_entries_set(RM_SDK_TABLE_TYPE_FLEX_MODIFIER_EMT_E, SX_ACCESS_CMD_ADD, 1, NULL);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("No resources to create flex modifier EMT [%u]\n", emt_id);
            goto out;
        }
        emt_entry_p->valid = TRUE;
        goto out;
    }

    if (!emt_entry_p->valid) {
        SX_LOG_ERR("Flex modifier EMT [%u] was not created and cannot be modified.\n", emt_id);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Don't allow changing of an EMT if it's in use */
    utils_rc = sdk_refcount_get(&emt_entry_p->refcount, &ref_count);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to get the reference count for EMT [%u].\n", emt_id);
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        if (emt_entry_p->is_tunnel &&
            (emt_cfg_p->emt_data_length_type == SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_DYNAMIC_E)) {
            /* Dynamic length is not supported for tunnel configuration */
            SX_LOG_ERR("EMT [%u] has dynamic length and cannot be used by tunnels.\n", emt_id);
            rc = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        if ((ref_count > 0) &&
            (emt_cfg_p->emt_data_length_type == SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_DYNAMIC_E) &&
            (emt_entry_p->emt_cfg.emt_data_length_type != SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_DYNAMIC_E)) {
            /* If the entry is already in use we should not change it to dynamic mode */
            SX_LOG_ERR("EMT [%u] has is in use and cannot be changed to dynamic length.\n", emt_id);
            rc = SX_STATUS_UNSUPPORTED;
            goto out;
        }
    }

    if (cmd == SX_ACCESS_CMD_DESTROY) {
        /* We cannot destroy if the EMT is in use */
        if ((ref_count > 0) || emt_entry_p->is_tunnel) {
            SX_LOG_ERR("EMT [%u] is used by %u clients or used by tunnel and cannot be destroyed.\n", emt_id,
                       ref_count);
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
        /* If we destroy release the resource */
        rc = rm_entries_set(RM_SDK_TABLE_TYPE_FLEX_MODIFIER_EMT_E, SX_ACCESS_CMD_DELETE, 1, NULL);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to release resource for EMT [%u]\n", emt_id);
            goto out;
        }

        /* If the entry might be still used by something call the fence */
        if (emt_entry_p->fence_needed) {
            utils_err = gc_object_fence(GC_FENCE_TYPE_SLOW);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                rc = sx_utils_status_to_sx_status(utils_err);
                SX_LOG_ERR("Failed to perform slow fence for EMT [%u] delete, utils_err = [%s]\n",
                           emt_id, SX_UTILS_STATUS_MSG(utils_err));
                goto out;
            }
        }
        /* For dynamic length we need to remove any previous GP register reference */
        if (emt_entry_p->configured &&
            (emt_entry_p->emt_cfg.emt_data_length_type == SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_DYNAMIC_E)) {
            rc = sdk_register_impl_ref_decrease(emt_entry_p->emt_cfg.emt_data_dynamic_length.gp_register,
                                                &emt_entry_p->gp_reg_ref);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to release GP register [%u] reference for EMT set, error: [%s]\n",
                           emt_entry_p->emt_cfg.emt_data_dynamic_length.gp_register.key.gp_reg.reg_id,
                           sx_status_str(rc));
                goto out;
            }
        }

        emt_entry_p->valid = FALSE;
        emt_entry_p->configured = FALSE;
        emt_entry_p->fence_needed = FALSE;
        emt_entry_p->is_tunnel = FALSE;
        SX_MEM_CLR(emt_entry_p->emt_cfg);
        goto out;
    }

    /* If we're here we're setting/overwriting a header */
    rc = __validate_emt_config(emt_id, emt_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("EMT [%u] failed validation.\n", emt_id);
        goto out;
    }

    /* For dynamic length we need to remove any previous GP register reference */
    if (emt_entry_p->configured &&
        (emt_entry_p->emt_cfg.emt_data_length_type == SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_DYNAMIC_E)) {
        rc = sdk_register_impl_ref_decrease(emt_entry_p->emt_cfg.emt_data_dynamic_length.gp_register,
                                            &emt_entry_p->gp_reg_ref);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to release GP register [%u] reference for EMT set, error: [%s]\n",
                       emt_entry_p->emt_cfg.emt_data_dynamic_length.gp_register.key.gp_reg.reg_id,
                       sx_status_str(rc));
            goto out;
        }
    }
    /* For dynamic length we need to add GP register reference */
    if (emt_cfg_p->emt_data_length_type == SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_DYNAMIC_E) {
        rc = sdk_register_impl_ref_increase(emt_cfg_p->emt_data_dynamic_length.gp_register,
                                            &ref_name_data,
                                            &emt_entry_p->gp_reg_ref);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to release GP register [%u] reference for EMT set, error: [%s]\n",
                       emt_cfg_p->emt_data_dynamic_length.gp_register.key.gp_reg.reg_id,
                       sx_status_str(rc));
            goto out;
        }
    }

    /* Actually set the entry in HW along with the tunnel fields if they exist */
    rc = __flex_modifier_hw_set(emt_id,
                                (ref_count > 0) ? TRUE : FALSE,
                                emt_cfg_p,
                                (emt_entry_p->is_tunnel) ? &emt_entry_p->tunnel_cfg : NULL,
                                (emt_entry_p->is_tunnel) ? emt_entry_p->uirif : 0,
                                &emt_entry_p->fence_needed);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("EMT [%u] failed configuration to HW.\n", emt_id);
        goto out;
    }

    emt_entry_p->configured = TRUE;
    emt_entry_p->emt_cfg = *emt_cfg_p;

    goto out;

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_modifier_get(const sx_access_cmd_t           cmd,
                              const sx_flex_modifier_emt_id_e emt_id,
                              sx_flex_modifier_emt_cfg_t     *emt_cfg_p)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    emt_db_entry_t *emt_entry_p = NULL;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier EMT get failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex modifier EMT get failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = flex_modifierr_db_emt_get(emt_id, &emt_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving EMT [%u] from DB.\n", emt_id);
        goto out;
    }

    if (emt_entry_p->configured != TRUE) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (emt_cfg_p) {
        *emt_cfg_p = emt_entry_p->emt_cfg;
    }

out:
    SX_LOG_EXIT();

    return rc;
}


sx_status_t flex_modifier_attr_set(const sx_access_cmd_t                cmd,
                                   const uint32_t                       attr_cfg_cnt,
                                   const sx_flex_modifier_attributes_t *attr_cfg_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    /*verify module init is done and port_attr_db initialized */
    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier attr set failed - module is not initialized . %s\n", sx_status_str(rc));
        goto out;
    }

    /*input validation */
    if (SX_CHECK_FAIL(rc = utils_check_pointer(attr_cfg_list_p, "attr_cfg_list_p"))) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /*sweep over list, call handlers */
    for (i = 0; i < attr_cfg_cnt; i++) {
        switch (attr_cfg_list_p[i].attr_type) {
        case SX_FLEX_MODIFIER_ATTR_TYPE_PORT_E:

            rc = flex_modifier_port_attr_set_handler(cmd, &attr_cfg_list_p[i].sx_flex_modifier_attr);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Flex modifier port attr set handler failed with status: %s\n", sx_status_str(rc));
                goto out;
            }
            break;

        default:
            rc = SX_STATUS_CMD_UNSUPPORTED;
            SX_LOG_ERR("Flex modifier attr_type = %d is not supported\n", attr_cfg_list_p[i].attr_type);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_modifier_port_attr_set_handler(const sx_access_cmd_t               cmd,
                                                const sx_flex_modifier_type_attr_u *sx_flex_modifier_attr)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_db_port_attr_item_t *port_attr_item_p = NULL;
    sx_port_log_id_t                      log_port = sx_flex_modifier_attr->port_attributes.log_port;
    uint16_t                              payload_offset_shift =
        sx_flex_modifier_attr->port_attributes.payload_offset_shift;


    if (payload_offset_shift > PORT_MODIFIER_PAYLOAD_OFFSET_MOV_MAX_BYTES) {
        SX_LOG_ERR("flex modifier payload_offset_shift [bytes] is out of range  X > %d\n",
                   PORT_MODIFIER_PAYLOAD_OFFSET_MOV_MAX_BYTES);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (PORT_MODIFIER_PAYLOAD_CHECK_GRAN(payload_offset_shift)) {
        SX_LOG_ERR("flex modifier payload_offset_shift [bytes] is not in supported granularity: %d [bytes]\n",
                   PORT_MODIFIER_PAYLOAD_OFFSET_MOV_GRAN_BYTES);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Validate the port is a network port */
    VALIDATE_PORT(flex_modifier_attr_set, log_port);

    /* Check that the port is valid */
    rc = port_db_info_get(log_port, NULL);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to retrieve port [0x%08X] db info, error: %s\n",
                   log_port, sx_status_str(rc));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_DELETE:

        rc = flex_modifier_db_port_attr_get(log_port, &port_attr_item_p);

        if ((NULL != port_attr_item_p) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {    /*port map already exist in db */
            /*Propagate configuration request to FW only if valid */
            rc = hwd_flex_modifier_reg_fmep_set(cmd, log_port, payload_offset_shift);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed un setting fmep register entry for port [0x%08X].\n", log_port);

                goto out;
            }

            /*delete entry from db upon fw confirmation */
            rc = flex_modifier_db_port_attr_delete(log_port);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to delete flex modifier db attribute entry for port [0x%08X].\n", log_port);
                goto out;
            }
        } else {
            SX_LOG_ERR("Flex modifier attributes are not configured for logical port [0x%x].\n", log_port);
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_ADD:

        rc = flex_modifier_db_port_attr_get(log_port, &port_attr_item_p);

        if ((NULL != port_attr_item_p) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {    /*port map already exist in db */
            /*in case new and current entries are equal skip fw/db update */
            if (port_attr_item_p->port_attributes.payload_offset_shift == payload_offset_shift) {
                /*do nothing */
                SX_LOG_INF(
                    "[flex_modifier_port_attr_set_handler] payload_offset_shift == current payload_offset_shift for log_port: %d .\n",
                    log_port);
                goto out;
            }
        } else {    /*no mapping in db for requested port - set new db entry */
            rc = flex_modifier_db_port_attr_add(log_port, &port_attr_item_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed setting new db attribute entry for port [0x%08X].\n", log_port);
                goto out;
            }
        }

        /*propagate request to fw */
        rc = hwd_flex_modifier_reg_fmep_set(cmd, log_port, payload_offset_shift);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed setting fmep register entry of port [0x%08X].\n", log_port);
            goto out;
        }
        /*update db with new conf upon fw confirmation */
        port_attr_item_p->port_attributes.log_port = log_port;
        port_attr_item_p->port_attributes.payload_offset_shift = payload_offset_shift;

        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex modifier attribute command = %d is not supported\n", cmd);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_attr_get(const sx_access_cmd_t          cmd,
                                   uint32_t                      *attr_cfg_cnt_p,
                                   sx_flex_modifier_attributes_t *attr_cfg_list_p)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_db_port_attr_item_t *port_attr_item_p = NULL;
    sx_port_log_id_t                      local_port = 0;
    uint32_t                              attr_cfg_cnt_local = 0, i = 0;

    SX_LOG_ENTER();


    /*verify module init is done and port_attr_db initialized */
    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier attr get failed -  module is not initialized . %s\n", sx_status_str(rc));
        goto out;
    }

    if ((*attr_cfg_cnt_p) == 0) {
        rc = flex_modifier_db_port_attr_count(attr_cfg_cnt_p);
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        /*sweep over list, call handlers */
        for (i = 0; i < *attr_cfg_cnt_p; i++) {
            switch (attr_cfg_list_p[i].attr_type) {
            case SX_FLEX_MODIFIER_ATTR_TYPE_PORT_E:

                VALIDATE_PORT(flex_modifier_attr_get,
                              attr_cfg_list_p[i].sx_flex_modifier_attr.port_attributes.log_port);

                /* Check that the port is valid */
                rc = port_db_info_get(attr_cfg_list_p[i].sx_flex_modifier_attr.port_attributes.log_port, NULL);

                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to retrieve port [0x%08X] db info, error: %s\n",
                               attr_cfg_list_p[i].sx_flex_modifier_attr.port_attributes.log_port, sx_status_str(rc));
                    goto out;
                }
                rc = flex_modifier_db_port_attr_get(attr_cfg_list_p[i].sx_flex_modifier_attr.port_attributes.log_port,
                                                    &port_attr_item_p);
                if (SX_CHECK_FAIL(rc)) {
                    /*if port attribute is not available in db return with 0.*/
                    rc = SX_STATUS_SUCCESS;
                    attr_cfg_list_p[i].sx_flex_modifier_attr.port_attributes.payload_offset_shift = 0;
                } else {
                    SX_MEM_CPY(attr_cfg_list_p[i].sx_flex_modifier_attr.port_attributes,
                               port_attr_item_p->port_attributes);
                }

                break;

            default:
                rc = SX_STATUS_CMD_UNSUPPORTED;
                SX_LOG_ERR("Flex modifier attr_type = %d is not supported \n", attr_cfg_list_p[i].attr_type);
                goto out;
            }
        }
        break;

    case SX_ACCESS_CMD_GET_ALL:
        rc = flex_modifier_db_port_attr_count(&attr_cfg_cnt_local);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to retrieve entry count for flex modifier attribute db.\n");
            goto out;
        }

        /* verify that allocated list is sufficient for all db entries*/
        if (attr_cfg_cnt_local > *attr_cfg_cnt_p) {
            SX_LOG_ERR("Flex modifier attr get all failed insufficient memory allocated.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        for (i = 0; i < *attr_cfg_cnt_p; i++) {
            rc = flex_modifier_db_port_attr_get_next(local_port, &port_attr_item_p);
            if (SX_CHECK_FAIL(rc)) {
                break;
            }
            SX_MEM_CPY(attr_cfg_list_p[i].sx_flex_modifier_attr.port_attributes, port_attr_item_p->port_attributes);
            local_port = port_attr_item_p->port_attributes.log_port;
        }
        *attr_cfg_cnt_p = i;
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex modifier attribute command = %d is not supported\n", cmd);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_validate_emt_bind(const sx_flex_modifier_emt_id_e  emt_id,
                                            sx_flex_modifier_emt_bind_type_e bind_type)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    emt_db_entry_t *emt_entry_p = NULL;
    uint32_t        i = 0;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier validate EMT bind failed. %s\n", sx_status_str(rc));
        goto out;
    }

    rc = flex_modifierr_db_emt_get(emt_id, &emt_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving EMT [%u] from DB.\n", emt_id);
        goto out;
    }

    if (emt_entry_p->configured != TRUE) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Flex modifier EMT [%u] is not configured.\n", emt_id);
        goto out;
    }

    if (emt_entry_p->is_tunnel == TRUE) {
        rc = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Flex modifier EMT [%u] cannot be bound to ACL since it's used by tunnel.\n", emt_id);
        goto out;
    }

    if (emt_entry_p->emt_cfg.emt_data_length_type == SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_DYNAMIC_E) {
        if ((bind_type == SX_FLEX_MODIFIER_BIND_TYPE_PUSH_E) || (bind_type == SX_FLEX_MODIFIER_BIND_TYPE_EDIT_E)) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Flex modifier EMT [%u] has a dynamic length not suitable for push/edit operations.\n", emt_id);
            goto out;
        }
    }

    if (bind_type == SX_FLEX_MODIFIER_BIND_TYPE_PUSH_E) {
        for (i = 0; i < emt_entry_p->emt_cfg.emt_data_cnt; i++) {
            if (emt_entry_p->emt_cfg.emt_data_list[i].skip) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Flex modifier EMT [%u] has a skip operation not suitable for push.\n", emt_id);
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_modifier_emt_ref_inc(const sx_flex_modifier_emt_id_e emt_id,
                                      const ref_name_data_t          *ref_name_data_p,
                                      sdk_ref_t                      *ref_p)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    emt_db_entry_t *emt_entry_p = NULL;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier validate EMT bind failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(ref_name_data_p, "ref_name_data_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(ref_p, "ref_p"))) {
        goto out;
    }

    rc = flex_modifierr_db_emt_get(emt_id, &emt_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving EMT [%u] from DB.\n", emt_id);
        goto out;
    }

    if (emt_entry_p->configured != TRUE) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Flex modifier EMT [%u] is not configured.\n", emt_id);
        goto out;
    }

    rc = sx_utils_status_to_sx_status(sdk_refcount_inc(&emt_entry_p->refcount, ref_name_data_p, ref_p));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to increase reference to flex modifier EMT [%u], %s\n",
                   emt_id,
                   sx_status_str(rc));
        goto out;
    }

    /* Indicate that the entry was used by someone and therefore a fence might be needed */
    emt_entry_p->fence_needed = TRUE;

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_modifier_emt_ref_dec(const sx_flex_modifier_emt_id_e emt_id, sdk_ref_t *ref_p)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    emt_db_entry_t *emt_entry_p = NULL;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier validate EMT bind failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(ref_p, "ref_p"))) {
        goto out;
    }

    rc = flex_modifierr_db_emt_get(emt_id, &emt_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving EMT [%u] from DB.\n", emt_id);
        goto out;
    }

    if (emt_entry_p->configured != TRUE) {
        SX_LOG_ERR("Flex modifier EMT [%u] is not configured.\n", emt_id);
        goto out;
    }

    rc = sx_utils_status_to_sx_status(sdk_refcount_dec(&emt_entry_p->refcount, ref_p));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to decrease reference to flex modifier EMT [%u], %s\n",
                   emt_id,
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_modifier_emt_ref_get(const sx_flex_modifier_emt_id_e emt_id, int* count_p)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    emt_db_entry_t *emt_entry_p = NULL;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier validate EMT bind failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(count_p, "count_p"))) {
        goto out;
    }

    rc = flex_modifierr_db_emt_get(emt_id, &emt_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving EMT [%u] from DB.\n", emt_id);
        goto out;
    }

    if (emt_entry_p->configured != TRUE) {
        SX_LOG_ERR("Flex modifier EMT [%u] is not configured.\n", emt_id);
        goto out;
    }

    rc = sx_utils_status_to_sx_status(sdk_refcount_get(&emt_entry_p->refcount, count_p));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get reference to flex modifier EMT [%u], %s\n",
                   emt_id,
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();

    return rc;
}

void flex_modifier_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    FILE *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_module_header_print(stream, "SDK FLEX MODIFIER Module");
    dbg_utils_pprinter_field_print(stream, "Module initialized", &__flex_modifier_init_done_s,
                                   PARAM_BOOL_E);
    if (!__flex_modifier_init_done_s) {
        goto out;
    }
    dbg_utils_pprinter_field_print(stream, "Secondary RAM offset", &__secondary_ram_offset, PARAM_UINT16_E);

    /* Dump the EMT database */
    flex_modifier_db_emt_dump(dbg_dump_params_p);
    /* Dump the port modifier attribute database */
    flex_modifier_port_attr_dump(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
}

sx_status_t flex_modifier_tunnel_set(const sx_tunnel_flex_header_cfg_t *tunnel_header_cfg_p,
                                     const sx_router_interface_t        uirif)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    emt_db_entry_t   *emt_entry_p = NULL;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;
    int               ref_count = 0;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier tunnel set failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(tunnel_header_cfg_p, "tunnel_header_cfg_p"))) {
        goto out;
    }

    rc = flex_modifierr_db_emt_get(tunnel_header_cfg_p->tunnel_header_emt_id.emt_id, &emt_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving EMT [%u] from DB for flex modifier tunnel set.\n",
                   tunnel_header_cfg_p->tunnel_header_emt_id.emt_id);
        goto out;
    }

    if (emt_entry_p->configured != TRUE) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Flex modifier EMT [%u] is not configured.\n",
                   tunnel_header_cfg_p->tunnel_header_emt_id.emt_id);
        goto out;
    }

    /* Dynamic length is not supported for tunnel configuration */
    if (emt_entry_p->emt_cfg.emt_data_length_type == SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_DYNAMIC_E) {
        SX_LOG_ERR("EMT [%u] has dynamic length and cannot be used by tunnels.\n",
                   tunnel_header_cfg_p->tunnel_header_emt_id.emt_id);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    /* Check if this EMT is already used by an ACL */
    utils_rc = sdk_refcount_get(&emt_entry_p->refcount, &ref_count);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to get the reference count for EMT [%u] for tunnel set.\n",
                   tunnel_header_cfg_p->tunnel_header_emt_id.emt_id);
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

    /* Check if the EMT is already in use by the ACL so we cannot use it for tunnel */
    if ((ref_count > 0) && (emt_entry_p->is_tunnel != TRUE)) {
        SX_LOG_ERR("EMT [%u] is used by %u ACLs and cannot be used by tunnels.\n",
                   tunnel_header_cfg_p->tunnel_header_emt_id.emt_id,
                   ref_count);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* Actually set the entry in HW along with the tunnel fields if they exist */
    rc = __flex_modifier_hw_set(tunnel_header_cfg_p->tunnel_header_emt_id.emt_id,
                                (ref_count > 0) ? TRUE : FALSE,
                                &emt_entry_p->emt_cfg,
                                tunnel_header_cfg_p,
                                uirif,
                                &emt_entry_p->fence_needed);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("EMT [%u] tunnel failed configuration to HW.\n",
                   tunnel_header_cfg_p->tunnel_header_emt_id.emt_id);
        goto out;
    }

    emt_entry_p->tunnel_cfg = *tunnel_header_cfg_p;
    emt_entry_p->uirif = uirif;
    emt_entry_p->is_tunnel = TRUE;

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_modifier_tunnel_unset(const sx_flex_modifier_emt_id_e emt_id)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    emt_db_entry_t   *emt_entry_p = NULL;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;
    int               ref_count = 0;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier tunnel set failed. %s\n", sx_status_str(rc));
        goto out;
    }

    rc = flex_modifierr_db_emt_get(emt_id, &emt_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving EMT [%u] from DB for flex modifier tunnel unset.\n", emt_id);
        goto out;
    }

    if (emt_entry_p->configured != TRUE) {
        SX_LOG_ERR("Flex modifier EMT [%u] is not configured.\n", emt_id);
        goto out;
    }

    utils_rc = sdk_refcount_get(&emt_entry_p->refcount, &ref_count);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to get the reference count for EMT [%u] for tunnel unset.\n", emt_id);
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

    if (ref_count > 0) {
        SX_LOG_ERR("EMT [%u] is in use and cannot be unset by tunnel.\n", emt_id);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* Actually remove the tunnel configuration from the entry */
    rc = __flex_modifier_hw_set(emt_id,
                                FALSE,
                                &emt_entry_p->emt_cfg,
                                NULL,
                                0,
                                &emt_entry_p->fence_needed);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("EMT [%u] tunnel failed configuration to HW.\n", emt_id);
        goto out;
    }

    SX_MEM_CLR(emt_entry_p->tunnel_cfg);
    emt_entry_p->uirif = 0;
    emt_entry_p->is_tunnel = FALSE;

out:
    SX_LOG_EXIT();

    return rc;
}

/* Write the complete flex modifier registers after ISSU is complete*/
sx_status_t flex_modifier_issu_set()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* When the ISSU is complete we'll write the flex modifier configuration
     * (including the flex tunnel information) to the register.
     */
    rc = flex_modifier_db_emt_foreach(__emt_at_device_ready, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in set EMT zero device configuration upon device ready, error: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_modifier_secondary_ram_lock()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier secondary ram lock failure. %s\n", sx_status_str(rc));
        goto out;
    }

    if (__secondary_ram_in_use) {
        rc = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("Flex modifier secondary RAM is already locked\n");
        goto out;
    }
    __secondary_ram_in_use = TRUE;

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_modifier_secondary_ram_unlock()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_modifier_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex modifier secondary ram unlock failure. %s\n", sx_status_str(rc));
        goto out;
    }

    if (!__secondary_ram_in_use) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Flex modifier secondary RAM is already unlocked\n");
        goto out;
    }
    __secondary_ram_in_use = FALSE;

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_modifier_secondary_ram_offset_set_internal(const ram_offset_t ram_secondary_offset)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__secondary_ram_in_use) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Flex modifier secondary RAM is locked, offset cannot be changed.\n");
        goto out;
    }

    if (ram_secondary_offset >= rm_resource_global.gp_ram_size) {
        SX_LOG_ERR("Flex modifier: RAM offset [%u] exceeds maximum [%u]\n",
                   ram_secondary_offset, rm_resource_global.gp_ram_size);
        goto out;
    }

    /* We reserve the lower offsets for the default EMT offset */
    if (ram_secondary_offset < SX_FLEX_MODIFIER_EMT_LAST_E) {
        SX_LOG_ERR("Flex modifier: RAM offset [%u] is reserved for EMT use\n",
                   ram_secondary_offset);
        goto out;
    }

    rc = hwd_flex_modifier_reg_fgcr_set(ram_secondary_offset);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex modifier: Failed to set RAM secondary offset to [%u]\n", ram_secondary_offset);
        goto out;
    }

    __secondary_ram_offset = ram_secondary_offset;

out:
    SX_LOG_EXIT();

    return rc;
}
