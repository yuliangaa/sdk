/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include "ethl2/brg.h"
#include "flex_parser_be.h"
#include "flex_parser_impl.h"
#include "flex_parser/hwd/hwd_flex_parser.h"

#undef __MODULE__
#define __MODULE__ FLEX_PARSER


/************************************************
 *  Global variables
 ***********************************************/
extern sx_brg_context_t brg_context;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t __flex_parser_init_done_s = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t flex_parser_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    sdk_flex_parser_impl_log_verbosity_level_set(verbosity_level);
    hwd_flex_parser_log_verbosity_level_set(verbosity_level);

    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_parser_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (verbosity_level_p == NULL) {
        SX_LOG_ERR("verbosity level pointer is NULL.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_parser_init(const IN sx_flex_parser_param_t *params_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == TRUE) {
        rc = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Init Failure. %s\n", sx_status_str(rc));
        goto out;
    }

    rc = sdk_flex_parser_init(params_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("flex_parser init failed.\n");
        goto out;
    }

    __flex_parser_init_done_s = TRUE;

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_parser_deinit()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Deinit Failure. %s\n", sx_status_str(rc));
        goto out;
    }

    rc = sdk_flex_parser_deinit(FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("flex_parser deinit failed.\n");
        goto out;
    }

    __flex_parser_init_done_s = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_parser_transition_set(const sx_access_cmd_t             cmd,
                                       const sx_flex_parser_header_t     from,
                                       const sx_flex_parser_transition_t to)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Transition set failed. %s\n", sx_status_str(rc));
        goto out;
    }
    rc = sdk_flex_parser_transition_set(cmd, from, to);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk transition set failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_transition_get(const sx_flex_parser_header_t curr_ph,
                                       sx_flex_parser_transition_t  *next_trans_p,
                                       uint32_t                     *next_trans_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Transition get failed. %s\n", sx_status_str(rc));
        goto out;
    }

    rc = sdk_flex_parser_transition_get(curr_ph, next_trans_p, next_trans_cnt_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk transition get failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_flex_transition_set(const sx_access_cmd_t               cmd,
                                            sx_flex_parser_transition_index_t  *transition_index_p,
                                            sx_flex_parser_transition_action_t *transition_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Transition set failed. %s\n", sx_status_str(rc));
        goto out;
    }
    rc = sdk_flex_parser_flex_transition_set(cmd, transition_index_p, transition_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk flex transition set failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_flex_transition_get(const sx_flex_parser_transition_index_t transition_index,
                                            sx_flex_parser_transition_action_t     *transition_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Transition get failed. %s\n", sx_status_str(rc));
        goto out;
    }
    rc = sdk_flex_parser_flex_transition_get(transition_index, transition_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk flex transition get failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_fpp_set(const sx_access_cmd_t         cmd,
                                const sx_flex_parser_fpp_id_t fpp_id,
                                const sx_flex_parser_fpp_t   *fpp_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex parser FPP set failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex parser FPP set failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = sdk_flex_parser_fpp_set(cmd, fpp_id, fpp_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk FPP set failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_fpp_get(const sx_access_cmd_t         cmd,
                                const sx_flex_parser_fpp_id_t fpp_id,
                                sx_flex_parser_fpp_t         *fpp_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex parser FPP get failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex parser FPP get failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = sdk_flex_parser_fpp_get(cmd, fpp_id, fpp_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk FPP get failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_root_set(const sx_access_cmd_t                cmd,
                                 const uint32_t                       root_cfg_count,
                                 const sx_flex_parser_root_sop_cfg_t *root_cfg_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex parser root set failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_UNSET)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex parser root set failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = sdk_flex_parser_root_set(cmd, root_cfg_count, root_cfg_list_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk root set failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_root_get(const sx_access_cmd_t          cmd,
                                 const sx_port_log_id_t         log_port,
                                 uint32_t                      *root_cfg_count_p,
                                 sx_flex_parser_root_sop_cfg_t *root_cfg_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex parser root get failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_GET_FIRST) && (cmd != SX_ACCESS_CMD_GETNEXT)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex parser root get failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = sdk_flex_parser_root_get(cmd, log_port, root_cfg_count_p, root_cfg_list_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk root get failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_hph_set(const sx_access_cmd_t         cmd,
                                const sx_flex_parser_hph_id_t hph_id,
                                const sx_flex_parser_hph_t   *hph_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex parser HPH set failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_UNSET)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex parser HPH set failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_SET) && (hph_cfg_p->ftlv_mode == SX_FLEX_PARSER_TLV_PARSING_DISABLED)) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Flex parser HPH set failed: FTLV mode (%u)\n", hph_cfg_p->ftlv_mode);
        goto out;
    }

    rc = sdk_flex_parser_hph_set(cmd, hph_id, hph_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk HPH set failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_hph_get(const sx_access_cmd_t         cmd,
                                const sx_flex_parser_hph_id_t hph_id,
                                sx_flex_parser_hph_t         *hph_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex parser HPH get failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex parser HPH get failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = sdk_flex_parser_hph_get(cmd, hph_id, hph_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk HPH get failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_fexp_set(const sx_access_cmd_t cmd, sx_flex_parser_fexp_id_t *fexp_id_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex parser FEXP set failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex parser FEXP set failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = sdk_flex_parser_fexp_set(cmd, fexp_id_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk FEXP set failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_flex_graph_set(const sx_access_cmd_t          cmd,
                                       const uint32_t                 actions_cnt,
                                       sx_flex_parser_graph_action_t *actions_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex parser flex graph set failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE) && (cmd != SX_ACCESS_CMD_DELETE_ALL)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex parser flex graph set failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = sdk_flex_parser_flex_graph_set(cmd, actions_cnt, actions_list_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk flex graph set failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_hard_graph_set(const sx_access_cmd_t          cmd,
                                       const uint32_t                 actions_cnt,
                                       sx_flex_parser_graph_action_t *actions_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex parser hard graph set failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_UNSET) && (cmd != SX_ACCESS_CMD_DELETE_ALL)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex parser hard graph set failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = sdk_flex_parser_hard_graph_set(cmd, actions_cnt, actions_list_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk hard graph set failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_resources_get(const sx_access_cmd_t cmd, sx_flex_parser_resources_t *flex_parser_resources)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Flex parser hard graph get failed. %s\n", sx_status_str(rc));
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Flex parser resources get failed: invalid command (%s)\n",
                   sx_access_cmd_str(cmd));
        goto out;
    }

    rc = sdk_flex_parser_resources_get(cmd, flex_parser_resources);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser sdk resources get et failed. %s\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_parser_reg_ext_point_set(sx_access_cmd_t        cmd,
                                          sx_register_key_t      reg_key,
                                          uint32_t               ext_point_cnt,
                                          sx_extraction_point_t *ext_point_list_p)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i = 0, j = 0;
    bit_vector_t      ext_point_set;
    boolean_t         bit_vec_set = FALSE, is_set = FALSE;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Failed to set extraction point: flex parser module "
                   "uninitialized, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_UNSET)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Failed to set extraction point on register: invalid command (%s), error: [%s]\n",
                   sx_access_cmd_str(cmd), sx_status_str(rc));
        goto out;
    }

    switch (reg_key.type) {
    case SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
        if (rm_resource_global.gp_register_num_max == 0) {
            rc = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Failed to set extraction point on register: GP registers are not supported\n");
            goto out;
        }
        if (reg_key.key.gp_reg.reg_id >= rm_resource_global.gp_register_num_max) {
            SX_LOG_ERR("Failed to set extraction point on register: "
                       "invalid value %d for GP register ID, max valid ID: %d.\n",
                       reg_key.key.gp_reg.reg_id, rm_resource_global.gp_register_num_max - 1);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to set extraction point on register: invalid register type %d\n", reg_key.type);
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        if ((ext_point_cnt == 0) || (ext_point_cnt > RM_API_FLEX_PARSER_EXT_POINT_MAX_NUM)) {
            SX_LOG_ERR("Failed to set extraction point on register: "
                       "invalid value %d for number of extraction points, valid range: [%d,%d].\n",
                       ext_point_cnt, 1, RM_API_FLEX_PARSER_EXT_POINT_MAX_NUM);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        utils_rc = bit_vector_allocate(SX_EXTRACTION_POINT_TYPE_LAST_E, &ext_point_set);
        if (SX_UTILS_CHECK_FAIL(utils_rc)) {
            bit_vector_free(ext_point_set);
            SX_LOG_ERR("Failed to set extraction point on register: failed to allocate memory, error: [%s]\n",
                       SX_UTILS_STATUS_MSG(utils_rc));
            rc = SX_STATUS_SX_UTILS_RETURNED_NON_ZERO;
            goto out;
        }

        bit_vec_set = TRUE;

        for (i = 0; i < ext_point_cnt; i++) {
            if ((ext_point_list_p[i].type == SX_EXTRACTION_POINT_TYPE_NONE_E) ||
                (ext_point_list_p[i].type >= SX_EXTRACTION_POINT_TYPE_LAST_E)) {
                SX_LOG_ERR("Failed to set extraction point on register: "
                           "invalid type %d (%s) for extraction point #%d.\n",
                           ext_point_list_p[i].type, sx_extraction_point_type_str(ext_point_list_p[i].type), i);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            utils_rc = bit_vector_get(ext_point_set, ext_point_list_p[i].type, &is_set);
            if (SX_UTILS_CHECK_FAIL(utils_rc)) {
                SX_LOG_ERR("Failed to set extraction point on register: failed to get bit %d, error: [%s]\n",
                           ext_point_list_p[i].type, SX_UTILS_STATUS_MSG(utils_rc));
                rc = SX_STATUS_SX_UTILS_RETURNED_NON_ZERO;
                goto out;
            }

            if (is_set) {
                rc = SX_STATUS_PARAM_ERROR;
                /* For FEXP we don't allow it twice only if it's the same FEXP ID. */
                if ((ext_point_list_p[i].type == SX_EXTRACTION_POINT_TYPE_FEXP_OUTER_E) ||
                    (ext_point_list_p[i].type == SX_EXTRACTION_POINT_TYPE_FEXP_INNER_E)) {
                    rc = SX_STATUS_SUCCESS;
                    for (j = 0; j < i; j++) {
                        if ((ext_point_list_p[i].type == ext_point_list_p[j].type) &&
                            (ext_point_list_p[i].attr.fexp_attr.fexp_id.fexp_id ==
                             ext_point_list_p[j].attr.fexp_attr.fexp_id.fexp_id)) {
                            rc = SX_STATUS_PARAM_ERROR;
                            break;
                        }
                    }
                }
                if (rc == SX_STATUS_PARAM_ERROR) {
                    SX_LOG_ERR("Failed to set extraction point on register: "
                               "Extraction point list contains type %d [%s] more than once.\n",
                               ext_point_list_p[i].type, sx_extraction_point_type_str(ext_point_list_p[i].type));
                    goto out;
                }
            }

            utils_rc = bit_vector_set(ext_point_set, ext_point_list_p[i].type);
            if (SX_UTILS_CHECK_FAIL(utils_rc)) {
                SX_LOG_ERR("Failed to set extraction point on register: failed to set bit %d, error: [%s]\n",
                           ext_point_list_p[i].type, SX_UTILS_STATUS_MSG(utils_rc));
                rc = SX_STATUS_SX_UTILS_RETURNED_NON_ZERO;
                goto out;
            }

            if (ext_point_list_p[i].offset > rm_resource_global.acl_custom_bytes_extraction_point_offset_max) {
                SX_LOG_ERR("Failed to set extraction point on register: "
                           "Offset %d of extraction point #%d (%d, %s) is to big offset. Max offset %d.\n",
                           ext_point_list_p[i].offset,
                           i,
                           ext_point_list_p[i].type, sx_extraction_point_type_str(ext_point_list_p[i].type),
                           rm_resource_global.acl_custom_bytes_extraction_point_offset_max);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            if (ext_point_list_p[i].offset % 2 != 0) {
                SX_LOG_ERR("Failed to set extraction point on register: "
                           "Offset of extraction point must be even. Offset %d for extraction point #%d (%d, %s).\n",
                           ext_point_list_p[i].offset,
                           i,
                           ext_point_list_p[i].type, sx_extraction_point_type_str(ext_point_list_p[i].type));
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
    } else { /* CMD is UNSET */
        if (ext_point_cnt != 0) {
            SX_LOG_ERR("Failed to unset extraction point on register: "
                       "ext_point_cnt value %d should be 0.\n", ext_point_cnt);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    rc = sdk_flex_parser_reg_ext_point_set(reg_key, ext_point_cnt, ext_point_list_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set extraction point on register, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    if (bit_vec_set) {
        bit_vector_free(ext_point_set);
    }
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_parser_reg_ext_point_get(sx_access_cmd_t        cmd,
                                          sx_register_key_t      reg_key,
                                          uint32_t              *ext_point_cnt_p,
                                          sx_extraction_point_t *ext_point_list_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_extraction_point_t *list_p = NULL;

    SX_LOG_ENTER();

    if (__flex_parser_init_done_s == FALSE) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Failed to get extraction point: flex parser module "
                   "uninitialized, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_COUNT)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Failed to get extraction point on register: invalid command (%s), error: [%s]\n",
                   sx_access_cmd_str(cmd), sx_status_str(rc));
        goto out;
    }

    switch (reg_key.type) {
    case SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
        if (rm_resource_global.gp_register_num_max == 0) {
            rc = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Failed to get extraction point on register: GP registers are not supported\n");
            goto out;
        }
        if (reg_key.key.gp_reg.reg_id >= rm_resource_global.gp_register_num_max) {
            SX_LOG_ERR("Failed to get extraction point on register: "
                       "invalid value %d for GP register ID, max valid ID: %d.\n",
                       reg_key.key.gp_reg.reg_id, rm_resource_global.gp_register_num_max - 1);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to set extraction point on register: invalid register type %d\n", reg_key.type);
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_GET) {
        list_p = ext_point_list_p;
    }

    rc = sdk_flex_parser_reg_ext_point_get(reg_key, ext_point_cnt_p, list_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get extraction point on register, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

void flex_parser_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    FILE *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_module_header_print(stream, "SDK FLEX PARSER Module");
    dbg_utils_pprinter_field_print(stream, "Module initialized", &__flex_parser_init_done_s,
                                   PARAM_BOOL_E);
    if (!__flex_parser_init_done_s) {
        goto out;
    }

    sdk_flex_parser_debug_dump(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
}
