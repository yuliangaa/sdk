/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include "hwd_flex_parser.h"
#include "hwd_flex_parser_reg.h"
#include "hwd_flex_parser_db.h"
#include "utils/sx_mem.h"
#include "utils/port_type_validate.h"
#include "ethl2/topo.h"
#include "ethl2/port_db.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "flex_parser/hwi/flex_parser_impl.h"
#include "sx/sdk/sx_status_convertor.h"
#include "complib/cl_byteswap.h"
#include "resource_manager/resource_manager_sdk_table.h"

#undef __MODULE__
#define __MODULE__ FLEX_PARSER

/************************************************
 *  Local definitions
 ***********************************************/
#define FLEX_PARSER_SPC_UDP_TRANS_PH_CNT 1

#define MAX_NEXT_HDR_OFFSET           (16)       /* The maximum value of the location of the next header (in bytes) */
#define MAX_EMPTY_TLV_NEXT_HDR_OFFSET (4)        /* The maximum value of the location of the next header for empty/tlv header (in bytes) */
#define MAX_NEXT_HDR_SIZE             (2)        /* The maximum size of the next header (in bytes)*/
#define MAX_TLV_NEXT_HDR_SIZE         (3)        /* The maximum size of the TLV next header (in bytes)*/
#define MAX_NEXT_HDR_MASK             (0xFFFF)   /* The maximum value of the mask to apply to the next header field */
#define MAX_TLV_NEXT_HDR_MASK         (0xFFFFFF) /* The maximum value of the mask to apply to a TLV next header field */

#define MAX_HDR_LEN_OFFSET (16)         /* The maximum value of the location of the header length (in bytes) */
#define MAX_HDR_LEN_SIZE   (1)          /* The maximum size of the header length (in bytes)*/

#define MAX_HDR_LEN_SHIFT (7)         /* The maximum value of the shift to apply to the header length field */
#define MIN_HDR_LEN_SHIFT (-7)        /* The minimum value of the shift to apply to the header length field */
#define MAX_HDR_LEN_CONST (127)       /* The maximum value of the add to apply to the header length field */
#define MIN_HDR_LEN_CONST (-127)      /* The minimum value of the add to apply to the header length field */

#define DWORD_MASK (0xFFFC)           /* A mask that will be used to determine the next header field does not cross a DWORD */
#define DWORD_SIZE (4)                /* DWORD size in bytes */

#define MAX_TLV_START (252)           /* The maximum value where a TLV should start */

/************************************************
 *  Global variables
 ***********************************************/
flex_parser_hwd_ops_t g_flex_parser_hwd_ops;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static const sx_dev_info_t __leaf_filter = {
    0,     /* dev_id */
    SX_DEV_NODE_TYPE_LEAF,     /* node_type */
    0,                                 /* num_ports */
    SX_CHIP_TYPE_UNKNOWN        /* sdk_chip_ver_t*/
};
/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __validate_parser_header(const sx_flex_parser_header_t *header_p);
static sx_status_t __flex_parser_transition_set_spc(const sx_access_cmd_t             cmd,
                                                    const sx_flex_parser_header_t     from,
                                                    const sx_flex_parser_transition_t to,
                                                    const boolean_t                   validate_only);
static sx_status_t __flex_parser_transition_set_spc2(const sx_access_cmd_t             cmd,
                                                     const sx_flex_parser_header_t     from,
                                                     const sx_flex_parser_transition_t to,
                                                     const boolean_t                   validate_only);
static sx_status_t __flex_parser_transition_get_spc(const sx_flex_parser_header_t curr_ph,
                                                    sx_flex_parser_transition_t  *next_trans_p,
                                                    uint32_t                     *next_trans_cnt_p);
static sx_status_t __flex_parser_deinit_spc();
static sx_status_t __flex_parser_init_spc(const sx_flex_parser_param_t *params_p);
static sx_status_t __flex_parser_deinit_spc2();
static sx_status_t __flex_parser_init_spc2(const sx_flex_parser_param_t *params_p);
static sx_status_t __flex_parser_device_ready_callback_spc(adviser_event_e event_type, void *param);
static sx_status_t __flex_parser_port_handle_swid_callback(adviser_event_e event_type, void *param_p);
static sx_status_t __flex_parser_root_set_spc2(const sx_access_cmd_t                cmd,
                                               const sx_flex_parser_root_sop_cfg_t *root_cfg_list_p,
                                               const uint32_t                       root_cfg_cnt);

/************************************************
 *  Function implementations
 ***********************************************/
static sx_status_t __validate_parser_header(const sx_flex_parser_header_t *header_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    switch (header_p->parser_hdr_type) {
    case SX_FLEX_PARSER_HEADER_FIXED_E:
        if (header_p->hdr_data.parser_hdr_fixed >= SX_FLEX_PARSER_HEADER_LAST) {
            SX_LOG_ERR("Invalid value for fixed parse header [%u].\n", header_p->hdr_data.parser_hdr_fixed);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_FLEX_PARSER_HEADER_FPP_E:
        if (header_p->hdr_data.parser_hdr_fpp >= SX_FLEX_PARSER_HEADER_FPP_LAST) {
            SX_LOG_ERR("Invalid value for flex parse program [%u].\n", header_p->hdr_data.parser_hdr_fpp);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Invalid value for parse header type [%u].\n", header_p->parser_hdr_type);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
        break;
    }

out:
    return rc;
}

static sx_status_t __validate_next_header(const sx_flex_parser_next_header_t *next_header_p,
                                          sx_flex_parser_fpp_type_e           fpp_type)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    int32_t     max_offset = 0;
    int32_t     offset_dword_max = 0;
    uint32_t    max_mask = 0;
    uint32_t    max_size = 0;

    /* The maximum allowed values are determined according the type of the FPP */
    max_offset = (fpp_type != SX_FLEX_PARSER_FPP_TYPE_FPH) ? MAX_EMPTY_TLV_NEXT_HDR_OFFSET : MAX_NEXT_HDR_OFFSET;
    max_mask = (fpp_type == SX_FLEX_PARSER_FPP_TYPE_FTLV) ? MAX_TLV_NEXT_HDR_MASK : MAX_NEXT_HDR_MASK;
    max_size = (fpp_type == SX_FLEX_PARSER_FPP_TYPE_FTLV) ? MAX_TLV_NEXT_HDR_SIZE : MAX_NEXT_HDR_SIZE;

    /* Check that the offset field does not cross a DWORD */
    offset_dword_max = (next_header_p->offset & DWORD_MASK) + DWORD_SIZE;

    if ((next_header_p->offset >= max_offset) ||
        (next_header_p->offset + next_header_p->size > max_offset) ||
        (next_header_p->offset + next_header_p->size > offset_dword_max)) {
        SX_LOG_ERR("Flex parser offset + size of the next header should not exceed %u. Value: %u\n",
                   (max_offset > offset_dword_max) ? max_offset : offset_dword_max,
                   next_header_p->offset + next_header_p->size);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (next_header_p->size > max_size) {
        SX_LOG_ERR("Flex parser size of the next header should not exceed %u. Value: %u. \n",
                   max_size,
                   next_header_p->size);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (next_header_p->mask > max_mask) {
        SX_LOG_ERR("Flex parser mask of the next header should not exceed 0x%X. Value: 0x%X.\n",
                   max_mask,
                   next_header_p->mask);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return rc;
}

static sx_status_t __validate_header_length(const sx_flex_parser_field_value_t *header_length_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if ((header_length_p->offset >= MAX_HDR_LEN_OFFSET) ||
        (header_length_p->offset + header_length_p->size > MAX_HDR_LEN_OFFSET)) {
        SX_LOG_ERR("Flex parser offset + size of the header length should not exceed %u.\n", MAX_HDR_LEN_OFFSET);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (header_length_p->size > MAX_HDR_LEN_SIZE) {
        SX_LOG_ERR("Flex parser size of the header length should not exceed %u. Value: %u.\n",
                   MAX_HDR_LEN_SIZE,
                   header_length_p->size);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (header_length_p->constant < MIN_HDR_LEN_CONST) {
        SX_LOG_ERR("Flex parser constant of the header length should be greater than %d. Value: %d.\n",
                   MIN_HDR_LEN_CONST,
                   header_length_p->constant);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((header_length_p->shift > MAX_HDR_LEN_SHIFT) || (header_length_p->shift < MIN_HDR_LEN_SHIFT)) {
        SX_LOG_ERR("Flex parser shift of the header length should be [%d]-[%d]. Value=[%d]\n",
                   MIN_HDR_LEN_SHIFT,
                   MAX_HDR_LEN_SHIFT,
                   header_length_p->shift);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return rc;
}

static sx_status_t __validate_transition_index(const uint8_t transition_index)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (transition_index >= MAX_HW_FLEX_TRANSITIONS) {
        rc = SX_STATUS_PARAM_ERROR;
    }
    return rc;
}

const char* get_transition_ref_name(char* name_buf, size_t name_size, void *flex_transition_p)
{
    snprintf(name_buf, name_size, "Flex transition %u", *((flex_parser_hw_entry_index_t*)flex_transition_p));
    return name_buf;
}

const char* get_log_port_ref_name(char* name_buf, size_t name_size, void *log_port_p)
{
    snprintf(name_buf, name_size, "Port 0x%08X", *((sx_port_log_id_t*)log_port_p));
    return name_buf;
}

static sx_status_t __flex_parser_device_ready_callback_spc(adviser_event_e event_type, void *param_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    udp_dport_val = 0;

    UNUSED_PARAM(param_p);

    SX_LOG_ENTER();

    if (event_type != ADVISER_EVENT_POST_DEVICE_READY_E) {
        SX_LOG_ERR("Wrong event type - expected event type is ADVISER_EVENT_POST_DEVICE_READY , "
                   "received event type : [%s]\n", ADVISER_EVENT_STR(event_type));
        rc = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    /* update the udp dport in db */
    rc = hwd_flex_parser_db_vxlan_udp_dport_init();
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR(" hwd db init failed [%s].\n", sx_status_str(rc));
        goto out;
    }

    /* read zero device configuration */
    rc = hwd_flex_parser_db_zero_dev_usr_conf_vxlan_udp_dport_value_get(&udp_dport_val);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR(" failed to retrieve zero device conf [%s].\n", sx_status_str(rc));
        goto out;
    }

    /* write the zero device configuration if any to register  and update db*/
    if (udp_dport_val != INVALID_UDP_PORT) {
        rc = hwd_flex_parser_reg_mprs_udp_dport_set(udp_dport_val);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed writing to hardware [%s].\n", sx_status_str(rc));
            goto out;
        }

        hwd_flex_parser_db_vxlan_udp_dport_set(udp_dport_val);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __gp_reg_ext_point_at_device_ready(hwd_flex_parser_gp_reg_ext_point_db_t *entry_p, void *param_p)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sx_dev_id_t         *dev_id_p = (sx_dev_id_t*)param_p;
    sx_gp_register_key_t gp_reg;

    SX_LOG_ENTER();

    SX_MEM_CLR(gp_reg);
    gp_reg.reg_id = entry_p->gp_reg_id;

    rc = hwd_flex_parser_reg_gp_register_ext_point_dev_set(*dev_id_p,
                                                           gp_reg,
                                                           entry_p->ext_points_count,
                                                           entry_p->ext_points_list);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in set extraction point list on GP register %d, dev_id %d, error: [%s]\n",
                   entry_p->gp_reg_id, *dev_id_p, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __fixed_transition_device_ready_callback_spc2(fixed_transition_db_entry_t *fixed_entry_p,
                                                                 void                        *param_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(param_p);

    /* It is assumed that all the fixed transitions are enabled therefore we only disable entries */
    if (fixed_entry_p->enabled == FALSE) {
        rc = hwd_flex_parser_reg_fphtt_set(SX_ACCESS_CMD_UNSET, fixed_entry_p->hw_entry_index);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flex parser failed at setting transition [%s] -> [%s] at device ready, error: [%s]\n",
                       sx_flex_parser_header_fixed_str(fixed_entry_p->from),
                       sx_flex_parser_header_fixed_str(fixed_entry_p->to),
                       sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_transition_device_ready_callback_spc2(flex_transition_db_entry_t *flex_entry_p,
                                                                void                       *param_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    header_db_entry_t *from_header_p = NULL;
    header_db_entry_t *to_header_p = NULL;
    uint16_t           transition_value = 0;

    UNUSED_PARAM(param_p);

    /* Validate the flex header exist and are valid */
    rc = hwd_flex_parser_db_header_get(flex_entry_p->from, &from_header_p);
    if (SX_CHECK_FAIL(rc) || !from_header_p->valid) {
        SX_LOG_ERR("Flex parser from header %s is not valid for setting a device ready transition.\n",
                   get_flex_parser_header_string(&flex_entry_p->from));
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    rc = hwd_flex_parser_db_header_get(flex_entry_p->to, &to_header_p);
    if (SX_CHECK_FAIL(rc) || !to_header_p->valid) {
        SX_LOG_ERR("Flex parser to header %s is not valid for setting a device ready transition.\n",
                   get_flex_parser_header_string(&flex_entry_p->to));
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    transition_value = (uint16_t)flex_entry_p->transition_value;
    if ((from_header_p->hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FPP_E) &&
        (from_header_p->fpp_data.fpp_cfg.protocol_field.size == 1)) {
        /* For an FPP header with next protocol size == 1 we need to reverse
         * the byte order so the match will be correct. */
        transition_value = cl_hton16(transition_value);
    }

    /* Write the flex transition register */
    rc = hwd_flex_parser_reg_fpftt_set(SX_ACCESS_CMD_SET,
                                       flex_entry_p->hw_entry_index,
                                       from_header_p->hw_entry_index,
                                       to_header_p->hw_entry_index,
                                       transition_value,
                                       flex_entry_p->encap_level);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex parser failed at setting transiting [%s] -> [%s] at device ready, error: [%s]\n",
                   get_flex_parser_header_string(&from_header_p->hdr),
                   get_flex_parser_header_string(&to_header_p->hdr),
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_header_device_ready_callback_spc2(header_db_entry_t *header_entry_p, void *param_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   cfg_tlv = (boolean_t)(intptr_t)param_p;

    /* We want to configure the TLV first and then the other FPP types */
    if (((header_entry_p->fpp_data.fpp_cfg.type == SX_FLEX_PARSER_FPP_TYPE_FTLV) && (cfg_tlv == TRUE)) ||
        ((header_entry_p->fpp_data.fpp_cfg.type == SX_FLEX_PARSER_FPP_TYPE_FPH) && (cfg_tlv == FALSE)) ||
        ((header_entry_p->fpp_data.fpp_cfg.type == SX_FLEX_PARSER_FPP_TYPE_FPH_EMPTY) && (cfg_tlv == FALSE))) {
        rc = hwd_flex_parser_reg_fppc_set(header_entry_p->hdr.hdr_data.parser_hdr_fpp,
                                          &header_entry_p->fpp_data.fpp_cfg);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flex parser failed at setting FPP [%u] at device ready, error: [%s]\n",
                       header_entry_p->hdr.hdr_data.parser_hdr_fpp, sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __fixed_header_device_ready_callback_spc2(header_db_entry_t *header_entry_p, void *param_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(param_p);

    /* Configure the TLV for the fixed headers we have in the DB */
    if (header_entry_p->fixed_data.can_have_tlv &&
        (header_entry_p->fixed_data.hph_cfg.ftlv_mode != SX_FLEX_PARSER_TLV_PARSING_DISABLED)) {
        rc = hwd_flex_parser_reg_fphhc_set(header_entry_p->hw_entry_index,
                                           header_entry_p->fixed_data.hph_cfg.ftlv_mode == SX_FLEX_PARSER_TLV_PARSING_ENABLE_OUTER ||
                                           header_entry_p->fixed_data.hph_cfg.ftlv_mode == SX_FLEX_PARSER_TLV_PARSING_ENABLE_OUTER_INNER,
                                           header_entry_p->fixed_data.hph_cfg.ftlv_mode == SX_FLEX_PARSER_TLV_PARSING_ENABLE_INNER ||
                                           header_entry_p->fixed_data.hph_cfg.ftlv_mode == SX_FLEX_PARSER_TLV_PARSING_ENABLE_OUTER_INNER,
                                           header_entry_p->fixed_data.hph_cfg.ftlv_id.fpp_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flex parser failed at setting fixed header [%s] TLV at device ready, error: [%s]\n",
                       sx_flex_parser_header_fixed_str(header_entry_p->hdr.hdr_data.parser_hdr_fixed), sx_status_str(
                           rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_port_root_device_read_callback_spc2(flex_parser_db_port_root_item_t *port_root_entry_p,
                                                              void                            *param_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    header_db_entry_t *to_header = NULL;

    UNUSED_PARAM(param_p);

    rc = hwd_flex_parser_db_flex_header_get(port_root_entry_p->flex_header, &to_header);
    if (SX_CHECK_FAIL(rc) || !to_header->valid) {
        SX_LOG_ERR("Flex parser to header %s is not valid for setting a device ready root.\n",
                   sx_flex_parser_header_fpp_str(port_root_entry_p->flex_header));
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    rc =
        hwd_flex_parser_reg_fpts_set(SX_ACCESS_CMD_SET, FALSE, port_root_entry_p->log_port, to_header->hw_entry_index);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("FPP [%u] cannot be set as root for port [0x%08X], error: [%s]\n",
                   port_root_entry_p->flex_header, port_root_entry_p->log_port, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_device_ready_callback_spc2(adviser_event_e event_type, void *param_p)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_dev_info_t *dev_info_p = (sx_dev_info_t*)(param_p);

    SX_LOG_ENTER();

    rc = __flex_parser_device_ready_callback_spc(event_type, param_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (event_type != ADVISER_EVENT_POST_DEVICE_READY_E) {
        SX_LOG_ERR("Wrong event type - expected event type is ADVISER_EVENT_POST_DEVICE_READY, "
                   "received event type: [%s]\n", ADVISER_EVENT_STR(event_type));
        rc = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    rc = hwd_flex_parser_db_gp_reg_ext_point_foreach(__gp_reg_ext_point_at_device_ready, &dev_info_p->dev_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in set GP register zero device configuration upon device ready, error: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }

    /* Configure the TLV headers first */
    rc = hwd_flex_parser_db_flex_header_foreach(__flex_header_device_ready_callback_spc2, (void*)TRUE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set flex parser TLV upon device ready, error: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }
    /* Configure the rest of the FPP headers */
    rc = hwd_flex_parser_db_flex_header_foreach(__flex_header_device_ready_callback_spc2, (void*)FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set flex parser FPP upon device ready, error: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }
    /* Configure the fixed headers with their TLVs if they exist */
    rc = hwd_flex_parser_db_fixed_header_foreach(__fixed_header_device_ready_callback_spc2, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set fixed headers upon device ready, error: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }
    /* Configure the flex transitions */
    rc = hwd_flex_parser_db_flex_transition_foreach(__flex_transition_device_ready_callback_spc2, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set flex transitions upon device ready, error: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }
    /* Enable/disable the fixed transitions */
    rc = hwd_flex_parser_db_fixed_transition_foreach(__fixed_transition_device_ready_callback_spc2, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set fixed transitions upon device ready, error: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }
    /* Set the port root configuration */
    rc = hwd_flex_parser_db_port_root_foreach(__flex_port_root_device_read_callback_spc2, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set port roots upon device ready, error: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_init_spc(IN const sx_flex_parser_param_t *params_p)
{
    sx_status_t   rc = SX_STATUS_SUCCESS;
    length_t      dev_info_arr_size = SX_DEV_ID_MAX;
    sx_dev_info_t dev_info_arr[SX_DEV_ID_MAX];

    SX_LOG_ENTER();
    UNUSED_PARAM(params_p);

    /* If devices is ready then read the udp dport value */
    rc = topo_device_tbl_bulk_get(SX_ACCESS_CMD_GET, &__leaf_filter, dev_info_arr, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(rc));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* in case of zero device do nothing */
    if (dev_info_arr_size == 0) {
        SX_LOG_DBG("Device not initialized yet\n");
        goto out;
    }

    /* Initialize the vxlan udp dport in hwd db*/
    rc = hwd_flex_parser_db_vxlan_udp_dport_init();
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR(" hwd db init failed [%s].\n", sx_status_str(rc));
        goto out;
    }

    hwd_flex_parser_db_gp_reg_ext_point_init();

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_deinit_spc(boolean_t is_forced)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(is_forced);

    hwd_flex_parser_db_vxlan_udp_dport_set(INVALID_UDP_PORT);
    hwd_flex_parser_db_zero_dev_usr_conf_vxlan_udp_dport_value_set(INVALID_UDP_PORT);
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_parser_init_spc2(IN const sx_flex_parser_param_t *params_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = __flex_parser_init_spc(params_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init legacy flex parser, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    rc = hwd_flex_parser_db_init();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init hwd flex parser DB, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FLEX_PARSER_PROGRAM_E].is_initialized = TRUE;
    rc = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_FLEX_PARSER_PROGRAM_E);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init RM for %s\n", SX_RESOURCE_MSG(RM_SDK_TABLE_TYPE_FLEX_PARSER_PROGRAM_E));
        goto out;
    }

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E].is_initialized = TRUE;
    rc = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init RM for %s\n", SX_RESOURCE_MSG(RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E));
        goto out;
    }

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_PRE_PORT_DEL_FROM_SWID_E,
                                __flex_parser_port_handle_swid_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed flex parser adviser register - advise DEL_PORT_FROM_SWID, error: %s \n",
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_deinit_spc2(boolean_t is_forced)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PRE_PORT_DEL_FROM_SWID_E,
                                __flex_parser_port_handle_swid_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed flex parser adviser delete - advise DEL_PORT_FROM_SWID, error: %s \n", sx_status_str(rc));
    }

    rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E, is_forced);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to de-init RM for %s\n", SX_RESOURCE_MSG(RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E));
        goto out;
    }

    rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_FLEX_PARSER_PROGRAM_E, is_forced);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to de-init RM for %s\n", SX_RESOURCE_MSG(RM_SDK_TABLE_TYPE_FLEX_PARSER_PROGRAM_E));
        goto out;
    }

    rc = hwd_flex_parser_db_gp_reg_ext_point_deinit(is_forced);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deinit flex parser extraction point DB, error: [%s].\n", sx_status_str(rc));
        goto out;
    }
    rc = __flex_parser_deinit_spc(is_forced);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deinit legacy flex parser, error: [%s].\n", sx_status_str(rc));
        goto out;
    }
    rc = hwd_flex_parser_db_deinit(is_forced);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to de-init hwd flex parser DB, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_transition_set_spc(const sx_access_cmd_t             cmd,
                                                    const sx_flex_parser_header_t     from,
                                                    const sx_flex_parser_transition_t to,
                                                    const boolean_t                   validate_only)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    length_t                      dev_info_arr_size = SX_DEV_ID_MAX;
    sx_dev_info_t                 dev_info_arr[SX_DEV_ID_MAX];
    sx_flex_parser_header_type_e  from_parser_hdr_type;
    sx_flex_parser_header_fixed_e from_parser_hdr_fixed;
    sx_flex_parser_header_type_e  to_parser_hdr_type;
    sx_flex_parser_header_fixed_e to_parser_hdr_fixed;
    sx_flex_parser_encap_level_e  to_encap_level;
    uint32_t                      udp_dport = 0;

    UNUSED_PARAM(cmd);

    SX_LOG_ENTER();

    from_parser_hdr_type = from.parser_hdr_type;
    to_parser_hdr_type = to.next_parser_hdr.parser_hdr_type;

    if ((from_parser_hdr_type != SX_FLEX_PARSER_HEADER_FIXED_E) ||
        (to_parser_hdr_type != SX_FLEX_PARSER_HEADER_FIXED_E)) {
        rc = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("params from.parser_hdr_type = [%d], to.parser_hdr_type = [%d] error: [%s] \n",
                   from_parser_hdr_type, to_parser_hdr_type, sx_status_str(rc));
        goto out;
    }

    from_parser_hdr_fixed = from.hdr_data.parser_hdr_fixed;
    to_parser_hdr_fixed = to.next_parser_hdr.hdr_data.parser_hdr_fixed;
    to_encap_level = to.encap_level;

    if ((from_parser_hdr_fixed != SX_FLEX_PARSER_HEADER_UDP_E) ||
        (to_parser_hdr_fixed != SX_FLEX_PARSER_HEADER_VXLAN_E)
        || (to_encap_level != SX_FLEX_PARSER_ENCAP_OUTER_E)) {
        rc = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("params from.parser_hdr_fixed = [%d], to.parser_hdr_fixed = [%d] encap_level = [%d] error: [%s] \n",
                   from_parser_hdr_fixed, to_parser_hdr_fixed, to_encap_level, sx_status_str(rc));
        goto out;
    }

    /* We're done with the validations */
    if (validate_only) {
        goto out;
    }

    /* update zero device configuration variable for future new detected devices */
    hwd_flex_parser_db_zero_dev_usr_conf_vxlan_udp_dport_value_set(to.transition_value);

    rc = hwd_flex_parser_db_vxlan_udp_dport_get(&udp_dport);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to retrieve udp dport from hwd [%s].\n", sx_status_str(rc));
        goto out;
    }

    if (udp_dport == to.transition_value) {
        SX_LOG_DBG("Same transition value set again\n");
        goto out;
    }

    /* if zero device then return */
    rc = topo_device_tbl_bulk_get(SX_ACCESS_CMD_GET, &__leaf_filter, dev_info_arr, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(rc));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* in case of zero device update pre device configuration */
    if (dev_info_arr_size == 0) {
        SX_LOG_DBG("Device not initialized yet\n");
        goto out;
    }

    /* update register value*/
    rc = hwd_flex_parser_reg_mprs_udp_dport_set(to.transition_value);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed writing to hardware [%s].\n", sx_status_str(rc));
        goto out;
    }

    /* update config variable - register shadow */
    hwd_flex_parser_db_vxlan_udp_dport_set(to.transition_value);

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_transition_get_spc(const sx_flex_parser_header_t curr_ph,
                                                    sx_flex_parser_transition_t  *next_trans_p,
                                                    uint32_t                     *next_trans_cnt_p)
{
    sx_flex_parser_header_type_e  curr_parser_hdr_type;
    sx_flex_parser_header_fixed_e curr_parser_hdr_fixed;
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    uint32_t                      req_cnt = 0;
    uint32_t                      udp_dport_val = 0;
    length_t                      dev_info_arr_size = SX_DEV_ID_MAX;
    sx_dev_info_t                 dev_info_arr[SX_DEV_ID_MAX];

    SX_LOG_ENTER();

    curr_parser_hdr_type = curr_ph.parser_hdr_type;
    if (curr_parser_hdr_type != SX_FLEX_PARSER_HEADER_FIXED_E) {
        rc = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("params curr_ph.parser_hdr_type = [%d]  error: [%s] \n",
                   curr_parser_hdr_type, sx_status_str(rc));
        goto out;
    }

    curr_parser_hdr_fixed = curr_ph.hdr_data.parser_hdr_fixed;
    if (curr_parser_hdr_fixed != SX_FLEX_PARSER_HEADER_UDP_E) {
        rc = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("params curr_ph.parser_hdr_fixed = [%d] error: [%s] \n",
                   curr_parser_hdr_fixed,  sx_status_str(rc));
        goto out;
    }

    rc = topo_device_tbl_bulk_get(SX_ACCESS_CMD_GET, &__leaf_filter, dev_info_arr, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(rc));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* in case of zero device set list count to 0 and return*/
    if (dev_info_arr_size == 0) {
        *next_trans_cnt_p = 0;
        SX_LOG_DBG("Device not initialized yet\n");
        goto out;
    }

    req_cnt = *next_trans_cnt_p;
    if ((NULL != next_trans_p) && (req_cnt > 0)) {
        /* Retrieve the udp dport value */
        rc = hwd_flex_parser_db_vxlan_udp_dport_get(&udp_dport_val);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("hwd db vxlan udp dport get failed [%s].\n", sx_status_str(rc));
            goto out;
        }
        next_trans_p[0].transition_value = udp_dport_val;
        next_trans_p[0].encap_level = SX_FLEX_PARSER_ENCAP_OUTER_E;
        next_trans_p[0].next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
        next_trans_p[0].next_parser_hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_VXLAN_E;
    }

    *next_trans_cnt_p = FLEX_PARSER_SPC_UDP_TRANS_PH_CNT;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __hwd_flex_parser_db_to_from_header_validate(const sx_flex_parser_header_t      to_hdr,
                                                                const sx_flex_parser_encap_level_e to_encap_level,
                                                                const header_db_entry_t           *to_header_p,
                                                                const sx_flex_parser_header_t      from_hdr,
                                                                const header_db_entry_t           *from_header_p,
                                                                const uint16_t                     transition_value)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Sometimes fixed headers cannot be set as inner - check it here */
    if ((to_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FIXED_E) &&
        (to_encap_level == SX_FLEX_PARSER_ENCAP_INNER_E) &&
        (to_header_p->fixed_data.can_be_inner == FALSE)) {
        SX_LOG_ERR("Flex parser to header %s is not valid for inner transition.\n",
                   get_flex_parser_header_string(&to_hdr));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    } else if ((to_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FPP_E) &&
               (to_header_p->fpp_data.fpp_cfg.type != SX_FLEX_PARSER_FPP_TYPE_FPH) &&
               (to_header_p->fpp_data.fpp_cfg.type != SX_FLEX_PARSER_FPP_TYPE_FPH_EMPTY)) {
        /* Check that the transition is happening to a correct type */
        SX_LOG_ERR("Flex parser to header %s is not valid for transition.\n",
                   get_flex_parser_header_string(&to_hdr));
        rc = SX_STATUS_ERROR;
        goto out;
    }
    /* Check if the header can be the next header */
    if ((to_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FIXED_E) &&
        (to_header_p->fixed_data.can_be_next_ph == FALSE)) {
        SX_LOG_ERR("Flex parser to header %s is not valid to be a next header.\n",
                   get_flex_parser_header_string(&to_hdr));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    /* Check that the transition value does not exceed the value */
    if ((from_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FIXED_E) &&
        (from_header_p->fixed_data.next_protocol_mask < transition_value)) {
        SX_LOG_ERR("Transition value [%u] for flex parser header %s is too high.\n",
                   transition_value,
                   get_flex_parser_header_string(&from_hdr));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    } else if ((from_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FPP_E) &&
               (from_header_p->fpp_data.fpp_cfg.type != SX_FLEX_PARSER_FPP_TYPE_FPH) &&
               (from_header_p->fpp_data.fpp_cfg.type != SX_FLEX_PARSER_FPP_TYPE_FPH_EMPTY)) {
        /* Check that the transition is happening from a correct type */
        SX_LOG_ERR("Flex parser to header %s is not valid for transition.\n",
                   get_flex_parser_header_string(&from_hdr));
        rc = SX_STATUS_ERROR;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __hwd_flex_parser_db_ref_count_dec_header(flex_transition_db_entry_t *flex_entry_p,
                                                             header_db_entry_t          *from_header_p,
                                                             header_db_entry_t          *old_to_header_p)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    utils_rc = sdk_refcount_dec(&from_header_p->from_refcount, &flex_entry_p->from_reference);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR(
            "Failed update from reference counter for flex transition [%u] from [%u], error: [%s]\n",
            flex_entry_p->hw_entry_index,
            from_header_p->hw_entry_index,
            SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }
    utils_rc = sdk_refcount_dec(&old_to_header_p->to_refcount, &flex_entry_p->to_reference);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR(
            "Failed update to reference counter for flex transition [%u] from [%u], error: [%s]\n",
            flex_entry_p->hw_entry_index,
            from_header_p->hw_entry_index,
            SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __hwd_flex_parser_db_ref_count_inc_header(flex_transition_db_entry_t *flex_entry_p,
                                                             header_db_entry_t          *from_header_p,
                                                             header_db_entry_t          *to_header_p,
                                                             ref_name_data_t            *ref_name_data)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    utils_rc = sdk_refcount_inc(&from_header_p->from_refcount, ref_name_data, &flex_entry_p->from_reference);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR(
            "Failed update from reference counter for flex transition [%u] from [%u] to [%u], error: [%s]\n",
            flex_entry_p->hw_entry_index,
            from_header_p->hw_entry_index,
            to_header_p->hw_entry_index,
            SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }
    utils_rc = sdk_refcount_inc(&to_header_p->to_refcount,  ref_name_data, &flex_entry_p->to_reference);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR(
            "Failed update to reference counter for flex transition [%u] from [%u] to [%u], error: [%s]\n",
            flex_entry_p->hw_entry_index,
            from_header_p->hw_entry_index,
            to_header_p->hw_entry_index,
            SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_parser_flex_transition_set_spc2(const sx_access_cmd_t               cmd,
                                                          sx_flex_parser_transition_index_t  *transition_index_p,
                                                          sx_flex_parser_transition_action_t *transition_cfg_p,
                                                          const boolean_t                     validate_only)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    boolean_t                    transition_rm_updated = FALSE;
    flex_transition_db_entry_t  *flex_entry_p = NULL;
    flex_transition_db_entry_t  *flex_entry_by_from_hdr_p = NULL;
    sx_flex_parser_header_t      dummy_from;
    uint32_t                     dummy_transition_value = 0;
    uint32_t                     transition_value = 0;
    sx_flex_parser_encap_level_e to_encap_level = SX_FLEX_PARSER_ENCAP_LAST_E;
    sx_access_cmd_t              hw_cmd;
    header_db_entry_t           *from_header_p = NULL;
    header_db_entry_t           *to_header_p = NULL;
    header_db_entry_t           *old_to_header_p = NULL;
    ref_name_data_t              ref_name_data = {.print_func_p = get_transition_ref_name,
                                                  .ref_data_p = NULL,
                                                  .data_size = sizeof(flex_parser_hw_entry_index_t)};


    if (SX_CHECK_FAIL(rc = __validate_transition_index(transition_index_p->flex_trans_index))) {
        SX_LOG_ERR("Invalid transition index %u for flex parser transition.\n", transition_index_p->flex_trans_index);
        goto out;
    }

    dummy_from.parser_hdr_type = SX_FLEX_PARSER_HEADER_LAST_E;

    if (cmd == SX_ACCESS_CMD_CREATE) {
        /*CREATE - SDK will validate that the requested transition_index resource is free and will mark the resource as busy.*/
        /* Allocate the transition from the resource manager */
        rc = rm_entries_set(RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E, SX_ACCESS_CMD_ADD, 1, NULL);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_RESOURCE_COND(rc,
                                     "No resources to create transition index %u, status = [%s].\n",
                                     transition_index_p->flex_trans_index,  sx_status_str(rc));
            goto out;
        }

        transition_rm_updated = TRUE;
        /* Allocate a new entry */
        rc = hwd_flex_parser_db_flex_transition_allocate(dummy_from,
                                                         dummy_transition_value,
                                                         transition_index_p->flex_trans_index,
                                                         TRUE,
                                                         &flex_entry_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed allocating flex transition index %u, status = [%s].\n",
                       transition_index_p->flex_trans_index, sx_status_str(rc));
            goto flex_write_fail;
        }
        /* We don't need to update the HW*/
        goto out;
    }

    /*unset/set/destroy use the exist flex entry. we find it by the transition index. */
    rc = hwd_flex_parser_db_flex_transition_index_get(transition_index_p->flex_trans_index, &flex_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get flex entry for flex transition index %u, status = [%s].\n",
                   transition_index_p->flex_trans_index, sx_status_str(rc));
        goto out;
    }

    if (flex_entry_p->valid == FALSE) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to set flex entry for flex transition index %u, entry is free. status = [%s].\n",
                   transition_index_p->flex_trans_index, sx_status_str(rc));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        if (transition_cfg_p == NULL) {
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }
        if ((transition_cfg_p->from_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FIXED_E) &&
            (transition_cfg_p->to_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FIXED_E)) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Failed to set fixed transition headers from %s to %s (value=%u) status = [%s]. "
                       "One or two of the headers must be flex. To set both fixed headers, use sx_api_flex_parser_transition_set()\n",
                       get_flex_parser_header_string(&transition_cfg_p->from_hdr),
                       get_flex_parser_header_string(&transition_cfg_p->to_hdr),
                       transition_cfg_p->transition_value,
                       sx_status_str(rc));
            goto out;
        }

        rc = hwd_flex_parser_db_header_get(transition_cfg_p->from_hdr, &from_header_p);
        if (SX_CHECK_FAIL(rc) || !from_header_p->valid) {
            SX_LOG_ERR("Flex parser from header %s is not valid for setting a transition.\n",
                       get_flex_parser_header_string(&transition_cfg_p->from_hdr));
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
        rc = hwd_flex_parser_db_header_get(transition_cfg_p->to_hdr, &to_header_p);
        if (SX_CHECK_FAIL(rc) || !to_header_p->valid) {
            SX_LOG_ERR("Flex parser to header %s is not valid for setting a transition.\n",
                       get_flex_parser_header_string(&transition_cfg_p->to_hdr));
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        rc = __hwd_flex_parser_db_to_from_header_validate(transition_cfg_p->to_hdr,
                                                          transition_cfg_p->to_encap_level,
                                                          to_header_p,
                                                          transition_cfg_p->from_hdr,
                                                          from_header_p,
                                                          transition_cfg_p->transition_value);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flex parser to header %s or from header %s is not valid for setting a transition.\n",
                       get_flex_parser_header_string(&transition_cfg_p->to_hdr),
                       get_flex_parser_header_string(&transition_cfg_p->from_hdr));
            goto out;
        }
        /* Check if this is an enabled entry*/
        if (flex_entry_p->in_use == TRUE) {
            /* On-the-fly changed allowed only for field to_hdr*/
            if ((hwd_flex_parser_db_flex_transition_get(transition_cfg_p->from_hdr, transition_cfg_p->transition_value,
                                                        &flex_entry_by_from_hdr_p)
                 == SX_STATUS_ENTRY_NOT_FOUND) || (flex_entry_by_from_hdr_p != flex_entry_p)) {
                rc = SX_STATUS_ERROR;
                SX_LOG_ERR(
                    "Failed to edit flex entry for flex transition index %u, on-the-fly changes allowed only for the to_hdr. status = [%s].\n",
                    transition_index_p->flex_trans_index,
                    sx_status_str(rc));
                goto out;
            }
            /* Get the old to header we need to decrease reference to */
            rc = hwd_flex_parser_db_header_get(flex_entry_p->to, &old_to_header_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get header %s in the transition.\n",
                           get_flex_parser_header_string(&flex_entry_p->to));
                goto out;
            }
        }
        transition_value = (uint16_t)transition_cfg_p->transition_value;
        if ((transition_cfg_p->from_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FPP_E) &&
            (from_header_p->fpp_data.fpp_cfg.protocol_field.size == 1)) {
            /* For an FPP header with next protocol size == 1 we need to reverse
             * the byte order so the match will be correct.
             */
            transition_value = cl_hton16(transition_value);
        }
        hw_cmd = SX_ACCESS_CMD_SET;
        to_encap_level = transition_cfg_p->to_encap_level;
    }

    if (cmd == SX_ACCESS_CMD_UNSET) {
        /* unset (Remove/disable) the flex transition in HW but do not free the transition_index resource*/
        if (flex_entry_p->in_use == FALSE) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR(
                "Failed to unset flex entry for flex transition index %u, entry is not in use by HW. status = [%s].\n",
                transition_index_p->flex_trans_index,
                sx_status_str(rc));
            goto out;
        }
    }
    /* We're done with the validations */
    if (validate_only) {
        goto out;
    }
    /*this need to do only for set with in_use = 1 or unset or destroy(with in_use = 1)*/
    if (((cmd == SX_ACCESS_CMD_SET) || (cmd == SX_ACCESS_CMD_UNSET) || (cmd == SX_ACCESS_CMD_DESTROY)) &&
        (flex_entry_p->in_use == TRUE)) {
        /* We'll reduce the references here which is good both for unset operation and overwrite operation.
         */
        if ((cmd == SX_ACCESS_CMD_UNSET) || (cmd == SX_ACCESS_CMD_DESTROY)) {
            /* Validate the flex headers exist and valid */
            rc = hwd_flex_parser_db_header_get(flex_entry_p->from, &from_header_p);
            if (SX_CHECK_FAIL(rc) || !from_header_p->valid) {
                SX_LOG_ERR("Flex parser from header %s is not valid for setting a transition.\n",
                           get_flex_parser_header_string(&flex_entry_p->from));
                rc = SX_STATUS_ENTRY_NOT_FOUND;
                goto out;
            }
            rc = hwd_flex_parser_db_header_get(flex_entry_p->to, &to_header_p);
            if (SX_CHECK_FAIL(rc) || !to_header_p->valid) {
                SX_LOG_ERR("Flex parser to header %s is not valid for setting a transition.\n",
                           get_flex_parser_header_string(&flex_entry_p->to));
                rc = SX_STATUS_ENTRY_NOT_FOUND;
                goto out;
            }
            rc = hwd_flex_parser_db_header_get(flex_entry_p->to, &old_to_header_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get header %s in the transition.\n",
                           get_flex_parser_header_string(&flex_entry_p->to));
                goto out;
            }
            transition_value = 0;
            hw_cmd = SX_ACCESS_CMD_UNSET;
        }
        rc = __hwd_flex_parser_db_ref_count_dec_header(flex_entry_p,
                                                       from_header_p,
                                                       old_to_header_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed update to reference counter, error: [%s]\n",
                       sx_status_str(rc));
            goto out;
        }
    }
    if ((((cmd == SX_ACCESS_CMD_DESTROY) || (cmd == SX_ACCESS_CMD_UNSET)) &&
         (flex_entry_p->in_use == TRUE)) || (cmd == SX_ACCESS_CMD_SET)) {
        rc = hwd_flex_parser_reg_fpftt_set(hw_cmd, flex_entry_p->hw_entry_index, from_header_p->hw_entry_index,
                                           to_header_p->hw_entry_index, transition_value,
                                           to_encap_level);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to %s flex transition header %s (value=%u) for transition index %u status = [%s] .\n",
                       sx_access_cmd_str(cmd),
                       get_flex_parser_header_string(&flex_entry_p->from),
                       transition_value,
                       transition_index_p->flex_trans_index,
                       sx_status_str(rc));
            goto out;
        }
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        /* Update the non key elements of the entry */
        flex_entry_p->from = transition_cfg_p->from_hdr;
        flex_entry_p->to = transition_cfg_p->to_hdr;
        flex_entry_p->transition_value = transition_cfg_p->transition_value;
        flex_entry_p->encap_level = transition_cfg_p->to_encap_level;
        /* Increase the reference to the headers now pointed by the transition */
        ref_name_data.ref_data_p = &flex_entry_p->hw_entry_index;
        rc = __hwd_flex_parser_db_ref_count_inc_header(flex_entry_p, from_header_p, to_header_p, &ref_name_data);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR(
                "Failed update from reference counter for flex transition [%u], error: [%s]\n",
                flex_entry_p->hw_entry_index,
                sx_status_str(rc));
            goto out;
        }
        flex_entry_p->in_use = TRUE;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_DESTROY) {
        /* DESTROY - SDK will mark the resource as free and will remove the transition from HW.*/
        /* in case we are doing destroy right after create, we don't need to decrease the reference*/
        rc = hwd_flex_parser_db_flex_transition_deallocate(dummy_from,
                                                           dummy_transition_value,
                                                           transition_index_p->flex_trans_index,
                                                           TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed deallocating flex transition index %u, status = [%s].\n",
                       transition_index_p->flex_trans_index, sx_status_str(rc));
            goto out;
        }

        rc = rm_entries_set(RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E, SX_ACCESS_CMD_DELETE, 1, NULL);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_RESOURCE_COND(rc,
                                     "Failed to delete resources for transition index %u, status = [%s].\n",
                                     transition_index_p->flex_trans_index,  sx_status_str(rc));
            goto out;
        }
    }
    if (cmd == SX_ACCESS_CMD_UNSET) {
        /* unset (Remove/disable) the flex transition in HW but do not free the transition_index resource*/
        flex_entry_p->in_use = FALSE;
    }

flex_write_fail:
    if (transition_rm_updated) {
        rm_entries_set(RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E, SX_ACCESS_CMD_DELETE, 1, NULL);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_flex_transition_get_spc2(sx_flex_parser_transition_index_t   transition_index,
                                                          sx_flex_parser_transition_action_t *transition_cfg_p)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    flex_transition_db_entry_t *flex_entry_p = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(transition_cfg_p, "transition_cfg_p"))) {
        goto out;
    }

    /* Check that the requested transition index is valid. Important since the db assumes this is valid. */
    if (SX_CHECK_FAIL(rc = __validate_transition_index(transition_index.flex_trans_index))) {
        SX_LOG_ERR("Invalid transition index for flex parser transition.\n");
        goto out;
    }
    /* Retrieve the transition information from the db */
    rc = hwd_flex_parser_db_flex_transition_index_get(transition_index.flex_trans_index, &flex_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get flex entry for flex transition index %u, status = [%s].\n",
                   transition_index.flex_trans_index, sx_status_str(rc));
        goto out;
    }
    if ((flex_entry_p->valid == FALSE) || (flex_entry_p->in_use == FALSE)) {
        transition_cfg_p->transition_en = FALSE;
        goto out;
    }

    transition_cfg_p->transition_en = TRUE;
    transition_cfg_p->from_hdr = flex_entry_p->from;
    transition_cfg_p->to_hdr = flex_entry_p->to;
    transition_cfg_p->to_encap_level = flex_entry_p->encap_level;
    transition_cfg_p->transition_value = flex_entry_p->transition_value;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_transition_set_spc2(const sx_access_cmd_t             cmd,
                                                     const sx_flex_parser_header_t     from,
                                                     const sx_flex_parser_transition_t to,
                                                     const boolean_t                   validate_only)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    fixed_transition_db_entry_t *fixed_entry_p = NULL;
    flex_transition_db_entry_t  *flex_entry_p = NULL;
    header_db_entry_t           *from_header_p = NULL;
    header_db_entry_t           *to_header_p = NULL;
    header_db_entry_t           *old_to_header_p = NULL;
    boolean_t                    flex_allocated = FALSE;
    boolean_t                    transition_rm_updated = FALSE;
    uint16_t                     transition_value = 0;
    ref_name_data_t              ref_name_data = {.print_func_p = get_transition_ref_name,
                                                  .ref_data_p = NULL,
                                                  .data_size = sizeof(flex_parser_hw_entry_index_t)};

    SX_LOG_ENTER();

    /* Check that the requested header is valid. Important since the db assumes this is valid. */
    if (SX_CHECK_FAIL(rc = __validate_parser_header(&from))) {
        SX_LOG_ERR("Invalid from header for flex parser transition set.\n");
        goto out;
    }

    if (SX_CHECK_FAIL(rc = __validate_parser_header(&to.next_parser_hdr))) {
        SX_LOG_ERR("Invalid to header for flex parser transition set.\n");
        goto out;
    }
    /* Check that the encapsulation is valid */
    if (to.encap_level >= SX_FLEX_PARSER_ENCAP_LAST_E) {
        SX_LOG_ERR("Invalid encapsulation level for flex parser transition [%d].\n", to.encap_level);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    /* Check that the encapsulation is valid */
    if (to.encap_level >= SX_FLEX_PARSER_ENCAP_LAST_E) {
        SX_LOG_ERR("Invalid encapsulation level for flex parser transition [%d].\n", to.encap_level);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* If both headers are fixed check if this is an already existing one or not */
    if ((from.parser_hdr_type == SX_FLEX_PARSER_HEADER_FIXED_E) &&
        (to.next_parser_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FIXED_E)) {
        /* Check that the current encapsulation is valid */
        if (to.current_encap >= SX_FLEX_PARSER_ENCAP_LAST_E) {
            SX_LOG_ERR("Invalid current encapsulation level for flex parser transition [%d].\n", to.current_encap);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        rc = hwd_flex_parser_db_fixed_transition_get(from.hdr_data.parser_hdr_fixed,
                                                     to.next_parser_hdr.hdr_data.parser_hdr_fixed,
                                                     to.current_encap,
                                                     to.transition_value,
                                                     &fixed_entry_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Setting flex parser transition from %s to %s in not supported.\n",
                       sx_flex_parser_header_fixed_str(from.hdr_data.parser_hdr_fixed),
                       sx_flex_parser_header_fixed_str(to.next_parser_hdr.hdr_data.parser_hdr_fixed));
            rc = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        /* This is a unique case we're handling as a backward compatible case with SPC1 (via mprs register)*/
        if ((from.hdr_data.parser_hdr_fixed == SX_FLEX_PARSER_HEADER_UDP_E) &&
            (to.next_parser_hdr.hdr_data.parser_hdr_fixed == SX_FLEX_PARSER_HEADER_VXLAN_E) &&
            (to.encap_level == SX_FLEX_PARSER_ENCAP_OUTER_E)) {
            rc = __flex_parser_transition_set_spc(cmd, from, to, validate_only);
            if (SX_CHECK_FAIL(rc)) {
                goto out;
            }
            /* We're done with the validations */
            if (validate_only) {
                goto out;
            }
            /* Update the database just to be consistent */
            fixed_entry_p->transition_value = to.transition_value;
            goto out;
        }
        /* We're done with the validations */
        if (validate_only) {
            goto out;
        }
        /* Set the transition in the FPHTT register */
        rc = hwd_flex_parser_reg_fphtt_set(cmd, fixed_entry_p->hw_entry_index);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed setting fixed transition from %s to %s with transition value %u.\n",
                       sx_flex_parser_header_fixed_str(from.hdr_data.parser_hdr_fixed),
                       sx_flex_parser_header_fixed_str(to.next_parser_hdr.hdr_data.parser_hdr_fixed),
                       to.transition_value);
            goto out;
        }
        /* Set the change in the DB entry */
        fixed_entry_p->enabled = (cmd == SX_ACCESS_CMD_UNSET) ? FALSE : TRUE;
    } else { /* This is a flex transition */
        /* Validate the flex header exist and are valid */
        rc = hwd_flex_parser_db_header_get(from, &from_header_p);
        if (SX_CHECK_FAIL(rc) || !from_header_p->valid) {
            SX_LOG_ERR("Flex parser from header %s is not valid for setting a transition.\n",
                       get_flex_parser_header_string(&from));
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
        rc = hwd_flex_parser_db_header_get(to.next_parser_hdr, &to_header_p);
        if (SX_CHECK_FAIL(rc) || !to_header_p->valid) {
            SX_LOG_ERR("Flex parser to header %s is not valid for setting a transition.\n",
                       get_flex_parser_header_string(&to.next_parser_hdr));
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
        /* Do some more validations here */
        if (cmd == SX_ACCESS_CMD_SET) {
            rc = __hwd_flex_parser_db_to_from_header_validate(to.next_parser_hdr,
                                                              to.encap_level,
                                                              to_header_p,
                                                              from,
                                                              from_header_p,
                                                              to.transition_value);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Flex parser to header %s or from header %s is not valid for setting a transition.\n",
                           get_flex_parser_header_string(&to.next_parser_hdr), get_flex_parser_header_string(&from));
                goto out;
            }
        }

        /* Check if this transition already exists - the from & transition value are the keys to the lookup*/
        rc = hwd_flex_parser_db_flex_transition_get(from, to.transition_value, &flex_entry_p);
        /* If such a transition doesn't exist */
        if (rc != SX_STATUS_SUCCESS) {
            /* We're trying to unset a non existing transition */
            if (cmd == SX_ACCESS_CMD_UNSET) {
                SX_LOG_ERR("Flex parser transition from header %s (value=%u) doesn't exist and cannot be removed.\n",
                           get_flex_parser_header_string(&from), to.transition_value);
                rc = SX_STATUS_ENTRY_NOT_FOUND;
                goto out;
            }
            /* We're done with the validations */
            if (validate_only) {
                rc = SX_STATUS_SUCCESS;
                goto out;
            }
            /* Allocate the transition from the resource manager */
            rc = rm_entries_set(RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E, SX_ACCESS_CMD_ADD, 1, NULL);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR_RESOURCE_COND(rc,
                                         "No resources to create transition from header %s (value=%u)",
                                         get_flex_parser_header_string(&from),
                                         to.transition_value);
                goto out;
            }
            transition_rm_updated = TRUE;
            /* Allocate a new entry */
            /* SDK will choose the next available entry*/
            rc =
                hwd_flex_parser_db_flex_transition_allocate(from, to.transition_value, 0, FALSE,
                                                            &flex_entry_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed allocating flex transition header %s (value=%u) status = [%s].\n",
                           get_flex_parser_header_string(&from), to.transition_value, sx_status_str(rc));
                goto flex_write_fail;
            }
            flex_allocated = TRUE;
        } else {
            /* If such a transition already exists we'll overwrite it.
             * We'll reduce the references here which is good both for unset operation and overwrite operation.
             */
            /* Get the old to header we need to decrease reference to */
            rc = hwd_flex_parser_db_header_get(flex_entry_p->to, &old_to_header_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get header %s in the transition.\n",
                           get_flex_parser_header_string(&flex_entry_p->to));
                goto out;
            }
            /* We're done with the validations */
            if (validate_only) {
                goto out;
            }
            rc = __hwd_flex_parser_db_ref_count_dec_header(flex_entry_p, from_header_p, old_to_header_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR(
                    "Failed to update reference counter for flex transition [%u], error: [%s]\n",
                    flex_entry_p->hw_entry_index,
                    sx_status_str(rc));
                goto flex_write_fail;
            }
        }

        /* We're done with the validations */
        /* coverity[dead_error_condition] */
        if (validate_only) {
            /* coverity[dead_error_line] */
            goto out;
        }

        transition_value = (uint16_t)to.transition_value;
        if ((from.parser_hdr_type == SX_FLEX_PARSER_HEADER_FPP_E) &&
            (from_header_p->fpp_data.fpp_cfg.protocol_field.size == 1)) {
            /* For an FPP header with next protocol size == 1 we need to reverse
             * the byte order so the match will be correct.
             */
            transition_value = cl_hton16(transition_value);
        }

        /* We'll update the HW anyway we don't care what was the previous entry */
        rc = hwd_flex_parser_reg_fpftt_set(cmd, flex_entry_p->hw_entry_index, from_header_p->hw_entry_index,
                                           to_header_p->hw_entry_index, transition_value,
                                           to.encap_level);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to %s flex transition header %s (value=%u) status = [%s] .\n",
                       sx_access_cmd_str(cmd),
                       get_flex_parser_header_string(&from),
                       to.transition_value,
                       sx_status_str(rc));
            goto flex_write_fail;
        }
        if (cmd == SX_ACCESS_CMD_UNSET) {
            rc = rm_entries_set(RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E, SX_ACCESS_CMD_DELETE, 1, NULL);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR_RESOURCE_COND(rc,
                                         "Failed resource deallocating transition from header %s (value=%u)",
                                         get_flex_parser_header_string(&from),
                                         to.transition_value);
                goto out;
            }
            rc = hwd_flex_parser_db_flex_transition_deallocate(from, to.transition_value, 0, FALSE);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed deallocating flex transition header %s (value=%u) status = [%s] .\n",
                           get_flex_parser_header_string(&from), to.transition_value, sx_status_str(rc));
                goto out;
            }
        } else {
            /* Update the non key elements of the entry */
            flex_entry_p->to = to.next_parser_hdr;
            flex_entry_p->transition_value = to.transition_value;
            flex_entry_p->encap_level = to.encap_level;
            /* Increase the reference to the headers now pointed by the transition */
            ref_name_data.ref_data_p = &flex_entry_p->hw_entry_index;
            rc = __hwd_flex_parser_db_ref_count_inc_header(flex_entry_p, from_header_p, to_header_p, &ref_name_data);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR(
                    "Failed to update reference counter for flex transition [%u], error: [%s]\n",
                    flex_entry_p->hw_entry_index,
                    sx_status_str(rc));
                goto flex_write_fail;
            }
        }
    }

    goto out;

flex_write_fail:
    if (transition_rm_updated) {
        rm_entries_set(RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E, SX_ACCESS_CMD_DELETE, 1, NULL);
    }
    if (flex_allocated) {
        hwd_flex_parser_db_flex_transition_deallocate(from, to.transition_value, 0, FALSE);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_transition_get_spc2(const sx_flex_parser_header_t curr_ph,
                                                     sx_flex_parser_transition_t  *next_trans_p,
                                                     uint32_t                     *next_trans_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(next_trans_cnt_p, "next_trans_cnt_p"))) {
        goto out;
    }
    /* If we need to return some values we need the next pointer to be valid */
    if ((*next_trans_cnt_p != 0) && (next_trans_p == NULL)) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hwd transition get invalid array_p [%s].\n", sx_status_str(rc));
        goto out;
    }

    /* Check that the requested header is valid. Important since the db assumes this is valid. */
    if (SX_CHECK_FAIL(rc = __validate_parser_header(&curr_ph))) {
        SX_LOG_ERR("Invalid header for flex parser transition get.\n");
        goto out;
    }

    /* Retrieve the transition information from the db */
    if (SX_CHECK_FAIL(rc = hwd_flex_parser_db_transitions_get(curr_ph, next_trans_p, next_trans_cnt_p))) {
        SX_LOG_ERR("Failed to get transition information from db.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* Callback used to enable/disable all fixed transactions */
static sx_status_t __fixed_transition_set_all_cb(fixed_transition_db_entry_t *fixed_entry_p, void *param_p)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_flex_parser_header_t     hdr;
    sx_flex_parser_transition_t transition;
    sx_access_cmd_t             set_cmd = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(hdr);
    SX_MEM_CLR(transition);

    set_cmd = (sx_access_cmd_t)param_p;

    hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;

    /* Enable/disable fixed transaction if they exist */
    if ((fixed_entry_p->enabled &&
         (set_cmd == SX_ACCESS_CMD_UNSET)) || (!fixed_entry_p->enabled && (set_cmd == SX_ACCESS_CMD_SET))) {
        /* Use the regular transition function to disable the transition */
        hdr.hdr_data.parser_hdr_fixed = fixed_entry_p->from;
        transition.current_encap = fixed_entry_p->curr_encap_level;
        transition.transition_value = fixed_entry_p->transition_value;
        transition.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
        transition.next_parser_hdr.hdr_data.parser_hdr_fixed = fixed_entry_p->to;
        rc = __flex_parser_transition_set_spc2(set_cmd, hdr, transition, FALSE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Disabling fixed parser transition from %s to %s failed.\n",
                       sx_flex_parser_header_fixed_str(fixed_entry_p->from),
                       sx_flex_parser_header_fixed_str(fixed_entry_p->to));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* Callback used to enable/disable all fixed transactions */
static sx_status_t __flex_transition_set_all_cb(flex_transition_db_entry_t *flex_entry_p, void *param_p)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_flex_parser_header_t     hdr;
    sx_flex_parser_transition_t transition;

    SX_LOG_ENTER();

    UNUSED_PARAM(param_p);

    SX_MEM_CLR(hdr);
    SX_MEM_CLR(transition);

    /* Use the regular transition function to disable the transition */
    hdr = flex_entry_p->from;
    transition.transition_value = flex_entry_p->transition_value;
    transition.next_parser_hdr = flex_entry_p->to;
    rc = __flex_parser_transition_set_spc2(SX_ACCESS_CMD_UNSET, hdr, transition, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Disabling flex parser transition from %s to %s failed.\n",
                   get_flex_parser_header_string(&hdr),
                   get_flex_parser_header_string(&transition.next_parser_hdr));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t __flex_parser_transition_set_all_spc2(const sx_access_cmd_t              cmd,
                                                  const sx_flex_parser_header_type_e hdr_type)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t set_cmd = 0;

    SX_LOG_ENTER();

    set_cmd = (cmd == SX_ACCESS_CMD_SET_ALL) ? SX_ACCESS_CMD_SET : SX_ACCESS_CMD_UNSET;
    switch (hdr_type) {
    case SX_FLEX_PARSER_HEADER_FIXED_E:
        /* For the fixed header we support both set all and delete all */
        rc = hwd_flex_parser_db_fixed_transition_foreach(__fixed_transition_set_all_cb, (void*)set_cmd);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Disabling all fixed transitions failed.\n");
            goto out;
        }
        break;

    case SX_FLEX_PARSER_HEADER_FPP_E:
        rc = hwd_flex_parser_db_flex_transition_foreach(__flex_transition_set_all_cb, (void*)set_cmd);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Disabling all flex transitions failed.\n");
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Flex parser unknown type [%u] for transition set all.\n", hdr_type);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
        break;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* This is a utility function to increase TLV/FEXP references used by this fpp */
static sx_status_t __increase_fpp_references(header_db_entry_t *fpp_entry_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_utils_status_t  utils_rc = SX_UTILS_STATUS_SUCCESS;
    header_db_entry_t *tlv_flex_entry_p = NULL;
    ref_name_data_t    ref_name_data = {.print_func_p = get_flex_header_ref_name,
                                        .ref_data_p = &fpp_entry_p->hdr.hdr_data.parser_hdr_fpp,
                                        .data_size = sizeof(sx_flex_parser_header_fpp_e)};

    SX_LOG_ENTER();

    /* If we have TLV we need to remove the reference to it */
    if (fpp_entry_p->fpp_data.fpp_cfg.my_tlv.enable) {
        rc = hwd_flex_parser_db_flex_header_get(fpp_entry_p->fpp_data.fpp_cfg.my_tlv.fpp_id.fpp_id, &tlv_flex_entry_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed retrieving TLV [%u] from DB.\n", fpp_entry_p->fpp_data.fpp_cfg.my_tlv.fpp_id.fpp_id);
            goto out;
        }
        /* If we set a TLV we need to set a reference to it */
        utils_rc = sdk_refcount_inc(&tlv_flex_entry_p->to_refcount, &ref_name_data, &fpp_entry_p->tlv_reference);
        if (SX_UTILS_CHECK_FAIL(utils_rc)) {
            SX_LOG_ERR("Failed increasing reference to TLV [%u] from header [%u], error: [%s]\n",
                       fpp_entry_p->fpp_data.fpp_cfg.my_tlv.fpp_id.fpp_id,
                       fpp_entry_p->hdr.hdr_data.parser_hdr_fpp,
                       SX_UTILS_STATUS_MSG(utils_rc));
            rc = sx_utils_status_to_sx_status(utils_rc);
            goto out;
        }
    }
    /* If the FPH uses extraction point remove the reference to them */
    if (fpp_entry_p->fpp_data.fpp_cfg.fexp_start.enable) {
        rc = hwd_flex_parser_db_fexp_ref_inc(fpp_entry_p->fpp_data.fpp_cfg.fexp_start.fexp_id.fexp_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed increasing reference for FEXP start [%u].\n",
                       fpp_entry_p->fpp_data.fpp_cfg.fexp_start.fexp_id.fexp_id);
            goto out;
        }
    }
    if (fpp_entry_p->fpp_data.fpp_cfg.fexp_offset.enable) {
        rc = hwd_flex_parser_db_fexp_ref_inc(fpp_entry_p->fpp_data.fpp_cfg.fexp_offset.fexp_id.fexp_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed increasing reference for FEXP offset [%u].\n",
                       fpp_entry_p->fpp_data.fpp_cfg.fexp_offset.fexp_id.fexp_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* This is a utility function to decrease TLV/FEXP references used by this fpp */
static sx_status_t __decrease_fpp_references(const header_db_entry_t *fpp_entry_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_utils_status_t  utils_rc = SX_UTILS_STATUS_SUCCESS;
    header_db_entry_t *tlv_flex_entry_p = NULL;

    SX_LOG_ENTER();

    /* If we have TLV we need to remove the reference to it */
    if (fpp_entry_p->fpp_data.fpp_cfg.my_tlv.enable) {
        rc = hwd_flex_parser_db_flex_header_get(fpp_entry_p->fpp_data.fpp_cfg.my_tlv.fpp_id.fpp_id, &tlv_flex_entry_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed retrieving TLV [%u] from DB.\n", fpp_entry_p->fpp_data.fpp_cfg.my_tlv.fpp_id.fpp_id);
            goto out;
        }
        utils_rc = sdk_refcount_dec(&tlv_flex_entry_p->to_refcount, &fpp_entry_p->tlv_reference);
        if (SX_UTILS_CHECK_FAIL(utils_rc)) {
            SX_LOG_ERR("Failed decreasing reference to TLV [%u] for header [%u], error: [%s]\n",
                       fpp_entry_p->fpp_data.fpp_cfg.my_tlv.fpp_id.fpp_id,
                       fpp_entry_p->hdr.hdr_data.parser_hdr_fpp,
                       SX_UTILS_STATUS_MSG(utils_rc));
            rc = sx_utils_status_to_sx_status(utils_rc);
            goto out;
        }
    }
    /* If the FPH uses extraction point remove the reference to them */
    if (fpp_entry_p->fpp_data.fpp_cfg.fexp_start.enable) {
        rc = hwd_flex_parser_db_fexp_ref_dec(fpp_entry_p->fpp_data.fpp_cfg.fexp_start.fexp_id.fexp_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed decreasing reference for FEXP start [%u].\n",
                       fpp_entry_p->fpp_data.fpp_cfg.fexp_start.fexp_id.fexp_id);
            goto out;
        }
    }
    if (fpp_entry_p->fpp_data.fpp_cfg.fexp_offset.enable) {
        rc = hwd_flex_parser_db_fexp_ref_dec(fpp_entry_p->fpp_data.fpp_cfg.fexp_offset.fexp_id.fexp_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed decreasing reference for FEXP offset [%u].\n",
                       fpp_entry_p->fpp_data.fpp_cfg.fexp_offset.fexp_id.fexp_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* This is a utility function to validate the configuration provided by the user */
static sx_status_t __validate_fpp_config(const sx_flex_parser_header_fpp_e fpp,
                                         const sx_flex_parser_fpp_t       *fpp_cfg_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    header_db_entry_t *tlv_flex_entry_p = NULL;
    fexp_db_entry_t   *fexp_start_db_entry_p = NULL, *fexp_offset_db_entry_p = NULL;

    SX_LOG_ENTER();
    /* Now validate the main program of the header */
    /* Validate the next header field */
    rc = __validate_next_header(&fpp_cfg_p->protocol_field, fpp_cfg_p->type);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Flex header is trying configure FPH [%u] with invalid next header.\n", fpp);
        goto out;
    }
    /* If this is not an empty header validate header length*/
    if (fpp_cfg_p->type != SX_FLEX_PARSER_FPP_TYPE_FPH_EMPTY) {
        /* Validate the header length field */
        rc = __validate_header_length(&fpp_cfg_p->hdr_len_field);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flex header [%u] is trying configure invalid header length.\n", fpp);
            goto out;
        }
    }
    /* Check if a TLV is configured to a TLV itself or an empty header */
    if ((fpp_cfg_p->type != SX_FLEX_PARSER_FPP_TYPE_FPH) && fpp_cfg_p->my_tlv.enable) {
        SX_LOG_ERR("FPP [%u] is TLV/empty and cannot be configured with TLV.\n", fpp);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    /* Validate the TLV exists and the offset is OK*/
    if (fpp_cfg_p->my_tlv.enable) {
        rc = hwd_flex_parser_db_flex_header_get(fpp_cfg_p->my_tlv.fpp_id.fpp_id, &tlv_flex_entry_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed retrieving TLV [%u] from DB.\n", fpp_cfg_p->my_tlv.fpp_id.fpp_id);
            goto out;
        }
        if (!tlv_flex_entry_p->valid || (tlv_flex_entry_p->fpp_data.fpp_cfg.type != SX_FLEX_PARSER_FPP_TYPE_FTLV)) {
            SX_LOG_ERR("FPP [%u] is trying to use a non configured TLV [%u].\n", fpp, fpp_cfg_p->my_tlv.fpp_id.fpp_id);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        /* Check limitation on the TLV offset */
        if ((fpp_cfg_p->my_tlv.tlv_start_offset > MAX_TLV_START) ||
            (fpp_cfg_p->my_tlv.tlv_start_offset == 0) ||
            ((fpp_cfg_p->my_tlv.tlv_start_offset & 0x3) != 0)) {
            SX_LOG_ERR(
                "Flex header [%u] is trying configure TLV [%u] with invalid offset [%u]. Should be a multiple of 4.\n",
                fpp,
                fpp_cfg_p->my_tlv.fpp_id.fpp_id,
                fpp_cfg_p->my_tlv.tlv_start_offset);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }
    /* Validate the extraction points */
    if (fpp_cfg_p->fexp_start.enable) {
        rc = hwd_flex_parser_db_fexp_get(fpp_cfg_p->fexp_start.fexp_id.fexp_id, &fexp_start_db_entry_p);
        if (SX_CHECK_FAIL(rc) || !fexp_start_db_entry_p->valid) {
            SX_LOG_ERR("FEXP start [%u] is not valid for setting FPP [%u].\n", fpp_cfg_p->fexp_start.fexp_id.fexp_id,
                       fpp);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }
    if (fpp_cfg_p->fexp_offset.enable) {
        rc = hwd_flex_parser_db_fexp_get(fpp_cfg_p->fexp_offset.fexp_id.fexp_id, &fexp_offset_db_entry_p);
        if (SX_CHECK_FAIL(rc) || !fexp_offset_db_entry_p->valid) {
            SX_LOG_ERR("FEXP offset [%u] is invalid for setting FPP [%u].\n", fpp_cfg_p->fexp_offset.fexp_id.fexp_id,
                       fpp);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        rc = __validate_header_length(&fpp_cfg_p->fexp_offset.fexp_offset);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("FEXP offset [%u] parameters are invalid for setting FPP [%u].\n",
                       fpp_cfg_p->fexp_offset.fexp_id.fexp_id,
                       fpp);
            goto out;
        }
    }
    /* Validate the FEXP used in this header are not the same */
    if ((fexp_start_db_entry_p != NULL) && (fexp_offset_db_entry_p != NULL) &&
        (fexp_start_db_entry_p->fexp == fexp_offset_db_entry_p->fexp)) {
        SX_LOG_ERR("Same FEXP [%u] is used in both positions for setting FPP [%u].\n",
                   fpp_cfg_p->fexp_offset.fexp_id.fexp_id,
                   fpp);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_fpp_set_spc2(const sx_access_cmd_t             cmd,
                                              const sx_flex_parser_header_fpp_e fpp,
                                              const sx_flex_parser_fpp_t       *fpp_cfg_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    header_db_entry_t *flex_entry_p = NULL;
    sx_utils_status_t  utils_rc = SX_UTILS_STATUS_SUCCESS;
    int                ref_count = 0;

    SX_LOG_ENTER();

    /* Retrieve the headers from the DB */
    rc = hwd_flex_parser_db_flex_header_get(fpp, &flex_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving flex header [%u] from DB.\n", fpp);
        goto out;
    }

    /* If we just create the entry validate it's not already defined */
    if (cmd == SX_ACCESS_CMD_CREATE) {
        if (flex_entry_p->valid) {
            SX_LOG_ERR("FPP [%u] is already created and cannot be created again.\n", fpp);
            rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
            goto out;
        }
        rc = rm_entries_set(RM_SDK_TABLE_TYPE_FLEX_PARSER_PROGRAM_E, SX_ACCESS_CMD_ADD, 1, NULL);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("No resources to create FPP [%u]\n", fpp);
            goto out;
        }
        /* Clear the DB entry just to make sure */
        hwd_flex_parser_db_flex_header_invalidate(fpp);
        flex_entry_p->valid = TRUE;
        goto out;
    }

    if (!flex_entry_p->valid) {
        SX_LOG_ERR("FPP [%u] was not created and cannot be modified.\n", fpp);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Don't allow changing a header if it's a destination of a transition */
    utils_rc = sdk_refcount_get(&flex_entry_p->to_refcount, &ref_count);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to get the to reference count for flex parser header [%d].\n", fpp);
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }
    if (ref_count > 0) {
        SX_LOG_ERR("Flex header [%u] is used by %u transitions and cannot be modified.\n", fpp, ref_count);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* If we're trying to remove a FPP. This can be completely or just setting it to undefined.*/
    if ((cmd == SX_ACCESS_CMD_DESTROY) ||
        ((cmd == SX_ACCESS_CMD_SET) && (fpp_cfg_p->type == SX_FLEX_PARSER_FPP_TYPE_UNDEFINED))) {
        /* Don't allow removing a header if it's a source of a transition */
        utils_rc = sdk_refcount_get(&flex_entry_p->from_refcount, &ref_count);
        if (SX_UTILS_CHECK_FAIL(utils_rc)) {
            SX_LOG_ERR("Failed to get the from reference count for flex parser header [%d].\n", fpp);
            rc = sx_utils_status_to_sx_status(utils_rc);
            goto out;
        }
        if (ref_count > 0) {
            SX_LOG_ERR("Flex header [%u] is used as a source by %u transitions and cannot be removed.\n",
                       fpp,
                       ref_count);
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
        /* Don't allow removing a header if it's a source of a transition */
        utils_rc = sdk_refcount_get(&flex_entry_p->fpp_data.ext_refcount, &ref_count);
        if (SX_UTILS_CHECK_FAIL(utils_rc)) {
            SX_LOG_ERR("Failed to get the external reference count for flex parser header [%d].\n", fpp);
            rc = sx_utils_status_to_sx_status(utils_rc);
            goto out;
        }
        if (ref_count > 0) {
            SX_LOG_ERR("Flex header [%u] is used by %u external modules and cannot be removed.\n",
                       fpp,
                       ref_count);
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
        /* Decrease references before destroying this header */
        rc = __decrease_fpp_references(flex_entry_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to decrease referenced when destroying flex header [%u].\n", fpp);
            goto out;
        }
        /* We only need to destroy the DB entries. We do not write anything to HW. */
        rc = hwd_flex_parser_db_flex_header_invalidate(fpp);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to invalidate flex header [%u] from DB.\n", fpp);
            goto out;
        }
        /* We retain the entry as valid if this is not a destroy */
        if (cmd == SX_ACCESS_CMD_SET) {
            flex_entry_p->valid = TRUE;
        } else {
            /* If we destroy release the resource */
            rc = rm_entries_set(RM_SDK_TABLE_TYPE_FLEX_PARSER_PROGRAM_E, SX_ACCESS_CMD_DELETE, 1, NULL);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to release resource for FPP [%u]\n", fpp);
                goto out;
            }
        }
        /* We're done here. Go out. */
        goto out;
    }

    /* Don't allow to change the type of the FPP on the fly */
    if ((flex_entry_p->fpp_data.fpp_cfg.type != SX_FLEX_PARSER_FPP_TYPE_UNDEFINED) &&
        (flex_entry_p->fpp_data.fpp_cfg.type != fpp_cfg_p->type)) {
        SX_LOG_ERR("FPP [%u] cannot change its type once it was already set.\n", fpp);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    /* If we're here we're setting/overwriting a header */
    rc = __validate_fpp_config(fpp, fpp_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("FPP [%u] failed validation.\n", fpp);
        goto out;
    }

    /* Configure the main header in the FW */
    rc = hwd_flex_parser_reg_fppc_set(fpp, fpp_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed configuring parse header register: FPP [%u].\n", fpp);
        goto out;
    }
    /* Decrease old references before adding new ones */
    rc = __decrease_fpp_references(flex_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to decrease referenced when destroying flex header [%u].\n", fpp);
        goto out;
    }
    /* Set the FPP in the DB */
    rc = hwd_flex_parser_db_flex_header_set(fpp, fpp_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed configuring parser header in DB: FPP [%u].\n", fpp);
        goto out;
    }
    /* Retrieve the updated header from the DB */
    rc = hwd_flex_parser_db_flex_header_get(fpp, &flex_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving flex header [%u] from DB.\n", fpp);
        goto out;
    }
    /* Increase references to the new TLV/FEXP */
    rc = __increase_fpp_references(flex_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to increase referenced when destroying flex header [%u].\n", fpp);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_fpp_get_spc2(const sx_access_cmd_t             cmd,
                                              const sx_flex_parser_header_fpp_e fpp,
                                              sx_flex_parser_fpp_t             *fpp_cfg)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    header_db_entry_t *flex_entry_p = NULL;

    SX_LOG_ENTER();

    UNUSED_PARAM(cmd);

    /* Retrieve the headers from the DB */
    rc = hwd_flex_parser_db_flex_header_get(fpp, &flex_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving flex header [%u] from DB.\n", fpp);
        goto out;
    }

    if (!flex_entry_p->valid) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_INF("FPP get operation [%u] from DB.\n", fpp);
        goto out;
    }

    if (fpp_cfg) {
        *fpp_cfg = flex_entry_p->fpp_data.fpp_cfg;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_hph_set_spc2(const sx_access_cmd_t               cmd,
                                              const sx_flex_parser_header_fixed_e fixed_header,
                                              const sx_flex_parser_hph_t         *hph_cfg_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_utils_status_t  utils_rc = SX_UTILS_STATUS_SUCCESS;
    header_db_entry_t *fixed_entry_p = NULL;
    header_db_entry_t *flex_entry_p = NULL;
    header_db_entry_t *prev_flex_entry_p = NULL;
    ref_name_data_t    ref_name_data = {.print_func_p = get_fixed_header_ref_name,
                                        .ref_data_p = NULL,
                                        .data_size = sizeof(sx_flex_parser_header_fixed_e)};

    SX_LOG_ENTER();

    UNUSED_PARAM(cmd);

    /* Get the fixed header from the DB and see if we can set a TLV to this header */
    rc = hwd_flex_parser_db_fixed_header_get(fixed_header, &fixed_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Fixed header [%u] is not valid for setting a TLV.\n", fixed_header);
        goto out;
    }
    /* Check if we can a TLV to this header */
    if (!fixed_entry_p->fixed_data.can_have_tlv) {
        SX_LOG_ERR("Cannot set a TLV for fixed header %s.\n", sx_flex_parser_header_fixed_str(fixed_header));
        rc = SX_STATUS_ERROR;
        goto out;
    }
    /* If a header was already set we need to remove reference to it*/
    if (fixed_entry_p->fixed_data.hph_cfg.ftlv_mode != SX_FLEX_PARSER_TLV_PARSING_DISABLED) {
        rc = hwd_flex_parser_db_flex_header_get(fixed_entry_p->fixed_data.hph_cfg.ftlv_id.fpp_id, &prev_flex_entry_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get previous flex header %s when setting a fixed TLV.\n",
                       sx_flex_parser_header_fpp_str(fixed_entry_p->fixed_data.hph_cfg.ftlv_id.fpp_id));
            goto out;
        }
    }
    /* If the TLV is not set and we don't want to set just go out */
    if ((cmd == SX_ACCESS_CMD_UNSET) && (prev_flex_entry_p == NULL)) {
        SX_LOG_INF("Tried to remove a non existing TLV from fixed header %s.\n",
                   sx_flex_parser_header_fixed_str(fixed_header));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        /* Retrieve the flex header we're going to use as TLV */
        rc = hwd_flex_parser_db_flex_header_get(hph_cfg_p->ftlv_id.fpp_id, &flex_entry_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get flex header %s when setting a fixed TLV.\n",
                       sx_flex_parser_header_fpp_str(hph_cfg_p->ftlv_id.fpp_id));
            goto out;
        }
        if (flex_entry_p->fpp_data.fpp_cfg.type != SX_FLEX_PARSER_FPP_TYPE_FTLV) {
            SX_LOG_ERR("Tried to use a non TLV flex header %s when setting a fixed TLV for %s.\n",
                       sx_flex_parser_header_fpp_str(hph_cfg_p->ftlv_id.fpp_id),
                       sx_flex_parser_header_fixed_str(fixed_header));
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }
    /* Write to the FW the new TLV */
    if (cmd == SX_ACCESS_CMD_UNSET) {
        rc = hwd_flex_parser_reg_fphhc_set(fixed_entry_p->hw_entry_index, 0, 0, 0);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to unset TLV for fixed header %s in register.\n",
                       sx_flex_parser_header_fixed_str(fixed_header));
            goto out;
        }
    } else {
        rc = hwd_flex_parser_reg_fphhc_set(fixed_entry_p->hw_entry_index,
                                           hph_cfg_p->ftlv_mode == SX_FLEX_PARSER_TLV_PARSING_ENABLE_OUTER ||
                                           hph_cfg_p->ftlv_mode == SX_FLEX_PARSER_TLV_PARSING_ENABLE_OUTER_INNER,
                                           hph_cfg_p->ftlv_mode == SX_FLEX_PARSER_TLV_PARSING_ENABLE_INNER ||
                                           hph_cfg_p->ftlv_mode == SX_FLEX_PARSER_TLV_PARSING_ENABLE_OUTER_INNER,
                                           hph_cfg_p->ftlv_id.fpp_id);

        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set TLV %s for fixed header %s in register.\n",
                       sx_flex_parser_header_fpp_str(hph_cfg_p->ftlv_id.fpp_id),
                       sx_flex_parser_header_fixed_str(fixed_header));
            goto out;
        }
    }
    /* Remove the reference from a previous TLV */
    if (prev_flex_entry_p != NULL) {
        utils_rc = sdk_refcount_dec(&prev_flex_entry_p->to_refcount, &fixed_entry_p->tlv_reference);
        if (SX_UTILS_CHECK_FAIL(utils_rc)) {
            SX_LOG_ERR("Failed decreasing reference TLV %s for fixed header %s, error: [%s]\n",
                       sx_flex_parser_header_fpp_str(prev_flex_entry_p->hdr.hdr_data.parser_hdr_fpp),
                       sx_flex_parser_header_fixed_str(fixed_header),
                       SX_UTILS_STATUS_MSG(utils_rc));
            rc = sx_utils_status_to_sx_status(utils_rc);
            goto out;
        }
    }
    /* Increase the reference to the new TLV */
    if (cmd == SX_ACCESS_CMD_SET) {
        ref_name_data.ref_data_p = &fixed_entry_p->hdr.hdr_data.parser_hdr_fixed;
        utils_rc = sdk_refcount_inc(&flex_entry_p->to_refcount, &ref_name_data, &fixed_entry_p->tlv_reference);
        if (SX_UTILS_CHECK_FAIL(utils_rc)) {
            SX_LOG_ERR("Failed increasing reference TLV %s for fixed header %s, error: [%s]\n",
                       sx_flex_parser_header_fpp_str(flex_entry_p->hdr.hdr_data.parser_hdr_fpp),
                       sx_flex_parser_header_fixed_str(fixed_header),
                       SX_UTILS_STATUS_MSG(utils_rc));
            rc = sx_utils_status_to_sx_status(utils_rc);
            goto out;
        }
    }

    if (cmd == SX_ACCESS_CMD_UNSET) {
        fixed_entry_p->fixed_data.hph_cfg.ftlv_mode = SX_FLEX_PARSER_TLV_PARSING_DISABLED;
        fixed_entry_p->fixed_data.hph_cfg.ftlv_id.fpp_id = 0;
    } else {
        /* Update the DB entry with the new TLV */
        fixed_entry_p->fixed_data.hph_cfg = *hph_cfg_p;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_hph_get_spc2(const sx_access_cmd_t               cmd,
                                              const sx_flex_parser_header_fixed_e fixed_header,
                                              sx_flex_parser_hph_t               *hph_cfg_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    header_db_entry_t *fixed_entry_p = NULL;

    SX_LOG_ENTER();

    UNUSED_PARAM(cmd);

    /* Get the fixed header from the DB and see if we can get a TLV to this header */
    rc = hwd_flex_parser_db_fixed_header_get(fixed_header, &fixed_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Fixed header [%u] is not valid for TLV get.\n", fixed_header);
        goto out;
    }
    /* No hard header configuration */
    if ((!fixed_entry_p->fixed_data.can_have_tlv) ||
        (fixed_entry_p->fixed_data.hph_cfg.ftlv_mode == SX_FLEX_PARSER_TLV_PARSING_DISABLED)) {
        SX_MEM_CLR_P(hph_cfg_p);
        hph_cfg_p->ftlv_mode = SX_FLEX_PARSER_TLV_PARSING_DISABLED;
        goto out;
    }

    *hph_cfg_p = fixed_entry_p->fixed_data.hph_cfg;

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_parser_fexp_set_spc2(const sx_access_cmd_t cmd, const sx_flex_parser_fexp_e fexp)
{
    sx_status_t      rc = SX_STATUS_SUCCESS;
    fexp_db_entry_t *fexp_db_entry_p = NULL;

    SX_LOG_ENTER();

    rc = hwd_flex_parser_db_fexp_get(fexp, &fexp_db_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("FEXP [%u] is invalid.\n", fexp);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    /* If we try to create an already existing entry */
    if ((cmd == SX_ACCESS_CMD_CREATE) && fexp_db_entry_p->valid) {
        SX_LOG_ERR("FEXP [%u] already exists and cannot be created again.\n", fexp);
        rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }
    if ((cmd == SX_ACCESS_CMD_DESTROY) && !fexp_db_entry_p->valid) {
        SX_LOG_ERR("FEXP [%u] wasn't created and cannot be destroyed.\n", fexp);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    if ((cmd == SX_ACCESS_CMD_DESTROY) && (fexp_db_entry_p->refcount > 0)) {
        SX_LOG_ERR("FEXP [%u] is in use and cannot be destroyed.\n", fexp);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }
    /* Update the DB entry accordingly */
    fexp_db_entry_p->valid = (cmd == SX_ACCESS_CMD_CREATE) ? TRUE : FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_port_handle_swid_callback(adviser_event_e event_type, void *param_p)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    sx_port_info_t               *port_info_p = (sx_port_info_t*)param_p;
    sx_flex_parser_root_sop_cfg_t root_cfg;

    SX_LOG_ENTER();

    rc = swid_validation_func_ptr(port_info_p->swid_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Swid validation failed, swid: %u\n", port_info_p->swid_id);
        /* SWID type mismatch, nothing to process */
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    switch (event_type) {
    case ADVISER_EVENT_PRE_PORT_DEL_FROM_SWID_E:
        /* The removal of the root port was moved here from the post callback.
         * Since the SWID port delete disables the port in FW (via the PSPA register)
         * we cannot call the FPTS register at the post callback.
         */

        /* Check if the port is a root for a FPP */
        rc = hwd_flex_parser_db_port_root_get(port_info_p->id, NULL);
        if (SX_CHECK_PASS(rc)) {
            SX_MEM_CLR(root_cfg);
            /* Use the regular function to remove any FPP set to this root */
            root_cfg.log_port = port_info_p->id;
            rc = __flex_parser_root_set_spc2(SX_ACCESS_CMD_UNSET, &root_cfg, 1);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to unset root FPP for port [0x%08X] on port swid delete, error: %s\n",
                           port_info_p->id, sx_status_str(rc));
                goto out;
            }
        }
        /* In the entry was not found we want to return success */
        rc = SX_STATUS_SUCCESS;
        break;

    default:
        SX_LOG_ERR("Invalid event type [%d] for flex parser port handle.\n", event_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_root_set_spc2(const sx_access_cmd_t                cmd,
                                               const sx_flex_parser_root_sop_cfg_t *root_cfg_list_p,
                                               const uint32_t                       root_cfg_cnt)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_utils_status_t                utils_rc = SX_UTILS_STATUS_SUCCESS;
    flex_parser_db_port_root_item_t *port_root_item_p = NULL;
    header_db_entry_t               *flex_entry_p = NULL;
    uint32_t                         i = 0;
    ref_name_data_t                  ref_name_data = {.print_func_p = get_log_port_ref_name,
                                                      .ref_data_p = NULL,
                                                      .data_size = sizeof(sx_port_log_id_t)};

    SX_LOG_ENTER();

    /* Do the validations before we actually do anything */
    for (i = 0; i < root_cfg_cnt; i++) {
        rc = hwd_flex_parser_db_port_root_get(root_cfg_list_p[i].log_port, &port_root_item_p);
        if ((cmd == SX_ACCESS_CMD_UNSET) && (rc != SX_STATUS_SUCCESS)) {
            SX_LOG_ERR("Port [0x%08X] has no root FPP to unset.\n", root_cfg_list_p[i].log_port);
            goto out;
        }
        if (cmd == SX_ACCESS_CMD_SET) {
            /* Validate the port is a network port */
            VALIDATE_PORT(flex_parser_root_set, root_cfg_list_p[i].log_port);
            /* Check that the port is valid */
            rc = port_db_info_get(root_cfg_list_p[i].log_port, NULL);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Can't retrieve port [0x%08X] for flex parser root set, error: %s\n",
                           root_cfg_list_p[i].log_port, sx_status_str(rc));
                goto out;
            }
            rc = hwd_flex_parser_db_flex_header_get(root_cfg_list_p[i].fpp_id.fpp_id, &flex_entry_p);
            if (SX_CHECK_FAIL(rc) || (flex_entry_p->valid == FALSE) ||
                ((flex_entry_p->fpp_data.fpp_cfg.type != SX_FLEX_PARSER_FPP_TYPE_FPH_EMPTY) &&
                 (flex_entry_p->fpp_data.fpp_cfg.type != SX_FLEX_PARSER_FPP_TYPE_FPH))) {
                SX_LOG_ERR("FPP [%u] cannot be set as root for port [0x%08X].\n",
                           root_cfg_list_p[i].fpp_id.fpp_id,
                           root_cfg_list_p[i].log_port);
                rc = SX_STATUS_ENTRY_NOT_FOUND;
                goto out;
            }
        }
    }
    /* We're done with the validation do the actual binding between port and FPP */
    for (i = 0; i < root_cfg_cnt; i++) {
        port_root_item_p = NULL;
        rc = hwd_flex_parser_db_port_root_get(root_cfg_list_p[i].log_port, &port_root_item_p);
        if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("Failed to get port root; error: %s.\n", sx_status_str(rc));
            goto out;
        }
        /* For delete/update operation we need to delete old references and DB entries */
        if (port_root_item_p != NULL) {
            rc = hwd_flex_parser_db_flex_header_get(port_root_item_p->flex_header, &flex_entry_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("FPP [%u] not found referenced by root port [0x%08X].\n",
                           port_root_item_p->flex_header,
                           root_cfg_list_p[i].log_port);
                goto out;
            }
            /* Decrease the reference to the FPP */
            utils_rc = sdk_refcount_dec(&flex_entry_p->to_refcount, &port_root_item_p->ref);
            if (SX_UTILS_CHECK_FAIL(utils_rc)) {
                SX_LOG_ERR("Failed to decrease reference for FPP [%u] for port [0x%08X].\n",
                           root_cfg_list_p[i].fpp_id.fpp_id,
                           root_cfg_list_p[i].log_port);
                rc = sx_utils_status_to_sx_status(utils_rc);
                goto out;
            }
            /* Delete the binding from the DB */
            rc = hwd_flex_parser_db_port_root_delete(root_cfg_list_p[i].log_port);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to delete DB flex parser root for port [0x%08X].\n", root_cfg_list_p[i].log_port);
                goto out;
            }
        }

        if (cmd == SX_ACCESS_CMD_UNSET) {
            /* Call the FPTS to set things in the FW */
            rc = hwd_flex_parser_reg_fpts_set(cmd, FALSE, root_cfg_list_p[i].log_port, 0);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set FPTS register for port [0x%08X]\n", root_cfg_list_p[i].log_port);
                goto out;
            }
        } else {  /* Set operation */
            rc = hwd_flex_parser_db_flex_header_get(root_cfg_list_p[i].fpp_id.fpp_id, &flex_entry_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("FPP [%u] not found to be added to root port [0x%08X].\n",
                           root_cfg_list_p[i].fpp_id.fpp_id,
                           root_cfg_list_p[i].log_port);
                goto out;
            }
            /* Call the FPTS to set things in the FW */
            rc = hwd_flex_parser_reg_fpts_set(cmd, FALSE, root_cfg_list_p[i].log_port, flex_entry_p->hw_entry_index);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set FPTS register for port [0x%08X]\n", root_cfg_list_p[i].log_port);
                goto out;
            }
            /* Update the DB with the new entry */
            rc = hwd_flex_parser_db_port_root_add(root_cfg_list_p[i].log_port, FALSE, &port_root_item_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to add DB flex parser root for port [0x%08X]\n", root_cfg_list_p[i].log_port);
                goto out;
            }
            port_root_item_p->log_port = root_cfg_list_p[i].log_port;
            port_root_item_p->flex_header = root_cfg_list_p[i].fpp_id.fpp_id;
            /* Increase the reference to the FPP */
            ref_name_data.ref_data_p = &port_root_item_p->log_port;
            utils_rc = sdk_refcount_inc(&flex_entry_p->to_refcount, &ref_name_data, &port_root_item_p->ref);
            if (SX_UTILS_CHECK_FAIL(utils_rc)) {
                SX_LOG_ERR("Failed to increase reference for FPP [%u] for port [0x%08X]\n",
                           root_cfg_list_p[i].fpp_id.fpp_id,
                           root_cfg_list_p[i].log_port);
                rc = sx_utils_status_to_sx_status(utils_rc);
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_root_get_spc2(const sx_access_cmd_t          cmd,
                                               sx_port_log_id_t               local_port,
                                               sx_flex_parser_root_sop_cfg_t *root_cfg_list_p,
                                               uint32_t                      *root_cfg_cnt)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_parser_db_port_root_item_t *port_root_item_p = NULL;
    uint32_t                         i = 0;
    uint32_t                         curr_root_cfg_num = 0;

    SX_LOG_ENTER();

    if (((*root_cfg_cnt) == 0) || (root_cfg_list_p == NULL)) {
        hwd_flex_parser_db_port_root_count(root_cfg_cnt);
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        rc = hwd_flex_parser_db_port_root_get(local_port, &port_root_item_p);
        if (SX_CHECK_FAIL(rc)) {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            *root_cfg_cnt = 0;
            goto out;
        }
        root_cfg_list_p->log_port = local_port;
        root_cfg_list_p->fpp_id.fpp_id = port_root_item_p->flex_header;
        *root_cfg_cnt = 1;
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        local_port = 0;

    /* no break */
    /* fall through */
    case SX_ACCESS_CMD_GETNEXT:
        /*if root_cfg_cnt > current number of root_cfg, root_cfg_cnt = current number of root_cfg elements in DB*/
        hwd_flex_parser_db_port_root_count(&curr_root_cfg_num);
        if (curr_root_cfg_num < *root_cfg_cnt) {
            *root_cfg_cnt = curr_root_cfg_num;
        }
        for (i = 0; i < *root_cfg_cnt; i++) {
            rc = hwd_flex_parser_db_port_root_get_next(local_port, &port_root_item_p);
            if (SX_CHECK_FAIL(rc)) {
                break;
            }
            root_cfg_list_p[i].log_port = port_root_item_p->log_port;
            root_cfg_list_p[i].fpp_id.fpp_id = port_root_item_p->flex_header;
            local_port = port_root_item_p->log_port;
        }
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is unsupported for flex parser root get, error: [%s].\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_resources_get_spc2(const sx_access_cmd_t       cmd,
                                                    sx_flex_parser_resources_t *flex_parser_resources_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(cmd);

    flex_parser_resources_p->total_fpp = SX_FLEX_PARSER_HEADER_FPP_LAST;
    flex_parser_resources_p->total_fexp = SX_FLEX_PARSER_FEXP_LAST;
    flex_parser_resources_p->total_transitions = MAX_HW_FLEX_TRANSITIONS;
    hwd_flex_parser_db_flex_header_count(&flex_parser_resources_p->used_fpp);
    hwd_flex_parser_db_fexp_count(&flex_parser_resources_p->used_fexp);
    hwd_flex_parser_db_transitions_count(&flex_parser_resources_p->used_transitions);

    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_reg_ext_point_is_set_spc2(sx_register_key_t reg_key, boolean_t *is_set_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (reg_key.type) {
    case SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
        rc = hwd_flex_parser_db_gp_reg_is_ext_point_set(reg_key.key.gp_reg.reg_id,
                                                        is_set_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get data from extraction point GP register (%d) DB, error: [%s]\n",
                       reg_key.key.gp_reg.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to get data from extraction point GP register DB: invalid register type %d\n",
                   reg_key.type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_reg_ext_point_set_spc2(sx_register_key_t      reg_key,
                                                        uint32_t               ext_point_cnt,
                                                        sx_extraction_point_t *ext_point_list_p,
                                                        sdk_ref_t             *ref_p)
{
    sx_status_t      rc = SX_STATUS_SUCCESS;
    fexp_db_entry_t *fexp_db_entry_p = NULL;
    uint32_t         i = 0;

    SX_LOG_ENTER();

    switch (reg_key.type) {
    case SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
        /* Validate that flex extraction points exist */
        for (i = 0; i < ext_point_cnt; i++) {
            if ((ext_point_list_p[i].type == SX_EXTRACTION_POINT_TYPE_FEXP_OUTER_E) ||
                (ext_point_list_p[i].type == SX_EXTRACTION_POINT_TYPE_FEXP_INNER_E)) {
                rc = hwd_flex_parser_db_fexp_get(ext_point_list_p[i].attr.fexp_attr.fexp_id.fexp_id, &fexp_db_entry_p);
                if (SX_CHECK_FAIL(rc) || !fexp_db_entry_p->valid) {
                    SX_LOG_ERR("FEXP [%u] is invalid for setting an extraction point for register [%u]\n",
                               ext_point_list_p[i].attr.fexp_attr.fexp_id.fexp_id,
                               reg_key.key.gp_reg.reg_id);
                    rc = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
            }
        }

        rc = hwd_flex_parser_reg_gp_register_ext_point_hw_set(reg_key.key.gp_reg, ext_point_cnt, ext_point_list_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set GP register (%d) extraction point list in HW, error: [%s]\n",
                       reg_key.key.gp_reg.reg_id, sx_status_str(rc));
            goto out;
        }

        rc = hwd_flex_parser_db_gp_reg_ext_point_set(reg_key.key.gp_reg.reg_id,
                                                     ext_point_cnt, ext_point_list_p,
                                                     ref_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set GP register (%d) extraction point list in DB, error: [%s]\n",
                       reg_key.key.gp_reg.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to set extraction point list on register: invalid register type %d\n", reg_key.type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_parser_reg_ext_point_validate_spc2(sx_register_key_t      reg_key,
                                                             uint32_t               ext_point_cnt,
                                                             sx_extraction_point_t *ext_point_list_p,
                                                             boolean_t             *is_valid_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i;

    UNUSED_PARAM(reg_key);

    *is_valid_p = TRUE;
    for (i = 0; i < ext_point_cnt; i++) {
        /* HASH_SIG ext points only supported by SPC4 */
        switch (ext_point_list_p[i].type) {
        case SX_EXTRACTION_POINT_TYPE_HASH_SIG0_E:
        case SX_EXTRACTION_POINT_TYPE_HASH_SIG1_E:
        case SX_EXTRACTION_POINT_TYPE_HASH_SIG2_E:
        case SX_EXTRACTION_POINT_TYPE_HASH_SIG3_E:
            SX_LOG_ERR("Extraction point \"%s\" isn't supported by this system\n",
                       sx_extraction_point_type_str(ext_point_list_p[i].type));
            *is_valid_p = FALSE;
            goto out;

        default:
            break;
        }
    }

out:
    return rc;
}

static sx_status_t __flex_parser_reg_ext_point_validate_spc4(sx_register_key_t      reg_key,
                                                             uint32_t               ext_point_cnt,
                                                             sx_extraction_point_t *ext_point_list_p,
                                                             boolean_t             *is_valid_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i;

    UNUSED_PARAM(reg_key);

    *is_valid_p = TRUE;
    for (i = 0; i < ext_point_cnt; i++) {
        /* HASH_SIG ext points only supported by SPC4
         * offset should be 0 */
        switch (ext_point_list_p[i].type) {
        case SX_EXTRACTION_POINT_TYPE_HASH_SIG0_E:
            /* Must be used with: Gp-Reg0 or Gp-Reg4 or Gp-Reg8    (SPC4 only) */
            if ((reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_0_E) &&
                (reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_4_E) &&
                (reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_8_E)) {
                SX_LOG_ERR("Extraction point \"%s\" should be used with: Gp-Reg0 or Gp-Reg4 or Gp-Reg8 only.\n",
                           sx_extraction_point_type_str(ext_point_list_p[i].type));
                *is_valid_p = FALSE;
                goto out;
            }

            if (ext_point_list_p[i].offset != 0) {
                SX_LOG_ERR("Extraction point \"%s\" should have offset 0.\n",
                           sx_extraction_point_type_str(ext_point_list_p[i].type));
                *is_valid_p = FALSE;
                goto out;
            }

            break;

        case SX_EXTRACTION_POINT_TYPE_HASH_SIG1_E:
            /* Must be used with: Gp-Reg1 or Gp-Reg5 or Gp-Reg9    (SPC4 only)   */
            if ((reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_1_E) &&
                (reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_5_E) &&
                (reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_9_E)) {
                SX_LOG_ERR("Extraction point \"%s\" should be used with: Gp-Reg1 or Gp-Reg5 or Gp-Reg9 only.\n",
                           sx_extraction_point_type_str(ext_point_list_p[i].type));
                *is_valid_p = FALSE;
                goto out;
            }

            if (ext_point_list_p[i].offset != 0) {
                SX_LOG_ERR("Extraction point \"%s\" should have offset 0.\n",
                           sx_extraction_point_type_str(ext_point_list_p[i].type));
                *is_valid_p = FALSE;
                goto out;
            }

            break;

        case SX_EXTRACTION_POINT_TYPE_HASH_SIG2_E:
            /* Must be used with: Gp-Reg2 or Gp-Reg6 or Gp-Reg10  (SPC4 only)   */
            if ((reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_2_E) &&
                (reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_6_E) &&
                (reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_10_E)) {
                SX_LOG_ERR("Extraction point \"%s\" should be used with: Gp-Reg2 or Gp-Reg6 or Gp-Reg10 only.\n",
                           sx_extraction_point_type_str(ext_point_list_p[i].type));
                *is_valid_p = FALSE;
                goto out;
            }

            if (ext_point_list_p[i].offset != 0) {
                SX_LOG_ERR("Extraction point \"%s\" should have offset 0.\n",
                           sx_extraction_point_type_str(ext_point_list_p[i].type));
                *is_valid_p = FALSE;
                goto out;
            }

            break;

        case SX_EXTRACTION_POINT_TYPE_HASH_SIG3_E:
            /* Must be used with: Gp-Reg3 or Gp-Reg7 or Gp-Reg11  (SPC4 only)   */
            if ((reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_3_E) &&
                (reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_7_E) &&
                (reg_key.key.gp_reg.reg_id != SX_GP_REGISTER_11_E)) {
                SX_LOG_ERR("Extraction point \"%s\" should be used with: Gp-Reg3 or Gp-Reg7 or Gp-Reg11 only.\n",
                           sx_extraction_point_type_str(ext_point_list_p[i].type));
                *is_valid_p = FALSE;
                goto out;
            }

            if (ext_point_list_p[i].offset != 0) {
                SX_LOG_ERR("Extraction point \"%s\" should have offset 0.\n",
                           sx_extraction_point_type_str(ext_point_list_p[i].type));
                *is_valid_p = FALSE;
                goto out;
            }

            break;

        default:
            break;
        }
    }

out:
    return rc;
}

static sx_status_t __flex_parser_reg_ext_point_get_spc2(sx_register_key_t      reg_key,
                                                        uint32_t              *ext_point_cnt_p,
                                                        sx_extraction_point_t *ext_point_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (reg_key.type) {
    case SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E:
        rc = hwd_flex_parser_db_gp_reg_ext_point_get(reg_key.key.gp_reg.reg_id, ext_point_cnt_p, ext_point_list_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get GP register (%d) extraction point list from DB, error: [%s]\n",
                       reg_key.key.gp_reg.reg_id, sx_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to get data from extraction point GP register DB: invalid register type %d\n",
                   reg_key.type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_fpp_ref_inc_spc2(const sx_flex_parser_header_fpp_e fpp,
                                                  const ref_name_data_t            *ref_name_data,
                                                  sdk_ref_t                        *ref_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_utils_status_t  utils_rc = SX_UTILS_STATUS_SUCCESS;
    header_db_entry_t *flex_entry_p = NULL;

    SX_LOG_ENTER();

    rc = hwd_flex_parser_db_flex_header_get(fpp, &flex_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("FPP [%u] not found for external reference.\n", fpp);
        goto out;
    }
    /* Increase the reference to the FPP */
    utils_rc = sdk_refcount_inc(&flex_entry_p->fpp_data.ext_refcount, ref_name_data, ref_p);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to increase external reference for FPP [%u].\n", fpp);
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_fpp_ref_dec_spc2(const sx_flex_parser_header_fpp_e fpp, sdk_ref_t *ref_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_utils_status_t  utils_rc = SX_UTILS_STATUS_SUCCESS;
    header_db_entry_t *flex_entry_p = NULL;

    SX_LOG_ENTER();

    rc = hwd_flex_parser_db_flex_header_get(fpp, &flex_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("FPP [%u] not found for external reference.\n", fpp);
        goto out;
    }
    /* Decrease the reference to the FPP */
    utils_rc = sdk_refcount_dec(&flex_entry_p->fpp_data.ext_refcount, ref_p);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to decrease external reference for FPP [%u].\n", fpp);
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static void __flex_parser_extended_dump_spc2(dbg_dump_params_t *dbg_dump_params_p)
{
    /* Dump the user defined flex headers */
    hwd_flex_parser_headers_dump(dbg_dump_params_p);

    /* Dump the hard transition table */
    hwd_flex_parser_transitions_dump(dbg_dump_params_p);

    /* Dump the root configuration table */
    hwd_flex_parser_root_cfg_dump(dbg_dump_params_p);
}

sx_status_t hwd_flex_parser_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    hwd_flex_parser_db_log_verbosity_level_set(verbosity_level);
    hwd_flex_parser_reg_log_verbosity_level_set(verbosity_level);
    SX_LOG_EXIT();

    return rc;
}

void hwd_flex_parser_set_impl_ops_spc()
{
    /* Implementation specific to Spectrum */
    g_flex_parser_hwd_ops.flex_parser_transition_set_pfn = __flex_parser_transition_set_spc;
    g_flex_parser_hwd_ops.flex_parser_transition_get_pfn = __flex_parser_transition_get_spc;
    g_flex_parser_hwd_ops.flex_parser_flex_transition_set_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_flex_transition_get_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_transition_set_all_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_init_pfn = __flex_parser_init_spc;
    g_flex_parser_hwd_ops.flex_parser_deinit_pfn = __flex_parser_deinit_spc;
    g_flex_parser_hwd_ops.flex_parser_dev_ready_cb_pfn = __flex_parser_device_ready_callback_spc;
    g_flex_parser_hwd_ops.flex_parser_fpp_set_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_fpp_get_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_hph_set_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_hph_get_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_fexp_set_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_root_set_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_root_get_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_resources_get_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_is_set_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_set_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_get_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_gp_reg_ext_point_dump_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_fpp_ref_inc_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_fpp_ref_dec_pfn = NULL;
    g_flex_parser_hwd_ops.flex_parser_extended_dump_pfn = NULL;
}

void hwd_flex_parser_set_impl_ops_spc2()
{
    /* Implementation specific to Spectrum2 & 3 */
    g_flex_parser_hwd_ops.flex_parser_transition_set_pfn = __flex_parser_transition_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_transition_get_pfn = __flex_parser_transition_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_flex_transition_set_pfn = __flex_parser_flex_transition_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_flex_transition_get_pfn = __flex_parser_flex_transition_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_transition_set_all_pfn = __flex_parser_transition_set_all_spc2;
    g_flex_parser_hwd_ops.flex_parser_init_pfn = __flex_parser_init_spc2;
    g_flex_parser_hwd_ops.flex_parser_deinit_pfn = __flex_parser_deinit_spc2;
    g_flex_parser_hwd_ops.flex_parser_dev_ready_cb_pfn = __flex_parser_device_ready_callback_spc2;
    g_flex_parser_hwd_ops.flex_parser_fpp_set_pfn = __flex_parser_fpp_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_fpp_get_pfn = __flex_parser_fpp_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_hph_set_pfn = __flex_parser_hph_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_hph_get_pfn = __flex_parser_hph_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_fexp_set_pfn = __flex_parser_fexp_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_root_set_pfn = __flex_parser_root_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_root_get_pfn = __flex_parser_root_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_resources_get_pfn = __flex_parser_resources_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_is_set_pfn = __flex_parser_reg_ext_point_is_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_set_pfn = __flex_parser_reg_ext_point_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_validate_pfn = __flex_parser_reg_ext_point_validate_spc2;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_get_pfn = __flex_parser_reg_ext_point_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_fpp_ref_inc_pfn = __flex_parser_fpp_ref_inc_spc2;
    g_flex_parser_hwd_ops.flex_parser_fpp_ref_dec_pfn = __flex_parser_fpp_ref_dec_spc2;
    g_flex_parser_hwd_ops.flex_parser_gp_reg_ext_point_dump_pfn = hwd_flex_parser_db_gp_reg_ext_point_dump;
    g_flex_parser_hwd_ops.flex_parser_extended_dump_pfn = __flex_parser_extended_dump_spc2;
}

void hwd_flex_parser_set_impl_ops_spc4()
{
    /* Implementation specific to Spectrum4 */
    g_flex_parser_hwd_ops.flex_parser_transition_set_pfn = __flex_parser_transition_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_transition_get_pfn = __flex_parser_transition_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_flex_transition_set_pfn = __flex_parser_flex_transition_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_flex_transition_get_pfn = __flex_parser_flex_transition_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_transition_set_all_pfn = __flex_parser_transition_set_all_spc2;
    g_flex_parser_hwd_ops.flex_parser_init_pfn = __flex_parser_init_spc2;
    g_flex_parser_hwd_ops.flex_parser_deinit_pfn = __flex_parser_deinit_spc2;
    g_flex_parser_hwd_ops.flex_parser_dev_ready_cb_pfn = __flex_parser_device_ready_callback_spc2;
    g_flex_parser_hwd_ops.flex_parser_fpp_set_pfn = __flex_parser_fpp_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_fpp_get_pfn = __flex_parser_fpp_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_hph_set_pfn = __flex_parser_hph_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_hph_get_pfn = __flex_parser_hph_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_fexp_set_pfn = __flex_parser_fexp_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_root_set_pfn = __flex_parser_root_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_root_get_pfn = __flex_parser_root_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_resources_get_pfn = __flex_parser_resources_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_is_set_pfn = __flex_parser_reg_ext_point_is_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_set_pfn = __flex_parser_reg_ext_point_set_spc2;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_validate_pfn = __flex_parser_reg_ext_point_validate_spc4;
    g_flex_parser_hwd_ops.flex_parser_reg_ext_point_get_pfn = __flex_parser_reg_ext_point_get_spc2;
    g_flex_parser_hwd_ops.flex_parser_fpp_ref_inc_pfn = __flex_parser_fpp_ref_inc_spc2;
    g_flex_parser_hwd_ops.flex_parser_fpp_ref_dec_pfn = __flex_parser_fpp_ref_dec_spc2;
    g_flex_parser_hwd_ops.flex_parser_gp_reg_ext_point_dump_pfn = hwd_flex_parser_db_gp_reg_ext_point_dump;
    g_flex_parser_hwd_ops.flex_parser_extended_dump_pfn = __flex_parser_extended_dump_spc2;
}
