/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWD_FLEX_PARSER_INCL__
#define __HWD_FLEX_PARSER_INCL__

#include <sx/sdk/sx_types.h>
#include <sx/utils/sdk_refcount.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define INVALID_UDP_PORT                 0
#define MAC_TO_MPLS_TRANSITION_VALUE_1   0x8847
#define MAC_TO_MPLS_TRANSITION_VALUE_2   0x8848
#define IPV4_TO_IPSEC_TRANSITION_VALUE_1 0x32
#define IPV4_TO_IPSEC_TRANSITION_VALUE_2 0x33
/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
void hwd_flex_parser_set_impl_ops_spc();

void hwd_flex_parser_set_impl_ops_spc2();

void hwd_flex_parser_set_impl_ops_spc4();

sx_status_t hwd_flex_parser_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

sx_status_t hwd_flex_parser_ext_point_set(sx_register_key_t      reg_key,
                                          uint32_t               ext_point_cnt,
                                          sx_extraction_point_t *ext_point_list_p,
                                          sdk_ref_t             *ref_p);

sx_status_t hwd_flex_parser_ext_point_get(sx_register_key_t      reg_key,
                                          uint32_t              *ext_point_cnt_p,
                                          sx_extraction_point_t *ext_point_list_p);

#endif /*__HWD_FLEX_PARSER_INCL__*/
