/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWD_FLEX_PARSER_DB_H_INCL__
#define __HWD_FLEX_PARSER_DB_H_INCL__


#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_flex_parser.h>
#include "sx/sdk/sx_strings.h"
#include <sx/utils/sdk_refcount.h>
#include <complib/cl_fleximap.h>
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/

#define MAX_HW_FLEX_TRANSITIONS                                                       \
    (rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E]. \
     table_size_max)

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/
typedef struct fixed_transition_db_entry {
    sx_flex_parser_header_fixed_e from;
    sx_flex_parser_header_fixed_e to;
    sx_flex_parser_encap_level_e  curr_encap_level;
    boolean_t                     enabled;
    uint32_t                      transition_value;
    flex_parser_hw_entry_index_t  hw_entry_index;
    sx_flex_parser_encap_level_e  next_encap_level;
} fixed_transition_db_entry_t;

typedef struct flex_transition_db_entry {
    boolean_t                    in_use; /* entry is enabled/disabled in HW. relevant for user index mode*/
    boolean_t                    valid; /*resource (transition_index) is allocated is the SDK*/
    sx_flex_parser_header_t      from;
    sx_flex_parser_header_t      to;
    uint32_t                     transition_value;
    flex_parser_hw_entry_index_t hw_entry_index;
    sx_flex_parser_encap_level_e encap_level;
    sdk_ref_t                    from_reference;    /* Used to keep a reference to the pointed header */
    sdk_ref_t                    to_reference;      /* Used to keep a reference to the pointed header */
} flex_transition_db_entry_t;

typedef struct fexp_db_entry {
    boolean_t             valid;
    sx_flex_parser_fexp_e fexp;
    uint32_t              refcount;              /* Used to keep count of the users (FPP) of this extraction point */
} fexp_db_entry_t;

typedef struct flex_header_db_entry {
    boolean_t                    valid;
    sx_flex_parser_header_t      hdr;
    flex_parser_hw_entry_index_t hw_entry_index;                /* The value used in the transition table to represent this header */
    sdk_refcount_t               from_refcount;                 /* Used to count the transitions from this header */
    sdk_refcount_t               to_refcount;                   /* Used to count the transitions pointing to this header */
    sdk_ref_t                    tlv_reference;                 /* Used to keep a reference to a TLV */
    union {
        struct {
            boolean_t            can_have_tlv;
            boolean_t            can_be_inner;
            boolean_t            can_be_next_ph;
            uint32_t             next_protocol_mask;
            sx_flex_parser_hph_t hph_cfg;
        } fixed_data;
        struct {
            sx_flex_parser_fpp_t fpp_cfg;
            sdk_refcount_t       ext_refcount;                  /* Used to count the external modules pointing to this header */
        } fpp_data;
    };
} header_db_entry_t;

typedef struct {
    cl_pool_item_t              pool_item;
    cl_map_item_t               map_item;
    sx_port_log_id_t            log_port;           /* The logical port for which the flex header is assigned */
    sx_flex_parser_header_fpp_e flex_header;        /* The flex header to be used by the port */
    sdk_ref_t                   ref;                /* Used to keep a reference to the pointed header */
} flex_parser_db_port_root_item_t;

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct {
    sx_gp_register_e      gp_reg_id;
    boolean_t             is_ext_point_set;
    sdk_ref_t             reference;
    uint32_t              ext_points_count;
    sx_extraction_point_t ext_points_list[RM_API_FLEX_PARSER_EXT_POINT_MAX_NUM];
} hwd_flex_parser_gp_reg_ext_point_db_t;

typedef sx_status_t (*hwd_flex_parser_gp_reg_ext_point_db_pfn_t)(hwd_flex_parser_gp_reg_ext_point_db_t *entry_p,
                                                                 void                                  *param_p);
/* Callback functions to be used by DB iterators during a device ready callback */
typedef sx_status_t (*hwd_flex_parser_fixed_transition_db_pfn_t)(fixed_transition_db_entry_t *fixed_transition_entry,
                                                                 void                        *param_p);
typedef sx_status_t (*hwd_flex_parser_flex_transition_db_pfn_t)(flex_transition_db_entry_t *flex_transition_entry,
                                                                void                       *param_p);
typedef sx_status_t (*hwd_flex_parser_header_db_pfn_t)(header_db_entry_t *header_entry, void *param_p);
typedef sx_status_t (*hwd_flex_parser_port_root_db_pfn_t)(flex_parser_db_port_root_item_t *port_root_entry,
                                                          void                            *param_p);


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t hwd_flex_parser_db_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

sx_status_t hwd_flex_parser_db_init();

sx_status_t hwd_flex_parser_db_deinit(boolean_t is_forced);

void hwd_flex_parser_db_vxlan_udp_dport_set(const uint32_t dport);

sx_status_t hwd_flex_parser_db_vxlan_udp_dport_get(uint32_t *dport);

void hwd_flex_parser_db_zero_dev_usr_conf_vxlan_udp_dport_value_set(uint32_t dport);

sx_status_t hwd_flex_parser_db_zero_dev_usr_conf_vxlan_udp_dport_value_get(uint32_t *dport);

sx_status_t hwd_flex_parser_db_vxlan_udp_dport_init();

sx_status_t hwd_flex_parser_db_gp_reg_is_ext_point_set(sx_gp_register_e gp_reg_id,
                                                       boolean_t       *is_ext_point_set);

sx_status_t hwd_flex_parser_db_gp_reg_ext_point_set(sx_gp_register_e       gp_reg_id,
                                                    uint32_t               ext_point_cnt,
                                                    sx_extraction_point_t *ext_point_list_p,
                                                    sdk_ref_t             *ref_p);

sx_status_t hwd_flex_parser_db_gp_reg_ext_point_get(sx_gp_register_e       gp_reg_id,
                                                    uint32_t              *ext_point_cnt_p,
                                                    sx_extraction_point_t *ext_point_list_p);

sx_status_t hwd_flex_parser_db_gp_reg_ext_point_foreach(hwd_flex_parser_gp_reg_ext_point_db_pfn_t func, void *param_p);

void hwd_flex_parser_db_gp_reg_ext_point_dump(dbg_dump_params_t *dbg_dump_params_p, sx_gp_register_e gp_reg_id);

sx_status_t hwd_flex_parser_db_gp_reg_ext_point_init();

sx_status_t hwd_flex_parser_db_gp_reg_ext_point_deinit(boolean_t is_forced);

const char* get_fixed_header_ref_name(char* name_buf, size_t name_size, void *fixed_header_p);
const char* get_flex_header_ref_name(char* name_buf, size_t name_size, void *flex_header_p);

/* This is a utility function to retrieve the string of a parse header */
const char* get_flex_parser_header_string(const sx_flex_parser_header_t *header_p);

/* Get a transitions from a hw header to hw header
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_fixed_transition_get(const sx_flex_parser_header_fixed_e from,
                                                    const sx_flex_parser_header_fixed_e to,
                                                    const sx_flex_parser_encap_level_e  encap_level,
                                                    uint32_t                            transition_value,
                                                    fixed_transition_db_entry_t       **fixed_entry_pp);

/* Iterate over all the entries in the fixed headers DB and call the callback function */
sx_status_t hwd_flex_parser_db_fixed_transition_foreach(hwd_flex_parser_fixed_transition_db_pfn_t func, void *param_p);

/* Get a flex transition - the unique key for this db is the transition index.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_flex_transition_index_get(const uint8_t                transition_index,
                                                         flex_transition_db_entry_t **flex_entry_pp);

/* Get a flex transition - the unique key for this db is from + transition value.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_flex_transition_get(const sx_flex_parser_header_t from,
                                                   const uint32_t                transition_value,
                                                   flex_transition_db_entry_t  **flex_entry_pp);

/* Iterate over all the entries in the flex headers DB and call the callback function */
sx_status_t hwd_flex_parser_db_flex_transition_foreach(hwd_flex_parser_flex_transition_db_pfn_t func, void *param_p);

/* Allocate a flex transition - the unique key for this db is from + transition value.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_flex_transition_allocate(const sx_flex_parser_header_t from,
                                                        const uint32_t                transition_value,
                                                        const uint8_t                 transition_index,
                                                        const boolean_t               allocate_by_transition_index,
                                                        flex_transition_db_entry_t  **flex_entry_pp);

/* Deallocate a flex transition - the unique key for this db is from + transition value.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_flex_transition_deallocate(const sx_flex_parser_header_t from,
                                                          const uint32_t                transition_value,
                                                          const uint8_t                 transition_index,
                                                          const boolean_t               deallocate_by_transition_index);

/* Get all the transitions from a specific header (fixed + flex).
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_transitions_get(const sx_flex_parser_header_t curr_ph,
                                               sx_flex_parser_transition_t  *next_trans_p,
                                               uint32_t                     *next_trans_cnt_p);

/* Get the number of transitions used */
sx_status_t hwd_flex_parser_db_transitions_count(uint32_t *transitions_count_p);

/* Get a fixed header information from the DB.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_fixed_header_get(const sx_flex_parser_header_fixed_e fixed_header,
                                                header_db_entry_t                 **fixed_header_entry_pp);

/* Iterate over all the entries in the fixed headers DB and call the callback function */
sx_status_t hwd_flex_parser_db_fixed_header_foreach(hwd_flex_parser_header_db_pfn_t func, void *param_p);

/* Get a flex header information from the DB. */
sx_status_t hwd_flex_parser_db_flex_header_get(const sx_flex_parser_header_fpp_e fpp,
                                               header_db_entry_t               **flex_header_entry_pp);

/* Get the number of flex headers used */
sx_status_t hwd_flex_parser_db_flex_header_count(uint32_t *flex_header_count);

/* Iterate over all the entries in the flex headers DB and call the callback function */
sx_status_t hwd_flex_parser_db_flex_header_foreach(hwd_flex_parser_header_db_pfn_t func, void *param_p);

/* Get a fixed/flex header information from the DB. */
sx_status_t hwd_flex_parser_db_header_get(const sx_flex_parser_header_t header,
                                          header_db_entry_t           **flex_header_entry_pp);

/* Set some of the flex header fields into the DB. */
sx_status_t hwd_flex_parser_db_flex_header_set(const sx_flex_parser_header_fpp_e fpp,
                                               const sx_flex_parser_fpp_t       *fpp_cfg_p);

/* Invalidate a flex header entry in the DB */
sx_status_t hwd_flex_parser_db_flex_header_invalidate(const sx_flex_parser_header_fpp_e fpp);

/* Increase a reference count to flex extraction point. */
sx_status_t hwd_flex_parser_db_fexp_ref_inc(const sx_flex_parser_fexp_e fexp);

/* Decrease a reference count to flex extraction point. */
sx_status_t hwd_flex_parser_db_fexp_ref_dec(const sx_flex_parser_fexp_e fexp);

/* Get the flex extraction point info from the DB. */
sx_status_t hwd_flex_parser_db_fexp_get(const sx_flex_parser_fexp_e fexp,
                                        fexp_db_entry_t           **fexp_db_entry_pp);

/* Get the number of flex extraction points used */
sx_status_t hwd_flex_parser_db_fexp_count(uint32_t *fexp_count_p);


/* Add a new port root entry to the DB */
sx_status_t hwd_flex_parser_db_port_root_add(const sx_port_log_id_t            log_port,
                                             const boolean_t                   reuse,
                                             flex_parser_db_port_root_item_t **port_root_item_pp);
/* Delete a port root entry from the DB */
sx_status_t hwd_flex_parser_db_port_root_delete(const sx_port_log_id_t log_port);
/* Get a port root entry from the DB */
sx_status_t hwd_flex_parser_db_port_root_get(const sx_port_log_id_t            log_port,
                                             flex_parser_db_port_root_item_t **port_root_item_pp);
/* Get the next root entry from the DB */
sx_status_t hwd_flex_parser_db_port_root_get_next(const sx_port_log_id_t            log_port,
                                                  flex_parser_db_port_root_item_t **port_root_item_pp);

/* Iterate over all the entries in the port root DB and call the callback function */
sx_status_t hwd_flex_parser_db_port_root_foreach(hwd_flex_parser_port_root_db_pfn_t func, void *param_p);

/* Get the number of entries in the root DB */
sx_status_t hwd_flex_parser_db_port_root_count(uint32_t *port_count_p);

/* Dump the user defined flex headers */
void hwd_flex_parser_headers_dump(dbg_dump_params_t *dbg_dump_params_p);

/* Dump the hard transition table */
void hwd_flex_parser_transitions_dump(dbg_dump_params_t *dbg_dump_params_p);

/* Dump the root to port configuration */
void hwd_flex_parser_root_cfg_dump(dbg_dump_params_t *dbg_dump_params_p);

#endif /*__HWD_FLEX_PARSER_DB_H_INCL__ */
