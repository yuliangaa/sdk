/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef HOST_INTERFACE_COMMON_H_
#define HOST_INTERFACE_COMMON_H_

#include <complib/sx_log.h>

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_api.h>
#include "span/span_db.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define SX_DR_PATH_GROUP_REQUIRED 0

#define SX_TRAP_ID_TRAP_GROUP_REQUIRED 5

#define SX_HW_TRAP_GROUP_CHECK_RANGE(TRAP_GROUP) \
    SX_CHECK_MAX(TRAP_GROUP, SX_HW_TRAP_GROUP_MAX_E)

#define SX_HW_TRAP_GROUP_SPECTRUM_MIN 0x0
#define SX_HW_TRAP_GROUP_SPECTRUM_MAX 0x1F

#define SPECTRUM_DEFAULT_TRAP_GROUPS_NUM 2

#define SPECTRUM_SPAN_TRAP_GROUPS_START 38
#define SPECTRUM_SPAN_TRAP_GROUPS_NUM   3

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum sx_hw_trap_group {
    SX_HW_TRAP_GROUP_0_E       = SXD_TRAP_GROUP_0,
    SX_HW_TRAP_GROUP_1_E       = SXD_TRAP_GROUP_1,
    SX_HW_TRAP_GROUP_2_E       = SXD_TRAP_GROUP_2,
    SX_HW_TRAP_GROUP_3_E       = SXD_TRAP_GROUP_3,
    SX_HW_TRAP_GROUP_4_E       = SXD_TRAP_GROUP_4,
    SX_HW_TRAP_GROUP_DISABLE_E = SXD_TRAP_GROUP_DISABLE,    /**< priority disable */

    SX_HW_TRAP_GROUP_MIN_E = SX_HW_TRAP_GROUP_0_E,    /**< minimum priority */
    SX_HW_TRAP_GROUP_MAX_E = SXD_TRAP_GROUP_4    /**< maximum priority */
} sx_hw_trap_group_e;

/**
 * This enum is used to indicate which flow was used for trap id binding.
 * None - no previous configuration
 * Regular - sx_api_host_ifc_trap_id_set
 * Ext - sx_api_host_ifc_trap_id_ext_set
 */
typedef enum {
    SX_HOST_IFC_TRAP_CFG_FLOW_TYPE_NONE_E    = 0,
    SX_HOST_IFC_TRAP_CFG_FLOW_TYPE_REGULAR_E = 1,
    SX_HOST_IFC_TRAP_CFG_FLOW_TYPE_EXT_E     = 2,
} sx_host_ifc_trap_cfg_flow_type_e;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of HOST IFC COMMON MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sx_status_t host_ifc_common_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

/**
 *  This function Sets the Host-Interface Capabilities.
 *
 * @param[in] max_num_cpu_tclass - Maximum CPU Traffic Class
 * @param[in] max_num_trap_groups - Maximum Trap Group
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_common_capabilities_set(IN uint8_t max_num_cpu_tclass,
                                             IN uint8_t max_num_trap_groups,
                                             IN uint8_t max_num_dr_paths);

/**
 *  This function checks if the given trap action is at the right range.
 *
 * @param[in] trap_action - trap action
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_check_trap_action(sx_trap_action_t trap_action);

/**
 *  This function convert trap prio to trap group.
 *
 * @param[in] trap_action - trap action
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_prio_2_trap_group(sx_trap_priority_t  trap_priority,
                                            sx_hw_trap_group_e *hw_trap_group);

/**
 *  This function finds the HW trap group mapped to the given trap group ID, or
 *  gets a new one, and sets the new trap group properties in the local DB.
 *  Note: This function should only be used on SPECTRUM devices.
 *
 * @param[in] swid            - SWID
 * @param[in] trap_group_id   - user trap group ID
 * @param[in] trap_priority   - trap priority
 * @param[in] truncate_mode	  - truncate mode
 * @param[in] truncate_size   - truncate size
 * @param[in] control_type    - control type
 * @param[out] hw_trap_group  - first free HW trap group
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL output parameter given
 */
sx_status_t host_ifc_spectrum_configure_hw_trap_group_properties(sx_swid_t                     swid,
                                                                 sx_trap_group_t               trap_group_id,
                                                                 sx_trap_priority_t            trap_priority,
                                                                 sx_truncate_mode_t            truncate_mode,
                                                                 sx_truncate_size_t            truncate_size,
                                                                 sx_trap_truncate_profile_id_t trunc_profile_id,
                                                                 sx_control_type_t             control_type,
                                                                 boolean_t                     add_timestamp,
                                                                 sx_packet_timestamp_source_e  timestamp_source,
                                                                 boolean_t                     is_tac_capable,
                                                                 boolean_t                     is_monitor,
                                                                 sx_fd_t                      *monitor_fd,
                                                                 uint32_t                     *hw_trap_group);

/**
 *  This function sets the HW trap group associated with the given priority to
 *  the given user trap group ID, and configures the properties in the local DB.
 *  Note: This function should only be used on SwitchX and SwitchX-2 devices.
 *
 * @param[in] swid            - SWID
 * @param[in] trap_group_id   - user trap group ID
 * @param[in] trap_priority   - trap priority
 * @param[in] truncate_mode	  - truncate mode
 * @param[in] truncate_size   - truncate size
 * @param[in] control_type    - control type
 * @param[out] hw_trap_group  - HW trap group associated with priority
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL output parameter given
 *         SX_STATUS_ENTRY_ALREADY_BOUND - HW trap group already bound
 *         SX_STATUS_ERROR - general error
 */
sx_status_t host_ifc_sx_configure_trap_group_properties(sx_swid_t                     swid,
                                                        sx_trap_group_t               trap_group_id,
                                                        sx_trap_priority_t            trap_priority,
                                                        sx_truncate_mode_t            truncate_mode,
                                                        sx_truncate_size_t            truncate_size,
                                                        sx_trap_truncate_profile_id_t trunc_profile_id,
                                                        sx_control_type_t             control_type,
                                                        boolean_t                     add_timestamp,
                                                        uint32_t                     *hw_trap_group);

/**
 *  This function sets the trap group in the local DB and in the device.
 *  Note: This function should only be used on SPECTRUM devices.
 *
 * @param[in] swid            - SWID
 * @param[in] trap_priority   - trap priority
 * @param[in] truncate_mode	  - truncate mode
 * @param[in] truncate_size   - truncate size
 * @param[in] trap_group	  - user trap group ID
 * @param[in] control_type    - control type
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL output parameter given
 *         SX_STATUS_ENTRY_ALREADY_BOUND - HW trap group already bound
 *         SX_STATUS_ERROR - general error
 */
sx_status_t host_ifc_spectrum_trap_group_set(sx_swid_id_t                swid,
                                             sx_trap_group_t             trap_group,
                                             sx_trap_group_attributes_t *trap_group_attributes_p);

/**
 *  This function sets the trap group in the local DB and in the device.
 *  Note: This function should only be used on SPECTRUM4 devices.
 *
 * @param[in] swid                        - SWID
 * @param[in] trap_group                  - trap_group
 * @param[in] trap_group_attributes_p	  - sx_trap_group_attributes_t
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL output parameter given
 *         SX_STATUS_ENTRY_ALREADY_BOUND - HW trap group already bound
 *         SX_STATUS_ERROR - general error
 */
sx_status_t host_ifc_spectrum_trap_group_set_spectrum4(sx_swid_id_t                swid,
                                                       sx_trap_group_t             trap_group,
                                                       sx_trap_group_attributes_t *trap_group_attributes_p);


/**
 *  This function validate group attributes for Spectrum.
 *
 * @param[in] swid                    - SWID
 * @param[in] trap_group              - User trap group ID
 * @param[in] trap_group_attributes_p - Trap group attributes
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL output parameter given
 *         SX_STATUS_PARAM_ERROR - Invalid parameter
 */
sx_status_t host_ifc_spectrum_validation_trap_group_set(sx_swid_id_t                swid,
                                                        sx_trap_group_t             trap_group,
                                                        sx_trap_group_attributes_t *trap_group_attributes_p);

/**
 *  This function unset the trap group in the local DB and in the device.
 *  The trap group properties and HW trap group ID before unset will be returned.
 *  Note: This function should only be used on SPECTRUM/2 devices.
 *
 * @param[in] swid                     - SWID
 * @param[in] trap_group	           - user trap group ID
 * @param[out] trap_group_attributes_p - trap group properties
 * @param[out] hw_trap_group_p         - HW trap group ID
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL output parameter given
 *         SX_STATUS_ERROR - general error
 */

sx_status_t host_ifc_spectrum_trap_group_unset(sx_swid_id_t                swid,
                                               sx_trap_group_t             trap_group,
                                               sx_trap_group_attributes_t *trap_group_attributes_p,
                                               uint32_t                   *hw_trap_group_p);

/**
 *  This function sets the trap group in the local DB.
 *  Note: This function should only be used on SwitchX and SwitchX-2 devices.
 *
 * @param[in] swid                    - SWID
 * @param[in] trap_group	          - user trap group ID
 * @param[in] trap_group_attributes_p - Trap group attributes
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL output parameter given
 *         SX_STATUS_ENTRY_ALREADY_BOUND - HW trap group already bound
 *         SX_STATUS_ERROR - general error
 */
sx_status_t host_ifc_sx_trap_group_set(sx_swid_id_t                swid,
                                       sx_trap_group_t             trap_group,
                                       sx_trap_group_attributes_t *trap_group_attributes_p);

/**
 *  This function sets the trap group in the local DB.
 *  Note: This function should only be used on Quantum devices.
 *
 * @param[in] swid                    - SWID
 * @param[in] trap_group	          - user trap group ID
 * @param[in] trap_group_attributes_p - Trap group attributes
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL output parameter given
 *         SX_STATUS_ENTRY_ALREADY_BOUND - HW trap group already bound
 *         SX_STATUS_ERROR - general error
 */
sx_status_t host_ifc_quantum_trap_group_set(sx_swid_id_t                swid,
                                            sx_trap_group_t             trap_group,
                                            sx_trap_group_attributes_t *trap_group_attributes_p);
/**
 *  This function unsets the trap group in the local DB.
 *  Note: This function should only be used on Quantum devices.
 *
 * @param[in] swid                     - SWID
 * @param[in] trap_group	           - user trap group ID
 * @param[out] trap_group_attributes_p - trap group properties
 * @param[out] hw_trap_group_p         - HW trap group ID
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL output parameter given
 *         SX_STATUS_ENTRY_ALREADY_BOUND - HW trap group already bound
 *         SX_STATUS_ERROR - general error
 */
sx_status_t host_ifc_quantum_trap_group_unset(sx_swid_id_t                swid,
                                              sx_trap_group_t             trap_group,
                                              sx_trap_group_attributes_t *trap_group_attributes_p,
                                              uint32_t                   *hw_trap_group_p);
/**
 *  This function initializes the EMAD HW trap group.
 *  Note: This function should only be called on SPECTRUM devices.
 *
 * @param[in] dev_info		  - device info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_spectrum_init_hw_trap_groups(sx_device_info_t *dev_info);

/**
 *  This function initializes the priority groups in the local host interface
 *  DB, and the rate limiter.
 *  Note: This function should only be called on SwitchX and SwitchX-2 devices.
 *
 * @param[in] pci_profile		  - PCI profile info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_sx_init_prio_group(sx_api_pci_profile_t *pci_profile);

/**
 *  This function initializes the rate limiter on SPECTRUM devices. There are
 *  no priority groups to be initialized at this point in the local DB.
 *  Note: This function should only be called on SPECTRUM devices.
 *
 * @param[in] pci_profile		  - PCI profile info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_spectrum_init_prio_group(sx_api_pci_profile_t *pci_profile);

/**
 *  This function checks the validity of the PCI profile.
 *  Note: This function should only be called on SPECTRUM devices.
 *
 * @param[in] pci_profile         - PCI profile info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_spectrum_validate_pci_profile(sx_api_pci_profile_t *pci_profile);

/**
 *  This function sets the default trap groups and trap IDs.
 *  Note: This function should only be called on SwitchX and SwitchX-2 devices.
 *
 * @param[in] pci_profile		  - PCI profile info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_sx_default_traps_set(sx_api_pci_profile_t *pci_profile);

/**
 *  This function sets the default trap groups and trap IDs.
 *  Note: This function should only be called on SPECTRUM devices.
 *
 * @param[in] pci_profile		  - PCI profile info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_spectrum_default_traps_set(sx_api_pci_profile_t *pci_profile);

/**
 *  This function sets the default trap groups and trap IDs on Spectrum2.
 *
 * @param[in] pci_profile         - PCI profile info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_default_traps_set_spectrum2(sx_api_pci_profile_t *pci_profile_p);

/**
 *  This function sets the default trap groups and trap IDs on Spectrum3.
 *
 * @param[in] pci_profile         - PCI profile info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_default_traps_set_spectrum3(sx_api_pci_profile_t *pci_profile_p);


/**
 *  This function sets the default trap groups and trap IDs on Spectrum4 and up.
 *
 * @param[in] pci_profile         - PCI profile info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_default_traps_set_spectrum4(sx_api_pci_profile_t *pci_profile_p);

/**
 *  This function sets the default trap groups and trap IDs on Spectrum5 (reduced set from Spectrum4).
 *
 * @param[in] pci_profile         - PCI profile info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_default_traps_set_spectrum5(sx_api_pci_profile_t *pci_profile_p);

/**
 *  This function return the number of the HW trap group in SX.
 *  Note: This function should only be called on SwitchX and SwitchX-2 devices.
 *
 * @param[in] hw_trap_group_num_p  - Number of HW trap group
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_sx_hw_trap_group_num_get(uint32_t *hw_trap_group_num_p);

/**
 *  This function return the number of the HW trap group in Spectrum.
 *  Note: This function should only be called on SPECTRUM devices.
 *
 * @param[in] hw_trap_group_num_p  - Number of HW trap group
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_spectrum_hw_trap_group_num_get(uint32_t *hw_trap_group_num_p);

/**
 *  This function return the number of the HW trap group.
 *  Wrapper for host_ifc_hw_trap_group_num_get_cb
 *
 * @param[in] hw_trap_group_num_p  - Number of HW trap group
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_hw_trap_group_num_get(uint32_t *hw_trap_group_num_p);

/**
 *  This function sets a trap ID and its properties in the HPKT register,
 *  but only if the HPKT will accept this trap ID.
 *  Note: This function should only be called on SwitchX and SwitchX-2 devices.
 *
 * @param[in] trap_id		                - trap ID to be set
 * @param[in] trap_action			- trap action to be set
 * @param[in] hw_trap_group			- HW trap group to which trap ID is set
 * @param[in] control_type			- control type of trap ID
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_sx_handle_hpkt(sx_trap_id_t       trap_id,
                                    uint32_t           hw_trap_id,
                                    sx_trap_action_t  *trap_action,
                                    uint32_t          *hw_trap_group,
                                    sx_control_type_t *control_type);

/**
 *  This function sets a trap ID and its properties in the HPKT register,
 *  but only if the HPKT will accept this trap ID.
 *  Note: This function should only be called on SPECTRUM devices.
 *
 * @param[in] trap_id		                - trap ID to be set
 * @param[in] trap_action			- trap action to be set
 * @param[in] hw_trap_group			- HW trap group to which trap ID is set
 * @param[in] control_type			- control type of trap ID
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_spectrum_handle_hpkt(sx_trap_id_t       trap_id,
                                          uint32_t           hw_trap_id,
                                          sx_trap_action_t  *trap_action,
                                          uint32_t          *hw_trap_group,
                                          sx_control_type_t *control_type);
/**
 *  This function init virtual traps table for switchx.
 *
 * @param[in] trap_action - trap action
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_vtrap_init_switchx(void);

/**
 *  This function init virtual traps table for spectrum.
 *
 * @param[in] trap_action - trap action
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_vtrap_init_spectrum(void);

/**
 *  This function binds/unbinds a policer to a trap priority.
 *  The policer type must be a global slow policer.
 *
 * @param[in] cmd              - BIND/UNBIND.
 * @param[in] swid             - Switch ID.
 * @param[in] trap_group    - Trap group .
 * @param[in] policer_id       - Policer ID.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_NULL if any input parameters is null
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_MEMORY_ERROR error handling memory
 * @return SX_STATUS_NO_RESOURCES device was not opened
 */
sx_status_t host_ifc_policer_bind_set(const sx_access_cmd_t    cmd,
                                      const sx_swid_t          swid,
                                      const sx_trap_priority_t trap_group,
                                      const sx_policer_id_t    policer_id);

sx_status_t sx_host_ifc_policer_bind_set(const sx_access_cmd_t    cmd,
                                         const sx_swid_id_t       swid,
                                         const sx_trap_priority_t trap_group,
                                         const sx_policer_id_t    policer_id);

sx_status_t sdk_host_ifc_policer_bind_set(const sx_access_cmd_t    cmd,
                                          const sx_swid_id_t       swid,
                                          const sx_trap_priority_t trap_group,
                                          const sx_policer_id_t    policer_id);

sx_status_t sx_host_ifc_policer_bind_get(const sx_swid_id_t       swid,
                                         const sx_trap_priority_t trap_group,
                                         sx_policer_id_t         *policer_id_p);

sx_status_t sdk_host_ifc_policer_bind_get(const sx_swid_id_t       swid,
                                          const sx_trap_priority_t trap_group,
                                          sx_policer_id_t         *policer_id_p);

sx_status_t host_ifc_ecc_stats_init_spectrum(void);

sx_status_t host_ifc_handle_htgt(sx_device_id_t                      device_id,
                                 sx_swid_id_t                        swid,
                                 sx_trap_group_t                     trap_group,
                                 sxd_host_interface_path_type_e     *path_type_p,
                                 sxd_host_interface_path_t          *host_path_p,
                                 boolean_t                          *policer_enabled_p,
                                 sx_policer_id_t                    *policer_id_p,
                                 sx_trap_priority_t                 *priority_p,
                                 sxd_host_interface_mirror_action_t *mirror_action_p,
                                 sx_span_session_id_int_t           *mirror_agent_p,
                                 sx_span_probability_rate_t         *mirror_probability_rate_p);

sx_status_t sdk_host_ifc_handle_htgt(sx_device_id_t                      device_id,
                                     sx_swid_id_t                        swid,
                                     sx_trap_group_t                     trap_group,
                                     sxd_host_interface_path_type_e     *path_type_p,
                                     sxd_host_interface_path_t          *host_path_p,
                                     boolean_t                          *policer_enabled_p,
                                     sx_policer_id_t                    *policer_id_p,
                                     sx_trap_priority_t                 *priority_p,
                                     sxd_host_interface_mirror_action_t *mirror_action_p,
                                     sx_span_session_id_int_t           *mirror_agent_p,
                                     sx_span_probability_rate_t         *mirror_probability_rate_p);

sx_status_t sx_host_ifc_handle_htgt(sx_device_id_t                      device_id,
                                    sx_swid_id_t                        swid,
                                    sx_trap_group_t                     trap_group,
                                    sxd_host_interface_path_type_e     *path_type_p,
                                    sxd_host_interface_path_t          *host_path_p,
                                    boolean_t                          *policer_enabled_p,
                                    sx_policer_id_t                    *policer_id_p,
                                    sx_trap_priority_t                 *priority_p,
                                    sxd_host_interface_mirror_action_t *mirror_action_p,
                                    sx_span_session_id_int_t           *mirror_agent_p,
                                    sx_span_probability_rate_t         *mirror_probability_rate_p);

sx_status_t host_ifc_check_trap_id_implicitly_set_by_sdk(sx_trap_id_t trap_id);

sx_status_t host_ifc_trap_truncate_profile_get_spectrum4(const sx_access_cmd_t               cmd,
                                                         const sx_trap_truncate_profile_id_t trunc_profile_id,
                                                         sx_trap_truncate_profile_cfg_t     *trunc_profile_cfg_p);
sx_status_t host_ifc_trap_truncate_profile_set_spectrum4(const sx_access_cmd_t                 cmd,
                                                         const sx_trap_truncate_profile_id_t   trunc_profile_id,
                                                         const sx_trap_truncate_profile_cfg_t *trunc_profile_cfg_p);
#endif /* HOST_INTERFACE_COMMON_H_ */
