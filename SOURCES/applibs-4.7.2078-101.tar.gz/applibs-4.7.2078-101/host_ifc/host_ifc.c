/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#include <complib/cl_spinlock.h>
#include <complib/cl_event.h>
#include <complib/cl_thread.h>
#include <complib/cl_mem.h>
#include <complib/cl_byteswap.h>
#include <complib/cl_shared_memory.h>
#include <complib/sx_trace_cbuff.h>
#include <complib/cl_bitops.h>
#include <complib/cl_dbg.h>
#include "complib/cl_fcntl.h"

#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_emad_parser.h>

#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <sx/utils/bit_vector.h>
#include <sx/utils/debug_cmd.h>

#include "host_ifc.h"
#include "host_ifc_db.h"
#include "trap_id.h"
#include "sx/sdk/sx_dev.h"
#include "sx_core/sx_core_api.h"
#include "ethl2/port.h"
#include "ethl2/brg.h"
#include "ethl2/port_db.h"
#include "utils/sx_adviser.h"
#include "utils/port_type_validate.h"
#include "ethl2/cos.h"
#include "ethl2/topo_db.h"
#include "ethl2/fdb_src_miss.h"
#include "policer/policer.h"
#include "policer/sdk_policer.h"
#include "policer_lib/policer_common.h"
#include "../policer/policer_manager.h"
#include "policer/policer_db.h"
#include "span/span_db.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "dbg/dbg.h"
#include <include/resource_manager/resource_manager.h>
#include "resource_manager/resource_manager_notifications.h"
#include "ethl2/brg.h"
#include "ethl2/port_uc_route.h"
#include "tunnel/hwi/tunnel_impl.h"
#include "issu/issu.h"
#include "sx_mgmt_lib/mgmt_lib_common.h"
#include "acl/flex_acl_db.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "bulk_counter/bulk_counter.h"
#include "stateful_db/stateful_db.h"
#include "tele/hwi/tele_impl.h"
#include "sx_api_utils/sniffer/sniffer.h"

#undef __MODULE__
#define __MODULE__ HOST_INTERFACE

#define PACK_SUFFIX __attribute__((packed))
/************************************************
 *  Global variables
 ***********************************************/
extern rm_resources_t   rm_resource_global;
extern sx_brg_context_t brg_context;

/************************************************
 *  Local variables
 ***********************************************/

static sx_add_intern_job_cb __add_internal_job_cb_s = NULL;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t                           __is_initialized_s = FALSE;
static sx_api_pci_profile_t                __pci_profile_s;
static int                                 __sx_event_fd;
static hwi_host_ifc_ops_t                  g_hwd_ops;
static boolean_t                           g_hwd_ops_params_registered = FALSE;
static host_ifc_trap_group_allocate_mode_e g_trap_group_allocate_mode = HOST_IFC_TRAP_GROUP_ALLOCATE_MODE_INVALID_E;

typedef struct timer_thread_param {
    sxd_handle sxd_h;
} timer_thread_param_t;

typedef struct parsed_ipac_event {
    sx_event_port_profile_apply_done_t port_profile_apply_done_event;
    uint16_t                           error_entry_index;
} parsed_ipac_event_t;

static parsed_ipac_event_t s_parsed_ipac_event;

typedef struct parsed_fsed_info {
    uint32_t translated_entries_num;
} parsed_fsed_info_t;

static parsed_fsed_info_t __fsed_info = {0};

cl_thread_t                 timer_thread_id;
cl_thread_t                 recv_thread_id;
static int                  is_timer_threads_and_event_created_s = 0;
static int                  stop_event_thread_s = 0;
static timer_thread_param_t ev_thread_params_s;
boolean_t                   event_timer_handler_exit_signal_issued = FALSE;
boolean_t                   recv_events_handler_exit_signal_issued = FALSE;
boolean_t                   host_ifc_event_timer_handler_thread_init_called = FALSE;
sxd_handle                  sw_event_sxd_h;
static cl_spinlock_t        host_ifc_state_lock_s;
static int                  monitor_trap_groups_count = 0;

#define FW_SOS_LOG_MAX_SIZE  256
#define FW_SOS_IRON_RISC     1
#define FW_SOS_EXECUTED_EMAD 1
#define FW_SOS_TEST          0x1

#define TRAP_GROUP_ID_MAX                63
#define SX_CONTROL_SX_TRAP_GROUP         SX_TRAP_PRIORITY_CRITICAL
#define SX_CONTROL_SPECTRUM_TRAP_PRIO    (rm_resource_global.trap_group_priority_max)
#define SX_SPECTRUM_MIRROR_TRAP_PRIO     (rm_resource_global.trap_group_priority_max)     /* don't care, any value OK */
#define SX_SPECTRUM_ACCUFLOW_TRAP_PRIO   (rm_resource_global.trap_group_priority_max)     /* don't care, any value OK */
#define SX_SPECTRUM_MOCS_TRAP_PRIO       (rm_resource_global.trap_group_priority_max)     /* don't care, any value OK */
#define SX_IB_QP1_TRAP_GROUP             3
#define SX_IB_OTHER_QP_TRAP_GROUP        1
#define EVENT_TIMER_TICK_IN_MSEC         100
#define EVENT_TIMEOUT_IN_TICKS_TIMER_1   1 /* EVENT_TIMER_TICK_IN_MSEC*/
#define EVENT_TIMEOUT_IN_TICKS_TIMER_2   (2 * EVENT_TIMER_TICK_IN_MSEC)
#define EVENT_TIMEOUT_IN_TICKS_TIMER_3   (10 * EVENT_TIMER_TICK_IN_MSEC)
#define BILLION                          1000000000L
#define SX_MAX_MONITOR_TRAP_GROUPS_COUNT 5

#define SX_CPU_TCLASS_TRAP_GROUP_0 8
#define SX_CPU_TCLASS_TRAP_GROUP_1 9
#define SX_CPU_TCLASS_TRAP_GROUP_2 10
#define SX_CPU_TCLASS_TRAP_GROUP_3 11

#define TRAP_ID_2_TRAP_TYPE(trap_id)                         \
    (((trap_id) < ((NUM_HW_SYNDROMES)-(NUM_SW_SYNDROMES))) ? \
     HOST_IFC_TRAP_TYPE_PACKET :                             \
     HOST_IFC_TRAP_TYPE_EVENT)

#define DECREMENT_CLEAR_SNAPSHOT(dst_cnt, snapshot_cnt) \
    if ((dst_cnt) < (snapshot_cnt)) { (dst_cnt) = 0; }  \
    else { (dst_cnt) -= (snapshot_cnt); }

#define TRAP_GROUP_ID_MAX_CHECK_MAX(trap_id) (trap_id <= TRAP_GROUP_ID_MAX)
#define TRAP_ACTION_DISCARD(trap_action)        \
    ((trap_action == SX_TRAP_ACTION_DISCARD) || \
     (trap_action == SX_TRAP_ACTION_SOFT_DISCARD))

#define STRLEN_UINT16 6 /*strlen of a uint16 plus 1 space*/

typedef enum ev_handling_mode {
    FAST_E,
    MEDIUM_E,
    SLOW_E
} ev_handling_mode_e;

typedef struct port_event {
    int                  type;
    int                  timeout_in_ticks;
    ev_handling_mode_e   handling_mode;
    struct timespec      timestamp;
    int                  log_port;
    sx_port_oper_state_t last_oper_state;
    sx_port_cntr_t       state_change_count;
} port_event_t;

typedef struct port_module_event {
    int                    timeout_in_ticks;
    ev_handling_mode_e     handling_mode;
    struct timespec        timestamp;
    sx_dev_id_t            dev_id;
    int                    module_id;
    sx_slot_id_t           slot_id;
    sx_port_module_state_t last_oper_state;
    boolean_t              event_disabled;
} port_module_event_t;

typedef struct emad_pmpe_reg_fmt {
    uint8_t  slot_index;
    uint8_t  module;
    uint8_t  reserved2;
    uint8_t  module_status;
    uint16_t reserved3;
    uint8_t  error_type;
    uint8_t  reserved4[9];
} PACK_SUFFIX emad_pmpe_reg_fmt_t;

port_event_t port_ev_arr[RM_API_LOCAL_PORT_MAX + 1];

#define __SX_LOG_EXIT(SX_STATUS) __sx_log_exit(SX_STATUS, __func__)

static bit_vector_t                      __bitmap_valid_trap_group = NULL;
static bit_vector_t                      __bitmap_valid_trap_id = NULL;
static sx_host_ifc_trap_id_counters_t    __clear_snapshot_trap[SX_TRAP_ID_MAX + 1];
static sx_host_ifc_trap_group_counters_t __clear_snapshot_group[TRAP_GROUP_ID_MAX + 1];
static sx_host_ifc_global_counters_t     __clear_snapshot_global;
/*
 * Currently there is no FW design about device_index and slot_index in MECCC, we don't know the valid ranges for device_index and slot_index.
 * FW always returns the ECC statistics for device_index 0 and slot_index 0, so here we only define a single software cache for device_index 0 and slot_index 0.
 * If FW supports multiple device_index/slot_index in the future, then we need to define the software cache for all possible combinations of device_index/slot_index.
 */
static sx_mgmt_ecc_stats_t __ecc_stats;
static boolean_t           __ecc_stats_initialized = FALSE;
static uint64_t            __pude_err_cnt = 0;

#define CAUSE_OFFSET_MASK 0x1F


/************************************************
 *  Local function declarations
 ***********************************************/
static void __host_ifc_resume_timer_thread(void *args);
static sx_status_t __host_ifc_open_sxd_for_event_recv(sxd_handle* sxd_h);
static sx_status_t __host_ifc_sx_set_eth_default_traps(sx_swid_t swid);
static sx_status_t __host_ifc_spectrum_set_eth_default_traps(sx_swid_t swid,
                                                             uint32_t  control_trap_group,
                                                             uint32_t  mirror_trap_group,
                                                             uint32_t  mocs_trap_group);
static sx_status_t __host_ifc_sx_set_ib_default_traps(sx_swid_t swid);
static void __host_ifc_recv_events_handler(void* args);
static sx_status_t __host_ifc_listener_set(sx_access_cmd_t        cmd,
                                           sxd_handle             handle,
                                           sx_swid_t              swid,
                                           sx_trap_id_t           trap_id,
                                           sx_user_channel_type_t channel_type);
static sx_status_t __handle_hpkt(uint32_t  trap_id,
                                 uint32_t *action_p,
                                 uint32_t *group_p,
                                 uint32_t *control_p,
                                 boolean_t trunc_en,
                                 uint8_t   trunc_prof);
static sx_status_t __handle_hcap(uint8_t *max_num_cpu_tclass,
                                 uint8_t *max_num_trap_groups,
                                 uint8_t *max_num_dr_paths);
static sx_status_t __host_ifc_hcap_get(uint8_t *max_num_cpu_tclass,
                                       uint8_t *max_num_trap_groups,
                                       uint8_t *max_num_dr_paths);
static sx_status_t __handle_htgt(sx_device_id_t                      device_id,
                                 sx_swid_id_t                        swid_id,
                                 sx_hw_trap_group_e                  trap_group,
                                 sxd_host_interface_path_type_e     *path_type_p,
                                 sxd_host_interface_path_t          *host_path_p,
                                 boolean_t                          *policer_enabled_p,
                                 sx_policer_id_t                    *policer_id_p,
                                 sx_trap_priority_t                 *priority_p,
                                 sxd_host_interface_mirror_action_t *mirror_action_p,
                                 sx_span_session_id_int_t           *mirror_agent_p,
                                 sx_span_probability_rate_t         *mirror_probability_rate_p);
static sx_status_t __sx_log_exit(sx_status_t rc,
                                 const char *func_name);
static sx_status_t __host_ifc_init_vtraps(void);
static sx_status_t __host_ifc_device_read_capabilities(sx_device_id_t device_id);
static sx_status_t __host_ifc_device_add_callback(adviser_event_e event,
                                                  void           *param);
static sx_status_t __host_ifc_sdk_client_close_callback(adviser_event_e event,
                                                        void           *param);
static sx_status_t __host_ifc_device_add(sx_device_info_t *dev_info);
static sx_status_t __host_ifc_trap_group_2_trap_prio(sx_hw_trap_group_e  trap_group,
                                                     sx_trap_priority_t *trap_priority);
static sx_status_t __host_ifc_critical_traps_set(sx_api_pci_profile_t *pci_profile);
static sx_status_t __host_ifc_init_prio_group(sx_api_pci_profile_t *pci_profile);
static sx_status_t __host_ifc_device_add_hw_trap_groups(sx_device_id_t device_id);
static sx_status_t __host_ifc_device_add_hw_trap_groups_logic(sx_device_id_t device_id,
                                                              uint32_t       num_trap_groups);
static sx_status_t __host_ifc_trap_id_set_to_hw_trap_group(sx_swid_t swid,
                                                           sx_trap_id_t trap_id, uint32_t hw_trap_group,
                                                           sx_trap_action_t trap_action);
static sx_status_t __host_ifc_trap_group_unset_impl(sx_swid_id_t                swid,
                                                    sx_trap_group_t             trap_group,
                                                    sx_trap_group_attributes_t *trap_group_attributes_p,
                                                    uint32_t                   *hw_trap_group_p);
static sx_status_t __host_ifc_sx_hw_trap_group_set(sx_swid_t swid,
                                                   uint32_t hw_trap_group, sx_trap_priority_t trap_priority,
                                                   sx_truncate_mode_t truncate_mode, sx_truncate_size_t truncate_size,
                                                   sx_control_type_t control_type);
static sx_status_t __host_ifc_spectrum_hw_trap_group_set(sx_swid_t          swid,
                                                         uint32_t           hw_trap_group,
                                                         sx_trap_priority_t trap_priority,
                                                         sx_truncate_mode_t truncate_mode,
                                                         sx_truncate_size_t truncate_size,
                                                         sx_control_type_t  control_type);
static sx_status_t __host_ifc_spectrum_hw_trap_group_set_null(sx_swid_t          swid,
                                                              uint32_t           hw_trap_group,
                                                              sx_trap_priority_t trap_priority,
                                                              sx_control_type_t  control_type);
static sx_status_t __host_ifc_hw_trap_group_set_logic(sx_swid_t          swid,
                                                      uint32_t           hw_trap_group,
                                                      sx_trap_priority_t trap_priority,
                                                      sx_truncate_mode_t truncate_mode,
                                                      sx_truncate_size_t truncate_size,
                                                      sx_control_type_t  control_type,
                                                      uint8_t            rdq,
                                                      uint8_t            cpu_tclass);
static sx_status_t __host_ifc_hw_trap_group_set_logic_null(sx_swid_t          swid,
                                                           uint32_t           hw_trap_group,
                                                           sx_trap_priority_t trap_priority,
                                                           sx_control_type_t  control_type);
static sx_status_t __validate_trap_control_allowed_for_trap_group(sx_swid_t         swid,
                                                                  sx_trap_group_t   trap_group,
                                                                  sx_control_type_t control_type);
static sx_status_t __host_ifc_validate_pci_profile(sx_api_pci_profile_t *pci_profile);
static void __host_ifc_close_threads(void);
static sx_status_t __host_ifc_is_trap_group_associated(sx_trap_group_t trap_group,
                                                       boolean_t      *is_associated_p,
                                                       sx_trap_id_t   *trap_id_p);
static sx_status_t __user_channel_filter_key_validate(const sx_host_ifc_filter_key_t *filter_key_p,
                                                      const sx_user_channel_t        *user_channel_p);
static sx_status_t __trap_id_channel_filter_vtrap_validate(sx_swid_t                swid,
                                                           sx_trap_id_t             vtrap,
                                                           const sx_user_channel_t *user_channel_p);
static sx_status_t __trap_group_allocate_mode_set(sx_access_cmd_t cmd);
static sx_status_t __host_ifc_default_actions_set(boolean_t     is_unset,
                                                  sx_trap_id_t* trap_id_to_unset_p,
                                                  boolean_t   * is_db_updated_p);
static sx_status_t __host_ifc_ecc_stats_init(void);

/**
 * This function validates the specified parameters before
 * passing them further.
 *
 * @parma[in]  swid        - The swid to configure
 * @param[in]  trap_id     - Trap ID to configure
 * @param[in]  trap_group  - Trap group to configure
 * @param[in]  trap_action - Trap action to configure
 *
 * @return sx_status_t
 */
static sx_status_t __host_ifc_trap_id_properties_validate(sx_swid_t        swid,
                                                          sx_trap_id_t     trap_id,
                                                          sx_trap_group_t  trap_group,
                                                          sx_trap_action_t trap_action);

/**
 * This function combines specified parameters into suitable
 * struct which will be used for the passing it to the SDK DB
 * and in the all the following flow till FW.
 *
 * @parma[in]  swid                     - The swid to configure
 * @param[in]  trap_id                  - Trap ID to configure
 * @param[in]  trap_group               - Trap group to configure
 * @param[in]  trap_action              - Trap action to configure
 * @param[out]  trap_id_properties_p    - Trap ID attributes
 * @param[out]  trap_group_properties_p - Trap group attributes
 *
 * @return sx_status_t
 */
static sx_status_t __host_ifc_trap_id_properties_prepare(sx_swid_t                         swid,
                                                         sx_trap_id_t                      trap_id,
                                                         sx_trap_group_t                   trap_group,
                                                         sx_trap_action_t                  trap_action,
                                                         host_ifc_trap_id_properties_t    *trap_id_properties_p,
                                                         host_ifc_trap_group_properties_t *trap_group_properties_p);
/**
 * This function can be used to see whether the specified trap
 * id already bound to the regular/monitor trap group.
 *
 * @param[in]  trap_id   - Trap ID to use.
 * @param[out]  is_regular_group_bound_p - is trap id associated
 *       to the regular trap group.
 * @param[out] is_monitor_group_bound_p  - is trap id associated
 *       to the monitor trap group.
 *
 * @return sx_status_t
 */
static sx_status_t __host_ifc_trap_id_is_group_associated_get(sx_trap_id_t trap_id,
                                                              boolean_t   *is_regular_group_bound_p,
                                                              boolean_t   *is_monitor_group_bound_p,
                                                              boolean_t   *is_tac_capable_group_bound_p);

/**
 * This function can be used to get the attributes of the
 * monitor or non monitor trap group which is associated with
 * the specified trap id.
 *
 * @param[in]  trap_id   - Trap ID to use.
 * @param[in]   is_monitor_trap_grp  - Type of trap group to be searched for
 * @param[out]  is_regular_group_bound_p - is trap id associated
 *       to the regular trap group.
 * @param[out] is_monitor_group_bound_p  - is trap id associated
 *       to the monitor trap group.
 *
 * @return sx_status_t
 */
static sx_status_t __host_ifc_trap_group_associated_attr_get(uint32_t            trap_id,
                                                             boolean_t           is_special_trap_grp,
                                                             sx_hw_trap_group_e *hw_trap_group_p,
                                                             sx_trap_action_t   *trap_action_p);

/**
 * This function is used to update the kernel with appropriated
 * command to start/stop using SW buffer for monitor trap group
 * what is required to support trap double registration.
 *
 * @param[in]  cmd           - command to execute
 * @param[in]  trap_id       - Trap ID to use.
 * @param[in]  hw_trap_group - HW trap group number.
 *
 * @return sx_status_t
 */
static sx_status_t __host_ifc_trap_id_update_driver(sx_access_cmd_t    cmd,
                                                    uint32_t           trap_id,
                                                    sx_hw_trap_group_e hw_trap_group);

/**
 * Get the trap group statistics from the kernel.
 * @param[in]  cmd - command to execute
 * @param[in]  hw_trap_group - HW trap group number
 * @param[in]  driver_handle - monitor driver handle
 * @param[out] group_stat_p - trap group statistics such as
 *       total number of discarded packets
 *
 * @return sx_status_t
 */
static sx_status_t __host_ifc_trap_group_stat_get_from_driver(sx_access_cmd_t                cmd,
                                                              sx_hw_trap_group_e             hw_trap_group,
                                                              sxd_handle                     driver_handle,
                                                              sx_host_ifc_trap_group_stat_t *group_stat_p);

static sx_status_t __host_ifc_trap_id_channel_filter_dump(dbg_dump_params_t *dbg_dump_params_p);

/************************************************
*  Function implementations
************************************************/
sx_status_t host_ifc_timer_threads_end_event_created_get(int *created)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(status = utils_check_pointer(created, "thread event created"))) {
        goto out;
    }
    *created = is_timer_threads_and_event_created_s;
out:
    return status;
}

static sx_status_t __host_ifc_init_prio_group(sx_api_pci_profile_t *pci_profile)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.host_ifc_init_prio_group_cb) {
        err = brg_context.spec_cb_g.host_ifc_init_prio_group_cb(pci_profile);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to initialize priority groups, return value: [%s]\n",
                       sx_status_str(err));
            goto out;
        }
    }

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_validate_pci_profile(sx_api_pci_profile_t *pci_profile)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.host_ifc_validate_pci_profile_cb) {
        err = brg_context.spec_cb_g.host_ifc_validate_pci_profile_cb(pci_profile);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("The PCI profile is invalid, return value: [%s]\n",
                       sx_status_str(err));
            goto out;
        }
    }

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_policer_bind_set(const sx_access_cmd_t    cmd,
                                      const sx_swid_id_t       swid,
                                      const sx_trap_priority_t trap_group,
                                      const sx_policer_id_t    policer_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.host_ifc_policer_bind_set_cb) {
        err = brg_context.spec_cb_g.host_ifc_policer_bind_set_cb(cmd,
                                                                 swid,
                                                                 trap_group,
                                                                 policer_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR(
                "Failed in host_ifc_policer_bind_set, [trap_group = %u, policer_id = %" PRIu64 "], return value: [%s]\n",
                trap_group,
                policer_id,
                sx_status_str(err));
            goto out;
        }
    }

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_policer_bind_get(const sx_swid_id_t       swid,
                                      const sx_trap_priority_t trap_group,
                                      sx_policer_id_t         *policer_id_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.host_ifc_policer_bind_get_cb) {
        err = brg_context.spec_cb_g.host_ifc_policer_bind_get_cb(swid,
                                                                 trap_group,
                                                                 policer_id_p);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
    }

out:
    return __SX_LOG_EXIT(err);
}


static sx_status_t __get_trap_group_policer_counter(sx_access_cmd_t        cmd,
                                                    sx_trap_group_t        trap_group,
                                                    sx_policer_counters_t *policer_counters)
{
    const int                        swid = 0; /* the only swid on Spectrum is 0 */
    host_ifc_trap_group_properties_t tg_properties;
    sx_policer_counters_clear_t      clear;
    boolean_t                        tg_is_configured;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         hw_trap_group;

    SX_LOG_ENTER();

    memset(policer_counters, 0, sizeof(*policer_counters));

    err = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get trap group %u HW trap group for swid %u, return value: [%s]\n",
                   trap_group, swid, sx_status_str(err));
        goto out;
    }

    err = host_ifc_db_trap_group_properties_get(swid, hw_trap_group, &tg_properties, &tg_is_configured);
    if ((err == SX_STATUS_SUCCESS) && tg_is_configured && tg_properties.policer_id_enabled) {
        err = sdk_policer_counters_get(tg_properties.policer_id, policer_counters);
        if ((err == SX_STATUS_SUCCESS) && (cmd == SX_ACCESS_CMD_READ_CLEAR)) {
            clear.clear_violation_counter = TRUE;
            sdk_policer_counters_clear_set(tg_properties.policer_id, &clear);
        }
    }
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __handle_hmon(sx_access_cmd_t                  cmd,
                                 host_ifc_wqe_overflow_cnt_type_e counter_type,
                                 struct ku_hmon_reg              *hmon_reg_data_arr,
                                 sxd_reg_meta_t                  *hmon_reg_meta_arr,
                                 length_t                         reserved_dev_info_arr_size,
                                 length_t                        *max_dev_id_p)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Get list of LEAF devices */
    status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(status));
        status = SX_STATUS_ERROR;
        goto out;
    }

    if (!dev_info_arr_size) {
        SX_LOG(SX_LOG_INFO, "Device list is empty (%s)\n", sx_status_str(status));
        goto out;
    }
    *max_dev_id_p = dev_info_arr_size;

    if (reserved_dev_info_arr_size < dev_info_arr_size) {
        SX_LOG_ERR("reserved_dev_info_arr_size [%d] is less than dev_info_arr_size [%d].\n",
                   reserved_dev_info_arr_size, dev_info_arr_size);
        status = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(hmon_reg_meta_arr[dev_idx]);
    hmon_reg_meta_arr[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    hmon_reg_meta_arr[dev_idx].access_cmd = SXD_ACCESS_CMD_GET;

    SX_MEM_CLR(hmon_reg_data_arr[dev_idx]);

    hmon_reg_data_arr[dev_idx].read_type = counter_type;
    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        hmon_reg_data_arr[dev_idx].clr = 1;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    status =
        sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HMON_E,
                                                                    hmon_reg_data_arr, hmon_reg_meta_arr,
                                                                    dev_info_arr_size, NULL, NULL));
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to query HMON: [%s].\n", sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t hwd_host_ifc_get_wqe_overflow_global_only_counter(sx_access_cmd_t              cmd,
                                                              host_ifc_wqe_overflow_cnt_t *tocpu_buffer_drop_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    uint32_t           rdq_idx = 0;
    struct ku_hmon_reg hmon_reg_data[SX_DEVICE_ID_COUNT];
    sxd_reg_meta_t     hmon_reg_meta[SX_DEVICE_ID_COUNT];
    length_t           dev_idx = 0;
    length_t           dev_info_arr_size = SX_DEV_ID_MAX;

    SX_LOG_ENTER();

    /* hmon_reg_data will be cleared per device inside the function below to reduce CPU load */
    status = __handle_hmon(cmd, HOST_IFC_WQE_OVERFLOW_REGULAR_CNT_E,
                           hmon_reg_data, hmon_reg_meta,
                           sizeof(hmon_reg_data), &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("HMON request failed [%s].\n", sx_status_str(status));
        status = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    /* Global counter */
    tocpu_buffer_drop_p->global = ((uint64_t)hmon_reg_data[dev_idx].wqe_overflow_low & TOCPU_BUFFER_DROP_CNT_MASK);
    if (hmon_reg_data[dev_idx].wqe_of_wrap == 1) {
        tocpu_buffer_drop_p->global += TOCPU_BUFFER_DROP_CNT_OVERFLOW_SUM;
    }

    /* Per RDQ counters are not supporting, returning 0 */
    for (rdq_idx = 0; rdq_idx < SXD_HMON_WQE_OVERFLOW_RDQ_NUM; rdq_idx++) {
        tocpu_buffer_drop_p->per_rdq[rdq_idx] = 0;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t hwd_host_ifc_get_wqe_overflow_counters(sx_access_cmd_t              cmd,
                                                   host_ifc_wqe_overflow_cnt_t *tocpu_buffer_drop_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    uint32_t           rdq_idx = 0;
    uint64_t           wqe_overflow_cnt = 0;
    uint64_t           global_wqe_overflow_cnt = 0;
    struct ku_hmon_reg hmon_reg_data[SX_DEVICE_ID_COUNT];
    sxd_reg_meta_t     hmon_reg_meta[SX_DEVICE_ID_COUNT];
    length_t           dev_idx = 0;
    length_t           dev_info_arr_size = SX_DEV_ID_MAX;

    SX_LOG_ENTER();

    status = __handle_hmon(cmd, HOST_IFC_WQE_OVERFLOW_REGULAR_CNT_E,
                           hmon_reg_data, hmon_reg_meta,
                           sizeof(hmon_reg_data), &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("HMON request failed [%s].\n", sx_status_str(status));
        status = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    /* Per RDQ counters */
    for (rdq_idx = 0; rdq_idx < SXD_HMON_WQE_OVERFLOW_RDQ_NUM; rdq_idx++) {
        wqe_overflow_cnt = hmon_reg_data[dev_idx].wqe_overflow_rdq[rdq_idx];
        tocpu_buffer_drop_p->per_rdq[rdq_idx] = wqe_overflow_cnt;
        global_wqe_overflow_cnt += wqe_overflow_cnt;
    }

    /* Global counter */
    tocpu_buffer_drop_p->global = global_wqe_overflow_cnt;
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t hwd_host_ifc_get_tac_wqe_overflow_counters(sx_access_cmd_t              cmd,
                                                       host_ifc_wqe_overflow_cnt_t *tocpu_buffer_drop_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    uint32_t           rdq_idx = 0;
    uint64_t           wqe_overflow_cnt = 0;
    uint64_t           global_wqe_overflow_cnt = 0;
    struct ku_hmon_reg hmon_reg_data[SX_DEVICE_ID_COUNT];
    sxd_reg_meta_t     hmon_reg_meta[SX_DEVICE_ID_COUNT];
    length_t           dev_idx = 0;
    length_t           dev_info_arr_size = SX_DEV_ID_MAX;

    SX_LOG_ENTER();

    /* hmon_reg_data will be cleared per device inside the function below to reduce CPU load */
    status = __handle_hmon(cmd, HOST_IFC_WQE_OVERFLOW_SUM_CNT_E,
                           hmon_reg_data, hmon_reg_meta,
                           sizeof(hmon_reg_data), &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("HMON request failed [%s].\n", sx_status_str(status));
        status = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    /* Per RDQ counters */
    for (rdq_idx = 0; rdq_idx < SXD_HMON_WQE_OVERFLOW_RDQ_NUM; rdq_idx++) {
        wqe_overflow_cnt = hmon_reg_data[dev_idx].wqe_overflow_rdq[rdq_idx];
        tocpu_buffer_drop_p->per_rdq[rdq_idx] = wqe_overflow_cnt;
        global_wqe_overflow_cnt += wqe_overflow_cnt;
    }

    /* Global counter */
    tocpu_buffer_drop_p->global = global_wqe_overflow_cnt;
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __get_wqe_overflow_counters(sx_access_cmd_t cmd, host_ifc_wqe_overflow_cnt_t *wqe_overflow_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (wqe_overflow_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("wqe_overflow_cnt_p is NULL.\n");
        goto out;
    }

    /* Get WQE overflow counters */
    if (g_hwd_ops.hwd_host_ifc_get_wqe_overflow_counters_pfn == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("g_hwd_ops.hwd_host_ifc_get_wqe_overflow_counters_pfn is NULL.\n");
        goto out;
    }

    err = g_hwd_ops.hwd_host_ifc_get_wqe_overflow_counters_pfn(cmd, wqe_overflow_cnt_p);

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t __host_ifc_trap_id_get_hpkt_group(sx_trap_id_t      trap_id,
                                              sx_swid_t         swid,
                                              sx_trap_action_t *hpkt_trap_action_p,
                                              sx_trap_group_t  *hpkt_trap_group_p)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    host_ifc_trap_id_properties_t trap_id_properties;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_id_properties);

    *hpkt_trap_group_p = SX_TRAP_GROUP_INVALID;

    rc = host_ifc_db_trap_id_properties_get(trap_id, &trap_id_properties);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't retrieve trap_id %d properties, rc = %s\n", trap_id, sx_status_str(rc));
        return rc;
    }
    *hpkt_trap_action_p = trap_id_properties.trap_action;

    rc = host_ifc_db_trap_group_reverse_map_get(swid, trap_id_properties.hw_trap_group,
                                                hpkt_trap_group_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("host_ifc_db_trap_group_reverse_map_get failed for hw trap group %d, rc = %s\n",
                   trap_id_properties.hw_trap_group, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __get_all_counters(sx_access_cmd_t                    cmd,
                                      const struct ku_get_counters      *ku_get_counters,
                                      sx_host_ifc_global_counters_t     *global,
                                      sx_host_ifc_trap_group_counters_t *per_group,
                                      sx_host_ifc_trap_id_counters_t    *per_trap_id)
{
    sx_trap_action_t            trap_action;
    sx_trap_group_t             trap_group, hw_trap_group = 0;
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sxd_status_t                sxd_rc = SXD_STATUS_SUCCESS;
    uint32_t                    hw_trap_id, trap_id;
    host_ifc_wqe_overflow_cnt_t wqe_overflow_cnt;
    sx_utils_status_t           utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR(wqe_overflow_cnt);

    err = __get_wqe_overflow_counters(cmd, &wqe_overflow_cnt);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Cannot get tocpu_buffer_drop counter [%s].\n", sx_status_str(err));
        goto out;
    }

    global->fromcpu_data_packet = ku_get_counters->fromcpu_data_packet;
    global->fromcpu_data_byte = ku_get_counters->fromcpu_data_byte;
    global->fromcpu_control_packet = ku_get_counters->fromcpu_control_packet;
    global->fromcpu_control_byte = ku_get_counters->fromcpu_control_byte;
    global->tocpu_buffer_drop = wqe_overflow_cnt.global;

    utils_err = bit_vector_find_first_set(__bitmap_valid_trap_id, &trap_id);
    while (utils_err != SX_UTILS_STATUS_ENTRY_NOT_FOUND) {
        CL_ASSERT(utils_err == SX_UTILS_STATUS_SUCCESS);

        err = __host_ifc_trap_id_get_hpkt_group(trap_id, 0 /* only swid on spectrum */, &trap_action, &trap_group);
        if ((err != SX_STATUS_SUCCESS) || (trap_group > SX_TRAP_GROUP_MAX)) {
            utils_err = bit_vector_find_next_set(__bitmap_valid_trap_id, &trap_id);
            continue;
        }

        /* Get hw trap id from virtual trap id */
        sxd_rc = sxd_dpt_vtrap_virt_to_hw_mapping_get(trap_id, &hw_trap_id);
        if (SXD_CHECK_FAIL(sxd_rc)) {
            SX_LOG_NTC("Failed in sxd_dpt_vtrap_virt_to_hw_mapping_get, trap id: [%u] , return value: [%s]\n",
                       trap_id,
                       SXD_STATUS_MSG(sxd_rc));
            utils_err = bit_vector_find_next_set(__bitmap_valid_trap_id, &trap_id);
            continue;
        }

        /* per trap_id counters */
        per_trap_id[trap_id].trap_id = trap_id;
        per_trap_id[trap_id].trap_group = trap_group;
        per_trap_id[trap_id].trap_type = TRAP_ID_2_TRAP_TYPE(hw_trap_id);

        if (per_trap_id[trap_id].trap_type == HOST_IFC_TRAP_TYPE_PACKET) {
            /* trap_id counters */
            per_trap_id[trap_id].u_trap_type.packet.tocpu_packet = ku_get_counters->trap_id_packet[hw_trap_id];
            per_trap_id[trap_id].u_trap_type.packet.tocpu_byte = ku_get_counters->trap_id_byte[hw_trap_id];

            /* global counters */
            global->tocpu_packet += ku_get_counters->trap_id_packet[hw_trap_id];
            global->tocpu_byte += ku_get_counters->trap_id_byte[hw_trap_id];
        } else { /* HOST_IFC_TRAP_TYPE_EVENT */
                 /* trap_id counters */
            per_trap_id[trap_id].u_trap_type.event.event_counter = ku_get_counters->trap_id_events[hw_trap_id];
            per_trap_id[trap_id].u_trap_type.event.drop_counter = ku_get_counters->trap_id_drops[hw_trap_id];
            /* trap_group counters */
            per_group[trap_group].event_counter += ku_get_counters->trap_id_events[hw_trap_id];

            /* global counters */
            global->event_counter += ku_get_counters->trap_id_events[hw_trap_id];
        }

        utils_err = bit_vector_find_next_set(__bitmap_valid_trap_id, &trap_id);
    }

    utils_err = bit_vector_find_first_set(__bitmap_valid_trap_group, &trap_group);
    while (utils_err != SX_UTILS_STATUS_ENTRY_NOT_FOUND) {
        CL_ASSERT(utils_err == SX_UTILS_STATUS_SUCCESS);

        per_group[trap_group].trap_group = trap_group;

        err = host_ifc_db_trap_group_map_get(0, trap_group, &hw_trap_group);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Cannot get hw_trap_group for trap_group (%d) [%s].\n", trap_group, sx_status_str(err));
            goto out;
        }
        if (hw_trap_group >= NUMBER_OF_RDQS) {
            SX_LOG_ERR("Invalid value of hw_trap_group (%d), trap_group (%d), max rdq (%d) [%s].\n",
                       hw_trap_group, trap_group, NUMBER_OF_RDQS, sx_status_str(err));
            goto out;
        }

        per_group[trap_group].tocpu_packet = ku_get_counters->trap_group_packet[hw_trap_group];
        per_group[trap_group].tocpu_byte = ku_get_counters->trap_group_byte[hw_trap_group];
        per_group[trap_group].tocpu_buffer_drop = wqe_overflow_cnt.per_rdq[hw_trap_group];

        err = __get_trap_group_policer_counter(cmd, trap_group, &per_group[trap_group].tocpu_drop_exceed_rate_packet);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get per trap group policer counters, [trap_group = %u]. err: %s\n",
                       trap_group, sx_status_str(err));
            goto out;
        }

        utils_err = bit_vector_find_next_set(__bitmap_valid_trap_group, &trap_group);
    }
out:
    SX_LOG_EXIT();
    return err;
}


static void __apply_counters_filter_trap_id_entry(sx_access_cmd_t                       cmd,
                                                  const sx_host_ifc_trap_id_counters_t* per_trap_id,
                                                  sx_host_ifc_counters_t               *host_ifc_cnt_p,
                                                  uint32_t                              trap_id,
                                                  uint32_t                             *idx_w_p,
                                                  boolean_t                             skip_invalid)
{
    sx_host_ifc_trap_id_counters_t new_snapshot;
    uint32_t                       idx_w;
    boolean_t                      is_valid;

    idx_w = *idx_w_p;

    if (bit_vector_get(__bitmap_valid_trap_id, trap_id, &is_valid) != SX_UTILS_STATUS_SUCCESS) {
        if (!skip_invalid) {
            memset(&host_ifc_cnt_p->trap_id_counters[idx_w], 0,
                   sizeof(sx_host_ifc_trap_id_counters_t));
            idx_w++;
        }
        SX_LOG_NTC("cannot get trap_id %u status. ignoring!\n", trap_id);
        goto out;
    }

    if (!is_valid) {
        if (!skip_invalid) {
            memset(&host_ifc_cnt_p->trap_id_counters[idx_w], 0,
                   sizeof(sx_host_ifc_trap_id_counters_t));
            idx_w++;
        } else {
            SX_LOG_NTC("trap_id %d is not configured. ignoring!\n", trap_id);
        }
        goto out;
    }

    memcpy(&host_ifc_cnt_p->trap_id_counters[idx_w],
           &per_trap_id[trap_id],
           sizeof(sx_host_ifc_trap_id_counters_t));

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        memcpy(&new_snapshot, &per_trap_id[trap_id], sizeof(new_snapshot));
    }

    if (host_ifc_cnt_p->trap_id_counters[idx_w].trap_type == HOST_IFC_TRAP_TYPE_EVENT) {
        DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->trap_id_counters[idx_w].u_trap_type.event.event_counter,
                                 __clear_snapshot_trap[trap_id].u_trap_type.event.event_counter);
    } else {
        CL_ASSERT(host_ifc_cnt_p->trap_id_counters[idx_w].trap_type == HOST_IFC_TRAP_TYPE_PACKET);
        DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->trap_id_counters[idx_w].u_trap_type.packet.tocpu_packet,
                                 __clear_snapshot_trap[trap_id].u_trap_type.packet.tocpu_packet);
        DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->trap_id_counters[idx_w].u_trap_type.packet.tocpu_byte,
                                 __clear_snapshot_trap[trap_id].u_trap_type.packet.tocpu_byte);
    }

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        memcpy(&__clear_snapshot_trap[trap_id], &new_snapshot, sizeof(__clear_snapshot_trap[trap_id]));
    }
    idx_w++;
out:
    *idx_w_p = idx_w;
}


static void __apply_counters_filter_trap_id_range(sx_access_cmd_t                       cmd,
                                                  const sx_host_ifc_counters_filter_t  *filter,
                                                  const sx_host_ifc_trap_id_counters_t* per_trap_id,
                                                  sx_host_ifc_counters_t               *host_ifc_cnt_p)
{
    uint32_t trap_id, trap_id_max, idx_w = 0;

    trap_id = filter->u_counter_type.trap_id_range.start;
    trap_id_max = filter->u_counter_type.trap_id_range.end + 1;


    for (; trap_id < trap_id_max; trap_id++) {
        __apply_counters_filter_trap_id_entry(cmd, per_trap_id, host_ifc_cnt_p, trap_id, &idx_w, FALSE);
    }
    host_ifc_cnt_p->trap_id_counters_cnt = trap_id_max - filter->u_counter_type.trap_id_range.start;
}


static void __apply_counters_filter_trap_id(sx_access_cmd_t                       cmd,
                                            const sx_host_ifc_counters_filter_t  *filter,
                                            const sx_host_ifc_trap_id_counters_t* per_trap_id,
                                            sx_host_ifc_counters_t               *host_ifc_cnt_p)
{
    uint32_t trap_id, idx_r, idx_w;

    for (idx_r = 0, idx_w = 0;
         idx_r < filter->u_counter_type.trap_id.trap_id_filter_cnt && idx_w < host_ifc_cnt_p->trap_id_counters_cnt;
         idx_r++) {
        trap_id = filter->u_counter_type.trap_id.trap_id_filter_list[idx_r];
        __apply_counters_filter_trap_id_entry(cmd, per_trap_id, host_ifc_cnt_p, trap_id, &idx_w, TRUE);
    }

    /* if trap_id_cnt == 0, user will get the number of active trap_id. otherwise, it holds the output array size */
    if (host_ifc_cnt_p->trap_id_counters_cnt == 0) {
        host_ifc_cnt_p->trap_id_counters_cnt = bit_vector_count(__bitmap_valid_trap_id);
    } else {
        host_ifc_cnt_p->trap_id_counters_cnt = idx_w;
    }
}


static sx_status_t __apply_counters_filter_trap_group_entry(sx_access_cmd_t                          cmd,
                                                            const sx_host_ifc_trap_group_counters_t* per_trap_group,
                                                            sx_host_ifc_counters_t                  *host_ifc_cnt_p,
                                                            uint32_t                                 group_id,
                                                            uint32_t                                *idx_w_p,
                                                            boolean_t                                skip_invalid)
{
    sx_host_ifc_trap_group_counters_t new_snapshot;
    boolean_t                         is_valid;
    uint32_t                          idx_w;
    sx_policer_counters_t             tocpu_drop_exceed_rate_packet;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    idx_w = *idx_w_p;

    if (bit_vector_get(__bitmap_valid_trap_group, group_id, &is_valid) != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_NTC("Cannot get trap_group %u status. ignoring!\n", group_id);
        if (!skip_invalid) {
            memset(&host_ifc_cnt_p->trap_group_counters[idx_w], 0,
                   sizeof(sx_host_ifc_trap_group_counters_t));
            idx_w++;
        }
        goto out;
    }

    if (!is_valid) {
        if (!skip_invalid) {
            memset(&host_ifc_cnt_p->trap_group_counters[idx_w], 0,
                   sizeof(sx_host_ifc_trap_group_counters_t));
            idx_w++;
        } else {
            SX_LOG_NTC("trap_group %d is not configured. ignoring!\n", group_id);
        }
        goto out;
    }

    memcpy(&host_ifc_cnt_p->trap_group_counters[idx_w],
           &per_trap_group[group_id],
           sizeof(sx_host_ifc_trap_group_counters_t));

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        memcpy(&new_snapshot, &per_trap_group[group_id], sizeof(new_snapshot));
    }

    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->trap_group_counters[idx_w].event_counter,
                             __clear_snapshot_group[group_id].event_counter);
    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->trap_group_counters[idx_w].tocpu_packet,
                             __clear_snapshot_group[group_id].tocpu_packet);
    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->trap_group_counters[idx_w].tocpu_byte,
                             __clear_snapshot_group[group_id].tocpu_byte);
    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->trap_group_counters[idx_w].tocpu_buffer_drop,
                             __clear_snapshot_group[group_id].tocpu_buffer_drop);

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        memcpy(&__clear_snapshot_group[group_id], &new_snapshot, sizeof(__clear_snapshot_group[group_id]));
        /* Clear Policier counters as well */
        err = __get_trap_group_policer_counter(cmd, group_id, &tocpu_drop_exceed_rate_packet);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to clear per trap group policer counters, [group_id = %u]. err: %s\n",
                       group_id, sx_status_str(err));
            goto out;
        }
    }

    idx_w++;
out:
    *idx_w_p = idx_w;
    return err;
}

static sx_status_t __apply_counters_filter_trap_group_range(sx_access_cmd_t                          cmd,
                                                            const sx_host_ifc_counters_filter_t     *filter,
                                                            const sx_host_ifc_trap_group_counters_t* per_trap_group,
                                                            sx_host_ifc_counters_t                  *host_ifc_cnt_p)
{
    uint32_t    group_id, max_group, idx_w = 0;
    sx_status_t err = SX_STATUS_SUCCESS;

    group_id = filter->u_counter_type.trap_group_range.start;
    max_group = filter->u_counter_type.trap_group_range.end + 1;

    for (; group_id < max_group; group_id++) {
        err = __apply_counters_filter_trap_group_entry(cmd, per_trap_group, host_ifc_cnt_p, group_id, &idx_w, FALSE);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
    }

    host_ifc_cnt_p->trap_group_counters_cnt = max_group - filter->u_counter_type.trap_group_range.start;

out:
    return err;
}

static sx_status_t __apply_counters_filter_trap_group(sx_access_cmd_t                          cmd,
                                                      const sx_host_ifc_counters_filter_t     *filter,
                                                      const sx_host_ifc_trap_group_counters_t* per_trap_group,
                                                      sx_host_ifc_counters_t                  *host_ifc_cnt_p)
{
    int         group_id;
    uint32_t    idx_r, idx_w;
    sx_status_t err = SX_STATUS_SUCCESS;

    for (idx_r = 0, idx_w = 0;
         idx_r < filter->u_counter_type.trap_group.trap_group_filter_cnt &&
         idx_w < host_ifc_cnt_p->trap_group_counters_cnt;
         idx_r++) {
        group_id = filter->u_counter_type.trap_group.trap_group_filter_list[idx_r];
        err = __apply_counters_filter_trap_group_entry(cmd, per_trap_group, host_ifc_cnt_p, group_id, &idx_w, TRUE);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
    }

    /* if group_cnt == 0, user will get the number of active groups. otherwise, it holds the output array size */
    if (host_ifc_cnt_p->trap_group_counters_cnt == 0) {
        host_ifc_cnt_p->trap_group_counters_cnt = bit_vector_count(__bitmap_valid_trap_group);
    } else {
        host_ifc_cnt_p->trap_group_counters_cnt = idx_w;
    }

out:
    return err;
}


static sx_status_t __apply_counters_filter(sx_access_cmd_t                          cmd,
                                           const sx_host_ifc_counters_filter_t     *filter_p,
                                           const sx_host_ifc_trap_group_counters_t* per_group,
                                           const sx_host_ifc_trap_id_counters_t   * per_trap_id,
                                           sx_host_ifc_counters_t                  *host_ifc_cnt_p)
{
    sx_host_ifc_global_counters_t        new_snapshot;
    sx_host_ifc_counters_filter_t        no_filter_group;
    sx_host_ifc_counters_filter_t        no_filter_trap_id;
    const sx_host_ifc_counters_filter_t* filter_group_p = NULL;
    const sx_host_ifc_counters_filter_t* filter_group_range_p = NULL;
    const sx_host_ifc_counters_filter_t* filter_trap_id_p = NULL;
    const sx_host_ifc_counters_filter_t* filter_trap_id_range_p = NULL;
    uint32_t                             trap_id, hw_trap_id, group_id;
    uint32_t                             idx_w;
    sx_utils_status_t                    utils_err;
    sxd_status_t                         sxd_rc = SXD_STATUS_SUCCESS;
    host_ifc_wqe_overflow_cnt_t          tocpu_buffer_drop;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(tocpu_buffer_drop);

    if (filter_p && (filter_p->counter_type == HOST_IFC_COUNTER_TYPE_TRAP_ID_E)) {
        filter_trap_id_p = filter_p;
    } else if (filter_p && (filter_p->counter_type == HOST_IFC_COUNTER_TYPE_TRAP_GROUP_E)) {
        filter_group_p = filter_p;
    } else if (filter_p && (filter_p->counter_type == HOST_IFC_COUNTER_TYPE_TRAP_GROUP_RANGE_E)) {
        filter_group_range_p = filter_p;
    } else if (filter_p && (filter_p->counter_type == HOST_IFC_COUNTER_TYPE_TRAP_ID_RANGE_E)) {
        filter_trap_id_range_p = filter_p;
    }

    if (filter_p == NULL) {
        filter_group_p = &no_filter_group;
        filter_trap_id_p = &no_filter_trap_id;

        /* build a filter for trap_id */
        no_filter_trap_id.counter_type = HOST_IFC_COUNTER_TYPE_TRAP_ID_E;
        idx_w = 0;

        utils_err = bit_vector_find_first_set(__bitmap_valid_trap_id, &hw_trap_id);
        /* coverity[example_checked] */
        while (utils_err != SX_UTILS_STATUS_ENTRY_NOT_FOUND && idx_w < host_ifc_cnt_p->trap_id_counters_cnt) {
            CL_ASSERT(utils_err == SX_UTILS_STATUS_SUCCESS);

            sxd_rc = sxd_dpt_vtrap_hw_to_virt_mapping_get(hw_trap_id, &trap_id);
            if (SXD_CHECK_FAIL(sxd_rc)) {
                SX_LOG_NTC("Failed in sxd_dpt_vtrap_hw_to_virt_mapping_get, hw_trap_id: [%u] , return value: [%s]\n",
                           hw_trap_id,
                           SXD_STATUS_MSG(sxd_rc));
                bit_vector_find_next_set(__bitmap_valid_trap_id, &hw_trap_id);
                continue;
            }

            no_filter_trap_id.u_counter_type.trap_id.trap_id_filter_list[idx_w++] = trap_id;
            utils_err = bit_vector_find_next_set(__bitmap_valid_trap_id, &hw_trap_id);
        }

        no_filter_trap_id.u_counter_type.trap_id.trap_id_filter_cnt = idx_w;

        /* build a filter for trap_group */
        no_filter_group.counter_type = HOST_IFC_COUNTER_TYPE_TRAP_GROUP_E;
        idx_w = 0;

        utils_err = bit_vector_find_first_set(__bitmap_valid_trap_group, &group_id);
        while (utils_err != SX_UTILS_STATUS_ENTRY_NOT_FOUND && idx_w < host_ifc_cnt_p->trap_group_counters_cnt) {
            CL_ASSERT(utils_err == SX_UTILS_STATUS_SUCCESS);
            no_filter_group.u_counter_type.trap_group.trap_group_filter_list[idx_w++] = group_id;
            utils_err = bit_vector_find_next_set(__bitmap_valid_trap_group, &group_id);
        }

        no_filter_group.u_counter_type.trap_group.trap_group_filter_cnt = idx_w;
    }

    if (filter_trap_id_range_p) {
        __apply_counters_filter_trap_id_range(cmd, filter_trap_id_range_p, per_trap_id, host_ifc_cnt_p);
    }

    if (filter_trap_id_p) {
        __apply_counters_filter_trap_id(cmd, filter_trap_id_p, per_trap_id, host_ifc_cnt_p);
    }

    if (filter_group_range_p) {
        err = __apply_counters_filter_trap_group_range(cmd, filter_group_range_p, per_group, host_ifc_cnt_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to apply trap group filter [%s].\n", sx_status_str(err));
            goto out;
        }
    }

    if (filter_group_p) {
        err = __apply_counters_filter_trap_group(cmd, filter_group_p, per_group, host_ifc_cnt_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to apply trap group filter [%s].\n", sx_status_str(err));
            goto out;
        }
    }

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        memcpy(&new_snapshot, &host_ifc_cnt_p->global_counters, sizeof(new_snapshot));
    }

    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->global_counters.event_counter,
                             __clear_snapshot_global.event_counter);
    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->global_counters.fromcpu_control_byte,
                             __clear_snapshot_global.fromcpu_control_byte);
    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->global_counters.fromcpu_control_packet,
                             __clear_snapshot_global.fromcpu_control_packet);
    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->global_counters.fromcpu_data_byte,
                             __clear_snapshot_global.fromcpu_data_byte);
    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->global_counters.fromcpu_data_packet,
                             __clear_snapshot_global.fromcpu_data_packet);
    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->global_counters.tocpu_buffer_drop,
                             __clear_snapshot_global.tocpu_buffer_drop);
    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->global_counters.tocpu_byte,
                             __clear_snapshot_global.tocpu_byte);
    DECREMENT_CLEAR_SNAPSHOT(host_ifc_cnt_p->global_counters.tocpu_packet,
                             __clear_snapshot_global.tocpu_packet);

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        memcpy(&__clear_snapshot_global, &new_snapshot, sizeof(__clear_snapshot_global));
        /* Clear CPU buffer drop counters */
        err = __get_wqe_overflow_counters(cmd, &tocpu_buffer_drop);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Clearing tocpu_buffer_drop [%s].\n", sx_status_str(err));
            goto out;
        }
    }
out:
    return err;
}


static sx_status_t __get_counters_from_driver(struct ku_get_counters *ku_get_counters)
{
    sxd_ctrl_pack_t ctrl_pack;
    int             sxd_err = SXD_STATUS_SUCCESS;

    memset(ku_get_counters, 0, sizeof(*ku_get_counters));
    memset(&ctrl_pack, 0, sizeof(ctrl_pack));

    ctrl_pack.cmd_body = (void*)ku_get_counters;
    ctrl_pack.ctrl_cmd = CTRL_CMD_GET_COUNTERS;
    sxd_err = sxd_ioctl(ev_thread_params_s.sxd_h, &ctrl_pack);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed in sxd_ioctl (set CTRL_CMD_GET_COUNTERS = FALSE) error %s\n", strerror(errno));
        return SX_STATUS_SXD_RETURNED_NON_ZERO;
    }

    return SX_STATUS_SUCCESS;
}

static int __pci_profile_get(sx_api_pci_profile_t* pci_profile)
{
    int sxd_err = SXD_STATUS_SUCCESS;

    sxd_err = sxd_access_reg_pci_profile_get(pci_profile);
    if (sxd_err != 0) {
        SX_LOG_ERR("%s: Failed to get pci profile in sx core \n", __func__);
        return SX_STATUS_SXD_RETURNED_NON_ZERO;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t host_ifc_counters_get(sx_access_cmd_t                      cmd,
                                  const sx_host_ifc_counters_filter_t *filter_p,
                                  sx_host_ifc_counters_t              *host_ifc_cnt_p)
{
    sx_host_ifc_trap_group_counters_t per_group[TRAP_GROUP_ID_MAX + 1];
    sx_host_ifc_trap_id_counters_t    per_trap_id[SX_TRAP_ID_MAX + 1];
    struct ku_get_counters            ku_get_counters;
    sx_status_t                       err = SX_STATUS_SUCCESS;


    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        err = SX_STATUS_CMD_UNPERMITTED;
        goto out;
    }

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    if (filter_p) {
        if ((filter_p->counter_type != HOST_IFC_COUNTER_TYPE_TRAP_ID_E) &&
            (filter_p->counter_type != HOST_IFC_COUNTER_TYPE_TRAP_GROUP_E) &&
            (filter_p->counter_type != HOST_IFC_COUNTER_TYPE_TRAP_GROUP_RANGE_E) &&
            (filter_p->counter_type != HOST_IFC_COUNTER_TYPE_TRAP_ID_RANGE_E)) {
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (filter_p->counter_type == HOST_IFC_COUNTER_TYPE_TRAP_ID_E) {
            if ((filter_p->u_counter_type.trap_id.trap_id_filter_cnt > SX_TRAP_ID_MAX) ||
                (filter_p->u_counter_type.trap_id.trap_id_filter_cnt > host_ifc_cnt_p->trap_id_counters_cnt)) {
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
        } else if (filter_p->counter_type == HOST_IFC_COUNTER_TYPE_TRAP_GROUP_E) {
            if ((filter_p->u_counter_type.trap_group.trap_group_filter_cnt > SX_TRAP_GROUP_MAX) ||
                (filter_p->u_counter_type.trap_group.trap_group_filter_cnt >
                 host_ifc_cnt_p->trap_group_counters_cnt)) {
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
        } else if (filter_p->counter_type == HOST_IFC_COUNTER_TYPE_TRAP_ID_RANGE_E) {
            if ((filter_p->u_counter_type.trap_id_range.end > SX_TRAP_ID_MAX) ||
                (filter_p->u_counter_type.trap_id_range.start < SX_TRAP_ID_MIN) ||
                (filter_p->u_counter_type.trap_id_range.start > filter_p->u_counter_type.trap_id_range.end) ||
                (((filter_p->u_counter_type.trap_id_range.end - filter_p->u_counter_type.trap_id_range.start) + 1) >
                 host_ifc_cnt_p->trap_id_counters_cnt)) {
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
        } else if (filter_p->counter_type == HOST_IFC_COUNTER_TYPE_TRAP_GROUP_RANGE_E) {
            if ((filter_p->u_counter_type.trap_group_range.end > SX_TRAP_GROUP_MAX) ||
                (filter_p->u_counter_type.trap_group_range.start > filter_p->u_counter_type.trap_group_range.end) ||
                (((filter_p->u_counter_type.trap_group_range.end -
                   filter_p->u_counter_type.trap_group_range.start) + 1) >
                 host_ifc_cnt_p->trap_group_counters_cnt)) {
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
        }
    }


    if ((host_ifc_cnt_p->trap_group_counters_cnt > SX_TRAP_GROUP_MAX) ||
        (host_ifc_cnt_p->trap_id_counters_cnt > SX_TRAP_ID_MAX)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = __get_counters_from_driver(&ku_get_counters);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    memset(per_group, 0, sizeof(per_group));
    memset(per_trap_id, 0, sizeof(per_trap_id));
    memset(&host_ifc_cnt_p->global_counters, 0, sizeof(host_ifc_cnt_p->global_counters));
    memset(&host_ifc_cnt_p->trap_group_counters, 0, sizeof(host_ifc_cnt_p->trap_group_counters));
    memset(&host_ifc_cnt_p->trap_id_counters, 0, sizeof(host_ifc_cnt_p->trap_id_counters));

    /* We need to first READ counters for all the trap groups and trapids.
     * Actual clear for trap group and trap ids present in filter in case of
     * SX_ACCESS_CMD_READ_CLEAR cmd is done when the filter is actually applied.
     */
    err = __get_all_counters(SX_ACCESS_CMD_READ,
                             &ku_get_counters,
                             &host_ifc_cnt_p->global_counters,
                             per_group,
                             per_trap_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get all counters.\n");
        goto out;
    }

    err = __apply_counters_filter(cmd,
                                  filter_p,
                                  per_group,
                                  per_trap_id,
                                  host_ifc_cnt_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to apply filters.\n");
        goto out;
    }

out:
    return err;
}

sx_status_t host_ifc_counters_get_wrapper(sx_access_cmd_t                      cmd,
                                          const sx_host_ifc_counters_filter_t *filter_p,
                                          sx_host_ifc_counters_t              *host_ifc_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.host_ifc_counters_get_cb != NULL) {
        rc = brg_context.spec_cb_g.host_ifc_counters_get_cb(cmd,
                                                            filter_p,
                                                            host_ifc_cnt_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("host_ifc_counters_get failed, for chip type %s, err = %s\n",
                       sx_chip_type_str((int)brg_context.spec_cb_g.dev_type), sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("host_ifc_counters_get is not supported for this chip type (%s), err = %s.\n",
                   sx_chip_type_str((int)brg_context.spec_cb_g.dev_type), sx_status_str(rc));
        goto out;
    }

out:
    return rc;
}

sx_status_t host_ifc_vtrap_init_switchx(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    int         i;

    for (i = 0; i <= SX_TRAP_ID_MAX; i++) {
        err = sxd_status_to_sx_status(sxd_dpt_vtrap_mapping_set(i, sx_host_ifc_virt_trap_to_sxd_trap_switchx[i]));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set sxd_dpt_vtrap_mapping, [vtrap = %u, trap = %u]"
                       "return value: [%s].\n",
                       i, sx_host_ifc_virt_trap_to_sxd_trap_switchx[i], sx_status_str(err));
        }
    }

    return err;
}

sx_status_t host_ifc_vtrap_init_spectrum(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    int         i;

    for (i = 0; i <= SX_TRAP_ID_MAX; i++) {
        err = sxd_status_to_sx_status(sxd_dpt_vtrap_mapping_set(i, sx_host_ifc_virt_trap_to_sxd_trap_spectrum[i]));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set sxd_dpt_vtrap_mapping, [vtrap = %u, trap = %u]"
                       "return value: [%s].\n",
                       i, sx_host_ifc_virt_trap_to_sxd_trap_spectrum[i], sx_status_str(err));
        }
    }

    return err;
}

static sx_status_t __host_ifc_init_vtraps(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.host_ifc_vtrap_init) {
        err = brg_context.spec_cb_g.host_ifc_vtrap_init();
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to init virtual traps, return value: [%s]\n",
                       sx_status_str(err));
            return err;
        }
    }

    return err;
}

static sx_status_t __host_ifc_listener_set(sx_access_cmd_t        cmd,
                                           sxd_handle             handle,
                                           sx_swid_t              swid,
                                           sx_trap_id_t           trap_id,
                                           sx_user_channel_type_t channel_type)
{
    struct ku_synd_ioctl synd_ioctl;
    sxd_ctrl_pack_t      ctrl_pack;
    int                  sxd_err = SXD_STATUS_SUCCESS;
    sx_status_t          err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR(synd_ioctl);
    SX_MEM_CLR(ctrl_pack);

    if (cmd == SX_ACCESS_CMD_ADD) {
        ctrl_pack.ctrl_cmd = CTRL_CMD_ADD_SYND;
    } else if (cmd == SX_ACCESS_CMD_DELETE) {
        ctrl_pack.ctrl_cmd = CTRL_CMD_REMOVE_SYND;
    }

    synd_ioctl.swid = swid;
    synd_ioctl.is_default = FALSE;
    synd_ioctl.is_register = 1;
    synd_ioctl.syndrome_num = trap_id;
    SX_API_GET_RELEVANT_PACKET_TYPE(trap_id, synd_ioctl.type);
    SX_API_GET_DROP_ENABLED(trap_id, synd_ioctl.critireas.dont_care.drop_enable);

    synd_ioctl.channel_type = (enum ku_user_channel_type)channel_type;

    ctrl_pack.cmd_body = (void*)&synd_ioctl;
    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("Add/remove syndrome sxd_ioctl error %s, [trap_id = %u, channel_type = %u]\n",
                   strerror(errno), trap_id, channel_type);
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    SX_LOG(SX_LOG_DEBUG, "Configured trap id [%u] successfully in driver, return value: %s.\n",
           trap_id, strerror(errno));

out:
    SX_LOG_EXIT();
    return err;
}

/* coverity[pass_by_value] */
static sx_status_t __host_ifc_send_trap_group_update_to_health_check(uint8_t                      dev_id,
                                                                     ku_dbg_health_check_params_t ku_dbg_health_check_params)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    sxd_status_t sxd_status = SXD_STATUS_SUCCESS;

    ku_dbg_health_check_params.dev_id = dev_id;
    sxd_status = sxd_access_sdk_fatal_failure_detection_info_set(&ku_dbg_health_check_params);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR(
            "Fatal failure detection set failed on updating trap group, with cmd (%d) and SXD return value: (%d) on device %d\n",
            ku_dbg_health_check_params.sxd_health_fatal_failure_detect_cmd,
            sxd_status,
            ku_dbg_health_check_params.dev_id);
        rc = SXD_STATUS_TO_SX_STATUS(sxd_status);
    }
    return rc;
}
static sx_status_t __handle_hpkt(uint32_t  hw_trap_id,
                                 uint32_t *action_p,
                                 uint32_t *group_p,
                                 uint32_t *control_p,
                                 boolean_t trunc_en,
                                 uint8_t   trunc_prof)
{
    struct ku_hpkt_reg hpkt_reg_data;
    sxd_reg_meta_t     hpkt_reg_meta;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        rc = SX_STATUS_SUCCESS;
    int                device_cnt = SX_DEV_ID_MAX;
    int                device_index = 0;
    topo_device_item_t dev_attrib[SX_DEV_ID_MAX];
    boolean_t          skip_sending_hpkt = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(hpkt_reg_meta);
    SX_MEM_CLR(hpkt_reg_data);

    /* set register fields */
    hpkt_reg_meta.swid = 0;

    /* get device list */
    rc = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in topo_db_device_list_get.\n");
        return __SX_LOG_EXIT(rc);
    }

    /* If trap ID is event, action must be NOP or TRAP (as defined in PRM) */
    if (trap_id_is_fw_event(hw_trap_id) &&
        (action_p[0] != SX_TRAP_ACTION_IGNORE) &&
        (action_p[0] != SX_TRAP_ACTION_TRAP_2_CPU)) {
        SX_LOG_ERR("Event trap 0x%x must be set with action NOP or TRAP but is set with %u\n",
                   hw_trap_id,
                   action_p[0]);
        return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }


    /* set register fields */
    hpkt_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    hpkt_reg_data.trap_id = hw_trap_id;
    hpkt_reg_data.tr_en = trunc_en;
    hpkt_reg_data.tr_prof = trunc_prof;
    /* If trap id is source trap, action field in HPKT is reserved (as defined in PRM) */
    if (trap_id_is_source(hw_trap_id)) {
        hpkt_reg_data.action = 0;
    } else {
        hpkt_reg_data.action = action_p[0];
    }
    hpkt_reg_data.trap_group = group_p[0];
    hpkt_reg_data.ctrl = control_p[0];

    if (hw_trap_id == SXD_TRAP_ID_DISCARD_DEC_NVE_OPTIONS) {
        rc = sdk_tunnel_trap_nve_options_set(&hpkt_reg_data, &skip_sending_hpkt);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("HPKT register set failed in the tunnel module, return value: (%d)\n", rc);
            return __SX_LOG_EXIT(rc);
        }

        if (skip_sending_hpkt != FALSE) {
            return __SX_LOG_EXIT(SX_STATUS_SUCCESS);
        }
    }

    SX_LOG_INF("HPKT set trap:[%u] group:[%u] action:[%u] control:[%u]\n",
               hpkt_reg_data.trap_id, hpkt_reg_data.trap_group, hpkt_reg_data.action, hpkt_reg_data.ctrl);
    /* move across all devices and send to driver */
    for (device_index = 0; device_index < device_cnt; device_index++) {
        /* HPKT should only be configured to local devices */
        if ((dev_attrib[device_index].node_type != SX_DEV_NODE_TYPE_LEAF_LOCAL) &&
            (dev_attrib[device_index].node_type != SX_DEV_NODE_TYPE_SPINE_LOCAL)) {
            continue;
        }

        hpkt_reg_meta.dev_id = dev_attrib[device_index].dev_id;
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HPKT_E,
                                                         &hpkt_reg_data,
                                                         &hpkt_reg_meta,
                                                         1,
                                                         NULL,
                                                         NULL);
    }

    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("HPKT register set failed on SXD, SXD return value: (%d)\n", sxd_status);
        return __SX_LOG_EXIT(SXD_STATUS_TO_SX_STATUS(sxd_status));
    }

    return __SX_LOG_EXIT(SX_STATUS_SUCCESS);
}

static sx_status_t __handle_htgt(sx_device_id_t                      device_id,
                                 sx_swid_id_t                        swid_id,
                                 sx_hw_trap_group_e                  trap_group,
                                 sxd_host_interface_path_type_e     *path_type_p,
                                 sxd_host_interface_path_t          *host_path_p,
                                 boolean_t                          *policer_enabled_p,
                                 sx_policer_id_t                    *policer_id_p,
                                 sx_trap_priority_t                 *priority_p,
                                 sxd_host_interface_mirror_action_t *mirror_action_p,
                                 sx_span_session_id_int_t           *mirror_agent_p,
                                 sx_span_probability_rate_t         *mirror_probability_rate_p)
{
    struct ku_htgt_reg               htgt_reg_data;
    sxd_reg_meta_t                   htgt_reg_meta;
    sxd_status_t                     sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    int                              device_cnt = SX_DEV_ID_MAX;
    int                              device_index = 0;
    topo_device_item_t               dev_attrib[SX_DEV_ID_MAX];
    ku_dbg_health_check_params_t     ku_dbg_health_check_params;
    boolean_t                        is_configured = FALSE;
    host_ifc_trap_group_properties_t trap_group_properties;


    SX_LOG_ENTER();

    SX_MEM_CLR(ku_dbg_health_check_params);
    SX_MEM_CLR(htgt_reg_meta);
    SX_MEM_CLR(htgt_reg_data);
    SX_MEM_CLR(trap_group_properties);

    /* get device list */
    if (device_id == 0) {
        rc = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in topo_db_device_list_get.\n");
            goto out;
        }
    } else {
        device_cnt = 1;
        dev_attrib[0].dev_id = device_id;
        dev_attrib[0].node_type = SX_DEV_NODE_TYPE_LEAF_LOCAL;
    }

    if (device_cnt == 0) {
        goto out;
    }
    /* set register fields */
    htgt_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    htgt_reg_data.trap_group = trap_group;
    htgt_reg_data.swid = swid_id;
    htgt_reg_data.type = (sxd_htgt_type_t)path_type_p[0];
    htgt_reg_data.pide = policer_enabled_p[0];
    htgt_reg_data.pid = SX_POLICER_PID_GET(policer_id_p[0]);
    htgt_reg_data.priority = priority_p[0];
    htgt_reg_data.mirror_action = mirror_action_p[0];
    htgt_reg_data.mirror_agent = mirror_agent_p[0];
    htgt_reg_data.mirror_probability_rate = mirror_probability_rate_p[0];

    switch (htgt_reg_data.type) {
    case SXD_HOST_IF_PATH_TYPE_LOCAL_E: /* local path */
        htgt_reg_data.path.cpu_tclass =
            host_path_p->local_path.cpu_tclass;
        htgt_reg_data.path.rdq =
            host_path_p->local_path.rdq;
        ku_dbg_health_check_params.params.tg_params.hw_trap_group = trap_group;
        ku_dbg_health_check_params.sxd_health_fatal_failure_detect_cmd =
            SXD_HEALTH_FATAL_FAILURE_ADD_TRAP_GROUP_E;
        break;

    case SXD_HOST_IF_PATH_TYPE_NULL_E: /* NULL path */
        ku_dbg_health_check_params.params.tg_params.hw_trap_group = trap_group;
        ku_dbg_health_check_params.sxd_health_fatal_failure_detect_cmd =
            SXD_HEALTH_FATAL_FAILURE_DELETE_TRAP_GROUP_E;
        break;

    default:
        SX_LOG_ERR("Wrong path type within the HTGT register\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    /* in case Health check monitor is active and we planing to delete trap
     * group MUST update Health check before sending the HTGT emad */
    if (sxd_health_check_active_get() &&
        (SXD_HEALTH_FATAL_FAILURE_DELETE_TRAP_GROUP_E ==
         ku_dbg_health_check_params.sxd_health_fatal_failure_detect_cmd)) {
        rc = __host_ifc_send_trap_group_update_to_health_check(dev_attrib[0].dev_id,
                                                               ku_dbg_health_check_params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Updating Health check with  delete trap group failed. rc: (%d)\n", rc);
            goto out;
        }
    }
    /* move across all devices and send to driver */
    for (device_index = 0; device_index < device_cnt; device_index++) {
        /* HTGT should only be configured to local devices */
        if ((dev_attrib[device_index].node_type != SX_DEV_NODE_TYPE_LEAF_LOCAL) &&
            (dev_attrib[device_index].node_type != SX_DEV_NODE_TYPE_SPINE_LOCAL)) {
            continue;
        }

        htgt_reg_meta.dev_id = dev_attrib[device_index].dev_id;
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HTGT_E,
                                                         &htgt_reg_data,
                                                         &htgt_reg_meta,
                                                         1,
                                                         NULL,
                                                         NULL);
    }


    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("HTGT register set failed on SXD, SXD return value: (%d)\n", sxd_status);
        rc = SXD_STATUS_TO_SX_STATUS(sxd_status);
        goto out;
    }

    /* in case Health check monitor is active and we adding new trap
    * group ,MUST update Health check after sending the HTGT emad */
    if (sxd_health_check_active_get() &&
        (SXD_HEALTH_FATAL_FAILURE_ADD_TRAP_GROUP_E ==
         ku_dbg_health_check_params.sxd_health_fatal_failure_detect_cmd)) {
        /* When adding/setting a trap group, the DB is updated before writing to HTGT, so we can rely on the DB
         *  to determine whether the trap group is monitor trap group or not. */
        rc = host_ifc_db_trap_group_properties_get(swid_id, trap_group, &trap_group_properties, &is_configured);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get properties for HW trap group %u\n", trap_group);
            goto out;
        }
        ku_dbg_health_check_params.params.tg_params.is_monitor = (sxd_boolean_t)(trap_group_properties.is_monitor);

        rc = __host_ifc_send_trap_group_update_to_health_check(dev_attrib[0].dev_id,
                                                               ku_dbg_health_check_params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Updating Health check with add trap group failed. rc: (%d)\n", rc);
            goto out;
        }
    }


out:
    return __SX_LOG_EXIT(rc);
}

static sx_status_t __handle_hctr(sx_trap_id_t trap_id,
                                 uint8_t      tcp_dport,
                                 uint8_t      tcp_sport,
                                 uint8_t      udp_dport,
                                 uint16_t     range_min,
                                 uint16_t     range_max)
{
    struct ku_hctr_reg hctr_reg_data;
    sxd_reg_meta_t     hctr_reg_meta;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        rc = SX_STATUS_SUCCESS;
    int                device_cnt = SX_DEV_ID_MAX;
    int                device_index = 0;
    topo_device_item_t dev_attrib[SX_DEV_ID_MAX];
    uint8_t            trap_index = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(hctr_reg_meta);
    SX_MEM_CLR(hctr_reg_data);

    /* set register fields */
    hctr_reg_meta.swid = 0;

    /* get device list */
    rc = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in topo_db_device_list_get.\n");
        goto out;
    }

    if (trap_id == SX_TRAP_ID_IP2ME_CUSTOM0) {
        trap_index = 0;
    } else if (trap_id == SX_TRAP_ID_IP2ME_CUSTOM1) {
        trap_index = 1;
    }

    /* set register fields */
    hctr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    hctr_reg_data.custom_trap_index = trap_index;
    hctr_reg_data.tcp_dport = tcp_dport;
    hctr_reg_data.tcp_sport = tcp_sport;
    hctr_reg_data.udp_dport = udp_dport;
    hctr_reg_data.range_min = range_min;
    hctr_reg_data.range_max = range_max;

    /* move across all devices and send to driver */
    for (device_index = 0; device_index < device_cnt; device_index++) {
        hctr_reg_meta.dev_id = dev_attrib[device_index].dev_id;
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HCTR_E,
                                                         &hctr_reg_data,
                                                         &hctr_reg_meta,
                                                         1,
                                                         NULL,
                                                         NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("HCTR register update failed on SXD, [custom_trap_index = %u], SXD return value: (%d)\n",
                       trap_index, sxd_status);
            rc = SX_STATUS_SXD_RETURNED_NON_ZERO;
            goto out;
        }
    }

out:
    return __SX_LOG_EXIT(SX_STATUS_SUCCESS);
}

static sx_status_t __trap_key_to_htac(sx_trap_id_t                   trap_id,
                                      sx_trap_id_user_defined_key_t *trap_key_list,
                                      uint32_t                       trap_key_cnt,
                                      struct ku_htac_reg            *htac_reg_data_p)
{
    if (trap_key_cnt == 0) {
        SX_LOG_ERR("trap_key_cnt is 0\n");
        return __SX_LOG_EXIT(SX_STATUS_CMD_ERROR);
    }

    switch (trap_id) {
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE0:
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE1:
    case SX_TRAP_ID_USER_OVERLAY_ICMPV6_CONF_TYPE:
        htac_reg_data_p->attr[0].icmp_type =
            trap_key_list[0].key.icmpv6_attr.icmpv6_type;
        break;

    case SX_TRAP_ID_USER_NVE_DECAP_ETH:
        htac_reg_data_p->attr[0].eth_type =
            trap_key_list[0].key.nve_decap_eth_attr.eth_type;

        if (trap_key_cnt > 1) {
            htac_reg_data_p->attr[1].eth_type =
                trap_key_list[1].key.nve_decap_eth_attr.eth_type;
        }
        break;

    case SX_TRAP_ID_USER_ETH_CONF_TYPE0:
    case SX_TRAP_ID_USER_ETH_CONF_TYPE1:
        htac_reg_data_p->attr[0].eth_type =
            trap_key_list[0].key.nve_decap_eth_attr.eth_type;
        break;

    default:
        SX_LOG_ERR("Wrong trad_id : %d \n", trap_id);
        return __SX_LOG_EXIT(SX_STATUS_CMD_ERROR);
    }

    htac_reg_data_p->trap_id = trap_id;

    return SX_STATUS_SUCCESS;
}

static sx_status_t __handle_htac(sx_trap_id_t                   trap_id,
                                 sx_trap_id_user_defined_key_t *trap_key_list,
                                 uint32_t                      *trap_key_cnt_p)
{
    struct ku_htac_reg htac_reg_data;
    sxd_reg_meta_t     reg_meta;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        rc = SX_STATUS_SUCCESS;
    int                device_cnt = SX_DEV_ID_MAX;
    int                device_index = 0;
    topo_device_item_t dev_attrib[SX_DEV_ID_MAX];

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(htac_reg_data);

    /* set register fields */
    reg_meta.swid = 0;

    /* get device list */
    rc = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in topo_db_device_list_get.\n");
        return __SX_LOG_EXIT(rc);
    }

    switch (trap_id) {
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE0:
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE1:
    case SX_TRAP_ID_USER_OVERLAY_ICMPV6_CONF_TYPE:
    case SX_TRAP_ID_USER_NVE_DECAP_ETH:
    case SX_TRAP_ID_USER_ETH_CONF_TYPE0:
    case SX_TRAP_ID_USER_ETH_CONF_TYPE1:
        break;

    default:
        SX_LOG_ERR("Invalid trap_id: (%d)\n", trap_id);
        return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    /* set register fields */
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    rc = __trap_key_to_htac(trap_id, trap_key_list, *trap_key_cnt_p, &htac_reg_data);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to convert trap key to HTAC register, rc %d.\n", rc);
        return __SX_LOG_EXIT(SX_STATUS_ERROR);
    }

    /* move across all devices and send to driver */
    for (device_index = 0; device_index < device_cnt; device_index++) {
        reg_meta.dev_id = dev_attrib[device_index].dev_id;
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HTAC_E,
                                                         &htac_reg_data,
                                                         &reg_meta,
                                                         1,
                                                         NULL,
                                                         NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("HTAC register update failed on SXD, [trap_id = %u], SXD return value: (%d)\n",
                       trap_id, sxd_status);
            return __SX_LOG_EXIT(SX_STATUS_SXD_RETURNED_NON_ZERO);
        }
    }

    return __SX_LOG_EXIT(SX_STATUS_SUCCESS);
}

static sx_status_t __host_ifc_get_hcot_tunnel_port(sx_tunnel_id_t tunnel_id, sxd_hcot_tunnel_port_t *tunnel_port)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t tunnel_attr;

    SX_MEM_CLR(tunnel_attr);
    rc = sdk_tunnel_impl_get(tunnel_id, &tunnel_attr);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to retrieve tunnel attributes : %d \n", tunnel_id);
        goto out;
    }

    if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, tunnel_attr.type,
                       SX_TUNNEL_TYPE_NVE_MAX)) {
        *tunnel_port = SXD_HCOT_TUNNEL_PORT_NVE_E;
    } else {
        SX_LOG_ERR("Tunnel type:%d is not supported for host configurable trap\n", tunnel_attr.type);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return rc;
}

static sx_status_t __trap_key_to_hcot_key_mask(struct ku_hcot_reg            *hcot_reg_data_p,
                                               sx_access_cmd_t                cmd,
                                               sx_trap_id_user_defined_key_t *trap_key_list)
{
    sx_trap_id_user_defined_key_type_t             key_type;
    sx_host_ifc_nve_decap_et_type_user_trap_attr_t nve_decap_eth_attr;
    sx_host_ifc_next_proto_type_user_trap_attr_t   next_proto_key_type_attr;
    sx_host_ifc_l4_port_user_trap_attr_t           l4_port_key_type_attr;
    sx_host_ifc_icmp_type_user_trap_attr_t         icmp_key_type_attr;

    key_type = trap_key_list[0].type;
    sx_status_t rc = SX_STATUS_SUCCESS;

    switch (key_type) {
    case SX_TRAP_ID_USER_DEFINED_KEY_ETH_TYPE_E:
        /* Ether type key handling */
        nve_decap_eth_attr = trap_key_list[0].key.nve_decap_eth_attr;
        if (cmd == SX_ACCESS_CMD_ADD) {
            if (nve_decap_eth_attr.is_eth_type_valid) {
                hcot_reg_data_p->mask.hcot_key_ethernet.ethertype = 0xFFFF;
            } else {
                hcot_reg_data_p->mask.hcot_key_ethernet.ethertype = 0;
            }
        } else {
            hcot_reg_data_p->mask.hcot_key_ethernet.ethertype = 0xFFFF;
        }
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_NEXT_PROTO_E:
        /* Next Proto Key type handling */
        next_proto_key_type_attr = trap_key_list[0].key.next_proto_key_type_attr;
        if (cmd == SX_ACCESS_CMD_ADD) {
            if (next_proto_key_type_attr.is_ipv4_valid) {
                hcot_reg_data_p->mask.hcot_key_next_proto.is_ipv4 = 0xFF;
            } else {
                hcot_reg_data_p->mask.hcot_key_next_proto.is_ipv4 = 0;
            }
            if (next_proto_key_type_attr.is_ip_proto_valid) {
                hcot_reg_data_p->mask.hcot_key_next_proto.ip_proto = 0xFF;
            } else {
                hcot_reg_data_p->mask.hcot_key_next_proto.ip_proto = 0;
            }
        } else {
            hcot_reg_data_p->mask.hcot_key_next_proto.is_ipv4 = 0xFF;
            hcot_reg_data_p->mask.hcot_key_next_proto.ip_proto = 0xFF;
        }
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_L4_PORT_E:
        /* L4 port Key type handling */
        l4_port_key_type_attr = trap_key_list[0].key.l4_port_key_type_attr;
        if (cmd == SX_ACCESS_CMD_ADD) {
            l4_port_key_type_attr = trap_key_list[0].key.l4_port_key_type_attr;
            if (l4_port_key_type_attr.is_ipv4_valid) {
                hcot_reg_data_p->mask.hcot_key_layer4_port.is_ipv4 = 0xFF;
            } else {
                hcot_reg_data_p->mask.hcot_key_layer4_port.is_ipv4 = 0;
            }
            if (l4_port_key_type_attr.is_l4_port_valid) {
                hcot_reg_data_p->mask.hcot_key_layer4_port.l4_port = 0xFFFF;
            } else {
                hcot_reg_data_p->mask.hcot_key_layer4_port.l4_port = 0;
            }
            if (l4_port_key_type_attr.is_udp_valid) {
                hcot_reg_data_p->mask.hcot_key_layer4_port.is_udp = 0xFF;
            } else {
                hcot_reg_data_p->mask.hcot_key_layer4_port.is_udp = 0;
            }
        } else {
            hcot_reg_data_p->mask.hcot_key_layer4_port.is_ipv4 = 0xFF;
            hcot_reg_data_p->mask.hcot_key_layer4_port.l4_port = 0xFFFF;
            hcot_reg_data_p->mask.hcot_key_layer4_port.is_udp = 0xFF;
        }
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_ICMP_E:
        /* ICMP Key type handling */
        hcot_reg_data_p->mask.hcot_key_icmp_igmp_type.is_igmp = 0xFF;
        icmp_key_type_attr = trap_key_list[0].key.icmp_key_type_attr;
        if (cmd == SX_ACCESS_CMD_ADD) {
            if (icmp_key_type_attr.is_ipv4_valid) {
                hcot_reg_data_p->mask.hcot_key_icmp_igmp_type.is_ipv4 = 0xFF;
            } else {
                hcot_reg_data_p->mask.hcot_key_icmp_igmp_type.is_ipv4 = 0;
            }
        } else {
            hcot_reg_data_p->mask.hcot_key_icmp_igmp_type.is_ipv4 = 0xFF;
        }
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_IGMP_E:
        /* IGMP Key type handling */
        hcot_reg_data_p->mask.hcot_key_icmp_igmp_type.is_igmp = 0xFF;
        hcot_reg_data_p->mask.hcot_key_icmp_igmp_type.is_ipv4 = 0xFF;
        break;

    default:
        break;
    }
    return rc;
}

static sx_status_t __trap_key_to_hcot_key_data(struct ku_hcot_reg            *hcot_reg_data_p,
                                               sx_access_cmd_t                cmd,
                                               sx_trap_id_user_defined_key_t *trap_key_list)
{
    sx_trap_id_user_defined_key_type_t             key_type;
    sx_host_ifc_nve_decap_et_type_user_trap_attr_t nve_decap_eth_attr;
    sx_host_ifc_next_proto_type_user_trap_attr_t   next_proto_key_type_attr;
    sx_host_ifc_l4_port_user_trap_attr_t           l4_port_key_type_attr;
    sx_host_ifc_icmp_type_user_trap_attr_t         icmp_key_type_attr;
    sx_host_ifc_igmp_type_user_trap_attr_t         igmp_key_type_attr;
    sxd_hcot_tunnel_port_t                         tunnel_port = 0;
    sx_status_t                                    rc = SX_STATUS_SUCCESS;

    key_type = trap_key_list[0].type;
    switch (key_type) {
    case SX_TRAP_ID_USER_DEFINED_KEY_ETH_TYPE_E:
        hcot_reg_data_p->key_type = SXD_HCOT_KEY_TYPE_ETHERTYPE_E;
        if (cmd == SX_ACCESS_CMD_ADD) {
            nve_decap_eth_attr = trap_key_list[0].key.nve_decap_eth_attr;
            /* Retrieve Ether type */
            if (nve_decap_eth_attr.is_eth_type_valid) {
                hcot_reg_data_p->key.hcot_key_ethernet.ethertype = nve_decap_eth_attr.eth_type;
            } else {
                hcot_reg_data_p->key.hcot_key_ethernet.ethertype = 0;
            }
            /* Retrieve Tunnel port */
            if (nve_decap_eth_attr.tunnel_id != SX_TUNNEL_ID_INVALID) {
                rc = __host_ifc_get_hcot_tunnel_port(nve_decap_eth_attr.tunnel_id, &tunnel_port);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to get the tunnel port from tunnel ID:%d\n", nve_decap_eth_attr.tunnel_id);
                    goto out;
                }
                hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = tunnel_port;
            } else {
                hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = 0;
            }
        } else {     /* SX_ACCESS_CMD_DELETE */
            hcot_reg_data_p->key.hcot_key_ethernet.ethertype = 0;
            hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = 0;
        }
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_NEXT_PROTO_E:
        hcot_reg_data_p->key_type = SXD_HCOT_KEY_TYPE_NEXT_PROTO_E;
        if (cmd == SX_ACCESS_CMD_ADD) {
            next_proto_key_type_attr = trap_key_list[0].key.next_proto_key_type_attr;
            /* Retrieve ipv4 or ipv6 attribute */
            if (next_proto_key_type_attr.is_ipv4_valid) {
                hcot_reg_data_p->key.hcot_key_next_proto.is_ipv4 = next_proto_key_type_attr.is_ipv4;
            } else {
                hcot_reg_data_p->key.hcot_key_next_proto.is_ipv4 = 0;
            }
            /* Retrieve ip proto validity */
            if (next_proto_key_type_attr.is_ip_proto_valid) {
                hcot_reg_data_p->key.hcot_key_next_proto.ip_proto = next_proto_key_type_attr.ip_proto;
            } else {
                hcot_reg_data_p->key.hcot_key_next_proto.ip_proto = 0;
            }
            /* Retrieve Tunnel port */
            if (next_proto_key_type_attr.tunnel_id != SX_TUNNEL_ID_INVALID) {
                rc = __host_ifc_get_hcot_tunnel_port(next_proto_key_type_attr.tunnel_id, &tunnel_port);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to get the tunnel port from tunnel ID:%d\n",
                               next_proto_key_type_attr.tunnel_id);
                    goto out;
                }
                hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = tunnel_port;
            } else {
                hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = 0;
            }
        } else {     /* SX_ACCESS_CMD_DELETE */
            hcot_reg_data_p->key.hcot_key_next_proto.is_ipv4 = 0;
            hcot_reg_data_p->key.hcot_key_next_proto.ip_proto = 0;
            hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = 0;
        }
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_L4_PORT_E:
        hcot_reg_data_p->key_type = SXD_HCOT_KEY_TYPE_LAYER4_PORT_E;
        if (cmd == SX_ACCESS_CMD_ADD) {
            l4_port_key_type_attr = trap_key_list[0].key.l4_port_key_type_attr;
            /* Retrieve ipv4 or ipv6 attribute */
            if (l4_port_key_type_attr.is_ipv4_valid) {
                hcot_reg_data_p->key.hcot_key_layer4_port.is_ipv4 = l4_port_key_type_attr.is_ipv4;
            } else {
                hcot_reg_data_p->key.hcot_key_layer4_port.is_ipv4 = 0;
            }
            /* Retrieve ipv4 port */
            if (l4_port_key_type_attr.is_l4_port_valid) {
                hcot_reg_data_p->key.hcot_key_layer4_port.l4_port = l4_port_key_type_attr.l4_port;
            } else {
                hcot_reg_data_p->key.hcot_key_layer4_port.l4_port = 0;
            }
            /* Retrieve udp validity*/
            if (l4_port_key_type_attr.is_udp_valid) {
                hcot_reg_data_p->key.hcot_key_layer4_port.is_udp = l4_port_key_type_attr.is_udp;
            } else {
                hcot_reg_data_p->key.hcot_key_layer4_port.is_udp = 0;
            }
            /* Retrieve Tunnel port */
            if (l4_port_key_type_attr.tunnel_id != SX_TUNNEL_ID_INVALID) {
                rc = __host_ifc_get_hcot_tunnel_port(l4_port_key_type_attr.tunnel_id, &tunnel_port);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to get the tunnel port from tunnel ID:%d\n", l4_port_key_type_attr.tunnel_id);
                    goto out;
                }
                hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = tunnel_port;
            } else {
                hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = 0;
            }
        } else {     /* SX_ACCESS_CMD_DELETE */
            hcot_reg_data_p->key.hcot_key_layer4_port.is_ipv4 = 0;
            hcot_reg_data_p->key.hcot_key_layer4_port.l4_port = 0;
            hcot_reg_data_p->key.hcot_key_layer4_port.is_udp = 0;
            hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = 0;
        }
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_ICMP_E:
        hcot_reg_data_p->key_type = SXD_HCOT_KEY_TYPE_ICMP_IGMP_TYPE_E;
        hcot_reg_data_p->key.hcot_key_icmp_igmp_type.is_igmp = 0;
        if (cmd == SX_ACCESS_CMD_ADD) {
            icmp_key_type_attr = trap_key_list[0].key.icmp_key_type_attr;
            /* Retrieve ipv4 or ipv6 attribute */
            if (icmp_key_type_attr.is_ipv4_valid) {
                hcot_reg_data_p->key.hcot_key_icmp_igmp_type.is_ipv4 = icmp_key_type_attr.is_ipv4;
            } else {
                hcot_reg_data_p->key.hcot_key_icmp_igmp_type.is_ipv4 = 0;
            }
            /* Set ICMP min and max values */
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.min = icmp_key_type_attr.min_icmp_type;
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.max = icmp_key_type_attr.max_icmp_type;
            /* Retrieve Tunnel port */
            if (icmp_key_type_attr.tunnel_id != SX_TUNNEL_ID_INVALID) {
                rc = __host_ifc_get_hcot_tunnel_port(icmp_key_type_attr.tunnel_id, &tunnel_port);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to get the tunnel port from tunnel ID:%d\n", icmp_key_type_attr.tunnel_id);
                    goto out;
                }
                hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = tunnel_port;
            } else {
                hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = 0;
            }
        } else {     /* SX_ACCESS_CMD_DELETE */
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.is_ipv4 = 0;
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.min = 0;
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.max = 0;
            hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = 0;
        }
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_IGMP_E:
        hcot_reg_data_p->key_type = SXD_HCOT_KEY_TYPE_ICMP_IGMP_TYPE_E;
        hcot_reg_data_p->key.hcot_key_icmp_igmp_type.is_igmp = 1;
        if (cmd == SX_ACCESS_CMD_ADD) {
            /* IGMP is valid only for IPv4 */
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.is_ipv4 = 1;
            igmp_key_type_attr = trap_key_list[0].key.igmp_key_type_attr;
            /* Set IGMP min and max values */
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.min = igmp_key_type_attr.min_igmp_type;
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.max = igmp_key_type_attr.max_igmp_type;
            /* Retrieve Tunnel port */
            if (igmp_key_type_attr.tunnel_id != SX_TUNNEL_ID_INVALID) {
                rc = __host_ifc_get_hcot_tunnel_port(igmp_key_type_attr.tunnel_id, &tunnel_port);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to get the tunnel port from tunnel ID:%d\n", igmp_key_type_attr.tunnel_id);
                    goto out;
                }
                hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = tunnel_port;
            } else {
                hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = 0;
            }
        } else {     /* SX_ACCESS_CMD_DELETE */
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.is_ipv4 = 0;
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.min = 0;
            hcot_reg_data_p->key.hcot_key_icmp_igmp_type.max = 0;
            hcot_reg_data_p->key.hcot_key_ethernet.tunnel_port = 0;
        }
        break;

    default:
        break;
    }
out:
    return rc;
}

static sx_status_t __trap_key_to_hcot(sx_access_cmd_t                cmd,
                                      sx_trap_id_user_defined_key_t *trap_key_list,
                                      uint32_t                       trap_key_cnt,
                                      struct ku_hcot_reg            *hcot_reg_data_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (trap_key_cnt == 0) {
        SX_LOG_ERR("trap_key_cnt is 0\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    rc = __trap_key_to_hcot_key_data(hcot_reg_data_p, cmd, trap_key_list);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get key data for trap\n");
        goto out;
    }
    rc = __trap_key_to_hcot_key_mask(hcot_reg_data_p, cmd, trap_key_list);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get key mask for trap\n");
        goto out;
    }
out:
    return rc;
}

static sx_status_t __handle_hcot(sx_access_cmd_t                cmd,
                                 sx_swid_t                      swid,
                                 sx_trap_id_t                   trap_id,
                                 sx_trap_id_user_defined_key_t *trap_key_list,
                                 uint32_t                      *trap_key_cnt_p)
{
    struct ku_hcot_reg hcot_reg_data;
    sxd_reg_meta_t     reg_meta;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        rc = SX_STATUS_SUCCESS;
    int                device_cnt = SX_DEV_ID_MAX;
    int                device_index = 0;
    topo_device_item_t dev_attrib[SX_DEV_ID_MAX];

    SX_LOG_ENTER();
    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(hcot_reg_data);

    /* set register fields */
    reg_meta.swid = swid;
    /* get device list */
    rc = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in topo_db_device_list_get.\n");
        return __SX_LOG_EXIT(rc);
    }

    hcot_reg_data.trap_id = trap_id;
    /* set register fields */
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    rc = __trap_key_to_hcot(cmd, trap_key_list, *trap_key_cnt_p, &hcot_reg_data);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to convert trap key to HCOT register, rc %d \n", rc);
        return __SX_LOG_EXIT(rc);
    }

    /* move across all devices and send to driver */
    for (device_index = 0; device_index < device_cnt; device_index++) {
        reg_meta.dev_id = dev_attrib[device_index].dev_id;
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HCOT_E,
                                                         &hcot_reg_data,
                                                         &reg_meta,
                                                         1,
                                                         NULL,
                                                         NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("HCOT register update failed on SXD, [trap_id = %u], SXD return value: (%d)\n",
                       trap_id, sxd_status);
            return __SX_LOG_EXIT(SX_STATUS_SXD_RETURNED_NON_ZERO);
        }
    }

    return __SX_LOG_EXIT(SX_STATUS_SUCCESS);
}

static sx_status_t __handle_hcap(OUT uint8_t *max_num_cpu_tclass,
                                 OUT uint8_t *max_num_trap_groups,
                                 OUT uint8_t *max_num_dr_paths)
{
    struct ku_hcap_reg hcap_reg_data;
    sxd_reg_meta_t     hcap_reg_meta;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_dev_info_t      device_list_arr[SX_DEV_ID_MAX];
    uint32_t           device_cnt = SX_DEV_ID_MAX;

    SX_LOG_ENTER();

    SX_MEM_CLR(hcap_reg_meta);
    SX_MEM_CLR(hcap_reg_data);
    /* set register fields */
    hcap_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    hcap_reg_meta.swid = 0;

    /* get device list */
    rc = port_device_list_get(SX_ACCESS_CMD_GET, device_list_arr, &device_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in port_device_list_get.\n");
        return __SX_LOG_EXIT(rc);
    }

    /* take the first device in the list */
    if (device_cnt == 0) {
        SX_LOG_ERR("Can't get hcap register values, device list is empty\n");
        return __SX_LOG_EXIT(SX_STATUS_ERROR);
    }

    /* get the info from the first device in the list */
    hcap_reg_meta.dev_id = device_list_arr[0].dev_id;
    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HCAP_E, &hcap_reg_data, &hcap_reg_meta, 1, NULL, NULL);

    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "HCAP register read failed on SXD, swid: (%u), SXD return value: (%d)\n",
            0, sxd_status);
        return __SX_LOG_EXIT(SX_STATUS_SXD_RETURNED_NON_ZERO);
    }

    max_num_cpu_tclass[0] = hcap_reg_data.max_cpu_ingress_tclass;
    max_num_trap_groups[0] = hcap_reg_data.max_num_trap_groups;
    max_num_dr_paths[0] = hcap_reg_data.max_num_dr_paths;

    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "HCAP register set failed on SXD, SXD return value: (%d)\n",
            sxd_status);
        return __SX_LOG_EXIT(SX_STATUS_SXD_RETURNED_NON_ZERO);
    }

    return __SX_LOG_EXIT(SX_STATUS_SUCCESS);
}

static sx_status_t __host_ifc_hcap_get(uint8_t *max_num_cpu_tclass,
                                       uint8_t *max_num_trap_groups,
                                       uint8_t *max_num_dr_paths)
{
    SX_LOG_ENTER();

    *max_num_cpu_tclass = rm_resource_global.hw_cpu_ingress_tclass_max;
    *max_num_trap_groups = rm_resource_global.hw_trap_groups_num_max;
    *max_num_dr_paths = rm_resource_global.hw_dr_paths_max;

    return __SX_LOG_EXIT(SX_STATUS_SUCCESS);
}


/**
 * This function prints func exit log and return sx_status
 *
 * @param[in]  sx_status  - status to return
 * @param[in]  func_name  - func name to print
 *
 * @return sx_status_t
 */
static sx_status_t __sx_log_exit(IN sx_status_t rc, IN const char *func_name)
{
    SX_LOG_FUNC_WRAP(func_name, "%s - left\n");
    return rc;
}

static sx_status_t __host_ifc_device_read_capabilities(sx_device_id_t device_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint8_t     max_num_cpu_tclass = 0;
    uint8_t     max_num_trap_groups = 0;
    uint8_t     max_num_dr_paths = 0;

    UNUSED_PARAM(device_id);
    SX_LOG_ENTER();


    /* get host interface capabilities */
    if (g_hwd_ops.hwd_host_ifc_handle_hcap_pfn == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("g_hwd_ops.hwd_host_ifc_handle_hcap_pfn is NULL.\n");
        return __SX_LOG_EXIT(rc);
    }

    rc = (*g_hwd_ops.hwd_host_ifc_handle_hcap_pfn)(&max_num_cpu_tclass, &max_num_trap_groups, &max_num_dr_paths);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR(
            "Failed to retrieve max num of cpu tclass/max num of trap groups parameters, using default parameters\n");
        return __SX_LOG_EXIT(rc);
    }
    /* O/W: */
    rc = host_ifc_common_capabilities_set(max_num_cpu_tclass, max_num_trap_groups, max_num_dr_paths);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("host_ifc_common_capabilities_set failed\n");
        return __SX_LOG_EXIT(rc);
    }

    SX_LOG_DBG(
        "Host-Interface Capabilities initialized successfully. Maximum CPU Traffic Class: %d, Maximum Traffic Groups: %d\n",
        max_num_cpu_tclass,
        max_num_trap_groups);

    /* no need to unadvise device add - requested only 1 notification */
    return __SX_LOG_EXIT(rc);
}

static void __host_ifc_resume_timer_thread(void *args)
{
    struct timeval   timeout;
    sx_status_t      rc;
    int              active_events_cnt;
    int              hc_fd = -1, max_fd;
    fd_set           read_fds;
    fd_set         * read_fds_p;
    struct timeval * timeout_p = NULL;
    int              ret = 0;
    /** Caching the bp_ctl DB entry for this thread.
     *  This variable is used due to performance concerns.
     *  It allows accessing the Process Background DB entry of the current thread
     *  without requesting the entry each time from the DB. One more point:
     *  that in such a way, we omit the continuous need to acquire the spinlock.*/
    cl_dbg_bp_ctl_db_entry_t *bp_ctl_db_entry_p = NULL;

    memset(&timeout, 0, sizeof(timeout));

    SX_LOG(SX_LOG_DEBUG, "Timer thread is started .... \n");

    UNUSED_PARAM(args);
    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, TRUE);

    if (bp_ctl_db_entry_p != NULL) {
        hc_fd = bp_ctl_db_entry_p->health_check_fd;
    }

    while (!stop_event_thread_s) {
        FD_ZERO(&read_fds);
        active_events_cnt = 0;

        rc = sx_mgmt_lib_module_event_status_poll(&active_events_cnt);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG(SX_LOG_ERROR, "sx_mgmt_lib_module_event_status_poll failed. rc=%d\n", rc);
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        }

        FD_ZERO(&read_fds);
        read_fds_p = NULL;
        timeout_p = NULL;
        max_fd = 0;

        if (hc_fd >= 0) {
            FD_SET(hc_fd, &read_fds);
            read_fds_p = &read_fds;
            max_fd = hc_fd;
        }

        if (active_events_cnt > 0) {
            timeout.tv_sec = 0;
            timeout.tv_usec = EVENT_TIMER_TICK_IN_MSEC * 1000;
            timeout_p = &timeout;
        } else {
            FD_SET(__sx_event_fd, &read_fds);
            read_fds_p = &read_fds;
            max_fd = MAX(__sx_event_fd, max_fd);
        }

        cl_fd_wait_on(max_fd, read_fds_p, NULL, timeout_p, &ret);

        if (ret < 0) {
            SX_LOG_ERR("host ifc resume thread: select() failed [err=%d]\n", ret);
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        }
        cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, FALSE);
        if (FD_ISSET(__sx_event_fd, &read_fds)) {
            cl_fd_read(__sx_event_fd);
        }

        /* check if time to die */
        if (event_timer_handler_exit_signal_issued == TRUE) {
            SX_LOG_DBG("Thread __host_ifc_resume_timer_thread is gracefully ending.\n");
            return;
        }
        SX_LOG(SX_LOG_DEBUG, "SOME EVENTS ARRIVED. WAKED UP.\n");

        cl_dbg_bp_ctl_thread_sync(&bp_ctl_db_entry_p);
    } /* while (!stop_event_thread) { */

    return;
}

static sx_status_t __host_ifc_open_sxd_for_event_recv(sxd_handle* sxd_h_p)
{
    char                 dev_name[2][MAX_NAME_LEN];
    char                *dev[1];
    uint32_t             dev_num = 1;
    sxd_ctrl_pack_t      ctrl_pack;
    struct ku_synd_ioctl ku_synd_ioctl;
    sxd_handle           sxd_dev_h;
    int                  sxd_err = SXD_STATUS_SUCCESS;
    sx_status_t          err = SX_STATUS_SUCCESS;

    memset(&ku_synd_ioctl, 0, sizeof(ku_synd_ioctl));
    memset(&ctrl_pack, 0, sizeof(ctrl_pack));

    dev[0] = dev_name[0];

    /* get device list from the devices directory */
    sxd_err = sxd_get_dev_list(dev, &dev_num);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("sxd_get_dev_list error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    /* open the first device */
    sxd_err = sxd_open_device(dev_name[0], &sxd_dev_h);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("sxd_open_device error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    /* set device: received multiple packets = false */
    ctrl_pack.cmd_body = (void*)FALSE;  /* according to drivers team request */
    ctrl_pack.ctrl_cmd = CTRL_CMD_MULTI_PACKET_ENABLE;
    sxd_err = sxd_ioctl(sxd_dev_h, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("sxd_ioctl (set MULTI_PACKET_ENABLE = FALSE) error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    /* set device: blocking on read */
    ctrl_pack.cmd_body = (void*)TRUE;  /* according to drivers team request */
    ctrl_pack.ctrl_cmd = CTRL_CMD_BLOCKING_ENABLE;
    sxd_err = sxd_ioctl(sxd_dev_h, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("sxd_ioctl (set BLOCKING_ENABLE = TRUE) error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    /* mark handle as valid */
    *sxd_h_p = sxd_dev_h;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_sx_set_eth_default_traps(sx_swid_t swid)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(swid);

    SX_LOG_ENTER();

    err = __host_ifc_trap_id_set_to_hw_trap_group(SX_SWID_ID_STACKING,
                                                  (sx_trap_id_t)SXD_TRAP_ID_GENERAL_ETH_EMAD,
                                                  SX_CONTROL_SX_TRAP_GROUP,
                                                  SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SXD_TRAP_ID_GENERAL_ETH_EMAD, SX_CONTROL_SX_TRAP_GROUP,
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_spectrum_set_eth_default_traps(sx_swid_t swid,
                                                             uint32_t  control_trap_group,
                                                             uint32_t  mirror_trap_group,
                                                             uint32_t  mocs_trap_group)
{
    uint32_t    mocs_traps[] = {
        SXD_TRAP_ID_MOCS_DONE,
        SXD_TRAP_ID_PPCNT,
        SXD_TRAP_ID_MGPCB,
        SXD_TRAP_ID_PBSR,
        SXD_TRAP_ID_SBSRD,
        SXD_TRAP_ID_MOPCE
    };
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i;

    SX_LOG_ENTER();

    err = __host_ifc_trap_id_set_to_hw_trap_group(swid, (sx_trap_id_t)SXD_TRAP_ID_GENERAL_ETH_EMAD,
                                                  control_trap_group, SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SXD_TRAP_ID_GENERAL_ETH_EMAD, control_trap_group, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < (sizeof(mocs_traps) / sizeof(mocs_traps[0])); i++) {
        err = __host_ifc_trap_id_set_to_hw_trap_group(swid, mocs_traps[i],
                                                      mocs_trap_group, SX_TRAP_ACTION_TRAP_2_CPU);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                       mocs_traps[i], mocs_trap_group, sx_status_str(err));
            goto out;
        }
    }

    err = __host_ifc_trap_id_set_to_hw_trap_group(swid, SX_TRAP_ID_MIRROR,
                                                  mirror_trap_group, SX_TRAP_ACTION_MIRROR_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SX_TRAP_ID_MIRROR, mirror_trap_group,
                   sx_status_str(err));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_sx_set_ib_default_traps(sx_swid_t swid)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    uint32_t mocs_traps[] = {
        SXD_TRAP_ID_MOCS_DONE,
        SXD_TRAP_ID_PPCNT
    };
    uint32_t i;

    err = __host_ifc_sx_hw_trap_group_set(swid, SX_CONTROL_SX_TRAP_GROUP,
                                          SX_TRAP_PRIORITY_CRITICAL, SX_TRUNCATE_MODE_DISABLE, 0,
                                          SX_CONTROL_TYPE_DEFAULT);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HW trap group %u on SWID %u, return value: [%s]\n",
                   SX_CONTROL_SX_TRAP_GROUP, swid,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_id_set_to_hw_trap_group(swid,
                                                  SX_TRAP_ID_INFINIBAND_QP0, SX_CONTROL_SX_TRAP_GROUP,
                                                  SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SX_TRAP_ID_INFINIBAND_QP0, SX_CONTROL_SX_TRAP_GROUP,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_id_set_to_hw_trap_group(swid,
                                                  (sx_trap_id_t)SXD_TRAP_ID_GENERAL_ETH_EMAD,
                                                  SX_CONTROL_SX_TRAP_GROUP,
                                                  SX_TRAP_ACTION_TRAP_2_CPU);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SXD_TRAP_ID_GENERAL_ETH_EMAD, SX_CONTROL_SX_TRAP_GROUP,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_sx_hw_trap_group_set(swid, SX_IB_QP1_TRAP_GROUP,
                                          SX_TRAP_PRIORITY_HIGH, SX_TRUNCATE_MODE_DISABLE, 0,
                                          SX_CONTROL_TYPE_DEFAULT);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HW trap group %u on SWID %u, return value: [%s]\n",
                   SX_IB_QP1_TRAP_GROUP, swid,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_id_set_to_hw_trap_group(swid,
                                                  SX_TRAP_ID_INFINIBAND_QP1, SX_IB_QP1_TRAP_GROUP,
                                                  SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SX_TRAP_ID_INFINIBAND_QP1, SX_IB_QP1_TRAP_GROUP,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_sx_hw_trap_group_set(swid, SX_IB_OTHER_QP_TRAP_GROUP,
                                          SX_TRAP_PRIORITY_LOW, SX_TRUNCATE_MODE_DISABLE, 0,
                                          SX_CONTROL_TYPE_DEFAULT);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HW trap group %u on SWID %u, return value: [%s]\n",
                   SX_IB_QP1_TRAP_GROUP, swid,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_id_set_to_hw_trap_group(swid,
                                                  SX_TRAP_ID_INFINIBAND_OTHER_QPS, SX_IB_OTHER_QP_TRAP_GROUP,
                                                  SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SX_TRAP_ID_INFINIBAND_OTHER_QPS, SX_IB_OTHER_QP_TRAP_GROUP,
                   sx_status_str(err));
        goto out;
    }

    if (brg_context.spec_cb_g.dev_type == SX_CHIP_TYPE_QUANTUM3) {
        for (i = 0; i < (sizeof(mocs_traps) / sizeof(mocs_traps[0])); i++) {
            err = __host_ifc_trap_id_set_to_hw_trap_group(swid, mocs_traps[i],
                                                          SX_CONTROL_SX_TRAP_GROUP, SX_TRAP_ACTION_TRAP_2_CPU);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                           mocs_traps[i], SX_CONTROL_SX_TRAP_GROUP, sx_status_str(err));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_set_default_traps(sx_api_pci_profile_t *pci_profile, sxd_handle sxd_h)
{
    int         swid = 0;
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = __host_ifc_critical_traps_set(pci_profile);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    for (swid = 0; swid < NUMBER_OF_SWIDS; swid++) {
        /* Set PUDE listener on each swid */
        err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, sxd_h, swid, SX_TRAP_ID_PUDE,
                                      (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                       SX_TRAP_ID_PUDE, sx_status_str(err));
            break;
        }

        /* Set HEALTH CHECK listener on each swid */
        err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, sxd_h, swid, SX_TRAP_ID_SDK_HEALTH_EVENT,
                                      (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                       SX_TRAP_ID_SDK_HEALTH_EVENT, sx_status_str(err));
            break;
        }


        /* Set PMPE listener on each swid */
        /* Add PMPE listener on each swid if management lib module support is enabled */
        err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, sxd_h, swid, SX_TRAP_ID_PMPE,
                                      (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                       SX_TRAP_ID_PMPE, sx_status_str(err));
            break;
        }

        /* Set FW_SOS listener on each swid */
        err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, sxd_h, swid, (sx_trap_id_t)SXD_TRAP_ID_MFDE,
                                      (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                       SXD_TRAP_ID_MFDE, sx_status_str(err));
            break;
        }

        /* Set MOCS_DONE listener on each swid */
        err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, sxd_h, swid, (sx_trap_id_t)SXD_TRAP_ID_MOCS_DONE,
                                      (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                       SXD_TRAP_ID_MOCS_DONE, sx_status_str(err));
            break;
        }


        /* Set IPAC_DONE listener on each swid */
        err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, sxd_h, swid, (sx_trap_id_t)SXD_TRAP_ID_IPAC_DONE,
                                      (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                       SXD_TRAP_ID_IPAC_DONE, sx_status_str(err));
            break;
        }
        /* Set FSHE listener on each swid */
        err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, sxd_h, swid, (sx_trap_id_t)SXD_TRAP_ID_FSHE,
                                      (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                       SXD_TRAP_ID_FSHE, sx_status_str(err));
            break;
        }
    }

    err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, sxd_h, SWID_NUM_DONT_CARE,
                                  SX_TRAP_ID_SIGNAL, (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_WRN("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                   SX_TRAP_ID_SIGNAL, sx_status_str(err));
    }

out:
    SX_LOG_EXIT();

    return err;
}


sx_status_t host_ifc_sysfs_sniffer_trap_register_set(sx_access_cmd_t cmd)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("CMD is unsupported %d\n", cmd);
        goto out;
    }

    err = __host_ifc_listener_set(cmd, ev_thread_params_s.sxd_h, 0, SX_TRAP_ID_SYSFS_SNIFFER,
                                  SX_USER_CHANNEL_TYPE_FD);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to (%s) SYSFS sniffer trap ID registration. Error: (%s)\n",
                   sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t host_ifc_stateful_db_trap_register_set(sx_access_cmd_t cmd)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("CMD is unsupported %d\n", cmd);
        goto out;
    }
    err = __host_ifc_listener_set(cmd, ev_thread_params_s.sxd_h, 0, (sx_trap_id_t)SXD_TRAP_ID_FSED,
                                  SX_USER_CHANNEL_TYPE_FD);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to (%s) FSED trap ID registration. Error: (%s)\n",
                   sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __get_severity_id_print(char *print_message, sxd_mfde_severity_t severity)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();


    switch (severity) {
    case SXD_MFDE_SEVERITY_FATL_E:
        strcpy(print_message, "FW FATAL SEVERITY");
        break;

    case SXD_MFDE_SEVERITY_NRML_E:
        strcpy(print_message, "FW NORMAL SEVERITY");
        break;

    case SXD_MFDE_SEVERITY_INTR_E:
        strcpy(print_message, "FW DEBUG SEVERITY");
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("invalid sxd_mfde_severity_t severity [%d] error: [%s].\n",
                   severity, sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __get_event_id_print(char *print_message, sxd_mfde_event_id_t event_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;


    SX_LOG_ENTER();


    switch (event_id) {
    case SXD_MFDE_EVENT_ID_CRSPACE_TIMEOUT_E:
        strcpy(print_message, "FW CR SPACE TIMEOUT EVENT");
        break;

    case SXD_MFDE_EVENT_ID_KVD_IM_STOP_E:
        strcpy(print_message, "FW KVD STOPPED EVENT");
        break;

    case SXD_MFDE_EVENT_ID_TEST_E:
        strcpy(print_message, "FW TEST EVENT");
        break;

    case SXD_MFDE_EVENT_ID_FW_ASSERT_E:
        strcpy(print_message, "FW ASSERT EVENT");
        break;

    case SXD_MFDE_EVENT_ID_FATAL_CAUSE_E:
        strcpy(print_message, "FW FATAL CAUSE EVENT");
        break;

    case SXD_MFDE_EVENT_ID_LONG_CMD_TIMEOUT_E:
        strcpy(print_message, "FW LONG COMMAND TIMEOUT");
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("invalid sxd_mfde_event_id_t event_id [%d] error [%s].\n",
                   event_id, sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __get_crtimeout_print(char    *print_message,
                                         uint8_t  irisc,
                                         uint8_t  log_id,
                                         uint16_t emad_number,
                                         uint8_t  dev_id)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    sx_chip_types_t chip_type = SX_CHIP_TYPE_UNKNOWN;
    boolean_t       iron_emad = FALSE;
    boolean_t       sma_access = FALSE;
    boolean_t       pci_tools_api = FALSE;
    boolean_t       regular_iric = FALSE;


    switch (emad_number) {
    case SXD_REG_ID_MFBA_E:
    case SXD_REG_ID_MFBE_E:
    case SXD_REG_ID_MFPA_E:
    case SXD_REG_ID_MSGI_E:
    case SXD_REG_ID_MFMC_E:
        iron_emad = TRUE;
        break;

    default:
        iron_emad = FALSE;
    }

    sxd_dpt_get_device_type(dev_id, (sxd_chip_types_t*)&chip_type);
    /*decide which cr master caused  crspace timeout according to chip type */
    switch (chip_type) {
    case SX_CHIP_TYPE_SPECTRUM2:
    case SX_CHIP_TYPE_QUANTUM:
    case SX_CHIP_TYPE_SPECTRUM:
    case SX_CHIP_TYPE_SPECTRUM_A1:
    case SX_CHIP_TYPE_SWITCH_IB:
    case SX_CHIP_TYPE_SWITCH_IB2:
        if ((log_id == 0) || ((log_id >= 2) && (log_id <= 7))) {
            regular_iric = TRUE;
        }
        if (log_id == 9) {
            pci_tools_api = TRUE;
        }
        if (log_id == 11) {
            sma_access = TRUE;
        }
        break;

    case SX_CHIP_TYPE_SPECTRUM3:
    case SX_CHIP_TYPE_SPECTRUM4:
    case SX_CHIP_TYPE_SPECTRUM5:
    case SX_CHIP_TYPE_QUANTUM2:
    case SX_CHIP_TYPE_QUANTUM3:
        if ((log_id == 0) || ((log_id >= 2) && (log_id <= 9))) {
            regular_iric = TRUE;
        }
        if (log_id == 11) {
            pci_tools_api = TRUE;
        }
        if (log_id == 12) {
            sma_access = TRUE;
        }
        break;

    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("cr-timeout print failed, unsupported ASIC type:[%d,%s]\n",
                   chip_type, sx_chip_type_str(chip_type));
        goto out;
        break;
    }


    if ((irisc == FW_SOS_IRON_RISC) && (log_id == FW_SOS_IRON_RISC) && (iron_emad == TRUE)) {
        strcpy(print_message, "Crspace timeout is due to EMAD/ICMD execution");
        goto out;
    }

    if ((pci_tools_api == TRUE) || ((irisc == 1) && (iron_emad == FALSE))) {
        strcpy(print_message, "Crspace timeout is due to Tools or FW dump me API");
        goto out;
    }

    if ((regular_iric == TRUE) && (log_id != irisc)) {
        strcpy(print_message, "Crspace timeout is due to internal FW process");
        goto out;
    }

    if (regular_iric == TRUE) {
        strcpy(print_message, "Crspace timeout is due to EMAD/ICMD execution");
        goto out;
    }

    if (sma_access == TRUE) {
        strcpy(print_message, "crspace timeout is sue to external access via HOST");
        goto out;
    }

    strcpy(print_message, "crspace timeout case is unknown. Check FW");
    SX_LOG(SX_LOG_DEBUG, "Selected print: %s\n", print_message);
out:
    return err;
}

static sx_status_t __handle_single_fsed(struct ku_fsed_reg *fsed_p)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sxd_status_t                      sxd_err = SXD_STATUS_SUCCESS;
    uint16_t                          page_ind = 0, record_ind = 0;
    sx_stateful_db_translated_entry_t translated_entry;
    sxd_fsed_sf_page_dump_mode_0_t   *mode_0_page_p = NULL;
    sxd_fsed_sf_page_dump_mode_1_t   *mode_1_page_p = NULL;
    uint8_t                           key_buff[SXD_FSED_SF_PAGE_DUMP_MODE_0_KEY_54B_NUM];

    /* Translate region_id to stateful DB key ID and HW key blocks to ACL keys */
    for (page_ind = 0; page_ind < fsed_p->num_pages; page_ind++) {
        switch (fsed_p->sf_dump_page[page_ind].mode) {
        case SXD_FSED_MODE_MODE_0_E:
            mode_0_page_p = &(fsed_p->sf_dump_page[page_ind].dump_page.sf_page_dump_mode_0);
            SX_MEM_CLR(translated_entry);
            err = stateful_db_hw_key_to_acl_key_convert((mode_0_page_p->region_id | FLEX_ACL_REGION_BIT_MASK),
                                                        mode_0_page_p->key_54b,
                                                        &(translated_entry));
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Error in translation of entry page (%d), return value: %s\n",
                           page_ind, sx_status_str(err));
                goto out;
            }

            translated_entry.entry_num = __fsed_info.translated_entries_num;
            __fsed_info.translated_entries_num++;
            sxd_err = sxd_access_bulk_stateful_db_keys_set((ku_stateful_db_translated_entry_t *)&translated_entry);
            if (SXD_CHECK_FAIL(sxd_err)) {
                SX_LOG_ERR("Stateful DB keys and key ID write failed with error %s.\n", SXD_STATUS_MSG(sxd_err));
                err = sxd_status_to_sx_status(sxd_err);
                goto out;
            }

            break;

        case SXD_FSED_MODE_MODE_1_E:
            mode_1_page_p = &(fsed_p->sf_dump_page[page_ind].dump_page.sf_page_dump_mode_1);
            for (record_ind = 0; record_ind < SXD_FSED_SF_PAGE_DUMP_MODE_1_RECORD_NUM; record_ind++) {
                if (mode_1_page_p->record[record_ind].valid == TRUE) {
                    SX_MEM_CLR(translated_entry);
                    /* Convert function HW key to ACL key operates on array size 56.
                     * For mode 0, we can send key_54b as is.
                     * For mode 1, we need to pad the short array to array size 56,
                     * by copying key_18b to the buffer's end. */
                    SX_MEM_CLR(key_buff);
                    memcpy(&key_buff[SXD_FSED_SF_PAGE_DUMP_MODE_0_KEY_54B_NUM -
                                     SXD_FSED_SF_PAGE_DUMP_MODE_1_KEY_18B_NUM],
                           mode_1_page_p->record[record_ind].key_18b,
                           sizeof(mode_1_page_p->record[record_ind].key_18b));
                    err = stateful_db_hw_key_to_acl_key_convert(
                        (mode_1_page_p->record[record_ind].region_id | FLEX_ACL_REGION_BIT_MASK),
                        key_buff,
                        &(translated_entry));
                    if (SX_CHECK_FAIL(err)) {
                        SX_LOG_ERR("Error in translation of entry page (%d) record (%d), return value: %s\n",
                                   page_ind, record_ind, sx_status_str(err));
                        goto out;
                    }
                    translated_entry.entry_num = __fsed_info.translated_entries_num;
                    __fsed_info.translated_entries_num++;
                    sxd_err = sxd_access_bulk_stateful_db_keys_set(
                        (ku_stateful_db_translated_entry_t *)&translated_entry);
                    if (SXD_CHECK_FAIL(sxd_err)) {
                        SX_LOG_ERR("Stateful DB keys and key ID write failed with error %s.\n",
                                   SXD_STATUS_MSG(sxd_err));
                        err = sxd_status_to_sx_status(sxd_err);
                        goto out;
                    }
                }
            }
            break;

        default:
            SX_LOG_ERR("FSED deparse failed: Invalid mode (%d) for page (%d).\n",
                       fsed_p->sf_dump_page[page_ind].mode, page_ind);
            err = SX_STATUS_ERROR;
            goto out;
            break;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __parse_fsed_event(char *recv_buff_p, uint16_t recv_buff_size)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sxd_status_t                sxd_err = SXD_STATUS_SUCCESS;
    sxd_emad_data_t             data;
    struct ku_fsed_reg          fsed_reg_data;
    sxd_reg_id_e                reg_id = 0;
    const uint8_t              *buff_p = (uint8_t*)recv_buff_p;
    uint16_t                    buff_remain = recv_buff_size;
    uint16_t                    type = 0, len = 0;
    const sxd_emad_operation_t *operation_p = NULL;
    const sxd_emad_reg_t       *reg_p = NULL;
    struct ku_read             *ku_read_p = (struct ku_read *)recv_buff_p;

    SX_LOG_ENTER();

    SX_MEM_CLR(data);
    SX_MEM_CLR(fsed_reg_data);
    data.fsed.reg_data = &fsed_reg_data;
    data.fsed.common.dev_id = ku_read_p->dev_id;

    buff_p = buff_p + sizeof(struct ku_read);
    buff_remain = recv_buff_size - sizeof(struct ku_read);

    if (buff_remain < sizeof(sxd_emad_header_t) + sizeof(sxd_emad_operation_t)) {
        SX_LOG_ERR("Buffer size is too short\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    /* Skip EMAD header */
    buff_p += sizeof(sxd_emad_header_t);
    buff_remain -= sizeof(sxd_emad_header_t);

    /* Get register ID */
    operation_p = (sxd_emad_operation_t*)buff_p;
    type = EMAD_TLV_TYPE(operation_p);
    if (type != EMAD_TLV_TYPE_OPERATION_E) {
        SX_LOG_ERR("Unexpected TLV in event (type=%u), expected: operation.\n", type);
        err = SX_STATUS_ERROR;
        goto out;
    }
    reg_id = cl_ntoh16(operation_p->register_id);
    buff_p += sizeof(sxd_emad_operation_t);
    buff_remain -= sizeof(sxd_emad_operation_t);

    while (buff_remain >= sizeof(sxd_emad_reg_t)) {
        reg_p = (sxd_emad_reg_t*)buff_p;
        type = EMAD_TLV_TYPE(reg_p);
        len = EMAD_TLV_LEN(reg_p);

        if ((type != EMAD_TLV_TYPE_REG_E) && (type != EMAD_TLV_TYPE_END_E)) {
            SX_LOG_ERR("Unexpected TLV in event (type=%u)\n", type);
            err = SX_STATUS_ERROR;
            break;
        }

        /* in case of END_TLV, just stop parsing */
        if (type == EMAD_TLV_TYPE_END_E) {
            break;
        }

        if (len == 0) {
            SX_LOG_ERR("REG-TLV length is 0\n");
            err = SX_STATUS_ERROR;
            goto out;
        }

        if (len > buff_remain) {
            SX_LOG_ERR("REG-TLV unexpected length (len=%u, buff_len=%u)\n", len, buff_remain);
            err = SX_STATUS_ERROR;
            goto out;
        }

        /* Do single FSED parsing */
        SX_MEM_CLR(fsed_reg_data);
        sxd_err = sxd_emad_deparse_single(&data, buff_p, reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed to deparse FSED, err: %s\n", SXD_STATUS_MSG(sxd_err));
            err = sxd_status_to_sx_status(sxd_err);
            goto out;
        }

        err = __handle_single_fsed(&fsed_reg_data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to handle FSED, err: %s\n", sx_status_str(err));
            goto out;
        }

        /* Go to the next EMAD in the event */
        buff_p += (len * 4);
        buff_remain -= (len * 4);
    }

    if (type != EMAD_TLV_TYPE_END_E) {
        SX_LOG_ERR("Unexpected end of frame (no END_TLV)\n");
        err = SX_STATUS_ERROR;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __parse_event(uint16_t           syndrome_id,
                                 char              *recv_buff_p,
                                 uint16_t           recv_buff_size,
                                 sx_receive_info_t *receive_info_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_err = SXD_STATUS_SUCCESS;
    sxd_emad_data_t     data;
    sxd_reg_id_e        reg_id;
    uint8_t             emad_buff[SXD_EMAD_BUFFER_MAX_SIZE];
    struct ku_pude_reg  pude_reg_data;
    struct ku_pmpe_reg  pmpe_reg_data;
    struct ku_mfde_reg  mfde_reg_data;
    struct ku_mocs_reg  mocs_reg_data;
    struct ku_ipac_reg  ipac_reg_data;
    struct ku_fshe_reg  fshe_reg_data;
    struct ku_meccc_reg meccc_reg_data;
    sx_port_phy_id_t    local_port = 0;
    sx_port_log_id_t    log_port = 0;
    int                 buf_len_to_copy;
    struct ku_read     *ku_read_p = NULL;
    uint32_t            log_level = SX_LOG_WARNING;
    char                print_message[2][FW_SOS_LOG_MAX_SIZE];
    uint8_t             tile;
    uint32_t            cause_reg, cause_offset;
    uint64_t            log_ip = 0;
    char               *assert_string;
    uint8_t             index = 0;
    boolean_t           health_check_log_en = FALSE;

    SX_LOG_ENTER();

    /* since ku_read is the start of the buffer */
    ku_read_p = (struct ku_read *)recv_buff_p;

    buf_len_to_copy = recv_buff_size - sizeof(struct ku_read) > SXD_EMAD_BUFFER_MAX_SIZE ?
                      SXD_EMAD_BUFFER_MAX_SIZE : recv_buff_size - sizeof(struct ku_read);
    memcpy(emad_buff, recv_buff_p + sizeof(struct ku_read), buf_len_to_copy);
    switch (syndrome_id) {
    case SX_TRAP_ID_SDK_HEALTH_EVENT:
        memcpy(&receive_info_p->event_info.sdk_health, emad_buff, sizeof(sx_event_health_notification_t));
        /* In case that "FATAL_ERROR_MODE" flag enabled and we got fatal health check event this print will
         * cause sdk abort */
        sx_log_health_check_log_get(&health_check_log_en);
        if (SX_HEALTH_SEVERITY_FATAL_E == receive_info_p->event_info.sdk_health.severity) {
            SX_LOG(SX_LOG_ERROR, "SX_HEALTH_FATAL: cause_string = [%s], cause_id = [%d], severity: [%d] \n",
                   sx_health_event_cause_str(receive_info_p->event_info.sdk_health.cause),
                   receive_info_p->event_info.sdk_health.cause,
                   receive_info_p->event_info.sdk_health.severity);
        } else if (TRUE == health_check_log_en) {
            SX_LOG(SX_LOG_WARNING, "SX_HEALTH_WARNING: cause_string = [%s], cause_id = [%d], severity: [%d] \n",
                   sx_health_event_cause_str(receive_info_p->event_info.sdk_health.cause),
                   receive_info_p->event_info.sdk_health.cause,
                   receive_info_p->event_info.sdk_health.severity);
        }

        break;

    case SX_TRAP_ID_PUDE:
        SX_LOG(SX_LOG_DEBUG, "Parsing event ID : PUDE\n");
        data.pude.reg_data = &pude_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing PUDE EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        receive_info_p->event_info.pude.oper_state = data.pude.reg_data->oper_status;
        receive_info_p->event_info.pude.logical_state = data.pude.reg_data->logical_state_status;

        data.pude.common.dev_id = ku_read_p->dev_id;
        /* build logical port */
        receive_info_p->event_info.pude.log_port = 0;
        SX_PORT_DEV_ID_SET(receive_info_p->event_info.pude.log_port, data.pude.common.dev_id);
        SX_PORT_TYPE_ID_SET(receive_info_p->event_info.pude.log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          data.pude.reg_data->local_port,
                                          data.pude.reg_data->lp_msb);
        SX_PORT_PHY_ID_SET(receive_info_p->event_info.pude.log_port, local_port);
        receive_info_p->event_info.pude.swid = data.pude.reg_data->swid;

        receive_info_p->source_log_port = receive_info_p->event_info.pude.log_port;

        SX_LOG(SX_LOG_DEBUG,
               "PUDE parsing info : Oper state: [%s] , Logical state: [%s] , Logical port: 0x%x , local port: 0x%x \n",
               sx_port_oper_state_str(receive_info_p->event_info.pude.oper_state),
               sx_port_logical_state_status_str(receive_info_p->event_info.pude.logical_state),
               receive_info_p->event_info.pude.log_port,
               local_port);

        M_PRINT_PORT_LOG_ID_MEMBERS(receive_info_p->source_log_port);
        break;

    case SX_TRAP_ID_PMPE:
        SX_LOG(SX_LOG_DEBUG, "Parsing event ID : PMPE\n");

        data.pmpe.reg_data = &pmpe_reg_data;
        data.pmpe.common.dev_id = ku_read_p->dev_id;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing PMPE EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        if ((data.pmpe.reg_data->slot_index > RM_API_SLOT_MAX_NUM) ||
            (data.pmpe.reg_data->module >= rm_resource_global.port_system_port_modules_max)) {
            SX_LOG(SX_LOG_ERROR,
                   "Slot[%d] module[%d] validation failed exceeding limits slot count[%d], module count[%d], not parsing event.\n",
                   data.pmpe.reg_data->slot_index,
                   data.pmpe.reg_data->module,
                   RM_API_SLOT_MAX_NUM,
                   rm_resource_global.port_system_port_modules_max);
            err = SX_STATUS_ERROR;
            goto out;
        }

        receive_info_p->event_info.pmpe.module_state = (sx_port_module_state_t)data.pmpe.reg_data->module_status;
        receive_info_p->event_info.pmpe.error_type = (uint8_t)data.pmpe.reg_data->error_type;
        receive_info_p->event_info.pmpe.module_id = data.pmpe.reg_data->module;
        receive_info_p->event_info.pmpe.slot_id = data.pmpe.reg_data->slot_index;
        receive_info_p->event_info.pmpe.device_id = data.pmpe.common.dev_id;
        /* no need to change reg_data->port_list since the calling function uses only the module_id */
        SX_LOG(SX_LOG_DEBUG, "PMPE parsing info : Oper state: [%s] , Slot id: 0x%x, Module id: 0x%x\n",
               sx_port_module_state_str(receive_info_p->event_info.pmpe.module_state),
               data.pmpe.reg_data->slot_index,
               data.pmpe.reg_data->module);

        break;

    case SXD_TRAP_ID_MFDE:
        SX_LOG(SX_LOG_DEBUG, "Parsing event ID: FW SOS\n");
        memset(&mfde_reg_data, 0, sizeof(mfde_reg_data));

        data.mfde.reg_data = &mfde_reg_data;
        data.mfde.common.dev_id = ku_read_p->dev_id;

        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing MFDE EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        receive_info_p->event_info.sdk_health.device_id = ku_read_p->dev_id;
        /* we can later set different severity according to different causes */
        receive_info_p->event_info.sdk_health.severity = SX_HEALTH_SEVERITY_FATAL_E;
        receive_info_p->event_info.sdk_health.was_debug_started = FALSE;

        /* MFDE arrived from FW */
        receive_info_p->event_info.sdk_health.cause = SX_HEALTH_CAUSE_FW_E;
        receive_info_p->event_info.sdk_health.irisc_id = data.mfde.reg_data->irisc_id;

        switch ((sxd_mfde_event_id_t)data.mfde.reg_data->event_id) {
        case SXD_MFDE_EVENT_ID_CRSPACE_TIMEOUT_E:
            log_level = SX_LOG_ERROR;
            log_ip = data.mfde.reg_data->event_params.crspace_timeout.log_ip;
            err = __get_crtimeout_print(print_message[0], data.mfde.reg_data->irisc_id,
                                        data.mfde.reg_data->event_params.crspace_timeout.log_id,
                                        data.mfde.reg_data->reg_attr_id, ku_read_p->dev_id);
            if (err == SX_STATUS_ERROR) {
                goto out;
            }

            SX_LOG(log_level,
                   "FW CR timeout on log_address:[0x%x] old_event:[%d] is_yu:[%d] is_iron:[%d] is_main_farm:[%d] log_id:[%d] log_ip:[0x%lx] [%s]\n",
                   data.mfde.reg_data->event_params.crspace_timeout.log_address,
                   data.mfde.reg_data->event_params.crspace_timeout.oe,
                   data.mfde.reg_data->event_params.crspace_timeout.is_yu,
                   data.mfde.reg_data->event_params.crspace_timeout.is_iron,
                   data.mfde.reg_data->event_params.crspace_timeout.is_main_farm,
                   data.mfde.reg_data->event_params.crspace_timeout.log_id,
                   log_ip,
                   print_message[0]);
            break;

        case SXD_MFDE_EVENT_ID_KVD_IM_STOP_E:
            log_level = SX_LOG_ERROR;
            SX_LOG(log_level, "FW KVM stopped, old_event:[%d] pipe mask:[%d] \n",
                   data.mfde.reg_data->event_params.kvd_im_stop.oe,
                   data.mfde.reg_data->event_params.kvd_im_stop.pipes_mask);
            break;

        case SXD_MFDE_EVENT_ID_TEST_E:
            log_level = SX_LOG_NOTICE;
            SX_LOG(log_level, "FW test event\n");
            receive_info_p->event_info.sdk_health.severity = SX_HEALTH_SEVERITY_NOTICE_E;
            break;

        case SXD_MFDE_EVENT_ID_FW_ASSERT_E:
            if (data.mfde.reg_data->event_params.fw_assert.test == FW_SOS_TEST) {
                receive_info_p->event_info.sdk_health.severity = SX_HEALTH_SEVERITY_NOTICE_E;
                log_level = SX_LOG_WARNING;
            } else {
                log_level = SX_LOG_ERROR;
            }
            assert_string = "N/A";
            /* if assert_string from FW is not empty */
            if (data.mfde.reg_data->event_params.fw_assert.assert_string[0]) {
                for (index = 0; index < SXD_MFDE_FW_ASSERT_ASSERT_STRING_NUM; index++) {
                    data.mfde.reg_data->event_params.fw_assert.assert_string[index] =
                        cl_ntoh32(data.mfde.reg_data->event_params.fw_assert.assert_string[index]);
                }
                assert_string = (char *)data.mfde.reg_data->event_params.fw_assert.assert_string;
                /* make sure string is NULL terminated */
                *(assert_string +
                  (SXD_MFDE_FW_ASSERT_ASSERT_STRING_NUM *
                   sizeof(data.mfde.reg_data->event_params.fw_assert.assert_string[0]) -
                   1)) = '\0';
            }
            SX_LOG(log_level,
                   " FW assert msg: [%s], FW assert event - assert id) = [0x%x], assert_var0 = [0x%x], assert_var1 = [0x%x], assert_var2 = [0x%x],"
                   " assert_var3 = [0x%x], assert_var4 = [0x%x], assert_existptr = [0x%x], assert_callra = [0x%x],"
                   " ext_synd = [0x%x], old_event = [0x%x], tile_index = [0x%x]\n",
                   assert_string,
                   data.mfde.reg_data->event_params.fw_assert.ext_synd,
                   data.mfde.reg_data->event_params.fw_assert.assert_var0,
                   data.mfde.reg_data->event_params.fw_assert.assert_var1,
                   data.mfde.reg_data->event_params.fw_assert.assert_var2,
                   data.mfde.reg_data->event_params.fw_assert.assert_var3,
                   data.mfde.reg_data->event_params.fw_assert.assert_var4,
                   data.mfde.reg_data->event_params.fw_assert.assert_existptr,
                   data.mfde.reg_data->event_params.fw_assert.assert_callra,
                   data.mfde.reg_data->event_params.fw_assert.ext_synd,
                   data.mfde.reg_data->event_params.fw_assert.oe,
                   data.mfde.reg_data->event_params.fw_assert.tile_index);

            break;

        case SXD_MFDE_EVENT_ID_FATAL_CAUSE_E:
            if (data.mfde.reg_data->event_params.fatal_cause.test == FW_SOS_TEST) {
                receive_info_p->event_info.sdk_health.severity = SX_HEALTH_SEVERITY_NOTICE_E;
                log_level = SX_LOG_WARNING;
            } else {
                log_level = SX_LOG_ERROR;
            }
            cause_reg = data.mfde.reg_data->event_params.fatal_cause.cause_id >> 5;
            cause_offset = data.mfde.reg_data->event_params.fatal_cause.cause_id & CAUSE_OFFSET_MASK;
            if ((data.mfde.reg_data->event_params.fatal_cause.fw_cause) &&
                (data.mfde.reg_data->event_params.fatal_cause.cause_id ==
                 SXD_MFDE_FW_FATAL_CASUE_ID_CORE_PLL_LOCK_FAILURE_E)) {
                receive_info_p->event_info.sdk_health.cause = SX_HEALTH_CAUSE_PLL_E;
            }

            if (TRUE == data.mfde.reg_data->event_params.fatal_cause.tile_v) {
                tile = data.mfde.reg_data->event_params.fatal_cause.tile_index;
                if (data.mfde.reg_data->event_params.fatal_cause.fw_cause) {
                    SX_LOG(log_level,
                           "FW fatal cause: FW cause id = [0x%x], tile_index = [0x%x] \n",
                           data.mfde.reg_data->event_params.fatal_cause.cause_id,
                           tile);
                } else {
                    SX_LOG(log_level,
                           "FW fatal cause: HW cause id = [0x%x], cause_reg = [0x%x], cause_offset = [0x%x], tile_index = [0x%x] \n",
                           data.mfde.reg_data->event_params.fatal_cause.cause_id,
                           cause_reg,
                           cause_offset,
                           tile);
                }
            } else {
                /* tile is not valid / no tile */
                if (data.mfde.reg_data->event_params.fatal_cause.fw_cause) {
                    SX_LOG(log_level, "FW fatal cause: FW cause id = [0x%x] \n",
                           data.mfde.reg_data->event_params.fatal_cause.cause_id);
                } else {
                    SX_LOG(log_level,
                           "FW fatal cause: HW cause id = [0x%x], cause_reg = [0x%x], cause_offset = [0x%x] \n",
                           data.mfde.reg_data->event_params.fatal_cause.cause_id,
                           cause_reg,
                           cause_offset);
                }
            }
            break;

        case SXD_MFDE_EVENT_ID_LONG_CMD_TIMEOUT_E:
            log_level = SX_LOG_WARNING;
            receive_info_p->event_info.sdk_health.severity = SX_HEALTH_SEVERITY_WARN_E;
            receive_info_p->event_info.sdk_health.cause = SX_HEALTH_CAUSE_FW_LONG_COMMAND_E;
            if (data.mfde.reg_data->severity == SXD_MFDE_SEVERITY_INTR_E) {
                /* debug flow */
                receive_info_p->event_info.sdk_health.severity = SX_HEALTH_SEVERITY_NOTICE_E;
                log_level = SX_LOG_NOTICE;
            }
            SX_LOG(log_level,
                   "FW Long Command Timeout: irisc_id = [%d],  reg_attr_id = [%d], mgmt_class = [%d], method = [%d], notify_fw_dump_completion = [%d]  \n",
                   data.mfde.reg_data->irisc_id,
                   data.mfde.reg_data->reg_attr_id,
                   data.mfde.reg_data->mgmt_class,
                   data.mfde.reg_data->method,
                   data.mfde.reg_data->notify_fw_dump_completion);
            break;

        default:
            /* no extra data */
            SX_LOG(log_level, "Unknown FW event:[%d]\n",
                   (sxd_mfde_event_id_t)data.mfde.reg_data->event_id);
            break;
        }

        err = __get_event_id_print(print_message[0], data.mfde.reg_data->event_id);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
        err = __get_severity_id_print(print_message[1], data.mfde.reg_data->severity);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
        SX_LOG(log_level,
               "FW health event device:[%u] FW cause:[%d,%s], severity:[%d,%s], register[0x%x], packet_state:[%d], "
               "IRISC:[%d], method:[%s]\n",
               ku_read_p->dev_id,
               data.mfde.reg_data->event_id,
               print_message[0],
               data.mfde.reg_data->severity,
               print_message[1],
               data.mfde.reg_data->reg_attr_id,
               data.mfde.reg_data->packet_state,
               data.mfde.reg_data->irisc_id,
               data.mfde.reg_data->method ? "read" : "write");
        break;

    case SXD_TRAP_ID_FSHE:
        memset(&fshe_reg_data, 0, sizeof(fshe_reg_data));

        data.fshe.reg_data = &fshe_reg_data;
        data.fshe.common.dev_id = ku_read_p->dev_id;

        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing FSHE EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }
        receive_info_p->event_info.sdk_health.device_id = ku_read_p->dev_id;

        /* we can later set different severity according to different causes */
        receive_info_p->event_info.sdk_health.severity = SX_HEALTH_SEVERITY_FATAL_E;
        receive_info_p->event_info.sdk_health.was_debug_started = FALSE;

        /* FSHE arrived from FW */
        receive_info_p->event_info.sdk_health.cause = SX_HEALTH_CAUSE_STATEFUL_DB_ORDERING_E;

        break;

    case SXD_TRAP_ID_MOCS_DONE:
        memset(&mocs_reg_data, 0, sizeof(mocs_reg_data));

        data.mocs.reg_data = &mocs_reg_data;
        data.mocs.common.dev_id = ku_read_p->dev_id;

        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing MOCS EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }


        receive_info_p->event_info.mocs_done_info.event_id = data.mocs.reg_data->event_tid;
        receive_info_p->event_info.mocs_done_info.status = data.mocs.reg_data->status;
        if (data.mocs.reg_data->type == SXD_MOCS_TYPE_FSED_E) {
            __fsed_info.translated_entries_num = 0;
        }

        break;

    case SXD_TRAP_ID_MECCC:
        memset(&meccc_reg_data, 0, sizeof(meccc_reg_data));

        data.meccc.reg_data = &meccc_reg_data;
        data.meccc.common.dev_id = ku_read_p->dev_id;

        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing MECCC EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        receive_info_p->event_info.meccc.slot_index = data.meccc.reg_data->slot_index;
        receive_info_p->event_info.meccc.device_index = data.meccc.reg_data->device_index;
        receive_info_p->event_info.meccc.ecc_stats.ecc_corrected = data.meccc.reg_data->ecc_crt_cnt;
        receive_info_p->event_info.meccc.ecc_stats.ecc_uncorrected = data.meccc.reg_data->ecc_ucrt_cnt;
        break;

    case SXD_TRAP_ID_IPAC_DONE:
        memset(&ipac_reg_data, 0, sizeof(ipac_reg_data));

        data.ipac.reg_data = &ipac_reg_data;
        data.ipac.common.dev_id = ku_read_p->dev_id;

        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing IPAC EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SXD_STATUS_TO_SX_STATUS(sxd_err);
            goto out;
        }
        receive_info_p->event_info.port_profile_apply_done_info.status =
            (sx_port_profile_apply_done_status_e)data.ipac.reg_data->status;
        s_parsed_ipac_event.error_entry_index = data.ipac.reg_data->error_entry_index;
        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          data.ipac.reg_data->error_local_port,
                                          data.ipac.reg_data->error_lp_msb);
        SX_PORT_TYPE_ID_SET(log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_DEV_ID_SET(log_port, data.ipac.common.dev_id);
        SX_PORT_PHY_ID_SET(log_port, local_port);

        receive_info_p->event_info.port_profile_apply_done_info.error_log_port = log_port;
        receive_info_p->event_info.port_profile_apply_done_info.port_profile_index = data.ipac.reg_data->profile_index;


        SX_LOG(SX_LOG_NOTICE,
               "IPAC done event:profile_index:[%d] status[0x%x], operation time [%d] registers applied [%d]\n",
               data.ipac.reg_data->profile_index,
               data.ipac.reg_data->status,
               data.ipac.reg_data->log_op_time,
               data.ipac.reg_data->log_op_registers
               );
        if (receive_info_p->event_info.port_profile_apply_done_info.status ==
            SX_PORT_PROFILE_APPLY_DONE_STATUS_ERROR_E) {
            SX_LOG(SX_LOG_ERROR,
                   "IPAC failed . Additional info on failure :local port[0x%x], error entry index [%d] registers id[%d]\n",
                   local_port,
                   data.ipac.reg_data->error_entry_index,
                   data.ipac.reg_data->error_register_id
                   );
        }

        break;


    default:
        SX_LOG(SX_LOG_WARNING, "Syndrome id [%u] is not supported yet\n", syndrome_id);
        err = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_send_event_from_events_handler(sx_trap_id_t      event_id,
                                                             void             *event_buffer_p,
                                                             uint32_t          event_buffer_size,
                                                             sx_ev_send_mode_e event_send_mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = host_ifc_send_event(event_id,
                             event_buffer_p,
                             event_buffer_size,
                             event_send_mode);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Could not send SDK health event, event_id = %u.\n", event_id);
    }

    return rc;
}

static void __host_ifc_recv_events_handler(void* args)
{
    sxd_handle                sxd_h = ((struct timer_thread_param*)args)->sxd_h;
    uint16_t                  trap_id = 0;
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_receive_info_t         receive_info;
    union ku_filter_critireas critireas;
    char                     *buffer_p = NULL;
    int                       buffer_size = SX_ETH_RDQ_MAX_MSG_SIZE, recv_size;
    struct ku_read           *ku_read_p = NULL;
    int                       err;
    uint32_t                  local_port;
    uint32_t                  verbosity_level;
    /** Caching the bp_ctl DB entry for this thread.
     *  This variable is used due to performance concerns.
     *  It allows accessing the Process Background DB entry of the current thread
     *  without requesting the entry each time from the DB. One more point:
     *  that in such a way, we omit the continuous need to acquire the spinlock.*/
    cl_dbg_bp_ctl_db_entry_t                *bp_ctl_db_entry_p = NULL;
    sxd_sysfs_access_sniffer_notification_t *sxd_sysfs_sniffer_notification_p = NULL;
    struct timespec                          sysfs_sniffer_timestamp;
    int                                      sysfs_buf_len_to_copy = 0;
    sx_api_sysfs_head_t                      sysfs_head;
    sx_api_events_head_t                     events_head;
    sx_event_health_notification_t           health_notification;
    adviser_event_e                          advisor_event = ADVISER_EVENT_NONE_E;
    boolean_t                                is_independent_module_enabled = FALSE;
    int                                      sxd_fd, hc_fd = -1, max_fd;
    fd_set                                   read_fds;
    int                                      ret;

    memset(&sysfs_head, 0, sizeof(sysfs_head));
    memset(&events_head, 0, sizeof(events_head));


    SX_LOG(SX_LOG_DEBUG, "Event receive loop started, sxd_h : 0x%x \n", (unsigned int)sxd_h);
    SX_MEM_CLR(critireas);
    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, TRUE);
    if (bp_ctl_db_entry_p != NULL) {
        hc_fd = bp_ctl_db_entry_p->health_check_fd;
    }
    buffer_p = cl_malloc(buffer_size);
    if (NULL == buffer_p) {
        SX_LOG_ERR("Can't allocate memory for a pack\n");
        rc = SX_STATUS_NO_MEMORY;
        FD_ZERO(&read_fds);
        cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

        goto free_out;
    }

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);

    while (1) {
        memset(buffer_p, 0, buffer_size);
        SX_MEM_CLR(receive_info);

        SX_LOG(SX_LOG_DEBUG, "Received a packet or event \n");
        recv_size = buffer_size;
        /* check if time to die */
        if (recv_events_handler_exit_signal_issued == TRUE) {
            SX_LOG_DBG("Thread __host_ifc_recv_events_handler is gracefully ending.\n");
            goto free_out;
        }

        FD_ZERO(&read_fds);

        if (hc_fd >= 0) {
            FD_SET(hc_fd, &read_fds);
        }

        rc = sxd_fd_get(sxd_h, &sxd_fd);
        if (rc) {
            SX_LOG_ERR("Failed to get fd from sxd handle (rc=%d)\n", rc);
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        }

        max_fd = MAX(sxd_fd, hc_fd);

        /* coverity[negative_shift] */
        FD_SET(sxd_fd, &read_fds);

        cl_fd_wait_on(max_fd, &read_fds, NULL, NULL, &ret);

        if (ret < 0) {
            SX_LOG(SX_LOG_ERROR, "Host ifc thread: Failed in select, error %d, errno %s\n", ret, strerror(errno));
            cl_spinlock_release(&host_ifc_state_lock_s);
            cl_free(buffer_p);
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        }

        if (hc_fd >= 0) {
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, FALSE);
        }

        /* check if time to die */
        if (recv_events_handler_exit_signal_issued == TRUE) {
            SX_LOG_DBG("Thread __host_ifc_recv_events_handler is gracefully ending.\n");
            goto free_out_unlock;
        }

        cl_dbg_bp_ctl_thread_sync(&bp_ctl_db_entry_p);

        if (FD_ISSET(sxd_fd, &read_fds)) {
            err = sxd_recv(sxd_h, buffer_p, &recv_size);
        } else {
            continue;
        }

        cl_spinlock_acquire(&host_ifc_state_lock_s);

        if (err < 0) {
            SX_LOG(SX_LOG_ERROR, "Failed in sxd_recv, error %d, errno %s\n", err, strerror(errno));
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
            goto free_out_unlock;
        }

        if (recv_size == 0) {
            SX_LOG(SX_LOG_ERROR, "Received buffer size is 0\n");
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
            goto free_out_unlock;
        }
        /* since ku_read is the start of the buffer */
        ku_read_p = (struct ku_read *)buffer_p;
        trap_id = ku_read_p->trap_id;
        switch (trap_id) {
        case SX_TRAP_ID_PUDE:
            SX_LOG(SX_LOG_DEBUG, "Receive event of PUDE\n");
            /* add parsing */
            rc = __parse_event(trap_id, buffer_p, buffer_size, &receive_info);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG(SX_LOG_ERROR, "Failed in __parse_event, error %d, [trap_id = %u]\n", rc, trap_id);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                goto free_out_unlock;
            }
            if (receive_info.event_info.pude.oper_state != SX_PORT_OPER_STATUS_UP) {
                advisor_event = ADVISER_EVENT_POST_PORT_OPER_DOWN_E;
            } else {
                advisor_event = ADVISER_EVENT_POST_PORT_OPER_UP_E;
            }
            rc = adviser_process_event(advisor_event, &receive_info.source_log_port);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Could not process %s event for port 0x%x, err: %s.\n",
                           ADVISER_EVENT_STR(advisor_event),
                           receive_info.source_log_port, sx_status_str(rc));
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                goto free_out_unlock;
            }

            rc = port_db_pude_cnt_increase(receive_info.event_info.pude.oper_state, receive_info.source_log_port);
            if (SX_STATUS_SUCCESS != rc) {
                if (SX_STATUS_ENTRY_NOT_FOUND == rc) {
                    __pude_err_cnt++;
                } else {
                    SX_LOG(SX_LOG_ERROR, "Failed in increment PUDE counters, error %d, [trap_id = %u]\n", rc, trap_id);
                    cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                    goto free_out_unlock;
                }
            }
            local_port = SX_PORT_PHY_ID_GET(receive_info.source_log_port);
            if (local_port <= rm_resource_global.port_lcl_num_max) {
                port_ev_arr[local_port].state_change_count++;
            }

            if (g_sniffer_enabled) {
                events_head.trap_id = trap_id;
                events_head.event_size = sizeof(receive_info.event_info.pude);
                memcpy(&events_head.event_info, &receive_info.event_info.pude, events_head.event_size);
                events_head.source_log_port = receive_info.source_log_port;
                events_sniffer_access_dispatch(&events_head);
            }
            break;

        /*In this case we are looking for health check event to parse and prints SX_LOG that can lead to sdk abort
         * in case "fatal_error_mode" is enable  */
        case SX_TRAP_ID_SDK_HEALTH_EVENT:
            SX_LOG(SX_LOG_DEBUG, "Receive Health check event\n");
            rc = __parse_event(trap_id, buffer_p, buffer_size, &receive_info);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG(SX_LOG_ERROR, "Failed in __parse_event, error %d, [trap_id = %u]\n", rc, trap_id);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
            }
            break;

        case SX_TRAP_ID_PMPE:
            SX_LOG(SX_LOG_DEBUG, "Receive event of PMPE\n");
            /* No module handling in independent module mode */
            if (is_independent_module_enabled == FALSE) {
                /* add parsing */
                rc = __parse_event(trap_id, buffer_p, buffer_size, &receive_info);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG(SX_LOG_ERROR, "Failed in __parse_event, error %d, [trap_id = %u]\n", rc, trap_id);
                    cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                    goto free_out_unlock;
                }
                rc = sx_mgmt_lib_module_event_rearm_after_timeout(receive_info.event_info.pmpe.slot_id,
                                                                  receive_info.event_info.pmpe.module_id,
                                                                  receive_info.event_info.pmpe.module_state,
                                                                  receive_info.event_info.pmpe.device_id);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG(SX_LOG_ERROR,
                           "Failed to rearm module event, slot[%u] module[%u], err:[%s]\n",
                           receive_info.event_info.pmpe.slot_id,
                           receive_info.event_info.pmpe.module_id,
                           sx_status_str(rc));
                    cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                    goto free_out_unlock;
                }
            }
            /* Invoke host interface timer thread after timeout is set for slot/module */
            if (cl_fd_signal(__sx_event_fd)) {
                SX_LOG_ERR("Failed writing to the PIPE of host ifc timer thread \n");
                goto free_out_unlock;
            }
            break;

        case SXD_TRAP_ID_MFDE:
            /* In case that sx_api_dbg_control_set is disable ill skip on monitor the event
             * Note: if sx_api_fatal_failure_detection enable so this event will be handle in the kernel side*/
            if (FALSE == dbg_control_active_get()) {
                break;
            }
            SX_LOG(SX_LOG_WARNING, "**********************FW SOS EVENT LOG START*************************\n");
            /* if health check is active this trap will be handle in the kernel side*/

            /* add parsing */
            rc = __parse_event(trap_id, buffer_p, buffer_size, &receive_info);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG(SX_LOG_ERROR, "Failed in __parse_event, error %d, [trap_id = %u]\n", rc, trap_id);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
                goto free_out_unlock;
            }

            /* Send SDK health event */

            if (receive_info.event_info.sdk_health.severity == SX_HEALTH_SEVERITY_NOTICE_E) {
                verbosity_level = SX_LOG_NOTICE;
            } else {
                verbosity_level = SX_LOG_ERROR;
            }

            SX_LOG(verbosity_level, "FW SOS device:[%d] sending SDK health:[%s] event cause:[%s,%d] (irisc:[%d])\n",
                   receive_info.event_info.sdk_health.device_id,
                   sx_health_severity_str(receive_info.event_info.sdk_health.severity),
                   sx_health_cause_str(
                       receive_info.event_info.sdk_health.cause), receive_info.event_info.sdk_health.cause,
                   receive_info.event_info.sdk_health.irisc_id);

            /* SDK health event --> NOS */
            rc = __host_ifc_send_event_from_events_handler(SX_TRAP_ID_SDK_HEALTH_EVENT,
                                                           &receive_info.event_info.sdk_health,
                                                           sizeof(receive_info.event_info.sdk_health),
                                                           SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("__host_ifc_send_event_from_events_handler failed, severity = %u, cause = %u, err = %s\n",
                           receive_info.event_info.sdk_health.severity,
                           receive_info.event_info.sdk_health.cause,
                           sx_status_str(rc));
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                goto free_out_unlock;
            }
            /* trigger automatic debug information collection according to policy */
            if (fw_dbg_is_auto_collection_en()) {
                /*trigger debug information collection, will use default parameters */

                SX_LOG(SX_LOG_NOTICE, "Sending an internal command to take FW dump\n");
                __add_internal_job_cb_s(SX_API_INT_CMD_DBG_GENERATE_DUMP_EXT_E,
                                        (uint8_t*)&receive_info.event_info.sdk_health.device_id,
                                        sizeof(receive_info.event_info.sdk_health.device_id),
                                        SX_CORE_MED_PRIO_BUF_E);
            }
            SX_LOG(SX_LOG_WARNING, "***********************FW SOS EVENT LOG END**************************\n");
            /* FW team decision, no auto re-arm, user can call MFGD from outside.
             * if needed in the future, use: fw_dbg_enable (dev_id) */

            break;

        case SXD_TRAP_ID_FSHE:
            /* if health check is active this trap will be handle in the kernel side*/
            if (sxd_health_check_active_get()) {
                break;
            }
            SX_LOG(SX_LOG_WARNING, "**********************FSHE EVENT LOG START*************************\n");
            /* add parsing */
            rc = __parse_event(trap_id, buffer_p, buffer_size, &receive_info);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG(SX_LOG_ERROR, "Failed in __parse_event, error %d, [trap_id = %u]\n", rc, trap_id);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                goto free_out_unlock;
            }
            /* Send SDK health event */

            SX_LOG(SX_LOG_ERROR, "FSHE device:[%d] sending SDK health:[%s] event cause:[%s,%d] \n",
                   receive_info.event_info.sdk_health.device_id,
                   sx_health_severity_str(receive_info.event_info.sdk_health.severity),
                   sx_health_cause_str(
                       receive_info.event_info.sdk_health.cause), receive_info.event_info.sdk_health.cause);

            /* SDK health event --> NOS */
            err = host_ifc_send_event(SX_TRAP_ID_SDK_HEALTH_EVENT,
                                      &receive_info.event_info.sdk_health,
                                      sizeof(receive_info.event_info.sdk_health),
                                      SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Could not send SDK health event.\n");
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                goto free_out_unlock;
            }

            SX_LOG(SX_LOG_WARNING, "***********************FSHE EVENT LOG END**************************\n");

            break;

        case SXD_TRAP_ID_FSED:
            rc = __parse_fsed_event(buffer_p, buffer_size);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_WRN("Failed in __parse_fsed_event, error %s.\n", sx_status_str(rc));
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                goto free_out_unlock;
            }
            break;

        case SXD_TRAP_ID_MOCS_DONE:
            rc = __parse_event(trap_id, buffer_p, buffer_size, &receive_info);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG(SX_LOG_ERROR, "Failed in __parse_event, error %d, [trap_id = %u]\n", rc, trap_id);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
                goto free_out_unlock;
            }

            if (issu_mocs_session_status_check()) {
                rc = issu_handle_mocs_done(receive_info.event_info.mocs_done_info.event_id);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG(SX_LOG_ERROR, "Failed in issu_handle_mocs_done, error %d, [trap_id = %u]\n", rc, trap_id);
                    cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                    goto free_out_unlock;
                }
            } else {
                bulk_counter_handle_mocs_done(receive_info.event_info.mocs_done_info.event_id,
                                              receive_info.event_info.mocs_done_info.status);
            }


            break;

        case SXD_TRAP_ID_MECCC:
            /* if health check is active this trap will be handle in the kernel side*/
            if (sxd_health_check_active_get()) {
                break;
            }
            rc = __parse_event(trap_id, buffer_p, buffer_size, &receive_info);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG(SX_LOG_ERROR, "Failed in __parse_event, error %d, [trap_id = %u]\n", rc, trap_id);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                goto free_out_unlock;
            }

            SX_MEM_CLR(health_notification);
            health_notification.device_id = ku_read_p->dev_id;
            health_notification.cause = SX_HEALTH_CAUSE_ECC_E;
            health_notification.irisc_id = DBG_ALL_IRISCS;
            health_notification.was_debug_started = FALSE;

            if (receive_info.event_info.meccc.ecc_stats.ecc_corrected != __ecc_stats.ecc_corrected) {
                health_notification.severity = SX_HEALTH_SEVERITY_NOTICE_E;
                health_notification.data.ecc_data.ecc_stats.ecc_corrected =
                    receive_info.event_info.meccc.ecc_stats.ecc_corrected;
                __ecc_stats.ecc_corrected = receive_info.event_info.meccc.ecc_stats.ecc_corrected;

                rc = __host_ifc_send_event_from_events_handler(SX_TRAP_ID_SDK_HEALTH_EVENT,
                                                               &health_notification,
                                                               sizeof(health_notification),
                                                               SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR(
                        "__host_ifc_send_event_from_events_handler failed, severity = %u, cause = %u, err = %s\n",
                        health_notification.severity,
                        health_notification.cause,
                        sx_status_str(rc));
                    cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
                    goto free_out_unlock;
                }
            }

            if (receive_info.event_info.meccc.ecc_stats.ecc_uncorrected != __ecc_stats.ecc_uncorrected) {
                health_notification.severity = SX_HEALTH_SEVERITY_FATAL_E;
                health_notification.data.ecc_data.ecc_stats.ecc_uncorrected =
                    receive_info.event_info.meccc.ecc_stats.ecc_uncorrected;
                __ecc_stats.ecc_uncorrected = receive_info.event_info.meccc.ecc_stats.ecc_uncorrected;

                SX_LOG_ERR("Uncorrectable ECC event received from device [%u]\n", health_notification.device_id);
                rc = __host_ifc_send_event_from_events_handler(SX_TRAP_ID_SDK_HEALTH_EVENT,
                                                               &health_notification,
                                                               sizeof(health_notification),
                                                               SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR(
                        "__host_ifc_send_event_from_events_handler failed, severity = %u, cause = %u, err = %s\n",
                        health_notification.severity,
                        health_notification.cause,
                        sx_status_str(rc));
                    cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                    goto free_out_unlock;
                }
            }
            break;

        case SXD_TRAP_ID_IPAC_DONE:
            rc = __parse_event(trap_id, buffer_p, buffer_size, &receive_info);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG(SX_LOG_WARNING, "Failed in __parse_event, error %d, [trap_id = %u]\n", rc, trap_id);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                goto free_out_unlock;
            }

            receive_info.event_info.port_profile_apply_done_info.db_copy_fail = FALSE;
            memcpy(&s_parsed_ipac_event.port_profile_apply_done_event,
                   &receive_info.event_info.port_profile_apply_done_info,
                   sizeof(sx_event_port_profile_apply_done_t));
            sx_core_api_add_internal_job(SX_API_INT_CMD_PORT_PROFILE_APPLY_JOB_PROCESS_E,
                                         NULL,
                                         0,
                                         SX_CORE_MED_PRIO_BUF_E);

            if (g_sniffer_enabled) {
                events_head.trap_id = trap_id;
                events_head.event_size = sizeof(sx_event_port_profile_apply_done_t);
                memcpy(&events_head.event_info, &receive_info.event_info.port_profile_apply_done_info,
                       sizeof(sx_event_port_profile_apply_done_t));
                events_head.source_log_port = receive_info.source_log_port;
                events_sniffer_access_dispatch(&events_head);
            }
            break;

        case SX_TRAP_ID_SYSFS_SNIFFER:

            sysfs_buf_len_to_copy = recv_size - sizeof(struct ku_read); /*the total length of the sysfs sniffer event */

            sxd_sysfs_sniffer_notification_p = (sxd_sysfs_access_sniffer_notification_t*)cl_malloc(
                sysfs_buf_len_to_copy);
            if (sxd_sysfs_sniffer_notification_p == NULL) {
                rc = SX_STATUS_NO_MEMORY;
                SX_LOG_ERR("Failed in memory allocation for sysfs sniffer event."
                           "(%s).\n",  sx_status_str(rc));
            } else {
                memcpy(sxd_sysfs_sniffer_notification_p, buffer_p + sizeof(struct ku_read), sysfs_buf_len_to_copy);

                SX_MEM_CPY_BUF(&sysfs_head.func_name, sxd_sysfs_sniffer_notification_p->func_name,
                               SX_SYSFS_CB_NAME_MAX);
                SX_MEM_CPY_BUF(&sysfs_head.path, sxd_sysfs_sniffer_notification_p->file_path, SX_SYSFS_FILE_PATH_MAX);
                sysfs_head.is_write = sxd_sysfs_sniffer_notification_p->len > 0 ? 1 : 0;
                sysfs_head.buf_len = sxd_sysfs_sniffer_notification_p->len;

                sysfs_sniffer_timestamp.tv_sec = (__time_t)sxd_sysfs_sniffer_notification_p->timestamp.tv_sec;
                sysfs_sniffer_timestamp.tv_nsec = sxd_sysfs_sniffer_notification_p->timestamp.tv_nsec;

                if (g_sniffer_enabled != FALSE) {
                    sysfs_sniffer_access_dispatch(&sysfs_head,
                                                  sxd_sysfs_sniffer_notification_p->buf,
                                                  sysfs_sniffer_timestamp);
                }
                cl_free(sxd_sysfs_sniffer_notification_p);
            }
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG(SX_LOG_WARNING, "Failed in __parse_event, error %d, [trap_id = %u]\n", rc, trap_id);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);

                goto free_out_unlock;
            }
            break;

        default:
            SX_LOG_INF("Ignore received trap [%u] \n", trap_id);
            break;
        }

        cl_spinlock_release(&host_ifc_state_lock_s);
    }

    goto free_out;

free_out_unlock:
    cl_spinlock_release(&host_ifc_state_lock_s);

free_out:
    if (NULL != buffer_p) {
        cl_free(buffer_p);
    }
    return;
}

static sx_status_t __host_ifc_enable_default_health_check(void)
{
    int                           sdk_fatal_err_mode_en = 0;
    sx_boot_mode_e                boot_mode = SX_BOOT_MODE_DISABLED_E;
    sx_dbg_health_sample_params_t health_params;
    sx_status_t                   err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(health_params);
    /* Enable fatal failure detection feature with default values*/
    err = (sx_status_t)sx_log_fatal_error_mode_get(&sdk_fatal_err_mode_en);
    if (SX_CHECK_FAIL(err)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Failed to read MFGD, return value:[%s]\n",
                   sx_status_str(err));
        goto out;
    }
    err = utils_boot_mode_get(&boot_mode);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get the boot mode err = %s\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }
    if (sdk_fatal_err_mode_en == TRUE) {
        health_params.failures_num = SX_DBG_HEALTH_NUM_OF_FAILURES_DEFAULT;
        health_params.periodic_time = SX_DBG_HEALTH_PERIODIC_TIME_DEFAULT;
        health_params.min_severity = SX_HEALTH_SEVERITY_FATAL_E;
        dbg_fatal_failure_detect(SX_ACCESS_CMD_ENABLE, &health_params);
    }

out:
    return err;
}

static sx_status_t __host_ifc_device_add_callback(adviser_event_e event, void *param)
{
    sx_device_info_t *dev_info = NULL;
    sx_status_t       err = SX_STATUS_SUCCESS;


    UNUSED_PARAM(event);

    SX_LOG_ENTER();

    dev_info = (sx_device_info_t*)param;

    if ((dev_info->node_type != SX_DEV_NODE_TYPE_SPINE_LOCAL) &&
        (dev_info->node_type != SX_DEV_NODE_TYPE_LEAF_LOCAL)) {
        return SX_STATUS_SUCCESS;
    }

    err = __host_ifc_device_add(dev_info);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in updating trap/event config to device. error: [%s].\n",
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_enable_default_health_check();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to enable Health check during init flow. error: [%s].\n",
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_device_read_capabilities(dev_info->dev_id);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in reading device capabilities. error: [%s].\n",
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_ecc_stats_init();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__host_ifc_ecc_stats_init failed, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_sdk_client_close_callback(adviser_event_e event, void *param)
{
    pid_t       client_pid;
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(event);

    SX_LOG_ENTER();

    client_pid = *((pid_t*)param);

    err = host_ifc_db_remove_all_fd_user_channels(client_pid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_db_remove_all_fd_user_channels failed, [client_pid = %u], return value: [%s].\n",
                   client_pid, sx_status_str(err));
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_device_add(sx_device_info_t *dev_info)
{
    sx_swid_t                     swid;
    sx_trap_id_t                  trap_id;
    host_ifc_trap_id_properties_t trap_id_properties;
    sx_status_t                   rc = SX_STATUS_SUCCESS;

    SX_MEM_CLR(trap_id_properties);

    SX_LOG_ENTER();

    rc = __host_ifc_device_add_hw_trap_groups(dev_info->dev_id);
    if (SX_CHECK_FAIL(rc)) {
        return __SX_LOG_EXIT(rc);
    }

    for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
        rc = host_ifc_db_trap_id_properties_get(trap_id, &trap_id_properties);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't retrieve trap_id %d properties, rc = %s\n", trap_id, sx_status_str(rc));
            return rc;
        }
        if (trap_id_properties.hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
            continue;
        }

        /* Only set MTPPST on the chips (SPC2, SPC4) that support it */
        if ((trap_id == SX_TRAP_ID_PTP_CLOCK_PPS_EVENT) && (g_hwd_ops.host_ifc_pps_trap_reg_pfn == NULL)) {
            continue;
        }

        /* Set trap ID in HPKT register, if necessary */
        if (brg_context.spec_cb_g.host_ifc_handle_hpkt_cb) {
            rc = brg_context.spec_cb_g.host_ifc_handle_hpkt_cb(trap_id,
                                                               trap_id_properties.hw_trap_id,
                                                               &trap_id_properties.trap_action,
                                                               &trap_id_properties.hw_trap_group,
                                                               &trap_id_properties.control_type);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set HPKT register: trap ID = [0x%x], hw_trap_id = [0x%x], hw_trap_group = [%u]. "
                           "return value: [%s]\n",
                           trap_id,
                           trap_id_properties.hw_trap_id,
                           trap_id_properties.hw_trap_group,
                           sx_status_str(rc));
                return __SX_LOG_EXIT(rc);
            }
        }
    }

    for (swid = SX_SWID_ID_MIN; swid <= rm_resource_global.swid_id_max; swid++) {
        dpt_path_params_t path_params;
        sxd_status_t      sxd_status;

        if (__pci_profile_s.swid_type[swid] != SX_KU_L2_TYPE_ETH) {
            continue;
        }

        path_params.sys_port_params.sys_port = 0;
        sxd_status = sxd_dpt_path_add(dev_info->dev_id, swid, SYS_PORT_ROUTE_PATH, path_params);
        rc = SXD_STATUS_TO_SX_STATUS(sxd_status);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set sys port path in user space DPT, "
                       "for device %d, swid %d. error: %s\n",
                       dev_info->dev_id, swid, sx_status_str(rc));
            return __SX_LOG_EXIT(rc);
        }
    }
    /* if we want to allow the FW dump me mode in sdk init we need to enable here FW_fatal_event
     * This should be done here. Depending on a new flag to dvs_start
     * note at this point OS is not listening to event.
     * there should be automatic debug dump support.
     * to enable use fw_dbg_enable(dev_info->dev_id)
     */


    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_trap_prio_2_trap_group(sx_trap_priority_t trap_priority, sx_hw_trap_group_e *trap_group)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *trap_group = (sx_hw_trap_group_e)trap_priority;

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_trap_group_2_trap_prio(sx_hw_trap_group_e trap_group, sx_trap_priority_t *trap_priority)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
        err = SX_STATUS_TRAP_ID_NOT_CONFIGURED;
        SX_LOG_ERR("Error trap ID is not configured\n");
        goto out;
    }

    *trap_priority = (sx_trap_priority_t)trap_group;

out:
    SX_LOG_EXIT();
    return err;
}

/***************************************************
 * event_timer_thread API Functions Implementations
 **************************************************/

cl_thread_t* host_ifc_get_event_timer_handler_thread_obj(void)
{
    return &(timer_thread_id);
}


void host_ifc_set_event_timer_handler_exit_signal_issue(boolean_t signal_issued)
{
    event_timer_handler_exit_signal_issued = signal_issued;
}


void host_ifc_event_timer_handler_wakeup(void)
{
    if (cl_fd_signal(__sx_event_fd)) {
        SX_LOG_ERR("Failed writing to the PIPE of host ifc timer thread in order to wake him up \n");
    }
}

boolean_t host_ifc_event_timer_handler_thread_init_was_called(void)
{
    return host_ifc_event_timer_handler_thread_init_called;
}


/* __host_ifc_recv_events_handler thread utilities */
cl_thread_t* host_ifc_get_recv_events_handler_thread_obj()
{
    return &(recv_thread_id);
}

void host_ifc_set_recv_events_handler_exit_signal_issue(boolean_t signal_issued)
{
    recv_events_handler_exit_signal_issued = signal_issued;
}

sx_status_t host_ifc_recv_events_handler_wakeup()
{
    int             ret = 0;
    char            buffer_p[10] = {0};
    struct ku_write ku_write;
    struct ku_iovec iov;
    sx_status_t     err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(ku_write);
    SX_MEM_CLR(iov);
    ku_write.meta.swid = 0;
    ku_write.meta.system_port_mid = 0;
    ku_write.meta.to_cpu = 0;
    ku_write.meta.type = SX_PKT_TYPE_LOOPBACK_CTL;
    ku_write.meta.rdq = 0;
    ku_write.meta.lp = 0;
    ku_write.meta.dev_id = 1;
    ku_write.meta.etclass = 6;
    ku_write.meta.loopback_data.trap_id = SX_TRAP_ID_SIGNAL;
    ku_write.meta.loopback_data.is_lag = 0;
    ku_write.meta.loopback_data.lag_subport = 0;
    ku_write.vec_entries = 1;
    ku_write.iov = &iov;
    ku_write.iov->iov_base = buffer_p;
    ku_write.iov->iov_len = 10;

    ret = sxd_send(sw_event_sxd_h, &ku_write, sizeof(struct ku_write));
    if (ret < 0) {
        err = SX_STATUS_ERROR;
    }

    return err;
}

sx_status_t host_ifc_get_port_last_oper_state(uint32_t local_port, sx_port_oper_state_t *last_oper_state_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (local_port > rm_resource_global.port_lcl_num_max) {
        SX_LOG_ERR("Local port %d is out of range.\n", local_port);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (last_oper_state_p == NULL) {
        SX_LOG_ERR("last_oper_state_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *last_oper_state_p = port_ev_arr[local_port].last_oper_state;

out:
    return err;
}

sx_status_t host_ifc_port_state_change_count_get(sx_access_cmd_t cmd,
                                                 uint32_t        local_port,
                                                 sx_port_cntr_t *state_change_count_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        err = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (local_port > rm_resource_global.port_lcl_num_max) {
        SX_LOG_ERR("Local port %u is out of range.\n", local_port);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (state_change_count_p == NULL) {
        SX_LOG_ERR("state_change_count_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
        *state_change_count_p = port_ev_arr[local_port].state_change_count;
        break;

    case SX_ACCESS_CMD_READ_CLEAR:
        *state_change_count_p = port_ev_arr[local_port].state_change_count;
        cl_spinlock_acquire(&host_ifc_state_lock_s);
        port_ev_arr[local_port].state_change_count = 0;
        cl_spinlock_release(&host_ifc_state_lock_s);
        break;

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t host_ifc_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    host_ifc_db_log_verbosity_level_set(verbosity_level);
    host_ifc_common_log_verbosity_level_set(verbosity_level);
    trap_id_log_verbosity_level_set(verbosity_level);

    return err;
}

sx_status_t host_ifc_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

    return err;
}

static sx_status_t __host_ifc_internal_trap_groups_from_profile_get(sx_api_pci_profile_t            *pci_profile,
                                                                    host_ifc_internal_trap_groups_t *internal_trap_groups_p)
{
    UNUSED_PARAM(pci_profile);
    internal_trap_groups_p->mirror_trap_group = TRAP_GROUP_INVALID_ID;
    internal_trap_groups_p->accuflow_trap_group = TRAP_GROUP_INVALID_ID;
    internal_trap_groups_p->mocs_trap_group = TRAP_GROUP_INVALID_ID;
    return SX_STATUS_SUCCESS;
}

static sx_status_t __host_ifc_internal_trap_groups_from_profile_get_spectrum(
    sx_api_pci_profile_t            *pci_profile,
    host_ifc_internal_trap_groups_t *internal_trap_groups_p)
{
    uint32_t mirror_rdq_index = 0;
    uint32_t mocs_rdq_index = 0;
    uint32_t rdq_count = 0;

    /*
     * mirror_trap_group is the last rdq
     * if emad_rdq is outside rdq list than last will be rdq_count[0] - 1
     * else if emad inside the rdq list then rdq_count[0] - 2
     */
    rdq_count = pci_profile->rdq_count[0];
    if (rdq_count > 0) {
        mirror_rdq_index = pci_profile->emad_rdq > (rdq_count - 1) ? rdq_count - 1 : rdq_count - 2;
        internal_trap_groups_p->mirror_trap_group = pci_profile->rdq[0][mirror_rdq_index];
        mocs_rdq_index = pci_profile->emad_rdq !=
                         mirror_rdq_index - 1 ? mirror_rdq_index - 1 : mirror_rdq_index - 2;
        internal_trap_groups_p->mocs_trap_group = pci_profile->rdq[0][mocs_rdq_index];
    } else {
        internal_trap_groups_p->mirror_trap_group = TRAP_GROUP_INVALID_ID;
        internal_trap_groups_p->mocs_trap_group = TRAP_GROUP_INVALID_ID;
    }

    internal_trap_groups_p->accuflow_trap_group = TRAP_GROUP_INVALID_ID;
    return SX_STATUS_SUCCESS;
}

static sx_status_t __host_ifc_internal_trap_groups_from_profile_get_spectrum2(
    sx_api_pci_profile_t            *pci_profile,
    host_ifc_internal_trap_groups_t *internal_trap_groups_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    accumulated_type_max_number = 0;
    uint32_t    mirror_rdq_index = 0;
    uint32_t    accuflow_rdq_index = 0;
    uint32_t    mocs_rdq_index = 0;
    uint32_t    rdq_count = 0;

    /*
     * mirror_trap_group is the last rdq
     * if emad_rdq is outside rdq list than last will be rdq_count[0] - 1
     * else if emad inside the rdq list then rdq_count[0] - 2
     */
    rdq_count = pci_profile->rdq_count[0];
    if (rdq_count > 0) {
        mirror_rdq_index = pci_profile->emad_rdq > (rdq_count - 1) ? rdq_count - 1 : rdq_count - 2;
        internal_trap_groups_p->mirror_trap_group = pci_profile->rdq[0][mirror_rdq_index];

        err = flow_counter_accumulated_num_get(&accumulated_type_max_number);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to check if Accumulated RDQ is needed. (err=%s)\n", sx_status_str(err));
            goto out;
        }

        if (accumulated_type_max_number > 0) {
            accuflow_rdq_index = pci_profile->emad_rdq !=
                                 mirror_rdq_index - 1 ? mirror_rdq_index - 1 : mirror_rdq_index - 2;
            internal_trap_groups_p->accuflow_trap_group = pci_profile->rdq[0][accuflow_rdq_index];
        } else {
            internal_trap_groups_p->accuflow_trap_group = TRAP_GROUP_INVALID_ID;
        }
        if (accuflow_rdq_index > 0) {
            mocs_rdq_index = pci_profile->emad_rdq !=
                             accuflow_rdq_index - 1 ? accuflow_rdq_index - 1 : accuflow_rdq_index - 2;
            internal_trap_groups_p->mocs_trap_group = pci_profile->rdq[0][mocs_rdq_index];
        } else {
            mocs_rdq_index = pci_profile->emad_rdq !=
                             mirror_rdq_index - 1 ? mirror_rdq_index - 1 : mirror_rdq_index - 2;
            internal_trap_groups_p->mocs_trap_group = pci_profile->rdq[0][mocs_rdq_index];
        }
    } else {
        internal_trap_groups_p->mirror_trap_group = TRAP_GROUP_INVALID_ID;
        internal_trap_groups_p->accuflow_trap_group = TRAP_GROUP_INVALID_ID;
        internal_trap_groups_p->mocs_trap_group = TRAP_GROUP_INVALID_ID;
    }

out:
    return err;
}

static sx_status_t __spectrum2_disable_accuflow_trap_group()
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    uint32_t                        accumulated_type_max_number = 0;
    host_ifc_internal_trap_groups_t internal_trap_groups;

    SX_LOG_ENTER();

    SX_MEM_CLR(internal_trap_groups);

    err = flow_counter_accumulated_num_get(&accumulated_type_max_number);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to check if Accumulated trap should be disabled (err=%s)\n", sx_status_str(err));
        goto out;
    }

    /* Set the action to SX_TRAP_ACTION_IGNORE (0) for the AccuFlow event to stop
     *  FW from sending updates for Accuflow counters during ISSU */
    if (accumulated_type_max_number > 0) {
        err = host_ifc_internal_trap_groups_from_profile_get(&__pci_profile_s, &internal_trap_groups);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get the AccuFlow trap group, return value: [%s]\n",
                       sx_status_str(err));
            goto out;
        }

        err = __host_ifc_trap_id_set_to_hw_trap_group(0, (sx_trap_id_t)SXD_TRAP_ID_ACCU_FLOW_INC,
                                                      internal_trap_groups.accuflow_trap_group, SX_TRAP_ACTION_IGNORE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to disable trap group %u, return value: [%s]\n",
                       internal_trap_groups.accuflow_trap_group, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();

    return err;
}

static sx_status_t __spectrum2_accuflow_counter_clear()
{
    sx_status_t         ret = SX_STATUS_SUCCESS;
    struct ku_mafcr_reg mafcr_reg_data;
    sxd_reg_meta_t      mafcr_reg_meta;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_dev_info_t       device_list_arr[SX_DEV_ID_MAX];
    uint32_t            device_cnt = SX_DEV_ID_MAX;
    uint32_t            accumulated_type_max_number;

    SX_LOG_ENTER();

    SX_MEM_CLR(mafcr_reg_meta);
    SX_MEM_CLR(mafcr_reg_data);

    ret = flow_counter_accumulated_num_get(&accumulated_type_max_number);
    if (SX_CHECK_FAIL(ret)) {
        SX_LOG_ERR("Failed to check if Accumulated fifo overflow should be cleared (err=%s)\n", sx_status_str(ret));
        goto out;
    }

    if (accumulated_type_max_number == 0) {
        /* Accumulated is not initialized. Ignore. */
        ret = SX_STATUS_SUCCESS;
        goto out;
    }

    /* set register fields */
    mafcr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    mafcr_reg_meta.swid = 0;
    mafcr_reg_data.clear = 1;

    /* get device list */
    ret = port_device_list_get(SX_ACCESS_CMD_GET, device_list_arr, &device_cnt);
    if (SX_CHECK_FAIL(ret)) {
        SX_LOG_ERR("failed in port_device_list_get.\n");
        goto out;
    }

    /* take the first device in the list */
    if (device_cnt == 0) {
        SX_LOG_ERR("Can't write MAFCR register, device list is empty.\n");
        ret = SX_STATUS_ERROR;
        goto out;
    }

    mafcr_reg_meta.dev_id = device_list_arr[0].dev_id;
    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MAFCR_E, &mafcr_reg_data,
                                                     &mafcr_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("MAFCR register write failed on SxD, SxD return value: (%d)\n", sxd_status);
        ret = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return ret;
}

static sx_status_t __spectrum2_pps_trap_reg(void)
{
    sx_status_t          ret = SX_STATUS_SUCCESS;
    sx_api_pci_profile_t pci_profile;

    SX_LOG_ENTER();

    ret = __pci_profile_get(&pci_profile);
    if (SX_CHECK_FAIL(ret)) {
        SX_LOG_ERR("Failed to get pci profile, return value: [%s]\n",
                   sx_status_str(ret));
        goto out;
    }

    ret = __host_ifc_trap_id_set_to_hw_trap_group(0, (sx_trap_id_t)SXD_TRAP_ID_MTPPST,
                                                  pci_profile.emad_rdq, SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(ret)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SXD_TRAP_ID_MTPPST, pci_profile.emad_rdq,
                   sx_status_str(ret));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return ret;
}

sx_status_t host_ifc_assign_ops(hwi_host_ifc_ops_t *valid_ops)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(valid_ops, "valid_ops")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    valid_ops->hwd_host_ifc_handle_hcap_pfn = __handle_hcap;
    valid_ops->hwd_host_ifc_get_wqe_overflow_counters_pfn = NULL;
    valid_ops->host_ifc_internal_trap_groups_from_profile_get_pfn = __host_ifc_internal_trap_groups_from_profile_get;
    valid_ops->host_ifc_disable_accuflow_trap_group_pfn = NULL;
    valid_ops->host_ifc_accuflow_counter_clear_pfn = NULL;
    valid_ops->host_ifc_pps_trap_reg_pfn = NULL;
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_assign_rm_cap_ops(hwi_host_ifc_ops_t *valid_ops)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(valid_ops, "valid_ops")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    valid_ops->hwd_host_ifc_handle_hcap_pfn = __host_ifc_hcap_get;
    valid_ops->hwd_host_ifc_get_wqe_overflow_counters_pfn = hwd_host_ifc_get_wqe_overflow_global_only_counter;
    valid_ops->host_ifc_internal_trap_groups_from_profile_get_pfn =
        __host_ifc_internal_trap_groups_from_profile_get_spectrum;
    valid_ops->host_ifc_disable_accuflow_trap_group_pfn = NULL;
    valid_ops->host_ifc_accuflow_counter_clear_pfn = NULL;
    valid_ops->host_ifc_pps_trap_reg_pfn = NULL;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_assign_ops_spectrum2(hwi_host_ifc_ops_t *valid_ops)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(valid_ops, "valid_ops")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    valid_ops->hwd_host_ifc_handle_hcap_pfn = __host_ifc_hcap_get;
    valid_ops->hwd_host_ifc_get_wqe_overflow_counters_pfn = hwd_host_ifc_get_wqe_overflow_counters;
    valid_ops->host_ifc_internal_trap_groups_from_profile_get_pfn =
        __host_ifc_internal_trap_groups_from_profile_get_spectrum2;
    valid_ops->host_ifc_disable_accuflow_trap_group_pfn = __spectrum2_disable_accuflow_trap_group;
    valid_ops->host_ifc_accuflow_counter_clear_pfn = __spectrum2_accuflow_counter_clear;
    valid_ops->host_ifc_pps_trap_reg_pfn = __spectrum2_pps_trap_reg;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_assign_ops_spectrum3(hwi_host_ifc_ops_t *valid_ops)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(valid_ops, "valid_ops")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    valid_ops->hwd_host_ifc_handle_hcap_pfn = __host_ifc_hcap_get;
    valid_ops->hwd_host_ifc_get_wqe_overflow_counters_pfn = hwd_host_ifc_get_wqe_overflow_counters;
    valid_ops->host_ifc_internal_trap_groups_from_profile_get_pfn =
        __host_ifc_internal_trap_groups_from_profile_get_spectrum2;
    valid_ops->host_ifc_disable_accuflow_trap_group_pfn = __spectrum2_disable_accuflow_trap_group;
    valid_ops->host_ifc_accuflow_counter_clear_pfn = __spectrum2_accuflow_counter_clear;
    valid_ops->host_ifc_pps_trap_reg_pfn = NULL;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_assign_ops_spectrum4(hwi_host_ifc_ops_t *valid_ops)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(valid_ops, "valid_ops")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    valid_ops->hwd_host_ifc_handle_hcap_pfn = __host_ifc_hcap_get;
    valid_ops->hwd_host_ifc_get_wqe_overflow_counters_pfn = hwd_host_ifc_get_tac_wqe_overflow_counters;
    valid_ops->host_ifc_internal_trap_groups_from_profile_get_pfn =
        __host_ifc_internal_trap_groups_from_profile_get_spectrum2;
    valid_ops->host_ifc_disable_accuflow_trap_group_pfn = __spectrum2_disable_accuflow_trap_group;
    valid_ops->host_ifc_accuflow_counter_clear_pfn = __spectrum2_accuflow_counter_clear;
    valid_ops->host_ifc_pps_trap_reg_pfn = __spectrum2_pps_trap_reg;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_assign_ops_spectrum5(hwi_host_ifc_ops_t *valid_ops)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    if (utils_check_pointer(valid_ops, "valid_ops")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    valid_ops->hwd_host_ifc_handle_hcap_pfn = __host_ifc_hcap_get;
    valid_ops->hwd_host_ifc_get_wqe_overflow_counters_pfn = hwd_host_ifc_get_tac_wqe_overflow_counters;
    valid_ops->host_ifc_internal_trap_groups_from_profile_get_pfn =
        __host_ifc_internal_trap_groups_from_profile_get_spectrum2;
    valid_ops->host_ifc_disable_accuflow_trap_group_pfn = NULL;
    valid_ops->host_ifc_accuflow_counter_clear_pfn = NULL;
    valid_ops->host_ifc_pps_trap_reg_pfn = __spectrum2_pps_trap_reg;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_host_ifc_register_hwd_ops(hwi_host_ifc_ops_t *ops)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(ops, "ops"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (TRUE == g_hwd_ops_params_registered) {
        SX_LOG(SX_LOG_ERROR, "HWD Host interface ops params already registered.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_MEM_CPY_TYPE(&g_hwd_ops, ops, hwi_host_ifc_ops_t);

    g_hwd_ops_params_registered = TRUE;

    SX_LOG_INF("HWD Host interface ops params registered successfully\n");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_host_ifc_register_modules(void)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    hwi_host_ifc_ops_t hwi_host_ifc_ops;

    SX_LOG_ENTER();

    SX_MEM_CLR(hwi_host_ifc_ops);

    if (brg_context.spec_cb_g.host_ifc_assign_ops_cb == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG(SX_LOG_ERROR, "brg_context.spec_cb_g.host_ifc_assign_ops_cb is NULL [%s]\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = brg_context.spec_cb_g.host_ifc_assign_ops_cb(&hwi_host_ifc_ops);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "host_ifc_assign_ops_cb failed. [%s]\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_host_ifc_register_hwd_ops(&hwi_host_ifc_ops);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "sdk_host_ifc_register_hwd_ops failed. [%s]\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_host_ifc_unregister_modules(void)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_hwd_ops_params_registered) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Host interface HWI ops handlers are not initialized. err: %s.\n", sx_status_str(sx_status));
        goto out;
    }

    SX_MEM_CLR(g_hwd_ops);

    g_hwd_ops_params_registered = FALSE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __host_ifc_trap_id_dump(dbg_dump_params_t *dbg_dump_params_p);
static void __debug_cmd_trap_id_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params = {
        .stream = stream,
        .thread_idx = 0,
        .thread_num = 1,
        .hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    };

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    SX_MEM_CLR(printer_params);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI:  failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    __host_ifc_trap_id_dump(&dbg_dump_params);

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}

static sx_status_t __host_ifc_hw_trap_group_dump(dbg_dump_params_t *dbg_dump_params_p, sx_swid_t swid);
static void __debug_cmd_hw_trap_group_swid_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params = {
        .stream = stream,
        .thread_idx = 0,
        .thread_num = 1,
        .hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    };
    sx_swid_t                   swid = 0;

    UNUSED_PARAM(argc);
    UNUSED_PARAM(handler_context);

    SX_MEM_CLR(printer_params);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI:  failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    swid = atoi(argv[0]);
    __host_ifc_hw_trap_group_dump(&dbg_dump_params, swid);

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}


sx_status_t host_ifc_trap_counters_dump(dbg_dump_params_t *dbg_dump_params_p);
static void __debug_cmd_trap_counters_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params = {
        .stream = stream,
        .thread_idx = 0,
        .thread_num = 1,
        .hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    };

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    SX_MEM_CLR(printer_params);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI:  failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    host_ifc_trap_counters_dump(&dbg_dump_params);

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}

static void __debug_cmd_health_event_parse_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    UNUSED_PARAM(argc);
    UNUSED_PARAM(handler_context);

    if (strcmp(argv[0], "enable") && strcmp(argv[0], "disable")) {
        dbg_utils_print(stream, "Invalid param %s, valid values: <enable|disable>\n", argv[0]);
        return;
    }

    dbg_utils_print(stream, "Executing: Health events parsing in host ifc - %sd \n", argv[0]);
    sx_log_health_check_log_set((strcmp(argv[0], "enable") == 0) ? TRUE : FALSE);
}

static void __debug_cmd_driver_debug_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    char cmd_rx_cqe[] = "echo 0 > /sys/module/sx_core/parameters/rx_cqev2_dbg";
    char cmd[200] = "";

    UNUSED_PARAM(argc);
    UNUSED_PARAM(handler_context);

    if (strcmp(argv[0], "rx") && strcmp(argv[0], "tx")) {
        dbg_utils_print(stream, "Invalid param %s, valid values: <rx|tx>\n", argv[0]);
        return;
    }

    if (strcmp(argv[1], "debug") && strcmp(argv[1], "dump")) {
        dbg_utils_print(stream, "Invalid param %s, valid values: <debug|dump>\n", argv[1]);
        return;
    }

    if (strcmp(argv[2], "enable") && strcmp(argv[2], "disable")) {
        dbg_utils_print(stream, "Invalid param %s, valid values: <enable|disable>\n", argv[2]);
        return;
    }

    dbg_utils_print(stream, "Will %s %s %s info in driver, see dmesg\n",
                    argv[2], argv[0], argv[1]);

    sprintf(cmd, "echo %d > /sys/module/sx_core/parameters/%s_%s",
            strcmp(argv[2], "enable") == 0 ? 1 : 0, argv[0], argv[1]);

    dbg_utils_print(stream, "executing: %s\n", cmd);
    if (system(cmd) != 0) {
        SX_LOG_ERR("Failed to execute %s\n", cmd);
    }

    if ((strcmp(argv[0], "rx") == 0) && (strcmp(argv[1], "debug") == 0)) {
        if (strcmp(argv[2], "enable") == 0) {
            cmd_rx_cqe[5] = '1';
        }
        dbg_utils_print(stream, "executing: %s\n", cmd_rx_cqe);
        if (system(cmd_rx_cqe) != 0) {
            SX_LOG_ERR("Failed to execute %s\n", cmd_rx_cqe);
        }
    }
}

static void __debug_cmd_driver_trap_id_debug_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    char cmd[200] = "";

    UNUSED_PARAM(argc);
    UNUSED_PARAM(handler_context);

    dbg_utils_print(stream, "hw_trap_id: %s, see dmesg\n", argv[0]);

    sprintf(cmd, "echo %s > /sys/module/sx_core/parameters/rx_debug_pkt_type",
            argv[0]);
    dbg_utils_print(stream, "executing: %s\n", cmd);
    if (system(cmd) != 0) {
        SX_LOG_ERR("Failed to execute %s\n", cmd);
    }
}

static void __debug_cmd_netdev_debug_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    char cmd[200] = "";

    UNUSED_PARAM(argc);
    UNUSED_PARAM(handler_context);

    if (strcmp(argv[0], "rx") && strcmp(argv[0], "tx")) {
        dbg_utils_print(stream, "Invalid param %s, valid values: <rx|tx>\n", argv[0]);
        return;
    }

    if (strcmp(argv[1], "enable") && strcmp(argv[1], "disable")) {
        dbg_utils_print(stream, "Invalid param %s, valid values: <enable|disable>\n", argv[1]);
        return;
    }

    dbg_utils_print(stream, "Will %s %s netdev debug info in driver, see dmesg\n",
                    argv[1], argv[0]);

    sprintf(cmd, "echo %d > /sys/module/sx_netdev/parameters/sx_netdev_%s_debug",
            strcmp(argv[1], "enable") == 0 ? 1 : 0,
            argv[0]);
    dbg_utils_print(stream, "executing: %s\n", cmd);
    if (system(cmd) != 0) {
        SX_LOG_ERR("Failed to execute %s\n", cmd);
    }
}

static void __host_ifc_rdq_tail_drops_dump(dbg_dump_params_t *dbg_dump_params)
{
    host_ifc_wqe_overflow_cnt_t wqe_overflow_cnt;
    uint32_t                    i;

    memset(&wqe_overflow_cnt, 0, sizeof(wqe_overflow_cnt));
    __get_wqe_overflow_counters(SX_ACCESS_CMD_READ, &wqe_overflow_cnt);
    dbg_utils_pprinter_print(dbg_dump_params->stream, "RDQ Total: %lu (On SPC1 it is an 8bit field + overflow bit)\n",
                             wqe_overflow_cnt.global);
    for (i = 0; i < sizeof(wqe_overflow_cnt.per_rdq) / sizeof(wqe_overflow_cnt.per_rdq[0]); i++) {
        dbg_utils_pprinter_print(dbg_dump_params->stream, "RDQ %02d: %lu\n", i, wqe_overflow_cnt.per_rdq[i]);
    }
}

static void __debug_cmd_rdq_tail_drops_dump_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params;

    SX_MEM_CLR(printer_params);
    SX_MEM_CLR(dbg_dump_params);

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI:  failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    __host_ifc_rdq_tail_drops_dump(&dbg_dump_params);

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}

static void __host_ifc_debug_cmd_register(void)
{
    sx_utils_debug_cmd_register_path("host_ifc trap_id", __debug_cmd_trap_id_cb, NULL);
    sx_utils_debug_cmd_register_path("host_ifc hw_trap_group swid <swid>", __debug_cmd_hw_trap_group_swid_cb, NULL);
    sx_utils_debug_cmd_register_path("host_ifc trap_counters", __debug_cmd_trap_counters_cb, NULL);
    sx_utils_debug_cmd_register_path("host_ifc rdq_tail_drops", __debug_cmd_rdq_tail_drops_dump_cb, NULL);
    sx_utils_debug_cmd_register_path("host_ifc health_event_parse <enable|disable>",
                                     __debug_cmd_health_event_parse_cb,
                                     NULL);
    sx_utils_debug_cmd_register_path("driver <rx|tx> <debug|dump> <enable|disable>", __debug_cmd_driver_debug_cb,
                                     NULL);
    sx_utils_debug_cmd_register_path("driver debug_trap_id <hw_trap_id>", __debug_cmd_driver_trap_id_debug_cb, NULL);
    sx_utils_debug_cmd_register_path("netdev debug <rx|tx> <enable|disable>", __debug_cmd_netdev_debug_cb, NULL);
}


/**
 * This function init the host interface module
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_init(sx_api_pci_profile_t *pci_profile)
{
    cl_status_t cl_err = CL_SUCCESS;
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   register_modules = FALSE;
    boolean_t   is_independent_module_enabled = FALSE;

    SX_LOG_ENTER();

    timer_thread_id.osd.id = (pthread_t)NULL;
    recv_thread_id.osd.id = (pthread_t)NULL;
    s_parsed_ipac_event.error_entry_index = 0;
    s_parsed_ipac_event.port_profile_apply_done_event.db_copy_fail = FALSE;
    s_parsed_ipac_event.port_profile_apply_done_event.device_id = 0;
    s_parsed_ipac_event.port_profile_apply_done_event.error_api = 0;
    s_parsed_ipac_event.port_profile_apply_done_event.error_log_port = 0;
    s_parsed_ipac_event.port_profile_apply_done_event.port_profile_index = 0;
    s_parsed_ipac_event.port_profile_apply_done_event.status = 0;

    if (SX_CHECK_FAIL(utils_check_pointer(pci_profile, "pci_profile"))) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (__is_initialized_s == TRUE) {
        SX_LOG(SX_LOG_INFO, "HOST interface already initialized \n");
        goto out;
    }

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    __host_ifc_debug_cmd_register();

    rc = sdk_host_ifc_register_modules();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in host interface modules registration\n");
        goto out;
    }
    register_modules = TRUE;

    rc = __host_ifc_validate_pci_profile(pci_profile);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "The PCI profile is invalid\n");
        goto out;
    }

    /* Validate that event size doesn't exceed SX_HOST_EVENT_BUFFER_SIZE_MAX,
     * to be sure that when event size increases, size of
     * appropriate define would be increased also */
    SDK_COMPILE_TIME_ASSERT(SX_HOST_EVENT_BUFFER_SIZE_MAX >= sizeof(sx_receive_info_t));

    /* init trap ID */
    trap_id_hw_syndrome_db_init();

    /* init virtual traps */
    __host_ifc_init_vtraps();

    /* Init host interface db trap info*/
    rc = host_ifc_db_init();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in host interface db init\n");
        goto out;
    }

    /* register for device notifications */
    rc = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_ADD_E,
                                __host_ifc_device_add_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in adviser_register_event, error: %s.\n",
                   sx_status_str(rc));
        goto out;
    }

    /* register for sdk client close notifications */
    rc = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_SDK_CLIENT_CLOSE_E,
                                __host_ifc_sdk_client_close_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in adviser_register_event, error: %s.\n",
                   sx_status_str(rc));
        goto out;
    }

    /* init capabilities */
    host_ifc_common_capabilities_set(SX_COS_TCLASS_REQUIRED, SX_TRAP_ID_TRAP_GROUP_REQUIRED,
                                     SX_DR_PATH_GROUP_REQUIRED);


    rc = __host_ifc_init_prio_group(pci_profile);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    rc = sx_mgmt_lib_module_event_map_init();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init module event map, error: %s.\n", sx_status_str(rc));
        goto out;
    }

    __is_initialized_s = TRUE;

    /* create the event_timer_thread */
    if (0 == is_timer_threads_and_event_created_s) {
        cl_err = cl_fd_init(&__sx_event_fd);
        if (cl_err != CL_SUCCESS) {
            SX_LOG_ERR("Could not initialize event fd for host ifc timer thread\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        /* No module management in independent mode */
        if (is_independent_module_enabled == FALSE) {
            cl_err = cl_thread_init(&timer_thread_id,
                                    __host_ifc_resume_timer_thread,
                                    (void*)&ev_thread_params_s,
                                    "hIfcRsmTmr", THREAD_MAX_ALLOWED_TIME_DEFAULT);
            if (cl_err != CL_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Could not create __host_ifc_resume_timer_thread thread\n");
                rc = SX_STATUS_NO_RESOURCES;
                goto out;
            }
        }

        host_ifc_event_timer_handler_thread_init_called = TRUE;

        /* open sxd */
        __host_ifc_open_sxd_for_event_recv(&ev_thread_params_s.sxd_h);

        /* open sxd for sw events generation */
        __host_ifc_open_sxd_for_event_recv(&sw_event_sxd_h);

        /* register on events which need rearming */
        __host_ifc_set_default_traps(pci_profile, ev_thread_params_s.sxd_h);
        cl_err = cl_thread_init(&recv_thread_id, __host_ifc_recv_events_handler,
                                (void*)&ev_thread_params_s, "hIfcEvents", THREAD_MAX_ALLOWED_TIME_DEFAULT);
        if (cl_err != CL_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not create __host_ifc_recv_events_handler thread\n");
            rc = SX_STATUS_NO_RESOURCES;
            goto out;
        }
    }   /* if (0 == is_timer_threads_and_event_created) { */

    is_timer_threads_and_event_created_s = 1;

    cl_spinlock_init(&host_ifc_state_lock_s);

    if (bit_vector_allocate(TRAP_GROUP_ID_MAX + 1, &__bitmap_valid_trap_group) != SX_UTILS_STATUS_SUCCESS) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }

    if (bit_vector_allocate(SX_TRAP_ID_MAX + 1, &__bitmap_valid_trap_id) != SX_UTILS_STATUS_SUCCESS) {
        bit_vector_free(__bitmap_valid_trap_group);
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
out:
    if (SX_CHECK_FAIL(rc)) {
        if (__is_initialized_s) {
            sx_mgmt_lib_module_event_map_deinit();
        }

        if (register_modules) {
            sdk_host_ifc_unregister_modules();
        }
    }

    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_deinit()
{
    /* MUST be called after threads are down, specifically the timer thread that uses "wait_for_sx_event" */
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_independent_module_enabled = FALSE;

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    sx_mgmt_lib_module_event_map_deinit();

    /* deregister for sdk client close notifications */
    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_SDK_CLIENT_CLOSE_E,
                                 __host_ifc_sdk_client_close_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event, error: %s.\n",
                   sx_status_str(err));
        return __SX_LOG_EXIT(err);
    }

    /* deregister for device notifications */
    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_ADD_E,
                                 __host_ifc_device_add_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event, error: %s.\n",
                   sx_status_str(err));
        return __SX_LOG_EXIT(err);
    }

    /* Close event timer. threads were closed earlier! */
    if (is_timer_threads_and_event_created_s) {
        cl_spinlock_acquire(&host_ifc_state_lock_s);
        recv_events_handler_exit_signal_issued = TRUE;
        stop_event_thread_s = 1;
        is_timer_threads_and_event_created_s = 0;
        host_ifc_event_timer_handler_thread_init_called = FALSE;
        if (cl_fd_signal(__sx_event_fd)) {
            SX_LOG_ERR("Failed writing to the PIPE of host ifc  timer thread during deinit \n");
            return __SX_LOG_EXIT(err);
        }
        /* wait for timer_thread exit , because it use wait_for_sx_event */
        if (is_independent_module_enabled == FALSE) {
            /* The thread was not created in independent mode */
            cl_thread_destroy(&timer_thread_id);
        }
        close(__sx_event_fd);
        cl_spinlock_release(&host_ifc_state_lock_s);
    }

    err = sdk_host_ifc_unregister_modules();
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed in sdk_host_ifc_unregister_modules, error: %s.\n", sx_status_str(err));
        return __SX_LOG_EXIT(err);
    }

    /* Deinitialize local DB */
    host_ifc_db_deinit();

    if (__bitmap_valid_trap_group) {
        bit_vector_free(__bitmap_valid_trap_group);
        __bitmap_valid_trap_group = NULL;
    }

    if (__bitmap_valid_trap_id) {
        bit_vector_free(__bitmap_valid_trap_id);
        __bitmap_valid_trap_id = NULL;
    }

    /* init trap ID */
    trap_id_hw_syndrome_db_deinit();

    __is_initialized_s = FALSE;

    return SX_STATUS_SUCCESS;
}

sx_status_t host_ifc_is_initialized_get(boolean_t *is_initialized)
{
    if (is_initialized == NULL) {
        SX_LOG_ERR("is_initialized is NULL.\n");
        return SX_STATUS_PARAM_NULL;
    }

    *is_initialized = __is_initialized_s;

    return SX_STATUS_SUCCESS;
}

void host_ifc_register_cb(sx_add_intern_job_cb cb)
{
    __add_internal_job_cb_s = cb;
}


static sx_status_t __host_ifc_tac_is_enabled(boolean_t *tac_is_enabled_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = sdk_tele_impl_tac_is_enabled(tac_is_enabled_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

out:
    return rc;
}

/*
 * This function will do required validation and
 * will add/remove trap group to/from TAC trap group DB
 */
static sx_status_t __host_ifc_trap_group_tac_db_update(sx_access_cmd_t cmd,
                                                       sx_trap_group_t trap_group,
                                                       uint32_t        hw_trap_group)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    tele_db_tac_trap_group_info_t trap_group_info;

    SX_MEM_CLR(trap_group_info);

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        trap_group_info.hw_trap_group_valid = TRUE;
        trap_group_info.hw_trap_group = hw_trap_group;
        rc = sdk_tele_impl_tac_trap_group_db_update(cmd, trap_group, &trap_group_info);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("TAC DB trap group db update cmd %s failed(tg:%d).rc:%s\n",
                       sx_access_cmd_str(cmd), trap_group, sx_status_str(rc));
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

out:
    return rc;
}

static sx_status_t __host_ifc_trap_group_set_impl(sx_swid_id_t                swid,
                                                  sx_trap_group_t             trap_group,
                                                  sx_trap_group_attributes_t *trap_group_attributes_p,
                                                  uint32_t                   *hw_trap_group_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_hw_trap_group_e hw_trap_group_id;
    boolean_t          tac_is_enabled = FALSE;

    if (RM_TRAP_GROUP_PRIORITY_CHECK_RANGE(trap_group_attributes_p->prio) == FALSE) {
        SX_LOG_ERR("Priority (%u) exceeds range (%u - %u)\n", trap_group_attributes_p->prio,
                   rm_resource_global.trap_group_priority_min,
                   rm_resource_global.trap_group_priority_max);
        return __SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
    }

    if ((trap_group_attributes_p->truncate_mode > SX_TRUNCATE_MODE_MAX) &&
        (trap_group_attributes_p->truncate_mode < SX_TRUNCATE_MODE_MIN)) {
        SX_LOG_ERR("Illegal truncate_mode (%u)\n", trap_group_attributes_p->truncate_mode);
        return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    if ((trap_group_attributes_p->control_type != SX_CONTROL_TYPE_DEFAULT) &&
        (trap_group_attributes_p->control_type != SX_CONTROL_TYPE_ENABLE) &&
        (trap_group_attributes_p->control_type != SX_CONTROL_TYPE_DISABLE)) {
        SX_LOG_ERR("Illegal control_type (%u)\n", trap_group_attributes_p->control_type);
        return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    if (trap_group_attributes_p->timestamp_source > SX_PACKET_TIMESTAMP_SOURCE_MAX_E) {
        SX_LOG_ERR("Illegal timestamp_source (%u)\n", trap_group_attributes_p->timestamp_source);
        return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    if ((trap_group_attributes_p->is_monitor == TRUE) && (trap_group_attributes_p->is_tac_capable == TRUE)) {
        SX_LOG_ERR("is_monitor and is_tac_capable are mutually exclusive and can't be both TRUE.\n");
        return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    /* If created trap group is tac capable , need to validate that TAC is enabled in Tele module */
    if (trap_group_attributes_p->is_tac_capable == TRUE) {
        rc = __host_ifc_tac_is_enabled(&tac_is_enabled);
        if (SX_CHECK_FAIL(rc) || (tac_is_enabled == FALSE)) {
            SX_LOG_ERR("Can't add TAC capable Trap group when Tele module TAC mode is DISABLED.\n");
            return __SX_LOG_EXIT(rc);
        }
    }

    if (brg_context.spec_cb_g.host_ifc_trap_group_set_cb) {
        rc = brg_context.spec_cb_g.host_ifc_trap_group_set_cb(swid, trap_group,
                                                              trap_group_attributes_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set trap group %u for swid %u, return value: [%s]\n",
                       trap_group, swid, sx_status_str(rc));
            return __SX_LOG_EXIT(rc);
        }
    }

    bit_vector_set(__bitmap_valid_trap_group, trap_group);

    rc = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group mapping from the DB, [trap_group = %u], return value: [%s].\n",
                   trap_group, SX_STATUS_MSG(rc));
        return __SX_LOG_EXIT(rc);
    }
    *hw_trap_group_p = hw_trap_group_id;

    /* If Trap Group is TAC capable then add it to TAC Trap Group DB */
    if (trap_group_attributes_p->is_tac_capable == TRUE) {
        rc = __host_ifc_trap_group_tac_db_update(SX_ACCESS_CMD_ADD, trap_group, hw_trap_group_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Trap group TAC validation failed.\n");
            return __SX_LOG_EXIT(rc);
        }
    }

    return rc;
}

sx_status_t host_ifc_trap_group_set(sx_swid_id_t                swid,
                                    sx_trap_group_t             trap_group,
                                    sx_trap_group_attributes_t *trap_group_attributes_p,
                                    uint32_t                   *hw_trap_group_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = __trap_group_allocate_mode_set(SX_ACCESS_CMD_SET);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set trap group allocate mode.\n");
        return rc;
    }

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    if (TRAP_GROUP_ID_MAX_CHECK_MAX(trap_group) == FALSE) {
        SX_LOG_ERR("HOST_IFC: trap group : %d exceeds range %d.\n",
                   trap_group, TRAP_GROUP_ID_MAX);
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (FALSE == RM_SWID_CHECK_RANGE(swid)) {
        SX_LOG_ERR("SWID (%u) exceeds range (%d...%d).\n", swid, 0,
                   rm_resource_global.swid_id_max);
        return __SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(trap_group_attributes_p, "trap_group_attributes_p"))) {
        SX_LOG_ERR("trap_group_attributes_p is NULL.\n");
        return __SX_LOG_EXIT(SX_STATUS_PARAM_NULL);
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(hw_trap_group_p, "hw_trap_group_p"))) {
        SX_LOG_ERR("hw_trap_group_p is NULL.\n");
        return __SX_LOG_EXIT(SX_STATUS_PARAM_NULL);
    }

    /* Legacy api sx_api_trap_group_set doesn't support tac capable Trap groups */
    if (trap_group_attributes_p->is_tac_capable == TRUE) {
        SX_LOG_ERR("sx_api_host_ifc_trap_group_set doesn't support TAC capable Trap groups.\n");
        return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    if (SX_CHECK_FAIL(rc =
                          __host_ifc_trap_group_set_impl(swid, trap_group, trap_group_attributes_p,
                                                         hw_trap_group_p))) {
        SX_LOG_ERR("Failed to set trap group.\n");
        return __SX_LOG_EXIT(rc);
    }

    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_trap_group_ext_set(sx_swid_id_t                swid,
                                        sx_access_cmd_t             cmd,
                                        sx_trap_group_t             trap_group,
                                        sx_trap_group_attributes_t *trap_group_attributes_p,
                                        uint32_t                   *hw_trap_group_p)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_trap_group_t            sw_trap_group_id = 0;
    sx_trap_group_attributes_t curr_trap_group_attributes;

    SX_LOG_ENTER();

    SX_MEM_CLR(curr_trap_group_attributes);

    rc = __trap_group_allocate_mode_set(cmd);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set trap group allocate mode for command [%d].\n", cmd);
        goto out;
    }

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (FALSE == RM_SWID_CHECK_RANGE(swid)) {
        SX_LOG_ERR("SWID (%u) exceeds range (%d...%d).\n", swid, 0,
                   rm_resource_global.swid_id_max);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(trap_group_attributes_p, "trap_group_attributes_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(hw_trap_group_p, "hw_trap_group_p"))) {
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_CREATE) {
        if (TRAP_GROUP_ID_MAX_CHECK_MAX(trap_group) == FALSE) {
            SX_LOG_ERR("HOST_IFC: trap group : %d exceeds range %d.\n",
                       trap_group, TRAP_GROUP_ID_MAX);
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        if ((trap_group_attributes_p->truncate_mode == SX_TRUNCATE_MODE_PROFILE_ENABLE) &&
            (!SX_TRAP_TRUNCATE_PROFILE_CHECK_RANGE(trap_group_attributes_p->trunc_profile_id))) {
            SX_LOG_ERR("trunc_profile_id is out of range.\n");
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        rc = host_ifc_db_allocate_trap_group(swid, &sw_trap_group_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to allocate a free trap group from DB.\n");
            goto out;
        }

        rc = __host_ifc_trap_group_set_impl(swid, sw_trap_group_id, trap_group_attributes_p, hw_trap_group_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to create trap group.\n");
            goto out;
        }

        trap_group_attributes_p->trap_group = sw_trap_group_id;

        break;

    case SX_ACCESS_CMD_EDIT:
        if ((trap_group_attributes_p->truncate_mode == SX_TRUNCATE_MODE_PROFILE_ENABLE) &&
            (!SX_TRAP_TRUNCATE_PROFILE_CHECK_RANGE(trap_group_attributes_p->trunc_profile_id))) {
            SX_LOG_ERR("trunc_profile_id is out of range.\n");
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        /* Check if a HW trap group is already mapped to the trap group ID */
        rc = host_ifc_db_trap_group_map_get(swid, trap_group, hw_trap_group_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get HW trap group ID for swid %u, trap group %u, return value: [%s]\n",
                       swid, trap_group, sx_status_str(rc));
            goto out;
        }

        if (*hw_trap_group_p == SX_HW_TRAP_GROUP_DISABLE_E) {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Trap group %u is not allocated yet, return value: [%s]\n",
                       trap_group, sx_status_str(rc));
            goto out;
        }

        rc = host_ifc_trap_group_get(trap_group, swid, &curr_trap_group_attributes);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get trap group attributes.\n");
            goto out;
        }

        /* EDIT operation isn't allowed on TAC capable trap groups */
        if (curr_trap_group_attributes.is_tac_capable == TRUE) {
            rc = SX_STATUS_CMD_ERROR;
            SX_LOG_ERR("Failed to edit trap group %d. EDIT operation isn't allowed on TAC capable trap groups.\n",
                       trap_group);
            goto out;
        }

        /* non TAC trap group can't be converted to TAC trap group
         * (the previous if check if is_tac_capable is FALSE */
        if (trap_group_attributes_p->is_tac_capable == TRUE) {
            rc = SX_STATUS_CMD_ERROR;
            SX_LOG_ERR(
                "Failed to edit trap group %d. EDIT operation can't change is_tac_capable attribute of trap groups.\n",
                trap_group);
            goto out;
        }

        rc = __host_ifc_trap_group_set_impl(swid, trap_group, trap_group_attributes_p, hw_trap_group_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to create trap group.\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_SET:
        rc = __host_ifc_trap_group_set_impl(swid, trap_group, trap_group_attributes_p, hw_trap_group_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to create trap group.\n");
            goto out;
        }
        trap_group_attributes_p->trap_group = trap_group;
        break;

    case SX_ACCESS_CMD_DESTROY:
    /* Fall through */
    case SX_ACCESS_CMD_UNSET:
        rc = __host_ifc_trap_group_unset_impl(swid, trap_group, trap_group_attributes_p, hw_trap_group_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to create trap group.\n");
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __host_ifc_trap_group_unset_impl(sx_swid_id_t                swid,
                                                    sx_trap_group_t             trap_group,
                                                    sx_trap_group_attributes_t *trap_group_attributes_p,
                                                    uint32_t                   *hw_trap_group_p)
{
    sx_status_t                rc = SX_STATUS_SUCCESS, rb_rc;
    sx_trap_group_attributes_t curr_trap_group_attributes;
    boolean_t                  tac_trap_group_removed = FALSE;

    rc = host_ifc_trap_group_get(trap_group, swid, &curr_trap_group_attributes);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group attributes.\n");
        goto out;
    }

    /* If the destroyed Trap Group is TAC capable then delete it from TAC Trap Group DB */
    if (curr_trap_group_attributes.is_tac_capable == TRUE) {
        rc = __host_ifc_trap_group_tac_db_update(SX_ACCESS_CMD_DELETE, trap_group, 0);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Trap group TAC validation failed.\n");
            goto out;
        }
        tac_trap_group_removed = TRUE;
    }

    if (brg_context.spec_cb_g.host_ifc_trap_group_unset_cb) {
        rc = brg_context.spec_cb_g.host_ifc_trap_group_unset_cb(swid, trap_group,
                                                                trap_group_attributes_p,
                                                                hw_trap_group_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to unset trap group %u for swid %u, return value: [%s]\n",
                       trap_group, swid, sx_status_str(rc));
            goto out;
        }
    }

    bit_vector_clear(__bitmap_valid_trap_group, trap_group);

out:
    if (SX_CHECK_FAIL(rc) && (tac_trap_group_removed == TRUE)) {
        rb_rc = __host_ifc_trap_group_tac_db_update(SX_ACCESS_CMD_ADD, trap_group, *hw_trap_group_p);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_ERR("Rollback to add TAC Trap group failed.\n");
        }
    }

    return rc;
}


sx_status_t host_ifc_trap_group_get(sx_trap_group_t             trap_group,
                                    sx_swid_id_t                swid,
                                    sx_trap_group_attributes_t *trap_group_attributes_p)
{
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    sx_hw_trap_group_e               hw_trap_group;
    sx_status_t                      rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_group_properties);

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    if (TRAP_GROUP_ID_MAX_CHECK_MAX(trap_group) == FALSE) {
        SX_LOG_ERR("HOST_IFC: trap group : %d exceeds range %d.\n",
                   trap_group, TRAP_GROUP_ID_MAX);
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (FALSE == SX_SWID_CHECK_RANGE(swid)) {
        SX_LOG_ERR("SWID (%u) exceeds range (%d...%d).\n", swid, SX_SWID_ID_MIN, SX_SWID_ID_MAX);
        return __SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(trap_group_attributes_p, "trap_group_attributes_p"))) {
        return __SX_LOG_EXIT(rc);
    }

    rc = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group mapping from the DB, [trap_group = %u], return value: [%s].\n",
                   trap_group, sx_status_str(rc));
        goto out;
    }

    if (hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
        return __SX_LOG_EXIT(SX_STATUS_ENTRY_NOT_FOUND);
    }

    /* Get trap priority DB parameters */
    rc = host_ifc_db_trap_group_properties_get(swid,
                                               hw_trap_group,
                                               &trap_group_properties,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to fetch trap group properties from DB, [hw_trap_group = %u], return value: [%s].\n",
                   hw_trap_group, sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    /* Validity check - group configured */
    if (is_trap_group_configured == FALSE) {
        return __SX_LOG_EXIT(SX_STATUS_ERROR);
    }

    trap_group_attributes_p->truncate_mode = trap_group_properties.truncate_mode;
    trap_group_attributes_p->truncate_size = trap_group_properties.truncate_size;
    trap_group_attributes_p->trunc_profile_id = trap_group_properties.trunc_profile_id;
    trap_group_attributes_p->prio = trap_group_properties.priority;
    trap_group_attributes_p->control_type = trap_group_properties.control_type;
    trap_group_attributes_p->add_timestamp = trap_group_properties.add_timestamp;
    trap_group_attributes_p->timestamp_source = trap_group_properties.timestamp_source;
    trap_group_attributes_p->is_tac_capable = trap_group_properties.is_tac_capable;
    trap_group_attributes_p->is_monitor = trap_group_properties.is_monitor;
    trap_group_attributes_p->monitor_fd = trap_group_properties.monitor_fd;
    trap_group_attributes_p->hw_trap_group = hw_trap_group;

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_trap_group_iter_get(const sx_access_cmd_t         cmd,
                                         const sx_swid_id_t            swid,
                                         const sx_trap_group_t         trap_group_id,
                                         const sx_trap_group_filter_t *filter_p,
                                         sx_trap_group_t              *trap_group_id_list_p,
                                         uint32_t                     *trap_group_id_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    err = host_ifc_db_trap_group_iter_get(cmd,
                                          swid,
                                          trap_group_id,
                                          filter_p,
                                          trap_group_id_list_p,
                                          trap_group_id_cnt_p);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to fetch trap group IDs from DB, return value: [%s].\n",
                   sx_status_str(err));
    }

    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_trap_id_get(sx_trap_id_t      trap_id,
                                 sx_swid_t         swid,
                                 sx_trap_action_t *trap_action,
                                 sx_trap_group_t  *trap_group)
{
    host_ifc_trap_id_properties_t trap_id_properties;
    sx_trap_priority_t            trap_priority;
    sx_status_t                   rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_id_properties);

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    /* inputs check */
    rc = trap_id_is_supported_device(trap_id);
    if (SX_CHECK_FAIL(rc)) {
        return __SX_LOG_EXIT(rc);
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(trap_action, "trap_action"))) {
        return __SX_LOG_EXIT(rc);
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(trap_group, "trap_group"))) {
        return __SX_LOG_EXIT(rc);
    }

    /* Get trap ID DB parameters */
    rc = host_ifc_db_trap_id_properties_get(trap_id, &trap_id_properties);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to fetch trap ID properties from DB, return value: [%s].\n",
                   sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    /* trap group -> trap priority */
    /* Some of the traps get default action but they are not attached to trap group as part of SDK init.
     * In this case we will bypass the validation on GROUP_DISABLE*/
    if (trap_id_properties.hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
        if ((trap_id_properties.trap_action == SX_TRAP_ACTION_IGNORE) ||
            (trap_id_properties.trap_action == SX_TRAP_ACTION_DISCARD) ||
            (trap_id_properties.trap_action == SX_TRAP_ACTION_SOFT_DISCARD) ||
            (trap_id_properties.trap_action == SX_TRAP_ACTION_SET_FW_DEFAULT)) {
            trap_id_properties.hw_trap_group = 0;
        }
    }
    rc = __host_ifc_trap_group_2_trap_prio(trap_id_properties.hw_trap_group, &trap_priority);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Trap ID [%d] was not bound to any trap group. return value: [%s].\n",
                   trap_id, sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    *trap_action = trap_id_properties.trap_action;
    rc = host_ifc_db_trap_group_reverse_map_get(swid, trap_id_properties.hw_trap_group, trap_group);

    return __SX_LOG_EXIT(rc);
}

static sx_status_t __trap_group_allocate_mode_set(sx_access_cmd_t cmd)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    host_ifc_trap_group_allocate_mode_e new_allocate_mode = HOST_IFC_TRAP_GROUP_ALLOCATE_MODE_INVALID_E;

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
    case SX_ACCESS_CMD_EDIT:
    case SX_ACCESS_CMD_DESTROY:
        new_allocate_mode = HOST_IFC_TRAP_GROUP_ALLOCATE_MODE_DYNAMIC_E;
        break;

    case SX_ACCESS_CMD_SET:
    case SX_ACCESS_CMD_UNSET:
        new_allocate_mode = HOST_IFC_TRAP_GROUP_ALLOCATE_MODE_STATIC_E;
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported trap group set command [%d].\n", cmd);
        goto out;
        break;
    }

    if ((g_trap_group_allocate_mode != new_allocate_mode) &&
        (g_trap_group_allocate_mode != HOST_IFC_TRAP_GROUP_ALLOCATE_MODE_INVALID_E)) {
        /* We cannot change legacy to new or vise-versa or change to default trap group allocation mode */
        rc = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR("Trap group allocation mode can not be changed [%s], current mode [%d], new mode [%d].\n",
                   sx_status_str(rc), g_trap_group_allocate_mode, new_allocate_mode);
        goto out;
    }

    g_trap_group_allocate_mode = new_allocate_mode;

out:
    return rc;
}


/*
 * This function will do the logic of SET operation by deciding what
 * should be configured in HPKT and SW BUFFER according to input parameters.
 *
 * IN params :
 * is_regular_group_associated - is regular trap group bound to the trap
 * regular_hw_trap_group       - regular trap group which bound to the trap
 * is_monitor_group_associated - is monitor trap group bound to the trap
 * monitor_hw_trap_group       - monitor trap group which bound to the trap
 * regular_trap_action         - trap action that was configured with regular trap group
 * monitor_trap_action         - trap action that was configured with monitor trap group
 * new_trap_action             - new trap action for currently configured trap group
 * new_trap_group_properties_p - properties of newly configured trap group
 *
 * OUT params:
 * update_hpkt_p               - does update of HPKT is required after new trap group set ?
 * update_driver_p             - does update of SW buffer in driver is required after new trap group set ?
 * enable_driver_sw_buff_p     - should SW buffer be enabled for newly added monitor trap group
 * disable_driver_old_sw_buff_p- should SW buffer be disabled for previously configured monitor trap group
 * hw_trap_group_p             - hw trap group that will be configured in HPKT
 * trap_action_p               - trap action which will be configured in HPKT
 * sw_buff_monitor_hw_trap_group_p - monitor trap group that SW buffer should be enabled for
 *
 */
static void __host_ifc_ext_trap_apply_set_logic(boolean_t                         is_regular_group_associated,
                                                sx_hw_trap_group_e                regular_hw_trap_group,
                                                boolean_t                         is_monitor_group_associated,
                                                sx_hw_trap_group_e                monitor_hw_trap_group,
                                                sx_trap_action_t                  regular_trap_action,
                                                sx_trap_action_t                  monitor_trap_action,
                                                sx_trap_action_t                  new_trap_action,
                                                host_ifc_trap_group_properties_t *new_trap_group_properties_p,
                                                boolean_t                        *update_hpkt_p,
                                                boolean_t                        *update_driver_p,
                                                boolean_t                        *enable_driver_sw_buff_p,
                                                boolean_t                        *disable_driver_old_sw_buff_p,
                                                sx_hw_trap_group_e               *hw_trap_group_p,
                                                sx_trap_action_t                 *trap_action_p,
                                                sx_hw_trap_group_e               *sw_buff_monitor_hw_trap_group_p)
{
    boolean_t is_new_trap_group_special = FALSE;

    *disable_driver_old_sw_buff_p = FALSE;

    if ((new_trap_group_properties_p->is_monitor == TRUE) ||
        (new_trap_group_properties_p->is_tac_capable == TRUE)) {
        is_new_trap_group_special = TRUE;
    }

    if (!is_regular_group_associated && !is_monitor_group_associated) {
        /* this is bind of first trap group
         * New state :
         * HPKT: new trap group (monitor or regular) , new action (assigned before if)
         * SW BUFF: don't change
         */
        *update_hpkt_p = TRUE;
        *hw_trap_group_p = new_trap_group_properties_p->group;
        *trap_action_p = new_trap_action;

        *update_driver_p = FALSE;
    } else if (is_regular_group_associated && !is_monitor_group_associated) {
        /* Only regular trap group is bound to this trap
         * no shadowing happen and only new action is matter
         * current state:
         * HPKT : regular trap group wit regular action
         * SW BUFF: disabled
         */

        if (!is_new_trap_group_special) {
            /*
             * The new trap group is regular trap group
             * Currently only single regular trap group is configured
             * So only update of HPKT with new trap group is needed.
             *
             * New state :
             * HPKT: new trap group (regular) , new action
             * SW BUFF: don't change
             */
            *update_hpkt_p = TRUE;
            *hw_trap_group_p = new_trap_group_properties_p->group;
            *trap_action_p = new_trap_action;

            *update_driver_p = FALSE;
        } else {
            /* the new trap group is monitor trap group */

            if (TRAP_ACTION_DISCARD(regular_trap_action)) {
                /*
                 * we will shadow regular trap group by monitor trap group
                 * because trap action is DISCARD
                 * Thus traps will go to monitor trap group and won't be discarded
                 *
                 * New state :
                 * HPKT: monitor trap group, monitor action
                 *      (monitor action is TRAP, regular action in this case is DISCARD)
                 * SW BUFF: don't change
                 */
                *update_hpkt_p = TRUE;
                *hw_trap_group_p = new_trap_group_properties_p->group;
                *trap_action_p = new_trap_action;

                *update_driver_p = FALSE;
            } else {
                /*
                 * trap action isn't DISCARD/DROP
                 * so the new state will be :
                 * HPKT   : no update is needed. Keep regular trap group with regular trap group action
                 * SW BUFF: ENABLED for monitor trap group
                 */
                *update_hpkt_p = FALSE;

                /* this will be used to reflect hw trap configuration in db */
                *hw_trap_group_p = regular_hw_trap_group;
                *trap_action_p = regular_trap_action;

                if ((new_trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP) ||
                    (new_trap_action == SX_TRAP_ACTION_TRAP_2_CPU)) {
                    *update_driver_p = TRUE;
                    *enable_driver_sw_buff_p = TRUE;
                    *sw_buff_monitor_hw_trap_group_p = new_trap_group_properties_p->group;
                }
            }
        } /* if ( ! new_trap_group_properties_p->is_monitor ){ */
    } else if (!is_regular_group_associated && is_monitor_group_associated) {
        /* Only monitor trap group is bound to this trap
         * no shadowing happen and only new action is matter
         */

        /* trap_group_properties.trap_group - newly added trap group */
        if (is_new_trap_group_special) {
            /* new monitor trap group was added (no regular trap group bound)
             * than we only need to replace old monitor trap group
             * Current state :
             * HPKT   : old monitor trap group
             * SW BUFF: DISABLE
             *
             * new state will be :
             * HPKT   : new monitor trap group
             * SW BUFF: don't update
             */
            *update_hpkt_p = TRUE;
            *hw_trap_group_p = new_trap_group_properties_p->group;
            *trap_action_p = new_trap_action;

            *update_driver_p = FALSE;
        } else {
            /* the new trap group is REGULAR trap group */

            if (TRAP_ACTION_DISCARD(new_trap_action)) {
                /* we will shadow regular trap group by monitor trap group because action is DISCARD/DROP
                 *
                 * Current state :
                 * HPKT   : monitor trap group with monitor action
                 * SW BUFF: DISABLED
                 *
                 * New state
                 * HPKT   : monitor trap group with monitor action,
                 *          the same like before so no update is needed
                 * SW BUFF: DISABLED ,
                 *          the same like before so no update is needed
                 * */
                *update_hpkt_p = FALSE;

                /* this will be used to reflect hw trap configuration in db */
                *hw_trap_group_p = monitor_hw_trap_group;
                *trap_action_p = monitor_trap_action;

                *update_driver_p = FALSE;
            } else {
                /* trap action isn't DISCARD/DROP , so HPKT will point to new regular trap group and
                 *  we will enable SW buff */
                *update_hpkt_p = TRUE;
                *hw_trap_group_p = new_trap_group_properties_p->group;
                *trap_action_p = new_trap_action;

                if ((monitor_trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP) ||
                    (monitor_trap_action == SX_TRAP_ACTION_TRAP_2_CPU)) {
                    *update_driver_p = TRUE;
                    *enable_driver_sw_buff_p = TRUE;
                    *sw_buff_monitor_hw_trap_group_p = monitor_hw_trap_group;
                }
            }
        }
    } else { /* is_regular_group_associated && is_monitor_group_associated */
        /* Both regular and monitor trap groups is bound to this trap */

        if (TRAP_ACTION_DISCARD(regular_trap_action)) {
            /* if regular trap action is DISCARD
             * and both regular and monitor trap groups are configured then
             * current state :
             * HPKT      : old monitor trap group (regular trap group is shadowed by monitor)
             * SW buffer : DISABLED for old monitor trap group
             */

            if (TRAP_ACTION_DISCARD(new_trap_action)) {
                /* we continue to shadow regular trap group by monitor trap group */
                if (is_new_trap_group_special) {
                    /*
                     * HPKT : update with new monitor trap group
                     * SW BUFF: don't update
                     */
                    *update_hpkt_p = TRUE;
                    *trap_action_p = new_trap_action;       /* shadow trap action as well */
                    *hw_trap_group_p = new_trap_group_properties_p->group;

                    *update_driver_p = FALSE;
                } else {
                    /*
                     * HPKT   : don't update
                     * SW BUFF: don't update
                     * only DB will be updated
                     */

                    *update_hpkt_p = FALSE;

                    /* this will be used to reflect hw trap configuration in db */
                    *hw_trap_group_p = monitor_hw_trap_group;
                    *trap_action_p = monitor_trap_action;

                    *update_driver_p = FALSE;
                }
            } else {  /* if (TRAP_ACTION_DISCARD(new_trap_action)) { */
                /* we remove shadowing of old regular trap group by old monitor trap group
                 * Current state:
                 * HPKT   : monitor trap group with monitor action
                 * SW BUFF: disabled
                 * */
                if (is_new_trap_group_special) {
                    /*
                     * New state :
                     * HPKT   : regular trap group with regular action
                     * SW BUFF: enabled for new monitor trap group
                     * */

                    *update_hpkt_p = TRUE;
                    *hw_trap_group_p = new_trap_group_properties_p->group;
                    *trap_action_p = new_trap_action;

                    *update_driver_p = FALSE;
                } else {
                    /*
                     * New state :
                     * HPKT : update with new regular trap group
                     * SW BUFF: enable for old monitor trap group
                     */
                    *update_hpkt_p = TRUE;
                    *hw_trap_group_p = new_trap_group_properties_p->group;
                    *trap_action_p = new_trap_action;

                    if ((monitor_trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP) ||
                        (monitor_trap_action == SX_TRAP_ACTION_TRAP_2_CPU)) {
                        *update_driver_p = TRUE;
                        *enable_driver_sw_buff_p = TRUE;
                        *sw_buff_monitor_hw_trap_group_p = monitor_hw_trap_group;
                    }
                }
            }
        } else {     /* if (TRAP_ACTION_DISCARD(regular_trap_action)) { */
            /* if regular trap action != DISCARD
             * and both regular and monitor trap groups are configured than
             * HPKT      : old regular trap group
             * SW buffer : ENABLED for old monitor trap group
             */

            if (TRAP_ACTION_DISCARD(new_trap_action)) {
                if (is_new_trap_group_special) {
                    /* Added monitor trap group with action DISCARD
                     * HPKT : don't update, keep use regular trap group with regular action
                     * SW BUFF: DISABLE for old monitor trap group ,
                     * and don't enable for new monitor trap group because new action DISCARD
                     */
                    *update_hpkt_p = FALSE;

                    /* this will be used to reflect hw trap configuration in db */
                    *hw_trap_group_p = regular_hw_trap_group;
                    *trap_action_p = regular_trap_action;

                    *update_driver_p = TRUE;
                    *enable_driver_sw_buff_p = FALSE;
                    *sw_buff_monitor_hw_trap_group_p = monitor_hw_trap_group;
                } else {
                    /* Added regular trap group with action DISCARD
                     * in this case SDK will shadow regular trap group with
                     * monitor trap group.
                     *
                     * HPKT   : update with new monitor trap group and monitor action
                     * SW BUFF: disable SW BUFF for monitor trap group
                     * only DB will be updated
                     */

                    *update_hpkt_p = TRUE;
                    *hw_trap_group_p = monitor_hw_trap_group;
                    *trap_action_p = monitor_trap_action;

                    *update_driver_p = TRUE;
                    *enable_driver_sw_buff_p = FALSE;
                    *sw_buff_monitor_hw_trap_group_p = monitor_hw_trap_group;
                }
            } else {
                /* we continue without shadowing of old regular trap group by old monitor trap group */
                if (is_new_trap_group_special) {
                    /*
                     * HPKT : don't update
                     *
                     * SW BUFF:
                     * DISABLE for old monitor trap group
                     * ENABLE with new regular trap group
                     *
                     */

                    *update_hpkt_p = FALSE;

                    /* this will be used to reflect hw trap configuration in db */
                    *hw_trap_group_p = monitor_hw_trap_group;
                    *trap_action_p = monitor_trap_action;

                    *update_driver_p = TRUE;
                    if ((new_trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP) ||
                        (new_trap_action == SX_TRAP_ACTION_TRAP_2_CPU)) {
                        /* enable SW_BUFF for new monitor trap group only if new_action is TRAP or
                         * EXCEPTION_TRAP and disable SW BUFF for old monitor trap group */
                        *enable_driver_sw_buff_p = TRUE;
                        *sw_buff_monitor_hw_trap_group_p = new_trap_group_properties_p->group;
                        *disable_driver_old_sw_buff_p = TRUE;
                    } else {
                        /* if new action != TRAP or EXCEPTION_TRAP only disable SW BUFF
                         * for old monitor trap group */
                        *enable_driver_sw_buff_p = FALSE;
                        *sw_buff_monitor_hw_trap_group_p = monitor_hw_trap_group;
                    }
                } else {
                    /*
                     * HPKT : update with new regular trap group
                     * SW BUFF: DON'T update
                     *
                     */

                    *update_hpkt_p = TRUE;
                    *hw_trap_group_p = new_trap_group_properties_p->group;
                    *trap_action_p = new_trap_action;

                    *update_driver_p = FALSE;
                }
            }     /* if ( TRAP_ACTION_DISCARD(new_trap_action) ) { */
        }     /* // if ( TRAP_ACTION_DISCARD(trap_id_properties_p->trap_action) ) { */
    }     /* if ( !is_regular_group_associated && is_monitor_group_associated ) { */

    SX_LOG_DBG("host_ifc_ext_trap_id_set SET logic: \n"
               "IN: is_reg_tg:%d, reg_hw_tg:%d, is_mon_tg:%d, mon_hw_tg:%d \n"
               "IN: reg_trap_action:%d, mon_trap_action:%d, new_trap_action:%d, new_hw_tg:%d, is_new_tg_mon:%d \n"
               "OUT: update_hpkt:%d, update_driver:%d, enable_driver_sw_buff:%d, \n"
               "OUT: hw_tg:%d, tg_action:%d, sw_buf_mon_tg:%d",
               is_regular_group_associated, regular_hw_trap_group,
               is_monitor_group_associated, monitor_hw_trap_group,
               regular_trap_action, monitor_trap_action, new_trap_action,
               new_trap_group_properties_p->group, new_trap_group_properties_p->is_monitor,
               *update_hpkt_p, *update_driver_p,  *enable_driver_sw_buff_p,
               *hw_trap_group_p, *trap_action_p, *sw_buff_monitor_hw_trap_group_p
               );
}

/*
 * This function will do the logic of UNSET operation by deciding what
 * should be configured in HPKT and SW BUFFER according to input parameters.
 *
 * IN params :
 * is_regular_group_associated - is regular trap group bound to the trap
 * regular_hw_trap_group       - regular trap group which bound to the trap
 * is_monitor_group_associated - is monitor trap group bound to the trap
 * monitor_hw_trap_group       - monitor trap group which bound to the trap
 * regular_trap_action         - trap action that was configured with regular trap group
 * monitor_trap_action         - trap action that was configured with monitor trap group
 * new_trap_group_properties_p - properties of newly configured trap group
 *
 * OUT params:
 * last_group_removed_p        - indicate that last group was unbound from the trap
 * update_hpkt_p               - does update of HPKT is required after new trap group set ?
 * update_driver_p             - does update of SW buffer in driver is required after new trap group set ?
 * enable_driver_sw_buff_p     - should SW buffer be enabled for newly added monitor trap group
 * hw_trap_group_p             - hw trap group that will be configured in HPKT
 * trap_action_p               - trap action which will be configured in HPKT
 * sw_buff_monitor_hw_trap_group_p - monitor trap group that SW buffer should be enabled for
 *
 */
static void __host_ifc_ext_trap_apply_unset_logic(boolean_t                         is_regular_group_associated,
                                                  sx_hw_trap_group_e                regular_hw_trap_group,
                                                  boolean_t                         is_monitor_group_associated,
                                                  sx_hw_trap_group_e                monitor_hw_trap_group,
                                                  sx_trap_action_t                  regular_trap_action,
                                                  sx_trap_action_t                  monitor_trap_action,
                                                  host_ifc_trap_group_properties_t *new_trap_group_properties_p,
                                                  boolean_t                        *last_group_removed_p,
                                                  boolean_t                        *update_hpkt_p,
                                                  boolean_t                        *update_driver_p,
                                                  boolean_t                        *enable_driver_sw_buff_p,
                                                  sx_hw_trap_group_e               *hw_trap_group_p,
                                                  sx_trap_action_t                 *trap_action_p,
                                                  sx_hw_trap_group_e               *sw_buff_monitor_hw_trap_group_p)
{
    *last_group_removed_p = FALSE;

    if (is_regular_group_associated && is_monitor_group_associated) {
        /* regular and monitor trap groups are associated with the trap */

        if (TRAP_ACTION_DISCARD(regular_trap_action)) {
            /* Current trap action is DISCARD this mean that
             * the regular trap group is shadowed by monitor trap group
             *
             * HPKT   : monitor trap group with monitor action
             * SW BUFF: DISABLED
             */

            if (new_trap_group_properties_p->is_monitor) {
                /*  we shadowed regular trap group by monitor trap group because action is DISCARD/DROP
                 *  so if we remove WJH group now , than need to configure HPKT with regular trap group
                 *  New state will be :
                 *  HPKT   : regular trap group with action
                 *  SW BUFF: DISABLED
                 */

                *update_hpkt_p = TRUE;
                *hw_trap_group_p = regular_hw_trap_group;
                *trap_action_p = regular_trap_action;

                *update_driver_p = FALSE;
            } else {
                /*
                 *  regular trap group is removed.
                 *  Only DB will be updated in upper layer.
                 *  No update is needed.
                 *  The state will remain the same :
                 *  HPKT   : monitor trap group with monitor action
                 *  SW BUFF: DISABLED
                 */
                *update_driver_p = FALSE;

                *update_hpkt_p = FALSE;
                *hw_trap_group_p = monitor_hw_trap_group;
                *trap_action_p = monitor_trap_action;
            }
        } else {
            /*
             * Current state :
             * HPKT   : regular trap group
             * SW BUFF: ENABLED
             */


            if (new_trap_group_properties_p->is_monitor) {
                *update_hpkt_p = FALSE;

                /* this will be used to reflect hw trap configuration in db */
                *hw_trap_group_p = regular_hw_trap_group;
                *trap_action_p = regular_trap_action;

                /* if we remove monitor TG than we need to disable driver sw buff */
                *update_driver_p = TRUE;
                *enable_driver_sw_buff_p = FALSE;
                *sw_buff_monitor_hw_trap_group_p = monitor_hw_trap_group;
            } else {
                /* if regular trap group is removed than the new state will be
                 * HPKT    : monitor trap group with monitor action
                 * SW BUFF : DISABLED
                 */
                *hw_trap_group_p = monitor_hw_trap_group;
                *trap_action_p = monitor_trap_action;
                *update_hpkt_p = TRUE;

                *update_driver_p = TRUE;
                *enable_driver_sw_buff_p = FALSE;
                *sw_buff_monitor_hw_trap_group_p = monitor_hw_trap_group;
            }
        }
    } else {
        /* one of the trap groups is bound : regular or monitor */

        *last_group_removed_p = TRUE;

        *update_hpkt_p = FALSE;     /* if last group is removed , __host_ifc_default_actions_set will set hpkt */
        *update_driver_p = FALSE;
    } /* if (is_regular_group_associated && is_monitor_group_associated) { */

    SX_LOG_DBG("host_ifc_ext_trap_id_set UNSET logic: \n"
               "IN: is_reg_tg:%d, reg_hw_tg:%d, is_mon_tg:%d, mon_hw_tg:%d \n"
               "IN: reg_trap_action:%d, mon_trap_action:%d, new_hw_tg:%d, is_new_tg_mon:%d \n"
               "OUT: update_hpkt:%d, update_driver:%d, enable_driver_sw_buff:%d, \n"
               "OUT: hw_tg:%d, tg_action:%d, sw_buf_mon_tg:%d",
               is_regular_group_associated, regular_hw_trap_group,
               is_monitor_group_associated, monitor_hw_trap_group,
               regular_trap_action, monitor_trap_action,
               new_trap_group_properties_p->group, new_trap_group_properties_p->is_monitor,
               *update_hpkt_p, *update_driver_p,  *enable_driver_sw_buff_p,
               *hw_trap_group_p, *trap_action_p, *sw_buff_monitor_hw_trap_group_p
               );
}


/* The following function is used to configure trap id with specified attributes (group, action).
 * Note that this function supports SET/UNSET flow and allows to bind the same trap id to two
 * different trap groups (must be one regular and one monitor trap group).
 *
 * Logic of this function allows to support trap double registration on the SPC/SPC2 chips
 * despite on the HW limitation which doesn't allow bind the same trap id to multiple trap
 * groups.
 *
 * Function configure HPKT register to notify HW that trap id bound to the particular RDQ and
 * check whether we should start/stop copying packets which match to trap to the SW buffer which
 * is used to handle HW limitation.
 *
 * In case when regular trap group action is DISCARD , HPKT will be configured with monitor trap
 * group. We want to continue to receive packets to monitor trap group even if these packets will
 * be discarded by regular trap group.
 *
 * Logic of the function is the following:
 * cmd == SET (implemented by __host_ifc_ext_trap_apply_set_logic)
 | ---------------------------------------------------------------------------------------------
 | First reg:     | Second reg: |Added trap group:|Action to perform:
 | ---------------------------------------------------------------------------------------------
 |  None           | None          |{NOS/WJH, Action}|HPKT: {NOS/WJH, Action}
 |                 |               |                 |DB  : {NOS/WJH, Action}
 |  ----------------------------------------------------------------------------------------------
 |  {NOS1, Action1}| None          |{NOS2,Action2}   |HPKT: {NOS1, Action1} ->
 |                 |               |                 |      {NOS2, Action2}
 |                 |               |                 |DB  : {NOS1, Action1} ->
 |                 |               |                 |      {NOS2, Action2}
 |  ----------------------------------------------------------------------------------------------
 |  {NOS1, Action1}| None          |{WJH2,Action2}   |Action1 != DISCARD (NOS action)
 |                 |               |                 |HPKT  : {NOS1, Action1}
 |                 |               |                 |Driver: Enabled SW Buffer for WJH2
 |                 |               |                 |DB    : {NOS1, Action1} ->
 |                 |               |                 |        {NOS1, Action1}, {WJH2,Action2}
 |                 |               |                 |
 |                 |               |                 |Action1 == DISCARD (NOS action)
 |                 |               |                 |HPKT  : {NOS1, Action1} ->
 |                 |               |                 |        {WJH2, Action2}
 |                 |               |                 |DB    : {NOS1, Action1} ->
 |                 |               |                 |        {NOS1, Action1}, {WJH2,Action2}
 |  ----------------------------------------------------------------------------------------------
 |  {WJH1, Action1}| None          | {NOS2, Action2} |Action2 != DISCARD (NOS action)
 |                 |               |                 |HPKT  : {NOS2, Action2}
 |                 |               |                 |Driver:  Enabled SW Buffer for WJH2
 |                 |               |                 |DB    : {WJH1, Action1} ->
 |                 |               |                 |        {WJH1,Action1}, {NOS2, Action2}
 |                 |               |                 |
 |                 |               |                 |Action2 == DISCARD (NOS action)
 |                 |               |                 |HPKT  : {WJH1, Action1}
 |                 |               |                 |DB    : {WJH1, Action1} ->
 |                 |               |                 |        {WJH1, Action1}, {NOS2,Action2}
 |----------------------------------------------------------------------------------------------
 | {WJH1, Action1} |  None         | {WJH2, Action2} |HPKT  : {WJH2, Action2}
 |                 |               |                 |DB    : {WJH1, Action1} ->  {WJH2, Action2}
 |----------------------------------------------------------------------------------------------
 |  {WJH1, Action1}|{NOS2,Action2} |{NOS3, Action3}  |Action3 != DISCARD (NOS action)
 |  or vise versa  |               |                 |HPKT  : {NOS3, Action3}
 |                 |               |                 |Driver:  Enabled SW Buffer for WJH2
 |                 |               |                 |DB    : {WJH1, Action1},{NOS2, Action2}->
 |                 |               |                 |        {WJH1,Action1},{NOS3, Action3}
 |                 |               |                 |
 |                 |               |                 |Action3 == DISCARD (NOS action)
 |                 |               |                 |HPKT  : {WJH1, Action1}
 |                 |               |                 |DB    : {WJH1, Action1},{NOS2, Action2}->
 |                 |               |                 |        {WJH1, Action1}, {NOS3,Action3}
 |----------------------------------------------------------------------------------------------
 |  {WJH1,Action1} |{NOS2,Action2} | {WJH3, Action3} |Action2 != DISCARD (NOS action)
 |  or vise versa  |               |                 |HPKT  : {NOS2, Action2}
 |                 |               |                 |Driver:  Enabled SW Buffer for WJH3
 |                 |               |                 |DB    : {WJH1, Action1}, {NOS2, Action2} ->
 |                 |               |                 |        {WJH3,Action3}, {NOS2, Action2}
 |                 |               |                 |
 |                 |               |                 |Action2 == DISCARD (NOS action)
 |                 |               |                 |HPKT  : {WJH3, Action3}
 |                 |               |                 |DB    : {WJH1, Action1}, {NOS2, Action2} ->
 |                 |               |                 |        {WJH3, Action3}, {NOS3,Action3}
 |----------------------------------------------------------------------------------------------
 |
 ** cmd == UNSET (implemented by __host_ifc_ext_trap_apply_unset_logic)
 * First reg:    | Second reg:  |Trap group to del:|Action to perform:
 *  ---------------------------------------------------------------------------------------------------------------------
 *  {NOS/WJH, Action}| None         |{NOS/WJH, Action} |HPKT: {NOS/WJH, Default Action}
 |                   |              |                  |DB  : empty
 |  ----------------------------------------------------------------------------------------------------------------------
 |  {NOS1, Action1}  |{WJH2,Action2}|{NOS1, Action1}   |Action1 != DISCARD (NOS action)
 |   or vise versa   |              |                  |HPKT  : {NOS1, Action1} ->
 |                   |              |                  |        {WJH2,Action2}
 |                   |              |                  |Driver: Disable SW Buffer for WJH2
 |                   |              |                  |DB    : {NOS1, Action1},{WJH2,Action2} ->
 |                   |              |                  |        {WJH2,Action2}
 |                   |              |                  |
 |                   |              |                  |Action1 == DISCARD (NOS action)
 |                   |              |                  |HPKT  : {WJH2,Action2}
 |                   |              |                  |DB    : {NOS1, Action1},{WJH2,Action2} ->
 |                   |              |                  |        {WJH2,Action2}
 |  ----------------------------------------------------------------------------------------------------------------------
 |  {NOS1, Action1}  |{WJH2,Action2}|{WJH2, Action2}   |Action1 != DISCARD (NOS action)
 |  or vise versa    |              |                  |HPKT  : {NOS1, Action1}
 |                   |              |                  |Driver: Disable SW Buffer for WJH2
 |                   |              |                  |DB    : {NOS1, Action1},{WJH2,Action2} ->
 |                   |              |                  |        {NOS1, Action1}
 |                   |              |                  |
 |                   |              |                  |Action1 == DISCARD (NOS action)
 |                   |              |                  |HPKT  : {WJH2,Action2} ->
 |                   |                                 |        {NOS1, Action1}
 |                   |              |                  |DB    : {NOS1, Action1},{WJH2,Action2} ->
 |                   |              |                  |        {NOS1, Action1}
 |  ----------------------------------------------------------------------------------------------------------------------
 |
 */
sx_status_t host_ifc_trap_id_ext_set(sx_access_cmd_t          cmd,
                                     sx_host_ifc_trap_key_t  *trap_key_p,
                                     sx_host_ifc_trap_attr_t *trap_attr_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sxd_status_t                     sxd_err = SXD_STATUS_SUCCESS;
    sx_trap_id_t                     mapped_trap_id = SX_TRAP_ID_MIN;
    host_ifc_trap_id_properties_t    trap_id_properties;
    host_ifc_trap_group_properties_t trap_group_properties;
    sx_swid_t                        swid = 0;
    boolean_t                        is_regular_group_associated = FALSE;
    boolean_t                        is_special_group_associated = FALSE;
    boolean_t                        is_monitor_group_associated = FALSE;
    boolean_t                        is_tac_capable_group_associated = FALSE;
    boolean_t                        update_driver = FALSE;
    boolean_t                        update_hpkt = FALSE;
    boolean_t                        is_db_updated = FALSE;
    boolean_t                        enable_driver_sw_buff = FALSE, disable_driver_old_sw_buff = FALSE;
    boolean_t                        last_group_removed;
    sx_hw_trap_group_e               special_hw_trap_group = SX_HW_TRAP_GROUP_0_E,
                                     sw_buff_mon_hw_trap_group = SX_HW_TRAP_GROUP_0_E;
    sx_hw_trap_group_e               hw_trap_group = SX_HW_TRAP_GROUP_0_E;
    sx_trap_action_t                 special_trap_action = SX_TRAP_ACTION_MIN;
    sx_trap_action_t                 trap_action = SX_TRAP_ACTION_MIN;
    sx_hw_trap_group_e               reg_hw_trap_group = SX_HW_TRAP_GROUP_0_E;
    sx_trap_action_t                 reg_trap_action = SX_TRAP_ACTION_MIN;
    sx_host_ifc_trap_cfg_flow_type_e flow_type = SX_HOST_IFC_TRAP_CFG_FLOW_TYPE_NONE_E;
    boolean_t                        is_in_use = FALSE;
    boolean_t                        has_default_action = FALSE;
    sx_access_cmd_t                  sw_buff_cmd;

    SX_MEM_CLR(trap_id_properties);
    SX_MEM_CLR(trap_group_properties);

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    if (trap_key_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Specified trap_key_p is NULL, return value [%s].\n",
                   sx_status_str(rc));
        goto out;
    }

    if (trap_attr_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Specified trap_attr_p is NULL, return value [%s].\n",
                   sx_status_str(rc));
        goto out;
    }

    /* make sure that used valid trap key value */
    if (trap_key_p->type != HOST_IFC_TRAP_KEY_TRAP_ID_E) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid Trap key type is specified.\n");
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_UNSET) {
        /* If cmd == SX_ACCESS_CMD_UNSET the trap action is reserved.
         * We change the action to SX_TRAP_ACTION_SET_FW_DEFAULT in order to pass validation*/
        if (!SX_TRAP_ID_SW_CHECK_RANGE(trap_key_p->trap_key_attr.trap_id)) {
            rc = trap_id_defaults_get(trap_key_p->trap_key_attr.trap_id,
                                      &has_default_action,
                                      &hw_trap_group,
                                      &trap_action);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("trap_id_defaults_get failed (%s)\n", sx_status_str(rc));
                return __SX_LOG_EXIT(rc);
            }
            if (has_default_action == TRUE) {
                trap_attr_p->attr.trap_id_attr.trap_action = SX_TRAP_ACTION_SET_FW_DEFAULT;
            }
        }
    }

    rc = __host_ifc_trap_id_properties_validate(swid,
                                                trap_key_p->trap_key_attr.trap_id,
                                                trap_attr_p->attr.trap_id_attr.trap_group,
                                                trap_attr_p->attr.trap_id_attr.trap_action);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("__host_ifc_trap_id_properties_validate failed (%s)\n", sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    rc = __host_ifc_trap_id_properties_prepare(swid,
                                               trap_key_p->trap_key_attr.trap_id,
                                               trap_attr_p->attr.trap_id_attr.trap_group,
                                               trap_attr_p->attr.trap_id_attr.trap_action,
                                               &trap_id_properties,
                                               &trap_group_properties);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("__host_ifc_trap_id_properties_prepare failed (%s)\n", sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    /* get the flow type value and make sure that regular and extended flows are not mixed */
    rc = host_ifc_db_trap_id_flow_type_get(trap_key_p->trap_key_attr.trap_id,
                                           trap_attr_p->attr.trap_id_attr.trap_group,
                                           &flow_type);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("host_ifc_db_trap_id_flow_type_get failed (%s)\n", sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    if (flow_type == SX_HOST_IFC_TRAP_CFG_FLOW_TYPE_REGULAR_E) {
        SX_LOG_DBG(
            "Particular trap id 0x%x and trap group %u already configured with regular API - leave this function.\n",
            trap_key_p->trap_key_attr.trap_id,
            trap_attr_p->attr.trap_id_attr.trap_group);
        goto out;
    }

    /* get the current trap binding configuration */
    rc = __host_ifc_trap_id_is_group_associated_get(trap_key_p->trap_key_attr.trap_id,
                                                    &is_regular_group_associated,
                                                    &is_monitor_group_associated,
                                                    &is_tac_capable_group_associated);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in __host_ifc_trap_id_is_group_associated_get, [trap_id = %u], return value: [%s]\n",
                   trap_key_p->trap_key_attr.trap_id,
                   sx_status_str(rc));
        goto out;
    }

    if ((is_monitor_group_associated == TRUE) ||
        (is_tac_capable_group_associated == TRUE)) {
        is_special_group_associated = TRUE;
    }

    if ((cmd == SX_ACCESS_CMD_UNSET) && (is_regular_group_associated == FALSE) &&
        (is_special_group_associated == FALSE)) {
        rc = SX_STATUS_SUCCESS;
        SX_LOG_WRN(
            "There are no associated trap groups with the specified trap id, [trap_id = %u], return value: [%s]\n",
            trap_key_p->trap_key_attr.trap_id,
            sx_status_str(rc));
        goto out;
    }


    if (is_special_group_associated) {
        /* Get the special trap group attributes which we will use to update the kernel */
        rc = __host_ifc_trap_group_associated_attr_get(trap_key_p->trap_key_attr.trap_id, TRUE,
                                                       &special_hw_trap_group,
                                                       &special_trap_action);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in __host_ifc_trap_id_is_group_associated, [trap_id = %u], return value: [%s]\n",
                       trap_key_p->trap_key_attr.trap_id,
                       sx_status_str(rc));
            goto out;
        }
    }

    if (is_regular_group_associated) {
        /* Get the monitor trap group attributes which we will use to update the kernel */
        rc = __host_ifc_trap_group_associated_attr_get(trap_key_p->trap_key_attr.trap_id, FALSE,
                                                       &reg_hw_trap_group,
                                                       &reg_trap_action);

        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in __host_ifc_trap_id_is_group_associated, [trap_id = %u], return value: [%s]\n",
                       trap_key_p->trap_key_attr.trap_id,
                       sx_status_str(rc));
            goto out;
        }
    }

    if (cmd == SX_ACCESS_CMD_UNSET) {
        if (!trap_group_properties.is_monitor && !trap_group_properties.is_tac_capable &&
            !is_regular_group_associated) {
            rc = SX_STATUS_SUCCESS;
            SX_LOG_WRN(
                "Can't unset regular trap group for trap_id:%u because no regular trap group bounded, rc:[%s]\n",
                trap_key_p->trap_key_attr.trap_id,
                sx_status_str(rc));
            goto out;
        }

        if (trap_group_properties.is_monitor && !is_monitor_group_associated) {
            rc = SX_STATUS_SUCCESS;
            SX_LOG_WRN(
                "Can't unset monitor trap group for trap_id:%u because no monitor trap group bounded, rc:[%s]\n",
                trap_key_p->trap_key_attr.trap_id,
                sx_status_str(rc));
            goto out;
        }

        if (trap_group_properties.is_tac_capable && !is_tac_capable_group_associated) {
            rc = SX_STATUS_SUCCESS;
            SX_LOG_WRN(
                "Can't unset TAC-capable trap group for trap_id:%u because no TAC-capable trap group bounded, rc:[%s]\n",
                trap_key_p->trap_key_attr.trap_id,
                sx_status_str(rc));
            goto out;
        }
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        __host_ifc_ext_trap_apply_set_logic(is_regular_group_associated,
                                            reg_hw_trap_group,
                                            is_special_group_associated,
                                            special_hw_trap_group,
                                            reg_trap_action,
                                            special_trap_action,
                                            trap_attr_p->attr.trap_id_attr.trap_action,
                                            &trap_group_properties,
                                            &update_hpkt,
                                            &update_driver,
                                            &enable_driver_sw_buff,
                                            &disable_driver_old_sw_buff,
                                            &hw_trap_group,
                                            &trap_action,
                                            &sw_buff_mon_hw_trap_group);
    } else {
        __host_ifc_ext_trap_apply_unset_logic(is_regular_group_associated,
                                              reg_hw_trap_group,
                                              is_special_group_associated,
                                              special_hw_trap_group,
                                              reg_trap_action,
                                              special_trap_action,
                                              &trap_group_properties,
                                              &last_group_removed,
                                              &update_hpkt,
                                              &update_driver,
                                              &enable_driver_sw_buff,
                                              &hw_trap_group,
                                              &trap_action,
                                              &sw_buff_mon_hw_trap_group);
    }

    /* trap properties will hold trap group amd trap action actual configured in HPKT */
    trap_id_properties.trap_action = trap_action;
    trap_id_properties.hw_trap_group = hw_trap_group;

    /*If we want to remove configuration for regular trap group we will set it to
     * the default action according to the documentation*/
    if ((cmd == SX_ACCESS_CMD_UNSET) && (last_group_removed == TRUE)) {
        rc = __host_ifc_default_actions_set(TRUE,
                                            &(trap_key_p->trap_key_attr.trap_id),
                                            &is_db_updated);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set HPKT register, [trap_id = %u, hw_trap_id = %u], return value: [%s]\n",
                       trap_key_p->trap_key_attr.trap_id, trap_id_properties.hw_trap_id, sx_status_str(rc));
            goto out;
        }
        update_hpkt = FALSE;
    }

    if (update_hpkt == TRUE) {
        if (brg_context.spec_cb_g.host_ifc_handle_hpkt_cb) {
            rc = brg_context.spec_cb_g.host_ifc_handle_hpkt_cb(trap_key_p->trap_key_attr.trap_id,
                                                               trap_id_properties.hw_trap_id,
                                                               &trap_action,
                                                               &hw_trap_group,
                                                               &trap_id_properties.control_type);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set HPKT register, [trap_id = %u, hw_trap_id = %u], return value: [%s]\n",
                           trap_key_p->trap_key_attr.trap_id, trap_id_properties.hw_trap_id, sx_status_str(rc));
                goto out;
            }
        } else {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("Failure: host_ifc_handle_hpkt_cb is NULL.\n");
            goto out;
        }
    }

    /*
     * Driver update required only for Monitor trap group
     * So update the driver only in case when old and new trap group isn't TAC capable
     */
    if ((update_driver == TRUE) && (trap_group_properties.is_tac_capable == FALSE) &&
        (is_tac_capable_group_associated == FALSE)) {
        /* For virtual trap ids may have different value in HW so let's use the actual trap id */
        sxd_err = sxd_dpt_vtrap_virt_to_hw_mapping_get(trap_key_p->trap_key_attr.trap_id, &mapped_trap_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            rc = sxd_status_to_sx_status(sxd_err);
            SX_LOG_ERR("Failed to convert trap ID %u to HW trap ID, sxd_err = [%s]\n",
                       trap_key_p->trap_key_attr.trap_id, SXD_STATUS_MSG(sxd_err));
            goto out;
        }

        if (enable_driver_sw_buff) {
            sw_buff_cmd = SX_ACCESS_CMD_SET;
        } else {
            sw_buff_cmd = SX_ACCESS_CMD_UNSET;
        }

        /* disable SW buff for old monitor group in case new monitor trap group is assigned */
        if ((sw_buff_cmd == SX_ACCESS_CMD_SET) &&
            (disable_driver_old_sw_buff == TRUE)) {
            rc = __host_ifc_trap_id_update_driver(SX_ACCESS_CMD_UNSET,
                                                  mapped_trap_id,
                                                  special_hw_trap_group);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR(
                    "Failed to remove old WJH group from driver, [trap_id = %u, trap_group = %u], return value: [%s]\n",
                    mapped_trap_id,
                    hw_trap_group,
                    sx_status_str(rc));
                goto out;
            }
        }

        rc = __host_ifc_trap_id_update_driver(sw_buff_cmd,
                                              mapped_trap_id,
                                              sw_buff_mon_hw_trap_group);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to update driver, [trap_id = %u, trap_group = %u], return value: [%s]\n",
                       mapped_trap_id, hw_trap_group, sx_status_str(rc));
            goto out;
        }
    }

    /* Mark state of the trap id - is it in use */
    is_in_use = (cmd == SX_ACCESS_CMD_SET) ? TRUE : FALSE;

    /*If we want to unset regular trap id,  we already set
     * the trap_id db as part of calling host_ifc_handle_hpkt_cb*/
    if (!is_db_updated) {
        rc = host_ifc_db_trap_id_properties_set(trap_key_p->trap_key_attr.trap_id,
                                                trap_id_properties,
                                                trap_id_properties.hw_trap_group ==
                                                SX_HW_TRAP_GROUP_DISABLE_E ? FALSE : TRUE,
                                                is_in_use);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in host_ifc_db_trap_id_properties_set, [trap_id = %u], return value: [%s]\n",
                       trap_key_p->trap_key_attr.trap_id,
                       sx_status_str(rc));
            goto out;
        }
    }

    /* update trap_id -> trap_group association */
    rc = host_ifc_db_trap_id_to_group_associate_set(cmd,
                                                    swid,
                                                    trap_key_p->trap_key_attr.trap_id,
                                                    &trap_attr_p->attr.trap_id_attr.trap_group,
                                                    &trap_attr_p->attr.trap_id_attr.trap_action);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR(
            "Failed in host_ifc_db_trap_id_to_group_associate_set, [cmd = %s, trap_id = %u], return value: [%s]\n",
            sx_access_cmd_str(cmd),
            trap_key_p->trap_key_attr.trap_id,
            sx_status_str(rc));
        goto out;
    }

    /* In case of SET cmd update trap group association list with the flow type value.
     *  For UNSET it is not needed since relevant entry was removed from the list. */
    if (cmd == SX_ACCESS_CMD_SET) {
        flow_type = SX_HOST_IFC_TRAP_CFG_FLOW_TYPE_EXT_E;

        if (trap_id_properties.hw_trap_group != SX_HW_TRAP_GROUP_DISABLE_E) {
            rc = host_ifc_db_trap_id_flow_type_set(trap_key_p->trap_key_attr.trap_id,
                                                   trap_attr_p->attr.trap_id_attr.trap_group,
                                                   flow_type);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed in host_ifc_db_trap_id_flow_type_set, [trap_id = %u], return value: [%s]\n",
                           trap_key_p->trap_key_attr.trap_id,
                           sx_status_str(rc));
                goto out;
            }
        }
    }

out:
    if (rc == SX_STATUS_SUCCESS) {
        if (cmd == SX_ACCESS_CMD_SET) {
            bit_vector_set(__bitmap_valid_trap_id, trap_key_p->trap_key_attr.trap_id);
        } else {
            if ((is_regular_group_associated == FALSE) || (is_special_group_associated == FALSE)) {
                /* If is_regular = TRUE and is_monitor = TRUE it means that we have double registration case,
                 * so, no need to clean-up valid trap ids map, since trap id stays in use and map will be cleaned
                 * for the following UNSET command
                 */
                bit_vector_clear(__bitmap_valid_trap_id, trap_key_p->trap_key_attr.trap_id);
            }
        }
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t host_ifc_trap_id_ext_get(sx_access_cmd_t          cmd,
                                     sx_host_ifc_trap_key_t  *trap_key_p,
                                     sx_host_ifc_trap_attr_t *trap_attr_p,
                                     uint32_t                *attr_cnt_p)
{
    sx_status_t      rc = SX_STATUS_SUCCESS;
    sx_trap_group_t  trap_groups[SX_TRAP_ID_MAX + 1];
    sx_trap_action_t trap_actions[SX_TRAP_ID_MAX + 1];
    uint32_t         i = 0;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Used invalid cmd value - %s[%u].\n", sx_status_str(rc), rc);
        goto out;
    }

    if (trap_key_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Specified trap_key_p is NULL, return value [%s].\n",
                   sx_status_str(rc));
        goto out;
    }

    if (trap_key_p->type != HOST_IFC_TRAP_KEY_TRAP_ID_E) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Used invalid Trap ID key type value - %u.\n", trap_key_p->type);
        goto out;
    }

    rc = host_ifc_db_trap_id_to_group_associate_get(trap_key_p->trap_key_attr.trap_id,
                                                    trap_groups,
                                                    trap_actions,
                                                    attr_cnt_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap ID associated groups from DB for "
                   "trap id (0x%x), return value: [%s].\n", trap_key_p->trap_key_attr.trap_id, sx_status_str(rc));
        goto out;
    }

    if (trap_attr_p != NULL) {
        for (i = 0; i < *attr_cnt_p; i++) {
            trap_attr_p[i].attr.trap_id_attr.trap_group = trap_groups[i];
            trap_attr_p[i].attr.trap_id_attr.trap_action = trap_actions[i];
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t host_ifc_trap_group_stat_get(sx_access_cmd_t                cmd,
                                         sx_host_ifc_trap_group_key_t  *group_key_p,
                                         sx_host_ifc_trap_group_stat_t *group_stat_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_swid_t                        swid = 0;
    sx_hw_trap_group_e               hw_trap_group = SX_HW_TRAP_GROUP_MIN_E;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_configured = FALSE;

    SX_MEM_CLR(trap_group_properties);

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    if ((cmd != SX_ACCESS_CMD_READ) &&
        (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Used invalid cmd value - %s[%u].\n", sx_status_str(rc), rc);
        goto out;
    }

    if (group_key_p->type != HOST_IFC_TRAP_GROUP_KEY_GROUP_ID_E) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Used invalid Trap Group key type value - %u.\n", group_key_p->type);
        goto out;
    }

    if (TRAP_GROUP_ID_MAX_CHECK_MAX(group_key_p->group_key_attr.trap_group_id) == FALSE) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Specified Trap Group ID value %u is more than maximum allowed.\n",
                   group_key_p->group_key_attr.trap_group_id);
        goto out;
    }

    rc = host_ifc_db_trap_group_map_get(swid,
                                        group_key_p->group_key_attr.trap_group_id,
                                        &hw_trap_group);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group mapping from the DB, [trap_group = %u], return value: [%s].\n",
                   group_key_p->group_key_attr.trap_group_id, sx_status_str(rc));
        goto out;
    }

    if (hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
        SX_LOG_ERR("Trap_group [%u] is not configured.\n", group_key_p->group_key_attr.trap_group_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = host_ifc_db_trap_group_properties_get(swid, hw_trap_group, &trap_group_properties, &is_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group properties from the DB, [trap_group = %u], return value: [%s].\n",
                   group_key_p->group_key_attr.trap_group_id, sx_status_str(rc));
        goto out;
    }

    /* Validity check - group configured */
    if (is_configured == FALSE) {
        SX_LOG_ERR("Trap_group [%u] is not configured.\n", hw_trap_group);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (trap_group_properties.is_monitor == FALSE) {
        SX_LOG_ERR("Trap_group [%u] is not monitor trap group.\n", hw_trap_group);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* send request to kernel to get total number of packets per RDQ # (trap group_id)  */
    SX_LOG_DBG("\n%s: group_key_p->group_key_attr.trap_group_id: %u hw_trap_group: %u\n",
               __func__,
               group_key_p->group_key_attr.trap_group_id, hw_trap_group);

    rc = __host_ifc_trap_group_stat_get_from_driver(cmd,
                                                    hw_trap_group,
                                                    ev_thread_params_s.sxd_h,
                                                    group_stat_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group statistics from the driver, [hw_trap_group = %u], return value: [%s].\n",
                   hw_trap_group, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __host_ifc_validate_add_parameters(sx_trap_id_user_defined_attributes_t  *user_defined_attributes_p,
                                                      sx_trap_id_user_defined_packet_type_t *packet_type,
                                                      sx_host_ifc_port_range_t              *port_range)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    boolean_t   packet_type_found = FALSE;
    boolean_t   port_range_found = FALSE;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < user_defined_attributes_p->key_list_cnt; i++) {
        switch (user_defined_attributes_p->key_list[i].type) {
        case SX_TRAP_ID_USER_DEFINED_KEY_PACKET_TYPE_E:
            if (packet_type_found) {
                SX_LOG_ERR("Packet type already provided in the key list.\n");
                status = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            *packet_type = user_defined_attributes_p->key_list[i].key.packet_type;
            if ((*packet_type != SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_E) &&
                (*packet_type != SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_TCP_E) &&
                (*packet_type != SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_TCP_E)) {
                SX_LOG_ERR("Packet type [%d] is not supported.\n",
                           *packet_type);
                status = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            packet_type_found = TRUE;
            break;

        case SX_TRAP_ID_USER_DEFINED_KEY_PORT_RANGE_E:
            if (port_range_found) {
                SX_LOG_ERR("Port range already provided in the key list.\n");
                status = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            *port_range = user_defined_attributes_p->key_list[i].key.port_range;
            if (port_range->port_range_max < port_range->port_range_min) {
                SX_LOG_ERR("port range max [%d] is smaller than port range min [%d].\n",
                           port_range->port_range_max, port_range->port_range_min);
                status = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            port_range_found = TRUE;
            break;

        default:
            SX_LOG_ERR("User defined key type is unsupported [%d].\n",
                       user_defined_attributes_p->key_list[i].type);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    if (port_range_found == FALSE) {
        SX_LOG_ERR("Port range is not defined.\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (packet_type_found == FALSE) {
        *packet_type = SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_TCP_E;
    }

    if ((*packet_type == SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_E) ||
        (*packet_type == SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_TCP_E)) {
        if (port_range->port_range_direction != SX_ACL_PORT_DIRECTION_DESTINATION) {
            SX_LOG_ERR("direction [%d] is not supported for UDP packet type.\n",
                       port_range->port_range_direction);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __host_ifc_user_defined_l4_port_trap_id_set(const sx_access_cmd_t                 cmd,
                                                               const sx_swid_t                       swid,
                                                               const sx_trap_id_t                    trap_id,
                                                               sx_trap_id_user_defined_attributes_t *user_defined_attributes_p)
{
    sx_status_t                           status = SX_STATUS_SUCCESS;
    uint32_t                              port_cnt = 0;
    sx_trap_id_user_defined_packet_type_t packet_type = 0;
    sx_host_ifc_port_range_t              port_range;
    uint8_t                               tcp_dport = 0;
    uint8_t                               tcp_sport = 0;
    uint8_t                               udp_dport = 0;

    SX_MEM_CLR(port_range);

    SX_LOG_ENTER();

    if (FALSE == SX_SWID_CHECK_RANGE(swid)) {
        SX_LOG_ERR("SWID (%u) exceeds range (%d...%d).\n", swid, SX_SWID_ID_MIN, SX_SWID_ID_MAX);
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Check SWID exist in DB */
    status = port_swid_get(SX_ACCESS_CMD_GET, swid, NULL, &port_cnt);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SWID not found [%u].\n", swid);
        goto out;
    }

    if (SX_TRAP_ID_USER_L4_PORT_CHECK_RANGE(trap_id) != TRUE) {
        SX_LOG_ERR("user trap_id of port type must be in the range of [%d-%d].\n",
                   SX_TRAP_ID_USER_BASE, SX_TRAP_ID_USER_MAX);
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        status = __host_ifc_validate_add_parameters(user_defined_attributes_p,
                                                    &packet_type, &port_range);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__host_ifc_validate_add_parameters Failed. %s \n", sx_status_str(status));
            goto out;
        }

        status = host_ifc_db_user_trap_id_get(trap_id, NULL);
        if (status != SX_STATUS_ENTRY_NOT_FOUND) {
            status = SX_STATUS_ENTRY_ALREADY_EXISTS;
            SX_LOG_ERR("host_ifc_db_user_trap_id_get Failed, [trap_id = %u], error: %s \n", trap_id,
                       sx_status_str(status));
            goto out;
        }
        status = SX_STATUS_SUCCESS;

        switch (packet_type) {
        case SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_E:
            udp_dport = 1;
            break;

        case SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_TCP_E:
            switch (port_range.port_range_direction) {
            case SX_ACL_PORT_DIRECTION_SOURCE:
                tcp_sport = 1;
                break;

            case SX_ACL_PORT_DIRECTION_DESTINATION:
                tcp_dport = 1;
                break;

            case SX_ACL_PORT_DIRECTION_BOTH:
                tcp_dport = 1;
                tcp_sport = 1;
                break;

            default:
                SX_LOG_ERR("ACL : Invalid port direction [%d]\n", port_range.port_range_direction);
                return SX_STATUS_PARAM_EXCEEDS_RANGE;
            }
            break;

        case SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_TCP_E:
            udp_dport = 1;
            switch (port_range.port_range_direction) {
            case SX_ACL_PORT_DIRECTION_SOURCE:
                tcp_sport = 1;
                break;

            case SX_ACL_PORT_DIRECTION_DESTINATION:
                tcp_dport = 1;
                break;

            case SX_ACL_PORT_DIRECTION_BOTH:
                tcp_dport = 1;
                tcp_sport = 1;
                break;

            default:
                SX_LOG_ERR("Invalid port direction [%d]\n", port_range.port_range_direction);
                return SX_STATUS_PARAM_EXCEEDS_RANGE;
            }
            break;

        default:
            SX_LOG_ERR("Invalid packet_type [%d].\n", packet_type);
            return SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        status = host_ifc_db_user_trap_id_get(trap_id, NULL);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("host_ifc_db_user_trap_id_get Failed, [trap_id = %u], error: %s \n", trap_id,
                       sx_status_str(status));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    status = __handle_hctr(trap_id,
                           tcp_dport,
                           tcp_sport,
                           udp_dport,
                           port_range.port_range_min,
                           port_range.port_range_max);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__handle_hctr for trap_id %d failed. %s \n", trap_id, sx_status_str(status));
        goto out;
    }

    status = host_ifc_db_user_trap_id_set(cmd, trap_id, user_defined_attributes_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("host_ifc_db_user_trap_id_set Failed, [trap_id = %u], error: %s \n", trap_id,
                   sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __host_ifc_user_defined_trap_id_attr_set(const sx_access_cmd_t                 cmd,
                                                            const sx_swid_t                       swid,
                                                            const sx_trap_id_t                    trap_id,
                                                            sx_trap_id_user_defined_attributes_t *user_defined_attributes_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    uint32_t    port_cnt = 0;

    SX_LOG_ENTER();

    if (FALSE == SX_SWID_CHECK_RANGE(swid)) {
        SX_LOG_ERR("SWID (%u) exceeds range (%d...%d).\n", swid, SX_SWID_ID_MIN, SX_SWID_ID_MAX);
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Check SWID exist in DB */
    status = port_swid_get(SX_ACCESS_CMD_GET, swid, NULL, &port_cnt);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SWID not found [%u].\n", swid);
        goto out;
    }

    if (SX_TRAP_ID_USER_ATTR_CHECK_RANGE(trap_id) != TRUE) {
        SX_LOG_ERR("Invalid user trap_id %d.\n", trap_id);
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:

        status = host_ifc_db_user_trap_id_get(trap_id, NULL);
        if (status != SX_STATUS_ENTRY_NOT_FOUND) {
            status = SX_STATUS_ENTRY_ALREADY_EXISTS;
            SX_LOG_ERR("host_ifc_db_user_trap_id_get Failed, [trap_id = %u], error: %s \n", trap_id,
                       sx_status_str(status));
            goto out;
        }
        status = SX_STATUS_SUCCESS;
        break;

    case SX_ACCESS_CMD_DELETE:
        status = host_ifc_db_user_trap_id_get(trap_id, NULL);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("host_ifc_db_user_trap_id_get Failed, [trap_id = %u], error: %s \n", trap_id,
                       sx_status_str(status));
            goto out;
        }

        if ((trap_id == SX_TRAP_ID_USER_ICMPV6_CONF_TYPE0) ||
            (trap_id == SX_TRAP_ID_USER_ICMPV6_CONF_TYPE1) ||
            (trap_id == SX_TRAP_ID_USER_OVERLAY_ICMPV6_CONF_TYPE)) {
            user_defined_attributes_p->key_list_cnt = 1;
            user_defined_attributes_p->key_list[0].type = SX_TRAP_ID_USER_DEFINED_KEY_IPV6_ICMP_TYPE_E;
            user_defined_attributes_p->key_list[0].key.icmpv6_attr.icmpv6_type = 0;
        } else if (trap_id == SX_TRAP_ID_USER_NVE_DECAP_ETH) {
            user_defined_attributes_p->key_list_cnt = 2;
            user_defined_attributes_p->key_list[0].type = SX_TRAP_ID_USER_DEFINED_KEY_NVE_DECAP_ETH_TYPE_E;
            user_defined_attributes_p->key_list[0].key.nve_decap_eth_attr.eth_type = 0;
            user_defined_attributes_p->key_list[1].type = SX_TRAP_ID_USER_DEFINED_KEY_NVE_DECAP_ETH_TYPE_E;
            user_defined_attributes_p->key_list[1].key.nve_decap_eth_attr.eth_type = 0;
        } else if ((trap_id == SX_TRAP_ID_USER_ETH_CONF_TYPE0) ||
                   (trap_id == SX_TRAP_ID_USER_ETH_CONF_TYPE1)) {
            user_defined_attributes_p->key_list_cnt = 1;
            user_defined_attributes_p->key_list[0].type = SX_TRAP_ID_USER_DEFINED_KEY_ETH_TYPE_E;
            user_defined_attributes_p->key_list[0].key.nve_decap_eth_attr.eth_type = 0;
        }

        break;

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    status = __handle_htac(trap_id, user_defined_attributes_p->key_list,
                           &user_defined_attributes_p->key_list_cnt);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__handle_hctr for trap_id %d failed. %s \n", trap_id, sx_status_str(status));
        goto out;
    }

    status = host_ifc_db_user_trap_id_set(cmd, trap_id, user_defined_attributes_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("host_ifc_db_user_trap_id_set Failed, [trap_id = %u], error: %s \n", trap_id,
                   sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t host_ifc_user_attr_ext_set_spectrum2(const sx_access_cmd_t                 cmd,
                                                 const sx_swid_t                       swid,
                                                 const sx_trap_id_t                    trap_id,
                                                 sx_trap_id_user_defined_attributes_t *user_defined_attributes_p)
{
    sx_status_t                          status = SX_STATUS_SUCCESS;
    uint32_t                             port_cnt = 0;
    sx_trap_id_user_defined_attributes_t user_defined_attributes_db_entry;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(status = utils_check_pointer(user_defined_attributes_p, "user_defined_attributes_p"))) {
        goto out;
    }

    if (FALSE == SX_SWID_CHECK_RANGE(swid)) {
        SX_LOG_ERR("SWID (%u) exceeds range (%d...%d).\n", swid, SX_SWID_ID_MIN, SX_SWID_ID_MAX);
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Check SWID exist in DB */
    status = port_swid_get(SX_ACCESS_CMD_GET, swid, NULL, &port_cnt);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SWID not found [%u].\n", swid);
        goto out;
    }

    if (SX_TRAP_ID_USER_ATTR_EXT_CHECK_RANGE(trap_id) != TRUE) {
        SX_LOG_ERR("Invalid user trap_id %d.\n", trap_id);
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:

        status = host_ifc_db_user_trap_id_get(trap_id, NULL);
        if (status != SX_STATUS_ENTRY_NOT_FOUND) {
            status = SX_STATUS_ENTRY_ALREADY_EXISTS;
            SX_LOG_ERR("host_ifc_db_user_trap_id_get Failed, [trap_id = %u], error: %s \n", trap_id,
                       sx_status_str(status));
            goto out;
        }
        status = SX_STATUS_SUCCESS;

        status = __handle_hcot(cmd, swid, trap_id, user_defined_attributes_p->key_list,
                               &user_defined_attributes_p->key_list_cnt);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__handle_hcot for trap_id %d failed. %s \n", trap_id, sx_status_str(status));
            goto out;
        }

        status = host_ifc_db_user_trap_id_set(cmd, trap_id, user_defined_attributes_p);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("host_ifc_db_user_trap_id_set Failed, [trap_id = %u], error: %s \n", trap_id,
                       sx_status_str(status));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        SX_MEM_CLR(user_defined_attributes_db_entry);
        status = host_ifc_db_user_trap_id_get(trap_id, &user_defined_attributes_db_entry);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("host_ifc_db_user_trap_id_get Failed, [trap_id = %u], error: %s \n", trap_id,
                       sx_status_str(status));
            goto out;
        }

        status = __handle_hcot(cmd, swid, trap_id, user_defined_attributes_db_entry.key_list,
                               &user_defined_attributes_db_entry.key_list_cnt);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__handle_hctr for trap_id %d failed. %s \n", trap_id, sx_status_str(status));
            goto out;
        }

        status = host_ifc_db_user_trap_id_set(cmd, trap_id, user_defined_attributes_p);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("host_ifc_db_user_trap_id_set Failed, [trap_id = %u], error: %s \n", trap_id,
                       sx_status_str(status));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __host_ifc_user_defined_ext_trap_id_attr_set(const sx_access_cmd_t                 cmd,
                                                                const sx_swid_t                       swid,
                                                                const sx_trap_id_t                    trap_id,
                                                                sx_trap_id_user_defined_attributes_t *user_defined_attributes_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.host_ifc_user_defined_ext_trap_id_attr_set_cb) {
        status = brg_context.spec_cb_g.host_ifc_user_defined_ext_trap_id_attr_set_cb(cmd,
                                                                                     swid,
                                                                                     trap_id,
                                                                                     user_defined_attributes_p);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to set extended user defined traps [%s]\n",
                       sx_status_str(status));
            goto out;
        }
    } else {
        SX_LOG_ERR("Unsupported extended user trap id - %s for attr set.\n", sx_host_ifc_trap_id_str(trap_id));
        status = SX_STATUS_CMD_UNSUPPORTED;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t host_ifc_user_defined_trap_id_set(const sx_access_cmd_t                 cmd,
                                              const sx_swid_t                       swid,
                                              const sx_trap_id_t                    trap_id,
                                              sx_trap_id_user_defined_attributes_t *user_defined_attributes_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    if (SX_TRAP_ID_USER_ATTR_CHECK_RANGE(trap_id) == TRUE) {
        status = __host_ifc_user_defined_trap_id_attr_set(cmd, swid, trap_id,
                                                          user_defined_attributes_p);
    } else if (SX_TRAP_ID_USER_L4_PORT_CHECK_RANGE(trap_id) == TRUE) {
        status = __host_ifc_user_defined_l4_port_trap_id_set(cmd, swid, trap_id,
                                                             user_defined_attributes_p);
    } else if (SX_TRAP_ID_USER_ATTR_EXT_CHECK_RANGE(trap_id) == TRUE) {
        status = __host_ifc_user_defined_ext_trap_id_attr_set(cmd, swid, trap_id,
                                                              user_defined_attributes_p);
    } else {
        SX_LOG_ERR("Unsupported trap id %d for attr set.\n", trap_id);
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return status;
}


sx_status_t sx_host_ifc_policer_bind_set(const sx_access_cmd_t    cmd,
                                         const sx_swid_id_t       swid,
                                         const sx_trap_priority_t trap_group,
                                         const sx_policer_id_t    policer_id)
{
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    sx_policer_type_e                policer_type;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    uint32_t                         port_cnt = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_group_properties);

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    if (FALSE == SX_SWID_CHECK_RANGE(swid)) {
        SX_LOG_ERR("SWID (%u) exceeds range (%d...%d).\n", swid, SX_SWID_ID_MIN, SX_SWID_ID_MAX);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        return __SX_LOG_EXIT(rc);
    }

    /* Check SWID exist in DB */
    rc = port_swid_get(SX_ACCESS_CMD_GET, swid, NULL, &port_cnt);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SWID not found [%u].\n", swid);
        return rc;
    }

    /* Get trap group DB parameters */
    rc = host_ifc_db_trap_group_properties_get(swid,
                                               trap_group,
                                               &trap_group_properties,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to fetch trap group properties from DB, [trap_group = %u], return value: [%s].\n",
                   trap_group, sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    /* Validity check - group configured */
    if (is_trap_group_configured == FALSE) {
        SX_LOG_ERR("Trap group (%u) is not configured on swid (%u).\n",
                   trap_group, swid);
        return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    /* Validity check - policer existed & bound */

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        /* On Switch IB platforms app is controlling policer id,
         *  so skip sdk validations */
        if (rm_resource_global.policer_host_ifc_pool_size == 0) {
            if (trap_group_properties.policer_id_enabled == TRUE) {
                SX_LOG_ERR("Trap group already bound to policer id %" PRIu64 ".\n",
                           trap_group_properties.policer_id);
                return __SX_LOG_EXIT(SX_STATUS_ENTRY_ALREADY_BOUND);
            }

            if (SX_POLICER_TYPE_GET(policer_id) != SX_POLICER_TYPE_GLOBAL_E) {
                SX_LOG_ERR("Trap group can only be bound to slow global policer\n");
                return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
            }

            rc = policer_db_type_get(policer_id, &policer_type);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get policer type, [policer_id = %" PRIu64 "] return value: [%s].\n",
                           policer_id,
                           sx_status_str(rc));
                return __SX_LOG_EXIT(rc);
            }

            if (policer_type != SX_POLICER_TYPE_GLOBAL_SLOW_E) {
                SX_LOG_ERR("Trap group can only be bound to slow global policer.\n");
                return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
            }
        }

        trap_group_properties.policer_id = policer_id;
        trap_group_properties.policer_id_enabled = TRUE;

        break;

    case SX_ACCESS_CMD_UNBIND:
        /* On Switch IB platforms app is controlling policer id,
         *  so skip sdk validations */
        if (rm_resource_global.policer_host_ifc_pool_size == 0) {
            if ((SX_POLICER_TYPE_GET(policer_id) != SX_POLICER_TYPE_GLOBAL_E) ||
                SX_CHECK_FAIL(policer_db_type_get(policer_id, &policer_type))) {
                SX_LOG_ERR("Invalid policer ID %" PRIu64 ".\n", policer_id);
                return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
            }
        }

        if (trap_group_properties.policer_id_enabled == FALSE) {
            SX_LOG_DBG("Trap group already unbound.\n");
            return __SX_LOG_EXIT(SX_STATUS_SUCCESS);
        }

        if (trap_group_properties.policer_id != policer_id) {
            SX_LOG_ERR("Trap group bound to policer id %" PRIu64 ", but given policer was %" PRIu64 ".\n",
                       trap_group_properties.policer_id, policer_id);
            return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
        }

        trap_group_properties.policer_id = policer_id;
        trap_group_properties.policer_id_enabled = FALSE;

        break;

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        return __SX_LOG_EXIT(rc);
    }

    rc = host_ifc_handle_htgt(0, swid, trap_group,
                              &(trap_group_properties.type),
                              &(trap_group_properties.path),
                              &(trap_group_properties.policer_id_enabled),
                              &(trap_group_properties.policer_id),
                              &(trap_group_properties.priority),
                              &(trap_group_properties.mirror_action),
                              &(trap_group_properties.mirror_agent),
                              &(trap_group_properties.mirror_probability_rate));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set HTGT register, [trap_group = %u], return value: [%s].\n", trap_group,
                   sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    /* add trap group properties to DB if write to register succeeded */
    rc = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET, swid, trap_group, &trap_group_properties);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in host_ifc_db_trap_group_properties_set, [trap_group = %u], return value: [%s].\n",
                   trap_group,
                   sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    /* On Switch IB platforms app is controlling policer id,
     *  so skip sdk validations */
    if (rm_resource_global.policer_host_ifc_pool_size == 0) {
        rc = policer_db_bind_set(cmd, policer_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set bind number in policer DB, [policer_id = %" PRIu64 "], error: %s.\n",
                       policer_id,
                       sx_status_str(rc));
            return __SX_LOG_EXIT(rc);
        }
    }

    return __SX_LOG_EXIT(rc);
}

sx_status_t sx_host_ifc_policer_bind_get(const sx_swid_id_t       swid,
                                         const sx_trap_priority_t trap_group,
                                         sx_policer_id_t         *policer_id_p)
{
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    sx_status_t                      rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(policer_id_p, "policer_id_p"))) {
        SX_LOG_ERR("HOST_IFC: policer_id_p is NULL.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (TRAP_GROUP_ID_MAX_CHECK_MAX(trap_group) == FALSE) {
        SX_LOG_ERR("HOST_IFC: trap group : %d exceeds range %d.\n",
                   trap_group, TRAP_GROUP_ID_MAX);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (FALSE == SX_SWID_CHECK_RANGE(swid)) {
        SX_LOG_ERR("HOST_IFC: SWID (%u) exceeds range (%d...%d).\n", swid, SX_SWID_ID_MIN, SX_SWID_ID_MAX);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Get trap priority DB parameters */
    rc = host_ifc_db_trap_group_properties_get(swid,
                                               trap_group,
                                               &trap_group_properties,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("HOST_IFC: Failed to fetch trap group properties from DB, [trap_group = %u], return value: [%s].\n",
                   trap_group, sx_status_str(rc));
        goto out;
    }

    /* Validity check - group configured */
    if (is_trap_group_configured == FALSE) {
        SX_LOG_ERR("HOST_IFC: trap_group [%u] is not configured.\n", trap_group);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (FALSE == trap_group_properties.policer_id_enabled) {
        SX_LOG_ERR("HOST_IFC: policer_id is not enabled for trap_group [%u].\n", trap_group);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *policer_id_p = trap_group_properties.policer_id;

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t sdk_host_ifc_policer_bind_get(const sx_swid_id_t       swid,
                                          const sx_trap_priority_t trap_group,
                                          sx_policer_id_t         *policer_id_p)
{
    sx_hw_trap_group_e               hw_trap_group = 0;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    sx_status_t                      rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(policer_id_p, "policer_id_p"))) {
        SX_LOG_ERR("HOST_IFC: policer_id_p is NULL.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (FALSE == SX_SWID_CHECK_RANGE(swid)) {
        SX_LOG_ERR("HOST_IFC: SWID (%u) exceeds range (%d...%d).\n", swid, SX_SWID_ID_MIN, SX_SWID_ID_MAX);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    rc = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group %u HW trap group for swid %u, return value: [%s]\n",
                   trap_group, swid, sx_status_str(rc));
        goto out;
    }

    /* Get trap group DB parameters */
    rc = host_ifc_db_trap_group_properties_get(swid,
                                               hw_trap_group,
                                               &trap_group_properties,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to fetch trap group properties from DB, [trap_group = %u], return value: [%s].\n",
                   hw_trap_group, sx_status_str(rc));
        goto out;
    }

    /* Validity check - group configured */
    if (is_trap_group_configured == FALSE) {
        SX_LOG_ERR("HOST_IFC: trap_group [%u] is not configured.\n", trap_group);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (FALSE == trap_group_properties.policer_id_enabled) {
        SX_LOG_INF("HOST_IFC: policer_id is not enabled for trap_group [%u].\n", trap_group);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *policer_id_p = trap_group_properties.policer_id;

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t sdk_host_ifc_policer_bind_set(const sx_access_cmd_t    cmd,
                                          const sx_swid_id_t       swid,
                                          const sx_trap_priority_t trap_group,
                                          const sx_policer_id_t    policer_id)
{
    host_ifc_trap_group_properties_t trap_group_properties, old_trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    sx_policer_type_e                policer_type;
    sx_status_t                      rc = SX_STATUS_SUCCESS, rb_status = SX_STATUS_SUCCESS;
    uint32_t                         port_cnt = 0;
    sx_policer_db_attrib_t           policer_attr;
    sx_hw_trap_group_e               hw_trap_group = 0;
    sx_policer_id_t                  int_policer_id = policer_id;


    SX_LOG_ENTER();

    SX_MEM_CLR(trap_group_properties);
    SX_MEM_CLR(old_trap_group_properties);
    SX_MEM_CLR(policer_attr);

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (FALSE == SX_SWID_CHECK_RANGE(swid)) {
        SX_LOG_ERR("SWID (%u) exceeds range (%d...%d).\n", swid, SX_SWID_ID_MIN, SX_SWID_ID_MAX);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Check SWID exist in DB */
    rc = port_swid_get(SX_ACCESS_CMD_GET, swid, NULL, &port_cnt);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SWID not found [%u].\n", swid);
        goto out;
    }

    rc = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group %u HW trap group for swid %u, return value: [%s]\n",
                   trap_group, swid, sx_status_str(rc));
        goto out;
    }

    /* Get trap group DB parameters */
    rc = host_ifc_db_trap_group_properties_get(swid,
                                               hw_trap_group,
                                               &trap_group_properties,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to fetch trap group properties from DB, [trap_group = %u], return value: [%s].\n",
                   hw_trap_group, sx_status_str(rc));
        goto out;
    }
    SX_MEM_CPY(old_trap_group_properties, trap_group_properties);

    /* Validity check - group configured */
    if (is_trap_group_configured == FALSE) {
        SX_LOG_ERR("Trap group (%u) is not configured on swid (%u).\n",
                   trap_group, swid);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Validity check - policer existed & bound */

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        if (trap_group_properties.policer_id_enabled == TRUE) {
            SX_LOG_ERR("Trap group already bound to policer id %" PRIu64 ".\n",
                       trap_group_properties.policer_id);
            rc = SX_STATUS_ENTRY_ALREADY_BOUND;
            goto out;
        }

        if (SX_POLICER_TYPE_GET(int_policer_id) != SX_POLICER_TYPE_GLOBAL_E) {
            SX_LOG_ERR("Trap group can only be bound to a global policer\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        rc = policer_db_type_get(int_policer_id, &policer_type);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get policer type, [policer_id = %" PRIu64 "], return value: [%s].\n",
                       int_policer_id,
                       sx_status_str(rc));
            goto out;
        }

        if (policer_type != SX_POLICER_TYPE_GLOBAL_E) {
            SX_LOG_ERR("Trap group can only be bound to a global policer.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        rc = policer_db_attrib_get(int_policer_id, &policer_attr);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in receiving current policer attributes, [policer_id = %" PRIu64 "], error: %s\n",
                       int_policer_id,
                       sx_status_str(rc));
            goto out;
        }

        if (policer_attr.is_host_ifc_policer == FALSE) {
            SX_LOG_ERR("the policer is not an host_ifc policer.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        rc = policer_manager_ref_add(int_policer_id,
                                     POLICER_MANAGER_TYPE_HOST_IFC_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in policer_manager_ref_add, [policer_id = %" PRIu64 "], error: %s\n",
                       int_policer_id,
                       sx_status_str(rc));
            goto out;
        }
        trap_group_properties.policer_id = int_policer_id;
        trap_group_properties.policer_id_enabled = TRUE;
        break;

    case SX_ACCESS_CMD_UNBIND:
        if ((SX_POLICER_TYPE_GET(int_policer_id) != SX_POLICER_TYPE_GLOBAL_E) ||
            SX_CHECK_FAIL(policer_db_type_get(int_policer_id, &policer_type))) {
            SX_LOG_ERR("Invalid policer ID %" PRIu64 ".\n", int_policer_id);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (trap_group_properties.policer_id_enabled == FALSE) {
            SX_LOG_DBG("Trap group already unbound.\n");
            rc = SX_STATUS_SUCCESS;
            goto out;
        }

        if (trap_group_properties.policer_id != int_policer_id) {
            SX_LOG_ERR("Trap group bound to policer id %" PRIu64 ", but given policer was %" PRIu64 ".\n",
                       trap_group_properties.policer_id, int_policer_id);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        trap_group_properties.policer_id = int_policer_id;
        trap_group_properties.policer_id_enabled = FALSE;

        rc = policer_manager_ref_delete(int_policer_id,
                                        POLICER_MANAGER_TYPE_HOST_IFC_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in policer_manager_ref_add, [policer_id = %" PRIu64 "], error: %s\n",
                       int_policer_id,
                       sx_status_str(rc));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }


    rc = host_ifc_handle_htgt(0, swid, hw_trap_group,
                              &(trap_group_properties.type),
                              &(trap_group_properties.path),
                              &(trap_group_properties.policer_id_enabled),
                              &int_policer_id,
                              &(trap_group_properties.priority),
                              &(trap_group_properties.mirror_action),
                              &(trap_group_properties.mirror_agent),
                              &(trap_group_properties.mirror_probability_rate));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set HTGT register, [trap_group = %u], return value: [%s].\n",
                   hw_trap_group,
                   sx_status_str(rc));
        goto rollback1;
    }

    /* add trap group properties to DB if write to register succeeded */
    rc = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET, swid, hw_trap_group, &trap_group_properties);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in host_ifc_db_trap_group_properties_set, [trap_group_id = %u], return value: [%s].\n",
                   hw_trap_group,
                   sx_status_str(rc));
        goto rollback2;
    }

    rc = policer_db_bind_set(cmd, int_policer_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set bind number in policer DB, [policer_id = %" PRIu64 "], error: %s.\n",
                   int_policer_id,
                   sx_status_str(rc));
        goto rollback3;
    }
    goto out;

rollback3:
    rb_status = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET,
                                                      swid,
                                                      hw_trap_group,
                                                      &old_trap_group_properties);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed in host_ifc_db_trap_group_properties_set, [trap_group_id = %u], return value: [%s].\n",
                   hw_trap_group,
                   sx_status_str(rb_status));
        goto out;
    }

rollback2:
    rb_status = host_ifc_handle_htgt(0,
                                     swid,
                                     hw_trap_group,
                                     &(old_trap_group_properties.type),
                                     &(old_trap_group_properties.path),
                                     &(old_trap_group_properties.policer_id_enabled),
                                     &(old_trap_group_properties.policer_id),
                                     &(old_trap_group_properties.priority),
                                     &(old_trap_group_properties.mirror_action),
                                     &(old_trap_group_properties.mirror_agent),
                                     &(old_trap_group_properties.mirror_probability_rate));
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to set HTGT register, [trap_group = %u], return value: [%s].\n",
                   hw_trap_group,
                   sx_status_str(rb_status));
        goto out;
    }

rollback1:
    if (cmd == SX_ACCESS_CMD_BIND) {
        rb_status = policer_manager_ref_delete(int_policer_id,
                                               POLICER_MANAGER_TYPE_HOST_IFC_E);
        if (SX_CHECK_FAIL(rb_status)) {
            SX_LOG_ERR("Error in policer_manager_ref_add, [policer_id = %" PRIu64 "], error (%s)\n",
                       int_policer_id,
                       sx_status_str(rb_status));
        }
        goto out;
    } else if (cmd == SX_ACCESS_CMD_UNBIND) {
        rb_status = policer_manager_ref_add(int_policer_id,
                                            POLICER_MANAGER_TYPE_HOST_IFC_E);
        if (SX_CHECK_FAIL(rb_status)) {
            SX_LOG_ERR("Error in policer_manager_ref_add, [policer_id = %" PRIu64 "], error (%s)\n",
                       int_policer_id,
                       sx_status_str(rb_status));
        }
        goto out;
    }


out:

    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_trap_filter_set(const sx_access_cmd_t cmd,
                                     sx_swid_t             swid,
                                     sx_trap_id_t          trap_id,
                                     sx_port_log_id_t      log_port_list[],
                                     length_t             *log_port_num)
{
    sx_status_t                err = SX_STATUS_SUCCESS, tot_err = SX_STATUS_SUCCESS;
    struct ku_trap_filter_data filter_data;
    sxd_ctrl_pack_t            ctrl_pack;
    int                        sxd_err;
    uint32_t                   i = 0, failed_idx = 0;
    uint32_t                   total_num_of_ports = *log_port_num;
    uint32_t                   port_num = 0;
    sx_port_info_t             port_info;
    sx_swid_id_t               port_swid_id;
    sx_port_log_id_t          *failed_log_port_list = NULL;
    sx_status_t                rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    /* Validate Port */
    for (i = 0; i < total_num_of_ports; i++) {
        VALIDATE_PORT(host_ifc_trap_filter_set, log_port_list[i]);
    }

    /* Check if swid was added into DB */
    err = port_swid_get(SX_ACCESS_CMD_GET, swid, NULL, &port_num);
    if (SX_CHECK_FAIL(err)) {
        return M_UTILS_SX_LOG_EXIT(err);
    }

    memset(&ctrl_pack, 0, sizeof(ctrl_pack));
    ctrl_pack.cmd_body = (void*)(&filter_data);
    filter_data.trap_id = trap_id;
    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        ctrl_pack.ctrl_cmd = CTRL_CMD_TRAP_FILTER_ADD;
        break;

    case SX_ACCESS_CMD_DELETE:
        ctrl_pack.ctrl_cmd = CTRL_CMD_TRAP_FILTER_REMOVE;
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        ctrl_pack.ctrl_cmd = CTRL_CMD_TRAP_FILTER_REMOVE_ALL;
        sxd_err = sxd_ioctl(ev_thread_params_s.sxd_h, &ctrl_pack);
        if (sxd_err != 0) {
            SX_LOG_ERR("sxd_ioctl (CTRL_CMD_TRAP_FILTER_REMOVE_ALL) failed with "
                       "error %s.\n", strerror(errno));
            err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        } else {
            err = host_ifc_db_trap_filter_set(SX_ACCESS_CMD_DELETE_ALL, swid, trap_id, SX_INVALID_PORT);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("host_ifc_db_trap_filter_set failed, [trap_id = %u], error (%s)\n", trap_id,
                           sx_status_str(err));
            }
        }
        /* For remove all we're done */
        goto out;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&failed_log_port_list, total_num_of_ports, sizeof(sx_port_log_id_t),
                        UTILS_MEM_TYPE_ID_HOST_IFC_E, "Failed to allocate memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }


    for (i = 0; i < total_num_of_ports; i++) {
        /* Check that the port exists in the ports DB */
        if (SX_CHECK_FAIL(err = port_db_info_get(log_port_list[i], &port_info))) {
            SX_LOG_ERR("Can't Get Port 0x%x Info (%s).\n", log_port_list[i], sx_status_str(err));
            failed_log_port_list[failed_idx++] = log_port_list[i];
            tot_err = err;
            continue;
        }

        /* Check that the port list entry's is part of the given swid */
        if (SX_CHECK_FAIL(rc = port_swid_alloc_get(SX_ACCESS_CMD_GET, log_port_list[i], &port_swid_id))) {
            SX_LOG_ERR("Can't Retrieve SwID of Port 0x%08X (%s). (buff of port get)\n",
                       log_port_list[i],
                       sx_status_str(rc));
            tot_err = SX_STATUS_PARAM_ERROR;
            failed_log_port_list[failed_idx++] = log_port_list[i];
            continue;
        }

        if (port_swid_id != swid) {
            SX_LOG_ERR("The SwID of Port 0x%08X is not the same as the given swid, "
                       "got (%d) expected (%d)\n", log_port_list[i], port_swid_id, swid);
            tot_err = SX_STATUS_PARAM_ERROR;
            failed_log_port_list[failed_idx++] = log_port_list[i];
            continue;
        }

        if (SX_PORT_TYPE_ID_GET(log_port_list[i]) != SX_PORT_TYPE_LAG) {
            /* The port can't be part of a LAG */
            if (port_info.part_of_lag_fl) {
                SX_LOG_ERR("Can't configure Port 0x%x since it's part of a LAG\n",
                           log_port_list[i]);
                tot_err = SX_STATUS_PARAM_ERROR;
                failed_log_port_list[failed_idx++] = log_port_list[i];
                continue;
            }

            filter_data.is_lag = 0;
            err = port_ucroute_base_map_get(SX_ACCESS_CMD_GET,
                                            log_port_list[i], &filter_data.sysport);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed translating logical port 0x%x to "
                           "system port\n", log_port_list[i]);
                failed_log_port_list[failed_idx++] = log_port_list[i];
                tot_err = err;
                continue;
            }
        } else {
            filter_data.is_lag = 1;
            filter_data.lag_id = SX_PORT_LAG_ID_GET(log_port_list[i]);
        }

        sxd_err = sxd_ioctl(ev_thread_params_s.sxd_h, &ctrl_pack);
        if (sxd_err != 0) {
            if (EEXIST == errno) {
                SX_LOG_ERR("Same trap filter already exists\n");
                tot_err = SX_STATUS_ENTRY_ALREADY_EXISTS;
            } else {
                SX_LOG_ERR("sxd_ioctl (%s) failed with error %s.\n",
                           (cmd == SX_ACCESS_CMD_ADD) ? "CTRL_CMD_TRAP_FILTER_ADD" :
                           "CTRL_CMD_TRAP_FILTER_REMOVE",
                           strerror(errno));
                tot_err = SX_STATUS_SXD_RETURNED_NON_ZERO;
            }
            failed_log_port_list[failed_idx++] = log_port_list[i];
            continue;
        } else {
            err = host_ifc_db_trap_filter_set(cmd, swid, trap_id, log_port_list[i]);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("host_ifc_db_trap_filter_set failed, error (%s)\n", sx_status_str(err));
                continue;
            }
        }
    }

out:
    if (failed_log_port_list != NULL) {
        if (failed_idx > 0) {
            SX_MEM_CPY_ARRAY(log_port_list, failed_log_port_list,
                             total_num_of_ports, sx_port_log_id_t);
            *log_port_num = failed_idx;
        }

        M_UTILS_MEM_PUT(failed_log_port_list, UTILS_MEM_TYPE_ID_HOST_IFC_E,
                        "Error on memory free", err);
        if (SX_CHECK_PASS(tot_err) && SX_CHECK_FAIL(err)) {
            tot_err = err;
        }
    }

    SX_LOG_EXIT();
    return tot_err;
}

sx_status_t host_ifc_trap_filter_get(const sx_access_cmd_t  cmd,
                                     const sx_swid_t        swid,
                                     const sx_trap_id_t     trap_id,
                                     const sx_port_log_id_t log_port_id,
                                     sx_port_log_id_t      *log_port_list_p,
                                     length_t              *log_port_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    err = host_ifc_db_trap_filter_get(cmd,
                                      swid,
                                      trap_id,
                                      log_port_id,
                                      log_port_list_p,
                                      log_port_cnt_p);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_db_trap_filter_get failed, return value: [%s].\n",
                   sx_status_str(err));
    }

    return __SX_LOG_EXIT(err);
}

sx_status_t rdq_timestamp_state_set(int rdq, boolean_t enable, boolean_t hw_utc_enable)
{
    struct ku_rdq_timestamp_state rdq_timestamp_state = {
        .dev_id = 1,
        .rdq = rdq,
        .enable = !!enable,
        .hw_utc_enable = !!hw_utc_enable,
    };
    sxd_ctrl_pack_t               ctrl_pack = {
        .ctrl_cmd = CTRL_CMD_SET_RDQ_TIMESTAMP_STATE,
        .cmd_body = &rdq_timestamp_state
    };
    sxd_status_t                  sxd_status = SXD_STATUS_SUCCESS;

    sxd_status = sxd_ioctl(ev_thread_params_s.sxd_h, &ctrl_pack);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to set timestamp state for rdq %d\n", rdq);
    }

    return SXD_STATUS_TO_SX_STATUS(sxd_status);
}


sx_status_t rdq_cpu_priority_set(int rdq, boolean_t high_prio)
{
    struct ku_rdq_cpu_priority rdq_cpu_prio = {
        .dev_id = 1,
        .rdq = rdq,
        .high_prio = !!high_prio
    };
    sxd_ctrl_pack_t            ctrl_pack = {
        .ctrl_cmd = CTRL_CMD_SET_RDQ_CPU_PRIORITY,
        .cmd_body = &rdq_cpu_prio
    };
    sxd_status_t               sxd_status = SXD_STATUS_SUCCESS;

    sxd_status = sxd_ioctl(ev_thread_params_s.sxd_h, &ctrl_pack);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to set timestamp state for rdq %d\n", rdq);
    }

    return SXD_STATUS_TO_SX_STATUS(sxd_status);
}


sx_status_t host_ifc_send_event(sx_trap_id_t      event_id,
                                void             *event_buffer_p,
                                uint32_t          event_buffer_size,
                                sx_ev_send_mode_e event_send_mode)
{
    sx_status_t           err = SX_STATUS_SUCCESS, err1 = SX_STATUS_SUCCESS;
    sxd_status_t          sxd_err = SXD_STATUS_SUCCESS;
    uint32_t              buffer_size = 0;
    void                 *buffer_p = NULL, *tmp_buffer_p = NULL;
    sxd_emad_operation_t *operation = NULL;
    sxd_emad_reg_t       *reg = NULL;
    struct ku_write       ku_write;
    struct ku_iovec       iov;
    sxd_emad_header_t    *emad_eth_hdr;
    emad_pmpe_reg_fmt_t  *emad_pmpe_reg_p = NULL;
    struct ku_pude_reg    pude_reg_data;

    SX_LOG_ENTER();

    if (SX_TRAP_ID_CHECK_RANGE(event_id) == FALSE) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(event_buffer_p, "packet buffer pointer"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(pude_reg_data);
    SX_MEM_CLR(ku_write);
    SX_MEM_CLR(iov);

    ku_write.meta.swid = 0;
    ku_write.meta.system_port_mid = 0;
    ku_write.meta.to_cpu = 0;
    ku_write.meta.type = SX_PKT_TYPE_LOOPBACK_CTL;
    ku_write.meta.rdq = 0;
    ku_write.meta.lp = 0;
    ku_write.meta.dev_id = 1;
    ku_write.meta.etclass = 6;
    ku_write.meta.loopback_data.trap_id = event_id;
    ku_write.meta.loopback_data.is_lag = 0;
    ku_write.meta.loopback_data.lag_subport = 0;
    ku_write.vec_entries = 1;
    ku_write.iov = &iov;
    /*
     * build the event packet payload with OR without EMAD header
     * for example :
     * - PMPE event will send with EMAD header
     * - NEED / NO_NEED to resolve & ACTIVITY will be sent without EMAD header
     */
    if (event_send_mode == SX_EV_SEND_MODE_WITH_EMAD_HDR_E) {
        buffer_size = sizeof(sxd_emad_header_t) +
                      sizeof(sxd_emad_operation_t) +
                      sizeof(sxd_emad_data_t) +
                      sizeof(sxd_emad_end_t);
        err = utils_clr_memory_get((void*)&buffer_p, 1, buffer_size, UTILS_MEM_TYPE_ID_HOST_IFC_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Memory allocation failed.\n");
            goto out;
        }

        ku_write.iov->iov_base = buffer_p;
        ku_write.iov->iov_len = buffer_size;
        tmp_buffer_p = buffer_p;
        emad_eth_hdr = tmp_buffer_p;
        emad_eth_hdr->et = cl_hton16(EMAD_HEADER_ET);
        tmp_buffer_p += sizeof(sxd_emad_header_t);
        operation = (sxd_emad_operation_t*)tmp_buffer_p;
        switch (event_id) {
        case SX_TRAP_ID_PMPE:
            operation->register_id = cl_hton16(SXD_REG_ID_PMPE_E);
            tmp_buffer_p += sizeof(sxd_emad_operation_t);
            reg = (sxd_emad_reg_t*)tmp_buffer_p;
            emad_pmpe_reg_p = (emad_pmpe_reg_fmt_t*)(reg->data->pmpe.reg);
            emad_pmpe_reg_p->slot_index = ((sx_event_info_t*)event_buffer_p)->pmpe.slot_id;
            emad_pmpe_reg_p->module = ((sx_event_info_t*)event_buffer_p)->pmpe.module_id;
            emad_pmpe_reg_p->module_status = ((sx_event_info_t*)event_buffer_p)->pmpe.module_state;
            emad_pmpe_reg_p->error_type = ((sx_event_info_t*)event_buffer_p)->pmpe.error_type;
            reg->type_len = (cl_hton16(sizeof(reg->data->pmpe)) & 0x7FF) >> 2;
            ku_write.meta.dev_id = ((sx_event_info_t*)event_buffer_p)->pmpe.device_id;
            break;

        default:
            SX_LOG_ERR("Sent as EMAD is unsupported for event %d \n", event_id);
            err = SX_STATUS_CMD_UNSUPPORTED;
            goto out;
        }
    } else {
        if (SX_TRAP_ID_SDK_HEALTH_EVENT == event_id) {
            ku_write.meta.dev_id = ((sx_event_info_t*)event_buffer_p)->sdk_health.device_id;
        }

        if (SX_TRAP_ID_PORT_PROFILE_APPLY_DONE == event_id) {
            ku_write.meta.dev_id = ((sx_event_info_t*)event_buffer_p)->port_profile_apply_done_info.device_id;
        }

        ku_write.iov->iov_base = event_buffer_p;
        ku_write.iov->iov_len = event_buffer_size;
    }

    /* For PUDE, use the same FD to receive and send, to avoid the SW PUDE is received by PUDE processing flow who sent it.
     * The driver loopback mechanism makes sure that the SW event written to an FD is not received by the same FD.
     *
     */
    if (event_id == SX_TRAP_ID_PUDE) {
        sxd_err = sxd_send(ev_thread_params_s.sxd_h, &ku_write, sizeof(struct ku_write));
    } else {
        sxd_err = sxd_send(sw_event_sxd_h, &ku_write, sizeof(struct ku_write));
    }
    if (sxd_err != sizeof(ku_write)) {
        SX_LOG_ERR("Failed sending loopback packet\n");
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    SX_LOG_DBG("Sent event through driver , event id: [%d]\n", event_id);

out:
    if (buffer_p != NULL) {
        err1 = utils_memory_put(buffer_p, UTILS_MEM_TYPE_ID_HOST_IFC_E);
        if (err1 != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to free buff memory. err %d \n", err1);
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_send_to_span(uint8_t span_hw_session_id, void      *packet_buffer_p, uint32_t packet_buffer_size)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    sxd_status_t    sxd_err = SXD_STATUS_SUCCESS;
    struct ku_write ku_write;
    struct ku_iovec iov;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(packet_buffer_p, "packet buffer pointer"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(ku_write);
    SX_MEM_CLR(iov);

    ku_write.meta.type = SX_PKT_TYPE_ETH_DATA;
    ku_write.meta.dev_id = 1;
    ku_write.meta.etclass = 0; /* best effort */
    ku_write.meta.span_oob_data_valid = 1;
    ku_write.meta.span_oob_data.ext_fwd_mode = SX_EXT_FWD_MODE_MIRROR_AGENT;  /* define ext fwd mode: regular_mirror_agent or mirror_agent */
    ku_write.meta.span_oob_data.span_session_id = span_hw_session_id;
    ku_write.meta.span_oob_data.mirror_reason_id = SX_HOST_BASED_MIRROR_REASON_ID_1_E;  /* currently not in use , but valid values 1-3 */

    ku_write.vec_entries = 1;
    ku_write.iov = &iov;
    ku_write.iov->iov_base = packet_buffer_p;
    ku_write.iov->iov_len = packet_buffer_size;

    sxd_err = sxd_send(sw_event_sxd_h, &ku_write, sizeof(struct ku_write));
    if (sxd_err != sizeof(ku_write)) {
        SX_LOG_ERR("Failed sending packet to span session %d\n", span_hw_session_id);
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    SX_LOG_DBG("Sent packet to span session id %d through driver. \n", span_hw_session_id);

out:

    SX_LOG_EXIT();
    return err;
}


static sx_status_t __host_ifc_spectrum_hw_trap_group_is_open_rdq(sx_swid_t swid, uint32_t hw_trap_group)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    uint8_t     found_rdq = FALSE;

    SX_LOG_ENTER();

    /* Scan pci profile RDQs for the available new hw_trap_group */
    for (i = 0; i < __pci_profile_s.rdq_count[swid]; i++) {
        if (__pci_profile_s.rdq[swid][i] == hw_trap_group) {
            found_rdq = TRUE;
            break;
        }
    }

    /* If the new hw_trap_group doesn't have an open RDQ in pci profile, return error */
    if (found_rdq == FALSE) {
        err = SX_STATUS_NO_RESOURCES;
    }

    SX_LOG_EXIT();
    return err;
}


/*
 *  Regular trap group TC will be shifted by REGULAR_RDQ_TC_SHIFT
 *  Special trap group (monitor or tac_capable) TC will remains the same
 *  This is needed to prioritize the traffic to regular trap groups over
 *  the traffic to monitor traps groups
 */
static uint8_t __trap_prio_2_cpu_tc(boolean_t is_special, sx_trap_priority_t trap_priority)
{
    return (is_special ? trap_priority : trap_priority + TRAP_GROUP_REGULAR_RDQ_TC_SHIFT);
}


/* Notify to all associated trap IDs when the hardware trap group's priority changes */
static sx_status_t __host_ifc_trap_group_prio_change_notify(sx_trap_group_t hw_trap_group)
{
    sx_status_t  status = SX_STATUS_SUCCESS;
    sx_trap_id_t trap_id_arr[SX_TRAP_ID_MAX];
    length_t     trap_id_arr_len = SX_TRAP_ID_MAX;
    uint32_t     i = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_id_arr);

    status = host_ifc_db_trap_id_list_get(hw_trap_group, trap_id_arr, &trap_id_arr_len);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to get list of associated trap IDs to HW trap group [%u], err: %s",
                   hw_trap_group,
                   sx_status_str(status));
        goto out;
    }

    for (i = 0; i < trap_id_arr_len; i++) {
        status = adviser_process_event(ADVISER_EVENT_POST_TRAP_ID_PRIO_CHANGE_E, &trap_id_arr[i]);
        if (SX_CHECK_FAIL(SX_STATUS_SUCCESS)) {
            SX_LOG_ERR("Could not process event '%s' for trap ID %u..\n",
                       ADVISER_EVENT_STR(ADVISER_EVENT_POST_TRAP_ID_PRIO_CHANGE_E), trap_id_arr[i]);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}


sx_status_t host_ifc_spectrum_configure_hw_trap_group_properties(sx_swid_t                     swid,
                                                                 sx_trap_group_t               trap_group_id,
                                                                 sx_trap_priority_t            trap_priority,
                                                                 sx_truncate_mode_t            truncate_mode,
                                                                 sx_truncate_size_t            truncate_size,
                                                                 sx_trap_truncate_profile_id_t trunc_profile_id,
                                                                 sx_control_type_t             control_type,
                                                                 boolean_t                     add_timestamp,
                                                                 sx_packet_timestamp_source_e  timestamp_source,
                                                                 boolean_t                     is_tac_capable,
                                                                 boolean_t                     is_monitor,
                                                                 sx_fd_t                      *monitor_fd,
                                                                 uint32_t                     *hw_trap_group)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_status_t                      err2 = SX_STATUS_SUCCESS;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    boolean_t                        trap_group_set = FALSE;
    boolean_t                        trap_group_deleted = FALSE;
    uint32_t                         old_hw_trap_group = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_group_properties);

    if (SX_CHECK_FAIL(utils_check_pointer(hw_trap_group,
                                          "hw_trap_group"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Check if a HW trap group is already mapped to the trap group ID */
    err = host_ifc_db_trap_group_map_get(swid, trap_group_id, hw_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get HW trap group ID for swid %u, trap group %u, return value: [%s]\n",
                   swid, trap_group_id, sx_status_str(err));
        goto out;
    }

    /* limit number of monitor trap groups to SX_MAX_MONITOR_TRAP_GROUPS_COUNT */
    if ((*hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) && is_monitor) {     /* if trap group wasn't existed before */
        if (monitor_trap_groups_count >= SX_MAX_MONITOR_TRAP_GROUPS_COUNT) {
            err = SX_STATUS_NO_RESOURCES;
            SX_LOG_ERR("Count of monitor trap groups reach max %d. [%s]\n",
                       SX_MAX_MONITOR_TRAP_GROUPS_COUNT, sx_status_str(err));
            goto out;
        }
    }

    /* If a HW trap group hasn't been mapped to this trap group ID yet, find a
     * free one and map it now. */
    if (*hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
        err = host_ifc_db_spectrum_hw_trap_group_get(swid, trap_priority, &__pci_profile_s, hw_trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get free HW trap group ID for swid %u, return value: [%s]\n",
                       swid, sx_status_str(err));
            goto out;
        }

        /* Verify that new hw_trap_group has open RDQ in pci profile */
        err = __host_ifc_spectrum_hw_trap_group_is_open_rdq(swid, *hw_trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("The new hw_trap_group (%u) doesn't have an open RDQ for"
                       " swid (%u) in pci_profile, return value: [%s]\n",
                       *hw_trap_group, swid, sx_status_str(err));
            goto out;
        }

        err = host_ifc_db_trap_group_map_set(SX_ACCESS_CMD_SET, swid, trap_group_id,
                                             *hw_trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set HW trap group %u to user trap group %u for swid %u, return value: [%s]\n",
                       *hw_trap_group, trap_group_id, swid, sx_status_str(err));
            goto out;
        }
        trap_group_set = TRUE;
    }

    err = host_ifc_db_trap_group_properties_get(swid, *hw_trap_group,
                                                &trap_group_properties, &is_trap_group_configured);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get trap group properties for swid %u HW trap group %u, return value: [%s]\n",
                   swid, *hw_trap_group, sx_status_str(err));
        goto out;
    }

    /* if trap group was exists before and it is Monitor trap group then it can't be changed to non-monitor */
    if ((!trap_group_set) && (trap_group_properties.is_monitor != is_monitor)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Conversion of monitor trap group to non-monitor (and vise versa) is unsupported. [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    /* If a HW trap group is already mapped to the trap group ID and the user wants
     * to change the priority, then we need to delete the old mapping and find a new one.
     */
    if ((!trap_group_set) && (trap_group_properties.priority != trap_priority)) {
        old_hw_trap_group = *hw_trap_group;
        err = host_ifc_db_trap_group_map_set(SX_ACCESS_CMD_DELETE, swid, trap_group_id,
                                             old_hw_trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to delete HW trap group %u from user trap group %u for swid %u, return value: [%s]\n",
                       old_hw_trap_group, trap_group_id, swid, sx_status_str(err));
            goto out;
        }
        trap_group_deleted = TRUE;

        err = host_ifc_db_spectrum_hw_trap_group_get(swid, trap_priority, &__pci_profile_s, hw_trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get free HW trap group ID for swid %u, return value: [%s]\n",
                       swid, sx_status_str(err));
            goto out;
        }

        /* Verify that new hw_trap_group has open RDQ in pci profile */
        err = __host_ifc_spectrum_hw_trap_group_is_open_rdq(swid, *hw_trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("The new hw_trap_group (%u) doesn't have an open RDQ for"
                       " swid (%u) in pci_profile, return value: [%s]\n",
                       *hw_trap_group, swid, sx_status_str(err));
            goto out;
        }

        err = host_ifc_db_trap_group_map_set(SX_ACCESS_CMD_SET, swid, trap_group_id,
                                             *hw_trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set HW trap group %u to user trap group %u for swid %u, return value: [%s]\n",
                       *hw_trap_group, trap_group_id, swid, sx_status_str(err));
            goto out;
        }
        trap_group_set = TRUE;
    }

    /* Fill in the remaining attributes of the HW trap group: one-to-one mapping
     * of HW trap group to RDQ to TClass. */
    trap_group_properties.control_type = control_type;
    trap_group_properties.add_timestamp = add_timestamp;
    trap_group_properties.timestamp_source = timestamp_source;
    trap_group_properties.group = *hw_trap_group;
    trap_group_properties.priority = trap_priority;
    trap_group_properties.swid = swid;
    trap_group_properties.truncate_mode = truncate_mode;
    trap_group_properties.truncate_size = truncate_size;
    trap_group_properties.trunc_profile_id = trunc_profile_id;
    trap_group_properties.is_tac_capable = is_tac_capable;
    trap_group_properties.is_monitor = is_monitor;
    if (is_monitor && monitor_fd) {
        trap_group_properties.monitor_fd = *monitor_fd;
    }
    trap_group_properties.type = SXD_HOST_IF_PATH_TYPE_LOCAL_E;
    trap_group_properties.path.local_path.rdq = *hw_trap_group;

    /*
     *  Regular trap group TC will be shifted by REGULAR_RDQ_TC_SHIFT
     *  This is needed to prioritize the traffic to regular trap groups over
     *  the traffic to monitor traps groups
     */
    trap_group_properties.path.local_path.cpu_tclass = __trap_prio_2_cpu_tc(
        (trap_group_properties.is_monitor | trap_group_properties.is_tac_capable), trap_priority);

    /* Set the new properties of the HW trap group in the local DB */
    err = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET, swid,
                                                *hw_trap_group, &trap_group_properties);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap group properties for swid %u HW trap group %u, return value: [%s]\n",
                   swid, *hw_trap_group, sx_status_str(err));
        goto out;
    }

    if ((trap_group_set == TRUE) && (trap_group_deleted != TRUE) && is_monitor) {      /* if trap group wasn't existed before */
        monitor_trap_groups_count++;
    }

out:
    if ((err) && (trap_group_set)) {
        err2 = host_ifc_db_trap_group_map_set(SX_ACCESS_CMD_DELETE, swid, trap_group_id,
                                              *hw_trap_group);
        if (SX_CHECK_FAIL(err2)) {
            SX_LOG_ERR("Failed to delete HW trap group %u from user trap group %u for swid %u, return value: [%s]\n",
                       *hw_trap_group, trap_group_id, swid, sx_status_str(err2));
        }
    }

    if ((err) && (trap_group_deleted)) {
        err2 = host_ifc_db_trap_group_map_set(SX_ACCESS_CMD_SET, swid, trap_group_id,
                                              old_hw_trap_group);
        if (SX_CHECK_FAIL(err2)) {
            SX_LOG_ERR("Failed to set HW trap group %u to user trap group %u for swid %u, return value: [%s]\n",
                       old_hw_trap_group, trap_group_id, swid, sx_status_str(err2));
        }
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_sx_configure_trap_group_properties(sx_swid_t                     swid,
                                                        sx_trap_group_t               trap_group_id,
                                                        sx_trap_priority_t            trap_priority,
                                                        sx_truncate_mode_t            truncate_mode,
                                                        sx_truncate_size_t            truncate_size,
                                                        sx_trap_truncate_profile_id_t trunc_profile_id,
                                                        sx_control_type_t             control_type,
                                                        boolean_t                     add_timestamp,
                                                        uint32_t                     *hw_trap_group)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_status_t                      err2 = SX_STATUS_SUCCESS;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    sx_hw_trap_group_e               old_hw_trap_group = 0;
    sx_trap_group_t                  old_trap_group = 0;
    boolean_t                        trap_group_set = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_group_properties);

    if (SX_CHECK_FAIL(utils_check_pointer(hw_trap_group,
                                          "hw_trap_group"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Convert trap priority to HW trap group ID */
    err = host_ifc_trap_prio_2_trap_group(trap_priority,
                                          hw_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("failed to convert priority %u to trap group, return value: [%s]\n",
                   trap_priority, sx_status_str(err));
        goto out;
    }

    /* Get HW trap group DB parameters */
    err = host_ifc_db_trap_group_properties_get(swid,
                                                *hw_trap_group,
                                                &trap_group_properties,
                                                &is_trap_group_configured);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to fetch HW trap group %u properties from DB for SWID %u, return value: [%s]\n",
                   *hw_trap_group, swid, sx_status_str(err));
        goto out;
    }

    /* Validity check - group configured */
    if (is_trap_group_configured == FALSE) {
        SX_LOG_ERR("Trap group [%u] is not configured\n", *hw_trap_group);
        err = SX_STATUS_ERROR;
        goto out;
    }

    /* Check if the user trap group is already mapped */
    err = host_ifc_db_trap_group_map_get(swid, trap_group_id,
                                         &old_hw_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get trap group mapping from the DB for SWID %u trap group %u, return value: [%s].\n",
                   swid, trap_group_id, sx_status_str(err));
        goto out;
    }

    if ((old_hw_trap_group != SX_HW_TRAP_GROUP_DISABLE_E) &&
        (old_hw_trap_group != *hw_trap_group)) {
        SX_LOG_ERR("Changing trap group priority is not supported\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    err = host_ifc_db_trap_group_reverse_map_get(swid, *hw_trap_group,
                                                 &old_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get trap group for SWID %u HW trap group %u, return value: [%s]\n",
                   swid, *hw_trap_group, sx_status_str(err));
        goto out;
    }

    if ((old_trap_group != SX_TRAP_GROUP_MAX + 1) &&
        (old_trap_group != trap_group_id)) {
        SX_LOG_ERR("HW trap group %u is already mapped to trap group %u\n",
                   *hw_trap_group, old_trap_group);
        err = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }

    /* No need to set the trap group in the local DB if it is already set */
    if (old_hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
        err = host_ifc_db_trap_group_map_set(SX_ACCESS_CMD_SET, swid, trap_group_id,
                                             *hw_trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set HW trap group [%u] mapping in the DB for SWID %u, return value: [%s]\n",
                       *hw_trap_group, swid, sx_status_str(err));
            goto out;
        }
        trap_group_set = TRUE;
    }

    trap_group_properties.control_type = control_type;
    trap_group_properties.add_timestamp = add_timestamp;
    trap_group_properties.timestamp_source = SX_PACKET_TIMESTAMP_SOURCE_LINUX_E;
    trap_group_properties.group = *hw_trap_group;
    trap_group_properties.priority = trap_priority;
    trap_group_properties.swid = swid;
    trap_group_properties.truncate_mode = truncate_mode;
    trap_group_properties.truncate_size = truncate_size;
    trap_group_properties.trunc_profile_id = trunc_profile_id;
    err = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET, swid,
                                                *hw_trap_group, &trap_group_properties);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set properties for SWID %u HW trap group %u, return value: [%s]\n",
                   swid, *hw_trap_group, sx_status_str(err));
        goto out;
    }

out:
    if ((err) && (trap_group_set)) {
        err2 = host_ifc_db_trap_group_map_set(SX_ACCESS_CMD_DELETE, swid, trap_group_id,
                                              *hw_trap_group);
        if (SX_CHECK_FAIL(err2)) {
            SX_LOG_ERR("Failed to unset HW trap group [%u] mapping in the DB for SWID %u, return value: [%s]\n",
                       *hw_trap_group, swid, sx_status_str(err2));
        }
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_spectrum_validation_trap_group_set(sx_swid_id_t                swid,
                                                        sx_trap_group_t             trap_group,
                                                        sx_trap_group_attributes_t *trap_group_attributes_p)
{
    if (trap_group_attributes_p == NULL) {
        return SX_STATUS_PARAM_NULL;
    }
    if ((trap_group_attributes_p->truncate_mode != SX_TRUNCATE_MODE_ENABLE) &&
        (trap_group_attributes_p->truncate_mode != SX_TRUNCATE_MODE_DISABLE)) {
        SX_LOG_ERR("Spectrum1 only support enable and disable mode\n");
        return SX_STATUS_PARAM_ERROR;
    }
    if (trap_group_attributes_p->timestamp_source == SX_PACKET_TIMESTAMP_SOURCE_HW_UTC_E) {
        /* Spectrum does not support HW UTC source */
        SX_LOG_ERR("Invalid timestamp source (HW UTC)\n");
        return SX_STATUS_PARAM_ERROR;
    } else {
        return host_ifc_spectrum_trap_group_set(swid, trap_group, trap_group_attributes_p);
    }
}

sx_status_t host_ifc_spectrum_trap_group_set(sx_swid_id_t                swid,
                                             sx_trap_group_t             trap_group,
                                             sx_trap_group_attributes_t *trap_group_attributes_p)
{
    if ((trap_group_attributes_p->truncate_mode != SX_TRUNCATE_MODE_ENABLE) &&
        (trap_group_attributes_p->truncate_mode != SX_TRUNCATE_MODE_DISABLE)) {
        SX_LOG_ERR("Spectrum2/3 only support enable and disable mode\n");
        return SX_STATUS_PARAM_ERROR;
    } else {
        return host_ifc_spectrum_trap_group_set_spectrum4(swid, trap_group, trap_group_attributes_p);
    }
}

sx_status_t host_ifc_spectrum_trap_group_set_spectrum4(sx_swid_id_t                swid,
                                                       sx_trap_group_t             trap_group,
                                                       sx_trap_group_attributes_t *trap_group_attributes_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sxd_status_t                     sxd_status = SXD_STATUS_SUCCESS;
    uint32_t                         hw_trap_group = 0;
    host_ifc_trap_group_properties_t trap_group_properties, old_trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    struct ku_set_truncate_params    truncate_params;
    sx_trap_id_t                     trap_id = 0;
    host_ifc_trap_id_properties_t    trap_id_properties;
    boolean_t                        is_regular_group_associated = FALSE;
    boolean_t                        is_monitor_group_associated = FALSE;
    boolean_t                        is_in_use = FALSE;
    host_ifc_db_profile_cfg_t        host_ifc_db_profile_cfg;

    SX_MEM_CLR(trap_group_properties);
    SX_MEM_CLR(truncate_params);
    SX_MEM_CLR(trap_id_properties);

    if (trap_group_attributes_p->is_tac_capable &&
        (trap_group_attributes_p->truncate_mode != SX_TRUNCATE_MODE_PROFILE_ENABLE)) {
        SX_LOG(SX_LOG_ERROR, "TAC group has to use a truncation profile \n");
        return SX_STATUS_PARAM_ERROR;
    }

    if (trap_group_attributes_p->truncate_mode == SX_TRUNCATE_MODE_PROFILE_ENABLE) {
        err = host_ifc_db_profile_cfg_get(trap_group_attributes_p->trunc_profile_id, &host_ifc_db_profile_cfg);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "host_ifc_db_profile_cfg_get failed: [%s].\n",
                   SX_STATUS_MSG(err));
            goto out;
        }

        if (host_ifc_db_profile_cfg.created == FALSE) {
            SX_LOG(SX_LOG_ERROR, "Trunc profile %d is not created.\n", trap_group_attributes_p->trunc_profile_id);
            return SX_STATUS_PARAM_ERROR;
        }


        if (trap_group_attributes_p->is_tac_capable &&
            (host_ifc_db_profile_cfg.cfg.truncate_size > SX_TELE_TAC_TRUNCATION_SIZE_DEFAULT)) {
            SX_LOG(SX_LOG_ERROR,
                   "For TAC group, truncate_size should be less than TAC max %d.\n",
                   SX_TELE_TAC_TRUNCATION_SIZE_DEFAULT);
            return SX_STATUS_PARAM_ERROR;
        }
    }

    SX_MEM_CLR(old_trap_group_properties);
    err = host_ifc_db_trap_group_properties_get(swid, hw_trap_group,
                                                &old_trap_group_properties,
                                                &is_trap_group_configured);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get current trap group properties for SWID %u, HW trap group %u, err: [%s]\n",
                   swid, hw_trap_group, sx_status_str(err));
        goto out;
    }

    err = host_ifc_spectrum_configure_hw_trap_group_properties(swid,
                                                               trap_group,
                                                               trap_group_attributes_p->prio,
                                                               trap_group_attributes_p->truncate_mode,
                                                               trap_group_attributes_p->truncate_size,
                                                               trap_group_attributes_p->trunc_profile_id,
                                                               trap_group_attributes_p->control_type,
                                                               trap_group_attributes_p->add_timestamp,
                                                               trap_group_attributes_p->timestamp_source,
                                                               trap_group_attributes_p->is_tac_capable,
                                                               trap_group_attributes_p->is_monitor,
                                                               &trap_group_attributes_p->monitor_fd,
                                                               &hw_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to configure HW trap group properties for swid %u, trap group %u, return value: [%s]\n",
                   swid, trap_group, sx_status_str(err));
        goto out;
    }

    err = host_ifc_db_trap_group_properties_get(swid, hw_trap_group,
                                                &trap_group_properties,
                                                &is_trap_group_configured);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get trap group properties for swid %u, HW trap group %u, return value: [%s]\n",
                   swid, hw_trap_group, sx_status_str(err));
        goto out;
    }

    err = __validate_trap_control_allowed_for_trap_group(swid,
                                                         trap_group,
                                                         trap_group_attributes_p->control_type);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("control type (%u) cannot be configure for the trap IDs registered"
                   "on SWID (%u), trap group (%u), err: [%s]\n",
                   trap_group_attributes_p->control_type, swid, trap_group, sx_status_str(err));
        goto out;
    }

    truncate_params.dev_id = 1;
    truncate_params.rdq = trap_group_properties.path.local_path.rdq;
    truncate_params.truncate_enable = (trap_group_attributes_p->truncate_mode == SX_TRUNCATE_MODE_ENABLE) ? 1 : 0;
    truncate_params.truncate_size = trap_group_attributes_p->truncate_size;
    sxd_status = sxd_access_reg_truncate_size_set(&truncate_params);
    err = SXD_STATUS_TO_SX_STATUS(sxd_status);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set truncate parameters in the driver, return value: [%s].\n",
                   SXD_STATUS_MSG(sxd_status));
        goto out;
    }

    err = host_ifc_handle_htgt(0, swid, hw_trap_group,
                               &trap_group_properties.type,
                               &trap_group_properties.path,
                               &trap_group_properties.policer_id_enabled,
                               &trap_group_properties.policer_id,
                               &trap_group_properties.priority,
                               &trap_group_properties.mirror_action,
                               &trap_group_properties.mirror_agent,
                               &trap_group_properties.mirror_probability_rate);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HTGT parameters in the driver, [trap_group = %u], return value: [%s]\n",
                   hw_trap_group, sx_status_str(err));
        goto out;
    }

    for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
        err = host_ifc_db_trap_id_properties_get(trap_id,
                                                 &trap_id_properties);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get trap ID %u properties, return value: [%s]\n",
                       trap_id, sx_status_str(err));
            continue;
        }

        if (trap_id_properties.hw_trap_group == hw_trap_group) {
            /* get the current trap binding configuration */
            err = __host_ifc_trap_id_is_group_associated_get(trap_id,
                                                             &is_regular_group_associated,
                                                             &is_monitor_group_associated,
                                                             NULL);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR(
                    "Failed in __host_ifc_trap_id_is_group_associated_get, [trap_id = %u], return value: [%s]\n",
                    trap_id,
                    sx_status_str(err));
                continue;
            }

            /* if trap id is used by different trap group as well we shouldn't update HW with DISCARD action */
            if ((trap_id_properties.trap_action == SX_TRAP_ACTION_DISCARD) &&
                ((is_regular_group_associated == TRUE) ||
                 (is_monitor_group_associated == TRUE))) {
                SX_LOG_DBG("Trap ID 0x%x is used by %s trap group, hence don't update HPKT with DISCARD action.\n",
                           trap_id,
                           ((is_regular_group_associated == TRUE) ? "regular" : "monitor"));
                continue;
            } else {
                trap_id_properties.control_type = trap_group_attributes_p->control_type;
                is_in_use = trap_id_properties.trap_action != SX_TRAP_ACTION_IGNORE &&
                            trap_id_properties.trap_action != SX_TRAP_ACTION_SET_FW_DEFAULT;
                err = host_ifc_db_trap_id_properties_set(trap_id,
                                                         trap_id_properties, TRUE, is_in_use);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to set trap ID %u properties, return value: [%s]\n",
                               trap_id, sx_status_str(err));
                    continue;
                }

                if (!SX_TRAP_ID_SW_CHECK_RANGE(trap_id)) {
                    err = __handle_hpkt(trap_id_properties.hw_trap_id, &trap_id_properties.trap_action,
                                        &hw_trap_group, &trap_id_properties.control_type,
                                        (trap_group_attributes_p->truncate_mode == SX_TRUNCATE_MODE_PROFILE_ENABLE),
                                        trap_group_attributes_p->trunc_profile_id);
                    if (SX_CHECK_FAIL(err)) {
                        SX_LOG_ERR(
                            "%s: Failed to set HPKT parameters in the driver for trap ID %u, return value: [%s]\n",
                            __FUNCTION__,
                            trap_id,
                            sx_status_str(err));
                        continue;
                    }
                }
            }
        }
    }

    if (old_trap_group_properties.priority != trap_group_properties.priority) {
        err = __host_ifc_trap_group_prio_change_notify(hw_trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to notify on changing priority of HW trap group [%u], err: %s\n",
                       hw_trap_group, sx_status_str(err));
            goto out;
        }
    }

    err = SX_STATUS_SUCCESS;

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_is_trap_group_associated(sx_trap_group_t trap_group,
                                                       boolean_t      *is_associated_p,
                                                       sx_trap_id_t   *trap_id_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_trap_id_t                     trap_id;
    sx_trap_group_t                  trap_groups[SX_TRAP_ID_MAX + 1];
    uint32_t                         trap_group_cnt;
    sx_host_ifc_trap_cfg_flow_type_e flow_type = SX_HOST_IFC_TRAP_CFG_FLOW_TYPE_NONE_E;
    uint32_t                         i;

    SX_LOG_ENTER();

    for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
        rc = host_ifc_db_trap_id_to_group_associate_get(trap_id,
                                                        trap_groups,
                                                        NULL,
                                                        &trap_group_cnt);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get trap ID associated groups from DB for "
                       "trap id (0x%x), return value: [%s].\n", trap_id, sx_status_str(rc));
            goto out;
        }

        if (trap_group_cnt == 0) {
            continue;
        }

        for (i = 0; i < trap_group_cnt; ++i) {
            flow_type = SX_HOST_IFC_TRAP_CFG_FLOW_TYPE_NONE_E;

            if (trap_groups[i] != trap_group) {
                continue;
            }

            rc = host_ifc_db_trap_id_flow_type_get(trap_id,
                                                   trap_groups[i],
                                                   &flow_type);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("host_ifc_db_trap_id_flow_type_get failed, trap_id: %u, trap_group: %u, error: %s\n",
                           trap_id, trap_groups[i], sx_status_str(rc));
                goto out;
            }

            if (flow_type == SX_HOST_IFC_TRAP_CFG_FLOW_TYPE_EXT_E) {
                *is_associated_p = TRUE;
                *trap_id_p = trap_id;
                goto out;
            }
        }
    }

    *is_associated_p = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t host_ifc_spectrum_trap_group_used(sx_swid_id_t    swid,
                                              sx_trap_group_t trap_group,
                                              boolean_t      *is_trap_group_associated_p)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    sx_hw_trap_group_e            hw_trap_group_id = SX_HW_TRAP_GROUP_MIN_E;
    sx_trap_id_t                  trap_id = SX_TRAP_ID_MIN;
    host_ifc_trap_id_properties_t trap_id_properties;
    boolean_t                     is_trap_group_associated = FALSE;

    SX_MEM_CLR(trap_id_properties);

    SX_LOG_ENTER();

    *is_trap_group_associated_p = FALSE;

    rc = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group_id);
    if (SX_CHECK_FAIL(rc)) {
        rc = SX_STATUS_SUCCESS;
        SX_LOG_DBG("Failed to get trap group mapping from the DB, [trap_group = %u].\n", trap_group);
        goto out;
    }

    if (hw_trap_group_id == SX_HW_TRAP_GROUP_DISABLE_E) {
        SX_LOG_DBG("The trap group (%u) has not been set yet.\n", trap_group);
        goto out;
    }

    rc = __host_ifc_is_trap_group_associated(trap_group, &is_trap_group_associated, &trap_id);
    if (SX_CHECK_FAIL(rc)) {
        rc = SX_STATUS_SUCCESS;
        SX_LOG_DBG("__host_ifc_is_trap_group_associated failed, [trap_group = %u].\n", trap_group);
        goto out;
    }

    if (is_trap_group_associated) {
        *is_trap_group_associated_p = TRUE;
        SX_LOG_ERR(
            "Trap ID (%u) is already associated with trap group (%u), please unset the trap ID first.\n",
            trap_id,
            trap_group);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t host_ifc_spectrum_trap_group_unset(sx_swid_id_t                swid,
                                               sx_trap_group_t             trap_group,
                                               sx_trap_group_attributes_t *trap_group_attributes_p,
                                               uint32_t                   *hw_trap_group_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_status_t                      rollback_rc = SX_STATUS_SUCCESS;
    sx_hw_trap_group_e               hw_trap_group_id = SX_HW_TRAP_GROUP_MIN_E;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    sx_trap_id_t                     trap_id = SX_TRAP_ID_MIN;
    host_ifc_trap_id_properties_t    trap_id_properties;
    sxd_host_interface_path_type_e   null_path_type = SXD_HOST_IF_PATH_TYPE_NULL_E;
    boolean_t                        is_trap_group_associated = FALSE;
    boolean_t                        is_trap_group_used = FALSE;
    sx_trap_group_t                  trap_groups[SX_TRAP_ID_MAX + 1];
    sx_trap_action_t                 trap_actions[SX_TRAP_ID_MAX + 1];
    uint32_t                         trap_group_cnt = 0;
    sx_hw_trap_group_e               hw_trap_group_dbl_id = SX_HW_TRAP_GROUP_DISABLE_E;

    SX_MEM_CLR(trap_id_properties);

    SX_LOG_ENTER();

    rc = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group mapping from the DB, [trap_group = %u], return value: [%s].\n",
                   trap_group, sx_status_str(rc));
        goto out;
    }

    if (hw_trap_group_id == SX_HW_TRAP_GROUP_DISABLE_E) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("The trap group (%u) has not been set yet.\n", trap_group);
        goto out;
    }
    *hw_trap_group_p = hw_trap_group_id;

    rc = __host_ifc_is_trap_group_associated(trap_group, &is_trap_group_associated, &trap_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("__host_ifc_is_trap_group_associated failed, [trap_group = %u], return value: [%s].\n",
                   trap_group, sx_status_str(rc));
        goto out;
    }

    if (is_trap_group_associated) {
        SX_LOG_ERR(
            "Trap ID (%u) is already associated with trap group (%u), please unset the trap ID first.\n",
            trap_id,
            trap_group);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    SX_MEM_CLR(trap_group_properties);
    rc = host_ifc_db_trap_group_properties_get(swid, hw_trap_group_id,
                                               &trap_group_properties,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group properties for swid %u, HW trap group %u, return value: [%s]\n",
                   swid, hw_trap_group_id, sx_status_str(rc));
        goto out;
    }
    trap_group_attributes_p->truncate_mode = trap_group_properties.truncate_mode;
    trap_group_attributes_p->truncate_size = trap_group_properties.truncate_size;
    trap_group_attributes_p->trunc_profile_id = trap_group_properties.trunc_profile_id;
    trap_group_attributes_p->prio = trap_group_properties.priority;
    trap_group_attributes_p->control_type = trap_group_properties.control_type;
    trap_group_attributes_p->add_timestamp = trap_group_properties.add_timestamp;
    trap_group_attributes_p->timestamp_source = trap_group_properties.timestamp_source;
    trap_group_attributes_p->is_tac_capable = trap_group_properties.is_tac_capable;
    trap_group_attributes_p->is_monitor = trap_group_properties.is_monitor;
    trap_group_attributes_p->monitor_fd = trap_group_properties.monitor_fd;

    if (trap_group_properties.policer_id_enabled) {
        SX_LOG_ERR("Policer (ID: %" PRIu64 ") is already bound to trap group (%u), please unbind the policer first.\n",
                   trap_group_properties.policer_id, trap_group);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = host_ifc_db_trap_group_map_set(SX_ACCESS_CMD_DELETE, swid, trap_group,
                                        hw_trap_group_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to delete HW trap group %u from user trap group %u for swid %u, return value: [%s]\n",
                   hw_trap_group_id, trap_group, swid, sx_status_str(rc));
        goto out;
    }

    rc = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_DELETE, swid,
                                               hw_trap_group_id, &trap_group_properties);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to delete trap group properties for swid %u HW trap group %u, return value: [%s]\n",
                   swid, hw_trap_group_id, sx_status_str(rc));
        goto trap_group_map_deleted;
    }

    for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
        rc = host_ifc_db_trap_id_properties_get(trap_id,
                                                &trap_id_properties);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get trap ID %u properties, return value: [%s]\n",
                       trap_id, sx_status_str(rc));
            continue;
        }

        if (trap_id_properties.hw_trap_group == hw_trap_group_id) {
            rc = host_ifc_db_trap_id_to_group_associate_get(trap_id,
                                                            trap_groups,
                                                            trap_actions,
                                                            &trap_group_cnt);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get trap ID associated groups from DB for "
                           "trap id (0x%x), return value: [%s].\n", trap_id, sx_status_str(rc));
                continue;
            }

            if (trap_group_cnt != 0) {
                /* If trap_group_cnt is not 0 then it means that we have trap double registration case
                 *  and instead of regular removing trap group we should replace properties */
                rc = host_ifc_db_trap_group_map_get(swid, trap_groups[0], &hw_trap_group_dbl_id);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR(
                        "Failed to get trap group mapping from the DB, [trap_group = %u], return value: [%s].\n",
                        trap_group,
                        sx_status_str(rc));
                    goto out;
                }

                /* update trap id properties with actual attributes */
                trap_id_properties.hw_trap_group = hw_trap_group_dbl_id;
                trap_id_properties.trap_action = trap_actions[0];
                is_trap_group_associated = TRUE;
                is_trap_group_used = TRUE;
            } else {
                trap_id_properties.hw_trap_group = SX_HW_TRAP_GROUP_DISABLE_E;
                is_trap_group_associated = FALSE;
                is_trap_group_used = FALSE;
            }

            rc = host_ifc_db_trap_id_properties_set(trap_id,
                                                    trap_id_properties, is_trap_group_used, is_trap_group_used);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get trap ID %u properties, return value: [%s]\n",
                           trap_id, sx_status_str(rc));
                continue;
            }

            if (is_trap_group_associated == FALSE) {
                bit_vector_clear(__bitmap_valid_trap_id, trap_id);
            }
        }
    }

    rc = host_ifc_handle_htgt(0, swid, hw_trap_group_id,
                              &null_path_type,
                              &trap_group_properties.path,
                              &trap_group_properties.policer_id_enabled,
                              &trap_group_properties.policer_id,
                              &trap_group_properties.priority,
                              &trap_group_properties.mirror_action,
                              &trap_group_properties.mirror_agent,
                              &trap_group_properties.mirror_probability_rate);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set HTGT parameters in the driver, [trap_group = %u], return value: [%s]\n",
                   hw_trap_group_id, sx_status_str(rc));
        goto trap_group_properties_deleted;
    }

    if (trap_group_attributes_p->is_monitor) {
        monitor_trap_groups_count--;
    }

    goto out;

trap_group_properties_deleted:
    rollback_rc = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET, swid,
                                                        hw_trap_group_id, &trap_group_properties);
    if (SX_CHECK_FAIL(rollback_rc)) {
        SX_LOG_ERR("Failed to set trap group properties for swid %u HW trap group %u, return value: [%s]\n",
                   swid, hw_trap_group_id, sx_status_str(rollback_rc));
    }

trap_group_map_deleted:
    rollback_rc = host_ifc_db_trap_group_map_set(SX_ACCESS_CMD_SET, swid, trap_group,
                                                 hw_trap_group_id);
    if (SX_CHECK_FAIL(rollback_rc)) {
        SX_LOG_ERR("Failed to set HW trap group %u to user trap group %u for swid %u, return value: [%s]\n",
                   hw_trap_group_id, trap_group, swid, sx_status_str(rollback_rc));
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t host_ifc_sx_trap_group_set(sx_swid_id_t                swid,
                                       sx_trap_group_t             trap_group,
                                       sx_trap_group_attributes_t *trap_group_attributes_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sxd_status_t                     sxd_status = SXD_STATUS_SUCCESS;
    uint32_t                         hw_trap_group = 0;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    struct ku_set_truncate_params    truncate_params;

    SX_MEM_CLR(trap_group_properties);
    SX_MEM_CLR(truncate_params);

    if (trap_group_attributes_p->control_type != SX_CONTROL_TYPE_DEFAULT) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Control type %u is not supported on this chip type, return value: [%s]\n",
                   trap_group_attributes_p->control_type, sx_status_str(err));
        goto out;
    }

    err = host_ifc_sx_configure_trap_group_properties(swid, trap_group,
                                                      trap_group_attributes_p->prio,
                                                      trap_group_attributes_p->truncate_mode,
                                                      trap_group_attributes_p->truncate_size,
                                                      trap_group_attributes_p->trunc_profile_id,
                                                      trap_group_attributes_p->control_type,
                                                      trap_group_attributes_p->add_timestamp,
                                                      &hw_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to configure HW trap group properties for swid %u, trap group %u, return value: [%s]\n",
                   swid, trap_group, sx_status_str(err));
        goto out;
    }

    err = host_ifc_db_trap_group_properties_get(swid, hw_trap_group,
                                                &trap_group_properties, &is_trap_group_configured);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get trap group properties for swid %u, HW trap group %u, return value: [%s]\n",
                   swid, hw_trap_group, sx_status_str(err));
        goto out;
    }

    truncate_params.dev_id = 1;
    truncate_params.rdq = trap_group_properties.path.local_path.rdq;
    truncate_params.truncate_enable = (trap_group_attributes_p->truncate_mode == SX_TRUNCATE_MODE_ENABLE) ? 1 : 0;
    truncate_params.truncate_size = trap_group_attributes_p->truncate_size;
    sxd_status = sxd_access_reg_truncate_size_set(&truncate_params);
    err = SXD_STATUS_TO_SX_STATUS(sxd_status);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set truncate parameters in the driver, return value: [%s].\n",
                   SXD_STATUS_MSG(sxd_status));
        goto out;
    }


out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_quantum_trap_group_set(sx_swid_id_t                swid,
                                            sx_trap_group_t             trap_group,
                                            sx_trap_group_attributes_t *trap_group_attributes_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sxd_status_t                     sxd_status = SXD_STATUS_SUCCESS;
    uint32_t                         hw_trap_group = 0;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    struct ku_set_truncate_params    truncate_params;
    host_ifc_db_profile_cfg_t        host_ifc_db_profile_cfg;

    SX_MEM_CLR(trap_group_properties);
    SX_MEM_CLR(truncate_params);
    SX_MEM_CLR(host_ifc_db_profile_cfg);

    if (trap_group_attributes_p->control_type != SX_CONTROL_TYPE_DEFAULT) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Control type %u is not supported on this chip type, return value: [%s]\n",
                   trap_group_attributes_p->control_type, sx_status_str(err));
        goto out;
    }

    if (trap_group_attributes_p->truncate_mode == SX_TRUNCATE_MODE_PROFILE_ENABLE) {
        err = host_ifc_db_profile_cfg_get(trap_group_attributes_p->trunc_profile_id, &host_ifc_db_profile_cfg);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "host_ifc_db_profile_cfg_get failed: [%s].\n",
                   SX_STATUS_MSG(err));
            goto out;
        }

        if (host_ifc_db_profile_cfg.created == FALSE) {
            SX_LOG(SX_LOG_ERROR, "Trunc profile %d is not created.\n", trap_group_attributes_p->trunc_profile_id);
            return SX_STATUS_PARAM_ERROR;
        }
    }

    err = host_ifc_sx_configure_trap_group_properties(swid, trap_group,
                                                      trap_group_attributes_p->prio,
                                                      trap_group_attributes_p->truncate_mode,
                                                      trap_group_attributes_p->truncate_size,
                                                      trap_group_attributes_p->trunc_profile_id,
                                                      trap_group_attributes_p->control_type,
                                                      trap_group_attributes_p->add_timestamp,
                                                      &hw_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to configure HW trap group properties for swid %u, trap group %u, return value: [%s]\n",
                   swid, trap_group, sx_status_str(err));
        goto out;
    }

    err = host_ifc_db_trap_group_properties_get(swid, hw_trap_group,
                                                &trap_group_properties, &is_trap_group_configured);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get trap group properties for swid %u, HW trap group %u, return value: [%s]\n",
                   swid, hw_trap_group, sx_status_str(err));
        goto out;
    }

    truncate_params.dev_id = 1;
    truncate_params.rdq = trap_group_properties.path.local_path.rdq;
    truncate_params.truncate_enable = (trap_group_attributes_p->truncate_mode == SX_TRUNCATE_MODE_ENABLE) ? 1 : 0;
    truncate_params.truncate_size = trap_group_attributes_p->truncate_size;
    sxd_status = sxd_access_reg_truncate_size_set(&truncate_params);
    err = SXD_STATUS_TO_SX_STATUS(sxd_status);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set truncate parameters in the driver, return value: [%s].\n",
                   SXD_STATUS_MSG(sxd_status));
        goto out;
    }

    /* We are not calling htgt because for IB, the HW trap groups ( 0-4) are set only during init in
     *   __host_ifc_sx_set_ib_default_traps and not for every trap group set.*/
out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_quantum_trap_group_unset(sx_swid_id_t                swid,
                                              sx_trap_group_t             trap_group,
                                              sx_trap_group_attributes_t *trap_group_attributes_p,
                                              uint32_t                   *hw_trap_group_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_hw_trap_group_e               hw_trap_group_id = SX_HW_TRAP_GROUP_MIN_E;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    sx_trap_id_t                     trap_id = SX_TRAP_ID_MIN;
    boolean_t                        is_trap_group_associated = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_group_properties);

    rc = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group mapping from the DB, [trap_group = %u], return value: [%s].\n",
                   trap_group, sx_status_str(rc));
        goto out;
    }

    if (hw_trap_group_id == SX_HW_TRAP_GROUP_DISABLE_E) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("The trap group (%u) has not been set yet.\n", trap_group);
        goto out;
    }
    *hw_trap_group_p = hw_trap_group_id;

    rc = __host_ifc_is_trap_group_associated(trap_group, &is_trap_group_associated, &trap_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("__host_ifc_is_trap_group_associated failed, [trap_group = %u], return value: [%s].\n",
                   trap_group, sx_status_str(rc));
        goto out;
    }

    if (is_trap_group_associated) {
        SX_LOG_ERR(
            "Trap ID (%u) is already associated with trap group (%u), please unset the trap ID first.\n",
            trap_id,
            trap_group);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = host_ifc_db_trap_group_properties_get(swid, hw_trap_group_id,
                                               &trap_group_properties,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap group properties for swid %u, HW trap group %u, return value: [%s]\n",
                   swid, hw_trap_group_id, sx_status_str(rc));
        goto out;
    }

    trap_group_attributes_p->truncate_mode = trap_group_properties.truncate_mode;
    trap_group_attributes_p->truncate_size = trap_group_properties.truncate_size;
    trap_group_attributes_p->trunc_profile_id = trap_group_properties.trunc_profile_id;
    trap_group_attributes_p->prio = trap_group_properties.priority;
    trap_group_attributes_p->control_type = trap_group_properties.control_type;
    trap_group_attributes_p->add_timestamp = trap_group_properties.add_timestamp;
    trap_group_attributes_p->timestamp_source = trap_group_properties.timestamp_source;

    rc = host_ifc_db_trap_group_map_set(SX_ACCESS_CMD_DELETE, swid, trap_group,
                                        hw_trap_group_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to delete HW trap group %u from user trap group %u for swid %u, return value: [%s]\n",
                   hw_trap_group_id, trap_group, swid, sx_status_str(rc));
        goto out;
    }

    /* We are not calling htgt because for IB, the HW trap groups ( 0-4) are set only during init in
     *   __host_ifc_sx_set_ib_default_traps and never being deleted.
     *    Only the mapping between SW trap group and HW trap group is changing.*/
    goto out;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t host_ifc_sx_init_prio_group(sx_api_pci_profile_t *pci_profile)
{
    sxd_host_interface_path_t        host_path_arr[SX_HW_TRAP_GROUP_MAX_E + 1];
    sx_swid_t                        swid_arr[SX_SWID_ID_COUNT + 1];
    sx_swid_t                        swid;
    int                              i = 0, rdq_max_idx;
    sx_hw_trap_group_e               trap_group;
    host_ifc_trap_group_properties_t trap_group_properties;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(trap_group_properties);

    if (SX_CHECK_FAIL(utils_check_pointer(pci_profile, "pci_profile"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CPY(__pci_profile_s, *pci_profile);

    /* config all SWID ID and SX_SWID_ID_STACKING trap groups */
    for (swid = SX_SWID_ID_MIN; swid <= SX_SWID_ID_MAX; swid++) {
        swid_arr[swid] = swid;
    }

    swid_arr[swid] = SX_SWID_ID_STACKING;

    for (i = 0; i < (SX_SWID_ID_COUNT + 1); i++) {
        int rdqs_swid;

        SX_MEM_CLR_ARRAY(host_path_arr, SX_HW_TRAP_GROUP_MAX_E + 1, sxd_host_interface_path_t);

        /* the STACKING swid should use same configurations as swid 0 */
        rdqs_swid = (swid_arr[i] == SX_SWID_ID_STACKING) ? 0 : swid_arr[i];
        /* If this swid doesn't have RDQs we can skip it */
        if ((pci_profile->rdq_count[rdqs_swid] == 0) ||
            (pci_profile->swid_type[rdqs_swid] == SX_KU_L2_TYPE_DONT_CARE)) {
            continue;
        }

        rdq_max_idx = pci_profile->rdq_count[rdqs_swid] - 1;
        host_path_arr[SX_HW_TRAP_GROUP_0_E].local_path.rdq = pci_profile->rdq[rdqs_swid][MIN(0, rdq_max_idx)];
        host_path_arr[SX_HW_TRAP_GROUP_0_E].local_path.cpu_tclass = SX_CPU_TCLASS_TRAP_GROUP_0;
        host_path_arr[SX_HW_TRAP_GROUP_1_E].local_path.rdq = pci_profile->rdq[rdqs_swid][MIN(1, rdq_max_idx)];
        host_path_arr[SX_HW_TRAP_GROUP_1_E].local_path.cpu_tclass = SX_CPU_TCLASS_TRAP_GROUP_1;
        host_path_arr[SX_HW_TRAP_GROUP_2_E].local_path.rdq = pci_profile->rdq[rdqs_swid][MIN(2, rdq_max_idx)];
        host_path_arr[SX_HW_TRAP_GROUP_2_E].local_path.cpu_tclass = SX_CPU_TCLASS_TRAP_GROUP_2;
        host_path_arr[SX_HW_TRAP_GROUP_3_E].local_path.rdq = pci_profile->rdq[rdqs_swid][MIN(3, rdq_max_idx)];
        host_path_arr[SX_HW_TRAP_GROUP_3_E].local_path.cpu_tclass = SX_CPU_TCLASS_TRAP_GROUP_3;
        host_path_arr[SX_HW_TRAP_GROUP_4_E].local_path.rdq = pci_profile->rdq[rdqs_swid][MIN(4, rdq_max_idx)];
        /* For separation between cpu_tclass of critical group for different swids (0-7) */
        host_path_arr[SX_HW_TRAP_GROUP_4_E].local_path.cpu_tclass = rdqs_swid;

        if ((pci_profile->swid_type[rdqs_swid] == SX_KU_L2_TYPE_ETH) ||
            (pci_profile->swid_type[rdqs_swid] == SX_KU_L2_TYPE_ROUTER_PORT)) {
            host_path_arr[SX_HW_TRAP_GROUP_4_E].local_path.rdq = pci_profile->emad_rdq;
        }

        for (trap_group = SX_HW_TRAP_GROUP_MIN_E; trap_group <= SX_HW_TRAP_GROUP_MAX_E; trap_group++) {
            /* add trap group properties to DB */
            trap_group_properties.swid = swid_arr[i];
            trap_group_properties.group = trap_group;
            trap_group_properties.type = SXD_HOST_IF_PATH_TYPE_LOCAL_E;
            trap_group_properties.path = host_path_arr[trap_group];
            trap_group_properties.policer_id_enabled = FALSE;
            trap_group_properties.policer_id = 0;
            trap_group_properties.add_timestamp = FALSE;
            trap_group_properties.timestamp_source = SX_PACKET_TIMESTAMP_SOURCE_LINUX_E;

            err = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET, swid_arr[i],
                                                        trap_group, &trap_group_properties);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed in host_ifc_db_trap_group_properties_set, [trap_group_id = %u], "
                           "return value: [%s].\n", trap_group, sx_status_str(err));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_spectrum_init_prio_group(sx_api_pci_profile_t *pci_profile)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(utils_check_pointer(pci_profile, "pci_profile"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CPY(__pci_profile_s, *pci_profile);

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_spectrum_validate_pci_profile(sx_api_pci_profile_t *pci_profile)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    uint32_t                        i = 0;
    struct rdq_properties           rdq_prop_array[SX_TRAP_PRIORITY_MAX - SX_TRAP_PRIORITY_MIN + 1];
    boolean_t                       rdq_exists[SX_TRAP_PRIORITY_MAX - SX_TRAP_PRIORITY_MIN + 1];
    uint32_t                        rdqs[SX_TRAP_PRIORITY_MAX - SX_TRAP_PRIORITY_MIN + 1];
    sx_trap_priority_t              priority;
    uint32_t                        index = 0;
    uint8_t                         rdq_count = 0;
    host_ifc_internal_trap_groups_t internal_trap_groups;

    if (SX_CHECK_FAIL(utils_check_pointer(pci_profile, "pci_profile"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(internal_trap_groups);

    /* update normalized pci profile from driver */
    err = __pci_profile_get(pci_profile);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get pci profile from the driver , return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    /*
     * The last two RDQs on spectrum are reserved. We need to check whether
     * the priority in each rdq is valid or not. And, the rdqs with the same
     * priority should have the same number of entries.
     */
    SX_MEM_CLR_ARRAY(rdq_prop_array, SX_TRAP_PRIORITY_MAX - SX_TRAP_PRIORITY_MIN + 1, struct rdq_properties);
    SX_MEM_CLR_ARRAY(rdqs, SX_TRAP_PRIORITY_MAX - SX_TRAP_PRIORITY_MIN + 1, uint32_t);
    for (i = 0; i < (SX_TRAP_PRIORITY_MAX - SX_TRAP_PRIORITY_MIN + 1); i++) {
        rdq_exists[i] = FALSE;
    }

    err = host_ifc_internal_trap_groups_from_profile_get(pci_profile, &internal_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get internal trap groups, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    rdq_count = (pci_profile->rdq_count[0] == 0) ? 0 : pci_profile->rdq_count[0] - 1;
    for (i = 0; i < rdq_count; i++) {
        priority = pci_profile->rdq_properties[i].priority;
        if (!SX_TRAP_PRIORITY_CHECK_RANGE(priority)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("The priority %d of RDQ %u is out of range[%u - %u]\n",
                       priority, i, SX_TRAP_PRIORITY_MIN, SX_TRAP_PRIORITY_MAX);
            goto out;
        }

        /* skip the check for emad rdq, because now can occur in
         *  between the normal RDQ with the addition of What just happened feature in SPC. we also
         *  need to avoid checking for accuflow and mocs trap groups.
         */
        if ((i == pci_profile->emad_rdq) || (i == internal_trap_groups.accuflow_trap_group)
            || (i == internal_trap_groups.mocs_trap_group)) {
            continue;
        }

        index = priority - SX_TRAP_PRIORITY_MIN;
        if (rdq_exists[index]) {
            if (rdq_prop_array[index].number_of_entries != pci_profile->rdq_properties[i].number_of_entries) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("RDQ %u and RDQ %u have the same priority but the different number of entries\n",
                           i, rdqs[index]);
                goto out;
            }
        } else {
            SX_MEM_CPY(rdq_prop_array[index], pci_profile->rdq_properties[i]);
            rdq_exists[index] = TRUE;
            rdqs[index] = i;
        }
    }

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_sx_default_traps_set(sx_api_pci_profile_t *pci_profile)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_swid_t   swid = 0;

    if (SX_CHECK_FAIL(utils_check_pointer(pci_profile, "pci_profile"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __host_ifc_sx_hw_trap_group_set(SX_SWID_ID_STACKING, SX_CONTROL_SX_TRAP_GROUP,
                                          SX_TRAP_PRIORITY_CRITICAL, SX_TRUNCATE_MODE_DISABLE, 0,
                                          SX_CONTROL_TYPE_DEFAULT);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HW trap group %u on SWID %u, return value: [%s]\n",
                   SX_CONTROL_SX_TRAP_GROUP, SX_SWID_ID_STACKING,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_id_set_to_hw_trap_group(SX_SWID_ID_STACKING,
                                                  SX_TRAP_ID_PUDE, SX_CONTROL_SX_TRAP_GROUP,
                                                  SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SX_TRAP_ID_PUDE, SX_CONTROL_SX_TRAP_GROUP,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_id_set_to_hw_trap_group(SX_SWID_ID_STACKING,
                                                  SX_TRAP_ID_PMPE, SX_CONTROL_SX_TRAP_GROUP,
                                                  SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SX_TRAP_ID_PMPE, SX_CONTROL_SX_TRAP_GROUP,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_id_set_to_hw_trap_group(SX_SWID_ID_STACKING,
                                                  (sx_trap_id_t)SXD_TRAP_ID_MFDE, SX_CONTROL_SX_TRAP_GROUP,
                                                  SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SXD_TRAP_ID_MFDE, SX_CONTROL_SX_TRAP_GROUP,
                   sx_status_str(err));
        goto out;
    }

    for (swid = 0; swid < RM_NUM_OF_SWIDS; swid++) {
        switch (pci_profile->swid_type[swid]) {
        case SX_KU_L2_TYPE_ETH:
            err = __host_ifc_sx_set_eth_default_traps(swid);
            if (SX_CHECK_FAIL(err)) {
                goto out;
            }

            break;

        case SX_KU_L2_TYPE_IB:
            err = __host_ifc_sx_set_ib_default_traps(swid);
            if (SX_CHECK_FAIL(err)) {
                goto out;
            }

            break;

        case SX_KU_L2_TYPE_ROUTER_PORT:
            /* Continue to listener registration.
             *  There no need for EMAD registration because this
             *  is still done in ETH swid for ALL swids */
            break;

        default:
            continue; /* skip PUDE. go to the next swid */
        }
    }

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_default_actions_set(boolean_t     is_unset,
                                                  sx_trap_id_t* trap_id_to_unset_p,
                                                  boolean_t   * is_db_updated_p)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_trap_id_t                  trap_id;
    sx_trap_id_t                  trap_id_start = SX_TRAP_ID_MIN, trap_id_end = SX_TRAP_ID_MAX;
    sx_trap_action_t              trap_action;
    host_ifc_trap_id_properties_t trap_id_properties;
    boolean_t                     has_default_action = TRUE;
    sx_hw_trap_group_e            hw_trap_group = SX_HW_TRAP_GROUP_DISABLE_E;
    sx_boot_mode_e                issu_boot_mode;
    boolean_t                     is_associated = FALSE;
    boolean_t                     is_in_use = FALSE;


    /* 1. In SDK init we want to initialize all the traps
     * 2. When we unset the trap we want to call HPKT only with the specific trap
     */
    if (is_unset) {
        trap_id_start = *trap_id_to_unset_p;
        trap_id_end = *trap_id_to_unset_p;
    } else {
        trap_id_start = SX_TRAP_ID_MIN;
        trap_id_end = SX_TRAP_ID_MAX;
    }
    if (is_db_updated_p != NULL) {
        *is_db_updated_p = FALSE;
    }

    sx_status = issu_boot_mode_get(&issu_boot_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to issu_boot_mode_get err = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }


    for (trap_id = trap_id_start; trap_id <= trap_id_end; trap_id++) {
        if (issu_boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
            if (trap_id_is_exclude_trap_issu_started(trap_id)) {
                continue;
            }
        }
        sx_status = trap_id_defaults_get(trap_id,
                                         &has_default_action,
                                         &hw_trap_group,
                                         &trap_action);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to trap_id_defaults_get err = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }


        /* This condition indicates that the setup does not support this trap or
         * this is invalid trap*/
        if ((has_default_action == FALSE) && (trap_action == SX_TRAP_ACTION_IGNORE)) {
            continue;
        }
        /* We will configure HPKT in 1 of the 3 conditions:
         * 1. As part of SDK init if trap_action != SX_TRAP_ACTION_SET_FW_DEFAULT
         * 2. We want to configure FWD_DISCARD_ERROR as part of the SDK init
         * 3. Any time we do UNSET
         */
        if (((is_unset == FALSE) && (trap_action != SX_TRAP_ACTION_SET_FW_DEFAULT)) ||
            ((has_default_action == TRUE) && (trap_action == SX_TRAP_ACTION_SET_FW_DEFAULT)) ||
            (is_unset == TRUE)) {
            sx_status = host_ifc_db_trap_id_properties_get(trap_id, &trap_id_properties);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG(SX_LOG_ERROR, "Failed to get trap ID %d properties, return value: [%s].\n",
                       trap_id, sx_status_str(sx_status));
                goto out;
            }

            if (issu_boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
                if (!is_unset) {
                    trap_id_properties.hw_trap_group = SX_HW_TRAP_GROUP_DISABLE_E;
                } else {
                    trap_id_properties.hw_trap_group = 0;
                }
                trap_id_properties.control_type = SX_CONTROL_TYPE_DEFAULT;
            } else {
                if (trap_id_properties.hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
                    continue;
                }
                is_associated = TRUE;
                is_in_use = TRUE;
            }
            trap_id_properties.trap_action = trap_action;
            trap_id_properties.tr_prof = 0;
            trap_id_properties.tr_en = 0;

            sx_status = host_ifc_db_trap_id_properties_set(trap_id,
                                                           trap_id_properties,
                                                           is_associated,
                                                           is_in_use);
            if (is_db_updated_p != NULL) {
                *is_db_updated_p = TRUE;
            }
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed in host_ifc_db_trap_id_properties_set, [trap_id = %u], return value: [%s]\n",
                           trap_id, sx_status_str(sx_status));
                goto out;
            }


            if (!SX_TRAP_ID_SW_CHECK_RANGE(trap_id)) {
                if (!is_unset) {
                    trap_id_properties.hw_trap_group = 0;
                }
                sx_status = __handle_hpkt(trap_id_properties.hw_trap_id,
                                          &trap_id_properties.trap_action, &trap_id_properties.hw_trap_group,
                                          &trap_id_properties.control_type, FALSE, 0);

                if (SX_CHECK_FAIL(sx_status)) {
                    SX_LOG_ERR("%s: Failed to set HPKT register, [hw_trap_id = %u], return value: [%s]\n",
                               __FUNCTION__, trap_id_properties.hw_trap_id, sx_status_str(sx_status));
                    goto out;
                }
            }

            sx_status = host_ifc_db_trap_id_from_group_list_unset(hw_trap_group, trap_id);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to remove trap_id = %u from HW trap group %d, return value: [%s]\n",
                           trap_id, hw_trap_group, sx_status_str(sx_status));
                goto out;
            }
        }
    }

out:
    return __SX_LOG_EXIT(sx_status);
}

sx_status_t host_ifc_spectrum_default_traps_set(sx_api_pci_profile_t *pci_profile)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_swid_t                       swid = 0;
    uint32_t                        tg_idx = 0;
    uint32_t                        control_trap_group;
    host_ifc_internal_trap_groups_t internal_trap_groups;

    SX_MEM_CLR(internal_trap_groups);

    if (SX_CHECK_FAIL(utils_check_pointer(pci_profile, "pci_profile"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __host_ifc_default_actions_set(FALSE, NULL, NULL);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set default actions on SWID 0, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    control_trap_group = pci_profile->emad_rdq;
    if (pci_profile->rdq_count[0] == 0) {
        SX_LOG_ERR("%s: No RDQs defined for SWID 0 in pci profile\n", __func__);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = host_ifc_internal_trap_groups_from_profile_get(pci_profile, &internal_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get internal trap groups, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_spectrum_hw_trap_group_set(0, control_trap_group,
                                                SX_CONTROL_SPECTRUM_TRAP_PRIO, SX_TRUNCATE_MODE_DISABLE, 0,
                                                SX_CONTROL_TYPE_DEFAULT);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HW trap group %u on SWID 0, return value: [%s]\n",
                   control_trap_group, sx_status_str(err));
        goto out;
    }

    /* Configure trap IDs to control trap group */
    err = __host_ifc_trap_id_set_to_hw_trap_group(0, SX_TRAP_ID_PUDE,
                                                  control_trap_group, SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SX_TRAP_ID_PUDE, control_trap_group,
                   sx_status_str(err));
        goto out;
    }

    /* Add PMPE listener on each swid if management lib module support is enabled */
    err = __host_ifc_trap_id_set_to_hw_trap_group(0, SX_TRAP_ID_PMPE,
                                                  control_trap_group, SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SX_TRAP_ID_PMPE, control_trap_group,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_id_set_to_hw_trap_group(0, (sx_trap_id_t)SXD_TRAP_ID_MFDE,
                                                  control_trap_group, SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SXD_TRAP_ID_MFDE, control_trap_group,
                   sx_status_str(err));
        goto out;
    }


    err = __host_ifc_trap_id_set_to_hw_trap_group(0, (sx_trap_id_t)SXD_TRAP_ID_MECCC,
                                                  control_trap_group, SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SXD_TRAP_ID_MECCC, control_trap_group,
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_id_set_to_hw_trap_group(0, (sx_trap_id_t)SXD_TRAP_ID_IPAC_DONE,
                                                  control_trap_group, SX_TRAP_ACTION_TRAP_2_CPU);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                   SXD_TRAP_ID_IPAC_DONE, control_trap_group,
                   sx_status_str(err));
        goto out;
    }


    /* Configure trap group for mirroring */
    err = __host_ifc_spectrum_hw_trap_group_set(0, internal_trap_groups.mirror_trap_group,
                                                SX_SPECTRUM_MIRROR_TRAP_PRIO, SX_TRUNCATE_MODE_DISABLE, 0,
                                                SX_CONTROL_TYPE_DEFAULT);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HW trap group %u on SWID 0, return value: [%s]\n",
                   internal_trap_groups.mirror_trap_group, sx_status_str(err));
        goto out;
    }

    /* Configure trap group for mocs */
    err = __host_ifc_spectrum_hw_trap_group_set(0, internal_trap_groups.mocs_trap_group,
                                                SX_SPECTRUM_MOCS_TRAP_PRIO, SX_TRUNCATE_MODE_DISABLE, 0,
                                                SX_CONTROL_TYPE_DEFAULT);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HW trap group %u on SWID 0, return value: [%s]\n",
                   internal_trap_groups.mocs_trap_group, sx_status_str(err));
        goto out;
    }

    /* Configure trap groups for use by SPAN session */
    for (tg_idx = 0; tg_idx < SPECTRUM_SPAN_TRAP_GROUPS_NUM; tg_idx++) {
        err = __host_ifc_spectrum_hw_trap_group_set_null(0, SPECTRUM_SPAN_TRAP_GROUPS_START + tg_idx,
                                                         SX_SPECTRUM_MIRROR_TRAP_PRIO,
                                                         SX_CONTROL_TYPE_DEFAULT);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set HW trap group %u on SWID 0, return value: [%s]\n",
                       SPECTRUM_SPAN_TRAP_GROUPS_START + tg_idx, sx_status_str(err));
            goto out;
        }
    }

    for (swid = 0; swid < RM_NUM_OF_SWIDS; swid++) {
        switch (pci_profile->swid_type[swid]) {
        case SX_KU_L2_TYPE_ETH:
            err = __host_ifc_spectrum_set_eth_default_traps(swid,
                                                            control_trap_group,
                                                            internal_trap_groups.mirror_trap_group,
                                                            internal_trap_groups.mocs_trap_group);
            if (SX_CHECK_FAIL(err)) {
                goto out;
            }
            break;

        case SX_KU_L2_TYPE_IB:
            break;

        case SX_KU_L2_TYPE_ROUTER_PORT:
            /* Continue to listener registration.
             *  There no need for EMAD registration because this
             *  is still done in ETH swid for ALL swids */
            break;

        default:
            continue;     /* skip PUDE. go to the next swid */
        }
    }

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_default_traps_set_spectrum2(sx_api_pci_profile_t *pci_profile_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_swid_t                       swid = 0;
    uint32_t                        accumulated_type_max_number = 0;
    host_ifc_internal_trap_groups_t internal_trap_groups;

    SX_LOG_ENTER();

    SX_MEM_CLR(internal_trap_groups);

    /* Set Spectrum default trap groups and IDs */
    err = host_ifc_spectrum_default_traps_set(pci_profile_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set legacy default traps, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    err = host_ifc_internal_trap_groups_from_profile_get(pci_profile_p, &internal_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get internal trap groups, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    for (swid = 0; swid < RM_NUM_OF_SWIDS; swid++) {
        switch (pci_profile_p->swid_type[swid]) {
        case SX_KU_L2_TYPE_ETH:
            err = __host_ifc_trap_id_set_to_hw_trap_group(swid,
                                                          (sx_trap_id_t)SXD_TRAP_ID_CEER,
                                                          internal_trap_groups.mocs_trap_group,
                                                          SX_TRAP_ACTION_TRAP_2_CPU);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                           SXD_TRAP_ID_CEER, internal_trap_groups.mocs_trap_group,
                           sx_status_str(err));
                goto out;
            }
            err = __host_ifc_trap_id_set_to_hw_trap_group(swid,
                                                          (sx_trap_id_t)SXD_TRAP_ID_MOFRB,
                                                          internal_trap_groups.mocs_trap_group,
                                                          SX_TRAP_ACTION_TRAP_2_CPU);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                           SXD_TRAP_ID_MOFRB, internal_trap_groups.mocs_trap_group, sx_status_str(err));
                goto out;
            }
            break;

        default:
            continue; /* Go to the next swid */
        }
    }

    err = flow_counter_accumulated_num_get(&accumulated_type_max_number);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to check if Accumulated trap should be configured (err=%s)\n", sx_status_str(err));
        goto out;
    }

    if (accumulated_type_max_number > 0) {
        /* Configure trap group for accumulated */
        err = __host_ifc_spectrum_hw_trap_group_set(0, internal_trap_groups.accuflow_trap_group,
                                                    SX_SPECTRUM_ACCUFLOW_TRAP_PRIO, SX_TRUNCATE_MODE_DISABLE, 0,
                                                    SX_CONTROL_TYPE_DEFAULT);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set Accumulated HW trap group %u, return value: [%s]\n",
                       internal_trap_groups.accuflow_trap_group, sx_status_str(err));
            goto out;
        }

        err = __host_ifc_trap_id_set_to_hw_trap_group(0, (sx_trap_id_t)SXD_TRAP_ID_ACCU_FLOW_INC,
                                                      internal_trap_groups.accuflow_trap_group,
                                                      SX_TRAP_ACTION_TRAP_2_CPU);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                       SXD_TRAP_ID_ACCU_FLOW_INC, internal_trap_groups.accuflow_trap_group,
                       sx_status_str(err));
            goto out;
        }

        err = __host_ifc_trap_id_set_to_hw_trap_group(0, (sx_trap_id_t)SXD_TRAP_ID_MAFBI,
                                                      internal_trap_groups.accuflow_trap_group,
                                                      SX_TRAP_ACTION_TRAP_2_CPU);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                       SXD_TRAP_ID_MAFBI, internal_trap_groups.accuflow_trap_group,
                       sx_status_str(err));
            goto out;
        }

        err = __host_ifc_trap_id_set_to_hw_trap_group(0, (sx_trap_id_t)SXD_TRAP_ID_MAFRI,
                                                      internal_trap_groups.accuflow_trap_group,
                                                      SX_TRAP_ACTION_TRAP_2_CPU);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                       SXD_TRAP_ID_MAFRI, internal_trap_groups.accuflow_trap_group,
                       sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_independent_module_default_traps_set(sx_api_pci_profile_t *pci_profile_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_swid_t   swid = 0;
    uint32_t    control_trap_group = pci_profile_p->emad_rdq;
    boolean_t   is_independent_module_enabled = FALSE;

    err = sx_mgmt_lib_independent_module_get(&is_independent_module_enabled);
    if (is_independent_module_enabled == TRUE) {
        err = __host_ifc_trap_id_set_to_hw_trap_group(swid, (sx_trap_id_t)SXD_TRAP_ID_MCION,
                                                      control_trap_group, SX_TRAP_ACTION_TRAP_2_CPU);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                       SXD_TRAP_ID_MCION, control_trap_group,
                       sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_default_traps_set_spectrum3(sx_api_pci_profile_t *pci_profile_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Set Spectrum2 default trap groups and IDs */
    err = host_ifc_default_traps_set_spectrum2(pci_profile_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set legacy default traps, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    /* Set independent module trap ID if applicable */
    err = __host_ifc_independent_module_default_traps_set(pci_profile_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set independent module default traps, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_default_traps_set_spectrum4(sx_api_pci_profile_t *pci_profile_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_swid_t                       swid = 0;
    uint32_t                        control_trap_group = 0;
    host_ifc_internal_trap_groups_t internal_trap_groups;

    SX_LOG_ENTER();

    SX_MEM_CLR(internal_trap_groups);
    /* Set Spectrum3 default trap groups and IDs */
    err = host_ifc_default_traps_set_spectrum3(pci_profile_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set legacy default traps, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    err = host_ifc_internal_trap_groups_from_profile_get(pci_profile_p, &internal_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get internal trap groups, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    /* Set Spectrum4 default trap IDs */
    control_trap_group = pci_profile_p->emad_rdq;

    for (swid = 0; swid < RM_NUM_OF_SWIDS; swid++) {
        switch (pci_profile_p->swid_type[swid]) {
        case SX_KU_L2_TYPE_ETH:
            err = __host_ifc_trap_id_set_to_hw_trap_group(swid, (sx_trap_id_t)SXD_TRAP_ID_FSHE,
                                                          control_trap_group, SX_TRAP_ACTION_TRAP_2_CPU);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                           SXD_TRAP_ID_FSHE, control_trap_group,
                           sx_status_str(err));
                goto out;
            }

            err = __host_ifc_trap_id_set_to_hw_trap_group(swid,
                                                          (sx_trap_id_t)SXD_TRAP_ID_FSED,
                                                          internal_trap_groups.mocs_trap_group,
                                                          SX_TRAP_ACTION_TRAP_2_CPU);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                           SXD_TRAP_ID_FSED, internal_trap_groups.mocs_trap_group,
                           sx_status_str(err));
                goto out;
            }

            err = __host_ifc_trap_id_set_to_hw_trap_group(swid,
                                                          (sx_trap_id_t)SXD_TRAP_ID_UPCNT,
                                                          internal_trap_groups.mocs_trap_group,
                                                          SX_TRAP_ACTION_TRAP_2_CPU);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                           SXD_TRAP_ID_UPCNT, internal_trap_groups.mocs_trap_group,
                           sx_status_str(err));
                goto out;
            }

            err = __host_ifc_trap_id_set_to_hw_trap_group(swid,
                                                          (sx_trap_id_t)SXD_TRAP_ID_UTCC,
                                                          internal_trap_groups.mocs_trap_group,
                                                          SX_TRAP_ACTION_TRAP_2_CPU);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                           SXD_TRAP_ID_UTCC, internal_trap_groups.mocs_trap_group,
                           sx_status_str(err));
                goto out;
            }
            err = __host_ifc_trap_id_set_to_hw_trap_group(swid,
                                                          (sx_trap_id_t)SXD_TRAP_ID_USACN,
                                                          internal_trap_groups.mocs_trap_group,
                                                          SX_TRAP_ACTION_TRAP_2_CPU);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                           SXD_TRAP_ID_USACN, internal_trap_groups.mocs_trap_group,
                           sx_status_str(err));
                goto out;
            }


            err = __host_ifc_trap_id_set_to_hw_trap_group(swid, (sx_trap_id_t)SXD_TRAP_ID_MOFTD,
                                                          internal_trap_groups.mocs_trap_group,
                                                          SX_TRAP_ACTION_TRAP_2_CPU);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set trap ID %d to internal trap group %u, return value: [%s]\n",
                           SXD_TRAP_ID_MOFTD, internal_trap_groups.mocs_trap_group,
                           sx_status_str(err));
                goto out;
            }
            break;

        default:
            continue;       /* Go to the next swid */
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

/* On Spectrum5, default trap IDs set is reduced */
sx_status_t host_ifc_default_traps_set_spectrum5(sx_api_pci_profile_t *pci_profile_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_swid_t                       swid = 0;
    uint32_t                        control_trap_group = pci_profile_p->emad_rdq;
    uint32_t                        i = 0;
    host_ifc_internal_trap_groups_t internal_trap_groups;
    uint32_t                        mocs_trap_ids[] = {
        SXD_TRAP_ID_MOFRB,
        SXD_TRAP_ID_FSED,
        SXD_TRAP_ID_MOFTD
    };

    SX_LOG_ENTER();

    SX_MEM_CLR(internal_trap_groups);

    /* Set Spectrum default trap groups and IDs */
    err = host_ifc_spectrum_default_traps_set(pci_profile_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set legacy default traps, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    err = host_ifc_internal_trap_groups_from_profile_get(pci_profile_p, &internal_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get internal trap groups, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    /* Set independent module trap ID if applicable */
    err = __host_ifc_independent_module_default_traps_set(pci_profile_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set independent module default traps, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    for (swid = 0; swid < RM_NUM_OF_SWIDS; swid++) {
        switch (pci_profile_p->swid_type[swid]) {
        case SX_KU_L2_TYPE_ETH:
            err = __host_ifc_trap_id_set_to_hw_trap_group(swid, (sx_trap_id_t)SXD_TRAP_ID_FSHE,
                                                          control_trap_group, SX_TRAP_ACTION_TRAP_2_CPU);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                           SXD_TRAP_ID_FSHE, control_trap_group,
                           sx_status_str(err));
                goto out;
            }

            for (i = 0; i < (sizeof(mocs_trap_ids) / sizeof(mocs_trap_ids[0])); i++) {
                err = __host_ifc_trap_id_set_to_hw_trap_group(swid, mocs_trap_ids[i],
                                                              internal_trap_groups.mocs_trap_group,
                                                              SX_TRAP_ACTION_TRAP_2_CPU);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to set trap ID %d to trap group %u, return value: [%s]\n",
                               mocs_trap_ids[i], internal_trap_groups.mocs_trap_group, sx_status_str(err));
                    goto out;
                }
            }
            break;

        default:
            continue;       /* Go to the next swid */
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_critical_traps_set(sx_api_pci_profile_t *pci_profile)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.host_ifc_default_traps_set_cb) {
        err = brg_context.spec_cb_g.host_ifc_default_traps_set_cb(pci_profile);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
    }

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_device_add_hw_trap_groups(sx_device_id_t device_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    num_trap_groups = 0;

    err = host_ifc_hw_trap_group_num_get(&num_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get number of HW trap groups, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_device_add_hw_trap_groups_logic(device_id, num_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to add HW trap groups, [device_id = %u, num_trap_groups = %u], return value: [%s]\n",
                   device_id, num_trap_groups, sx_status_str(err));
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_device_add_hw_trap_groups_logic(sx_device_id_t device_id, uint32_t num_trap_groups)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_swid_t                        swid = 0;
    sx_swid_t                       *swid_arr = cl_malloc((RM_NUM_OF_SWIDS + 1) * sizeof(sx_swid_t)); /* +1 for stacking SWID */
    uint8_t                          i = 0;
    uint32_t                         trap_group = 0;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_configured = FALSE;

    SX_MEM_CLR(trap_group_properties);

    if (!swid_arr) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for SWID array\n");
        goto out;
    }

    /* config all SWID ID and SX_SWID_ID_STACKING trap groups */
    for (swid = 0; swid <= rm_resource_global.swid_id_max; ++swid) {
        swid_arr[swid] = swid;
    }

    swid_arr[swid] = SX_SWID_ID_STACKING;

    for (i = 0; i < (RM_NUM_OF_SWIDS + 1); ++i) {
        swid = swid_arr[i];

        for (trap_group = 0; trap_group < num_trap_groups; ++trap_group) {
            err = host_ifc_db_trap_group_properties_get(swid,
                                                        trap_group,
                                                        &trap_group_properties,
                                                        &is_configured);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("can't retrieve swid %d trap_group %d properties, rc = %s\n",
                           swid, trap_group, sx_status_str(err));
                goto out;
            }

            if (is_configured) {
                err = host_ifc_handle_htgt(device_id,
                                           trap_group_properties.swid,
                                           trap_group,
                                           &trap_group_properties.type,
                                           &trap_group_properties.path,
                                           &trap_group_properties.policer_id_enabled,
                                           &trap_group_properties.policer_id,
                                           &trap_group_properties.priority,
                                           &trap_group_properties.mirror_action,
                                           &trap_group_properties.mirror_agent,
                                           &trap_group_properties.mirror_probability_rate);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to set HTGT register, swid = [%u], trap_group = [%u]."
                               "return value: [%s]\n", swid, trap_group, sx_status_str(err));
                    goto out;
                }
            }
        }
    }

out:
    if (swid_arr) {
        cl_free(swid_arr);
    }
    return __SX_LOG_EXIT(err);
}

/*
 * This function sets a trap ID directly to a HW trap group, without going
 * through the user trap group and without needing the HW trap group to be
 * associated with a user trap group. This is useful for setting control traps
 * to control trap groups, such as EMADs.
 *
 * @param[in]  swid	     - The swid to configure
 * @param[in] trap_id	 - trap ID to configure
 * @param[in] hw_trap_group	- HW trap group
 * @param[in]  trap_action - action to be configured to trap
 *
 * @return sx_status_t
 */
static sx_status_t __host_ifc_trap_id_set_to_hw_trap_group(sx_swid_t        swid,
                                                           sx_trap_id_t     trap_id,
                                                           uint32_t         hw_trap_group,
                                                           sx_trap_action_t trap_action)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    host_ifc_trap_id_properties_t    trap_id_properties;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_configured = FALSE;

    SX_MEM_CLR(trap_id_properties);
    SX_MEM_CLR(trap_group_properties);

    err = host_ifc_db_trap_id_properties_get(trap_id, &trap_id_properties);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to get trap ID %d properties, return value: [%s].\n",
               trap_id, sx_status_str(err));
        goto out;
    }

    /* Get trap priority DB parameters */
    err = host_ifc_db_trap_group_properties_get(swid,
                                                hw_trap_group,
                                                &trap_group_properties,
                                                &is_configured);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to fetch trap group properties from DB for SWID %u HW trap group %u, return value: [%s].\n",
                   swid, hw_trap_group, sx_status_str(err));
        goto out;
    }

    /* add trap id properties to DB */
    trap_id_properties.trap_action = trap_action;
    trap_id_properties.hw_trap_group = hw_trap_group;
    err = host_ifc_db_trap_id_properties_set(trap_id,
                                             trap_id_properties,
                                             TRUE,
                                             TRUE);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in host_ifc_db_trap_id_properties_set, [trap_id = %u], return value: [%s]\n",
                   trap_id, sx_status_str(err));
        goto out;
    }

    err = __handle_hpkt(trap_id_properties.hw_trap_id,
                        &(trap_id_properties.trap_action),
                        &(trap_id_properties.hw_trap_group),
                        &(trap_group_properties.control_type),
                        (trap_group_properties.truncate_mode == SX_TRUNCATE_MODE_PROFILE_ENABLE),
                        trap_group_properties.trunc_profile_id);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("%s: Failed to set HPKT register, [hw_trap_id = %u], return value: [%s]\n",
                   __FUNCTION__, trap_id_properties.hw_trap_id, sx_status_str(err));
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_hw_trap_group_set_logic(sx_swid_t          swid,
                                                      uint32_t           hw_trap_group,
                                                      sx_trap_priority_t trap_priority,
                                                      sx_truncate_mode_t truncate_mode,
                                                      sx_truncate_size_t truncate_size,
                                                      sx_control_type_t  control_type,
                                                      uint8_t            rdq,
                                                      uint8_t            cpu_tclass)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sxd_status_t                     sxd_status = SXD_STATUS_SUCCESS;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_configured = FALSE;
    struct ku_set_truncate_params    truncate_params;

    SX_MEM_CLR(trap_group_properties);
    SX_MEM_CLR(truncate_params);

    err = host_ifc_db_trap_group_properties_get(swid, hw_trap_group,
                                                &trap_group_properties, &is_configured);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    /* Fill in attributes for HW trap group */
    trap_group_properties.control_type = control_type;
    trap_group_properties.group = hw_trap_group;
    trap_group_properties.path.local_path.rdq = rdq;
    trap_group_properties.path.local_path.cpu_tclass = cpu_tclass;
    trap_group_properties.priority = trap_priority;
    trap_group_properties.swid = swid;
    trap_group_properties.truncate_mode = truncate_mode;
    trap_group_properties.truncate_size = truncate_size;
    trap_group_properties.type = SXD_HOST_IF_PATH_TYPE_LOCAL_E;

    truncate_params.dev_id = 1;
    truncate_params.rdq = trap_group_properties.path.local_path.rdq;
    truncate_params.truncate_enable = (truncate_mode == SX_TRUNCATE_MODE_ENABLE) ? 1 : 0;
    truncate_params.truncate_size = truncate_size;
    sxd_status = sxd_access_reg_truncate_size_set(&truncate_params);
    err = SXD_STATUS_TO_SX_STATUS(sxd_status);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set truncate parameters in the driver, return value: [%s].\n",
                   SXD_STATUS_MSG(sxd_status));
        goto out;
    }

    /* Set control trap group in HTGT, with above properties */
    err = host_ifc_handle_htgt(0, trap_group_properties.swid,
                               hw_trap_group, &trap_group_properties.type,
                               &trap_group_properties.path, &trap_group_properties.policer_id_enabled,
                               &trap_group_properties.policer_id, &trap_group_properties.priority,
                               &trap_group_properties.mirror_action, &trap_group_properties.mirror_agent,
                               &trap_group_properties.mirror_probability_rate);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap group %u in HTGT, return value: [%s]\n",
                   hw_trap_group, sx_status_str(err));
        goto out;
    }

    /* Update DB if write to register succeeded */
    err = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET,
                                                swid, hw_trap_group, &trap_group_properties);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_hw_trap_group_set_logic_null(sx_swid_t          swid,
                                                           uint32_t           hw_trap_group,
                                                           sx_trap_priority_t trap_priority,
                                                           sx_control_type_t  control_type)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_configured = FALSE;

    SX_MEM_CLR(trap_group_properties);

    err = host_ifc_db_trap_group_properties_get(swid, hw_trap_group,
                                                &trap_group_properties, &is_configured);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    /* Fill in attributes for HW trap group */
    trap_group_properties.control_type = control_type;
    trap_group_properties.group = hw_trap_group;
    trap_group_properties.priority = trap_priority;
    trap_group_properties.swid = swid;
    trap_group_properties.truncate_mode = SX_TRUNCATE_MODE_DISABLE;
    trap_group_properties.truncate_size = 0;
    trap_group_properties.type = SXD_HOST_IF_PATH_TYPE_NULL_E;

    /* Set control trap group in HTGT, with above properties */
    err = host_ifc_handle_htgt(0, trap_group_properties.swid,
                               hw_trap_group, &trap_group_properties.type, NULL,
                               &trap_group_properties.policer_id_enabled, &trap_group_properties.policer_id,
                               &trap_group_properties.priority,
                               &trap_group_properties.mirror_action, &trap_group_properties.mirror_agent,
                               &trap_group_properties.mirror_probability_rate);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set trap group %u in HTGT, return value: [%s]\n",
                   hw_trap_group, sx_status_str(err));
        goto out;
    }

    /* Update DB if write to register succeeded */
    err = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET,
                                                swid, hw_trap_group, &trap_group_properties);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

/*
 * This function sets only the HW trap group in the local DB and in the relevant
 * registers. It does not require the HW trap group to be mapped to a user trap
 * group. This is relevant for control trap groups which are not exposed to the
 * user, such as the EMAD trap group.
 * Note: This function should only be called on SPECTRUM devices.
 *
 * @param[in]  swid	     - The swid to configure
 * @param[in] hw_trap_group	- HW trap group
 * @param[in]  trap_priority - Trap priority assigned for trap id
 * @param[in]  truncate_mode - Truncate mode
 * @param[in]  truncate_size - Truncate size
 * @param[in] control_type  - Control type of trap group
 *
 * @return sx_status_t
 */
static sx_status_t __host_ifc_spectrum_hw_trap_group_set(sx_swid_t          swid,
                                                         uint32_t           hw_trap_group,
                                                         sx_trap_priority_t trap_priority,
                                                         sx_truncate_mode_t truncate_mode,
                                                         sx_truncate_size_t truncate_size,
                                                         sx_control_type_t  control_type)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint8_t     cpu_tclass;

    /* __trap_prio_2_cpu_tc get is_monitor param FALSE because
     * this flow is relevant for control trap groups only */
    cpu_tclass = __trap_prio_2_cpu_tc(FALSE, trap_priority);

    err = __host_ifc_hw_trap_group_set_logic(swid, hw_trap_group, trap_priority,
                                             truncate_mode, truncate_size, control_type, hw_trap_group,
                                             cpu_tclass);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HW trap group %u, return value: [%s]\n",
                   hw_trap_group, sx_status_str(err));
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_spectrum_hw_trap_group_set_null(sx_swid_t          swid,
                                                              uint32_t           hw_trap_group,
                                                              sx_trap_priority_t trap_priority,
                                                              sx_control_type_t  control_type)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = __host_ifc_hw_trap_group_set_logic_null(swid, hw_trap_group, trap_priority, control_type);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HW trap group %u, return value: [%s]\n",
                   hw_trap_group, sx_status_str(err));
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

/*
 * This function sets only the HW trap group in the local DB and in the relevant
 * registers. It does not require the HW trap group to be mapped to a user trap
 * group. This is relevant for control trap groups which are not exposed to the
 * user, such as the EMAD trap group.
 * Note: This function should only be called on SwitchX and SwitchX-2 devices.
 *
 * @param[in]  swid	     - The swid to configure
 * @param[in] hw_trap_group	- HW trap group
 * @param[in]  trap_priority - Trap priority assigned for trap id
 * @param[in]  truncate_mode - Truncate mode
 * @param[in]  truncate_size - Truncate size
 * @param[in] control_type  - Control type of trap group
 *
 * @return sx_status_t
 */
static sx_status_t __host_ifc_sx_hw_trap_group_set(sx_swid_t          swid,
                                                   uint32_t           hw_trap_group,
                                                   sx_trap_priority_t trap_priority,
                                                   sx_truncate_mode_t truncate_mode,
                                                   sx_truncate_size_t truncate_size,
                                                   sx_control_type_t  control_type)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_swid_t   rdqs_swid = (swid == SX_SWID_ID_STACKING) ? 0 : swid;
    uint8_t     rdq = 0;
    uint8_t     cpu_tclass = 0;
    uint8_t     rdq_max_idx = 0;

    rdq_max_idx = __pci_profile_s.rdq_count[rdqs_swid] - 1;
    switch (hw_trap_group) {
    case SX_HW_TRAP_GROUP_0_E:
        rdq = __pci_profile_s.rdq[rdqs_swid][MIN(0, rdq_max_idx)];
        cpu_tclass = SX_CPU_TCLASS_TRAP_GROUP_0;
        break;

    case SX_HW_TRAP_GROUP_1_E:
        rdq = __pci_profile_s.rdq[rdqs_swid][MIN(1, rdq_max_idx)];
        cpu_tclass = SX_CPU_TCLASS_TRAP_GROUP_1;
        break;

    case SX_HW_TRAP_GROUP_2_E:
        rdq = __pci_profile_s.rdq[rdqs_swid][MIN(2, rdq_max_idx)];
        cpu_tclass = SX_CPU_TCLASS_TRAP_GROUP_2;
        break;

    case SX_HW_TRAP_GROUP_3_E:
        rdq = __pci_profile_s.rdq[rdqs_swid][MIN(3, rdq_max_idx)];
        cpu_tclass = SX_CPU_TCLASS_TRAP_GROUP_3;
        break;

    case SX_HW_TRAP_GROUP_4_E:
        if ((__pci_profile_s.swid_type[rdqs_swid] == SX_KU_L2_TYPE_ETH) ||
            (__pci_profile_s.swid_type[rdqs_swid] == SX_KU_L2_TYPE_ROUTER_PORT)) {
            rdq = __pci_profile_s.emad_rdq;
        } else {
            rdq = __pci_profile_s.rdq[rdqs_swid][MIN(4, rdq_max_idx)];
        }
        cpu_tclass = rdqs_swid;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid HW trap group %d\n", hw_trap_group);
        goto out;
    }

    err = __host_ifc_hw_trap_group_set_logic(swid, hw_trap_group, trap_priority,
                                             truncate_mode, truncate_size, control_type, rdq, cpu_tclass);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set HW trap group %u, return value: [%s]\n",
                   hw_trap_group, sx_status_str(err));
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_sx_handle_hpkt(sx_trap_id_t       trap_id,
                                    uint32_t           hw_trap_id,
                                    sx_trap_action_t  *trap_action,
                                    uint32_t          *hw_trap_group,
                                    sx_control_type_t *control_type)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(utils_check_pointer(trap_action, "trap_action"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_trap_group, "hw_trap_group"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(control_type, "control_type"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*trap_action != SX_TRAP_ACTION_IGNORE) &&
        (*trap_action != SX_TRAP_ACTION_TRAP_2_CPU) &&
        (*trap_action != SX_TRAP_ACTION_MIRROR_2_CPU) &&
        (*trap_action != SX_TRAP_ACTION_DISCARD)) {
        SX_LOG_ERR("Trap action (%u) not supported on chip type %s \n", *trap_action,
                   sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((!SX_TRAP_ID_ACL_CHECK_RANGE(trap_id)) &&
        (!SX_TRAP_ID_IPTRAP_CHECK_RANGE(trap_id)) &&
        (!SX_TRAP_ID_SW_CHECK_RANGE(trap_id))) {
        err = __handle_hpkt(hw_trap_id,
                            trap_action, hw_trap_group, control_type, FALSE, 0);

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("%s: Failed to set HPKT register, [hw_trap_id = %u], return value: [%s]\n",
                       __FUNCTION__,
                       hw_trap_id,
                       sx_status_str(err));
            goto out;
        }
    }

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_spectrum_handle_hpkt(sx_trap_id_t       trap_id,
                                          uint32_t           hw_trap_id,
                                          sx_trap_action_t  *trap_action,
                                          uint32_t          *hw_trap_group,
                                          sx_control_type_t *control_type)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_configured;
    sx_swid_t                        swid = 0;

    if (SX_CHECK_FAIL(utils_check_pointer(trap_action, "trap_action"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_trap_group, "hw_trap_group"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(control_type, "control_type"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = host_ifc_db_trap_group_properties_get(swid, *hw_trap_group,
                                                &trap_group_properties, &is_configured);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get trap group properties for swid %u HW trap group %u, return value: [%s]\n",
                   swid, *hw_trap_group, sx_status_str(err));
        goto out;
    }

    if (!SX_TRAP_ID_SW_CHECK_RANGE(trap_id)) {
        err = __handle_hpkt(hw_trap_id,
                            trap_action, hw_trap_group, control_type,
                            trap_group_properties.truncate_mode == SX_TRUNCATE_MODE_PROFILE_ENABLE,
                            trap_group_properties.trunc_profile_id);

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("%s: Failed to set HPKT register, [hw_trap_id = %u], return value: [%s]\n",
                       __FUNCTION__,
                       hw_trap_id,
                       sx_status_str(err));
            goto out;
        }
    }

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_trap_group_span_probability_rate_set(const sx_span_probability_rate_t rate)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_swid_t                        swid = 0;
    sx_hw_trap_group_e               mirror_trap_group;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;
    host_ifc_internal_trap_groups_t  internal_trap_groups;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_group_properties);
    SX_MEM_CLR(internal_trap_groups);

    if (__is_initialized_s == FALSE) {
        SX_LOG(SX_LOG_INFO, "HOST IFC module is not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }
    if (__pci_profile_s.rdq_count[0] == 0) {
        SX_LOG_ERR("%s: No RDQs defined for SWID 0 in pci profile\n", __func__);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = host_ifc_internal_trap_groups_from_profile_get(&__pci_profile_s, &internal_trap_groups);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get internal trap groups, return value: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }
    mirror_trap_group = internal_trap_groups.mirror_trap_group;

    /* Get trap group DB parameters */
    rc = host_ifc_db_trap_group_properties_get(swid,
                                               mirror_trap_group,
                                               &trap_group_properties,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to fetch trap group properties from DB, return value: [%s].\n",
                   sx_status_str(rc));
        goto out;
    }

    /* Validity check - group configured */
    if (is_trap_group_configured == FALSE) {
        SX_LOG_ERR("Trap group (%u) is not configured on swid (%u).\n",
                   mirror_trap_group, swid);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    trap_group_properties.mirror_probability_rate = rate;

    rc = host_ifc_handle_htgt(0, swid, mirror_trap_group,
                              &(trap_group_properties.type),
                              &(trap_group_properties.path),
                              &(trap_group_properties.policer_id_enabled),
                              &(trap_group_properties.policer_id),
                              &(trap_group_properties.priority),
                              &(trap_group_properties.mirror_action),
                              &(trap_group_properties.mirror_agent),
                              &(trap_group_properties.mirror_probability_rate));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set HTGT register, return value: [%s].\n", sx_status_str(rc));
        goto out;
    }

    /* add trap group properties to DB if write to register succeeded */
    rc = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET,
                                               swid,
                                               mirror_trap_group,
                                               &trap_group_properties);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in host_ifc_db_trap_group_properties_set, return value: [%s].\n",
                   sx_status_str(rc));
        goto out;
    }

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_trap_group_span_set(const sx_access_cmd_t          cmd,
                                         const sx_trap_group_t          hw_trap_group,
                                         const sx_span_session_id_int_t span_session_id)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_swid_t                        swid = 0;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_group_properties);

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    /* Get trap group DB parameters */
    rc = host_ifc_db_trap_group_properties_get(swid,
                                               hw_trap_group,
                                               &trap_group_properties,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to fetch trap group properties from DB, [trap_group = %u], return value: [%s].\n",
                   hw_trap_group, sx_status_str(rc));
        goto out;
    }

    /* Validity check - group configured */
    if (is_trap_group_configured == FALSE) {
        SX_LOG_ERR("Trap group (%u) is not configured on swid (%u).\n",
                   hw_trap_group, swid);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Set mirroring fields */

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        trap_group_properties.mirror_action = SXD_HOST_IF_MIRROR_ACTION_TRAP_TO_MIRROR;
        trap_group_properties.mirror_agent = span_session_id;
        break;

    case SX_ACCESS_CMD_DELETE:
        trap_group_properties.mirror_action = SXD_HOST_IF_MIRROR_ACTION_TRAP_TO_CPU;
        trap_group_properties.mirror_agent = span_session_id;
        break;

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    rc = host_ifc_handle_htgt(0, swid, hw_trap_group,
                              &(trap_group_properties.type),
                              &(trap_group_properties.path),
                              &(trap_group_properties.policer_id_enabled),
                              &(trap_group_properties.policer_id),
                              &(trap_group_properties.priority),
                              &(trap_group_properties.mirror_action),
                              &(trap_group_properties.mirror_agent),
                              &(trap_group_properties.mirror_probability_rate));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set HTGT register, [trap_group = %u], return value: [%s].\n",
                   hw_trap_group, sx_status_str(rc));
        goto out;
    }

    /* add trap group properties to DB if write to register succeeded */
    rc = host_ifc_db_trap_group_properties_set(SX_ACCESS_CMD_SET,
                                               swid,
                                               hw_trap_group,
                                               &trap_group_properties);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in host_ifc_db_trap_group_properties_set, [trap_group_id = %u], return value: [%s].\n",
                   hw_trap_group, sx_status_str(rc));
        goto out;
    }

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_trap_group_for_span_get(sx_trap_group_t *hw_trap_groups_p, uint32_t *hw_trap_group_count_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    trap_idx = 0;
    uint32_t    tg_count = 0;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(hw_trap_groups_p, "hw_trap_groups"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_trap_groups_p, "hw_trap_groups"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    tg_count = MIN(*hw_trap_group_count_p, SPECTRUM_SPAN_TRAP_GROUPS_NUM);
    for (trap_idx = 0; trap_idx < tg_count; trap_idx++) {
        hw_trap_groups_p[trap_idx] = SPECTRUM_SPAN_TRAP_GROUPS_START + trap_idx;
    }
    *hw_trap_group_count_p = tg_count;

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_set_trap_id_for_span(const sx_access_cmd_t cmd,
                                          const sx_trap_id_t    trap_id,
                                          const sx_trap_group_t trap_group)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    sx_swid_t       swid = 0;
    sx_trap_id_t    _trap_id = trap_id;
    sx_trap_group_t hw_trap_group = trap_group;

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        err = __host_ifc_trap_id_set_to_hw_trap_group(swid, trap_id, hw_trap_group, SX_TRAP_ACTION_EXCEPTION_TRAP);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed setting Trap ID %u for Trap Group %u, return value: [%s].\n",
                       trap_id, trap_group, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        err = __host_ifc_default_actions_set(TRUE, &_trap_id, NULL);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set default actions, [trap_id = %u, hw_trap_id = %u], return value: [%s]\n",
                       trap_id, hw_trap_group, sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_span_mirror_tables_set(const sx_access_cmd_t cmd, const sx_span_session_id_int_t span_session_id)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    uint32_t                        mirror_trap_group;
    host_ifc_internal_trap_groups_t internal_trap_groups;

    SX_MEM_CLR(internal_trap_groups);

    SX_LOG_ENTER();
    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (__pci_profile_s.rdq_count[0] == 0) {
        SX_LOG_ERR("%s: No RDQs defined for SWID 0 in pci profile\n", __func__);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = host_ifc_internal_trap_groups_from_profile_get(&__pci_profile_s, &internal_trap_groups);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get internal trap groups, return value: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }
    mirror_trap_group = internal_trap_groups.mirror_trap_group;

    rc = host_ifc_trap_group_span_set(cmd, mirror_trap_group, span_session_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed setting Mirror SPAN session %u for trap group %u, return value: [%s].\n",
                   span_session_id, mirror_trap_group, sx_status_str(rc));
        goto out;
    }

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_hw_trap_groups_get(uint64_t *hw_trap_group_status)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    long                             hw_trap_group_id;
    uint32_t                         num_trap_groups = 0;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_configured;

    memset(&trap_group_properties, 0, sizeof(trap_group_properties));
    *hw_trap_group_status = 0;

    rc = host_ifc_hw_trap_group_num_get(&num_trap_groups);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get number of HW trap groups, return value: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }
    for (hw_trap_group_id = 0;
         hw_trap_group_id < num_trap_groups;
         hw_trap_group_id++) {
        is_configured = FALSE;
        /* i used here "swid" 0 ,need to consider to extend it to the generic case and run on all "swid" list*/
        rc = host_ifc_db_trap_group_properties_get(0,
                                                   hw_trap_group_id,
                                                   &trap_group_properties,
                                                   &is_configured);
        if (rc) {
            SX_LOG_ERR("Failed to get trap group properties from the DB,"
                       " for (%lu) HW trap group return value: [%s].\n",
                       hw_trap_group_id, sx_status_str(rc));
            continue;
        }

        if (is_configured) {
            if ((trap_group_properties.type == SXD_HOST_IF_PATH_TYPE_LOCAL_E) ||
                (trap_group_properties.type == SXD_HOST_IF_PATH_TYPE_STACKING_EN_E)) {
                cl_set_bit64(hw_trap_group_status, trap_group_properties.path.local_path.rdq);
            }
        }
    }
out:
    return rc;
}

static sx_status_t __host_ifc_hw_trap_group_dump(dbg_dump_params_t *dbg_dump_params_p, sx_swid_t swid)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    uint8_t                          str_len = 20;
    char                             truncate_mode_str[str_len];
    char                             policer_str[str_len];
    char                             control_str[str_len];
    char                             timestamp[str_len];
    char                             mirror_action_str[str_len];
    char                             path_type_str[25];
    char                             path_str[160];
    uint32_t                         hw_trap_group;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_configured;
    uint32_t                         num_trap_groups = 0;
    dbg_utils_table_columns_t        hw_trap_group_entries_dump_clmns[] = {
        { "HW Trap Group", 14,    PARAM_UINT32_E,     &hw_trap_group},
        { "Priority",      10,    PARAM_UINT32_E,     &trap_group_properties.priority},
        { "Trunc Mode",    11,    PARAM_STRING_E,     &truncate_mode_str},
        { "Trunc Size",    11,    PARAM_UINT16_E,     &trap_group_properties.truncate_size},
        { "Trunc Prof",    11,    PARAM_UINT16_E,     &trap_group_properties.trunc_profile_id},
        { "Ctrl Type",     10,    PARAM_STRING_E,     &control_str},
        { "Timestamp",     15,    PARAM_STRING_E,     &timestamp},
        { "Policer ID",    11,    PARAM_STRING_E,     &policer_str},
        { "Mirror Agent",  12,    PARAM_UINT8_E,      &trap_group_properties.mirror_agent},
        { "Mirror Action", 13,    PARAM_STRING_E,     &mirror_action_str},
        { "Path Type",     12,    PARAM_STRING_E,     &path_type_str},
        { "Path",          35,    PARAM_EXT_STRING_E, &path_str},
        { "Monitor",        8,    PARAM_BOOL_E,       &trap_group_properties.is_monitor},
        { "Mon. FD",        8,    PARAM_UINT32_E,     &trap_group_properties.monitor_fd.fd},
        {NULL, 0, 0, NULL}
    };
    FILE                            *stream = dbg_dump_params_p->stream;

    memset(&trap_group_properties, 0, sizeof(trap_group_properties));

    rc = host_ifc_hw_trap_group_num_get(&num_trap_groups);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get number of HW trap groups, return value: [%s]\n",
                   sx_status_str(rc));
    }

    dbg_utils_pprinter_table_headline_print(stream, hw_trap_group_entries_dump_clmns);

    /* print group attributes per trap group */
    for (hw_trap_group = 0;
         hw_trap_group < num_trap_groups;
         hw_trap_group++) {
        rc = host_ifc_db_trap_group_properties_get(swid,
                                                   hw_trap_group,
                                                   &trap_group_properties,
                                                   &is_configured);
        if (rc) {
            SX_LOG_ERR("Failed to get trap group properties from the DB,"
                       " for (%u) HW trap group return value: [%s].\n",
                       hw_trap_group, sx_status_str(rc));
            continue;
        }

        if (!is_configured) {
            continue;
        }

        switch (trap_group_properties.truncate_mode) {
        case SX_TRUNCATE_MODE_DISABLE:
            strcpy(truncate_mode_str, "DISABLE");
            break;

        case SX_TRUNCATE_MODE_ENABLE:
            strcpy(truncate_mode_str, "ENABLE");
            break;

        case SX_TRUNCATE_MODE_PROFILE_ENABLE:
            strcpy(truncate_mode_str, "PROFILE");
            break;

        default:
            sprintf(truncate_mode_str, "NA (%u)", trap_group_properties.truncate_mode);
            break;
        }
        switch (trap_group_properties.type) {
        case SXD_HOST_IF_PATH_TYPE_LOCAL_E:
            strcpy(path_type_str, "LOCAL");
            sprintf(path_str, "RDQ %u, CPU TC %u",
                    trap_group_properties.path.local_path.rdq,
                    trap_group_properties.path.local_path.cpu_tclass);
            break;

        case SXD_HOST_IF_PATH_TYPE_NULL_E: /* NULL path */
            strcpy(path_type_str, "NULL");
            strcpy(path_str, "NA");
            break;

        default:
            sprintf(path_type_str, "NA (%u)",
                    trap_group_properties.type);
            strcpy(path_str, "NA");
            break;
        }

        if (trap_group_properties.policer_id_enabled) {
            sprintf(policer_str, "%" PRIu64 "", trap_group_properties.policer_id);
        } else {
            strcpy(policer_str, "No Policer");
        }

        switch (trap_group_properties.control_type) {
        case SX_CONTROL_TYPE_DEFAULT:
            strcpy(control_str, "DEFAULT");
            break;

        case SX_CONTROL_TYPE_ENABLE:
            strcpy(control_str, "ENABLE");
            break;

        case SX_CONTROL_TYPE_DISABLE:
            strcpy(control_str, "DISABLE");
            break;

        default:
            sprintf(control_str, "NA (%u)", trap_group_properties.control_type);
            break;
        }

        if (trap_group_properties.timestamp_source == SX_PACKET_TIMESTAMP_SOURCE_HW_UTC_E) {
            strcpy(timestamp, "Enabled HW UTC");
        } else {
            strcpy(timestamp, "Enabled Linux");
        }

        switch (trap_group_properties.mirror_action) {
        case SXD_HOST_IF_MIRROR_ACTION_TRAP_TO_CPU:
            strcpy(mirror_action_str, "CPU");
            break;

        case SXD_HOST_IF_MIRROR_ACTION_TRAP_TO_CPU_AND_MIRROR:
            strcpy(mirror_action_str, "CPU & MIRROR");
            break;

        case SXD_HOST_IF_MIRROR_ACTION_TRAP_TO_MIRROR:
            strcpy(mirror_action_str, "MIRROR");
            break;

        default:
            sprintf(mirror_action_str, "NA (%u)", trap_group_properties.mirror_action);
            break;
        }

        dbg_utils_pprinter_table_data_line_print(stream, hw_trap_group_entries_dump_clmns);
    }

    return rc;
}

static sx_status_t __host_ifc_trap_group_dump(dbg_dump_params_t *dbg_dump_params_p, sx_swid_t swid)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    uint32_t                  trap_group;
    uint32_t                  hw_trap_group;
    dbg_utils_table_columns_t trap_group_entries_dump_clmns[] = {
        { "Trap Group",       15,    PARAM_UINT32_E,     &trap_group},
        { "HW Trap Group",    15,    PARAM_UINT32_E,     &hw_trap_group},
        {NULL, 0, 0, NULL}
    };
    FILE                     *stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_table_headline_print(stream, trap_group_entries_dump_clmns);

    /* print group attributes per trap group */
    for (trap_group = 0; trap_group <= TRAP_GROUP_ID_MAX; trap_group++) {
        rc = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get HW trap group from the DB for (%u) "
                       "trap group, return value: [%s].\n",
                       trap_group, sx_status_str(rc));
            continue;
        }

        if (hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
            continue;
        }

        dbg_utils_pprinter_table_data_line_print(stream, trap_group_entries_dump_clmns);
    }

    return rc;
}


static sx_status_t __host_ifc_trap_id_channel_filter_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                             rc = SX_STATUS_SUCCESS;
    char                                    trap_str[40];
    char                                    user_channel_str[17];
    char                                    user_channel_attr_str[60];
    char                                    filter_key_str[17];
    char                                    filter_key_id_str[17];
    sx_trap_id_t                            trap_id = 0;
    uint32_t                                channel_filter_entry_cnt = 0;
    uint32_t                                tmp_cnt = 0;
    sx_host_ifc_channel_filter_get_entry_t *channel_filter_entry_list_p = NULL;
    uint8_t                                 swid = 0;
    uint32_t                                j = 0;
    uint32_t                                attr_len = 60;
    uint8_t                                *mac_p = NULL;
    char                                   *filter_key_type_str[] = {
        [SX_HOST_IFC_REGISTER_KEY_TYPE_GLOBAL] = "GLOBAL",
        [SX_HOST_IFC_REGISTER_KEY_TYPE_PORT] = "PORT",
        [SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN] = "VLAN",
    };
    char                                   *user_channel_type_str[] = {
        [SX_USER_CHANNEL_TYPE_FD] = "FD",
        [SX_USER_CHANNEL_TYPE_L3_NETDEV] = "L3 NETDEV",
        [SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV] = "LOG PORT NETDEV",
        [SX_USER_CHANNEL_TYPE_PHY_PORT_NETDEV] = "PHY PORT NETDEV",
        [SX_USER_CHANNEL_TYPE_L2_TUNNEL] = "L2 TUNNEL",
    };
    dbg_utils_table_columns_t               channel_filter_entries_dump_clmns[] = {
        { "Trap",                    40,         PARAM_STRING_E,     &trap_str},
        { "Trap ID",                 10,         PARAM_UINT32_E,     &trap_id},
        { "User Channel Type",       17,         PARAM_STRING_E,     &user_channel_str},
        { "User Channel Attributes", 24,         PARAM_EXT_STRING_E, &user_channel_attr_str},
        { "Filter Key Type",         17,         PARAM_STRING_E,     &filter_key_str},
        { "Filter Key ID",           17,         PARAM_STRING_E,     &filter_key_id_str},
        {NULL, 0, 0, NULL}
    };
    FILE                                   *stream = dbg_dump_params_p->stream;

    memset(trap_str, 0, sizeof(trap_str));
    memset(user_channel_str, 0, sizeof(user_channel_str));
    memset(user_channel_attr_str, 0, sizeof(user_channel_attr_str));
    memset(filter_key_str, 0, sizeof(filter_key_str));
    memset(filter_key_id_str, 0, sizeof(filter_key_id_str));

    for (swid = 0; swid < RM_NUM_OF_SWIDS; swid++) {
        dbg_utils_pprinter_secondary_header_print(stream, "SWID %u", swid);
        dbg_utils_pprinter_table_headline_print(stream, channel_filter_entries_dump_clmns);

        for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
            /**get entries from DB for trap_id **/
            channel_filter_entry_cnt = 0;
            rc =
                host_ifc_trap_id_channel_filter_get(SX_ACCESS_CMD_GET,
                                                    swid,
                                                    trap_id,
                                                    NULL,
                                                    0,
                                                    NULL,
                                                    &(channel_filter_entry_cnt));
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get channel filter entries count from the DB for (%u) "
                           "trap id.\n", trap_id);
                continue;
            }
            channel_filter_entry_list_p =
                (sx_host_ifc_channel_filter_get_entry_t*)cl_malloc(
                    sizeof(sx_host_ifc_channel_filter_get_entry_t) * channel_filter_entry_cnt);
            if (channel_filter_entry_list_p == NULL) {
                SX_LOG_ERR("Failed to allocate memory for channel_filter_entry_list for (%u) trap_id.\n", trap_id);
                continue;
            }
            tmp_cnt = channel_filter_entry_cnt;
            rc = host_ifc_trap_id_channel_filter_get(SX_ACCESS_CMD_GET_FIRST,
                                                     swid,
                                                     trap_id,
                                                     NULL,
                                                     0,
                                                     channel_filter_entry_list_p,
                                                     &(tmp_cnt));
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get channel filter entries from the DB for (%u) "
                           "trap id.\n", trap_id);
                cl_free(channel_filter_entry_list_p);
                continue;
            }
            if (tmp_cnt != channel_filter_entry_cnt) {
                SX_LOG_ERR("Failed to get all channel filter entries from the DB for (%u) "
                           "trap id.\n", trap_id);
                cl_free(channel_filter_entry_list_p);
                continue;
            }

            /** fill fields **/

            strncpy(trap_str,  sx_host_ifc_trap_id_str(trap_id), sizeof(trap_str));
            for (j = 0; j < channel_filter_entry_cnt; j++) {
                memset(filter_key_str, 0, sizeof(filter_key_str));
                strncpy(filter_key_str,
                        filter_key_type_str[channel_filter_entry_list_p[j].filter_key.key_type],
                        sizeof(filter_key_str));

                memset(filter_key_id_str, 0, sizeof(filter_key_id_str));
                if (channel_filter_entry_list_p[j].filter_key.key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_PORT) {
                    sprintf(filter_key_id_str,
                            "0x%" PRIx32,
                            channel_filter_entry_list_p[j].filter_key.key_value.port_id);
                } else if (channel_filter_entry_list_p[j].filter_key.key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN) {
                    sprintf(filter_key_id_str, "%u", channel_filter_entry_list_p[j].filter_key.key_value.vlan_id);
                }

                memset(user_channel_str, 0, sizeof(user_channel_str));
                strncpy(user_channel_str,
                        user_channel_type_str[channel_filter_entry_list_p[j].user_channel.type],
                        sizeof(user_channel_str));
                memset(user_channel_attr_str, 0, sizeof(user_channel_attr_str));
                if (channel_filter_entry_list_p[j].user_channel.type == SX_USER_CHANNEL_TYPE_FD) {
                    snprintf(user_channel_attr_str, attr_len,
                             "FD %u", channel_filter_entry_list_p[j].user_channel.channel.fd.fd);
                } else if (channel_filter_entry_list_p[j].user_channel.type == SX_USER_CHANNEL_TYPE_L2_TUNNEL) {
                    mac_p = (uint8_t*)(&(channel_filter_entry_list_p[j].user_channel.channel.l2_tunnel_params.dmac));
                    snprintf(user_channel_attr_str,
                             attr_len,
                             "DMAC %.2X:%.2X:%.2X:%.2X:%.2X:%.2X, PRIO %u, VID %u",
                             mac_p[0],
                             mac_p[1],
                             mac_p[2],
                             mac_p[3],
                             mac_p[4],
                             mac_p[5],
                             channel_filter_entry_list_p[j].user_channel.channel.l2_tunnel_params.prio,
                             channel_filter_entry_list_p[j].user_channel.channel.l2_tunnel_params.vid);
                }
                dbg_utils_pprinter_table_data_line_print(stream, channel_filter_entries_dump_clmns);
            }
            if (channel_filter_entry_list_p != NULL) {
                cl_free(channel_filter_entry_list_p);
            }
        }
    }
    return rc;
}

static sx_status_t __host_ifc_trap_id_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    uint8_t                               str_len = 20;
    uint8_t                               attr_len = 126;
    char                                  trap_id_str[40];
    char                                  action_str[str_len];
    char                                  trap_group_str[str_len];
    char                                  user_trap_group_str[str_len];
    char                                  tmp[str_len];
    char                                  control_str[str_len];
    char                                  attributes_str[attr_len];
    sx_trap_id_t                          trap_id = 0;
    uint32_t                              hw_trap_id = 0;
    host_ifc_trap_id_properties_t         trap_id_properties;
    sx_trap_group_t                       trap_groups[SX_TRAP_ID_MAX + 1];
    uint32_t                              trap_group_cnt = 0;
    uint32_t                              i = 0;
    sx_trap_id_user_defined_attributes_t  user_def_attr;
    sx_trap_id_user_defined_packet_type_t packet_type = 0;
    sx_acl_port_range_direction_t         direction = 0;
    sx_acl_port_range_ip_header_t         ip_header = 0;
    int32_t                               attr_shift = 0;
    sx_trap_id_user_defined_key_type_t    key_type = 0;
    FILE                                 *stream = dbg_dump_params_p->stream;
    uint8_t                               swid = 0;
    sx_hw_trap_group_e                    hw_trap_group_id;

    memset(user_trap_group_str, 0, sizeof(user_trap_group_str));
    memset(attributes_str, 0, sizeof(attributes_str));
    memset(&user_def_attr, 0, sizeof(user_def_attr));
    memset(tmp, 0, sizeof(tmp));

    dbg_utils_table_columns_t trap_id_entries_dump_clmns[] = {
        { "Trap",             40,    PARAM_STRING_E,     &trap_id_str},
        { "Trap ID",          10,    PARAM_HEX_E,        &trap_id},
        { "HW Trap ID",       11,    PARAM_HEX_E,        &hw_trap_id},
        { "Trap Group",       20,    PARAM_STRING_E,     &user_trap_group_str},
        { "HW Trap Group",    15,    PARAM_STRING_E,     &trap_group_str},
        { "Action",           15,    PARAM_STRING_E,     &action_str},
        { "Control Type",     15,    PARAM_STRING_E,     &control_str},
        { "Trunc En",         10,    PARAM_BOOL_E,      &trap_id_properties.tr_en},
        { "Trunc Prof",       12,    PARAM_UINT8_E,     &trap_id_properties.tr_prof},
        {NULL, 0, 0, NULL}
    };
    char                    * packet_type_str[] = {
        [SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_E] = "UDP",
        [SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_TCP_E] = "TCP",
        [SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_TCP_E] = "UDP_TCP",
        [SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_TCP_E + 1] = "UNKNOWN",
    };
    char                    * range_dir_str[] = {
        [SX_ACL_PORT_DIRECTION_SOURCE] = "SRC",
        [SX_ACL_PORT_DIRECTION_DESTINATION] = "DST",
        [SX_ACL_PORT_DIRECTION_BOTH] = "BOTH",
        [SX_ACL_PORT_DIRECTION_MAX + 1] = "UNKNOWN",
    };
    char                    * range_iph_str[] = {
        [SX_ACL_PORT_RANGE_IP_HEADER_OUTER] = "OUT",
        [SX_ACL_PORT_RANGE_IP_HEADER_INNER] = "IN",
        [SX_ACL_PORT_RANGE_IP_HEADER_BOTH] = "BOTH",
        [SX_ACL_PORT_RANGE_IP_HEADER_MAX + 1] = "UNKNOWN",
    };
    dbg_utils_table_columns_t trap_id_attr_dump_clmns[] = {
        { "Trap",             40,    PARAM_STRING_E,     &trap_id_str},
        { "Key",               3,    PARAM_UINT32_E,     &key_type},
        { "Attributes",       126,   PARAM_EXT_STRING_E,     &attributes_str},
        {NULL, 0, 0, NULL}
    };

    dbg_utils_pprinter_table_headline_print(stream, trap_id_entries_dump_clmns);


    for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
        rc = host_ifc_db_trap_id_properties_get(trap_id, &trap_id_properties);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get trap ID properties from DB for "
                       "trap id (0x%x), return value: [%s].\n", trap_id, sx_status_str(rc));
            continue;
        }

        if (trap_id_properties.hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
            continue;
        }

        rc =
            host_ifc_db_trap_id_to_group_associate_get(trap_id, trap_groups, NULL, &trap_group_cnt);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get trap ID associated groups from DB for "
                       "trap id (0x%x), return value: [%s].\n", trap_id, sx_status_str(rc));
            continue;
        }

        memset(user_trap_group_str, 0, sizeof(user_trap_group_str));

        if ((trap_group_cnt == 0) ||
            (trap_groups[0] == (SX_TRAP_GROUP_MAX + 1))) {
            sprintf(user_trap_group_str, "%s", "Disabled");
        } else {
            for (i = 0; i < trap_group_cnt; i++) {
                /* trap group -> HW trap group */
                rc = host_ifc_db_trap_group_map_get(swid, trap_groups[i], &hw_trap_group_id);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to get hw trap group for trap group %u\n", trap_groups[i]);
                    continue;
                }

                sprintf(tmp, "%u(hw:%u),", trap_groups[i], hw_trap_group_id);
                strcat(user_trap_group_str, tmp);
            }
            user_trap_group_str[strlen(user_trap_group_str) - 1] = '\0';
        }

        hw_trap_id = trap_id_properties.hw_trap_id;

        sprintf(trap_group_str, "%u", trap_id_properties.hw_trap_group);
        switch (trap_id_properties.trap_action) {
        case SX_TRAP_ACTION_IGNORE:
            strcpy(action_str, "IGNORE");
            break;

        case SX_TRAP_ACTION_TRAP_2_CPU:
            strcpy(action_str, "TRAP");
            break;

        case SX_TRAP_ACTION_MIRROR_2_CPU:
            strcpy(action_str, "MIRROR");
            break;

        case SX_TRAP_ACTION_DISCARD:
            strcpy(action_str, "DISCARD");
            break;

        case SX_TRAP_ACTION_SOFT_DISCARD:
            strcpy(action_str, "SOFT_DISCARD");
            break;

        case SX_TRAP_ACTION_TRAP_SOFT_DISCARD:
            strcpy(action_str, "TRAP_SFT_DSCRD");
            break;

        case SX_TRAP_ACTION_EXCEPTION_TRAP:
            strcpy(action_str, "EXCEPTION_TRAP");
            break;

        case SX_TRAP_ACTION_SET_FW_DEFAULT:
            strcpy(action_str, "SET_FW_DEFAULT");
            break;

        default:
            sprintf(action_str, "NA (%u)", trap_id_properties.trap_action);
            break;
        }
        switch (trap_id_properties.control_type) {
        case SX_CONTROL_TYPE_DEFAULT:
            strcpy(control_str, "DEFAULT");
            break;

        case SX_CONTROL_TYPE_ENABLE:
            strcpy(control_str, "ENABLE");
            break;

        case SX_CONTROL_TYPE_DISABLE:
            strcpy(control_str, "DISABLE");
            break;

        default:
            sprintf(control_str, "NA (%u)", trap_id_properties.control_type);
            break;
        }

        /* set string line */
        memset(trap_id_str, 0, sizeof(trap_id_str));
        /* coverity[buffer_size_warning] */
        strncpy(trap_id_str,  sx_host_ifc_trap_id_str(trap_id), sizeof(trap_id_str));
        dbg_utils_pprinter_table_data_line_print(stream, trap_id_entries_dump_clmns);
    }

    dbg_utils_pprinter_general_header_print(stream, "User defined Trap - Attributes");

    dbg_utils_pprinter_table_headline_print(stream, trap_id_attr_dump_clmns);
    for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
        rc = host_ifc_db_trap_id_properties_get(trap_id, &trap_id_properties);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get trap ID properties from DB for "
                       "trap id (0x%x), return value: [%s].\n", trap_id, sx_status_str(rc));
            continue;
        }

        if (trap_id_properties.hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
            continue;
        }
        /* set string line */
        memset(trap_id_str, 0, sizeof(trap_id_str));
        strncpy(trap_id_str,  sx_host_ifc_trap_id_str(trap_id), (sizeof(trap_id_str) - 1));

        /* get trap attributes */
        memset(attributes_str, 0, sizeof(attributes_str));
        attr_shift = 0;
        if (SX_TRAP_ID_USER_CHECK_RANGE(trap_id) == TRUE) {
            rc = host_ifc_db_user_trap_id_get(trap_id, &user_def_attr);
            if (rc == SX_STATUS_SUCCESS) {
                for (i = 0; i < user_def_attr.key_list_cnt; i++) {
                    if ((attr_shift < 0) || (attr_shift > attr_len)) {
                        continue;
                    }
                    key_type = user_def_attr.key_list[i].type;
                    switch (key_type) {
                    case SX_TRAP_ID_USER_DEFINED_KEY_PACKET_TYPE_E:
                        packet_type = user_def_attr.key_list[i].key.packet_type;
                        if (packet_type > SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_TCP_E) {
                            packet_type = SX_TRAP_ID_USER_DEFINED_PACKET_TYPE_UDP_TCP_E + 1;
                        }

                        attr_shift = snprintf(attributes_str + attr_shift, attr_len - attr_shift,
                                              "PKT_T[%s] ", packet_type_str[packet_type]);
                        break;

                    case SX_TRAP_ID_USER_DEFINED_KEY_PORT_RANGE_E:
                        direction = user_def_attr.key_list[i].key.port_range.port_range_direction;
                        if (direction > SX_ACL_PORT_DIRECTION_MAX) {
                            direction = SX_ACL_PORT_DIRECTION_MAX + 1;
                        }

                        ip_header = user_def_attr.key_list[i].key.port_range.port_range_ip_header;
                        if (ip_header > SX_ACL_PORT_RANGE_IP_HEADER_MAX) {
                            ip_header = SX_ACL_PORT_RANGE_IP_HEADER_MAX + 1;
                        }
                        attr_shift = snprintf(attributes_str + attr_shift, attr_len - attr_shift,
                                              "RANGE[%u %u %s %s %s] ",
                                              user_def_attr.key_list[i].key.port_range.port_range_min,
                                              user_def_attr.key_list[i].key.port_range.port_range_max,
                                              range_dir_str[direction], range_iph_str[ip_header],
                                              user_def_attr.key_list[i].key.port_range.port_range_ip_length ? "T" : "F");
                        break;

                    case SX_TRAP_ID_USER_DEFINED_KEY_IPV6_ICMP_TYPE_E:
                        attr_shift = snprintf(attributes_str + attr_shift, attr_len - attr_shift,
                                              "IPV6_ICMP_TYPE[0x%02x] ",
                                              user_def_attr.key_list[i].key.icmpv6_attr.icmpv6_type);
                        break;

                    case SX_TRAP_ID_USER_DEFINED_KEY_NVE_DECAP_ETH_TYPE_E:
                        if (SX_TRAP_ID_USER_ATTR_EXT_CHECK_RANGE(trap_id) != TRUE) {
                            attr_shift = snprintf(attributes_str + attr_shift, attr_len - attr_shift,
                                                  "ETH_TYPE[0x%04x] ",
                                                  user_def_attr.key_list[i].key.nve_decap_eth_attr.eth_type);
                        } else {
                            attr_shift = snprintf(attributes_str + attr_shift,
                                                  attr_len - attr_shift,
                                                  "ETH_TYPE[0x%04x], IS_ETH_TYPE_VALID[%s], TUNID[0x%04x]",
                                                  user_def_attr.key_list[i].key.nve_decap_eth_attr.eth_type,
                                                  user_def_attr.key_list[i].key.nve_decap_eth_attr.is_eth_type_valid ? "T" : "F",
                                                  user_def_attr.key_list[i].key.nve_decap_eth_attr.tunnel_id);
                        }
                        break;

                    case SX_TRAP_ID_USER_DEFINED_KEY_NEXT_PROTO_E:
                        attr_shift = snprintf(attributes_str + attr_shift,
                                              attr_len - attr_shift,
                                              "IS_IPV4[0x%x], IS_IPV4_VALID[%s], IPPROTO[0x%04x], IPPROTO_VALID[%s],"
                                              " TUN_ID[0x%04x]",
                                              user_def_attr.key_list[i].key.next_proto_key_type_attr.is_ipv4,
                                              user_def_attr.key_list[i].key.next_proto_key_type_attr.is_ipv4_valid ? "T" : "F",
                                              user_def_attr.key_list[i].key.next_proto_key_type_attr.ip_proto,
                                              user_def_attr.key_list[i].key.next_proto_key_type_attr.is_ip_proto_valid ? "T" : "F",
                                              user_def_attr.key_list[i].key.next_proto_key_type_attr.tunnel_id);
                        break;

                    case SX_TRAP_ID_USER_DEFINED_KEY_L4_PORT_E:
                        attr_shift = snprintf(attributes_str + attr_shift,
                                              attr_len - attr_shift,
                                              "IS_IPV4[0x%x], IS_IPV4_VALID[%s], IS_UDP[0x%x], IS_UDP_VALID[%s], L4PORT[0x%04x],"
                                              " L4PORT_VALID[%s], TUN_ID[0x%04x]",
                                              user_def_attr.key_list[i].key.l4_port_key_type_attr.is_ipv4,
                                              user_def_attr.key_list[i].key.l4_port_key_type_attr.is_ipv4_valid ? "T" : "F",
                                              user_def_attr.key_list[i].key.l4_port_key_type_attr.is_udp,
                                              user_def_attr.key_list[i].key.l4_port_key_type_attr.is_udp_valid ? "T" : "F",
                                              user_def_attr.key_list[i].key.l4_port_key_type_attr.l4_port,
                                              user_def_attr.key_list[i].key.l4_port_key_type_attr.is_l4_port_valid ? "T" : "F",
                                              user_def_attr.key_list[i].key.l4_port_key_type_attr.tunnel_id);
                        break;

                    case SX_TRAP_ID_USER_DEFINED_KEY_ICMP_E:
                        attr_shift = snprintf(attributes_str + attr_shift,
                                              attr_len - attr_shift,
                                              "IS_IPV4[0x%x], IS_IPV4_VALID[%s], MIN_ICMP[0x%04x], MAX_ICMP[0x%04x],"
                                              " TUN_ID[0x%04x]",
                                              user_def_attr.key_list[i].key.icmp_key_type_attr.is_ipv4,
                                              user_def_attr.key_list[i].key.icmp_key_type_attr.is_ipv4_valid ? "T" : "F",
                                              user_def_attr.key_list[i].key.icmp_key_type_attr.min_icmp_type,
                                              user_def_attr.key_list[i].key.icmp_key_type_attr.max_icmp_type,
                                              user_def_attr.key_list[i].key.icmp_key_type_attr.tunnel_id);
                        break;

                    case SX_TRAP_ID_USER_DEFINED_KEY_IGMP_E:
                        attr_shift = snprintf(attributes_str + attr_shift,
                                              attr_len - attr_shift,
                                              "MIN_IGMP[0x%04x], MAX_IGMP[0x%04x], TUN_ID[0x%04x]",
                                              user_def_attr.key_list[i].key.igmp_key_type_attr.min_igmp_type,
                                              user_def_attr.key_list[i].key.igmp_key_type_attr.max_igmp_type,
                                              user_def_attr.key_list[i].key.igmp_key_type_attr.tunnel_id);
                        break;

                    default:
                        attr_shift = snprintf(attributes_str + attr_shift, attr_len - attr_shift,
                                              "Unknown[%u] ", user_def_attr.key_list[i].type);
                        break;
                    }
                }
                dbg_utils_pprinter_table_data_line_print(stream, trap_id_attr_dump_clmns);
            }
        }
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t host_ifc_trap_counters_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    char        trap_id_str[40];
    uint8_t     i = 0;
    uint32_t    tocpu_byte_counters = 0, tocpu_packet_counters = 0, event_counters = 0,
                drop_counters = 0;
    sx_host_ifc_counters_t             host_ifc_cnt;
    sx_host_ifc_trap_id_counters_t    *trap_id_counter_p = NULL;
    sx_host_ifc_trap_group_counters_t *trap_group_counter_p = NULL;
    dbg_utils_table_columns_t          trap_id_counters_entries_dump_clmns[] = {
        { "Trap",          40, PARAM_STRING_E, &trap_id_str},
        { "Trap ID",       7,  PARAM_UINT32_E, NULL},
        { "Trap Group",    11, PARAM_UINT32_E, NULL},
        { "Type",          8,  PARAM_STRING_E, NULL},
        { "Event",         6,  PARAM_UINT32_E, NULL},
        { "Drop",          6,  PARAM_UINT32_E, NULL},
        { "To CPU packet", 14, PARAM_UINT32_E, NULL},
        { "To CPU bytes",  13, PARAM_UINT32_E, NULL},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t          trap_group_counters_entries_dump_clmns[] = {
        { "Trap Group",                11, PARAM_UINT32_E, NULL},
        { "Event",                     6,  PARAM_UINT32_E, NULL},
        { "To CPU packet",             14, PARAM_UINT32_E, NULL},
        { "To CPU bytes",              13, PARAM_UINT32_E, NULL},
        { "To CPU buffer drop",        19, PARAM_UINT32_E, NULL},
        { "Policer violation counter", 26, PARAM_UINT32_E, NULL},
        {NULL, 0, 0, NULL}
    };
    FILE                              *stream = NULL;

    SX_LOG_ENTER();

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    SX_MEM_CLR(host_ifc_cnt);

    dbg_utils_pprinter_secondary_header_print(stream, "HOST IFC GLOBAL COUNTERS");

    host_ifc_cnt.trap_group_counters_cnt = SX_TRAP_GROUP_MAX;
    host_ifc_cnt.trap_id_counters_cnt = SX_TRAP_ID_MAX;

    err = host_ifc_counters_get(SX_ACCESS_CMD_READ, NULL, &host_ifc_cnt);
    if (err != SX_STATUS_SUCCESS) {
        dbg_utils_pprinter_data_unavailable_print(stream);
        goto out;
    }

    dbg_utils_pprinter_field_print(stream, "Event counter:", &host_ifc_cnt.global_counters.event_counter,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "To CPU data byte:", &host_ifc_cnt.global_counters.tocpu_byte,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "To CPU data packet:",
                                   &host_ifc_cnt.global_counters.tocpu_packet,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "To CPU buffer drop:",
                                   &host_ifc_cnt.global_counters.tocpu_buffer_drop,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "From CPU data byte:",
                                   &host_ifc_cnt.global_counters.fromcpu_data_byte,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "From CPU data packet:",
                                   &host_ifc_cnt.global_counters.fromcpu_data_packet,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "From CPU control byte:",
                                   &host_ifc_cnt.global_counters.fromcpu_control_byte,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "From CPU control packet:",
                                   &host_ifc_cnt.global_counters.fromcpu_control_packet,
                                   PARAM_UINT32_E);

    dbg_utils_pprinter_field_print(stream, "PUDE errors count:", &__pude_err_cnt, PARAM_UINT32_E);

    dbg_utils_pprinter_print(stream, "\n");

    dbg_utils_pprinter_secondary_header_print(stream, "HOST IFC TRAP ID COUNTERS");

    dbg_utils_pprinter_field_print(stream, "Total traps:", &host_ifc_cnt.trap_id_counters_cnt, PARAM_UINT32_E);

    dbg_utils_pprinter_print(stream, "\n");

    if (host_ifc_cnt.trap_id_counters_cnt > 0) {
        dbg_utils_pprinter_table_headline_print(stream, trap_id_counters_entries_dump_clmns);

        for (i = 0; i < host_ifc_cnt.trap_id_counters_cnt; i++) {
            trap_id_counter_p = &host_ifc_cnt.trap_id_counters[i];
            trap_id_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_ID_COUNTERS_TRAP_ID_E].data =
                &trap_id_counter_p->trap_id;
            trap_id_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_ID_COUNTERS_TRAP_GROUP_E].data =
                &trap_id_counter_p->trap_group;
            trap_id_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_ID_COUNTERS_TYPE_E].data = SX_TRAP_TYPE_STR(
                trap_id_counter_p->trap_type);

            if (trap_id_counter_p->trap_type == HOST_IFC_TRAP_TYPE_PACKET) {
                tocpu_byte_counters = trap_id_counter_p->u_trap_type.packet.tocpu_byte;
                tocpu_packet_counters = trap_id_counter_p->u_trap_type.packet.tocpu_packet;
                event_counters = 0;
            } else { /* HOST_IFC_TRAP_TYPE_EVENT */
                tocpu_byte_counters = 0;
                tocpu_packet_counters = 0;
                event_counters = trap_id_counter_p->u_trap_type.event.event_counter;
                drop_counters = trap_id_counter_p->u_trap_type.event.drop_counter;
            }

            trap_id_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_ID_COUNTERS_TOCPU_PACKET_E].data =
                &tocpu_packet_counters;
            trap_id_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_ID_COUNTERS_TOCPU_BYTE_E].data =
                &tocpu_byte_counters;
            trap_id_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_ID_COUNTERS_EVENT_E].data = &event_counters;
            trap_id_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_ID_COUNTERS_DROP_E].data = &drop_counters;

            /* set string line */
            memset(trap_id_str, 0, sizeof(trap_id_str));
            strncpy(trap_id_str,  sx_host_ifc_trap_id_str(trap_id_counter_p->trap_id), sizeof(trap_id_str));

            dbg_utils_pprinter_table_data_line_print(stream, trap_id_counters_entries_dump_clmns);
        }
    }

    dbg_utils_pprinter_secondary_header_print(stream, "HOST IFC TRAP GROUP COUNTERS");

    dbg_utils_pprinter_field_print(stream, "Total trap groups:", &host_ifc_cnt.trap_group_counters_cnt,
                                   PARAM_UINT32_E);

    dbg_utils_pprinter_print(stream, "\n");

    if (host_ifc_cnt.trap_group_counters_cnt > 0) {
        dbg_utils_pprinter_table_headline_print(stream, trap_group_counters_entries_dump_clmns);

        for (i = 0; i < host_ifc_cnt.trap_group_counters_cnt; i++) {
            trap_group_counter_p = &host_ifc_cnt.trap_group_counters[i];
            trap_group_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_GROUP_COUNTERS_TRAP_GROUP_E].data =
                &trap_group_counter_p->trap_group;
            trap_group_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_GROUP_COUNTERS_EVENT_E].data =
                &trap_group_counter_p->event_counter;
            trap_group_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_GROUP_COUNTERS_TOCPU_PACKET_E].data =
                &trap_group_counter_p->tocpu_packet;
            trap_group_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_GROUP_COUNTERS_TOCPU_BYTE_E].data =
                &trap_group_counter_p->tocpu_byte;
            trap_group_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_GROUP_COUNTERS_TOCPU_BUFFER_DROP_E].data =
                &trap_group_counter_p->tocpu_buffer_drop;
            trap_group_counters_entries_dump_clmns[DBG_HOST_IFC_TRAP_GROUP_COUNTERS_POLICER_VIOLATION_COUNTER_E].data =
                &trap_group_counter_p->tocpu_drop_exceed_rate_packet.violation_counter;

            dbg_utils_pprinter_table_data_line_print(stream, trap_group_counters_entries_dump_clmns);
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t is_truncate_profile_used_by_any_trap(sx_trap_truncate_profile_id_t trunc_profile_id,
                                                 boolean_t                    *used,
                                                 char                        * buf,
                                                 uint16_t                      len)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    sx_trap_id_t                  trap_id = 0;
    host_ifc_trap_id_properties_t trap_id_properties;
    int                           pos = 0;

    *used = FALSE;
    if (buf) {
        *buf = 0;
    }

    for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
        rc = host_ifc_db_trap_id_properties_get(trap_id, &trap_id_properties);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get trap ID properties from DB for "
                       "trap id (0x%x), return value: [%s].\n", trap_id, sx_status_str(rc));
            goto out;
        }

        if (trap_id_properties.hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
            continue;
        }

        if (trap_id_properties.tr_en && (trap_id_properties.tr_prof == trunc_profile_id)) {
            *used = TRUE;
            if (buf) {
                pos += snprintf(buf + pos, len - pos, "%d ",  trap_id);
            }
        }
    }

out:
    return rc;
}

sx_status_t is_truncate_profile_used_by_any_trap_group(sx_trap_truncate_profile_id_t trunc_profile_id,
                                                       boolean_t                    *usesd,
                                                       char                        * buf,
                                                       uint16_t                      len)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_configured;
    uint32_t                         num_trap_groups = 0;
    uint32_t                         hw_trap_group;
    uint32_t                         swid = 0, swid_num = 0;
    int                              pos = 0;

    if (buf) {
        *buf = 0;
    }
    rc = host_ifc_hw_trap_group_num_get(&num_trap_groups);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get number of HW trap groups, return value: [%s]\n",
                   sx_status_str(rc));
    }
    rc = port_swid_list_get(SX_ACCESS_CMD_COUNT, NULL, &swid_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve "
                   "number of SWIDs (%s).\n", sx_status_str(rc));
        goto out;
    }
    for (swid = 0; swid < swid_num; swid++) {
        for (hw_trap_group = 0;
             hw_trap_group < num_trap_groups;
             hw_trap_group++) {
            rc = host_ifc_db_trap_group_properties_get(swid,
                                                       hw_trap_group,
                                                       &trap_group_properties,
                                                       &is_configured);
            if (rc) {
                SX_LOG_ERR("Failed to get trap group properties from the DB,"
                           " for (%u) HW trap group return value: [%s].\n",
                           hw_trap_group, sx_status_str(rc));
                continue;
            }

            if (is_configured && (trap_group_properties.truncate_mode == SX_TRUNCATE_MODE_PROFILE_ENABLE) &&
                (trap_group_properties.trunc_profile_id == trunc_profile_id)) {
                *usesd = TRUE;
                if (buf) {
                    pos += snprintf(buf + pos, len - pos, "%d ",  hw_trap_group);
                }
            }
        }
    }

out:
    return rc;
}


sx_status_t host_ifc_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    uint32_t                        i = 0, swid_num = 0;
    sx_swid_t                      *swid_list_p = NULL;
    FILE                           *stream = NULL;
    host_ifc_internal_trap_groups_t internal_trap_groups;
    uint32_t                        control_trap_group;
    char                           *invalid_trap_group_str = "N/A";
    host_ifc_db_profile_cfg_t       host_ifc_db_profile_cfg;
    char                          * pr_buff = NULL;
    boolean_t                       is_used;
    uint32_t                        len = SX_TRAP_ID_MAX * STRLEN_UINT16;

    rc = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    SX_MEM_CLR(internal_trap_groups);

    /* get number of swids */
    rc = port_swid_list_get(SX_ACCESS_CMD_COUNT, NULL, &swid_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("host_ifc_dbg_generate_dump - Failed to retrieve "
                   "number of SWIDs (%s).\n", sx_status_str(rc));
        goto out;
    }

    /* allocate memory and get swids list */
    swid_list_p = (sx_swid_t*)cl_malloc(swid_num * sizeof(sx_swid_t));
    if (swid_list_p == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("host_ifc_dbg_generate_dump - Failed in memory allocation "
                   "(%s).\n",  sx_status_str(rc));
        goto out;
    }

    rc = port_swid_list_get(SX_ACCESS_CMD_GET, swid_list_p, &swid_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("host_ifc_dbg_generate_dump - Failed to retrieve SWIDs info (%s).\n",
                   sx_status_str(rc));
        goto out;
    }

    dbg_utils_pprinter_module_header_print(stream, "Host IFC Module");

    dbg_utils_pprinter_general_header_print(stream, "Host IFC - per SWID configuration");

    for (i = 0; i < swid_num; i++) {
        dbg_utils_pprinter_secondary_header_print(stream, "SWID %u", swid_list_p[i]);
        rc = __host_ifc_trap_group_dump(dbg_dump_params_p, swid_list_p[i]);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("host_ifc_dbg_generate_dump - Failed to dump "
                       "trap group table, err (%s).\n",  sx_status_str(rc));
        }
        rc = __host_ifc_hw_trap_group_dump(dbg_dump_params_p, swid_list_p[i]);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("host_ifc_dbg_generate_dump - Failed to dump "
                       "hw trap group table, err (%s).\n",  sx_status_str(rc));
        }
    }

    if (brg_context.spec_cb_g.host_ifc_trap_counters_dump_cb != NULL) {
        dbg_utils_pprinter_general_header_print(stream, "Host IFC - RDQ Tail drops");
        __host_ifc_rdq_tail_drops_dump(dbg_dump_params_p);
    }

    dbg_utils_pprinter_general_header_print(stream, "Host IFC - Trap ID Table");

    rc = __host_ifc_trap_id_dump(dbg_dump_params_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("host_ifc_dbg_generate_dump - Failed to dump "
                   "trap id table, err (%s).\n",  sx_status_str(rc));
    }

    if (brg_context.spec_cb_g.host_ifc_trap_counters_dump_cb != NULL) {
        dbg_utils_pprinter_general_header_print(stream, "Host IFC - Trap counters Table");

        rc = brg_context.spec_cb_g.host_ifc_trap_counters_dump_cb(dbg_dump_params_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("host_ifc_dbg_generate_dump - Failed to dump "
                       "trap counters table, err (%s).\n",  sx_status_str(rc));
        }
    }

    dbg_utils_pprinter_general_header_print(stream, "Host IFC - Channel Filters Table");

    rc = __host_ifc_trap_id_channel_filter_dump(dbg_dump_params_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__host_ifc_trap_id_channel_filter_dump - Failed to dump "
                   "channel filters table, err (%s).\n",  sx_status_str(rc));
    }

    dbg_utils_pprinter_secondary_header_print(stream, "Host IFC - RDQs");

    control_trap_group = __pci_profile_s.emad_rdq;

    dbg_utils_pprinter_field_print(stream, "Control trap group:", &control_trap_group, PARAM_UINT32_E);

    rc = host_ifc_internal_trap_groups_from_profile_get(&__pci_profile_s, &internal_trap_groups);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get internal trap groups, return value: [%s]\n",
                   sx_status_str(rc));
        goto out;
    }

    if (internal_trap_groups.mirror_trap_group != TRAP_GROUP_INVALID_ID) {
        dbg_utils_pprinter_field_print(stream,
                                       "Mirror trap group:",
                                       &internal_trap_groups.mirror_trap_group,
                                       PARAM_UINT8_E);
    } else {
        dbg_utils_pprinter_field_print(stream, "Mirror trap group:", invalid_trap_group_str, PARAM_STRING_E);
    }

    if (internal_trap_groups.accuflow_trap_group != TRAP_GROUP_INVALID_ID) {
        dbg_utils_pprinter_field_print(stream, "Accumulated trap group:", &internal_trap_groups.accuflow_trap_group,
                                       PARAM_UINT8_E);
    } else {
        dbg_utils_pprinter_field_print(stream, "Accumulated trap group:", invalid_trap_group_str, PARAM_STRING_E);
    }
    if (internal_trap_groups.mocs_trap_group != TRAP_GROUP_INVALID_ID) {
        dbg_utils_pprinter_field_print(stream, "MOCS trap group:", &internal_trap_groups.mocs_trap_group,
                                       PARAM_UINT8_E);
    } else {
        dbg_utils_pprinter_field_print(stream, "MOCS trap group:", invalid_trap_group_str, PARAM_STRING_E);
    }

    dbg_utils_pprinter_general_header_print(stream, "Host truncation profile Table");

    pr_buff = (char *)cl_malloc(len);
    if (pr_buff == NULL) {
        SX_LOG_ERR("Failed to malloc memory");
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }


    for (i = 0; i <= SX_TRAP_TRUNCATE_PROFILE_MAX; i++) {
        rc = host_ifc_db_profile_cfg_get(i, &host_ifc_db_profile_cfg);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "host_ifc_db_profile_cfg_get failed: [%s].\n",
                   SX_STATUS_MSG(rc));
            goto out;
        }
        dbg_utils_pprinter_secondary_header_print(stream, "Profile %d", i);
        dbg_utils_pprinter_field_print(stream, "Size:", &host_ifc_db_profile_cfg.cfg.truncate_size,
                                       PARAM_UINT16_E);
        dbg_utils_pprinter_field_print(stream, "Created:", &host_ifc_db_profile_cfg.created,
                                       PARAM_BOOL_E);

        rc = is_truncate_profile_used_by_any_trap(i, &is_used, pr_buff, len);
        if (rc) {
            SX_LOG_ERR("is_truncate_profile_used_by_any_trap failed %s", sx_status_str(rc));
            goto out;
        }
        dbg_utils_pprinter_field_print(stream, "Used by trap:", pr_buff, PARAM_STRING_E);

        rc = is_truncate_profile_used_by_any_trap_group(i, &is_used, pr_buff, len);
        if (rc) {
            SX_LOG_ERR("is_truncate_profile_used_by_any_trap_group failed %s", sx_status_str(rc));
            goto out;
        }

        dbg_utils_pprinter_field_print(stream, "Used by trap group:", pr_buff, PARAM_STRING_E);
    }
out:
    if (pr_buff) {
        cl_free(pr_buff);
    }

    if (swid_list_p) {
        cl_free(swid_list_p);
    }

    return rc;
}


sx_status_t sx_host_ifc_handle_htgt(sx_device_id_t                      device_id,
                                    sx_swid_id_t                        swid,
                                    sx_trap_group_t                     trap_group,
                                    sxd_host_interface_path_type_e     *path_type_p,
                                    sxd_host_interface_path_t          *host_path_p,
                                    boolean_t                          *policer_enabled_p,
                                    sx_policer_id_t                    *policer_id_p,
                                    sx_trap_priority_t                 *priority_p,
                                    sxd_host_interface_mirror_action_t *mirror_action_p,
                                    sx_span_session_id_int_t           *mirror_agent_p,
                                    sx_span_probability_rate_t         *mirror_probability_rate_p)
{
    return __handle_htgt(device_id,
                         swid,
                         trap_group,
                         path_type_p,
                         host_path_p,
                         policer_enabled_p,
                         policer_id_p,
                         priority_p,
                         mirror_action_p,
                         mirror_agent_p,
                         mirror_probability_rate_p);
}

sx_status_t sdk_host_ifc_handle_htgt(sx_device_id_t                      device_id,
                                     sx_swid_id_t                        swid,
                                     sx_trap_group_t                     trap_group,
                                     sxd_host_interface_path_type_e     *path_type_p,
                                     sxd_host_interface_path_t          *host_path_p,
                                     boolean_t                          *policer_enabled_p,
                                     sx_policer_id_t                    *policer_id_p,
                                     sx_trap_priority_t                 *priority_p,
                                     sxd_host_interface_mirror_action_t *mirror_action_p,
                                     sx_span_session_id_int_t           *mirror_agent_p,
                                     sx_span_probability_rate_t         *mirror_probability_rate_p)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS, rb_status = SX_STATUS_SUCCESS;
    policer_manager_index_t        policer_hw_id = 0;
    policer_manager_block_length_t policer_size = 0;
    sx_policer_id_t                policer_id = 0;

    SX_LOG_ENTER();

    if (*policer_enabled_p == TRUE) {
        rc = policer_manager_handle_lock(*policer_id_p,
                                         POLICER_MANAGER_TYPE_HOST_IFC_E,
                                         &policer_hw_id,
                                         &policer_size);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in policer_manager_handle_lock : error (%s)\n", sx_status_str(rc));
            goto out;
        }
    }

    SX_POLICER_PID_SET(policer_id, policer_hw_id);

    rc = __handle_htgt(device_id,
                       swid,
                       trap_group,
                       path_type_p,
                       host_path_p,
                       policer_enabled_p,
                       &policer_id,
                       priority_p,
                       mirror_action_p,
                       mirror_agent_p,
                       mirror_probability_rate_p);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set HTGT register, [trap_group = %u], return value: [%s].\n",
                   trap_group, sx_status_str(rc));
        goto out;
    }

out:
    if (*policer_enabled_p == TRUE) {
        rb_status = policer_manager_handle_release(*policer_id_p,
                                                   POLICER_MANAGER_TYPE_HOST_IFC_E);
        if (SX_CHECK_FAIL(rb_status)) {
            SX_LOG_ERR("Error in policer_manager_handle_release : error (%s)\n", sx_status_str(rb_status));
        }
    }
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __validate_trap_control_allowed_for_trap_group(sx_swid_t         swid,
                                                                  sx_trap_group_t   trap_group,
                                                                  sx_control_type_t control_type)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_trap_id_t                  trap_id = 0;
    uint32_t                      hw_trap_group = 0;
    host_ifc_trap_id_properties_t trap_id_properties;

    SX_LOG_ENTER();
    SX_MEM_CLR(trap_id_properties);

    /* default control type and disabled are valid for all traps */
    if ((control_type == SX_CONTROL_TYPE_DEFAULT) ||
        (control_type == SX_CONTROL_TYPE_DISABLE)) {
        goto out;
    }

    err = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get trap group %u HW trap group for swid %u, return value: [%s]\n",
                   trap_group, swid, sx_status_str(err));
        goto out;
    }

    for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
        err = host_ifc_db_trap_id_properties_get(trap_id,
                                                 &trap_id_properties);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get trap ID %u properties, return value: [%s]\n",
                       trap_id, sx_status_str(err));
            continue;
        }
        /*hw_trap_group 0 uses as a group for default action,
         * in this case we have different control_type for every trap
         */
        if (hw_trap_group == 0) {
            goto out;
        }
        if (trap_id_properties.hw_trap_group == hw_trap_group) {
            err = trap_id_control_type_valid(trap_id, control_type);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed verifying trap id %u is valid for control type %u, return value: [%s]\n",
                           trap_id, control_type, sx_status_str(err));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __lcl_port_uc_route_get(sx_port_id_t port_id, sx_port_ucroute_id_t *ucroute_id_p)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sxd_status_t sxd_err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG_DBG("Attempt to Retrieve UC-Route of Port 0x%08X\n", port_id);

    if (SX_PORT_PHY_ID_GET(port_id) == CPU_PORT_PHY_ID) {
        /* Build CPU port route*/
        *ucroute_id_p = UCROUTE_CPU_PORT_PREFIX;
        *ucroute_id_p |= SX_PORT_DEV_ID_GET(port_id) << UCROUTE_CPU_DEV_BIT_OFFSET;
    } else {
        sxd_err = sxd_dpt_get_uc_route_by_local_port(SX_PORT_DEV_ID_GET(port_id),
                                                     SX_PORT_PHY_ID_GET(port_id),
                                                     ucroute_id_p);
        if (sxd_err != SXD_STATUS_SUCCESS) {
            err = sxd_status_to_sx_status(sxd_err);
            SX_LOG_ERR("Failed to get UC route by port 0x08%x, sxd_err = [%s]\n",
                       port_id, SXD_STATUS_MSG(sxd_err));
            goto out;
        }
    }

    SX_LOG_DBG("Succeeded to retrieve UC-Route of port 0x%08x = 0x%04x\n",
               port_id, *ucroute_id_p);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __trap_id_register_validate(sx_swid_t swid, sx_trap_id_t trap_id)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    sx_trap_action_t hw_action;
    sx_trap_group_t  trap_group;

    SX_LOG_ENTER();

    /* validate there is a trap group associated with the trap_id,
     * for some SW events this is not required */
    if (!SX_TRAP_ID_ACL_CHECK_RANGE(trap_id) &&
        !SX_TRAP_ID_IPTRAP_CHECK_RANGE(trap_id) &&
        (SX_TRAP_ID_SW_CHECK_RANGE(trap_id) &&
         (trap_id != SX_TRAP_ID_FDB_EVENT) &&
         (trap_id != SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT) &&
         (trap_id != SX_TRAP_ID_SDK_HEALTH_EVENT))) {
        err = host_ifc_trap_id_get(trap_id, swid, &hw_action, &trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get trap ID %u on SWID %u, err = [%s]\n",
                       trap_id, swid, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_trap_id_register_set(sx_access_cmd_t          cmd,
                                          sx_swid_t                swid,
                                          sx_trap_id_t             vtrap,
                                          const sx_user_channel_t *user_channel,
                                          const pid_t              client_pid,
                                          sx_trap_id_t            *trap_id_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sxd_status_t               sxd_err = SXD_STATUS_SUCCESS;
    sx_host_ifc_register_key_t register_key;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    SX_MEM_CLR(register_key);

    if (utils_check_pointer(user_channel, "user_channel")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(trap_id_p, "trap_id_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    sxd_err = sxd_dpt_vtrap_virt_to_hw_mapping_get(vtrap, trap_id_p);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = sxd_status_to_sx_status(sxd_err);
        SX_LOG_ERR("Failed to convert trap ID %u to HW trap ID, sxd_err = [%s]\n",
                   vtrap, SXD_STATUS_MSG(sxd_err));
        goto out;
    }

    if (trap_id_is_event(*trap_id_p) &&
        (user_channel->type != SX_USER_CHANNEL_TYPE_FD)) {
        SX_LOG_ERR("Trap ID %u is an event. It's possible to register to events on a file descriptor only.\n",
                   vtrap);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = __trap_id_register_validate(swid, *trap_id_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in __trap_id_register, trap id: [%u], return value: [%s]\n",
                   *trap_id_p, sx_status_str(err));
        goto out;
    }

    err = host_ifc_db_trap_id_register_set(cmd,
                                           swid,
                                           vtrap,
                                           user_channel,
                                           client_pid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_db_trap_id_register_set failed, [trap_id = %u], err = [%s]\n", vtrap,
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_trap_id_register_get(const sx_access_cmd_t    cmd,
                                          const sx_swid_t          swid,
                                          const sx_trap_id_t       trap_id,
                                          const sx_user_channel_t *user_channel,
                                          const pid_t              client_pid,
                                          sx_user_channel_t       *user_channel_list_p,
                                          uint32_t                *user_channel_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    err = host_ifc_db_trap_id_register_get(cmd,
                                           swid,
                                           trap_id,
                                           user_channel,
                                           client_pid,
                                           user_channel_list_p,
                                           user_channel_cnt_p);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_db_trap_id_register_get failed, [trap_id = %u], return value: [%s].\n",
                   trap_id, sx_status_str(err));
    }

    return __SX_LOG_EXIT(err);
}


sx_status_t host_ifc_port_vlan_trap_id_register_set(sx_access_cmd_t                   cmd,
                                                    sx_swid_t                         swid,
                                                    sx_trap_id_t                      vtrap,
                                                    const sx_host_ifc_register_key_t *register_key_p,
                                                    const sx_user_channel_t          *user_channel_p,
                                                    const pid_t                       client_pid,
                                                    sx_port_ucroute_id_t             *sys_port_p)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sxd_status_t sxd_err = SXD_STATUS_SUCCESS;
    sx_trap_id_t trap_id = 0;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    if (utils_check_pointer(register_key_p, "register_key")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(user_channel_p, "user_channel")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(sys_port_p, "sys_port_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Validate Port */
    VALIDATE_PORT(host_ifc_port_vlan_trap_id_register_set, register_key_p->key_value.port_id);

    sxd_err = sxd_dpt_vtrap_virt_to_hw_mapping_get(vtrap, &trap_id);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = sxd_status_to_sx_status(sxd_err);
        SX_LOG_ERR("Failed to convert trap ID %u to HW trap ID, sxd_err = [%s]\n",
                   vtrap,
                   SXD_STATUS_MSG(sxd_err));
        goto out;
    }

    if (trap_id_is_event(trap_id) &&
        (user_channel_p->type != SX_USER_CHANNEL_TYPE_FD)) {
        SX_LOG_ERR("Trap ID %u is an event. It's possible to register to events on a file descriptor only.\n",
                   vtrap);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /****** configure HW according to trap ID ******/
    err = __trap_id_register_validate(swid, trap_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in __configure_trap, trap id: [%u], err = [%s]\n",
                   trap_id, sx_status_str(err));
    }

    if (register_key_p->key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_PORT) {
        if (SX_PORT_TYPE_ID_GET(register_key_p->key_value.port_id) != SX_PORT_TYPE_LAG) {
            err = __lcl_port_uc_route_get(register_key_p->key_value.port_id,
                                          sys_port_p);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed translating logical port 0x%x to system port, err = [%s]\n",
                           register_key_p->key_value.port_id,
                           sx_status_str(err));
                goto out;
            }
        }
    }

    err = host_ifc_db_port_vlan_trap_id_register_set(cmd,
                                                     swid,
                                                     vtrap,
                                                     register_key_p,
                                                     user_channel_p,
                                                     client_pid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_db_port_vlan_trap_id_register_set failed, [trap_id = %u], err = [%s]\n",
                   vtrap,
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_port_vlan_trap_id_register_get(const sx_access_cmd_t                   cmd,
                                                    const sx_swid_t                         swid,
                                                    const sx_trap_id_t                      trap_id,
                                                    const sx_host_ifc_register_get_entry_t *register_entry,
                                                    const pid_t                             client_pid,
                                                    sx_host_ifc_register_get_entry_t       *register_entry_list_p,
                                                    uint32_t                               *register_entry_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    err = host_ifc_db_port_vlan_trap_id_register_get(cmd,
                                                     swid,
                                                     trap_id,
                                                     register_entry,
                                                     client_pid,
                                                     register_entry_list_p,
                                                     register_entry_cnt_p);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_db_port_vlan_trap_id_register_get failed, [trap_id = %u], return value: [%s].\n",
                   trap_id, sx_status_str(err));
    }

    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_remove_fd_user_channels(const sx_fd_t *fd_p, const pid_t client_pid)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        return __SX_LOG_EXIT(SX_STATUS_SUCCESS);
    }

    err = host_ifc_db_remove_fd_user_channels(fd_p, client_pid);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_db_remove_fd_user_channels failed, return value: [%s].\n",
                   sx_status_str(err));
    }

    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_open(int *fd_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    int         sxd_err = 0;
    char        dev_name[2][MAX_NAME_LEN];
    char       *dev[1];
    uint32_t    dev_num = 1;

    SX_LOG_ENTER();

    if (fd_p == NULL) {
        SX_LOG_ERR("NULL file descriptor\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    dev[0] = dev_name[0];

    /* get device list from the devices directory */
    sxd_err = sxd_get_dev_list(dev, &dev_num);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed to get device list, errno = [%s]\n",
                   strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    sxd_err = sxd_open_device_ext(dev_name[0], fd_p);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed to open device %s, errno = [%s]\n", dev_name[0],
                   strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_close(int fd)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    int         sxd_err = 0;

    SX_LOG_ENTER();

    sxd_err = sxd_close_device_ext(fd);
    if (sxd_err != 0) {
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        SX_LOG_ERR("Failed to close FD %d, sxd_err = [%d], errno = [%s]\n",
                   fd, sxd_err, strerror(errno));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static void __host_ifc_close_threads(void)
{
    /* Stop polling and event thread for PUDE and PMPE */
    if (is_timer_threads_and_event_created_s) {
        recv_events_handler_exit_signal_issued = TRUE;
        host_ifc_recv_events_handler_wakeup();
        cl_thread_destroy(&recv_thread_id);

        event_timer_handler_exit_signal_issued = TRUE;
        if (cl_fd_signal(__sx_event_fd)) {
            SX_LOG_ERR("Failed writing to the PIPE of host ifc timer thread in order to close him \n");
        }
        stop_event_thread_s = 1;
        cl_thread_destroy(&timer_thread_id);
        close(__sx_event_fd);

        timer_thread_id.osd.id = (pthread_t)NULL;
        recv_thread_id.osd.id = (pthread_t)NULL;
        is_timer_threads_and_event_created_s = 0;
        host_ifc_event_timer_handler_thread_init_called = FALSE;
    }

    return;
}

sx_status_t host_ifc_pause(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    int         ret = 0;

    SX_LOG_ENTER();

    __host_ifc_close_threads();

    /* close sxd */
    ret = sxd_close_device(ev_thread_params_s.sxd_h);
    if (ret) {
        SX_LOG_ERR("sxd_close_device error: %s\n", strerror(errno));
        err = SXD_STATUS_TO_SX_STATUS(SXD_STATUS_DEVICE_CLOSE_ERROR);
        goto out;
    }

    /* close sxd for sw events generation */
    ret = sxd_close_device(sw_event_sxd_h);
    if (ret) {
        SX_LOG_ERR("sxd_close_device error: %s\n", strerror(errno));
        err = SXD_STATUS_TO_SX_STATUS(SXD_STATUS_DEVICE_CLOSE_ERROR);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_resume(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    cl_status_t cl_err = CL_SUCCESS;
    int         swid = 0;

    SX_LOG_ENTER();

    stop_event_thread_s = 0;
    recv_events_handler_exit_signal_issued = FALSE;
    event_timer_handler_exit_signal_issued = FALSE;

    /* create the event_timer_thread */
    if (0 == is_timer_threads_and_event_created_s) {
        cl_err = cl_fd_init(&__sx_event_fd);
        if (cl_err != CL_SUCCESS) {
            SX_LOG_ERR("Could not initialize event fd for host ifc resume timer thread\n");
            err = SX_STATUS_ERROR;
            goto out;
        }

        cl_err = cl_thread_init(&timer_thread_id,
                                __host_ifc_resume_timer_thread,
                                (void*)&ev_thread_params_s,
                                "hIfcRsmTmr", THREAD_MAX_ALLOWED_TIME_DEFAULT);
        if (cl_err != CL_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not create __host_ifc_resume_timer_thread thread\n");
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }

        host_ifc_event_timer_handler_thread_init_called = TRUE;

        /* open sxd */
        __host_ifc_open_sxd_for_event_recv(&ev_thread_params_s.sxd_h);

        /* open sxd for sw events generation */
        __host_ifc_open_sxd_for_event_recv(&sw_event_sxd_h);

        /* register on events which need rearming */
        for (swid = 0; swid < NUMBER_OF_SWIDS; swid++) {
            /* Add PUDE listener on each swid */
            err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, ev_thread_params_s.sxd_h, swid, SX_TRAP_ID_PUDE,
                                          (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                           SX_TRAP_ID_PUDE, sx_status_str(err));
                break;
            }

            /* Add HEALTH_CHECK listener on each swid */
            err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD,
                                          ev_thread_params_s.sxd_h,
                                          swid,
                                          SX_TRAP_ID_SDK_HEALTH_EVENT,
                                          (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                           SX_TRAP_ID_SDK_HEALTH_EVENT, sx_status_str(err));
                break;
            }

            /* Add PMPE listener on each swid if management lib module support is enabled */
            err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, ev_thread_params_s.sxd_h, swid, SX_TRAP_ID_PMPE,
                                          (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                           SX_TRAP_ID_PMPE, sx_status_str(err));
                break;
            }

            /* Add MFDE listener on each swid */
            err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD,
                                          ev_thread_params_s.sxd_h,
                                          swid,
                                          (sx_trap_id_t)SXD_TRAP_ID_MFDE,
                                          (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                           SXD_TRAP_ID_MFDE, sx_status_str(err));
                break;
            }
            /* Add FSHE listener on each swid */
            err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD,
                                          ev_thread_params_s.sxd_h,
                                          swid,
                                          (sx_trap_id_t)SXD_TRAP_ID_FSHE,
                                          (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                           SXD_TRAP_ID_FSHE, sx_status_str(err));
                break;
            }
            /* Add FSED listener on each swid */
            err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD,
                                          ev_thread_params_s.sxd_h,
                                          swid,
                                          (sx_trap_id_t)SXD_TRAP_ID_FSED,
                                          (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                           SXD_TRAP_ID_FSED, sx_status_str(err));
                break;
            }
            /* Add MOCS_DONE listener on each swid */
            err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD,
                                          ev_thread_params_s.sxd_h,
                                          swid,
                                          (sx_trap_id_t)SXD_TRAP_ID_MOCS_DONE,
                                          (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                           SXD_TRAP_ID_MOCS_DONE, sx_status_str(err));
                break;
            }

            /* Add MECCC listener on each swid */
            err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD,
                                          ev_thread_params_s.sxd_h,
                                          swid,
                                          (sx_trap_id_t)SXD_TRAP_ID_MECCC,
                                          (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                           SXD_TRAP_ID_MECCC, sx_status_str(err));
                break;
            }

            /* Add IPAC_DONE listener on each swid */
            err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD,
                                          ev_thread_params_s.sxd_h,
                                          swid,
                                          (sx_trap_id_t)SXD_TRAP_ID_IPAC_DONE,
                                          (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                           SXD_TRAP_ID_IPAC_DONE, sx_status_str(err));
                break;
            }
        }

        err = __host_ifc_listener_set(SX_ACCESS_CMD_ADD, ev_thread_params_s.sxd_h, SWID_NUM_DONT_CARE,
                                      SX_TRAP_ID_SIGNAL, (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_WRN("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                       SX_TRAP_ID_SIGNAL, sx_status_str(err));
        }

        cl_err = cl_thread_init(&recv_thread_id, __host_ifc_recv_events_handler,
                                (void*)&ev_thread_params_s, "hIfcRsmEvents", THREAD_MAX_ALLOWED_TIME_DEFAULT);
        if (cl_err != CL_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not create __host_ifc_recv_events_handler thread\n");
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }
    }   /* if (0 == is_timer_threads_and_event_created) { */

    is_timer_threads_and_event_created_s = 1;

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __host_ifc_trap_id_properties_validate(sx_swid_t        swid,
                                                          sx_trap_id_t     trap_id,
                                                          sx_trap_group_t  trap_group,
                                                          sx_trap_action_t trap_action)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_hw_trap_group_e               hw_trap_group = SX_HW_TRAP_GROUP_0_E;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_trap_group_configured;
    boolean_t                        tac_is_trap_bind_allowed;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    /* inputs check */
    rc = trap_id_is_supported_device(trap_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("trap_id_is_supported_device failed (%s)\n", sx_status_str(rc));
        goto out;
    }

    rc = trap_id_implicitly_set_by_sdk(trap_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("trap_id_implicitly_set_by_sdk failed (%s)\n", sx_status_str(rc));
        goto out;
    }

    rc = host_ifc_check_trap_action(trap_action);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    rc = trap_id_allowed_trap_action(trap_id, trap_action);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("The trap ID %u cannot be configured to action %u, error: %s\n",
                   trap_id, trap_action, sx_status_str(rc));
        goto out;
    }

    rc = trap_id_conflicts_check(trap_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("The trap ID %u conflicts with previously configured trap.(%s)\n", trap_id, sx_status_str(rc));
        goto out;
    }

    /* trap group -> HW trap group */
    rc = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
        SX_LOG(SX_LOG_ERROR, "Trap group [%u] was not initialized for swid [%u]\n",
               trap_group, swid);
        rc = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    /* TAC validation that traps can't be bound to Trap Group with TAC enable if TAC wasn't connected to this trap group */
    /* Get trap priority DB parameters */
    rc = host_ifc_db_trap_group_properties_get(swid,
                                               hw_trap_group,
                                               &trap_group_properties,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to fetch trap group properties from DB, [hw_trap_group = %u], return value: [%s].\n",
                   hw_trap_group, sx_status_str(rc));
        goto out;
    }

    if ((trap_group < (SX_TRAP_GROUP_MAX + 1)) &&
        (is_trap_group_configured == TRUE) &&
        (trap_group_properties.is_tac_capable == TRUE)) {
        /* Events are not allowed to be bound to TAC capable trap groups */
        if (trap_id_is_event(trap_id)) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR(
                "Events (event id %d) are not allowed to be bound to TAC capable trap groups (%d), return value: [%s].\n",
                trap_id,
                trap_group,
                sx_status_str(rc));
            goto out;
        }

        rc = sdk_tele_impl_tac_is_trap_bind_allowed(trap_group,
                                                    &tac_is_trap_bind_allowed);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("sdk_tele_impl_tac_is_trap_bind_allowed failed for [trap_group = %u], return value: [%s].\n",
                       trap_group, sx_status_str(rc));
            goto out;
        }

        if (tac_is_trap_bind_allowed == FALSE) {
            rc = SX_STATUS_CMD_UNPERMITTED;
            SX_LOG_ERR(
                "Bind of traps to TAC capable trap group %d isn't allowed before the trap group will be connected to TAC.\n",
                trap_group);
            goto out;
        }
    }

    SX_LOG_DBG("Validated trap id: [%d], trap_group: [%u] trap action: [%d]. \n", trap_id, trap_group, trap_action);

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __host_ifc_trap_id_properties_prepare(sx_swid_t                         swid,
                                                         sx_trap_id_t                      trap_id,
                                                         sx_trap_group_t                   trap_group,
                                                         sx_trap_action_t                  trap_action,
                                                         host_ifc_trap_id_properties_t    *trap_id_properties_p,
                                                         host_ifc_trap_group_properties_t *trap_group_properties_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_hw_trap_group_e hw_trap_group = SX_HW_TRAP_GROUP_0_E;
    boolean_t          is_trap_group_configured = FALSE;

    SX_LOG_ENTER();

    /* trap group -> HW trap group */
    rc = host_ifc_db_trap_group_map_get(swid, trap_group, &hw_trap_group);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    rc = host_ifc_db_trap_id_properties_get(trap_id, trap_id_properties_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "host_ifc_db_trap_id_properties_get failed, [trap_id = %u], return value: [%s].\n",
               trap_id, sx_status_str(rc));
        goto out;
    }

    /* Get trap priority DB parameters */
    rc = host_ifc_db_trap_group_properties_get(swid,
                                               hw_trap_group,
                                               trap_group_properties_p,
                                               &is_trap_group_configured);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to fetch trap group properties from DB, [hw_trap_group = %u], return value: [%s].\n",
                   hw_trap_group, sx_status_str(rc));
        goto out;
    }

    /* Validity check - group configured */
    if (is_trap_group_configured == FALSE) {
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (trap_id_properties_p->hw_trap_group != 0) {
        rc = trap_id_control_type_valid(trap_id_properties_p->hw_trap_id, trap_group_properties_p->control_type);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed verifying trap id %u is valid for control type %u, return value: [%s]\n",
                       trap_id, trap_group_properties_p->control_type, sx_status_str(rc));
            goto out;
        }
    }

    rc = trap_id_conflicts_check(trap_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("The trap ID %u conflicts with previously configured trap.(%s)\n", trap_id, sx_status_str(rc));
        goto out;
    }

    trap_id_properties_p->hw_trap_group = hw_trap_group;
    trap_id_properties_p->trap_action = trap_action;
    trap_id_properties_p->control_type = trap_group_properties_p->control_type;
    trap_id_properties_p->tr_en = (trap_group_properties_p->truncate_mode == SX_TRUNCATE_MODE_PROFILE_ENABLE);
    trap_id_properties_p->tr_prof = trap_group_properties_p->trunc_profile_id;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __host_ifc_trap_id_is_group_associated_get(sx_trap_id_t trap_id,
                                                              boolean_t   *is_regular_group_bound_p,
                                                              boolean_t   *is_monitor_group_bound_p,
                                                              boolean_t   *is_tac_capable_group_bound_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_trap_group_t                  trap_groups[SX_TRAP_ID_MAX + 1];
    uint32_t                         trap_group_cnt = 0;
    uint32_t                         i = 0;
    host_ifc_trap_group_properties_t trap_group_properties;
    boolean_t                        is_regular_associated = FALSE;
    boolean_t                        is_monitor_associated = FALSE;
    boolean_t                        is_tac_capable_associated = FALSE;
    boolean_t                        is_monitor = FALSE;
    boolean_t                        is_tac_capable = FALSE;
    sx_hw_trap_group_e               hw_trap_group = SX_HW_TRAP_GROUP_MIN_E;
    sx_trap_action_t                 trap_action = SX_TRAP_ACTION_MIN;

    SX_LOG_ENTER();

    SX_MEM_CLR(trap_group_properties);

    rc = host_ifc_db_trap_id_to_group_associate_get(trap_id, trap_groups, NULL, &trap_group_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap ID associated groups from DB for "
                   "trap id (0x%x), return value: [%s].\n", trap_id, sx_status_str(rc));
        goto out;
    }

    for (i = 0; i < trap_group_cnt; i++) {
        if (trap_groups[i] == (TRAP_GROUP_ID_MAX + 1)) {
            continue;
        }

        rc = host_ifc_db_trap_group_associated_attr_get(trap_id,
                                                        trap_groups[i],
                                                        &hw_trap_group,
                                                        &trap_action,
                                                        &is_monitor,
                                                        &is_tac_capable);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get trap group properties from DB for "
                       "trap id (0x%x), trap group (%u), return value: [%s].\n",
                       trap_id,
                       trap_groups[i],
                       sx_status_str(rc));
            goto out;
        }

        if ((is_monitor == FALSE) && (is_tac_capable == FALSE)) {
            /* at least single regular trap group is configured */
            is_regular_associated = TRUE;
        }

        if (is_monitor == TRUE) {
            is_monitor_associated = TRUE;
        }

        if (is_tac_capable == TRUE) {
            is_tac_capable_associated = TRUE;
        }
    }

    if (is_regular_group_bound_p) {
        *is_regular_group_bound_p = is_regular_associated;
    }

    if (is_monitor_group_bound_p) {
        *is_monitor_group_bound_p = is_monitor_associated;
    }

    if (is_tac_capable_group_bound_p) {
        *is_tac_capable_group_bound_p = is_tac_capable_associated;
    }

out:
    SX_LOG_ENTER();
    return rc;
}

/*
 * Trap ID can be bound to 1 regular and 1 special trap group only
 * So when is_special_trap_grp is TRUE we will return special Trap Group : monitor or "TAC capable"
 */
static sx_status_t __host_ifc_trap_group_associated_attr_get(uint32_t            trap_id,
                                                             boolean_t           is_special_trap_grp,
                                                             sx_hw_trap_group_e *hw_trap_group_p,
                                                             sx_trap_action_t   *trap_action_p)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    boolean_t       is_monitor = FALSE;
    boolean_t       is_tac_capable = FALSE;
    sx_trap_group_t trap_groups[SX_TRAP_ID_MAX + 1];
    uint32_t        trap_group_cnt = 0;
    uint32_t        i = 0;

    SX_LOG_ENTER();

    rc = host_ifc_db_trap_id_to_group_associate_get(trap_id, trap_groups, NULL, &trap_group_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get trap ID associated groups from DB for "
                   "trap id (0x%x), return value: [%s].\n", trap_id, sx_status_str(rc));
        goto out;
    }

    for (i = 0; i < trap_group_cnt; i++) {
        if (trap_groups[i] == (TRAP_GROUP_ID_MAX + 1)) {
            continue;
        }

        rc = host_ifc_db_trap_group_associated_attr_get(trap_id,
                                                        trap_groups[i],
                                                        hw_trap_group_p,
                                                        trap_action_p,
                                                        &is_monitor,
                                                        &is_tac_capable);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get trap group properties from DB for "
                       "trap id (0x%x), trap group (%u), return value: [%s].\n",
                       trap_id,
                       trap_groups[i],
                       sx_status_str(rc));
            goto out;
        }

        if ((is_monitor == is_special_trap_grp) ||
            (is_tac_capable == is_special_trap_grp)) {
            break;
        }
    }

out:
    SX_LOG_ENTER();
    return rc;
}


static sx_status_t __host_ifc_trap_id_update_driver(sx_access_cmd_t    cmd,
                                                    uint32_t           trap_id,
                                                    sx_hw_trap_group_e hw_trap_group)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    sxd_status_t                 sxd_err = SXD_STATUS_SUCCESS;
    struct ku_monitor_synd_ioctl monitor_synd_ioctl;
    sxd_ctrl_pack_t              ctrl_pack;

    SX_MEM_CLR(monitor_synd_ioctl);
    SX_MEM_CLR(ctrl_pack);

    SX_LOG_ENTER();

    /* update driver -> add/remove listener - to start/stop copying packets to SW buff of monitor RDQ */
    SX_LOG_DBG("\n%s: cmd: %s trap_id: 0x%x hw_trap_group: %u\n",
               __func__, sx_access_cmd_str(cmd), trap_id, hw_trap_group);

    monitor_synd_ioctl.swid = 0;
    monitor_synd_ioctl.cmd = (cmd == SX_ACCESS_CMD_SET) ? TRUE : FALSE;
    monitor_synd_ioctl.syndrome_num = trap_id;
    monitor_synd_ioctl.monitor_hw_trap_group = hw_trap_group;

    monitor_synd_ioctl.port_vlan_params.port_vlan_type = KU_PORT_VLAN_PARAMS_TYPE_GLOBAL;

    SX_API_GET_RELEVANT_PACKET_TYPE(trap_id, monitor_synd_ioctl.type);
    SX_API_GET_DROP_ENABLED(trap_id, monitor_synd_ioctl.critireas.dont_care.drop_enable);

    ctrl_pack.ctrl_cmd = CTRL_CMD_MONITOR_SW_QUEUE_SYND;

    ctrl_pack.cmd_body = (void*)&monitor_synd_ioctl;

    sxd_err = sxd_ioctl(ev_thread_params_s.sxd_h, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in sxd_ioctl add/remove monitor syndrome, err = [%u], errno = [%s]\n",
                   sxd_err, strerror(errno));
        rc = sxd_status_to_sx_status(sxd_err);
    }

    SX_LOG_ENTER();
    return rc;
}


static sx_status_t __host_ifc_trap_group_stat_get_from_driver(sx_access_cmd_t                cmd,
                                                              sx_hw_trap_group_e             hw_trap_group,
                                                              sxd_handle                     driver_handle,
                                                              sx_host_ifc_trap_group_stat_t *group_stat_p)
{
    sx_status_t                             rc = SX_STATUS_SUCCESS;
    sxd_status_t                            sxd_err = SXD_STATUS_SUCCESS;
    struct ku_monitor_trap_group_stat_ioctl monitor_trap_group_stat;
    sxd_ctrl_pack_t                         ctrl_pack;

    SX_MEM_CLR(monitor_trap_group_stat);
    SX_MEM_CLR(ctrl_pack);

    SX_LOG_ENTER();

    monitor_trap_group_stat.monitor_hw_trap_group = hw_trap_group;
    monitor_trap_group_stat.clear_after_read = (cmd == SX_ACCESS_CMD_READ) ? FALSE : TRUE;

    ctrl_pack.ctrl_cmd = CTRL_CMD_GET_RDQ_STAT;

    ctrl_pack.cmd_body = (void*)&monitor_trap_group_stat;

    sxd_err = sxd_ioctl(driver_handle, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("Failed in sxd_ioctl getting monitor statistics, err = [%s]\n",
                   strerror(errno));
        rc = sxd_status_to_sx_status(sxd_err);
    }

    /* return retrieved data to the user */
    group_stat_p->data.total_cnt = monitor_trap_group_stat.discarded_pkts_total_num;

    SX_LOG_ENTER();
    return rc;
}


static sx_status_t __trap_id_channel_filter_vtrap_validate(sx_swid_t                swid,
                                                           sx_trap_id_t             vtrap,
                                                           const sx_user_channel_t *user_channel_p)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sxd_status_t sxd_err = SXD_STATUS_SUCCESS;
    sx_trap_id_t trap_id = 0;

    SX_LOG_ENTER();

    sxd_err = sxd_dpt_vtrap_virt_to_hw_mapping_get(vtrap, &trap_id);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = sxd_status_to_sx_status(sxd_err);
        SX_LOG_ERR("Failed to convert trap ID %u to HW trap ID, sxd_err = [%s]\n",
                   vtrap,
                   SXD_STATUS_MSG(sxd_err));
        goto out;
    }

    if (trap_id_is_event(trap_id) &&
        (user_channel_p->type != SX_USER_CHANNEL_TYPE_FD)) {
        SX_LOG_ERR("Trap ID %u is an event. It's possible to receive events on a file descriptor only.\n",
                   vtrap);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = __trap_id_register_validate(swid, trap_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in __trap_id_register_validate, trap id: [%u], err = [%s]\n",
                   trap_id, sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __user_channel_filter_key_validate(const sx_host_ifc_filter_key_t *filter_key_p,
                                                      const sx_user_channel_t        *user_channel_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (filter_key_p->key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_PORT) {
        VALIDATE_PORT(host_ifc_trap_id_channel_filter_set, filter_key_p->key_value.port_id);
    }
    if ((user_channel_p->type == SX_USER_CHANNEL_TYPE_FD) &&
        (user_channel_p->channel.fd.valid == FALSE)) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_trap_id_channel_filter_set(sx_access_cmd_t                 cmd,
                                                sx_swid_t                       swid,
                                                sx_trap_id_t                    vtrap,
                                                const sx_host_ifc_filter_key_t *filter_key_p,
                                                const sx_user_channel_t        *user_channel_p,
                                                const pid_t                     client_pid,
                                                sx_port_ucroute_id_t           *sys_port_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initiated.\n");
        err = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }
    err = __user_channel_filter_key_validate(filter_key_p, user_channel_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    err = __trap_id_channel_filter_vtrap_validate(swid, vtrap, user_channel_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    if (utils_check_pointer(sys_port_p, "sys_port_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (filter_key_p->key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_PORT) {
        if (SX_PORT_TYPE_ID_GET(filter_key_p->key_value.port_id) != SX_PORT_TYPE_LAG) {
            err = __lcl_port_uc_route_get(filter_key_p->key_value.port_id,
                                          sys_port_p);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed translating logical port 0x%x to system port, err = [%s]\n",
                           filter_key_p->key_value.port_id,
                           sx_status_str(err));
                goto out;
            }
        }
    }

    err = host_ifc_db_trap_id_channel_filter_set(cmd,
                                                 swid,
                                                 vtrap,
                                                 filter_key_p,
                                                 user_channel_p,
                                                 client_pid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_db_trap_id_channel_filter_set failed, [trap_id = %u], err = [%s]\n",
                   vtrap,
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_internal_trap_groups_from_profile_get(sx_api_pci_profile_t            *pci_profile,
                                                           host_ifc_internal_trap_groups_t *internal_trap_groups_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (g_hwd_ops.host_ifc_internal_trap_groups_from_profile_get_pfn == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("g_hwd_ops.host_ifc_internal_trap_groups_from_profile_get_pfn is NULL [%s]\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = g_hwd_ops.host_ifc_internal_trap_groups_from_profile_get_pfn(pci_profile, internal_trap_groups_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("g_hwd_ops.host_ifc_internal_trap_groups_from_profile_get_pfn failed. [%s]\n",
                   sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t host_ifc_disable_accuflow_trap_group()
{
    sx_status_t ret = SX_STATUS_SUCCESS;

    if (g_hwd_ops.host_ifc_disable_accuflow_trap_group_pfn != NULL) {
        ret = (*g_hwd_ops.host_ifc_disable_accuflow_trap_group_pfn)();
    }
    return ret;
}

sx_status_t host_ifc_accuflow_counter_clear()
{
    sx_status_t ret = SX_STATUS_SUCCESS;

    if (g_hwd_ops.host_ifc_accuflow_counter_clear_pfn != NULL) {
        ret = (*g_hwd_ops.host_ifc_accuflow_counter_clear_pfn)();
    }
    return ret;
}

sx_status_t host_ifc_pps_trap_reg(void)
{
    sx_status_t ret = SX_STATUS_SUCCESS;

    if (g_hwd_ops.host_ifc_pps_trap_reg_pfn != NULL) {
        ret = (*g_hwd_ops.host_ifc_pps_trap_reg_pfn)();
    }
    return ret;
}

sx_status_t host_ifc_trap_id_channel_filter_get(const sx_access_cmd_t                         cmd,
                                                const sx_swid_t                               swid,
                                                const sx_trap_id_t                            trap_id,
                                                const sx_host_ifc_channel_filter_get_entry_t *channel_filter_entry,
                                                const pid_t                                   client_pid,
                                                sx_host_ifc_channel_filter_get_entry_t       *channel_filter_entry_list_p,
                                                uint32_t                                     *channel_filter_entry_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (__is_initialized_s == FALSE) {
        SX_LOG_ERR("HOST IFC module is not initiated.\n");
        err = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    err = host_ifc_db_trap_id_channel_filter_get(cmd,
                                                 swid,
                                                 trap_id,
                                                 channel_filter_entry,
                                                 client_pid,
                                                 channel_filter_entry_list_p,
                                                 channel_filter_entry_cnt_p);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_db_trap_id_channel_filter_get failed, [trap_id = %u], return value: [%s].\n",
                   trap_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_trap_truncate_profile_get_spectrum4(const sx_access_cmd_t               cmd,
                                                         const sx_trap_truncate_profile_id_t trunc_profile_id,
                                                         sx_trap_truncate_profile_cfg_t     *trunc_profile_cfg_p)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    host_ifc_db_profile_cfg_t host_ifc_db_profile_cfg;

    UNUSED_PARAM(cmd);

    if (!SX_TRAP_TRUNCATE_PROFILE_CHECK_RANGE(trunc_profile_id)) {
        SX_LOG_ERR("trunc_profile_id is out of range.\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    sx_status = host_ifc_db_profile_cfg_get(trunc_profile_id, &host_ifc_db_profile_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "host_ifc_db_profile_cfg_get failed: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    if (!host_ifc_db_profile_cfg.created) {
        SX_LOG(SX_LOG_INFO, "The truncation profile is not created.\n");
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    *trunc_profile_cfg_p = host_ifc_db_profile_cfg.cfg;
out:
    return sx_status;
}

sx_status_t host_ifc_trap_truncate_profile_get(const sx_access_cmd_t               cmd,
                                               const sx_trap_truncate_profile_id_t trunc_profile_id,
                                               sx_trap_truncate_profile_cfg_t     *trunc_profile_cfg_p)
{
    sx_status_t rc = SX_STATUS_UNSUPPORTED;

    if (brg_context.spec_cb_g.host_ifc_trap_truncate_profile_get_cb) {
        rc = brg_context.spec_cb_g.host_ifc_trap_truncate_profile_get_cb(cmd, trunc_profile_id,
                                                                         trunc_profile_cfg_p);
    } else {
        SX_LOG_ERR("Truncation profile is supported on spectrum4 and above.\n");
    }
    return rc;
}

sx_status_t host_ifc_trap_truncate_profile_set_spectrum4(const sx_access_cmd_t                 cmd,
                                                         const sx_trap_truncate_profile_id_t   trunc_profile_id,
                                                         const sx_trap_truncate_profile_cfg_t *trunc_profile_cfg_p)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    struct ku_hgcr_reg        hgcr_reg_data;
    host_ifc_db_profile_cfg_t host_ifc_db_profile_cfg;
    boolean_t                 is_used;
    char                    * pr_buff = NULL;
    uint32_t                  len = SX_TRAP_ID_MAX * STRLEN_UINT16;


    if (!SX_TRAP_TRUNCATE_PROFILE_CHECK_RANGE(trunc_profile_id)) {
        SX_LOG_ERR("trunc_profile_id is out of range.\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (((cmd == SX_ACCESS_CMD_EDIT) || (cmd == SX_ACCESS_CMD_CREATE))) {
        if (trunc_profile_cfg_p->truncate_size % SX_TRAP_TRUNCATE_PROFILE_GRANULARITY) {
            SX_LOG_ERR("truncate_size granularity is %d\n", SX_TRAP_TRUNCATE_PROFILE_GRANULARITY);
            sx_status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    sx_status = host_ifc_db_profile_cfg_get(trunc_profile_id, &host_ifc_db_profile_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "host_ifc_db_profile_cfg_get failed: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_EDIT) && (host_ifc_db_profile_cfg.created == FALSE)) {
        SX_LOG(SX_LOG_ERROR, "Please create the profile before edit it.\n");
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_CREATE) && host_ifc_db_profile_cfg.created) {
        SX_LOG(SX_LOG_WARNING, "The profile already exists.\n");
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_DESTROY) {
        /*check every trap group and trap to make sure no one is using the profile*/
        pr_buff = (char *)cl_malloc(len);
        if (pr_buff == NULL) {
            SX_LOG_ERR("Failed to malloc memory");
            sx_status = SX_STATUS_NO_MEMORY;
            goto out;
        }

        sx_status = is_truncate_profile_used_by_any_trap(trunc_profile_id,
                                                         &is_used,
                                                         pr_buff,
                                                         len);
        if (sx_status) {
            SX_LOG_ERR("is_truncate_profile_used_by_any_trap failed %s", sx_status_str(sx_status));
            goto out;
        }

        if (is_used) {
            SX_LOG(SX_LOG_ERROR, "The profile is used by trap %s \n", pr_buff);
            sx_status = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }

        sx_status = is_truncate_profile_used_by_any_trap_group(trunc_profile_id,
                                                               &is_used,
                                                               pr_buff,
                                                               len);
        if (sx_status) {
            SX_LOG_ERR("is_truncate_profile_used_by_any_trap_group failed%s", sx_status_str(sx_status));
            goto out;
        }

        if (is_used) {
            SX_LOG(SX_LOG_ERROR, "The profile is used by trap group %s \n", pr_buff);
            sx_status = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }

        host_ifc_db_profile_cfg.cfg.truncate_size = SX_TRAP_TRUNCATE_PROFILE_MAX_SIZE;
        host_ifc_db_profile_cfg.created = FALSE;
        sx_status = host_ifc_db_profile_cfg_set(trunc_profile_id, &host_ifc_db_profile_cfg);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "host_ifc_db_profile_cfg_set failed: [%s].\n",
                   SX_STATUS_MSG(sx_status));
        }
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_EDIT) {
        pr_buff = (char *)cl_malloc(len);
        if (pr_buff == NULL) {
            SX_LOG_ERR("Failed to malloc memory");
            sx_status = SX_STATUS_NO_MEMORY;
            goto out;
        }

        sx_status = is_truncate_profile_used_by_any_trap(trunc_profile_id,
                                                         &is_used,
                                                         pr_buff,
                                                         len);
        if (sx_status) {
            SX_LOG_ERR("is_truncate_profile_used_by_any_trap failed %s", sx_status_str(sx_status));
            goto out;
        }

        if (is_used) {
            SX_LOG(SX_LOG_ERROR, "The profile is used by trap %s \n", pr_buff);
            sx_status = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
    }

    /* read the HGCR */
    sx_status = __handle_hgcr(SXD_ACCESS_CMD_GET, &hgcr_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to get HGCR: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    switch (trunc_profile_id) {
    case SX_TRAP_TRUNCATE_PROFILE_0_E:
        hgcr_reg_data.truncation_size = trunc_profile_cfg_p->truncate_size;
        break;

    case SX_TRAP_TRUNCATE_PROFILE_1_E:
        hgcr_reg_data.truncation_size_prof1 = trunc_profile_cfg_p->truncate_size;
        break;

    case SX_TRAP_TRUNCATE_PROFILE_2_E:
        hgcr_reg_data.truncation_size_prof2 = trunc_profile_cfg_p->truncate_size;
        break;

    /* coverity[dead_error_begin]*/
    default:
        SX_LOG(SX_LOG_ERROR, "Unsupported trunc_profile_id : %d \n", trunc_profile_id);
        return SX_STATUS_ERROR;
    }

    sx_status = __handle_hgcr(SXD_ACCESS_CMD_SET, &hgcr_reg_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to set HGCR: [%s].\n",
               SX_STATUS_MSG(sx_status));
        goto out;
    }

    host_ifc_db_profile_cfg.cfg = *trunc_profile_cfg_p;
    host_ifc_db_profile_cfg.created = TRUE;
    sx_status = host_ifc_db_profile_cfg_set(trunc_profile_id, &host_ifc_db_profile_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "host_ifc_db_profile_cfg_set failed: [%s].\n",
               SX_STATUS_MSG(sx_status));
    }

out:
    if (pr_buff) {
        cl_free(pr_buff);
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t host_ifc_trap_truncate_profile_set(const sx_access_cmd_t                 cmd,
                                               const sx_trap_truncate_profile_id_t   trunc_profile_id,
                                               const sx_trap_truncate_profile_cfg_t *trunc_profile_cfg_p)
{
    sx_status_t rc = SX_STATUS_UNSUPPORTED;

    if (brg_context.spec_cb_g.host_ifc_trap_truncate_profile_set_cb) {
        rc = brg_context.spec_cb_g.host_ifc_trap_truncate_profile_set_cb(cmd, trunc_profile_id,
                                                                         trunc_profile_cfg_p);
    } else {
        SX_LOG_ERR("Truncation profile is supported on spectrum4 and above.\n");
    }
    return rc;
}

sx_status_t __handle_hgcr(sxd_access_cmd_t access_cmd, struct ku_hgcr_reg *hgcr_reg_data_p)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t     hgcr_reg_meta;
    struct ku_hgcr_reg hgcr_reg_data;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG(SX_LOG_DEBUG, "HGCR %s\n", SXD_ACCESS_CMD_STR(access_cmd));

    SX_MEM_CLR(hgcr_reg_meta);
    SX_MEM_CLR(hgcr_reg_data);

    /* Get list of LEAF devices */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (dev_info_arr_size == 0) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve devices, err: %s.\n",
               sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (access_cmd == SXD_ACCESS_CMD_SET) {
        hgcr_reg_data = *hgcr_reg_data_p;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    hgcr_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    hgcr_reg_meta.access_cmd = access_cmd;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HGCR_E,
                                                     &hgcr_reg_data, &hgcr_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to %s HGCR: [%s].\n",
               SXD_ACCESS_CMD_STR(access_cmd),
               SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    if (access_cmd == SXD_ACCESS_CMD_GET) {
        *hgcr_reg_data_p = hgcr_reg_data;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


void host_ifc_apply_done_status_get(sx_event_port_profile_apply_done_t *params_p, uint16_t *error_entry_index)
{
    memcpy(params_p, &s_parsed_ipac_event.port_profile_apply_done_event,
           sizeof(sx_event_port_profile_apply_done_t));
    *error_entry_index = s_parsed_ipac_event.error_entry_index;
}

sx_status_t host_ifc_get_ecc_stats(uint8_t slot_index, uint8_t device_index, sx_mgmt_ecc_stats_t *ecc_stats_p)
{
    sx_status_t         ret = SX_STATUS_SUCCESS;
    struct ku_meccc_reg meccc_reg_data;
    sxd_reg_meta_t      meccc_reg_meta;
    int                 device_cnt = SX_DEV_ID_MAX;
    topo_device_item_t  dev_attrib[SX_DEV_ID_MAX];

    SX_LOG_ENTER();

    SX_MEM_CLR(meccc_reg_meta);
    SX_MEM_CLR(meccc_reg_data);

    /* set register fields */
    meccc_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    meccc_reg_meta.swid = 0;
    meccc_reg_data.slot_index = slot_index;
    meccc_reg_data.device_index = device_index;

    /* get device list */
    ret = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(ret)) {
        SX_LOG_ERR("Failed in topo_db_device_list_get, error: %s.\n", sx_status_str(ret));
        goto out;
    }

    if (device_cnt == 0) {
        SX_LOG_ERR("Device list is empty.\n");
        ret = SX_STATUS_ERROR;
        goto out;
    }

    meccc_reg_meta.dev_id = dev_attrib[0].dev_id;
    ret = sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MECCC_E, &meccc_reg_data,
                                                                      &meccc_reg_meta, 1, NULL, NULL));
    if (SX_CHECK_FAIL(ret)) {
        SX_LOG_ERR("MECCC register read failed on SxD (%s)\n", sx_status_str(ret));
        goto out;
    }

    ecc_stats_p->ecc_corrected = meccc_reg_data.ecc_crt_cnt;
    ecc_stats_p->ecc_uncorrected = meccc_reg_data.ecc_ucrt_cnt;

out:
    SX_LOG_EXIT();
    return ret;
}

sx_status_t host_ifc_ecc_stats_init_spectrum(void)
{
    sx_status_t ret = SX_STATUS_SUCCESS;
    int         swid = 0;

    if (__ecc_stats_initialized) {
        goto out;
    }

    /* Currently only device_index 0 and slot_index 0 is supported for MECCC, see comments for __ecc_stats */
    ret = host_ifc_get_ecc_stats(0, 0, &__ecc_stats);
    if (SX_CHECK_FAIL(ret)) {
        SX_LOG_ERR("Failed to get the initial ECC statistics, error: %s.\n", sx_status_str(ret));
        goto out;
    }

    for (swid = 0; swid < NUMBER_OF_SWIDS; swid++) {
        /* Set MECCC listener on each swid */
        ret = __host_ifc_listener_set(SX_ACCESS_CMD_ADD,
                                      ev_thread_params_s.sxd_h,
                                      swid,
                                      (sx_trap_id_t)SXD_TRAP_ID_MECCC,
                                      (sx_user_channel_type_t)SX_KU_USER_CHANNEL_TYPE_FD);
        if (SX_CHECK_FAIL(ret)) {
            SX_LOG_ERR("__host_ifc_listener_set trap id [%d] failed [%s].\n",
                       SXD_TRAP_ID_MECCC, sx_status_str(ret));
            goto out;
        }
    }

    __ecc_stats_initialized = TRUE;

out:
    return ret;
}

static sx_status_t __host_ifc_ecc_stats_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.host_ifc_ecc_stats_init_cb) {
        err = brg_context.spec_cb_g.host_ifc_ecc_stats_init_cb();
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to init ECC stats, return value: [%s]\n",
                       sx_status_str(err));
            return err;
        }
    }

    return err;
}
