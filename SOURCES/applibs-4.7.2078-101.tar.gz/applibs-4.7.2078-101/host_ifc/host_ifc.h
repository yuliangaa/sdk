/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HOST_IFC_H__
#define __HOST_IFC_H__


#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_types.h>

#include "utils/sx_adviser.h"
#include "span/span_db.h"
#include "utils/sx_internal.h"

/************************************************
 *  Local Defines
 ***********************************************/
#define TRAP_GROUP_REGULAR_RDQ_TC_SHIFT    10
#define TRAP_GROUP_INVALID_ID              255
#define TOCPU_BUFFER_DROP_CNT_MASK         0xff
#define TOCPU_BUFFER_DROP_CNT_OVERFLOW_SUM 0x100

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

typedef enum {
    SX_EV_SEND_MODE_WITH_EMAD_HDR_E,
    SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E,
} sx_ev_send_mode_e;

typedef enum host_ifc_trap_group_allocate_mode {
    HOST_IFC_TRAP_GROUP_ALLOCATE_MODE_STATIC_E = 0,
    HOST_IFC_TRAP_GROUP_ALLOCATE_MODE_DYNAMIC_E,
    HOST_IFC_TRAP_GROUP_ALLOCATE_MODE_INVALID_E,
} host_ifc_trap_group_allocate_mode_e;

typedef struct host_ifc_default_trap_group {
    uint8_t mirror_trap_group;
    uint8_t accuflow_trap_group;
    uint8_t mocs_trap_group;
} host_ifc_internal_trap_groups_t;

typedef struct host_ifc_wqe_overflow_cnt {
    uint64_t global;
    uint64_t per_rdq[SXD_HMON_WQE_OVERFLOW_RDQ_NUM];
} host_ifc_wqe_overflow_cnt_t;

typedef enum host_ifc_wqe_overflow_cnt_type {
    HOST_IFC_WQE_OVERFLOW_REGULAR_CNT_E = 0,
    HOST_IFC_WQE_OVERFLOW_TAC_CNT_E,
    HOST_IFC_WQE_OVERFLOW_SUM_CNT_E,
} host_ifc_wqe_overflow_cnt_type_e;

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/
#define SX_TRAP_TRUNCATE_PROFILE_CHECK_RANGE(tr_id) \
    (((tr_id) >= SX_TRAP_TRUNCATE_PROFILE_MIN) &&   \
     (tr_id) <= SX_TRAP_TRUNCATE_PROFILE_MAX)
/************************************************
 *  Type definitions
 ***********************************************/
/* function pointers for HWD APIs */
typedef struct hwi_host_ifc_ops {
    sx_status_t (*hwd_host_ifc_handle_hcap_pfn)(uint8_t *max_num_cpu_tclass, uint8_t *max_num_trap_groups,
                                                uint8_t *max_num_dr_paths);
    sx_status_t (*hwd_host_ifc_get_wqe_overflow_counters_pfn)(sx_access_cmd_t              cmd,
                                                              host_ifc_wqe_overflow_cnt_t *tocpu_buffer_drop);
    sx_status_t (*host_ifc_internal_trap_groups_from_profile_get_pfn)(sx_api_pci_profile_t *pci_profile,
                                                                      host_ifc_internal_trap_groups_t *
                                                                      internal_trap_groups_p);
    sx_status_t (*host_ifc_disable_accuflow_trap_group_pfn)(void);
    sx_status_t (*host_ifc_accuflow_counter_clear_pfn)(void);
    sx_status_t (*host_ifc_pps_trap_reg_pfn)(void);
} hwi_host_ifc_ops_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


void host_ifc_apply_done_status_get(sx_event_port_profile_apply_done_t *params_p, uint16_t *error_entry_index);

sx_status_t host_ifc_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t host_ifc_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

/* __event_timer_handler thread utilities */
cl_thread_t* host_ifc_get_event_timer_handler_thread_obj(void);
void host_ifc_set_event_timer_handler_exit_signal_issue(boolean_t signal_issued);
void host_ifc_event_timer_handler_wakeup(void);
boolean_t host_ifc_event_timer_handler_thread_init_was_called(void);
/* __host_ifc_recv_events_handler thread utilities */
cl_thread_t* host_ifc_get_recv_events_handler_thread_obj();
void host_ifc_set_recv_events_handler_exit_signal_issue(boolean_t signal_issued);
sx_status_t host_ifc_recv_events_handler_wakeup(void);
sx_status_t host_ifc_get_port_last_oper_state(uint32_t local_port, sx_port_oper_state_t *last_oper_state_p);
sx_status_t host_ifc_internal_trap_groups_from_profile_get(sx_api_pci_profile_t            *pci_profile,
                                                           host_ifc_internal_trap_groups_t *internal_trap_groups_p);
sx_status_t host_ifc_disable_accuflow_trap_group(void);
sx_status_t host_ifc_accuflow_counter_clear(void);
sx_status_t host_ifc_pps_trap_reg(void);

sx_status_t host_ifc_hw_trap_groups_get(uint64_t * hw_trap_group_status);


/**
 * This function init the host interface ops callback vector
 *
 * @param[out] valid_ops - callback vector
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_assign_ops(hwi_host_ifc_ops_t *valid_ops);

/**
 * This function init the host interface ops callback vector
 * with functions which allow to avoid calling unsupported by FW
 * registers and retrieve values from RM
 *
 * @param[out] valid_ops - callback vector
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_assign_rm_cap_ops(hwi_host_ifc_ops_t *valid_ops);

/**
 * This function init the host interface ops callback vector for
 * Spectrum2 and above devices
 *
 * @param[out] valid_ops - callback vector
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_assign_ops_spectrum2(hwi_host_ifc_ops_t *valid_ops);

/**
 * This function init the host interface ops callback vector for
 * Spectrum3 and above devices
 *
 * @param[out] valid_ops - callback vector
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_assign_ops_spectrum3(hwi_host_ifc_ops_t *valid_ops);

/**
 * This function init the host interface ops callback vector for
 * Spectrum4 and above devices
 *
 * @param[out] valid_ops - callback vector
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_assign_ops_spectrum4(hwi_host_ifc_ops_t *valid_ops);

/**
 * This function init the host interface ops callback vector for
 * Spectrum5 and above devices
 *
 * @param[out] valid_ops - callback vector
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_assign_ops_spectrum5(hwi_host_ifc_ops_t *valid_ops);

/**
 * This function register the host interface ops callback vector
 *
 * @param[out] valid_ops - callback vector
 *
 * @return sx_status_t
 */
sx_status_t sdk_host_ifc_register_hwd_ops(hwi_host_ifc_ops_t *ops);

/**
 * This function registers host interface ops callback vector
 *
 * @return sx_status_t
 */
sx_status_t sdk_host_ifc_register_modules(void);

/**
 * This function unregisters host interface ops callback vector
 *
 * @return sx_status_t
 */
sx_status_t sdk_host_ifc_unregister_modules(void);

/**
 * This function init the host interface module
 *
 * @param[in] pci_profile		PCI profile info
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_init(sx_api_pci_profile_t *pci_profile);

/**
 * This function deinit the host interface module
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_deinit(void);

/*
 * This function gets whether host interface module is initialized
 */
sx_status_t host_ifc_is_initialized_get(boolean_t *is_initialized);

void host_ifc_register_cb(sx_add_intern_job_cb cb);

/**
 * This function set a trap group properties : truncate mode, truncate size
 *
 * @param[in]  cmd	     - The command to execute
 * @param[in]  swid	     - The swid to configure
 * @param[in] trap_group    - Trap group handle
 * @param[in] trap_group_attributes_p    - Trap group attributes
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_group_set(sx_swid_id_t                swid,
                                    sx_trap_group_t             trap_group,
                                    sx_trap_group_attributes_t *trap_group_attributes_p,
                                    uint32_t                   *hw_trap_group_p);

/**
 * This function set a trap group.
 *
 * @param[in]  swid                       - The swid to configure
 * @param[in]  cmd                        - Command
 * @param[in]  trap_group                 - Trap group handle
 * @param[out] trap_group_attributes_p    - Trap group attributes
 * @param[out] hw_trap_group_p            - HW trap group ID
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_group_ext_set(sx_swid_id_t                swid,
                                        sx_access_cmd_t             cmd,
                                        sx_trap_group_t             trap_group,
                                        sx_trap_group_attributes_t *trap_group_attributes_p,
                                        uint32_t                   *hw_trap_group_p);


/**
 * This function set a trap group properties : truncate mode, truncate size
 *
 * @param[in]  trap_group    - Trap group handle
 * @param[in]  swid	     - The swid to configure
 * @param[out]  trap_priority - Trap priority assigned for trap id
 * @param[out]  truncate_mode - Truncate mode
 * @param[out]  truncate_size - Truncate size
 * @param[out]  control_type - Control type
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_group_get(sx_trap_group_t             trap_group,
                                    sx_swid_id_t                swid,
                                    sx_trap_group_attributes_t *trap_group_attributes_p);

/**
 * This function retrieves a list of one or more trap group IDs.
 *
 * @param [in] cmd                     - GET/GET_FIRST/GET_NEXT
 * @param [in] swid                    - switch ID
 * @param [in] trap_group_id           - trap group ID
 * @param [in] filter_p                - specify a filter parameter (not supported yet)
 * @param [out] trap_group_id_list_p   - return list of trap group IDs
 * @param [in,out] trap_group_id_cnt_p - [in] number of trap group IDs to get
 *                                     - [out] number of trap group IDs returned
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_group_iter_get(const sx_access_cmd_t         cmd,
                                         const sx_swid_id_t            swid,
                                         const sx_trap_group_t         trap_group_id,
                                         const sx_trap_group_filter_t *filter_p,
                                         sx_trap_group_t              *trap_group_id_list_p,
                                         uint32_t                     *trap_group_id_cnt_p);

/**
 * This function get a trap id properties : trap group , trap action
 *
 * @param[in]   trap_id	      - trap id to query
 * @param[in]  swid	      - The switch ID
 * @param[out]  trap_action   - trap to cpu / mirror to cpu / discard
 * @param[out]  trap_group    - Trap group configured for trap id
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_id_get(sx_trap_id_t      trap_id,
                                 sx_swid_t         swid,
                                 sx_trap_action_t *trap_action,
                                 sx_trap_group_t  *trap_group);

/**
 * This function set a trap id properties such as trap group,
 * trap action.
 * Note that this function allows to specify cmd parameter and
 * supports trap double registration (binding the same trap id
 * to regular and monitor trap groups at the same time).
 *
 * @param[in]  cmd	   - SET/UNSET command to execute
 * @param[in]  trap_key_p  - Trap key value such as Trap ID.
 * @param[in]  trap_attr_p - Trap key attributes to set such as trap action and trap group.
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_id_ext_set(sx_access_cmd_t          cmd,
                                     sx_host_ifc_trap_key_t  *trap_key_p,
                                     sx_host_ifc_trap_attr_t *trap_attr_p);

/**
 * This function get a trap id properties such as trap group,
 * trap action
 * Note that this function allows to retrieve all trap groups
 * and their trap actions which are associated with the
 * specified trap id.
 *
 * @param[in]  cmd	        - GET command to execute
 * @param[in]  trap_key_p   - Trap key value such as Trap ID.
 * @param[out]  trap_attr_p - Trap key attributes to set such as
 *       trap action and trap group.
 * @param[out] attr_cnt     - number of the attribute instances
 *       which bound to trap
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_id_ext_get(sx_access_cmd_t          cmd,
                                     sx_host_ifc_trap_key_t  *trap_key_p,
                                     sx_host_ifc_trap_attr_t *trap_attr_p,
                                     uint32_t                *attr_cnt_p);

/**
 * This function gets a trap group statistics data such as total
 * number of discarded packets in trap group.
 *
 * @param[in]  cmd	        - GET command to execute
 * @param[in]  group_key_p  - Trap group key value such as Trap Group ID.
 * @param[out] group_stat_p - Trap group statistics.
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_group_stat_get(sx_access_cmd_t                cmd,
                                         sx_host_ifc_trap_group_key_t  *group_key_p,
                                         sx_host_ifc_trap_group_stat_t *group_stat_p);

sx_status_t host_ifc_user_defined_trap_id_set(const sx_access_cmd_t                 cmd,
                                              const sx_swid_id_t                    swid,
                                              const sx_trap_id_t                    trap_id,
                                              sx_trap_id_user_defined_attributes_t *user_defined_attributes_p);

sx_status_t host_ifc_trap_filter_set(sx_access_cmd_t  cmd,
                                     sx_swid_t        swid,
                                     sx_trap_id_t     trap_id,
                                     sx_port_log_id_t log_port_list[],
                                     length_t        *log_port_num);
sx_status_t host_ifc_trap_filter_get(const sx_access_cmd_t  cmd,
                                     const sx_swid_t        swid,
                                     const sx_trap_id_t     trap_id,
                                     const sx_port_log_id_t log_port_id,
                                     sx_port_log_id_t      *log_port_list_p,
                                     length_t              *log_port_cnt_p);

sx_status_t host_ifc_counters_get(sx_access_cmd_t                      cmd,
                                  const sx_host_ifc_counters_filter_t *filter_p,
                                  sx_host_ifc_counters_t              *host_ifc_cnt_p);

sx_status_t host_ifc_counters_get_wrapper(sx_access_cmd_t                      cmd,
                                          const sx_host_ifc_counters_filter_t *filter_p,
                                          sx_host_ifc_counters_t              *host_ifc_cnt_p);

sx_status_t host_ifc_policer_bind_set(const sx_access_cmd_t    cmd,
                                      const sx_swid_t          swid,
                                      const sx_trap_priority_t trap_group,
                                      const sx_policer_id_t    policer_id);

sx_status_t host_ifc_policer_bind_get(const sx_swid_id_t       swid,
                                      const sx_trap_priority_t trap_group,
                                      sx_policer_id_t         *policer_id_p);

sx_status_t sx_host_ifc_policer_bind_set(const sx_access_cmd_t    cmd,
                                         const sx_swid_id_t       swid,
                                         const sx_trap_priority_t trap_group,
                                         const sx_policer_id_t    policer_id);

sx_status_t sdk_host_ifc_policer_bind_set(const sx_access_cmd_t    cmd,
                                          const sx_swid_id_t       swid,
                                          const sx_trap_priority_t trap_group,
                                          const sx_policer_id_t    policer_id);

sx_status_t host_ifc_device_add(adviser_event_e event,
                                void           *param,
                                uint32_t        size);

sx_status_t host_ifc_send_event(IN sx_trap_id_t      event_id,
                                IN void             *event_buffer_p,
                                IN uint32_t          event_buffer_size,
                                IN sx_ev_send_mode_e event_send_mode);

sx_status_t host_ifc_send_to_span(IN uint8_t  span_hw_session_id,
                                  IN void    *packet_buffer_p,
                                  IN uint32_t packet_buffer_size);


static const unsigned int sx_host_ifc_virt_trap_to_sxd_trap_switchx[SX_TRAP_ID_MAX + 1] = {
    [SX_TRAP_ID_FDB_SRC_MISS] = SXD_TRAP_ID_ACL_MAX - 1,
};
static const unsigned int sx_host_ifc_virt_trap_to_sxd_trap_spectrum[SX_TRAP_ID_MAX + 1] = {
    [SX_TRAP_ID_FDB_SRC_MISS] = SXD_TRAP_ID_FDB_MISS,
    [SX_TRAP_ID_L3_UC_IP_BASE] = SXD_TRAP_ID_RTR_INGRESS0,
    [SX_TRAP_ID_L3_UC_IP_BASE + 1] = SXD_TRAP_ID_RTR_INGRESS0,
    [SX_TRAP_ID_L3_UC_IP_BASE + 2] = SXD_TRAP_ID_RTR_INGRESS0,
    [SX_TRAP_ID_L3_UC_IP_BASE + 3] = SXD_TRAP_ID_RTR_INGRESS1,
    [SX_TRAP_ID_L3_NEIGH_IP_BASE] = SXD_TRAP_ID_RTR_EGRESS0,
    [SX_TRAP_ID_L3_NEIGH_IP_BASE + 1] = SXD_TRAP_ID_RTR_EGRESS0,
    [SX_TRAP_ID_L3_NEIGH_IP_BASE + 2] = SXD_TRAP_ID_RTR_EGRESS0,
    [SX_TRAP_ID_L3_NEIGH_IP_BASE + 3] = SXD_TRAP_ID_RTR_EGRESS1,
    [SX_TRAP_ID_IPV6_ROUTER_SOLICITATION] = SXD_TRAP_ID_L3_IPV6_ROUTER_SOLICITATION,
    [SX_TRAP_ID_IPV6_ROUTER_ADVERTISEMENT] = SXD_TRAP_ID_L3_IPV6_ROUTER_ADVERTISEMENT,
    [SX_TRAP_ID_IPV6_NEIGHBOR_SOLICITATION] = SXD_TRAP_ID_L3_IPV6_NEIGHBOR_SOLICITATION,
    [SX_TRAP_ID_IPV6_NEIGHBOR_ADVERTISEMENT] = SXD_TRAP_ID_L3_IPV6_NEIGHBOR_ADVERTISEMENT,
    [SX_TRAP_ID_IPV6_REDIRECTION] = SXD_TRAP_ID_L3_IPV6_REDIRECTION
};

/**
 * This function sets or deletes the mirroring session used for table mirroring.
 *
 * @param[in] cmd - ADD / DELETE
 * @param[in] span_session_id - SPAN session ID
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_span_mirror_tables_set(const sx_access_cmd_t          cmd,
                                            const sx_span_session_id_int_t span_session_id);

/**
 * This function sets or deletes the SPAN probability rate for a trap group.
 *
 * @param[in] cmd - SET / DELETE
 * @param[in] trap_group - Trap Group
 * @param[in] span_session_id - SPAN session ID
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_group_span_probability_rate_set(const sx_span_probability_rate_t rate);
/**
 * This function sets or deletes the SPAN session for a trap group.
 *
 * @param[in] cmd - ADD / DELETE
 * @param[in] trap_group - Trap Group
 * @param[in] span_session_id - SPAN session ID
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_trap_group_span_set(const sx_access_cmd_t          cmd,
                                         const sx_trap_group_t          hw_trap_group,
                                         const sx_span_session_id_int_t span_session_id);

sx_status_t host_ifc_trap_group_for_span_get(sx_trap_group_t *hw_trap_groups_p,
                                             uint32_t        *hw_trap_group_count_p);

sx_status_t host_ifc_set_trap_id_for_span(const sx_access_cmd_t cmd,
                                          const sx_trap_id_t    trap_id,
                                          const sx_trap_group_t trap_group);

sx_status_t host_ifc_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);

sx_status_t host_ifc_trap_counters_dump(dbg_dump_params_t *dbg_dump_params_p);

sx_status_t rdq_timestamp_state_set(int rdq, boolean_t enable, boolean_t hw_utc_enable);
sx_status_t rdq_cpu_priority_set(int rdq, boolean_t high_prio);

sx_status_t host_ifc_trap_id_register_set(sx_access_cmd_t          cmd,
                                          sx_swid_t                swid,
                                          sx_trap_id_t             vtrap,
                                          const sx_user_channel_t *user_channel,
                                          const pid_t              client_pid,
                                          sx_trap_id_t            *trap_id_p);

sx_status_t host_ifc_trap_id_register_get(const sx_access_cmd_t    cmd,
                                          const sx_swid_t          swid,
                                          const sx_trap_id_t       trap_id,
                                          const sx_user_channel_t *user_channel,
                                          const pid_t              client_pid,
                                          sx_user_channel_t       *user_channel_list_p,
                                          uint32_t                *user_channel_cnt_p);

sx_status_t host_ifc_port_vlan_trap_id_register_set(sx_access_cmd_t                   cmd,
                                                    sx_swid_t                         swid,
                                                    sx_trap_id_t                      vtrap,
                                                    const sx_host_ifc_register_key_t *register_key_p,
                                                    const sx_user_channel_t          *user_channel_p,
                                                    const pid_t                       client_pid,
                                                    sx_port_ucroute_id_t             *sys_port_p);

sx_status_t host_ifc_port_vlan_trap_id_register_get(const sx_access_cmd_t                   cmd,
                                                    const sx_swid_t                         swid,
                                                    const sx_trap_id_t                      trap_id,
                                                    const sx_host_ifc_register_get_entry_t *register_entry,
                                                    const pid_t                             client_pid,
                                                    sx_host_ifc_register_get_entry_t       *register_entry_list_p,
                                                    uint32_t                               *register_entry_cnt_p);

sx_status_t host_ifc_remove_fd_user_channels(const sx_fd_t *fd_p,
                                             const pid_t    client_pid);

/**
 * This function aimed to maintain the existing functionality of
 * trap handling and support trap double registration. In case
 * of regular trap id handling this function will execute
 * regular trap binding flow, but in case of trap double
 * registration it will invoke additional logic to maintain
 * existing functionality and allow to support trap id double
 * registration
 * Depends on the current configuration this function will
 * update kernel with required command to start/stop using SW
 * buffer of monitor trap group.
 *
 * @param[in]  cmd	   - SET/UNSET command to execute
 * @parma[in]  swid    - The swid to configure
 * @param[in]  trap_id - Trap ID to configure
 *
 * @return sx_status_t
 */
sx_status_t host_ifc_open(int *fd_p);

sx_status_t host_ifc_close(int fd);

sx_status_t host_ifc_timer_threads_end_event_created_get(int *created);

sx_status_t host_ifc_pause(void);

sx_status_t host_ifc_resume(void);

sx_status_t host_ifc_port_state_change_count_get(sx_access_cmd_t cmd,
                                                 uint32_t        local_port,
                                                 sx_port_cntr_t *state_change_count_p);
sx_status_t host_ifc_trap_id_channel_filter_set(sx_access_cmd_t                 cmd,
                                                sx_swid_t                       swid,
                                                sx_trap_id_t                    vtrap,
                                                const sx_host_ifc_filter_key_t *filter_key_p,
                                                const sx_user_channel_t        *user_channel_p,
                                                const pid_t                     client_pid,
                                                sx_port_ucroute_id_t           *sys_port_p);
sx_status_t host_ifc_trap_id_channel_filter_get(const sx_access_cmd_t                         cmd,
                                                const sx_swid_t                               swid,
                                                const sx_trap_id_t                            trap_id,
                                                const sx_host_ifc_channel_filter_get_entry_t *channel_filter_entry,
                                                const pid_t                                   client_pid,
                                                sx_host_ifc_channel_filter_get_entry_t       *channel_filter_entry_list_p,
                                                uint32_t                                     *channel_filter_entry_cnt_p);

sx_status_t host_ifc_user_attr_ext_set_spectrum2(const sx_access_cmd_t                 cmd,
                                                 const sx_swid_t                       swid,
                                                 const sx_trap_id_t                    trap_id,
                                                 sx_trap_id_user_defined_attributes_t *user_defined_attributes_p);

sx_status_t hwd_host_ifc_get_wqe_overflow_global_only_counter(sx_access_cmd_t              cmd,
                                                              host_ifc_wqe_overflow_cnt_t *tocpu_buffer_drop);

sx_status_t hwd_host_ifc_get_wqe_overflow_counters(sx_access_cmd_t              cmd,
                                                   host_ifc_wqe_overflow_cnt_t *tocpu_buffer_drop);

sx_status_t hwd_host_ifc_get_tac_wqe_overflow_counters(sx_access_cmd_t              cmd,
                                                       host_ifc_wqe_overflow_cnt_t *tocpu_buffer_drop);

sx_status_t host_ifc_get_ecc_stats(uint8_t slot_index, uint8_t device_index, sx_mgmt_ecc_stats_t *ecc_stats_p);

sx_status_t host_ifc_sysfs_sniffer_trap_register_set(sx_access_cmd_t cmd);

sx_status_t host_ifc_stateful_db_trap_register_set(sx_access_cmd_t cmd);

sx_status_t host_ifc_spectrum_trap_group_used(sx_swid_id_t    swid,
                                              sx_trap_group_t trap_group,
                                              boolean_t      *is_trap_group_associated_p);

sx_status_t __handle_hgcr(sxd_access_cmd_t access_cmd, struct ku_hgcr_reg *hgcr_reg_data_p);
sx_status_t host_ifc_trap_truncate_profile_set(sx_access_cmd_t                       cmd,
                                               sx_trap_truncate_profile_id_t         trunc_profile_id,
                                               const sx_trap_truncate_profile_cfg_t *trunc_profile_cfg_p);
sx_status_t host_ifc_trap_truncate_profile_get(sx_access_cmd_t                 cmd,
                                               sx_trap_truncate_profile_id_t   trunc_profile_id,
                                               sx_trap_truncate_profile_cfg_t *trunc_profile_cfg_p);

#endif /* __HOST_IFC_H__ */
