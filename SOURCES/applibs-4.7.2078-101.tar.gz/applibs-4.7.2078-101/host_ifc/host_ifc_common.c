/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "host_ifc_common.h"
#include "ethl2/brg.h"

#undef  __MODULE__
#define __MODULE__ HOST_INTERFACE_COMMON

/************************************************
 *  Global variables
 ***********************************************/

extern sx_brg_context_t brg_context;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static uint8_t __cpu_tclass_max_s = SX_COS_TCLASS_REQUIRED;
static uint8_t __trap_group_max_s = SX_TRAP_ID_TRAP_GROUP_REQUIRED;
static uint8_t __direct_route_paths_max_s = SX_DR_PATH_GROUP_REQUIRED;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t host_ifc_common_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

sx_status_t host_ifc_common_capabilities_set(IN uint8_t max_num_cpu_tclass,
                                             IN uint8_t max_num_trap_groups,
                                             IN uint8_t max_num_dr_paths)
{
    __cpu_tclass_max_s = max_num_cpu_tclass;
    __trap_group_max_s = max_num_trap_groups;
    __direct_route_paths_max_s = max_num_dr_paths;

    return SX_STATUS_SUCCESS;
}

sx_status_t host_ifc_check_trap_action(IN sx_trap_action_t trap_action)
{
    if ((SX_TRAP_ACTION_MAX < trap_action) || (SX_TRAP_ACTION_MIN > (int)trap_action)) {
        SX_LOG_ERR("Trap action (%u) out of range [%u...%u]\n",
                   trap_action, SX_TRAP_ACTION_MIN, SX_TRAP_ACTION_MAX);
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* O/W: */
    return SX_STATUS_SUCCESS;
}

sx_status_t host_ifc_sx_hw_trap_group_num_get(uint32_t *hw_trap_group_num_p)
{
    if (hw_trap_group_num_p == NULL) {
        SX_LOG_ERR("hw_trap_group_num_p is NULL\n");
        return SX_STATUS_PARAM_NULL;
    }

    *hw_trap_group_num_p = rm_resource_global.hw_trap_groups_num_max;
    return SX_STATUS_SUCCESS;
}

sx_status_t host_ifc_spectrum_hw_trap_group_num_get(uint32_t *hw_trap_group_num_p)
{
    if (hw_trap_group_num_p == NULL) {
        SX_LOG_ERR("hw_trap_group_num_p is NULL\n");
        return SX_STATUS_PARAM_NULL;
    }

    /* Total HW trap group: user trap group + monitor trap group +
     * internal (1 for EMADs and 1 as a mirroring agent) +
     * Span (3 for use with SPAN sessions) */
    *hw_trap_group_num_p = rm_resource_global.hw_total_trap_groups_num_max;
    return SX_STATUS_SUCCESS;
}

sx_status_t host_ifc_hw_trap_group_num_get(uint32_t *hw_trap_group_num_p)
{
    /* Make sure host_ifc_hw_trap_group_num_get_cb exists */
    if (brg_context.spec_cb_g.host_ifc_hw_trap_group_num_get_cb == NULL) {
        SX_LOG_ERR("host_ifc_hw_trap_group_num_get_cb not set.\n");
        return SX_STATUS_ERROR;
    }
    return brg_context.spec_cb_g.host_ifc_hw_trap_group_num_get_cb(hw_trap_group_num_p);
}

sx_status_t host_ifc_handle_htgt(sx_device_id_t                      device_id,
                                 sx_swid_id_t                        swid,
                                 sx_trap_group_t                     trap_group,
                                 sxd_host_interface_path_type_e     *path_type_p,
                                 sxd_host_interface_path_t          *host_path_p,
                                 boolean_t                          *policer_enabled_p,
                                 sx_policer_id_t                    *policer_id_p,
                                 sx_trap_priority_t                 *priority_p,
                                 sxd_host_interface_mirror_action_t *mirror_action_p,
                                 sx_span_session_id_int_t           *mirror_agent_p,
                                 sx_span_probability_rate_t         *mirror_probability_rate_p)
{
    /* Make sure host_ifc_handle_htgt exists */
    if (brg_context.spec_cb_g.host_ifc_handle_htgt == NULL) {
        SX_LOG_ERR("host_ifc_handle_htgt not set.\n");
        return SX_STATUS_ERROR;
    }
    return brg_context.spec_cb_g.host_ifc_handle_htgt(device_id,
                                                      swid,
                                                      trap_group,
                                                      path_type_p,
                                                      host_path_p,
                                                      policer_enabled_p,
                                                      policer_id_p,
                                                      priority_p,
                                                      mirror_action_p,
                                                      mirror_agent_p,
                                                      mirror_probability_rate_p);
}
