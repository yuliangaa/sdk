/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/sx_log.h>
#include "trap_id.h"
#include "host_ifc_db.h"
#include "ethl2/brg.h"

#undef __MODULE__
#define __MODULE__ HOST_INTERFACE

/************************************************
 *  Global variables
 ***********************************************/

extern sx_brg_context_t brg_context;

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cl_map_t g_sw_to_hw_syndrome_map; /* Mapping of SW <-> HW syndromes.
                                          * HW syndrome value isn't exposed in PRM and can differ depending on the type of chip */
/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t trap_id_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

boolean_t trap_id_is_source(uint32_t hw_trap_id)
{
    boolean_t is_source_trap = FALSE;

    if ((hw_trap_id >= SXD_TRAP_ID_ACL_MIN) && (hw_trap_id <= SXD_TRAP_ID_ACL_MAX)) {
        is_source_trap = TRUE;
    } else {
        switch (hw_trap_id) {
        case SXD_TRAP_ID_FDB:
        case SXD_TRAP_ID_ETH_L2_PKT_SAMPLE:
        case SXD_TRAP_ID_MIRROR:
        case SXD_TRAP_ID_ETH_L3_RPF:
        case SXD_TRAP_ID_ETH_L3_ASSERT:
        case SXD_TRAP_ID_IP2ME:
        case SXD_TRAP_ID_RTR_INGRESS0:
        case SXD_TRAP_ID_RTR_INGRESS1:
        case SXD_TRAP_ID_RTR_INGRESS2:
        case SXD_TRAP_ID_RTR_INGRESS3:
        case SXD_TRAP_ID_RTR_EGRESS0:
        case SXD_TRAP_ID_RTR_EGRESS1:
        case SXD_TRAP_ID_RTR_EGRESS2:
        case SXD_TRAP_ID_RTR_EGRESS3:
        case SXD_TRAP_ID_MPLS_ILM0:
        case SXD_TRAP_ID_MPLS_ILM1:
        case SXD_TRAP_ID_MPLS_ILM2:
        case SXD_TRAP_ID_MPLS_ILM3:
        case SXD_TRAP_ID_MPLS_NHLFE0:
        case SXD_TRAP_ID_MPLS_NHLFE1:
        case SXD_TRAP_ID_MPLS_NHLFE2:
        case SXD_TRAP_ID_MPLS_NHLFE3:
            is_source_trap = TRUE;
            break;

        default:
            is_source_trap = FALSE;
            break;
        }
    }
    return is_source_trap;
}

boolean_t trap_id_is_fw_event(uint32_t hw_trap_id)
{
    boolean_t is_event_trap = FALSE;

    switch (hw_trap_id) {
    case SXD_TRAP_ID_GENERAL_ETH_EMAD:
    case SXD_TRAP_ID_PUDE:
    case SXD_TRAP_ID_PMPE:
    case SXD_TRAP_ID_PPBME:
    case SXD_TRAP_ID_FLAE:
    case SXD_TRAP_ID_TMPW:
    case SXD_TRAP_ID_CPUWD:
    case SXD_TRAP_ID_FORE:
    case SXD_TRAP_ID_PTP_ING_EVENT:
    case SXD_TRAP_ID_PTP_EGR_EVENT:
    case SXD_TRAP_ID_SB_CONG_TX_PORT:
    case SXD_TRAP_ID_INFINIBAND_IN_NV_ACCESS_REG:
    case SXD_TRAP_ID_INFINIBAND_IB_FMAD_RCV:
    case SXD_TRAP_ID_INFINIBAND_RESET_CMD:
    case SXD_TRAP_ID_MFDE:
    case SXD_TRAP_ID_FSHE:
    case SXD_TRAP_ID_FSPS:
    case SXD_TRAP_ID_MCION:
    case SXD_TRAP_ID_TSDE:
    case SXD_TRAP_ID_DSDSC:
    case SXD_TRAP_ID_BCTOE:
    case SXD_TRAP_ID_PMLPE:
    case SXD_TRAP_ID_UTFD:
    case SXD_TRAP_ID_MECCC:
    case SXD_TRAP_ID_PTSE:
    case SXD_TRAP_ID_UPCNT:
    case SXD_TRAP_ID_UTCC:
    case SXD_TRAP_ID_USACN:
        is_event_trap = TRUE;
        break;

    default:
        is_event_trap = FALSE;
        break;
    }
    return is_event_trap;
}

boolean_t trap_id_is_exclude_trap_issu_started(uint32_t trap_id)
{
    switch (trap_id) {
    case SXD_TRAP_ID_GENERAL_ETH_EMAD:
    case SX_TRAP_ID_NEW_DEVICE_ADD:
    case SX_TRAP_ID_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_FDB_EVENT:
    case SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY:
    case SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT:
    case SX_TRAP_ID_ROUTER_MC_ACTIVITY:
    case SX_TRAP_ID_FDB_IP_ADDR_ACTIVITY:
    case SX_TRAP_ID_PORT_ADDED:
    case SX_TRAP_ID_PORT_DELETED:
    case SX_TRAP_ID_PORT_ADDED_TO_LAG:
    case SX_TRAP_ID_PORT_REMOVED_FROM_LAG:
    case SX_TRAP_ID_SIGNAL:
    case SX_TRAP_ID_OBJECT_DELETED_EVENT:
    case SX_TRAP_ID_API_LOGGER_EVENT:
    case SX_TRAP_ID_SDK_HEALTH_EVENT:
    case SX_TRAP_ID_BULK_COUNTER_DONE_EVENT:
    case SX_TRAP_ID_ACL_ACTIVITY:
        return TRUE;

    default:
        return FALSE;
    }

    return FALSE;
}

sx_status_t trap_id_control_type_valid(sx_trap_id_t trap_id, sx_control_type_t control_type)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    switch (trap_id) {
    case SX_TRAP_ID_ETH_L2_STP:
    case SX_TRAP_ID_ETH_L2_LACP:
    case SX_TRAP_ID_ETH_L2_EAPOL:
    case SX_TRAP_ID_ETH_L2_LLDP:
    case SX_TRAP_ID_ETH_L2_MMRP:
    case SX_TRAP_ID_ETH_L2_MVRP:
    case SX_TRAP_ID_ETH_L2_RPVST:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_QUERY:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V1_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_LEAVE:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V3_REPORT:
        break;

    default:
        if (control_type == SX_CONTROL_TYPE_ENABLE) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("SX_CONTROL_TYPE_ENABLE (%u) is not valid for trap id (%u), err: %s\n",
                       control_type, trap_id, sx_status_str(err));
            goto out;
        }
        break;
    }
out:
    SX_LOG_EXIT();
    return err;
}

boolean_t trap_id_is_event(uint16_t syndrome_id)
{
    boolean_t is_event = 0;

    switch (syndrome_id) {
    case SX_TRAP_ID_PUDE:  /* port up/down*/
    case SX_TRAP_ID_PMPE:  /* port module plug / unplug */
    case SXD_TRAP_ID_FLAE: /* FDB learning and aging event */
    case SX_TRAP_ID_TMPW:  /* Temperature warning event */
    case SX_TRAP_ID_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY:
    case SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED:
    case SX_TRAP_ID_TAC_ACTION_DONE:
    case SX_TRAP_ID_BER_MONITOR:
    case SXD_TRAP_ID_MAFBI:
    case SXD_TRAP_ID_MAFRI:
    case SXD_TRAP_ID_ACCU_FLOW_INC:
    case SX_TRAP_ID_SDK_HEALTH_EVENT:
    case SX_TRAP_ID_PORT_TX_READY:
        is_event = TRUE;
        break;

    default:
        is_event = FALSE;
        break;
    }

    return is_event;
}

sx_status_t trap_id_implicitly_set_by_sdk(uint16_t trap_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    switch (trap_id) {
    case SX_TRAP_ID_PUDE:
    case SX_TRAP_ID_PMPE:
    case SXD_TRAP_ID_MFDE:
    case SXD_TRAP_ID_FSHE:
    case SXD_TRAP_ID_FSED:
    case SXD_TRAP_ID_GENERAL_ETH_EMAD:
    case SXD_TRAP_ID_MOCS_DONE:
    case SXD_TRAP_ID_MECCC:
    case SXD_TRAP_ID_PPCNT:
    case SXD_TRAP_ID_MGPCB:
    case SXD_TRAP_ID_MOFRB:
    case SXD_TRAP_ID_PBSR:
    case SXD_TRAP_ID_SBSRD:
    case SX_TRAP_ID_MIRROR:
    case SXD_TRAP_ID_ACCU_FLOW_INC:
    case SXD_TRAP_ID_MAFBI:
    case SXD_TRAP_ID_MAFRI:
    case SXD_TRAP_ID_IPAC_DONE:
        SX_LOG_ERR("Not allowed to set trap ID %d since it has already been implicitly set by SDK.\n", trap_id);
        rc = SX_STATUS_PARAM_ERROR;
        break;

    default:
        break;
    }

    return rc;
}

static sx_status_t __check_fw_default_action_allowed_for_trap_id(uint16_t trap_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (SX_TRAP_ID_SW_CHECK_RANGE(trap_id)) {
        SX_LOG_ERR("Trap action (%u) is not valid for trap id (%u)\n", SX_TRAP_ACTION_SET_FW_DEFAULT, trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (trap_id) {
    case SX_TRAP_ID_TRANSACTION_ERROR:
    case SXD_TRAP_ID_GENERAL_ETH_EMAD:
    case SXD_TRAP_ID_MOCS_DONE:
    case SXD_TRAP_ID_MECCC:
    case SXD_TRAP_ID_PPCNT:
    case SXD_TRAP_ID_MGPCB:
    case SXD_TRAP_ID_MOFRB:
    case SXD_TRAP_ID_PBSR:
    case SXD_TRAP_ID_SBSRD:
    case SX_TRAP_ID_MIRROR_AGENT0:
    case SX_TRAP_ID_MIRROR_AGENT1:
    case SX_TRAP_ID_MIRROR_AGENT2:
    case SX_TRAP_ID_MIRROR_AGENT3:
    case SX_TRAP_ID_MIRROR_AGENT4:
    case SX_TRAP_ID_MIRROR_AGENT5:
    case SX_TRAP_ID_MIRROR_AGENT6:
    case SX_TRAP_ID_MIRROR_AGENT7:
    case SXD_TRAP_ID_ACCU_FLOW_INC:
    case SXD_TRAP_ID_MAFBI:
    case SXD_TRAP_ID_MAFRI:
    case SX_TRAP_ID_PORT_TX_READY:
        SX_LOG_ERR("Trap action (%u) is not valid for trap id (%u)\n", SX_TRAP_ACTION_SET_FW_DEFAULT, trap_id);
        err = SX_STATUS_PARAM_ERROR;
        break;

    default:
        err = SX_STATUS_SUCCESS;
        break;
    }

out:
    return err;
}

sx_status_t trap_id_allowed_trap_action(sx_trap_id_t trap_id, sx_trap_action_t trap_action)
{
    if (trap_action == SX_TRAP_ACTION_SET_FW_DEFAULT) {
        return __check_fw_default_action_allowed_for_trap_id(trap_id);
    }

    switch (trap_id) {
    case SX_TRAP_ID_FDB_MISMATCH:
        if ((trap_action == SX_TRAP_ACTION_SOFT_DISCARD) ||
            (trap_action == SX_TRAP_ACTION_TRAP_SOFT_DISCARD)) {
            SX_LOG_ERR("Trap action (%u) (SOFT_DISCARD) is not valid for trap id (%u)\n", trap_action, trap_id);
            return SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_TRAP_ID_FID_MISS:
        if ((trap_action == SX_TRAP_ACTION_IGNORE) ||
            (trap_action == SX_TRAP_ACTION_MIRROR_2_CPU) ||
            (trap_action == SX_TRAP_ACTION_SOFT_DISCARD) ||
            (trap_action == SX_TRAP_ACTION_TRAP_SOFT_DISCARD)) {
            SX_LOG_ERR("Trap action (%u) is not valid for trap id (%u)\n", trap_action, trap_id);
            return SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_TRAP_ID_FDB:
    case SX_TRAP_ID_GENERAL_FDB:
    case SX_TRAP_ID_ARN_RECEIVE_OK:
        if ((trap_action == SX_TRAP_ACTION_TRAP_2_CPU) || (trap_action == SX_TRAP_ACTION_DISCARD)) {
            SX_LOG_ERR("Trap action (%u) is not valid for trap id (%u)\n", trap_action, trap_id);
            return SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_TRAP_ID_ETH_L2_STP:
    case SX_TRAP_ID_ETH_L2_LACP:
    case SX_TRAP_ID_ETH_L2_EAPOL:
    case SX_TRAP_ID_ETH_L2_LLDP:
    case SX_TRAP_ID_ETH_L2_MMRP:
    case SX_TRAP_ID_ETH_L2_MVRP:
    case SX_TRAP_ID_ETH_L2_RPVST:
        /* These Link layer protocols may be forwarded */
        break;

    case SX_TRAP_ID_PIM:
    case SX_TRAP_ID_HOST_MISS_IPV4:
    case SX_TRAP_ID_HOST_MISS_IPV6:
        if ((trap_action == SX_TRAP_ACTION_IGNORE) || (trap_action == SX_TRAP_ACTION_MIRROR_2_CPU)) {
            SX_LOG_ERR("Trap action (%u) is not valid for trap id (%u)\n", trap_action, trap_id);
            return SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_TRAP_ID_FDB_SRC_MISS:
        if ((trap_action == SX_TRAP_ACTION_SOFT_DISCARD) || (trap_action == SX_TRAP_ACTION_TRAP_SOFT_DISCARD)) {
            SX_LOG_ERR("Trap action (%u) is not valid for trap id (%u)\n", trap_action, trap_id);
            return SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_TRAP_ID_PACKET_RECEIVED:
        if ((trap_action != SX_TRAP_ACTION_TRAP_2_CPU) && (trap_action != SX_TRAP_ACTION_DISCARD)) {
            SX_LOG_ERR("Trap action (%u) is not valid for trap id (%u)\n", trap_action, trap_id);
            return SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_TRAP_ID_NVE_DECAP_FRAG_ERROR:
        if ((trap_action == SX_TRAP_ACTION_IGNORE) || (trap_action == SX_TRAP_ACTION_MIRROR_2_CPU)) {
            SX_LOG_ERR("Trap action (%u) is not valid for trap id (%u)\n", trap_action, trap_id);
            return SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_TRAP_ID_DISCARD_ING_PACKET:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_VLAN:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_STP:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LINK_LOCAL:
    case SX_TRAP_ID_DISCARD_ING_LSR_NO_LABEL:
    case SX_TRAP_ID_DISCARD_ING_LSR_UC_ET:
    case SX_TRAP_ID_DISCARD_ING_LSR_MC_DMAC:
    case SX_TRAP_ID_DISCARD_LSR_MIN_LABEL:
    case SX_TRAP_ID_DISCARD_LSR_MAX_LABEL:
    case SX_TRAP_ID_DISCARD_LSR_LB:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0:
    case SX_TRAP_ID_DISCARD_ENC_ISOLATION:
    case SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0:
    case SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR:
        if ((trap_action != SX_TRAP_ACTION_EXCEPTION_TRAP) && (trap_action != SX_TRAP_ACTION_DISCARD) &&
            (trap_action != SX_TRAP_ACTION_IGNORE)) {
            SX_LOG_ERR("Trap action (%u) is not valid for trap id (%u)\n", trap_action, trap_id);
            return SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_TRAP_ID_DISCARD_ING_SWITCH:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH:
    case SX_TRAP_ID_DISCARD_ING_ROUTER:
    case SX_TRAP_ID_DISCARD_ING_LSR:
    case SX_TRAP_ID_DISCARD_ROUTER:
    case SX_TRAP_ID_DISCARD_ROUTER2:
    case SX_TRAP_ID_DISCARD_ROUTER3:
    case SX_TRAP_ID_DISCARD_LSR:
    case SX_TRAP_ID_DISCARD_LSR2:
    case SX_TRAP_ID_DISCARD_LSR3:
    case SX_TRAP_ID_DISCARD_DEC:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH:
    case SX_TRAP_ID_DISCARD_ISOLATION:
    case SX_TRAP_ID_DISCARD_NON_ROUTED:
    case SX_TRAP_ID_DISCARD_EGR_LSR:
    case SX_TRAP_ID_DISCARD_MC_SCOPE:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS:
    case SX_TRAP_ID_DISCARD_ROUTER_IRIF_EN:
    case SX_TRAP_ID_DISCARD_ROUTER_ERIF_EN:
    case SX_TRAP_ID_DISCARD_ROUTER_ERIF_FWD:
    case SX_TRAP_ID_DISCARD_ROUTER_LPM4:
    case SX_TRAP_ID_DISCARD_ROUTER_LPM6:
    case SX_TRAP_ID_DISCARD_EGR_LSR_NO_LABEL:
    case SX_TRAP_ID_DISCARD_EGR_LSR_NO_IP:
    case SX_TRAP_ID_DISCARD_EGR_LSR_PHP_NO_IP:
    case SX_TRAP_ID_DISCARD_DEC_PKT:
    case SX_TRAP_ID_DISCARD_DEC_NVE_OPTIONS:
    case SX_TRAP_ID_DISCARD_DEC_DIS:

        if ((trap_action != SX_TRAP_ACTION_EXCEPTION_TRAP) && (trap_action != SX_TRAP_ACTION_DISCARD)) {
            SX_LOG_ERR("Trap action (%u) is not valid for trap id (%u)\n", trap_action, trap_id);
            return SX_STATUS_PARAM_ERROR;
        }
        break;

    default:
        return SX_STATUS_SUCCESS;
    }
    /* O/W: */
    return SX_STATUS_SUCCESS;
}

sx_status_t trap_id_is_supported_switchx(sx_trap_id_t trap_id)
{
    if (((trap_id >= SX_TRAP_ID_ACL_MIN) && (trap_id <= SX_TRAP_ID_ACL_MAX)) ||
        ((trap_id >= SX_TRAP_ID_IPTRAP_MIN) && (trap_id <= SX_TRAP_ID_IPTRAP_MAX))) {
        return SX_STATUS_SUCCESS;
    }

    switch ((uint16_t)trap_id) {
    /* GENERAL */
    case SX_TRAP_ID_GENERAL_FDB:
    case SX_TRAP_ID_GENERAL_DR_IPC:
    case SX_TRAP_ID_GENERAL_DR_RES:
    case SXD_TRAP_ID_GENERAL_ETH_EMAD:
    case SX_TRAP_ID_FDB:

    /* EVENTS */
    case SX_TRAP_ID_PUDE:
    case SX_TRAP_ID_PMPE:
    case SXD_TRAP_ID_FLAE:
    case SX_TRAP_ID_TMPW:
    case SX_TRAP_ID_BER_MONITOR:
    case SX_TRAP_ID_MFRI:
    case SX_TRAP_ID_PPIR:
    case SX_TRAP_ID_MFCDR:
    case SX_TRAP_ID_IBISSU:
    case SX_TRAP_ID_SPZR:

    /* ETHERNET L2 */
    case SX_TRAP_ID_ETH_L2_STP:
    case SX_TRAP_ID_ETH_L2_LACP:
    case SX_TRAP_ID_ETH_L2_EAPOL:
    case SX_TRAP_ID_ETH_L2_LLDP:
    case SX_TRAP_ID_ETH_L2_MMRP:
    case SX_TRAP_ID_ETH_L2_MVRP:
    case SX_TRAP_ID_ETH_L2_RPVST:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_QUERY:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V1_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V3_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_LEAVE:
    case SX_TRAP_ID_ETH_L2_DHCP:
    case SX_TRAP_ID_ETH_L2_DHCPV6:
    case SX_TRAP_ID_ETH_L2_PACKET_SAMPLING:
    case SX_TRAP_ID_ETH_L2_RARP_OPCODES:

    /* IPV6 L2 */
    case SX_TRAP_ID_IPV6_MLD_V1_V2:
    case SX_TRAP_ID_IPV6_MLD_V1_REPORT:
    case SX_TRAP_ID_IPV6_MLD_V1_DONE:
    case SX_TRAP_ID_IPV6_MLD_V2_REPORT:

    /* FCoE */
    case SX_TRAP_ID_FCOE_FIP:

    /* Telemetry threshold crossing */
    case SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED:

    /* Router */
    case SX_TRAP_ID_ARP_REQUEST:
    case SX_TRAP_ID_ARP_RESPONSE:
    case SX_TRAP_ID_ETH_L3_MTUERROR:
    case SX_TRAP_ID_ETH_L3_TTLERROR:
    case SX_TRAP_ID_ETH_L3_LBERROR:
    case SX_TRAP_ID_OSPF:
    case SX_TRAP_ID_RIP_V1:
    case SX_TRAP_ID_RIP_V2:
    case SX_TRAP_ID_PIM:
    case SX_TRAP_ID_VRRP:
    case SX_TRAP_ID_VRRP_IPV6:
    case SX_TRAP_ID_RESERVED_MC:
    case SX_TRAP_ID_IPBC:
    case SX_TRAP_ID_ETH_L3_RPF:
    case SX_TRAP_ID_ETH_L3_URPF_PROTECTION:
    case SX_TRAP_ID_ETH_L3_ASSERT:
    case SX_TRAP_ID_L3_UC_IP_BASE:
    case SX_TRAP_ID_L3_NEIGH_IP_BASE:
    case SX_TRAP_ID_L3_MC_IP_BASE:

    /* IPV6 ROUTER */
    case SX_TRAP_ID_IPV6_LINK_LOCAL_DST:
    case SX_TRAP_ID_IPV6_LINK_LOCAL_SRC:
    case SX_TRAP_ID_IPV6_ALL_NODES_LINK:
    case SX_TRAP_ID_IPV6_ROUTER_SOLICITATION:
    case SX_TRAP_ID_IPV6_ROUTER_ADVERTISEMENT:
    case SX_TRAP_ID_IPV6_NEIGHBOR_SOLICITATION:
    case SX_TRAP_ID_IPV6_NEIGHBOR_ADVERTISEMENT:
    case SX_TRAP_ID_IPV6_REDIRECTION:

    /* InfiniBand */
    case SX_TRAP_ID_INFINIBAND_QP0:
    case SX_TRAP_ID_INFINIBAND_QP1:
    case SX_TRAP_ID_INFINIBAND_OTHER_QPS:
    case SX_TRAP_ID_INFINIBAND_EXTERNAL_SMA:
    case SX_TRAP_ID_INFINIBAND_IB_FMAD_RCV:
    case SX_TRAP_ID_INFINIBAND_IN_NV_ACCESS_REG:
    case SX_TRAP_ID_INFINIBAND_RESET_CMD:

    /* SDK Test Traps */
    case SX_TRAP_ID_SDK_TEST1:
    case SX_TRAP_ID_SDK_TEST2:

    /* SWITCHX SDK EVENTS */
    case SX_TRAP_ID_SIGNAL:
    case SX_TRAP_ID_NEW_DEVICE_ADD:
    case SX_TRAP_ID_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_FDB_EVENT:
    case SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY:
    case SXD_TRAP_ID_CPUWD:
    case SXD_TRAP_ID_FORE:
    case SX_TRAP_ID_IPV6_OSPF:
    case SX_TRAP_ID_IPV6_DHCP:
    case SX_TRAP_ID_FDB_SRC_MISS:
    case SX_TRAP_ID_SDK_HEALTH_EVENT:
    case SX_TRAP_ID_BULK_COUNTER_DONE_EVENT:

        return SX_STATUS_SUCCESS;

    default:
        SX_LOG_ERR("Trap ID (%u) is not valid\n", trap_id);
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t trap_id_is_supported_spectrum(sx_trap_id_t trap_id)
{
    if (((trap_id >= SX_TRAP_ID_ACL_MIN) && (trap_id <= SX_TRAP_ID_ACL_MAX)) ||
        ((trap_id >= SX_TRAP_ID_IPTRAP_MIN) && (trap_id <= SX_TRAP_ID_IPTRAP_MAX))) {
        return SX_STATUS_SUCCESS;
    }

    switch ((uint16_t)trap_id) {
    /* GENERAL */
    case SX_TRAP_ID_GENERAL_FDB:
    case SXD_TRAP_ID_GENERAL_ETH_EMAD:
    case SXD_TRAP_ID_MOCS_DONE:
    case SXD_TRAP_ID_MECCC:
    case SXD_TRAP_ID_PPCNT:
    case SXD_TRAP_ID_MGPCB:
    case SXD_TRAP_ID_PBSR:
    case SXD_TRAP_ID_SBSRD:
    case SX_TRAP_ID_FDB:
    case SX_TRAP_ID_TRANSACTION_ERROR:

    /* EVENTS */
    case SX_TRAP_ID_PUDE:
    case SX_TRAP_ID_PMPE:
    case SXD_TRAP_ID_FLAE:
    case SX_TRAP_ID_TMPW:
    case SX_TRAP_ID_BER_MONITOR:
    case SX_TRAP_ID_PACKET_RECEIVED:

    /* ETHERNET L2 */
    case SX_TRAP_ID_ETH_L2_STP:
    case SX_TRAP_ID_ETH_L2_LACP:
    case SX_TRAP_ID_ETH_L2_EAPOL:
    case SX_TRAP_ID_ETH_L2_LLDP:
    case SX_TRAP_ID_ETH_L2_MMRP:
    case SX_TRAP_ID_ETH_L2_MVRP:
    case SX_TRAP_ID_ETH_L2_RPVST:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_QUERY:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V1_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V3_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_LEAVE:
    case SX_TRAP_ID_ETH_L2_DHCP:
    case SX_TRAP_ID_ETH_L2_DHCPV6:
    case SX_TRAP_ID_ETH_L2_UDLD:
    case SX_TRAP_ID_ETH_L2_PACKET_SAMPLING:
    case SX_TRAP_ID_ETH_L2_RARP_OPCODES:
    case SX_TRAP_ID_FDB_MISMATCH:
    case SX_TRAP_ID_FID_MISS:

    /* IPV6 L2 */
    case SX_TRAP_ID_IPV6_MLD_V1_V2:
    case SX_TRAP_ID_IPV6_MLD_V1_REPORT:
    case SX_TRAP_ID_IPV6_MLD_V1_DONE:
    case SX_TRAP_ID_IPV6_MLD_V2_REPORT:

    /* FCoE */
    case SX_TRAP_ID_FCOE_FIP:

    /* Telemetry threshold crossing */
    case SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED:

    /* Router */
    case SX_TRAP_ID_ARP_REQUEST:
    case SX_TRAP_ID_ARP_RESPONSE:
    case SX_TRAP_ID_ETH_L3_MTUERROR:
    case SX_TRAP_ID_ETH_L3_TTLERROR:
    case SX_TRAP_ID_ETH_L3_LBERROR:
    case SX_TRAP_ID_OSPF:
    case SX_TRAP_ID_RIP_V1:
    case SX_TRAP_ID_RIP_V2:
    case SX_TRAP_ID_PIM:
    case SX_TRAP_ID_VRRP:
    case SX_TRAP_ID_VRRP_IPV6:
    case SX_TRAP_ID_RESERVED_MC:
    case SX_TRAP_ID_IPBC:
    case SX_TRAP_ID_ETH_L3_RPF:
    case SX_TRAP_ID_ETH_L3_URPF_PROTECTION:
    case SX_TRAP_ID_ETH_L3_ASSERT:
    case SX_TRAP_ID_L3_UC_IP_BASE:
    case SX_TRAP_ID_L3_NEIGH_IP_BASE:
    case SX_TRAP_ID_L3_MC_IP_BASE:
    case SX_TRAP_ID_HOST_MISS_IPV4:
    case SX_TRAP_ID_HOST_MISS_IPV6:
    case SX_TRAP_ID_IP2ME:
    case SX_TRAP_ID_BFD_IPV4:
    case SX_TRAP_ID_BFD_IPV6:
    case SX_TRAP_ID_SSH_IPV4:
    case SX_TRAP_ID_SSH_IPV6:
    case SX_TRAP_ID_PING_IPV4:
    case SX_TRAP_ID_PING_IPV6:
    case SX_TRAP_ID_ROUTER_ALERT_IPV4:
    case SX_TRAP_ID_IPV4_DHCP:
    case SX_TRAP_ID_IPV6_DHCP:
    case SX_TRAP_ID_SNMP_IPV4:
    case SX_TRAP_ID_SNMP_IPV6:
    case SX_TRAP_ID_ROUTER_ARPBC:
    case SX_TRAP_ID_ROUTER_ARPUC:
    case SX_TRAP_ID_ROUTER_RARP_OPCODES:

    /* IPV6 ROUTER */
    case SX_TRAP_ID_IPV6_UNSPECIFIED_SIP:
    case SX_TRAP_ID_IPV6_UNSPECIFIED_DIP:
    case SX_TRAP_ID_IPV6_LINK_LOCAL_DST:
    case SX_TRAP_ID_IPV6_LINK_LOCAL_SRC:
    case SX_TRAP_ID_IPV6_ALL_NODES_LINK:
    case SX_TRAP_ID_IPV6_ROUTER_SOLICITATION:
    case SX_TRAP_ID_IPV6_ROUTER_ADVERTISEMENT:
    case SX_TRAP_ID_IPV6_NEIGHBOR_SOLICITATION:
    case SX_TRAP_ID_IPV6_NEIGHBOR_ADVERTISEMENT:
    case SX_TRAP_ID_IPV6_REDIRECTION:
    case SX_TRAP_ID_IPV6_ALL_ROUTERS_LINK:
    case SX_TRAP_ID_ROUTER_ALERT_IPV6:

    /* MPLS */
    case SX_TRAP_ID_MPLS_ILM_MISS:
    case SX_TRAP_ID_MPLS_LDP:
    case SX_TRAP_ID_MPLS_LB_LSP_PING:
    case SX_TRAP_ID_MPLS_ILM0:
    case SX_TRAP_ID_MPLS_ILM1:
    case SX_TRAP_ID_MPLS_ILM2:
    case SX_TRAP_ID_MPLS_ILM3:
    case SX_TRAP_ID_MPLS_NHLFE0:
    case SX_TRAP_ID_MPLS_NHLFE1:
    case SX_TRAP_ID_MPLS_NHLFE2:
    case SX_TRAP_ID_MPLS_NHLFE3:

    /* BGP */
    case SX_TRAP_ID_IPV4_BGP:
    case SX_TRAP_ID_IPV6_BGP:

    /* SDK Test Traps */
    case SX_TRAP_ID_SDK_TEST1:
    case SX_TRAP_ID_SDK_TEST2:

    /* SWITCHX SDK EVENTS */
    case SX_TRAP_ID_SIGNAL:
    case SX_TRAP_ID_NEW_DEVICE_ADD:
    case SX_TRAP_ID_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_FDB_EVENT:
    case SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY:
    case SX_TRAP_ID_ROUTER_MC_ACTIVITY:
    case SX_TRAP_ID_FDB_IP_ADDR_ACTIVITY:
    case SX_TRAP_ID_PORT_ADDED:
    case SX_TRAP_ID_PORT_DELETED:
    case SX_TRAP_ID_PORT_ADDED_TO_LAG:
    case SX_TRAP_ID_PORT_REMOVED_FROM_LAG:
    case SX_TRAP_ID_OBJECT_DELETED_EVENT:
    case SXD_TRAP_ID_CPUWD:
    case SXD_TRAP_ID_FORE:
    case SX_TRAP_ID_IPV6_OSPF:
    case SX_TRAP_ID_FDB_SRC_MISS:
    case SX_TRAP_ID_SDK_HEALTH_EVENT:
    case SX_TRAP_ID_PORT_PROFILE_APPLY_DONE:
    case SX_TRAP_ID_BULK_COUNTER_DONE_EVENT:
    case SX_TRAP_ID_API_LOGGER_EVENT:
    case SX_TRAP_ID_ACL_ACTIVITY:
    /* async */
    case SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT:

    /* SPAN */
    case SX_TRAP_ID_MIRROR:

    /* User Defined */
    case SX_TRAP_ID_USER_BASE:
    case SX_TRAP_ID_USER_MAX:
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE0:
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE1:
    case SX_TRAP_ID_USER_ETH_CONF_TYPE0:
    case SX_TRAP_ID_USER_ETH_CONF_TYPE1:
    case SX_TRAP_ID_USER_OVERLAY_ICMPV6_CONF_TYPE:
    case SX_TRAP_ID_USER_NVE_DECAP_ETH:

    /* Tunneling */
    case SX_TRAP_ID_IPIP_DECAP_ERROR:
    case SX_TRAP_ID_DECAP_ENCAP:
    case SX_TRAP_ID_IPIP_ERROR:
    case SX_TRAP_ID_NVE_DECAP_IGMP:
    case SX_TRAP_ID_NVE_DECAP_ARP:
    case SX_TRAP_ID_NVE_DECAP_TAG_ERROR:
    case SX_TRAP_ID_NVE_IPV4_DHCP:
    case SX_TRAP_ID_NVE_IPV6_DHCP:
    case SX_TRAP_ID_NVE_DECAP_FRAG_ERROR:
    case SX_TRAP_ID_NVE_ENCAP_ARP:
    case SX_TRAP_ID_NVE_DECAP_MLD:
    case SX_TRAP_ID_DECAP_ECN0:
    case SX_TRAP_ID_DECAP_ECN1:

    /* PTP */
    case SX_TRAP_ID_PTP_EVENT:
    case SX_TRAP_ID_PTP_GENERAL:
    case SX_TRAP_ID_PTP_ING_EVENT:
    case SX_TRAP_ID_PTP_EGR_EVENT:

    /* Discards */
    case SX_TRAP_ID_DISCARD_ING_PACKET:
    case SX_TRAP_ID_DISCARD_ING_SWITCH:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH:
    case SX_TRAP_ID_DISCARD_ING_ROUTER:
    case SX_TRAP_ID_DISCARD_ING_LSR:
    case SX_TRAP_ID_DISCARD_ROUTER:
    case SX_TRAP_ID_DISCARD_ROUTER2:
    case SX_TRAP_ID_DISCARD_ROUTER3:
    case SX_TRAP_ID_DISCARD_LSR:
    case SX_TRAP_ID_DISCARD_LSR2:
    case SX_TRAP_ID_DISCARD_LSR3:
    case SX_TRAP_ID_DISCARD_DEC:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH:
    case SX_TRAP_ID_DISCARD_ISOLATION:
    case SX_TRAP_ID_DISCARD_NON_ROUTED:
    case SX_TRAP_ID_DISCARD_EGR_LSR:
    case SX_TRAP_ID_DISCARD_MC_SCOPE:

    /* Extended Discards */

    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC:

    case SX_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_VLAN:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_STP:

    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS:

    case SX_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LINK_LOCAL:

    case SX_TRAP_ID_DISCARD_ING_LSR_NO_LABEL:
    case SX_TRAP_ID_DISCARD_ING_LSR_UC_ET:
    case SX_TRAP_ID_DISCARD_ING_LSR_MC_DMAC:

    case SX_TRAP_ID_DISCARD_ROUTER_IRIF_EN:
    case SX_TRAP_ID_DISCARD_ROUTER_ERIF_EN:
    case SX_TRAP_ID_DISCARD_ROUTER_ERIF_FWD:
    case SX_TRAP_ID_DISCARD_ROUTER_LPM4:
    case SX_TRAP_ID_DISCARD_ROUTER_LPM6:

    case SX_TRAP_ID_DISCARD_LSR_MIN_LABEL:
    case SX_TRAP_ID_DISCARD_LSR_MAX_LABEL:
    case SX_TRAP_ID_DISCARD_LSR_LB:

    case SX_TRAP_ID_DISCARD_DEC_PKT:
    case SX_TRAP_ID_DISCARD_DEC_NVE_OPTIONS:
    case SX_TRAP_ID_DISCARD_DEC_DIS:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC:
    case SX_TRAP_ID_DISCARD_ENC_ISOLATION:

    case SX_TRAP_ID_DISCARD_EGR_LSR_NO_LABEL:
    case SX_TRAP_ID_DISCARD_EGR_LSR_NO_IP:
    case SX_TRAP_ID_DISCARD_EGR_LSR_PHP_NO_IP:

    case SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0:
    case SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1:

        return SX_STATUS_SUCCESS;

    default:
        SX_LOG_ERR("Trap ID (%u) is not valid\n", trap_id);
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t trap_id_is_supported_spectrum2(sx_trap_id_t trap_id)
{
    if (((trap_id >= SX_TRAP_ID_MIRROR_AGENT0) && (trap_id <= SX_TRAP_ID_MIRROR_AGENT7)) ||
        (trap_id == SX_TRAP_ID_QUEUE_SNAPSHOT_TRIGGER_EVENT)) {
        return SX_STATUS_SUCCESS;
    } else if ((trap_id == SX_TRAP_ID_PTP_ING_EVENT) || (trap_id == SX_TRAP_ID_PTP_EGR_EVENT)) {
        SX_LOG_ERR("PTP FIFO events are not supported\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    } else if (SX_TRAP_ID_USER_ATTR_EXT_CHECK_RANGE(trap_id)) {
        return SX_STATUS_SUCCESS;
    } else if (SX_TRAP_ID_MGMT_TRAP_CHECK_RANGE(trap_id)) {
        return SX_STATUS_SUCCESS;
    } else if (SX_TRAP_ID_MACSEC_TRAP_CHECK_RANGE(trap_id)) {
        return SX_STATUS_SUCCESS;
    } else if ((trap_id == (sx_trap_id_t)SXD_TRAP_ID_MOFRB)) {
        return SX_STATUS_SUCCESS;
    } else if (trap_id == SX_TRAP_ID_ARN_RECEIVE_OK) {
        return SX_STATUS_SUCCESS;
    } else {
        return trap_id_is_supported_spectrum(trap_id);
    }
}

sx_status_t trap_id_is_supported_spectrum3(sx_trap_id_t trap_id)
{
    switch (trap_id) {
    case SX_TRAP_ID_PORT_TX_READY:
        return SX_STATUS_SUCCESS;

    default:
        return trap_id_is_supported_spectrum2(trap_id);
    }
}

sx_status_t trap_id_is_supported_spectrum4(sx_trap_id_t trap_id)
{
    switch (trap_id) {
    case SX_TRAP_ID_STATEFUL_DB_PARTITION_THRESHOLD_CROSSED:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0:
    case SX_TRAP_ID_TAC_ACTION_DONE:
        return SX_STATUS_SUCCESS;

    default:
        return trap_id_is_supported_spectrum3(trap_id);
    }
}

sx_status_t trap_id_is_supported_device(sx_trap_id_t trap_id)
{
    /* Make sure trap_id_supported_cb exists */
    if (brg_context.spec_cb_g.trap_id_supported_cb == NULL) {
        SX_LOG_ERR("trap_id_supported_cb not set.\n");
        return SX_STATUS_ERROR;
    }
    return brg_context.spec_cb_g.trap_id_supported_cb(trap_id);
}

sx_status_t trap_id_conflicts_check(sx_trap_id_t trap_id)
{
    if (brg_context.spec_cb_g.host_ifc_check_trap_id_conflicts_cb == NULL) {
        return SX_STATUS_SUCCESS;
    }
    return brg_context.spec_cb_g.host_ifc_check_trap_id_conflicts_cb(trap_id);
}

sx_status_t trap_id_conflicts_check_spectrum(sx_trap_id_t trap_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (SX_TRAP_ID_DISCARD_CHECK_RANGE(trap_id) == TRUE) {
        err = host_ifc_db_discard_trap_check(trap_id);
    } else if (SX_TRAP_ID_EXTENDED_DISCARD_CHECK_RANGE(trap_id) == TRUE) {
        err = host_ifc_db_extended_discard_trap_check(trap_id);
    }

    return err;
}

static sx_status_t __default_action_set_wrapper(const sx_trap_id_t trap_id,
                                                sx_trap_action_t  *trap_action_p,
                                                boolean_t         *has_default_action_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.host_ifc_default_action_set_cb == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "brg_context.spec_cb_g.host_ifc_default_action_set_cb is NULL [%s]\n",
               sx_status_str(sx_status));
        goto out;
    }

    sx_status =
        brg_context.spec_cb_g.host_ifc_default_action_set_cb(trap_id, trap_action_p, has_default_action_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "host_ifc_default_action_set_cb failed. [%s]\n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t trap_id_default_action_set_spectrum(const sx_trap_id_t trap_id,
                                                sx_trap_action_t  *trap_action_p,
                                                boolean_t         *has_default_action_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    *trap_action_p = SX_TRAP_ACTION_IGNORE;

    switch (trap_id) {
    /*Will set the traps to SX_TRAP_ACTION_IGNORE in SDK int and unset trap*/
    case SX_TRAP_ID_PTP_ING_EVENT:
    case SX_TRAP_ID_PTP_EGR_EVENT:
    case SX_TRAP_ID_ETH_L3_ASSERT:
        *has_default_action_p = TRUE;
        *trap_action_p = SX_TRAP_ACTION_IGNORE;
        break;

    case SX_TRAP_ID_DISCARD_ISOLATION:
        *has_default_action_p = FALSE;
        *trap_action_p = SX_TRAP_ACTION_SET_FW_DEFAULT;
        break;

    default:
        *has_default_action_p = FALSE;
        break;
    }

    return sx_status;
}

sx_status_t trap_id_default_action_set_spectrum2(const sx_trap_id_t trap_id,
                                                 sx_trap_action_t  *trap_action_p,
                                                 boolean_t         *has_default_action_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    *trap_action_p = SX_TRAP_ACTION_IGNORE;

    switch (trap_id) {
    /*We want to configure FWD_DISCARD_ERROR (RO).For this operation we
     * need to send the FW - SX_TRAP_ACTION_SET_FW_DEFAULT */
    case SX_TRAP_ID_DISCARD_ISOLATION:
        *has_default_action_p = TRUE;
        *trap_action_p = SX_TRAP_ACTION_SET_FW_DEFAULT;
        break;

    case SX_TRAP_ID_USER_CONF_SWITCH0:
    case SX_TRAP_ID_USER_CONF_SWITCH1:
    case SX_TRAP_ID_USER_CONF_SWITCH2:
    case SX_TRAP_ID_USER_CONF_SWITCH3:
    case SX_TRAP_ID_USER_CONF_ROUTER0:
    case SX_TRAP_ID_USER_CONF_ROUTER1:
    case SX_TRAP_ID_USER_CONF_ROUTER2:
    case SX_TRAP_ID_USER_CONF_ROUTER3:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC0:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC1:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC2:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC3:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC0:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC1:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC2:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC3:
        *has_default_action_p = TRUE;
        *trap_action_p = SX_TRAP_ACTION_IGNORE;
        break;

    default:
        *has_default_action_p = FALSE;
        break;
    }

    return sx_status;
}

sx_status_t trap_id_default_action_set_ib(const sx_trap_id_t trap_id,
                                          sx_trap_action_t  *trap_action_p,
                                          boolean_t         *has_default_action_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    *trap_action_p = SX_TRAP_ACTION_IGNORE;

    switch (trap_id) {
    case SX_TRAP_ID_INFINIBAND_QP0:
    case SX_TRAP_ID_INFINIBAND_QP1:
    case SX_TRAP_ID_INFINIBAND_OTHER_QPS:
    case SX_TRAP_ID_INFINIBAND_EXTERNAL_SMA:
        *has_default_action_p = TRUE;
        *trap_action_p = SX_TRAP_ACTION_DISCARD;
        break;

    default:
        *has_default_action_p = FALSE;
        break;
    }

    return sx_status;
}

sx_status_t trap_id_defaults_get(sx_trap_id_t        trap_id,
                                 boolean_t          *has_default_action_p,
                                 sx_hw_trap_group_e *hw_trap_group_p,
                                 sx_trap_action_t   *trap_action_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    switch (trap_id) {
    /*Will set the traps to SX_TRAP_ACTION_IGNORE in SDK init and unset trap*/
    case SX_TRAP_ID_ETH_L2_STP:
    case SX_TRAP_ID_ETH_L2_LACP:
    case SX_TRAP_ID_ETH_L2_EAPOL:
    case SX_TRAP_ID_ETH_L2_LLDP:
    case SX_TRAP_ID_ETH_L2_MMRP:
    case SX_TRAP_ID_ETH_L2_MVRP:
    case SX_TRAP_ID_ETH_L2_RPVST:
    case SX_TRAP_ID_ETH_L2_UDLD:
    case SX_TRAP_ID_ETH_L2_DHCP:
    case SX_TRAP_ID_ETH_L2_DHCPV6:
    case SX_TRAP_ID_FCOE_FIP:
    case SX_TRAP_ID_PTP_EVENT:
    case SX_TRAP_ID_PTP_GENERAL:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_QUERY:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V1_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_LEAVE:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V3_REPORT:
    case SX_TRAP_ID_USER_ETH_CONF_TYPE0:
    case SX_TRAP_ID_USER_ETH_CONF_TYPE1:
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE0:
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE1:
    case SX_TRAP_ID_USER_OVERLAY_ICMPV6_CONF_TYPE:
    case SX_TRAP_ID_ETH_L2_RARP_OPCODES:
    case SX_TRAP_ID_OSPF:
    case SX_TRAP_ID_RIP_V1:
    case SX_TRAP_ID_RIP_V2:
    case SX_TRAP_ID_VRRP:
    case SX_TRAP_ID_IPV6_OSPF:
    case SX_TRAP_ID_IPV6_MLD_V1_V2:
    case SX_TRAP_ID_IPV6_MLD_V1_REPORT:
    case SX_TRAP_ID_IPV6_MLD_V1_DONE:
    case SX_TRAP_ID_IPV6_MLD_V2_REPORT:
    case SX_TRAP_ID_IPV6_DHCP:
    case SX_TRAP_ID_VRRP_IPV6:
    case SX_TRAP_ID_IPV4_BGP:
    case SX_TRAP_ID_IPV6_BGP:
    case SX_TRAP_ID_IPV6_ROUTER_SOLICITATION:
    case SX_TRAP_ID_IPV6_ROUTER_ADVERTISEMENT:
    case SX_TRAP_ID_IPV6_NEIGHBOR_SOLICITATION:
    case SX_TRAP_ID_IPV6_NEIGHBOR_ADVERTISEMENT:
    case SX_TRAP_ID_IPV6_REDIRECTION:
    case SX_TRAP_ID_MPLS_LDP:
    case SX_TRAP_ID_MPLS_LB_LSP_PING:
    case SX_TRAP_ID_NVE_DECAP_IGMP:
    case SX_TRAP_ID_NVE_DECAP_ARP:
    case SX_TRAP_ID_NVE_DECAP_TAG_ERROR:
    case SX_TRAP_ID_NVE_IPV4_DHCP:
    case SX_TRAP_ID_NVE_IPV6_DHCP:
    case SX_TRAP_ID_NVE_ENCAP_ARP:
    case SX_TRAP_ID_USER_NVE_DECAP_ETH:
    case SX_TRAP_ID_NVE_DECAP_MLD:
    case SX_TRAP_ID_IP2ME_CUSTOM0:
    case SX_TRAP_ID_IP2ME_CUSTOM1:
    case SX_TRAP_ID_BFD_IPV4:
    case SX_TRAP_ID_BFD_IPV6:
    case SX_TRAP_ID_SSH_IPV4:
    case SX_TRAP_ID_SSH_IPV6:
    case SX_TRAP_ID_PING_IPV4:
    case SX_TRAP_ID_PING_IPV6:
    case SX_TRAP_ID_ROUTER_ALERT_IPV4:
    case SX_TRAP_ID_ROUTER_ALERT_IPV6:
    case SX_TRAP_ID_SNMP_IPV4:
    case SX_TRAP_ID_SNMP_IPV6:
    case SX_TRAP_ID_ROUTER_ARPBC:
    case SX_TRAP_ID_ROUTER_ARPUC:
    case SX_TRAP_ID_ROUTER_RARP_OPCODES:
    case SX_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC:
    case SX_TRAP_ID_DECAP_ECN0:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0:
    case SX_TRAP_ID_TAC_ACTION_DONE:
        *has_default_action_p = TRUE;
        *hw_trap_group_p = 0;
        *trap_action_p = SX_TRAP_ACTION_IGNORE;
        break;

    /* Will set the traps to SX_TRAP_ACTION_DISCARD in SDK init and unset trap*/
    case SX_TRAP_ID_DISCARD_ROUTER2:
    case SX_TRAP_ID_DISCARD_ROUTER3:
    case SX_TRAP_ID_DISCARD_LSR2:
    case SX_TRAP_ID_DISCARD_LSR3:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_VLAN:
    case SX_TRAP_ID_IPV6_ALL_ROUTERS_LINK:
        *has_default_action_p = TRUE;
        *hw_trap_group_p = 0;
        *trap_action_p = SX_TRAP_ACTION_DISCARD;
        break;

    /* Will set the traps to SX_TRAP_ACTION_SOFT_DISCARD in SDK init and unset trap*/
    case SX_TRAP_ID_RESERVED_MC:
    case SX_TRAP_ID_IPBC:
    case SX_TRAP_ID_IPV6_UNSPECIFIED_SIP:
        *has_default_action_p = TRUE;
        *hw_trap_group_p = 0;
        *trap_action_p = SX_TRAP_ACTION_SOFT_DISCARD;
        break;

    /* We want to configure trap_action = FWD_DISCARD_ERROR (RO). For this operation we
     * need to send the FW - SX_TRAP_ACTION_SET_FW_DEFAULT */
    case SX_TRAP_ID_DECAP_ECN1:
    case SX_TRAP_ID_ETH_L3_MTUERROR:
    case SX_TRAP_ID_ETH_L3_TTLERROR:
    case SX_TRAP_ID_ETH_L3_LBERROR:
    case SX_TRAP_ID_IPV6_LINK_LOCAL_DST:
    case SX_TRAP_ID_IPV6_LINK_LOCAL_SRC:
    case SX_TRAP_ID_HOST_MISS_IPV4:
    case SX_TRAP_ID_HOST_MISS_IPV6:
    case SX_TRAP_ID_MPLS_ILM_MISS:
    case SX_TRAP_ID_DECAP_ENCAP:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH:
    case SX_TRAP_ID_DISCARD_ING_LSR:
    case SX_TRAP_ID_DISCARD_ROUTER:
    case SX_TRAP_ID_DISCARD_LSR:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH:
    case SX_TRAP_ID_DISCARD_EGR_LSR:
    case SX_TRAP_ID_DISCARD_NON_ROUTED:
    case SX_TRAP_ID_DISCARD_MC_SCOPE:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_STP:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS:
    case SX_TRAP_ID_DISCARD_ING_LSR_NO_LABEL:
    case SX_TRAP_ID_DISCARD_ING_LSR_UC_ET:
    case SX_TRAP_ID_DISCARD_ING_LSR_MC_DMAC:
    case SX_TRAP_ID_DISCARD_ROUTER_IRIF_EN:
    case SX_TRAP_ID_DISCARD_ROUTER_ERIF_EN:
    case SX_TRAP_ID_DISCARD_ROUTER_ERIF_FWD:
    case SX_TRAP_ID_DISCARD_ROUTER_LPM4:
    case SX_TRAP_ID_DISCARD_ROUTER_LPM6:
    case SX_TRAP_ID_DISCARD_LSR_MIN_LABEL:
    case SX_TRAP_ID_DISCARD_LSR_MAX_LABEL:
    case SX_TRAP_ID_DISCARD_LSR_LB:
    case SX_TRAP_ID_DISCARD_DEC_DIS:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC:
    case SX_TRAP_ID_DISCARD_ENC_ISOLATION:
    case SX_TRAP_ID_DISCARD_EGR_LSR_NO_LABEL:
    case SX_TRAP_ID_DISCARD_EGR_LSR_NO_IP:
    case SX_TRAP_ID_DISCARD_EGR_LSR_PHP_NO_IP:
    case SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0:
    case SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1:
    case SX_TRAP_ID_IPIP_DECAP_ERROR:
    case SX_TRAP_ID_IPIP_ERROR:
    case SX_TRAP_ID_IPV6_UNSPECIFIED_DIP:
    case SX_TRAP_ID_FID_MISS:
    case SX_TRAP_ID_ETH_L3_URPF_PROTECTION:
    case SX_TRAP_ID_ARN_RECEIVE_OK:
        *has_default_action_p = TRUE;
        *hw_trap_group_p = 0;
        *trap_action_p = SX_TRAP_ACTION_SET_FW_DEFAULT;
        break;

    /* Traps with different default action per check. We will not set them in SDK init,
     * we Will set the traps to SX_TRAP_ACTION_SET_FW_DEFAULT when we unset trap*/
    case SX_TRAP_ID_DISCARD_ING_PACKET:
    case SX_TRAP_ID_DISCARD_ING_SWITCH:
    case SX_TRAP_ID_DISCARD_DEC:
    case SX_TRAP_ID_DISCARD_DEC_PKT:
    case SX_TRAP_ID_DISCARD_DEC_NVE_OPTIONS:
    case SX_TRAP_ID_DISCARD_ING_ROUTER:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LINK_LOCAL:
    case SX_TRAP_ID_PORT_ADDED:
        *has_default_action_p = FALSE;
        *hw_trap_group_p = SX_HW_TRAP_GROUP_DISABLE_E;
        *trap_action_p = SX_TRAP_ACTION_SET_FW_DEFAULT;
        break;

    /* Traps w/o default action in FW - we will set them to SX_TRAP_ACTION_IGNORE*/
    case SX_TRAP_ID_GENERAL_FDB:
    case SX_TRAP_ID_FDB:
    case SX_TRAP_ID_PORT_DELETED:
    case SX_TRAP_ID_PORT_ADDED_TO_LAG:
    case SX_TRAP_ID_PORT_REMOVED_FROM_LAG:
    case SX_TRAP_ID_FDB_SRC_MISS:
    case SX_TRAP_ID_ETH_L2_PACKET_SAMPLING:
    case SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED:
    case SX_TRAP_ID_ARP_REQUEST:
    case SX_TRAP_ID_ARP_RESPONSE:
    case SX_TRAP_ID_ETH_L3_RPF:
    case SX_TRAP_ID_L3_UC_IP_BASE:
    case SX_TRAP_ID_L3_MC_IP_BASE:
    case SX_TRAP_ID_L3_NEIGH_IP_BASE:
    case SX_TRAP_ID_IPV4_DHCP:
    case SX_TRAP_ID_DECAP_TABLE_0:
    case SX_TRAP_ID_DECAP_TABLE_1:
    case SX_TRAP_ID_IGMP_V3_P1:
    case SX_TRAP_ID_IGMP_V3_P0:
    case SX_TRAP_ID_ACL_DROP:
    case SX_TRAP_ID_SYS_ACL_DROP:
    case SX_TRAP_ID_MPLS_ILM0:
    case SX_TRAP_ID_MPLS_ILM1:
    case SX_TRAP_ID_MPLS_ILM2:
    case SX_TRAP_ID_MPLS_ILM3:
    case SX_TRAP_ID_MPLS_NHLFE0:
    case SX_TRAP_ID_MPLS_NHLFE1:
    case SX_TRAP_ID_MPLS_NHLFE2:
    case SX_TRAP_ID_MPLS_NHLFE3:
    case SX_TRAP_ID_SDK_TEST1:
    case SX_TRAP_ID_SDK_TEST2:
        *has_default_action_p = TRUE;
        *hw_trap_group_p = 0;
        *trap_action_p = SX_TRAP_ACTION_IGNORE;
        break;

    /* The other traps are valid only for SPC1 or SPC2 and above
     * or don't have any default action*/
    default:
        sx_status = __default_action_set_wrapper(trap_id, trap_action_p, has_default_action_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed in __host_ifc_default_action_set_wrapper, [trap_id = %u], return value: [%s]\n",
                       trap_id, sx_status_str(sx_status));
            goto out;
        }

        /* Handle ACL Trap IDs */
        if (SX_TRAP_ID_ACL_CHECK_RANGE(trap_id)) {
            *has_default_action_p = TRUE;
            *hw_trap_group_p = 0;
            *trap_action_p = SX_TRAP_ACTION_IGNORE;
            break;
        }

        if (*has_default_action_p == FALSE) {
            *hw_trap_group_p = SX_HW_TRAP_GROUP_DISABLE_E;
        } else {
            *hw_trap_group_p = 0;
        }
        break;
    }

out:
    return sx_status;
}

boolean_t trap_id_is_acl_key_supported(sx_trap_id_t trap_id)
{
    /* Make sure trap_id_is_acl_key_supported_cb exists */
    if (brg_context.spec_cb_g.trap_id_is_acl_key_supported_cb == NULL) {
        SX_LOG_ERR("trap_id_is_acl_key_supported_cb not set.\n");
        return SX_STATUS_ERROR;
    }
    return brg_context.spec_cb_g.trap_id_is_acl_key_supported_cb(trap_id);
}

boolean_t trap_id_is_acl_key_supported_spectrum4(sx_trap_id_t trap_id)
{
    boolean_t is_trap_supported = FALSE;

    switch (trap_id) {
    /*These traps supported as an ACL key in Spectrum-4 and above.*/
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL:
        is_trap_supported = TRUE;
        break;

    default:
        is_trap_supported = trap_id_is_acl_key_supported_spectrum(trap_id);
        break;
    }

    return is_trap_supported;
}

boolean_t trap_id_is_acl_key_supported_spectrum(sx_trap_id_t trap_id)
{
    boolean_t is_trap_supported = FALSE;

    switch (trap_id) {
    /* Unsupported traps as an ACL key */
    case SX_TRAP_ID_GENERAL_FDB:
    case SX_TRAP_ID_FDB:
    case SX_TRAP_ID_ETH_L3_MTUERROR:
    case SX_TRAP_ID_ETH_L3_TTLERROR:
    case SX_TRAP_ID_ETH_L3_LBERROR:
    case SX_TRAP_ID_OSPF:
    case SX_TRAP_ID_RIP_V1:
    case SX_TRAP_ID_RIP_V2:
    case SX_TRAP_ID_PIM:
    case SX_TRAP_ID_ETH_L3_RPF:
    case SX_TRAP_ID_ETH_L3_URPF_PROTECTION:
    case SX_TRAP_ID_IP2ME:
    case SX_TRAP_ID_IPV6_OSPF:
    case SX_TRAP_ID_IPV4_DHCP:
    case SX_TRAP_ID_IPV6_DHCP:
    case SX_TRAP_ID_MPLS_NHLFE0:
    case SX_TRAP_ID_MPLS_NHLFE1:
    case SX_TRAP_ID_MPLS_NHLFE2:
    case SX_TRAP_ID_MPLS_NHLFE3:
    case SX_TRAP_ID_MPLS_ILM0:
    case SX_TRAP_ID_MPLS_ILM1:
    case SX_TRAP_ID_MPLS_ILM2:
    case SX_TRAP_ID_MPLS_ILM3:
    case SX_TRAP_ID_MPLS_LDP:
    case SX_TRAP_ID_MPLS_LB_LSP_PING:
    case SX_TRAP_ID_MIRROR:
    case SX_TRAP_ID_IPIP_DECAP_ERROR:
    case SX_TRAP_ID_IP2ME_CUSTOM0:
    case SX_TRAP_ID_IP2ME_CUSTOM1:
    case SX_TRAP_ID_BFD_IPV4:
    case SX_TRAP_ID_BFD_IPV6:
    case SX_TRAP_ID_DECAP_ECN0:
    case SX_TRAP_ID_DECAP_ECN1:
    case SX_TRAP_ID_NVE_DECAP_TAG_ERROR:
    case SX_TRAP_ID_NVE_DECAP_FRAG_ERROR:
    case SX_TRAP_ID_IPIP_ERROR:
    case SX_TRAP_ID_DECAP_ENCAP:
    case SX_TRAP_ID_USER_CONF_ROUTER0:
    case SX_TRAP_ID_USER_CONF_ROUTER1:
    case SX_TRAP_ID_USER_CONF_ROUTER2:
    case SX_TRAP_ID_USER_CONF_ROUTER3:
    case SX_TRAP_ID_DISCARD_ING_PACKET:
    case SX_TRAP_ID_DISCARD_ING_SWITCH:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH:
    case SX_TRAP_ID_DISCARD_ING_ROUTER:
    case SX_TRAP_ID_DISCARD_ING_LSR:
    case SX_TRAP_ID_DISCARD_ROUTER:
    case SX_TRAP_ID_DISCARD_ROUTER2:
    case SX_TRAP_ID_DISCARD_ROUTER3:
    case SX_TRAP_ID_DISCARD_LSR:
    case SX_TRAP_ID_DISCARD_DEC:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH:
    case SX_TRAP_ID_DISCARD_ISOLATION:
    case SX_TRAP_ID_DISCARD_NON_ROUTED:
    case SX_TRAP_ID_DISCARD_EGR_LSR:
    case SX_TRAP_ID_DISCARD_MC_SCOPE:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP:
    case SX_TRAP_ID_DISCARD_ROUTER_IRIF_EN:
    case SX_TRAP_ID_DISCARD_ROUTER_ERIF_EN:
    case SX_TRAP_ID_DISCARD_ROUTER_ERIF_FWD:
    case SX_TRAP_ID_DISCARD_DEC_PKT:
    case SX_TRAP_ID_DISCARD_DEC_DIS:
    /* IB */
    case SX_TRAP_ID_INFINIBAND_IB_FMAD_RCV:
    case SX_TRAP_ID_INFINIBAND_RESET_CMD:
    case SX_TRAP_ID_INFINIBAND_QP0:
    case SX_TRAP_ID_INFINIBAND_QP1:
    case SX_TRAP_ID_INFINIBAND_OTHER_QPS:
    case SX_TRAP_ID_INFINIBAND_EXTERNAL_SMA:
    case SX_TRAP_ID_INFINIBAND_IN_NV_ACCESS_REG:
    /* Virtual Traps */
    case SX_TRAP_ID_L3_UC_IP_BASE:
    case SX_TRAP_ID_L3_MC_IP_BASE:
    case SX_TRAP_ID_L3_NEIGH_IP_BASE:
    case SX_TRAP_ID_IPTRAP_MAX:
    /* Management and Peripherals Control Traps */
    case SX_TRAP_ID_TSDE:
    case SX_TRAP_ID_DSDSC:
    case SX_TRAP_ID_BCTOE:
    case SX_TRAP_ID_PMLPE:

    case SX_TRAP_ID_PTP_ING_EVENT:
    case SX_TRAP_ID_PTP_EGR_EVENT:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS:
    case SX_TRAP_ID_DISCARD_DEC_NVE_OPTIONS:
    case SX_TRAP_ID_SIGNAL:
    case SX_TRAP_ID_NEW_DEVICE_ADD:
    case SX_TRAP_ID_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_FDB_EVENT:
    case SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY:
    case SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT:
    case SX_TRAP_ID_ROUTER_MC_ACTIVITY:
    case SX_TRAP_ID_FDB_IP_ADDR_ACTIVITY:
    case SX_TRAP_ID_TRANSACTION_ERROR:
    case SX_TRAP_ID_BFD_TIMEOUT_EVENT:
    case SX_TRAP_ID_BFD_PACKET_EVENT:
    case SX_TRAP_ID_OBJECT_DELETED_EVENT:
    case SX_TRAP_ID_SDK_HEALTH_EVENT:
    case SX_TRAP_ID_PORT_PROFILE_APPLY_DONE:
    case SX_TRAP_ID_API_LOGGER_EVENT:
    case SX_TRAP_ID_BULK_COUNTER_DONE_EVENT:
    case SX_TRAP_ID_PORT_ADDED:
    case SX_TRAP_ID_PORT_DELETED:
    case SX_TRAP_ID_PORT_ADDED_TO_LAG:
    case SX_TRAP_ID_PORT_REMOVED_FROM_LAG:
    case SX_TRAP_ID_BULK_REFRESH_COUNTER_DONE_EVENT:
    case SX_TRAP_ID_ACL_ACTIVITY:
    case SX_TRAP_ID_BER_MONITOR:
    case SX_TRAP_ID_MFRI:
    case SX_TRAP_ID_PPIR:
    case SX_TRAP_ID_MFCDR:
    case SX_TRAP_ID_SPZR:
    case SX_TRAP_ID_PLLP:
    case SX_TRAP_ID_IBISSU:
    case SX_TRAP_ID_UTFD:
    case SX_TRAP_ID_QUEUE_SNAPSHOT_TRIGGER_EVENT:
    case SX_TRAP_ID_PTP_CLOCK_PPS_EVENT:
    case SX_TRAP_ID_STATEFUL_DB_PARTITION_THRESHOLD_CROSSED:
    case SX_TRAP_ID_PORT_TX_READY:
    case SX_TRAP_ID_ETH_L2_MVRP:
    case SX_TRAP_ID_ETH_L2_RARP_OPCODES:
    case SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED:
    case SX_TRAP_ID_TAC_ACTION_DONE:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC:
    case SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL:

    case SX_TRAP_ID_ETH_L3_ASSERT:
    case SX_TRAP_ID_TMPW:
    case SX_TRAP_ID_SDK_TEST1:
    case SX_TRAP_ID_SDK_TEST2:
    case SX_TRAP_ID_ARN_RECEIVE_OK:
        is_trap_supported = FALSE;
        break;

    /* Supported trap IDs as an ACL key. */
    case SX_TRAP_ID_GENERAL_DR_IPC:
    case SX_TRAP_ID_GENERAL_DR_RES:
    case SX_TRAP_ID_PUDE:
    case SX_TRAP_ID_PMPE:
    case SX_TRAP_ID_ACL_MIN ... SX_TRAP_ID_ACL_MAX:
    case SX_TRAP_ID_ETH_L2_STP:
    case SX_TRAP_ID_ETH_L2_LACP:
    case SX_TRAP_ID_MIRROR_AGENT_MIN ... SX_TRAP_ID_MIRROR_AGENT_MAX:
    case SX_TRAP_ID_ETH_L2_EAPOL:
    case SX_TRAP_ID_ETH_L2_LLDP:
    case SX_TRAP_ID_ETH_L2_MMRP:
    case SX_TRAP_ID_ETH_L2_RPVST:
    case SX_TRAP_ID_ETH_L2_DHCP:
    case SX_TRAP_ID_ETH_L2_DHCPV6:
    case SX_TRAP_ID_FCOE_FIP:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_QUERY:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V1_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_REPORT:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V2_LEAVE:
    case SX_TRAP_ID_ETH_L2_IGMP_TYPE_V3_REPORT:
    case SX_TRAP_ID_ARP_REQUEST:
    case SX_TRAP_ID_ARP_RESPONSE:
    case SX_TRAP_ID_VRRP:
    case SX_TRAP_ID_IPBC:
    case SX_TRAP_ID_IPV6_UNSPECIFIED_DIP:
    case SX_TRAP_ID_IPV6_UNSPECIFIED_SIP:
    case SX_TRAP_ID_IPV6_LINK_LOCAL_DST:
    case SX_TRAP_ID_IPV6_LINK_LOCAL_SRC:
    case SX_TRAP_ID_IPV6_MLD_V1_V2:
    case SX_TRAP_ID_IPV6_MLD_V1_REPORT:
    case SX_TRAP_ID_IPV6_MLD_V1_DONE:
    case SX_TRAP_ID_IPV6_MLD_V2_REPORT:
    case SX_TRAP_ID_IPV6_ROUTER_SOLICITATION:
    case SX_TRAP_ID_IPV6_ROUTER_ADVERTISEMENT:
    case SX_TRAP_ID_IPV6_NEIGHBOR_SOLICITATION:
    case SX_TRAP_ID_IPV6_NEIGHBOR_ADVERTISEMENT:
    case SX_TRAP_ID_IPV6_REDIRECTION:
    case SX_TRAP_ID_HOST_MISS_IPV4:
    case SX_TRAP_ID_HOST_MISS_IPV6:
    case SX_TRAP_ID_MPLS_ILM_MISS:
    case SX_TRAP_ID_IPV6_ALL_NODES_LINK:
    case SX_TRAP_ID_IPV6_ALL_ROUTERS_LINK:
    case SX_TRAP_ID_ETH_L2_PACKET_SAMPLING:
    case SX_TRAP_ID_FDB_MISMATCH:
    case SX_TRAP_ID_IPV4_BGP:
    case SX_TRAP_ID_IPV6_BGP:
    case SX_TRAP_ID_SSH_IPV4:
    case SX_TRAP_ID_SSH_IPV6:
    case SX_TRAP_ID_SNMP_IPV4:
    case SX_TRAP_ID_SNMP_IPV6:
    case SX_TRAP_ID_PING_IPV4:
    case SX_TRAP_ID_PING_IPV6:
    case SX_TRAP_ID_NVE_DECAP_ARP:
    case SX_TRAP_ID_NVE_IPV4_DHCP:
    case SX_TRAP_ID_NVE_IPV6_DHCP:
    case SX_TRAP_ID_NVE_ENCAP_ARP:
    case SX_TRAP_ID_ETH_L2_UDLD:
    case SX_TRAP_ID_PTP_EVENT:
    case SX_TRAP_ID_PTP_GENERAL:
    case SX_TRAP_ID_VRRP_IPV6:
    case SX_TRAP_ID_ROUTER_ALERT_IPV4:
    case SX_TRAP_ID_ROUTER_ALERT_IPV6:
    case SX_TRAP_ID_FID_MISS:
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE0:
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE1:
    case SX_TRAP_ID_USER_NVE_DECAP_ETH:
    case SX_TRAP_ID_NVE_DECAP_MLD:
    case SX_TRAP_ID_NVE_DECAP_IGMP:
    case SX_TRAP_ID_DISCARD_LSR2:
    case SX_TRAP_ID_DISCARD_LSR3:
    case SX_TRAP_ID_ROUTER_ARPBC:
    case SX_TRAP_ID_ROUTER_ARPUC:
    case SX_TRAP_ID_ROUTER_RARP_OPCODES:
    case SX_TRAP_ID_PACKET_RECEIVED:
    case SX_TRAP_ID_USER_CONF_SWITCH0:
    case SX_TRAP_ID_USER_CONF_SWITCH1:
    case SX_TRAP_ID_USER_CONF_SWITCH2:
    case SX_TRAP_ID_USER_CONF_SWITCH3:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC0:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC1:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC2:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC3:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC0:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC1:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC2:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC3:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC:
    case SX_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_VLAN:
    case SX_TRAP_ID_DISCARD_ING_SWITCH_STP:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL:
    case SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LINK_LOCAL:
    case SX_TRAP_ID_DISCARD_ING_LSR_NO_LABEL:
    case SX_TRAP_ID_DISCARD_ING_LSR_UC_ET:
    case SX_TRAP_ID_DISCARD_ING_LSR_MC_DMAC:
    case SX_TRAP_ID_DISCARD_ROUTER_LPM4:
    case SX_TRAP_ID_DISCARD_ROUTER_LPM6:
    case SX_TRAP_ID_DISCARD_LSR_MIN_LABEL:
    case SX_TRAP_ID_DISCARD_LSR_MAX_LABEL:
    case SX_TRAP_ID_DISCARD_LSR_LB:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC:
    case SX_TRAP_ID_DISCARD_EGR_LSR_NO_LABEL:
    case SX_TRAP_ID_DISCARD_EGR_LSR_NO_IP:
    case SX_TRAP_ID_DISCARD_EGR_LSR_PHP_NO_IP:
    case SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0:
    case SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1:
    case SX_TRAP_ID_DISCARD_ENC_ISOLATION:
    case SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0:
    case SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0:

    case SX_TRAP_ID_FDB_SRC_MISS:
    case SX_TRAP_ID_RESERVED_MC:
    case SX_TRAP_ID_USER_OVERLAY_ICMPV6_CONF_TYPE:
    case SX_TRAP_ID_USER_ETH_CONF_TYPE0:
    case SX_TRAP_ID_USER_ETH_CONF_TYPE1:
    case SX_TRAP_ID_SYSFS_SNIFFER:
        is_trap_supported = TRUE;
        break;
    }
    /* No Default clause is specified intentionally.
     * Every new trap should be added to one of the cases above. Otherwise, the build fails */
    return is_trap_supported;
}

sx_status_t trap_id_hw_syndrome_db_init(void)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    cl_status_t cl_err = CL_SUCCESS;

    cl_err = cl_map_init(&g_sw_to_hw_syndrome_map, 0);
    if (SX_UTILS_CHECK_FAIL(cl_err)) {
        SX_LOG_ERR("Failed to allocate memory for mapping SW<->HW trap IDs \n");
        sx_status = cl_status_to_sx_status(cl_err);
        goto out;
    }

out:
    return sx_status;
}

sx_status_t trap_id_hw_syndrome_db_deinit(void)
{
    cl_map_remove_all(&g_sw_to_hw_syndrome_map);
    cl_map_destroy(&g_sw_to_hw_syndrome_map);

    return SX_STATUS_SUCCESS;
}

sx_status_t trap_id_hw_syndrome_get(sx_trap_id_t trap_id, uint16_t *p_hw_syndrome)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_hthm_reg hthm_reg_data;
    sxd_reg_meta_t     reg_meta;
    void              *p_obj = NULL;

    SX_LOG_ENTER();

    SX_CHECK_NULL_OUT(p_hw_syndrome, sx_status, "p_hw_syndrome");

    SX_MEM_CLR(hthm_reg_data);
    SX_MEM_CLR(reg_meta);

    /* Check if this trap_id is already mapped to HW syndrome.
     * If not, retrieve the HW syndrome and add it to DB. */
    p_obj = cl_map_get(&g_sw_to_hw_syndrome_map, trap_id);
    if (p_obj != cl_map_end(&g_sw_to_hw_syndrome_map)) {
        *p_hw_syndrome = (uint16_t)(uintptr_t)p_obj;
        goto out;
    }

    reg_meta.dev_id = DEFAULT_DEV_ID;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    hthm_reg_data.trap_id = trap_id;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HTHM_E, &hthm_reg_data, &reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get HW syndrome for trap ID %d - HTHM register access failed, err: %d\n",
                   trap_id,
                   sxd_status);
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    if (!hthm_reg_data.vld) {
        SX_LOG_ERR("The SW Trap id %d isn't valid for mapping to the HW syndrome.\n", trap_id);
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *p_hw_syndrome = hthm_reg_data.hw_trap_id;

    /* Insert the HW syndrome into the map */
    if (cl_map_insert(&g_sw_to_hw_syndrome_map, trap_id, (void *)(uintptr_t)*p_hw_syndrome) == NULL) {
        SX_LOG_ERR("Failed to insert HW trap_id into sw_to_hw_trap_id DB\n");
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}
