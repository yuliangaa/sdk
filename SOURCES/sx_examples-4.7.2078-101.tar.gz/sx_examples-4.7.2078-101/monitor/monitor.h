/*
 * Copyright (C) 2009-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef MONITOR_H_
#define MONITOR_H_

#include <pthread.h>

#ifndef UNUSED_PARAM
#define UNUSED_PARAM(P) ((void)(P))
#endif

#ifndef MONITOR_LOG_DEBUG
/* #define	SDKD_LOG_DEBUG	LOG_NOTICE */
#define MONITOR_LOG_DEBUG LOG_DEBUG
#endif

#endif /* SDKD_H_ */
