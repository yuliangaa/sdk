/*
 * Copyright (C) 2009-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "monitor.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <complib/cl_thread.h>
/* ------------------------------------------------------------------------- */
/** Globals
 */
#define MONITOR_WAIT_TIME_SEC  15
#define MONITOR_WAIT_TIME_USEC (MONITOR_WAIT_TIME_SEC * 1000000)
static cl_event_t stop_monitor_event;
boolean_t         stop_monitor;
cl_thread_t       main_thread;

/* this function is responsible for cleaning resources*/
int sdkd_deinit(void);

/* The following function will be called from SDK
 * after loading this module by DLL (using construct/ destroy functions)
 */
/* create thread which implement main_func. This Thread may communicate with other daemons etc.*/
void sdkd_init(void);

/* The main function which will run by the created thread*/
void main_func(void *arg);

/**************************************** implementations ****************************************/
void sdkd_init(void)
{
    cl_status_t cl_err = CL_SUCCESS;

    cl_err = cl_event_init(&(stop_monitor_event), FALSE);
    if (cl_err != CL_SUCCESS) {
        printf("Could not create event for daemon thread\n");
        return;
    }
    cl_err = cl_thread_init(&main_thread, main_func, NULL, NULL, 0);
    if (cl_err != CL_SUCCESS) {
        printf("Could not create monitor daemon thread\n");
        return;
    }
}


void main_func(void *arg __attribute__((unused)))
{
    int         err = 0;
    cl_status_t cl_err = CL_SUCCESS;

    UNUSED_PARAM(arg);
    printf("MONITOR DAEMON Launched\n");

    while (1) {
        cl_err = cl_event_wait_on(&stop_monitor_event, MONITOR_WAIT_TIME_USEC, TRUE);
        if ((cl_err != CL_SUCCESS) && (cl_err != CL_TIMEOUT)) {
            printf("Error on waiting on event\n");
            return;
        }
        if (stop_monitor == TRUE) {
            return;
        }
        printf("Hello from monitor daemon plugin thread (expected every %d sec)\n", MONITOR_WAIT_TIME_SEC);
    }
    printf("MONITOR DAEMON exiting with code %d\n", err);
    return;
}


int sdkd_deinit(void)
{
    int err = 0;

    printf("Terminating Monitor daemon\n");
    stop_monitor = TRUE;
    cl_event_signal(&stop_monitor_event);
    cl_thread_destroy(&main_thread);
    cl_event_destroy(&stop_monitor_event);

    printf("Monitor daemon termination done\n");
    return err;
}
