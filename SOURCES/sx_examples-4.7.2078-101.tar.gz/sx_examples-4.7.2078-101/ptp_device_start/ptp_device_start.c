/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

/**
 * This example is used to show how to initialize the SDK PTP module.
 **/

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_api_ptp.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_access_register_init.h>

#define PTP_TRAP_GROUP_ID (26)

static sx_status_t __get_chip_type(sx_chip_types_t *chip_type_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mgir_reg mgir_reg;

    memset(&reg_meta, 0, sizeof(reg_meta));
    memset(&mgir_reg, 0, sizeof(mgir_reg));

    if (chip_type_p == NULL) {
        printf("ERROR: chip_type_p is NULL.\n");
        exit(1);
    }

    sxd_status = sxd_access_reg_init(0, NULL, SX_VERBOSITY_LEVEL_INFO);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        printf("ERROR: SXD API sxd_access_reg_init failed: [%s]\n", SXD_STATUS_MSG(sxd_status));
        exit(1);
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.dev_id = 1;
    memset(&mgir_reg, 0, sizeof(struct ku_mgir_reg));

    sxd_status = sxd_access_reg_mgir(&mgir_reg, &reg_meta, 1, NULL, NULL);
    if (sxd_status) {
        printf("%s: failed in get MGIR for dev_id %d, error: %d \n",
               __func__, 1, sxd_status);
    }

    switch (mgir_reg.hw_info.device_id) {
    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
        if (mgir_reg.hw_info.device_hw_revision == 0xA0) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM;
        } else if (mgir_reg.hw_info.device_hw_revision == 0xA1) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM_A1;
        } else {
            printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
            exit(1);
        }
        printf("Device type is: SPECTRUM.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM2;

        printf("Device type is: SPECTRUM2.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM3;

        printf("Device type is: SPECTRUM3.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM4;

        printf("Device type is: SPECTRUM4.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM5;

        printf("Device type is: SPECTRUM5.\n");
        break;

    default:
        printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
        exit(1);
    }

    return status;
}

sx_status_t ptp_mode_set(sx_api_handle_t sx_handle, ptp_mode_t ptp_mode)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    sx_ptp_params_t ptp_params = {0};

    printf("configure PTP RX mode\n");

    /* configure PTP RX mode */
    switch (ptp_mode) {
    case KU_PTP_MODE_POLLING:
        ptp_params.ptp_mode = SX_PTP_MODE_POLLING;
        break;

    case KU_PTP_MODE_EVENTS:
        ptp_params.ptp_mode = SX_PTP_MODE_EVENTS;
        break;

    case KU_PTP_MODE_DISABLED:
        sx_status = sx_api_ptp_deinit_set(sx_handle);
        if (sx_status) {
            printf("ERROR: Failed to de-init PTP module, error %d.\n", sx_status);
        }
        return sx_status;

    default:
        printf("Failed to set PTP due to invalid mode\n");
        return SX_STATUS_PARAM_ERROR;
    }

    sx_status = sx_api_ptp_init_set(sx_handle, &ptp_params);
    if (sx_status) {
        printf("ERROR: Failed to init PTP module, error %d.\n", sx_status);
        return sx_status;
    }

    return sx_status;
}

int register_ptp_traps(sx_api_handle_t sx_handle, ptp_mode_t ptp_mode, sx_chip_types_t chip_type)
{
    sx_trap_group_attributes_t trap_group_attributes = {
        .prio = SX_TRAP_PRIORITY_HIGH,
        .truncate_mode = SX_TRUNCATE_MODE_DISABLE,
        .is_monitor = 0,
    };
    sx_user_channel_t          user_channel = {
        .type = SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV,
    };
    sx_trap_id_t               spc1_specific_traps[] = {
        SX_TRAP_ID_PTP_EGR_EVENT,
        SX_TRAP_ID_PTP_ING_EVENT
    };
    sx_trap_id_t               general_traps[] = {
        SX_TRAP_ID_PTP_EVENT,
        SX_TRAP_ID_PTP_GENERAL,
        SX_TRAP_ID_ETH_L2_LLDP
    };
    sx_status_t                sx_status;
    int                        i, num_of_traps;
    sx_host_ifc_trap_key_t     trap_key;
    sx_host_ifc_trap_attr_t    trap_attr;

    memset(&trap_key, 0, sizeof(trap_key));
    memset(&trap_attr, 0, sizeof(trap_attr));

    printf("configure trap group %u\n", PTP_TRAP_GROUP_ID);
    sx_status = sx_api_host_ifc_trap_group_set(sx_handle, 0, PTP_TRAP_GROUP_ID, &trap_group_attributes);
    if (sx_status != SX_STATUS_SUCCESS) {
        goto done;
    }

    num_of_traps = sizeof(general_traps) / sizeof(general_traps[0]);
    printf("configuring PTP traps\n");

    trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E;
    trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU;
    trap_attr.attr.trap_id_attr.trap_group = PTP_TRAP_GROUP_ID;

    for (i = 0; i < num_of_traps; i++) {
        trap_key.trap_key_attr.trap_id = general_traps[i];
        sx_status = sx_api_host_ifc_trap_id_ext_set(sx_handle, SX_ACCESS_CMD_SET, &trap_key, &trap_attr);
        if (sx_status != SX_STATUS_SUCCESS) {
            goto done;
        }
        printf("registering PTP traps\n");
        sx_status =
            sx_api_host_ifc_trap_id_register_set(sx_handle, SX_ACCESS_CMD_REGISTER, 0, general_traps[i],
                                                 &user_channel);
        if (sx_status != SX_STATUS_SUCCESS) {
            goto done;
        }
    }
    if (chip_type == SXD_MGIR_HW_DEV_ID_SPECTRUM) {
        printf("configuring PTP traps for SPC1\n");
        num_of_traps = sizeof(spc1_specific_traps) / sizeof(spc1_specific_traps[0]);
        if (ptp_mode == KU_PTP_MODE_POLLING) {
            num_of_traps--; /* not using SX_TRAP_ID_PTP_ING_EVENT trap */
        }

        for (i = 0; i < num_of_traps; i++) {
            trap_key.trap_key_attr.trap_id = spc1_specific_traps[i];
            sx_status = sx_api_host_ifc_trap_id_ext_set(sx_handle, SX_ACCESS_CMD_SET, &trap_key, &trap_attr);
            if (sx_status != SX_STATUS_SUCCESS) {
                goto done;
            }
            sx_status =
                sx_api_host_ifc_trap_id_register_set(sx_handle,
                                                     SX_ACCESS_CMD_REGISTER,
                                                     0,
                                                     spc1_specific_traps[i],
                                                     &user_channel);
            if (sx_status != SX_STATUS_SUCCESS) {
                goto done;
            }
        }
    }

done:
    printf("closing the SX API handle\n");
    sx_api_close(&sx_handle);
    return (sx_status == SX_STATUS_SUCCESS) ? SX_STATUS_SUCCESS : SX_STATUS_ERROR;
}


int main(int argc, char *argv[])
{
    ptp_mode_t      ptp_mode = KU_PTP_MODE_EVENTS;
    sx_api_handle_t sx_handle;
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    sx_chip_types_t chip_type = SX_CHIP_TYPE_UNKNOWN;

    UNUSED_PARAM(argv);
    UNUSED_PARAM(argc);

    if (SX_STATUS_SUCCESS != __get_chip_type(&chip_type)) {
        printf("ERROR: Failed to determine the current chip type.\n");
        exit(1);
    }

    printf("Open a SX API handle\n");
    sx_status = sx_api_open(NULL, &sx_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        return -1;
    }

    /* Init SDK PTP device */
    sx_status = ptp_mode_set(sx_handle, ptp_mode);
    if (sx_status) {
        printf("ERROR: Failed to initialize the PTP device, error %d.\n", sx_status);
        return -1;
    }

    /* De-Init SDK PTP device */
    sx_status = ptp_mode_set(sx_handle, KU_PTP_MODE_DISABLED);
    if (sx_status) {
        printf("ERROR: Failed to deinit the PTP device, error %d.\n", sx_status);
        return -1;
    }

    /* Init SDK PTP device */
    sx_status = ptp_mode_set(sx_handle, ptp_mode);
    if (sx_status) {
        printf("ERROR: Failed to initialize the PTP device, error %d.\n", sx_status);
        return -1;
    }

    /* Register to PTP traps */
    sx_status = register_ptp_traps(sx_handle, ptp_mode, chip_type);
    if (sx_status) {
        printf("ERROR: Failed to register PTP traps, error %d.\n", sx_status);
        return -1;
    }

    return 0;
}
