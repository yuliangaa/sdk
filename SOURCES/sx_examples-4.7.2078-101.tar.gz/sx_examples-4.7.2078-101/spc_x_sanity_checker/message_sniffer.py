#!/usr/bin/env python3

import os
import sys
import re
import logging
import time
from logging import DEBUG, WARNING, INFO, ERROR


SNIFFER_VER_IGN = "sdk-ver-ignore"


class MessageSnifferException(Exception):
    pass


class CustomFormatter(logging.Formatter):
    grey = "\x1b[38;21m"
    yellow = "\x1b[33;21m"
    red = "\x1b[31;21m"
    bold_red = "\x1b[31;1m"
    reset = "\x1b[0m"
    format = '%(asctime)s - %(levelname)s - %(message)s'

    FORMATS = {
        logging.DEBUG: grey + format + reset,
        logging.INFO: yellow + format + reset,
        logging.WARNING: red + format + reset,
        logging.ERROR: bold_red + format + reset,
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


logger = logging.getLogger(__file__)
# [Month-Day Hour:Min:Sec,Milli][Log-Level][Filename:Line] Message
formatter = logging.Formatter(
    '[%(asctime)s,%(msecs)03d][%(levelname)s][%(filename)s:%(lineno)d] %(message)s', '%m-%d %H:%M:%S')
sh = logging.StreamHandler(sys.stdout)
sh.setFormatter(CustomFormatter())
logger.addHandler(sh)
logger.setLevel(INFO)
sh.setLevel(INFO)


class MessageSniffer:
    enabled = True
    bad_flow_start = "Bad-Flow: Start"
    bad_flow_end = "Bad-Flow: End"

    critical_search_patterns = [
        "(?:Oops: |BUG: |nable to handle|possible circular locking|stuck for)",   # Kernel related critical errors
        "(?:segfault|nknown symbol|general protection ip)",                             # SDK/App crash related errors
    ]

    search_patterns = [
        "(?:ERROR|fatal|critical)",                                                 # SDK Process & Other system errors
        "sxd_(?:kernel|memtrack): \[error\]",                                       # SDK Driver errors
        "mlxsw.*(?i:fail|error|not released|could not start)",                      # HW-Mgmt driver related errors
        "(?:RIP: |core dumped)"
        " WARNING: ",
        "\[DVS-WARNING\] Running out of disk space",  # Message defined in /auto/sw_system_project/sx_sdk/sx_ver_build_scripts/dvs_os/dvs-root-fs-monitor.sh
    ] + critical_search_patterns

    ignore_patterns = [
        SNIFFER_VER_IGN,
        "SDK-Test",
        "invalid or missing fw_fatal_event_mode, setting fw_fatal_event_mode",      # Not real error, from evb_start.sh
        "(?:dvs|evb)_st(?:art|op).sh.*(?i:fatal.*error.*mode|===.*fatal)",          # DVS Scripts logs which are not real errors
        "mlxsw.*(?i:retry_cntr)",                                                   # Specific retry attempt failed, not a real error
        "sx_sdk.*[1-9].*(?:NOTICE|INFO|WARN|DEBUG)",                                # SDK Messages with non-ERROR Verbosity that could still hold error string
        "(?:Fan|PSU).*has failed",                                                  # HW-Mgmt Possible issue to PSU. Not interesting from SDK POV.
        "Can't get value of subfeature",                                            # HW-Mgmt Possible issue to PSU. Not interesting from SDK POV.
        "WJH_LIB\.ERROR.*(?:(?:Expat.*error)|(?:wjh_db_open_xml_file failed)|(?:Failed to update wjh conf))",
        "Could not open.*/sys/module/mlxsw_core",
        "kmod_module_get_holders.*could not open",
        "memtrack.ko error=No such file or directory",
        "(?:mlxfwmanager|supervisorctl|kdump-tools|containerd|snmpd|calgary)",
        "/sbin/init",
        "watchdog",
        "no SMART Error Log",
        "nable to locate IOAPIC",
        "kernel reports TIME_ERROR",
        "WARNING: Running pip as the 'root' user can result in broken permissions",
        "firewalld.*WARNING",
        "kmod_module_get_refcnt: could not read",
        "segfault at.*telnetd",                             # Unrelated to tests, appears on old kernel 4.19 rarely.
        "telnetd.*segfault",                                # Unrelated to tests, appears rarely on Debian 11
        "cpufreq",                                          # Rare errors during boot - Not interesting
        "RETBleed",                                         # Issues warnings on some CPUs during boot, don't care
    ]

    ignore_patterns_kmemleak = [
        "pci_add_resource_offset\+0x6f",    # SPC1: Small memleak during boot PCI Scan, unrelated to SDK/FW/etc.
    ]

    def __init__(self, system_log, kmemleak_log, loglevel, added_ignores=None, added_kmemleak_ignores=None):
        self.error_raise = True
        self.system_log_last_idx = 0
        self.system_log = system_log
        self.kmemleak_log = kmemleak_log
        self.delim = "#DELIM#"      # Used as lines separator, to easy find strings contained in parsed lines already
        self.error_raise = False

        logger.setLevel(loglevel)
        sh.setLevel(loglevel)

        self.search_regex = self.critical_search_regex = self.ignore_regex = self.ignore_regex_kmemleak = ""

        for search_pt in MessageSniffer.search_patterns:
            self.search_regex += "(?:{})|".format(search_pt)
        self.search_regex = re.compile("(?:{})".format(self.search_regex[:-1]))

        for critical_search_pt in MessageSniffer.critical_search_patterns:
            self.critical_search_regex += "(?:{})|".format(critical_search_pt)
        self.critical_search_regex = re.compile("(?:{})".format(self.critical_search_regex[:-1]))

        added_ignores = added_ignores or []
        if MessageSniffer.ignore_patterns + added_ignores:  # Might be empty
            for ignore_pt in MessageSniffer.ignore_patterns + added_ignores:
                self.ignore_regex += "(?:{})|".format(ignore_pt)
            self.ignore_regex = re.compile("(?:{})".format(self.ignore_regex[:-1]))

        added_kmemleak_ignores = added_kmemleak_ignores or []
        if MessageSniffer.ignore_patterns_kmemleak + added_kmemleak_ignores:   # Might be empty
            for ignore_pt_kmemleak in MessageSniffer.ignore_patterns_kmemleak + added_kmemleak_ignores:
                self.ignore_regex_kmemleak += "(?:{})|".format(ignore_pt_kmemleak)
            self.ignore_regex_kmemleak = re.compile("(?:{})".format(self.ignore_regex_kmemleak[:-1]))

        logger.debug("MessageSniffer initialized | Checks enabled = %s, System log = %s, Kernel Memleak Tracking = %s",
                     self.enabled, self.system_log, bool(self.kmemleak_log))

    def error_raise_disable(self):
        self.error_raise = False

    def error_raise_enable(self):
        self.error_raise = True

    @staticmethod
    def flush_system_logs():
        """ Force rsyslog daemon flush its logs to the disk, so it's updated before we open it for reading """
        if os.system("pkill -HUP rsyslogd"):
            logger.warning("Failed to flush system logs daemon")

    def readnext_system_logs(self):
        with open(self.system_log, "r", errors="ignore") as f:
            f.seek(self.system_log_last_idx)
            ret_lines = f.readlines()
            self.system_log_last_idx = f.tell()
            return ret_lines

    def ignore_expressions(self, expression_list=None):
        """
        Read the existing system logs from last sniffer index in the system logs,
        Add custom verification ignore pattern to any lines matching an expression from the expression list.
        Adjusted log lines, will not be considered as errors in future message sniffer check.

        This is useful when expecting a certain error in the system logs following some test,
        But wanting to ignore specifically only that certain error,
        While not missing out on other unexpected errors in the syslog

        For example, if we expect to get a failure such as 'device 1 is notice fatal failure detection', but we don't
        want the test to fail, calling ignore_expressions('device 1 is notice fatal failure detection')
        will update the syslog lines to be:
            'device 1 is notice fatal failure detection [sdk-ver-ignore]'
        Thus resulting in ignoring it in a later message sniffer check

        NOTE:
            Ignoring system logs expressions dynamically is prune to races -
            SDK Error log to syslog might be still in queue by the OS (Since OS Manages the access to syslog),
            While this function already called - Resulting in not actually marking all needed logs with ignore.
            To reduce probability of that happening, we added explicit sleep 0.5 sec before opening the syslog.
            ** If possible - Its better to use bad_flow decorator for flows resulting in syslog errors,
                Rather than rely on this method - To avoid such race conditions **

        Args:
            expression_list:  List of expressions to match in the syslog and attach ignore pattern to.
                If none given, will attach ignore pattern to all lines in the syslog,
                From last read index.
        """

        expression_list = expression_list or []
        if isinstance(expression_list, str):
            expression_list = [expression_list]

        logger.debug("Marking syslog %s expressions to be ignored:\n%s", self.system_log, "\n".join(expression_list))

        new_lines = []
        pattern = "(.*" + ".*)|(.*".join(expression_list) + ".*)"

        self.flush_system_logs()
        with open(self.system_log, "r+", errors="ignore") as f:
            f.seek(self.system_log_last_idx)    # Start from last index message sniffer will check on
            lines = f.readlines()
            for line in lines:
                if SNIFFER_VER_IGN not in line and re.match(pattern, line):
                    new_lines.append("{} [{}]\n".format(line.strip(), SNIFFER_VER_IGN))
                else:
                    new_lines.append(line)
            f.seek(self.system_log_last_idx)    # Re-Seek the last index, to write from there
            f.write("".join(new_lines))         # No need for new line, original lines already contains such
            f.truncate()

    def check(self, with_kmemleak=False):
        """
        Check system logs for errors

        Args:
            with_kmemleak: Check kernel memleaks logs on applicable envs (Debug kernel)

        Returns:
            In case exception on error wasn't raised (due to error disable for example),
            Returns the system logs strings list, errors list, and ignored errors list
        """
        logger.debug("MessageSniffer: Checking for errors, with_kmemleak={}".format(with_kmemleak))

        errors = ""
        critical_errors = ""
        ignored_errors = ""
        system_logs = self.readnext_system_logs()

        during_bad_flow = False
        for i, line in enumerate(system_logs):
            line = line.strip()
            # Mark bad-flow start: We ignore all errors during a bad-flow testing
            if not during_bad_flow and self.bad_flow_start in line:
                logger.debug("Detected bad flow start: '%s'", line)
                during_bad_flow = True
                continue
            if during_bad_flow and self.bad_flow_end in line:
                during_bad_flow = False
                logger.debug("Detected bad flow end: '%s'", line)
                continue

            if self.search_regex.search(line) is None:
                continue

            critical_error_found = bool(self.critical_search_regex.search(line))
            if during_bad_flow and not critical_error_found:
                ignored_errors += self.delim + line
                continue

            reduced_line = line.split("]", 1)[-1].strip()       # We want to strip kernel timestamp from the error shown to user, i.e. "May 15 00:58:03 localhost kernel: [  469.926902] "

            if "memtrack" in reduced_line and "leak" in reduced_line:
                memtrack_errors = [err.split("]")[-1] for err in system_logs[i - 11:i] if err.strip().split(":")[-1]]
                line += "\n" + " ".join(memtrack_errors)

            if self.ignore_regex and self.ignore_regex.search(line) is not None:
                if reduced_line not in ignored_errors:
                    ignored_errors += self.delim + line
            else:   # Optionally add error line to critical errors AND found 'regular' errors
                if critical_error_found and reduced_line not in critical_errors:
                    critical_errors += self.delim + line
                if reduced_line not in errors:
                    errors += self.delim + line

        if self.kmemleak_log and with_kmemleak:
            logger.info("Checking for kernel memory leaks")
            os.system(f"echo scan > {self.kmemleak_log}")
            with open(self.kmemleak_log, "w+") as f:
                kmemleaks = f.readlines()
                f.write("clear")

            # Create memleaks blocks
            kmemleaks_errors = []
            for line in kmemleaks:
                if not line:
                    continue

                if line.rstrip()[0].strip():                    # Trace start: Line without indent
                    kmemleaks_errors.append(line)
                elif kmemleaks_errors:                          # Part of prev trace
                    kmemleaks_errors[-1] += line
                else:
                    kmemleaks_errors.append(
                        f"Kmemleaks analysis: line parsed doesn't match trace start, consider as error:\n{line}\n"
                    )

            for leak_stack in kmemleaks_errors:
                if self.ignore_regex_kmemleak and self.ignore_regex_kmemleak.search(leak_stack) is not None:
                    if leak_stack not in ignored_errors:
                        ignored_errors += self.delim + leak_stack
                else:
                    errors += self.delim + ("Kernel Suspected Memory leak:\n%s\n" % leak_stack)
                    critical_errors += self.delim + ("Kernel Suspected Memory leak:\n%s\n" % leak_stack)

        if ignored_errors:
            logger.debug("MessageSniffer Ignored the following errors (only 1 occurrence is printed):"
                         "\n- %s\n\nAll above errors were IGNORED.\n",
                         "\n- ".join(ignored_errors.split(self.delim)))

        if errors and self.enabled:       # Enter this block of log/raise only if module was enabled
            # Don't edit e_str: CI PATTERN! Consult with AdielB
            e_str = \
                "MessageSniffer errors: %s\n" % ("\n- ".join(errors.split(self.delim)))
            if self.error_raise:
                raise MessageSnifferException(e_str)

            logger.warning(e_str + "\nErrors weren't raised as exception by user choice\n")

        # Enter this only if critical errors found and module enabled
        # Unlike SDK message sniffer we don't raise an exception here on
        if critical_errors and self.enabled:
            if self.error_raise:
                raise MessageSnifferException(
                    "MessageSniffer CRITICAL Errors: %s\n" % ("\n- ".join(critical_errors.split(self.delim)))
                )
        return system_logs, errors.split(self.delim), ignored_errors.split(self.delim)


if __name__ == '__main__':
    sniffer = MessageSniffer()
    logger.info("Message Sniffer error checker started | Logs tested: %s%s",
                sniffer.system_log, ", " + sniffer.kmemleak_log if sniffer.kmemleak_log else "")

    sniffer.check(with_kmemleak=True)
    logger.info("Message Sniffer finished success - No errors found")
