#!/usr/bin/env python3

import sys
import json
import argparse
import ipaddress
import tarfile
import logging
import os
import subprocess
from pathlib import Path
from logging import DEBUG, WARNING, INFO, ERROR
from message_sniffer import MessageSniffer, CustomFormatter


VALIDATION_LIST = ['ports', 'counters', 'rm', 'gc', 'l3', 'ar', 'cos', 'sb', 'vxlan']
VALIDATION_LIST_CHOICES = ['all', 'ports', 'counters', 'rm', 'gc', 'l3', 'ar', 'cos', 'sb', 'vxlan']


def print_usage():
    print("Usage:\n")
    print("Example with SDK dump and golden dump: " + sys.argv[0]
          + "--json_dump <path_to_sdk_dump> --golden_json_dump <path_to_golden_json_dump>")
    print("Example with cl_support_file for standalone test: " + sys.argv[0] + '--cl_support_file <path_to_cl_support_file>')
    print("Example with cl_support_folder,  debug verbosity and ar, l3 only validation :" + sys.argv[0]
          + '--cl_support_folder <path_to_folder_containing_cl_support_files> --golden_json_dump <path_to_golden_json_dump> --validations_list ar l3 --loglevel debug          ')


parser = argparse.ArgumentParser(
    description='SPC-X dump analyzer - Analyze provided CL Support/SDK dump file for sanity against a golden dump. If no\
        golden dump provided will do standalone test only', usage=print_usage())
group_inp = parser.add_mutually_exclusive_group()
group_inp.add_argument('--json_dump', help='Individual SDK Json dump file to be analyzed')
group_inp.add_argument('--cl_support_file', help='Provide in .txz or .tar.gz format as an alternative to the json dump file')
group_inp.add_argument('--cl_support_folder', help='Provide a directory which contains cl_support file in .txz or .tar.gz format')
group_cmp = parser.add_mutually_exclusive_group()
group_cmp.add_argument('--golden_json_dump', help='The golden dump file to compare against, alternatively provide system type')
group_cmp.add_argument("--system_type", dest="system_type", choices=['leaf', 'spine', 'super_spine', 'tor'], help='system_type', required=False)
parser.add_argument('--loglevel', '-l', choices=['error', 'warning', 'info', 'debug'], help="Log Level to run script at: Default {info}")
parser.add_argument('--force_clean', action='store_true', help="Force clean all extracted dump info at end of script", required=False)
parser.add_argument('--pause_after_stage', dest='pause_stage', action='store_true', help="Pause at the end of every stage", required=False)
parser.add_argument('--validations_list', dest='validations_list', default=['all'], choices=VALIDATION_LIST_CHOICES, help="List of validations to run: Default {all}", nargs='+', required=False)
parser.add_argument('--skip_message_sniffer', dest='skip_message_sniffer', action='store_true', help="Skip syslog, kernel dump validations", required=False)
parser.add_argument('--skip_extract', dest='skip_extract', action='store_true', help="Skip extraction, user should ensure extracted folder is present in in  /tmp/spc_x_dumps/", required=False)
args = parser.parse_args()

# Logger
logger = logging.getLogger(__file__)


# Path of SDK dump inside CL support file
CL_SUPPORT_SDK_DUMP_LOCATION = "/var/log/sdk_dbg/sdkdump.json"
CL_SUPPORT_DUMP_EXTRACT_PATH = "/tmp/spc_x_dumps/"
DEF_LOG_LEVEL = INFO
# Base path of Syslog, may contain multiple .gz and a .1 file. By CL policy max 7 files are retained
CL_SUPPORT_SYSLOG_BASE_PATH = "/var/log/"
CL_SUPPORT_SYSLOG_FILES_LIST = ['syslog', 'syslog.1', 'syslog.2.gz', 'syslog.3.gz', 'syslog.4.gz', 'syslog.5.gz', 'syslog.6.gz', 'syslog.7.gz']

SX_PORT_TYPE_NETWORK = 0
SX_PORT_TYPE_LAG = 1
SX_PORT_TYPE_VPORT = 2
SX_PORT_TYPE_VLAG = 3


def getLevelName(loglevel):
    if loglevel is None:
        loglevel = DEF_LOG_LEVEL
    else:
        loglevel = loglevel.upper()
    return loglevel


def set_log_level(loglevel):
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(CustomFormatter())
    logger.addHandler(sh)
    logger.setLevel(getLevelName(loglevel))
    sh.setLevel(getLevelName(loglevel))


def message_sniffer_init(sylog_path, kmem_leak_path, loglevel):
    ignore_list = []
    kmemleak_ignore_list = []

    message_sniffer = MessageSniffer(sylog_path, kmem_leak_path, getLevelName(loglevel),
                                     added_ignores=ignore_list, added_kmemleak_ignores=kmemleak_ignore_list)
    return message_sniffer


def run_and_test_raising(cmd, should_fail=False):
    rc = run_and_test(cmd, should_fail)
    if rc != 0:
        raise Exception('run_and_test failed of cmd = ' + cmd + ' with rc = ' + str(rc))
    return 0


def do_pause_stage(do_pause):
    if do_pause:
        input("Press any key to continue..")


def run_and_test(cmd, should_fail=False):
    print("Running command : " + cmd)
    ret = subprocess.call(cmd, shell=True)
    failed = (ret != 0)
    # ret = ret / 256
    if should_fail:
        if failed:
            return 0

    if not should_fail:
        if not failed:
            return 0

    logger.info("Command " + cmd + " mismatched Failure = " + str(should_fail))
    logger.info("return value:")
    logger.info(ret)
    return ret


def get_port_type(port_id_str):
    port_id = int(port_id_str, 0)
    return (port_id & 0xF0000000) >> 28


def get_port_type_str(port_id_str):
    port_type = get_port_type(port_id_str)
    if port_type == SX_PORT_TYPE_NETWORK:
        return "PORT"
    if port_type == SX_PORT_TYPE_LAG:
        return "LAG"
    if port_type == SX_PORT_TYPE_VPORT:
        return "VPORT"
    if port_type == SX_PORT_TYPE_VLAG:
        return "VLAG"
    else:
        return "Unknown"


def get_vlan_id_from_vport(port_id_str):
    port_id = int(port_id_str, 0)
    return str((port_id & 0x0FFF0000) >> 16)


def get_port_id_from_vport(port_id_str):
    port_id = int(port_id_str, 0)
    ret_port = port_id & 0x000003FF
    ret_port = ret_port | (1 << 16)
    return "0x%x" % ret_port


def get_lag_id_from_vlag(port_id_str):
    port_id = int(port_id_str, 0)
    ret_port = port_id & 0x000003FF
    ret_port = ret_port | (1 << 28)
    return "0x%x" % ret_port


def get_local_port_from_port(port_id_str):
    port_id = int(port_id_str, 0)
    return (port_id & 0x000003FF)


def is_ipv4_addr(ip):
    return ipaddress.ip_address(ip).version == 4


def is_ipv6_addr(ip):
    return ipaddress.ip_address(ip).version == 6


def is_ip_mc_addr(ip):
    return ipaddress.ip_address(ip).is_multicast


def get_ip_proto(ip):
    if is_ipv4_addr(ip):
        return "4"
    else:
        return "6"


def __cleanup_folders(*args):
    run_and_test_raising('rm -rf ' + CL_SUPPORT_DUMP_EXTRACT_PATH)
    run_and_test_raising('mkdir -p ' + CL_SUPPORT_DUMP_EXTRACT_PATH)
    run_and_test_raising('chmod -R 777 ' + CL_SUPPORT_DUMP_EXTRACT_PATH)


def check_port_discard_counters(json_obj, json_obj_cmp):
    logger.info("Stage: Checking Port Discard counters...")
    data = json_obj["json_root_obj"]
    port_module = data["Port Module"]
    port_db = port_module["Port DB Dump"]["Device 1"]["SWID 0"]
    port_perf_cntr = port_module["Port Performance Counters"]["Device 1"]["SWID 0"]

    for key, value in port_db.items():
        if type(value) == list:
            if "Oper" in value[0]:
                port_table_input = value
                break
    for port in port_table_input:
        port_type = get_port_type(port["Port ID"])
        if port_type == SX_PORT_TYPE_NETWORK:
            port_discard_cntr_key = "Port " + port["Port ID"] + " - " + "DISCARD Counters Group"
            port_discard_cntr = port_perf_cntr[port_discard_cntr_key]
            if port_discard_cntr["ingress_discard_all"] != "0":
                logger.warning("Port [%s] ingress_discard_all counters are non-zero" % (port["Port ID"]))
            else:
                logger.debug("Port [%s] ingress_discard_all counters are zero" % (port["Port ID"]))

            if port_discard_cntr["egress_general"] != "0" or port_discard_cntr["egress_vlan_membership"] != "0" \
                    or port_discard_cntr["egress_hoq"] != "0" or port_discard_cntr["egress_hoq_stall"] != "0" \
                    or port_discard_cntr["egress_sll"] != "0" or port_discard_cntr["egress_stp_filter"] != "0" \
                    or port_discard_cntr["egress_policy_engine"] != "0":
                logger.warning("Port [%s]: one or more egress discard counters are non-zero: egress_general [%s] egress_vlan_membership [%s] egress_hoq [%s] egress_hoq_stall [%s] egress_sll [%s] egress_stp_filter [%s] egress_policy_engine [%s]" % (port["Port ID"], port_discard_cntr["egress_general"],
                                                                                                                                                                                                                                                        port_discard_cntr["egress_vlan_membership"], port_discard_cntr["egress_hoq"], port_discard_cntr["egress_hoq_stall"], port_discard_cntr["egress_sll"], port_discard_cntr["egress_stp_filter"], port_discard_cntr["egress_policy_engine"]))
            else:
                logger.debug("Port [%s]: All egress discard counters are zero" % (port["Port ID"]))


def validate_ports_up(json_objs_input):
    logger.info("Stage: Validating Ports Status...")
    data = json_objs_input["json_root_obj"]
    port_module = data["Port Module"]
    port_db = port_module["Port DB Dump"]["Device 1"]["SWID 0"]

    for key, value in port_db.items():
        if type(value) == list:
            if "Oper" in value[0]:
                port_table_input = value
                break
    for port in port_table_input:
        if port["Oper"] == "Down":
            logger.warning("Port [%s] is Oper Down" % (port["Port ID"]))
        else:
            logger.debug("Port [%s] is Oper Up" % (port["Port ID"]))

    logger.info("Stage: Checking Port Counters")
    port_perf_cntr = port_module["Port Performance Counters"]["Device 1"]["SWID 0"]
    for port in port_table_input:
        if port["Oper"] == "Up":
            port_type = get_port_type(port["Port ID"])
            if port_type == SX_PORT_TYPE_NETWORK:
                logger.debug("Checking Port [%s] 802.3 counters" % (port["Port ID"]))
                port_8023_cntr_key = "Port " + port["Port ID"] + " - " + "IEEE 802.3 Counters Group"
                port_8023_cntr = port_perf_cntr[port_8023_cntr_key]
                if port_8023_cntr["frame_check_sequence_errors"] != "0":
                    logger.warning("Port [%s] fcs errors are non-zero" % (port["Port ID"]))
                else:
                    logger.debug("Port [%s] fcs errors are zero" % (port["Port ID"]))
                if port_8023_cntr["symbol_error_during_carrier"] != "0":
                    logger.warning("Port [%s] symbol_error_during_carrier is non-zero" % (port["Port ID"]))
                else:
                    logger.debug("Port [%s] symbol_error_during_carrier is zero" % (port["Port ID"]))

                if port_8023_cntr["in_range_length_errors"] != "0":
                    logger.warning("Port [%s] in_range_length_errors is non-zero" % (port["Port ID"]))
                else:
                    logger.debug("Port [%s] in_range_length_errors is zero" % (port["Port ID"]))

                if port_8023_cntr["frame_too_long_errors"] != "0":
                    logger.warning("Port [%s] frame_too_long_errors is non-zero" % (port["Port ID"]))
                else:
                    logger.debug("Port [%s] frame_too_long_errors is zero" % (port["Port ID"]))

                if port_8023_cntr["pause_mac_ctrl_frames_received"] != "0":
                    logger.warning("Port [%s] pause_mac_ctrl_frames_received is non-zero" % (port["Port ID"]))
                else:
                    logger.debug("Port [%s] pause_mac_ctrl_frames_received is zero" % (port["Port ID"]))

                if port_8023_cntr["pause_mac_ctrl_frames_transmitted"] != "0":
                    logger.warning("Port [%s] pause_mac_ctrl_frames_transmitted is non-zero" % (port["Port ID"]))
                else:
                    logger.debug("Port [%s] pause_mac_ctrl_frames_transmitted is zero" % (port["Port ID"]))

    logger.info("Stage: Checking Port PHY Statistics ")
    phy_statistics = port_module["Port DB Dump"]["Device 1"]["SWID 0"]["The Packets Will Be Truncated To Oper Size -4B For The CRC"]["PHY Statistics counters"]
    for port in phy_statistics:
        if port["Admin"] == "Up":
            if port["Oper"] == "Up":
                if "Ext Eff/Raw BER" in port:
                    if port["Link Down Events"] != "0/0/0":
                        logger.warning("Port [%s] Link Flap counter [%s]" % (port["Port ID"], port["Link Down Events"]))
                else:
                    # Only External link side
                    if port["Link Down Events"] != "0":
                        logger.warning("Port [%s] Link Flap counter [%s]" % (port["Port ID"], port["Link Down Events"]))

            else:
                logger.warning("Port [%s] is Admin Up but not Oper Up" % (port["Port ID"]))

    logger.info("Stage: AR Link Utilization")
    ar_port_attributes = port_db["Adaptive Routing Port Attributes:"]["port_dump_ar_attr_clmns"]

    for port in ar_port_attributes:
        if port["Link Utilization"] != 0:
            logger.warning("Port Link Utilization for Port {} is Non Zero {}".format(port["Port ID"], port["Link Utilization"]))
        else:
            logger.debug("Port Link Utilization for Port {} is Zero".format(port["Port ID"]))


def validate_ports_config(json_objs_input, json_obs_cmp):
    logger.info("Stage: Comparing Port Config with Golden")
    data = json_objs_input["json_root_obj"]
    port_module = data["Port Module"]
    port_db = port_module["Port DB Dump"]["Device 1"]["SWID 0"]

    data_cmp = json_obs_cmp["json_root_obj"]
    port_module_cmp = data_cmp["Port Module"]
    port_db_cmp = port_module_cmp["Port DB Dump"]["Device 1"]["SWID 0"]

    keys_cmp = ['Speed', 'Speed api', 'FEC', 'MTU', 'Trunc', 'Forwarding mode']

    for key, value in port_db.items():
        if type(value) == list:
            if "Oper" in value[0]:
                port_table_input = value
                break

    for key, value in port_db_cmp.items():
        if type(value) == list:
            if "Oper" in value[0]:
                port_table_cmp = value
                break

    for port_in, port_cmp in zip(port_table_input, port_table_cmp):
        if port_in["Port ID"] == port_cmp["Port ID"] and get_port_type(port_in["Port ID"]) == SX_PORT_TYPE_NETWORK:
            for key in keys_cmp:
                if key in port_in and key in port_cmp:
                    if port_in[key] != port_cmp[key]:
                        logger.warning("Key [%s] does not match for Port [%s]" % (key, port_in["Port ID"]))
                    else:
                        logger.debug("Key [%s] matches for Port [%s]:" % (key, port_in["Port ID"]))
                else:
                    logger.error("Key [%s] does not exist in dump" % (key))

    port_dump_pfc_in = port_db["port_dump_pfc_clmns"]
    port_dump_pfc_cmp = port_db_cmp["port_dump_pfc_clmns"]
    keys_cmp = ['Tx flow control state', 'Tx Prio Policy', 'Tx Cb Policy', 'Rx flow control state', 'Rx Prio Policy', 'Rx Cb Policy']
    for port_in, port_cmp in zip(port_dump_pfc_in, port_dump_pfc_cmp):
        if port_in["Port ID"] == port_cmp["Port ID"]:
            for key in keys_cmp:
                if key in port_in and key in port_cmp:
                    if port_in[key] != port_cmp[key]:
                        logger.warning("Key [%s] does not match for Port [%s]" % (key, port_in["Port ID"]))
                    else:
                        logger.debug("Key [%s] matches for Port [%s]:" % (key, port_in["Port ID"]))
                else:
                    logger.error("Key [%s] does not exist in dump" % (key))


def validate_cos_config(json_objs_input, json_objs_compare):
    if not json_objs_compare:
        logger.info("No golden dump/config provided, skipping COS config validation")
        return
    logger.info("Stage: Comparing CoS Config with Golden")
    data = json_objs_input["json_root_obj"]
    data_cmp = json_objs_compare["json_root_obj"]

    cos_init = data["SDK Init Parameters"]["COS Init Params"]["cos_params_table"]
    cos_init_cmp = data_cmp["SDK Init Parameters"]["COS Init Params"]["cos_params_table"]

    if cos_init != cos_init_cmp:
        logger.warning("CoS Init Params {} dont match with golden {}".format(cos_init, cos_init_cmp))
    else:
        logger.debug("CoS Init Params {} match with golden".format(cos_init))

    global_cos_attrs = data["CoS Module"]["Global CoS Attributes:"]["Switch Priority To IEEE Priority Table"]["prio_to_ieee_prio_clmns"]
    global_cos_attrs_cmp = data_cmp["CoS Module"]["Global CoS Attributes:"]["Switch Priority To IEEE Priority Table"]["prio_to_ieee_prio_clmns"]

    for x, y in zip(global_cos_attrs, global_cos_attrs_cmp):
        if x != y:
            logger.warning("Switch Priority To IEEE Priority Table entry {} dont match with golden {}".format(x, y))
        else:
            logger.debug("Switch Priority To IEEE Priority Table entry {}  matches with golden {}".format(x, y))

    port_speed_to_ptp_shaper = data["CoS Module"]["Global CoS Attributes:"]["Port Speed To PTP Shaper Params Table"]["ptp_config_data_clmns"]
    port_speed_to_ptp_shaper_cmp = data_cmp["CoS Module"]["Global CoS Attributes:"]["Port Speed To PTP Shaper Params Table"]["ptp_config_data_clmns"]

    for x, y in zip(port_speed_to_ptp_shaper, port_speed_to_ptp_shaper_cmp):
        if x != y:
            logger.warning("Port Speed To PTP Shaper Params Table entry {} dont match with golden {}".format(x, y))
        else:
            logger.debug("Port Speed To PTP Shaper Params Table entry {}  matches with golden {}".format(x, y))
    cos_elephant_detection = data["CoS Module"]["Global CoS Attributes:"]["CoS Elephant Detection Global Configuration:"]
    cos_elephant_detection_cmp = data_cmp["CoS Module"]["Global CoS Attributes:"]["CoS Elephant Detection Global Configuration:"]

    if cos_elephant_detection != cos_elephant_detection_cmp:
        logger.warning("CoS Elephant Detection Global Configuration {} does not match with golden {}".format(x, y))
    else:
        logger.debug("CoS Elephant Detection Global Configuration {} matches with golden {}".format(x, y))

    cos_port_group_mapping = data["CoS Module"]["CoS Port Group Mapping"]
    cos_port_group_mapping_cmp = data_cmp["CoS Module"]["CoS Port Group Mapping"]

    for pg in range(0, 8):
        cos_pg_str = "CoS Port Group Number {}".format(pg)
        cos_pg_mapping_per_pg = cos_port_group_mapping[cos_pg_str]["prio_to_tc_clmns"]
        cos_pg_mapping_per_pg_cmp = cos_port_group_mapping_cmp[cos_pg_str]["prio_to_tc_clmns"]

        for x, y in zip(cos_pg_mapping_per_pg, cos_pg_mapping_per_pg_cmp):
            if x != y:
                logger.warning("CoS Port Group Mapping for PG {}: {} does not match with golden {}".format(pg, x, y))
            else:
                logger.debug("CoS Port Group Mapping for PG {}: {} matches with golden {}".format(pg, x, y))

    # Per port CoS attributes
    port_module = data["Port Module"]
    port_db = port_module["Port DB Dump"]["Device 1"]["SWID 0"]

    for key, value in port_db.items():
        if type(value) == list:
            if "Oper" in value[0]:
                port_table_input = value
                break

    for port in port_table_input:
        port_type = get_port_type(port["Port ID"])
        if port_type == SX_PORT_TYPE_NETWORK:
            port_cos_str = "Port [{}] CoS Attributes:".format(port["Port ID"])
            port_ingress_cos_attr = data["CoS Module"][port_cos_str]["Port Ingress CoS Attributes:"]
            port_ingress_cos_attr_cmp = data_cmp["CoS Module"][port_cos_str]["Port Ingress CoS Attributes:"]

            for x, y in zip(port_ingress_cos_attr, port_ingress_cos_attr_cmp):
                if type(x) != list:
                    if x != y:
                        logger.warning("Port {} Ingress CoS Attributes {} dont match with golden {}".format(port["Port ID"], x, y))
                    else:
                        logger.debug("Port {} Ingress CoS Attributes {} match with golden {}".format(port["Port ID"], x, y))
                else:
                    for x1, y1 in zip(x, y):
                        if x1 != y1:
                            logger.warning("Port Ingress {} CoS Attributes {} dont match with golden {}".format(port["Port ID"], x1, y1))
                        else:
                            logger.debug("Port Ingress {} CoS Attributes {} match with golden {}".format(port["Port ID"], x1, y1))

            port_egress_cos_attr = data["CoS Module"][port_cos_str]["Port Egress CoS Attributes:"]
            port_egress_cos_attr_cmp = data_cmp["CoS Module"][port_cos_str]["Port Egress CoS Attributes:"]

            for x, y in zip(port_egress_cos_attr, port_egress_cos_attr_cmp):
                if type(x) != list:
                    if x != y:
                        logger.warning("Port {} Egress CoS Attributes {} dont match with golden {}".format(port["Port ID"], x, y))
                    else:
                        logger.debug("Port {} Egress CoS Attributes {} match with golden {}".format(port["Port ID"], x, y))
                else:
                    for x1, y1 in zip(x, y):
                        if x1 != y1:
                            logger.warning("Port Egress {} CoS Attributes {} dont match with golden {}".format(port["Port ID"], x1, y1))
                        else:
                            logger.debug("Port Egress {} CoS Attributes {} match with golden {}".format(port["Port ID"], x1, y1))


def validate_sb_config(json_objs_input, json_objs_compare):
    if not json_objs_compare:
        logger.info("No golden dump/config provided, skipping SB config validation")
        return
    logger.info("Stage: Comparing Shared Buffer Config with Golden")
    data = json_objs_input["json_root_obj"]
    sb_module = data["Shared Buffers module"]
    sb_db_pool = sb_module["Shared Buffers DB Dump"]["Pools Settings"]
    sb_db_shared_head_room = sb_module["Shared Buffers DB Dump"]["Shared Headroom Pools Settings"]
    sb_db_multicast = sb_module["Shared Buffers DB Dump"]["Multicast Settings"]

    # Golden data
    data_cmp = json_objs_compare["json_root_obj"]
    sb_module_cmp = data_cmp["Shared Buffers module"]
    sb_db_pool_cmp = sb_module_cmp["Shared Buffers DB Dump"]["Pools Settings"]
    sb_db_shared_head_room_cmp = sb_module_cmp["Shared Buffers DB Dump"]["Shared Headroom Pools Settings"]
    sb_db_multicast_cmp = sb_module_cmp["Shared Buffers DB Dump"]["Multicast Settings"]

    sb_pool_dump_clmns = sb_db_pool["sb_pool_dump_clmns"]
    sb_pool_dump_clmns_cmp = sb_db_pool_cmp["sb_pool_dump_clmns"]

    keys_cmp = ['Direction', 'Size', 'Pool mode', 'Buffer type', 'Pool type', 'MAX occupancy']
    for pool_in, pool_cmp in zip(sb_pool_dump_clmns, sb_pool_dump_clmns_cmp):
        if pool_in["Pool"] == pool_cmp["Pool"]:
            for key in keys_cmp:
                if key in pool_in and key in pool_cmp:
                    if pool_in[key] != pool_cmp[key]:
                        logger.warning("Key [%s] does not match for Pool [%s]" % (key, pool_in["Pool"]))
                    else:
                        logger.debug("Key [%s] matches for Pool [%s]:" % (key, pool_in["Pool"]))
                else:
                    logger.error("Key [%s] does not exist in dump" % (key))

    sb_mc_dump_clmns = sb_db_multicast["sb_mc_dump_clmns"]
    sb_mc_dump_clmns_cmp = sb_db_multicast_cmp["sb_mc_dump_clmns"]

    keys_cmp = ['Pool', 'Size', 'Max mode', 'Max- Alpha/Basis points', 'MAX Occupancy']
    for pool_in, pool_cmp in zip(sb_mc_dump_clmns, sb_mc_dump_clmns_cmp):
        if pool_in["SP"] == pool_cmp["SP"]:
            for key in keys_cmp:
                if key in pool_in and key in pool_cmp:
                    if pool_in[key] != pool_cmp[key]:
                        logger.warning("Key [%s] does not match for SP [%s]" % (key, pool_in["SP"]))
                    else:
                        logger.debug("Key [%s] matches for SP [%s]:" % (key, pool_in["SP"]))
                else:
                    logger.error("Key [%s] does not exist in dump" % (key))

    sb_db_ports = sb_module["Shared Buffers DB Dump"]["Ports Settings"]["Device 1"]["SWID 0"]
    sb_db_ports_cmp = sb_module_cmp["Shared Buffers DB Dump"]["Ports Settings"]["Device 1"]["SWID 0"]

    port_module = data["Port Module"]
    port_db = port_module["Port DB Dump"]["Device 1"]["SWID 0"]

    for key, value in port_db.items():
        if type(value) == list:
            if "Oper" in value[0]:
                port_table_input = value
                break

    keys_cmp = ['Direction', 'Size', 'Max mode', 'Max- Alpha/Basis points', 'MAX occupancy']
    for port in port_table_input:
        if port["Oper"] == "Up":
            port_type = get_port_type(port["Port ID"])
            if port_type == SX_PORT_TYPE_NETWORK:
                port_data_pool_key = "Port " + port["Port ID"]
                port_data_pool_key_inner = "Port Data Pools " + port["Port ID"]
                try:
                    port_data_pool_table_input = sb_db_ports[port_data_pool_key][port_data_pool_key_inner]["sb_port_pool_dump_clmns"]
                    port_data_pool_table_cmp = sb_db_ports_cmp[port_data_pool_key][port_data_pool_key_inner]["sb_port_pool_dump_clmns"]
                    for pool_data_in, pool_data_cmp in zip(port_data_pool_table_input, port_data_pool_table_cmp):
                        if pool_data_in["Pool"] == pool_data_cmp["Pool"]:
                            for key in keys_cmp:
                                if key in pool_data_in and key in pool_data_cmp:
                                    if pool_data_in[key] != pool_data_cmp[key]:
                                        logger.warning("Key [%s] does not match for Pool [%s]" % (key, pool_data_in["Pool"]))
                                    else:
                                        logger.debug("Key [%s] matches for Pool [%s]:" % (key, pool_data_in["Pool"]))
                                else:
                                    logger.error("Key [%s] does not exist in dump" % (key))

                except KeyError:
                    logger.error("No Port Data Pools config for port [%s]" % (key, port["Port ID"]))


def validate_rm_thresholds(json_objs_input, json_obj_cmp):
    logger.info("Stage: Validating Resource Manager thresholds")
    data = json_objs_input["json_root_obj"]
    rm_module = data["Resource Manager"]
    rm_sdk_tables = rm_module["Resource Manager SDK Tables"]["sdk_table"]

    for sdk_resource in rm_sdk_tables:
        if sdk_resource["Init"] == "True":
            if sdk_resource["Allocated"] != "0" and sdk_resource["Max"] != "0":
                if int(float(sdk_resource["Max"]) * 0.9) < int(sdk_resource["Allocated"]):
                    logger.warning("Resource [%s] is close to User defined Maximum" % (sdk_resource["Resource"]))
                else:
                    logger.debug("Resource [%s] is not close to User defined Maximum" % (sdk_resource["Resource"]))

    ctcam_table = rm_module["Resource Manager TCAM Table"]["tcam_table"][0]

    if ctcam_table["Init"] == "TRUE":
        if int(float(ctcam_table["Size"]) * 0.9) < int(ctcam_table["Tot Alloc"]):
            logger.warning("Resource CTCAM is at or close to maximum: Used [%s] Max [%s]" % (ctcam_table["Size"], ctcam_table["Tot Alloc"]))
        else:
            logger.debug("Resource CTCAM is not close to maximum: Used [%s] Max [%s]" % (ctcam_table["Size"], ctcam_table["Tot Alloc"]))

    kvd_table = rm_module["Resource Manager KVD Hash Table"]["kvd_table"][0]
    if kvd_table["Init"] == "TRUE":
        if int(float(kvd_table["Size"]) * 0.9) < int(kvd_table["Allocation"]):
            logger.warning("Resource KVD Hash is at or close to maximum: Used [%s] Max [%s]" % (kvd_table["Size"], kvd_table["Allocation"]))
        else:
            logger.debug("Resource KVD Hash is not to maximum: Used [%s] Max [%s]" % (kvd_table["Size"], kvd_table["Allocation"]))

        if kvd_table["Pending Delete"] != "0":
            logger.warning("Pending Delete entries are present in KVD Hash Table [%s]" % (kvd_table["Pending Delete"]))
        else:
            logger.debug("Pending Delete entries are Not present in KVD Hash Table [%s]" % (kvd_table["Pending Delete"]))


def validate_garbage_collector(json_objs_input, json_obj_cmp):
    logger.info("Stage: Validating Garbage Collector")
    # TODO check GC thresholds
    data = json_objs_input["json_root_obj"]
    gc_module = data["Garbage collector module"]

    if gc_module["Module initialized"] == "TRUE":
        global_fence_queue = gc_module["Global Fence Queue"]
        if global_fence_queue["Object count"] != "0":
            logger.warning("Global Fence Queue is not zero, count [%s]" % (global_fence_queue["Object count"]))
        else:
            logger.debug("Global Fence Queue is Zero]")
        gc_post_queue = gc_module["GC Post Queue"]
        if gc_post_queue["Object count"] != "0":
            logger.warning("GC: Post Queue is not zero [%s]" % (gc_post_queue["Object count"]))
        else:
            logger.debug("GC: Post Queue is zero")
    else:
        logger.error("Garbage Collector module is uninitialized")


def get_vlan_from_rif(rif):
    if "bridge" in rif:
        return rif["bridge"]
    elif "vport" in rif:
        return get_vlan_id_from_vport(rif["vport"])
    elif "adaptive ro" in rif:
        return get_vlan_id_from_vport(rif["adaptive ro"])
    else:
        return rif["vlan"]


def get_network_ip_address_by_mask(ip, mask_active_bit):
    if is_ipv4_addr(ip):
        network = ipaddress.IPv4Network(f"{ip}/{mask_active_bit}", strict=False)
    else:
        network = ipaddress.IPv6Network(f"{ip}/{mask_active_bit}", strict=False)
    return network.network_address


def __get_rif(router_module_obj, rif_id):

    if router_module_obj.get("Router Interface Module Tables"):
        rifs = router_module_obj['Router Interface Module Tables']['HWI ROUTER INTERFACE']
    else:
        rifs = router_module_obj['HWI ROUTER INTERFACE']

    for key, value in rifs.items():
        if type(value) is not dict:
            continue

        rif_type = value["Type"]
        for key1, value1 in value.items():
            if type(value1) is not list:
                continue

            for rif in value1:
                if "RIF id" not in rif:
                    continue
                if rif["RIF id"] == rif_id:
                    rif['rif_type'] = rif_type
                    if rif_type == "Adaptive Routing":
                        rif["ar_vport"] = rif["adaptive ro"]
                    vlan = get_vlan_from_rif(rif)
                    rif['act_vlan'] = vlan
                    return rif

    logger.error("Unexpected error, the RIF (ID: %s) is not found in the JSON dump." % (rif_id))
    return None


def __check_rif_enabled(router_module_obj, rif_id, proto):
    rif_obj = __get_rif(router_module_obj, rif_id)
    rif_str = "UV{} st".format(proto)
    if rif_obj[rif_str] != "ENABLE":
        return False
    else:
        return True


def __is_route_configured_for_ip(router_module, vrid, ip):
    proto = get_ip_proto(ip)
    proto_str = "IPv{} UC Routes".format(proto)
    if router_module.get("HWI UC-Route Tables"):
        uc_route_entries = router_module["HWI UC-Route Tables"][proto_str]
    else:
        uc_route_entries = router_module[proto_str]

    found = False
    if uc_route_entries.get("router_uc_entries_dump_clmns"):
        for uc_route in uc_route_entries["router_uc_entries_dump_clmns"]:
            if uc_route["Action"] == "Forward" and vrid == uc_route["VRID"]:
                if get_network_ip_address_by_mask(ip, uc_route["Mask len"]) == ipaddress.ip_address(uc_route["IP"]):
                    found = True
                    break
    else:
        logger.warning("No IPv{} UC Routes configured".format(proto_str))
        found = False

    return found


def __check_neigh_valid(router_module_obj, eg_rif, ip, mask, proto):
    if router_module_obj.get("Router Neighbor Module Tables"):
        neighbor_db = router_module_obj["Router Neighbor Module Tables"]['HWI DB ROUTER NEIGHBOR']
    else:
        neighbor_db = router_module_obj['HWI DB ROUTER NEIGHBOR']

    found = False
    for _, value in neighbor_db.items():
        if type(value) is not list:
            continue
        for neighbor in value:
            if (eg_rif and neighbor['RIF'] == eg_rif) or eg_rif is None:
                if get_ip_proto(neighbor['IP']) == proto:
                    if (mask and get_network_ip_address_by_mask(neighbor['IP'], mask) == ipaddress.ip_address(ip)) \
                            or neighbor['IP'] == ip:
                        found = True
                        if eg_rif is None:
                            eg_rif = neighbor['RIF']
                        logger.debug("Found Matching Neighbor entry {} for Route {} Mask {}".format(neighbor['IP'], ip, mask))

                        if neighbor["Resolved"] != '1':
                            logger.warning("Neighbour {} found by entry is not resolved for Route {} Mask{}".format(neighbor['IP'], ip, mask))

    if not found:
        if mask:
            logger.warning("No Matching Neighbor entry for Route [%s]" % (ip + '/' + mask))
        else:
            logger.warning("No Matching Neighbor entry for Route [%s]" % (ip))
    return found, eg_rif


def __verify_vrid_enabled(vrid_db, vrid, ip, proto):
    proto_str = "ip{}".format(proto)
    for vridi in vrid_db:
        if vridi["VRID"] == vrid:
            if vridi[proto_str] != "1":
                logger.warning("IPv{} Unicast  is not supported on Vrid {} for UC Route {}".format(proto, vrid, ip))
            else:
                logger.debug("IPv{} Unicast  is supported on Vrid {} for UC Route {}".format(proto, vrid, ip))


def verify_vrid_enabled(router_module_obj, vrid, ip):
    if router_module_obj.get("VRID Module Tables"):
        vrid_db = router_module_obj["VRID Module Tables"]["Used VRIDs table"]["sdk_router_vrid_dump_columns"]
    else:
        vrid_db = router_module_obj["Used VRIDs table"]["sdk_router_vrid_dump_columns"]

    __verify_vrid_enabled(vrid_db, vrid, ip, get_ip_proto(ip))


def __get_ecmp_hw_handle_size_type(ecmp_module_obj, ecmp_id):
    ecmp_id_db = ecmp_module_obj["HWI ECMP"]["ECMP ID DB"]
    hw_block_handle = None
    ecmp_type = None
    container_type = None
    dest_ecmp_id = None
    for key, value in ecmp_id_db.items():
        if type(value) is not list:
            continue

        for ecmp in value:
            if ecmp["ECMP ID"] == ecmp_id:
                hw_block_handle = ecmp["HW block handle"]
                ecmp_type = ecmp["ECMP type"]
                container_type = ecmp["Container type"]
                if ecmp["Destination ECMP ID"] != "":
                    dest_ecmp_id = ecmp["Destination ECMP ID"]
                break

        if hw_block_handle is not None:
            break

    if hw_block_handle is None:
        logger.error("Unexpected error, the ECMP ID {} is not found from the JSON dump.".format(ecmp_id))
        return None, None, None, None, None

    ecmp_size = None
    ecmp_block_handles = ecmp_module_obj["ECMP Block Handles"]
    for key, value in ecmp_block_handles.items():
        if type(value) is not list:
            continue

        for ecmp_block_handle in value:
            if ecmp_block_handle["ECMP HW block handle"] == hw_block_handle:
                ecmp_size = ecmp_block_handle["Total weight"]
                break

        if ecmp_size is not None:
            break

    if ecmp_size is None:
        logger.error("Unexpected error, the ECMP HW block handle {} is not found from the JSON dump.".format(hw_block_handle))
        return None, None, None, None, None

    return hw_block_handle, ecmp_size, ecmp_type, container_type, dest_ecmp_id


def __verify_local_route(router_module_obj, vrid, ip, mask, eg_rif, proto):

    verify_vrid_enabled(router_module_obj, vrid, ip)

    enabled = __check_rif_enabled(router_module_obj, eg_rif, proto)
    if not enabled:
        logger.warning("RIF [%s] is not enabled for Local Route [%s]" % (eg_rif, ip))
    else:
        logger.debug("RIF [%s] is enabled for Local Route [%s]" % (eg_rif, ip))

    __check_neigh_valid(router_module_obj, eg_rif, ip, mask, proto)


def __verify_ecmp_route(router_module_obj, vrid, ip, mask, ecmp_id, proto):

    verify_vrid_enabled(router_module_obj, vrid, ip)

    if router_module_obj.get("Router ECMP Module Tables"):
        ecmp_module_obj = router_module_obj["Router ECMP Module Tables"]
    else:
        ecmp_module_obj = router_module_obj

    ecmp_hw_block_handle, size, type, container_type, _ = __get_ecmp_hw_handle_size_type(ecmp_module_obj, ecmp_id)

    if container_type != 'IP':
        logger.error("Skipping ECMP route validation, only IP container supported")
        return

    if type != 'Adaptive':
        ecmp_block_handles = ecmp_module_obj["ECMP Block Handles"]

        ecmp_active_set_str = "Active Set Of ECMP Block Handle {}".format(ecmp_hw_block_handle)
        active_set_db = ecmp_block_handles[ecmp_active_set_str]["active_set_tbl_columns"]
        if not active_set_db:
            logger.warning("No Resolved Next Hops for IP {} ECMP ID {}".format(ip, ecmp_id))
        else:
            for active_set in active_set_db:
                if active_set["Type"] == "IP":
                    enabled = __check_rif_enabled(router_module_obj, active_set["HWI RIF"], proto)
                    if not enabled:
                        logger.warning("RIF [%s] is not enabled for ECMP Route [%s]" % (active_set["HWI RIF"], ip))
                    else:
                        logger.debug("RIF [%s] is enabled for ECMP Route [%s]" % (active_set["HWI RIF"], ip))

                    found, _ = __check_neigh_valid(router_module_obj, active_set["HWI RIF"], active_set["Next hop"], None, proto)
                    if found:
                        if active_set["Action"] != "Forward":
                            logger.warning("ECMP ID {} Action is not Forward, action {}".format(ecmp_id, active_set["Action"]))
                        else:
                            logger.debug("ECMP ID {} has resolved next hop {} RIF {}" .format(ecmp_id, active_set["Next hop"], active_set["HWI RIF"]))

                    else:
                        logger.error("Unexpected error: ECMP ID {} Resolved Neighbor {} not found in Neigh DB".format(ecmp_id, active_set["IP"]))
    else:
        ecmp_active_sets = ecmp_module_obj["HWI ECMP"]
        ecmp_active_set_str = "ECMP HW Entry {}".format(ecmp_hw_block_handle)
        active_set_db = ecmp_active_sets[ecmp_active_set_str]["nh_set_entry_dump_clmns"]
        if not active_set_db:
            logger.warning("No Resolved Next Hops for IP {} ECMP ID {}".format(ip, ecmp_id))
        else:
            for active_set in active_set_db:
                if active_set["Type"] == "IP":
                    enabled = __check_rif_enabled(router_module_obj, active_set["RIF"], proto)
                    if not enabled:
                        logger.warning("RIF [%s] is not enabled for ECMP Route [%s]" % (active_set["RIF"], ip))
                    else:
                        logger.debug("RIF [%s] is enabled for ECMP Route [%s]" % (active_set["RIF"], ip))

                    found, _ = __check_neigh_valid(router_module_obj, active_set["RIF"], active_set["IP"], None, proto)
                    if found:
                        if active_set["Action"] != "Forward":
                            logger.warning("ECMP ID {} Action is not Forward, action {}".format(ecmp_id, active_set["Action"]))
                        else:
                            logger.debug("ECMP ID {} has resolved next hop {} RIF {}" .format(ecmp_id, active_set["IP"], active_set["RIF"]))

                    else:
                        logger.error("Unexpected error: ECMP ID {} Resolved Neighbor {} not found in Neigh DB".format(ecmp_id, active_set["IP"]))


def l3_params_validate(json_objs_input, json_obj_cmp):
    logger.info("Stage: Validating Layer 3")

    data = json_objs_input["json_root_obj"]
    router_module = data["Router"]

    if router_module.get("Router Module General Information"):
        if router_module["Router Module General Information"]['SDK Router HWI']['Modules are initialized'] != "TRUE":
            logger.error("ERROR: Router module not initialized")
        else:
            general_params = router_module["Router Module General Information"]["General params"]
    else:
        if router_module['SDK Router HWI']['Modules are initialized'] != "TRUE":
            logger.error("ERROR: Router module not initialized")
        else:
            general_params = router_module["General params"]

    if "VRID Module Tables" not in router_module and "Used VRIDs table" not in router_module:
        logger.error("ERROR: Virtual router information not present in Dump")
        return

    if "HWI ROUTER INTERFACE" not in router_module and "Router Interface Module Tables" not in router_module:
        logger.error("ERROR: RIF information not present in Dump")
        return

    if "HWI DB ROUTER NEIGHBOR" not in router_module and "Router Neighbor Module Tables" not in router_module:
        logger.error("ERROR: Neigh information not present in Dump")
        return

    # Protocols
    logger.info("Stage: Validating VRID Protocols")
    proto_checker = ["ip4_enable", "ip4_mc_enable", "ip6_enable"]
    for key in proto_checker:
        if general_params[key] != "TRUE":
            logger.warning("l3 Protocol [%s] is not supported by Router module" % (key))
        else:
            logger.debug("l3 Protocol [%s] is supported by Router module" % (key))

    # VRID Protocols
    if router_module.get("VRID Module Tables"):
        vrid_db = router_module["VRID Module Tables"]["Used VRIDs table"]["sdk_router_vrid_dump_columns"]
    else:
        vrid_db = router_module["Used VRIDs table"]["sdk_router_vrid_dump_columns"]

    proto_checker = ["ip4", "ip6", "ip4mc"]
    for vrid in vrid_db:
        for key in proto_checker:
            if vrid[key] != "1":
                logger.warning("l3 Protocol [%s] is not supported for VRID [%s]" % (key, vrid["VRID"]))
            else:
                logger.debug("l3 Protocol [%s] is supported for VRID [%s]" % (key, vrid["VRID"]))

    # UC Routes Local

    proto_list = ["4", "6"]
    for proto in proto_list:
        proto_str = "IPv{} UC Routes".format(proto)
        logger.info("Stage: Validating {} Routes".format(proto_str))
        if router_module.get("HWI UC-Route Tables"):
            uc_route_entries = router_module["HWI UC-Route Tables"][proto_str]
        else:
            uc_route_entries = router_module[proto_str]

        if uc_route_entries.get("router_uc_entries_dump_clmns"):
            for uc_route in uc_route_entries["router_uc_entries_dump_clmns"]:
                logger.debug("Checking Route {}".format(uc_route["IP"] + '/' + uc_route["Mask len"]))
                if uc_route["Action"] == "Forward":
                    if uc_route["Type"] == "Local":
                        __verify_local_route(router_module, uc_route["VRID"], uc_route["IP"], uc_route["Mask len"], uc_route["Eg. RIF"], proto)
                    elif uc_route["Type"] == "ECMP":
                        __verify_ecmp_route(router_module, uc_route["VRID"], uc_route["IP"], uc_route["Mask len"], uc_route["ECMP ID"], proto)
        else:
            logger.debug("No {} UC Routes configured".format(proto_str))


def __verify_port_up(json_objs_input, port_in, opt_str=''):
    data = json_objs_input["json_root_obj"]
    port_module = data["Port Module"]
    port_db = port_module["Port DB Dump"]["Device 1"]["SWID 0"]

    for key, value in port_db.items():
        if type(value) == list:
            if "Oper" in value[0]:
                port_table_input = value
                break

    for port in port_table_input:
        if str(int(port["Port ID"], 16)) == port_in:
            if port["Oper"] == "Down":
                logger.warning("{} {} {} is Oper Down".format(opt_str, get_port_type_str(port["Port ID"]), port["Port ID"]))
            else:
                logger.debug("{} {} {} is Oper UP".format(opt_str, get_port_type_str(port["Port ID"]), port["Port ID"]))


def bitLen(n):
    length = 0
    while (n):
        n >>= 1
        length += 1
    return (length)


def __isKthBitSet(n, k):
    if n & (1 << k):
        return True
    else:
        return False


def __get_set_bits(n):
    k = 0
    set_bit_list = []
    l = bitLen(n)
    while (l):
        if __isKthBitSet(n, k):
            set_bit_list.append(k)
        l -= 1
        k += 1
    return set_bit_list


def ar_params_validate(json_objs_input):
    logger.info("Stage: Validating Adaptive ECMP config")
    data = json_objs_input["json_root_obj"]
    router_module_obj = data["Router"]

    if router_module_obj.get("Adaptive Routing ECMP Module Tables"):
        ar_module_obj = router_module_obj["Adaptive Routing ECMP Module Tables"]
    else:
        ar_module_obj = router_module_obj

    if ar_module_obj.get("Adaptive Routing ECMP Active Set Dump"):
        active_set = ar_module_obj["Adaptive Routing ECMP Active Set Dump"]
    else:
        logger.error("No Adaptive Routing Config present in Dump")
        return

    for _, value in active_set.items():
        for value1 in value["active_set_tbl_columns"]:
            __verify_port_up(json_objs_input, value1["RIF Sub Port"])

    if router_module_obj.get("Router Interface Module Tables"):
        rifs_mod = router_module_obj['Router Interface Module Tables']['HWI ROUTER INTERFACE']
    else:
        rifs_mod = router_module_obj['HWI ROUTER INTERFACE']

    rifs = rifs_mod["Printing Router Interfaces Of Type Adaptive Routing"]["rif_entry_table"]
    for rif in rifs:
        __verify_port_up(json_objs_input, str(int(rif["adaptive ro"], 16)))

    ecmp_local_port_groups = ar_module_obj["AR Port Groups ECMP Details"]["ecmp_dump_columns"]
    ecmp_port_group_map = {}

    for local_port_group in ecmp_local_port_groups:
        port_list = []
        port_start_count = 0
        for x in range(0, 8):
            port_grp_str = "Port Map #{}".format(x)
            if int(local_port_group[port_grp_str], 16) != 0:
                set_bit_list = __get_set_bits(int(local_port_group[port_grp_str], 16))
                for bit_set in set_bit_list:
                    port_list.append(bit_set + port_start_count)
            port_start_count += 32
        ecmp_port_group_map[local_port_group["ECMP Handle"]] = port_list

    port_module = data["Port Module"]
    port_db = port_module["Port DB Dump"]["Device 1"]["SWID 0"]

    for key, value in port_db.items():
        if type(value) == list:
            if "Oper" in value[0]:
                port_table_input = value
                break

    label_log_port_map = {}
    for port in port_table_input:
        port_type = get_port_type(port["Port ID"])
        if port_type == SX_PORT_TYPE_NETWORK:
            label_log_port_map[port["Local"]] = port["Port ID"]

    for key, value in ecmp_port_group_map.items():
        for port in value:
            __verify_port_up(json_objs_input, str(int(label_log_port_map[str(port)], 16)), "AR ECMP" + key)


def ar_config_validate(json_objs_input, json_objs_compare):
    logger.info("Stage: Comparing AR config with golden")
    data = json_objs_input["json_root_obj"]
    router_module_obj = data["Router"]
    if router_module_obj.get("HWI Adaptive Routing Tables"):
        ar_config_obj = router_module_obj["HWI Adaptive Routing Tables"]
    elif data.get('HWI Router Adaptive Routing DB'):
        ar_config_obj = data['HWI Router Adaptive Routing DB']
    else:
        logger.error("No Adaptive Routing Config present in Dump")
        return

    data_cmp = json_objs_compare["json_root_obj"]
    router_module_obj_cmp = data_cmp["Router"]
    if router_module_obj_cmp.get("HWI Adaptive Routing Tables"):
        ar_config_obj_cmp = router_module_obj_cmp["HWI Adaptive Routing Tables"]
    elif data_cmp.get('HWI Router Adaptive Routing DB'):
        ar_config_obj_cmp = data_cmp['HWI Router Adaptive Routing DB']
    else:
        logger.error("No Adaptive Routing Config present in Golden Dump")
        return

    for ar_in in ar_config_obj_cmp:
        if ar_in in ar_config_obj:
            if ar_config_obj[ar_in] != ar_config_obj_cmp[ar_in]:
                logger.warning("AR Config {} does not match with golden config {}".format(ar_in, ar_config_obj[ar_in]))
            else:
                logger.debug("AR Config {} does match with golden config {}".format(ar_in, ar_config_obj[ar_in]))
        else:
            logger.error("AR Config Param {} does not exist in dump".format(ar_in))


def validate_ports(json_obj_input, json_obj_compare):
    validate_ports_up(json_obj_input)
    if json_obj_compare:
        validate_ports_config(json_obj_input, json_obj_compare)
    else:
        logger.info("No golden dump/config provided, skipping ports config validation")


def ar_validate(json_obj_input, json_obj_compare):
    ar_params_validate(json_obj_input)
    if json_obj_compare:
        ar_config_validate(json_obj_input, json_obj_compare)
    else:
        logger.info("No golden dump/config provided, skipping AR config validation")


def __verify_nve_nexthop(router_module_obj, dip, ulvrid, proto, tunnel_id):

    # Get Dest see if it is resolved
    found = False
    enabled = False
    n_found = False

    n_found, eg_rif = __check_neigh_valid(router_module_obj, None, dip, None, proto)
    if n_found:
        logger.debug("Neighbor present for Tunnel {}".format(tunnel_id))
    else:
        logger.warning("Neighbor is not present for Tunnel {}".format(tunnel_id))

    if eg_rif:
        enabled = __check_rif_enabled(router_module_obj, eg_rif, proto)
        if not enabled:
            logger.warning("Underlay RIF {} is not enabled for Proto IPv{} VxLAN tunnel {}".format(eg_rif, proto, tunnel_id))
        else:
            logger.debug("Underlay RIF {} is enabled for Proto IPv{} VxLAN tunnel {}".format(eg_rif, proto, tunnel_id))

    # Is there a route configured in the Underlay Vrid that matches ?
    found = __is_route_configured_for_ip(router_module_obj, ulvrid, dip)
    if not found:
        logger.warning("No matching route configured in Vrid {} for Proto IPv{} in VxLAN tunnel {}".format(ulvrid, proto, tunnel_id))
    else:
        logger.debug("Matching route configured in Vrid {} for Proto IPv{} in VxLAN tunnel {}".format(ulvrid, proto, tunnel_id))

    return (found and enabled and n_found)


def __verify_nve_ecmp(router_module_obj, ecmp_id, tun_id, proto):

    if router_module_obj.get("Router ECMP Module Tables"):
        ecmp_module_obj = router_module_obj["Router ECMP Module Tables"]
    else:
        ecmp_module_obj = router_module_obj

    ecmp_hw_block_handle, size, _, container_type, dest_ecmp_id = __get_ecmp_hw_handle_size_type(ecmp_module_obj, ecmp_id)

    if container_type in ["NVE MC", "NVE Flood"]:
        pass
    else:
        logger.debug("ECMP type {} in not NVE".format(container_type))
        return False

    ecmp_block_handles = ecmp_module_obj["ECMP Block Handles"]
    ecmp_active_set_str = "Active Set Of ECMP Block Handle {}".format(ecmp_hw_block_handle)
    active_set_db_list = [ecmp_block_handles[ecmp_active_set_str]["active_set_tbl_columns"]]
    # Check if redirect exists, then find the info for than one, too. Only one redirect possible
    if dest_ecmp_id:
        logger.debug("ECMP {} is Redirected to ECMP {}".format(ecmp_id, dest_ecmp_id))
        dest_ecmp_hw_block_handle, _, _, _, _ = __get_ecmp_hw_handle_size_type(ecmp_module_obj, ecmp_id)
        dest_ecmp_active_set_str = "Active Set Of ECMP Block Handle {}".format(dest_ecmp_hw_block_handle)
        active_set_db_list.append(ecmp_block_handles[dest_ecmp_active_set_str]["active_set_tbl_columns"])

    for active_set_db in active_set_db_list:
        if not active_set_db:
            logger.warning("No Resolved Next Hops for Tunnel {} ECMP ID {}".format(tun_id, ecmp_id))
        else:
            for active_set in active_set_db:
                if active_set["Type"] == "Tunnel Encapsulation":
                    found, eg_rif = __check_neigh_valid(router_module_obj, None, active_set["Next hop"], None, proto)
                    if found:
                        if active_set["Action"] != "Forward":
                            logger.warning("Tunnel {} ECMP ID {} Action is not Forward, action {}".format(tun_id, ecmp_id, active_set["Action"]))
                        else:
                            logger.debug("Tunnel {} ECMP ID {} has resolved next hop {} RIF {}" .format(tun_id, ecmp_id, active_set["Next hop"], eg_rif))

                    else:
                        logger.error("Unexpected error: Tunnel {} ECMP ID {} Resolved Neighbor {} not found in Neigh DB".format(tun_id, ecmp_id, active_set["IP"]))

    return True


def vxlan_params_compare(json_obj_input, json_obj_compare):
    logger.info("Stage: Comparing VXLAN config with golden")
    data = json_obj_input["json_root_obj"]
    tunnel_module_obj = data["TUNNEL"]
    vxlan_gen_obj = tunnel_module_obj["NVE tunnel module general params"]

    data_cmp = json_obj_compare["json_root_obj"]
    tunnel_module_obj_cmp = data_cmp["TUNNEL"]
    vxlan_gen_obj_cmp = tunnel_module_obj_cmp["NVE tunnel module general params"]

    for x, y in zip(vxlan_gen_obj, vxlan_gen_obj_cmp):
        if x != y:
            logger.warning("VxLAN General Config Param {} does not match with golden {}".format(x, y))
        else:
            logger.debug("VxLAN General Config Param {} matches with golden {}".format(x, y))

    hwd_tngcr_config = tunnel_module_obj["HWD tunnel module general params"]["TNGCR Config"]
    hwd_tngcr_config_cmpr = tunnel_module_obj_cmp["HWD tunnel module general params"]["TNGCR Config"]

    hwd_tigcr_config = tunnel_module_obj["HWD tunnel module general params"]["TIGCR Config"]
    hwd_tigcr_config_cmpr = tunnel_module_obj_cmp["HWD tunnel module general params"]["TIGCR Config"]

    if hwd_tngcr_config["NVE type"] == "VXLAN":
        for x, y in zip(hwd_tngcr_config, hwd_tngcr_config_cmpr):
            if "Underlay" not in x:
                if x != y:
                    logger.warning("TNGCR Config Param {} does not match with golden {}".format(x, y))
                else:
                    logger.debug("TNGCR Config Param{} matches with golden {}".format(x, y))

        for x, y in zip(hwd_tigcr_config, hwd_tigcr_config_cmpr):
            if x != y:
                logger.warning("TIGCR Config Param {} does not match with golden {}".format(x, y))
            else:
                logger.debug("TIGCR Config Param{} matches with golden {}".format(x, y))

    else:
        logger.warning("NVE tunnel type is not VXLAN, skipping HWD checks")

    if "HWD tunnel module CoS Data type 1 VXLAN" in tunnel_module_obj:
        hwd_tunnel_cos_decap = tunnel_module_obj["HWD tunnel module CoS Data type 1 VXLAN"]["Decap"]["tunnel_decap_cos_data_table"]
        hwd_tunnel_cos_decap_cmp = tunnel_module_obj_cmp["HWD tunnel module CoS Data type 1 VXLAN"]["Decap"]["tunnel_decap_cos_data_table"]

        hwd_tunnel_cos_encap = tunnel_module_obj["HWD tunnel module CoS Data type 1 VXLAN"]["Encap"]["tunnel_encap_cos_data_table"]
        hwd_tunnel_cos_encap_cmp = tunnel_module_obj_cmp["HWD tunnel module CoS Data type 1 VXLAN"]["Encap"]["tunnel_encap_cos_data_table"]

        for x, y in zip(hwd_tunnel_cos_decap, hwd_tunnel_cos_decap_cmp):
            if x != y:
                logger.warning("Tunnel Decap Cos Param {} does not match with golden {}".format(x, y))
            else:
                logger.debug("Tunnel Decap Cos Param {} matches with golden".format(x, y))

        for x, y in zip(hwd_tunnel_cos_encap, hwd_tunnel_cos_encap_cmp):
            if x != y:
                logger.warning("Tunnel Encap Cos Param {} does not match with golden {}".format(x, y))
            else:
                logger.debug("Tunnel Encap Cos Param {} matches with golden".format(x, y))


def __validate_region_actions(json_obj_input, region_id):
    data = json_obj_input["json_root_obj"]
    acl_module_obj = data["Flex ACL"]
    sw_action = acl_module_obj["SW Actions"]
    sw_action_rules = sw_action["rules_dump_columns"]
    validate = True

    for action in sw_action_rules:
        if action["Region ID"] == region_id:
            if action["Type"] in ['TRAP', 'TRAP_W_USER_ID']:
                logger.warning("NVE action region has a TRAP action type")
                validate = False
            elif action["Type"] == 'FORWARD':
                # Need to check if Forward has type Discard
                forward_action_details = sw_action["SW ACTION FORWARD"]["action_dump_descr[act_type].columns_p"]
                for fowrard_action in forward_action_details:
                    if fowrard_action["Region ID"] == region_id:
                        if fowrard_action["Action"] == 'DISCARD':
                            logger.warning("NVE action region has a forward with discard action type")
                            validate = False
    return validate


def __get_acl_type_direction_bindings(json_obj_input, region_id):
    data = json_obj_input["json_root_obj"]
    acl_module_obj = data["Flex ACL"]
    region_details = acl_module_obj["Allocated ACL Regions"]["regions_dump_columns"]
    acl_tables = acl_module_obj["Allocated ACL Tables"]["acl_dump_columns"]
    acl_bind_attributes = acl_module_obj["Allocated Bind Attributes DB"]["acl_dump_columns"]
    group_tables = acl_module_obj["Allocated ACL Groups DB"]["acl_dump_columns"]
    type = direction = group_id = bind_attr_id = None
    bind_point_list = []

    for region in region_details:
        if region_id == region["Region ID"]:
            type = region["Type"]
            direction = region["Direction"]

    for acl in acl_tables:
        if acl["Region ID"] == region_id:
            group_id = acl["Bound Gr"]

    for group in group_tables:
        if group["Group ID"] == group_id:
            bind_attr_id = group["Bind Attr ID"]

    for bind_id in acl_bind_attributes:
        if bind_attr_id == bind_id["Bind ID"]:
            if bind_id["Ports"] != "0":
                bind_point_list.append(bind_id["PortID"])
            if bind_id["LAGs"] != "0":
                bind_point_list.append(bind_id["LAG ID"])
            if bind_id["RIFs"] != "0":
                bind_point_list.append(bind_id["RIF ID"])
            if bind_id["VLANs"] != "0":
                bind_point_list.append(bind_id["VLAN Grp"])

    return type, direction, bind_point_list


def __compare_is_equal_tunnel_id_str(tunnel_id1, tunnel_id2):
    if 'x' in tunnel_id1:
        tun_id1_val = int(tunnel_id1, 16)
    else:
        tun_id1_val = int(tunnel_id1)

    if 'x' in tunnel_id2:
        tun_id2_val = int(tunnel_id2, 16)
    else:
        tun_id2_val = int(tunnel_id2)

    return (tun_id1_val == tun_id2_val)


def vxlan_flex_acl_validate(json_obj_input, direction, ul_vrid, proto, tunnel_id):
    data = json_obj_input["json_root_obj"]
    acl_module_obj = data["Flex ACL"]
    router_module_obj = data["Router"]
    mc_container_module_obj = data["MC Container"]["MC Container DB"]["MC Containers Next Hops Table"]["mc_container_next_hop_columns"]
    tunnel_decap_db_obj = data["TUNNEL"]["Decap Table Entries"]["decap_table_columns"]
    found = False

    if not acl_module_obj["ACL Key handles"]["acl_dump_columns"]:
        logger.warning("No ACL Rule configured")
        return found

    sw_action = acl_module_obj["SW Actions"]
    sw_action_rules = sw_action["rules_dump_columns"]
    if direction == 'ENCAP':
        for action in sw_action_rules:
            if action["Type"] == 'NVE_MC_TUNNEL_ENCAP':
                nve_action_details = sw_action["SW ACTION NVE MC TUNNEL ENCAP"]["action_dump_descr[act_type].columns_p"]
                for nve_action in nve_action_details:
                    # Find MC Container
                    for mc_cnt in mc_container_module_obj:
                        if mc_cnt["ID"] == nve_action["MC container"]:
                            # IF type ECMP or "Tunnel ENCAP IP" then it could be Tunnel
                            if mc_cnt["Type"] == "ECMP":
                                # Find the ECMP container and see if type is NVE
                                found = __verify_nve_ecmp(router_module_obj, mc_cnt["Contents"], tunnel_id, proto)
                            elif mc_cnt["Type"] == "Tunnel ENCAP IP":
                                # Contents in this case are formatted as tun{TunID}:{Next hop}
                                found = __verify_nve_nexthop(router_module_obj, mc_cnt["Contents"].split(':')[1], ul_vrid, proto, tunnel_id)
                            else:
                                logger.error("Unexpected NH type for NVE TUnnel Encap action")
                                return False
                            break
                    if found:
                        nve_region_id = action["Region ID"]
                        acl_keys_db = acl_module_obj["ACL RULES SW KEYS DB"]["rules_dump_columns"]
                        key_list = []
                        for acl_key in acl_keys_db:
                            if acl_key["Region ID"] == nve_region_id:
                                key_list.append({acl_key["Key Type"]: (acl_key["Key value"], acl_key["Key mask"])})
                        logger.debug("Found NVE_MC_TUNNEL_ENCAP Rule in Region {} Keys {}".format(nve_region_id, key_list))
                        break

                validated = __validate_region_actions(json_obj_input, action["Region ID"])
                if not validated:
                    logger.warning("NVE Tunnel ACL action {} has a Trap/Discard action in Region {}".format(action["Type"], action["Region ID"]))

            if action["Type"] == 'NVE_TUNNEL_ENCAP':
                nve_action_details = sw_action["SW ACTION NVE TUNNEL ENCAP"]["action_dump_descr[act_type].columns_p"]
                for nve_action in nve_action_details:
                    # NH is tunnel
                    if nve_action["Encap. type"] == "Tunnel":
                        found = __verify_nve_nexthop(router_module_obj, nve_action["Underlay DIP"], ul_vrid, proto, tunnel_id)
                    elif nve_action["Encap. type"] == "ECMP":
                        found = __verify_nve_ecmp(router_module_obj, nve_action["ECMP ID"], tunnel_id, proto)
                    else:
                        logger.error("Unexpected NH type for NVE TUnnel Encap action")
                        return False
                    if found:
                        nve_region_id = action["Region ID"]
                        acl_keys_db = acl_module_obj["ACL RULES SW KEYS DB"]["rules_dump_columns"]
                        key_list = []
                        for acl_key in acl_keys_db:
                            if acl_key["Region ID"] == nve_region_id:
                                key_list.append({acl_key["Key Type"]: (acl_key["Key value"], acl_key["Key mask"])})
                        logger.debug("Found NVE_TUNNEL_ENCAP Rule in Region {} Keys {}".format(nve_region_id, key_list))
                        break

                # Validate other actions in this Region, see if there are any Discard actions
                # Note this is limited, we only check for any Trap or Discard actions.
                validated = __validate_region_actions(json_obj_input, action["Region ID"])
                if not validated:
                    logger.warning("NVE Tunnel ACL action {} has a Trap/Discard action in Region {}".format(action["Type"], action["Region ID"]))

        return found
    else:
        # Decap path (Can be set explicitly by user via ACL path or System ACL via Router. ACL )
        # Find Rule -> goes to L2 Bridge set by VNI - From VNI get Bridge/FID mapping. VLAN tag does not matter in SPC2+
        # We have already checked FID/VNI mapping exists in Decap case
        found = False
        for action in sw_action_rules:
            if action["Type"] == 'TUNNEL_DECAP':
                decap_details = sw_action["SW ACTION TUNNEL DECAP"]["action_dump_descr[act_type].columns_p"]
                for decap_action in decap_details:
                    region_id = decap_action["Region ID"]
                    tunnel_id = decap_action["Tunnel id"]

                    type, acl_direction, bind_point_list = __get_acl_type_direction_bindings(json_obj_input, region_id)
                    # If User created tunnel decap
                    # In both cases a UCRT action is internally added with Tunnel termination action pointing to Tunnel Decap handle
                    # Since there is only 1 NVE tunnel possible, no reason to validate it at this time
                    if acl_direction == "INGRESS":
                        if type != "USER":
                            logger.error("Unexpected bind point for Tunnel Decap System ACL")
                            return False
                        found = True

                    elif acl_direction == "RIF_INGRESS":
                        if type == "SYSTEM":
                            # System ACL, find Decap Table
                            # Sanity only, TUNNEL_DECAP action would not exist if action is not Forward
                            if not tunnel_decap_db_obj:
                                logger.error("Unexpected error: No Decap Table exists for Tunnel {}".format(tunnel_id))
                                return False
                            else:
                                for decap_entry in tunnel_decap_db_obj:
                                    if __compare_is_equal_tunnel_id_str(decap_entry["Tunnel ID"], tunnel_id):
                                        if decap_entry["Action"] == "Forward":
                                            logger.debug("Found Decap Rule for Tunnel {} Decap Type {} DIP {}".format(tunnel_id, decap_entry["Type"], decap_entry["Dest IP"]))
                                            found = True

                            if not found:
                                logger.error("Unexpected error: No Decap Rule exists for Tunnel {}".format(tunnel_id))
                                return False

                        else:
                            found = True

        if found and type == 'USER':
            nve_region_id = action["Region ID"]
            acl_keys_db = acl_module_obj["ACL RULES SW KEYS DB"]["rules_dump_columns"]
            key_list = []
            for acl_key in acl_keys_db:
                if acl_key["Region ID"] == nve_region_id:
                    key_list.append({acl_key["Key Type"]: (acl_key["Key value"], acl_key["Key mask"])})
                logger.debug("Found TUNNEL_DECAP Rule in Region {} Keys {} Bind Point".format(nve_region_id, key_list, bind_point_list))
                break

            validated = __validate_region_actions(json_obj_input, action["Region ID"])
            if not validated:
                logger.warning("Tunnel Decap for Tunnel {} has a Trap/Discard action in Region {}".format(tunnel_id, region_id))

        return found


def get_dont_care_rif(json_obj_input):
    data = json_obj_input["json_root_obj"]
    chip_type = data["SDK versions"]["Chip Type:"]
    if chip_type == "CHIP_TYPE_SPECTRUM" or chip_type == "CHIP_TYPE_SPECTRUM_A1":     # SPC1
        return "1001"
    elif chip_type == "CHIP_TYPE_SWITCH_SPECTRUM4":   # SPC4
        return "8001"
    else:                       # SPC2/3
        return "4001"


def __find_mc_route_action(json_obj_input, mc_container_id):
    data = json_obj_input["json_root_obj"]
    acl_module_obj = data["Flex ACL"]
    sw_action = acl_module_obj["SW Actions"]
    mc_action_details = sw_action["SW ACTION MC ROUTE"]["action_dump_descr[act_type].columns_p"]
    found = False
    mc_route_db = data["Router"]["MC-Route Tables"]["HWI MC ROUTE DB"]["MC Route Dump IPv4"]["mc_route_db_columns"]

    mc_action_region_id = None
    sw_key_details = acl_module_obj["ACL RULES SW KEYS DB"]["rules_dump_columns"]
    mc_vrid = None

    for mc_action in mc_action_details:
        # MC Route action mc_container is under ecmp key
        if mc_action["ecmp"] == mc_container_id:
            found = True
            mc_action_region_id = mc_action["Region ID"]
            mc_rule_offset = mc_action["Offset"]
            break
    if found:
        for sw_key in sw_key_details:
            if sw_key["Region ID"] == mc_action_region_id and sw_key["Offset"] == mc_rule_offset:
                # MC Rule will always have SIP/DIP/VRID . Find Vrid so we can pull details from MC DB
                if sw_key["Key Type"] == "VIRTUAL_ROUTER":
                    mc_vrid = sw_key["Key value"].split(':')
                    break

    # Max VRID value is 4K, Keys are stored in XX:XX format but reversed
    if mc_vrid:
        mc_vrid_value = str(int("0x{}{}".format(mc_vrid[1], mc_vrid[0]), 0))

        for mc_route_entry in mc_route_db:
            if mc_route_entry["VRID"] == mc_vrid_value:
                return mc_route_entry

    return None


def vxlan_params_validate(json_obj_input):
    data = json_obj_input["json_root_obj"]
    tunnel_module_obj = data["TUNNEL"]

    hwd_tngcr_config = tunnel_module_obj["HWD tunnel module general params"]["TNGCR Config"]

    if hwd_tngcr_config["NVE type"] != "VXLAN":
        logger.warning("NVE tunnel type is not VXLAN, skipping Vxlan checks")
        return

    # Find NVE tunnel ID, can only be one NVE tunnel
    tunnel_entry_table = tunnel_module_obj["HWI TUNNEL DB"]["tunnel_entry_table"]

    nve_tunnel_id = None
    for tunnel in tunnel_entry_table:
        if tunnel["Type"] == "NVE":
            nve_tunnel_id = tunnel["ID"]
            break

    if not nve_tunnel_id:
        logger.error("Unexpected error, could not find NVE tunnel ID")
    else:
        logger.debug("Found NVE Tunnel ID {}".format(nve_tunnel_id))

    tunnel_details = tunnel_module_obj["Tunnel detailed data"]["TUNNEL {}".format(nve_tunnel_id)]

    # Ensure Underlay Vrid is enabled
    router_module_obj = data["Router"]
    verify_vrid_enabled(router_module_obj, tunnel_details["Underlay VRID"], tunnel_details["Underlay SIP"])

    # Check RIFs are enabled (if underlay domain type is RIF, else it is internally created )
    if tunnel_details["Underlay Domain Type"] == "RIF":
        proto = get_ip_proto(tunnel_details["Underlay SIP"])
        enabled = __check_rif_enabled(tunnel_details["Underlay RIF Encap"], proto)
        if not enabled:
            logger.warning("Loopback RIF {} is not enabled for Proto IPv{} VxLAN tunnel {}".format(tunnel_details["Underlay RIF Encap"], proto, nve_tunnel_id))
        else:
            logger.debug("Loopback RIF {} is enabled for Proto IPv{} VxLAN tunnel {}".format(tunnel_details["Underlay RIF Encap"], proto, nve_tunnel_id))

    # Check if FID-VNI mapping exists
    tunn_bridge_vni = tunnel_module_obj["Tunnel, Bridge to VNI mapping"]["Bridge To VNI - Tunnel {}".format(nve_tunnel_id)]["tunnel_bridge_to_vni_table"]
    if not tunn_bridge_vni:
        logger.warning("No VLAN/Bridge to VNI mapping exists, decap packets will be dropped")
    else:
        logger.debug("FID-VNI mapping exists for Tunnel {} Bridge {} VNI {}".format(nve_tunnel_id, tunn_bridge_vni[0]["FID"], tunn_bridge_vni[0]["VNI"]))

    # Encap path
    if tunnel_details["Dir"] == 'SYMMETRIC' or tunnel_details["Dir"] == 'ENCAP':
        logger.info("Stage: Validating NVE Encap Path...")
        # Is there a route configured in the UL Vrid for the encapsulated packet ? (just sanity, since we dont know the actual packet DIP till later)
        proto = get_ip_proto(tunnel_details["Underlay SIP"])
        proto_str = "IPv{} UC Routes".format(proto)
        logger.info("Stage: Validating {} Routes for Tunnel {}".format(proto_str, nve_tunnel_id))
        if router_module_obj.get("HWI UC-Route Tables"):
            uc_route_entries = router_module_obj["HWI UC-Route Tables"][proto_str]
        else:
            uc_route_entries = router_module_obj[proto_str]
        if uc_route_entries.get("router_uc_entries_dump_clmns"):
            for uc_route in uc_route_entries["router_uc_entries_dump_clmns"]:
                if uc_route["VRID"] == tunnel_details["Underlay VRID"]:
                    if uc_route["Action"] == "Forward":
                        if uc_route["Type"] == "Local":
                            __verify_local_route(router_module_obj, uc_route["VRID"], uc_route["IP"], uc_route["Mask len"], uc_route["Eg. RIF"], proto)
                        elif uc_route["Type"] == "ECMP":
                            __verify_ecmp_route(router_module_obj, uc_route["VRID"], uc_route["IP"], uc_route["Mask len"], uc_route["ECMP ID"], proto)
        else:
            logger.warning("No {} UC Routes configured for Tunnel ".format(proto_str, nve_tunnel_id))

        # How do we reach the Tunnel, Check ACL
        found_acl = False
        found_fdb_uc = False
        found_fdb_mc = False
        found_fdb_flood = False
        found_acl = vxlan_flex_acl_validate(json_obj_input, 'ENCAP', tunnel_details["Underlay VRID"], proto, nve_tunnel_id)

        # Find if UC FDB entry exists
        fdb_module_obj = data["FDB Module"]["FDB UC Table Dump"]["SWID 0"]["mac_dump_clmns"]
        for fdb_entry in fdb_module_obj:
            if fdb_entry["Port"] == "0x80010000":
                found_fdb_uc = True
                # validate action is forward
                if fdb_entry["Action"] != "FORWARD":
                    logger.warning("FDB action to Tunnel does not have forward action")
                    break
                # Get type, can be next hop (SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP) or ECMP (SX_FDB_UC_MAC_ADDR_DEST_TYPE_ECMP_NEXT_HOP_CONTAINER)
                if fdb_entry["Destination Type"] == "Next hop":
                    verified = __verify_nve_nexthop(router_module_obj, fdb_entry["Destination"], tunnel_details["Underlay VRID"], proto, nve_tunnel_id)
                elif fdb_entry["Destination Type"] == "ECMP":
                    # ECMP with tunnel next hops SX_ECMP_CONTAINER_TYPE_NVE_FLOOD or SX_ECMP_CONTAINER_TYPE_NVE_MC
                    # find the relevant container and verify
                    # Is there a redirect, verify the redirected container also
                    verified = __verify_nve_ecmp(router_module_obj, fdb_entry["Destination"], nve_tunnel_id, proto)
                else:
                    logger.error("Unexpected Destination type for Tunnel FDB {}".format(fdb_entry["Destination Type"]))
                if not verified:
                    logger.warning("Could not validate Tunnel/ECMP next hop for FDB Tunnel entry")
        if found_fdb_uc and verified:
            logger.debug("Found UC Tunnel FDB Entry for Tunnel ID {} of Type {}".format(nve_tunnel_id, fdb_entry["Destination Type"]))

        # Could be MC FDB
        fdb_mc_module_obj = data["FDB Multicast Extended Module"]["mc_mac_addr_db_dump_clmns"]
        mc_container_module_obj = data["MC Container"]["MC Container DB"]["MC Containers Next Hops Table"]["mc_container_next_hop_columns"]
        if data["MC Container"]["MC Container DB"]["Initialized"] != "TRUE":
            logger.debug("MC Container not initialized")
            found_fdb_mc = False
        else:
            for fdb_entry in fdb_mc_module_obj:
                if fdb_entry["Action"] == "FORWARD":
                    # Find MC container and see if it has type NVE next hop
                    mc_container = fdb_entry["Container"]
                    for mc_cnt in mc_container_module_obj:
                        if mc_cnt["ID"] == mc_container:
                            # IF type ECMP or "Tunnel ENCAP IP" then it could be Tunnel
                            if mc_cnt["Type"] == "ECMP":
                                # Find the ECMP container and see if type is NVE
                                found_fdb_mc = __verify_nve_ecmp(router_module_obj, mc_cnt["Contents"], nve_tunnel_id, proto)
                                break
                            elif mc_cnt["Type"] == "Tunnel ENCAP IP":
                                # Contents in this case are formatted as tun{TunID}:{Next hop}
                                found_fdb_mc = True
                                __verify_nve_nexthop(router_module_obj, mc_cnt["Contents"].split(':')[1], tunnel_details["Underlay VRID"], proto, nve_tunnel_id)
                                break
        if found_fdb_mc:
            logger.debug("Found MC Tunnel FDB Entry for Tunnel ID {}, MC Container {} of Type {}".format(nve_tunnel_id, mc_container, mc_cnt["Type"]))

        # Could not find in ACL or FDB, check flooding
        # Check NVE flood vector
        fdb_flood_db = data["FDB Flood Module"]["FDB FLOOD DB"]["SWID #0"]["List of MC containers"]
        mc_container_module_obj = data["MC Container"]["MC Container DB"]["MC Containers Next Hops Table"]["mc_container_next_hop_columns"]
        for fdb_flood_entry in fdb_flood_db:
            mc_container = fdb_flood_entry["MC container ID"]
            # MC container needs to be of type FLOOD or VLAN unaware
            # Next hop can be a tunnel Encap or an ECMP with NVE FLood/NVE MC type
            for mc_cnt in mc_container_module_obj:
                if mc_cnt["ID"] == mc_container:
                    if mc_cnt["Type"] == "ECMP":
                        # Find the ECMP container and see if type is NVE
                        found_fdb_flood = __verify_nve_ecmp(router_module_obj, mc_cnt["Contents"], nve_tunnel_id, proto)
                        break
                    elif mc_cnt["Type"] == "Tunnel ENCAP IP":
                        # Contents in this case are formatted as tun{TunID}:{Next hop}
                        found_fdb_flood = True
                        __verify_nve_nexthop(router_module_obj, mc_cnt["Contents"].split(':')[1], tunnel_details["Underlay VRID"], proto, nve_tunnel_id)
                        break

        if found_fdb_flood:
            logger.debug("Found NVE Flood FDB Entry for Tunnel ID {}, MC Container {} of Type {}".format(nve_tunnel_id, mc_container, mc_cnt["Type"]))
            return

        if not found_acl and not found_fdb_uc and not found_fdb_mc and not found_fdb_flood:
            logger.error("Could not validate Encap Tunnel configuration")

    if tunnel_details["Dir"] == 'SYMMETRIC' or tunnel_details["Dir"] == 'DECAP':
        logger.info("Stage: Validating NVE Decap Path...")
        # Check ACL action
        found_acl = False
        found_fdb_mc = False
        found_acl = vxlan_flex_acl_validate(json_obj_input, 'DECAP', tunnel_details["Underlay VRID"], proto, nve_tunnel_id)

        fdb_mc_module_obj = data["FDB Multicast Extended Module"]["mc_mac_addr_db_dump_clmns"]
        mc_container_module_obj = data["MC Container"]["MC Container DB"]["MC Containers Next Hops Table"]["mc_container_next_hop_columns"]

        # Check MC path
        if data["MC Container"]["MC Container DB"]["Initialized"] != "TRUE":
            logger.debug("MC Container not initialized")
            found_fdb_mc = False
        else:
            # Check if the MC Container has an NVE NH
            mc_container_id = None
            mc_route_entry = None
            for mc_cnt in mc_container_module_obj:
                if mc_cnt["Type"] == "VIF":
                    # There can be only one NVE next hop
                    if "NVE" in mc_cnt["Contents"]:
                        tunnel_id = mc_cnt["Contents"].split(':')[1]
                        if __compare_is_equal_tunnel_id_str(tunnel_id, nve_tunnel_id):
                            mc_container_id = mc_cnt["ID"]
                            mc_route_entry = __find_mc_route_action(json_obj_input, mc_container_id)
                            if mc_route_entry:
                                break

            if mc_route_entry:
                irif = mc_route_entry["iRIF"]
                dont_care_rif = get_dont_care_rif(json_obj_input)
                if irif == dont_care_rif:
                    irif = "Don't Care"
                logger.debug("Found MC Decap Action MC Container {} for Tunnel {} SIP{} GrpID {} iRIF {}".format(mc_container_id, nve_tunnel_id, mc_route_entry["Source"], mc_route_entry["Group"], irif))

        if not found_acl and not mc_route_entry:
            logger.error("Could not validate Decap Tunnel configuration")


def vxlan_validate(json_obj_input, json_obj_compare):
    data = json_obj_input["json_root_obj"]
    tunnel_module_obj = data["TUNNEL"]

    if tunnel_module_obj["HWI TUNNEL"]["Module initialized"] != 'TRUE':
        logger.warning("Tunnel Module not initialized, skipping")
        return
    vxlan_params_validate(json_obj_input)

    if json_obj_compare:
        vxlan_params_compare(json_obj_input, json_obj_compare)


validation_funcs = {
    'ports': [validate_ports],
    'counters': [check_port_discard_counters],
    'rm': [validate_rm_thresholds],
    'gc': [validate_garbage_collector],
    'l3': [l3_params_validate],
    'ar': [ar_validate],
    'cos': [validate_cos_config],
    'sb': [validate_sb_config],
    'vxlan': [vxlan_validate]
}


def parse_args(args):
    json_objs_input = []
    json_obj_compare = {}
    val_list = []
    msg_sniffer_path_list = []

    if not args.json_dump and not args.cl_support_file and not args.cl_support_folder:
        print("Error: mandatory parameters are not specified 1\n")
        parser.print_help()
        sys.exit(1)

    if not args.skip_extract:
        __cleanup_folders(args)

    if args.json_dump:
        json_obj_input = {}
        json_dump = open(args.json_dump, 'rb')
        with json_dump:
            try:
                json_obj_input['filename'] = os.path.basename(args.json_dump)
                json_obj_input['json_root_obj'] = json.load(json_dump)
                json_objs_input.append(json_obj_input)
            except ValueError as e:
                raise SystemExit(e)

    elif args.cl_support_file:
        file_name = CL_SUPPORT_DUMP_EXTRACT_PATH + os.path.basename(args.cl_support_file).rsplit('.')[0] + CL_SUPPORT_SDK_DUMP_LOCATION
        json_obj_input = {}
        with tarfile.open(args.cl_support_file, 'r') as tar:
            if not args.skip_extract:
                tar.extract(os.path.basename(args.cl_support_file).rsplit('.')[0] + CL_SUPPORT_SDK_DUMP_LOCATION, path=CL_SUPPORT_DUMP_EXTRACT_PATH)
            json_dump = open(file_name, 'rb')
            with json_dump:
                try:
                    json_obj_input['filename'] = os.path.basename(args.cl_support_file)
                    json_obj_input['json_root_obj'] = json.load(json_dump)
                    json_objs_input.append(json_obj_input)

                except ValueError as e:
                    raise SystemExit(e)

        if not args.skip_message_sniffer:
            file_name = CL_SUPPORT_DUMP_EXTRACT_PATH + os.path.basename(args.cl_support_file).rsplit('.')[0] + CL_SUPPORT_SYSLOG_BASE_PATH
            if not args.skip_extract:
                with tarfile.open(args.cl_support_file, 'r') as tar:
                    for f in CL_SUPPORT_SYSLOG_FILES_LIST:
                        try:
                            tar.extract(os.path.basename(args.cl_support_file).rsplit('.')[0] + CL_SUPPORT_SYSLOG_BASE_PATH + f, path=CL_SUPPORT_DUMP_EXTRACT_PATH)
                        except tarfile.ExtractError:
                            break
                run_and_test_raising('gunzip {}*.gz '.format(file_name))
            msg_sniffer_path_list.append(file_name)

    elif args.cl_support_folder:
        for filename in os.listdir(args.cl_support_folder):
            if filename.endswith(".txz") or filename.endswith(".tar.gz"):
                file_name = CL_SUPPORT_DUMP_EXTRACT_PATH + os.path.basename(filename).rsplit('.')[0] + CL_SUPPORT_SDK_DUMP_LOCATION
                json_obj_input = {}
                with tarfile.open(args.cl_support_folder + '/' + filename, 'r') as tar:
                    if not args.skip_extract:
                        tar.extract(os.path.basename(filename).rsplit('.')[0] + CL_SUPPORT_SDK_DUMP_LOCATION, path=CL_SUPPORT_DUMP_EXTRACT_PATH)
                    json_dump = open(file_name, 'rb')
                    with json_dump:
                        try:
                            json_obj_input['json_root_obj'] = json.load(json_dump)
                            json_obj_input['filename'] = os.path.basename(filename)
                            json_objs_input.append(json_obj_input)

                        except ValueError as e:
                            raise SystemExit(e)

                if not args.skip_message_sniffer:
                    file_name = CL_SUPPORT_DUMP_EXTRACT_PATH + os.path.basename(filename).rsplit('.')[0] + CL_SUPPORT_SYSLOG_BASE_PATH
                    if not args.skip_extract:
                        with tarfile.open(args.cl_support_folder + '/' + filename, 'r') as tar:
                            for f in CL_SUPPORT_SYSLOG_FILES_LIST:
                                try:
                                    tar.extract(os.path.basename(filename).rsplit('.')[0] + CL_SUPPORT_SYSLOG_BASE_PATH + f, path=CL_SUPPORT_DUMP_EXTRACT_PATH)
                                except tarfile.ExtractError:
                                    break
                        run_and_test_raising('gunzip {}*.gz '.format(file_name))
                    msg_sniffer_path_list.append(file_name)

    if args.golden_json_dump:
        json_dump = open(args.golden_json_dump, 'rb')
        with json_dump:
            try:
                json_obj_compare['json_root_obj'] = json.load(json_dump)
            except ValueError as e:
                raise SystemExit(e)
    elif args.system_type:
        print("Unsupported please use golden dump")
        parser.print_help()
        sys.exit(1)

    if args.validations_list:
        if args.validations_list == ['all']:
            val_list = VALIDATION_LIST
        else:
            val_list = args.validations_list
    else:
        val_list = VALIDATION_LIST

    return json_objs_input, json_obj_compare, val_list, msg_sniffer_path_list


def main():
    json_objs_input, json_obj_compare, validation_list, msg_sniffer_path_list = parse_args(args)
    set_log_level(args.loglevel)

    for idx, json_obj_input in enumerate(json_objs_input):
        logger.info("*****************Checking File {}*****************".format(json_obj_input['filename']))
        for v in validation_list:
            for func in validation_funcs[v]:
                func(json_obj_input, json_obj_compare)
                do_pause_stage(args.pause_stage)

        if msg_sniffer_path_list:
            logger.info("*****************Checking syslog in {} for errors*****************".format(json_obj_input['filename']))
            for dirpath, _, files in os.walk(msg_sniffer_path_list[idx]):
                for file in files:
                    if file.startswith("syslog"):
                        temp = os.path.join(dirpath, file)
                        logger.info("Checking {} for errors".format(file))
                        # No kmemleak in cl_support_file
                        message_sniffer = message_sniffer_init(temp, None, args.loglevel)
                        message_sniffer.check(with_kmemleak=False)

        if args.force_clean:
            logger.info("Cleaning up by user request")
            __cleanup_folders(args)


if __name__ == "__main__":
    sys.exit(main())
