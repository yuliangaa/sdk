/*
 * Copyright (C) 2009-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <errno.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sdk/sx_api_vlan.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/cr_access.h>
#include <sx/sxd/sxd_dpt.h>

enum test_tool_op {
    OP_SYS_CFG,
    OP_DEV_ADD,
    OP_DEV_DEL,
    OP_INVALID
};
struct sys_params {
    char    sys_netdev_name[16];
    uint8_t sys_netdev_mac[6];
    int     sys_board_number;
    int     sys_cqe_ver;
};
struct dev_params {
    uint8_t                  dev_id;
    uint8_t                  dev_mac[6];
    uint16_t                 dev_vid;
    uint8_t                  dev_is_master;
    uint8_t                  dev_config_hopf;
    struct ku_sgmii_mft_info dev_mft_info;
};
sxd_handle __sxd_handle;

void str_to_mac(const char *strmac, uint8_t *mac)
{
    uint32_t values[6];
    int      ret;

    ret = sscanf(strmac, "%x:%x:%x:%x:%x:%x", &values[0], &values[1], &values[2], &values[3], &values[4], &values[5]);
    if (ret != 6) {
        printf("bad MAC address passed\n");
        return;
    }

    for (ret = 0; ret < 6; ret++) {
        mac[ret] = (uint8_t)values[ret];
    }
}


void sx_vista_log_cb(sx_log_severity_t severity, const char *module_name, char *msg)
{
    UNUSED_PARAM(severity);
    UNUSED_PARAM(module_name);
    UNUSED_PARAM(msg);
}


int init_sxd_layer(void)
{
    sxd_status_t sxd_err;

    sxd_err = sxd_access_reg_init(1, sx_vista_log_cb, SX_VERBOSITY_LEVEL_ERROR);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to init Access register lib\n");
        return 0;
    }

    sxd_err = sxd_open_device("sxcdev", &__sxd_handle);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to open device\n");
    }

    return (int)sxd_err;
}


sxd_status_t __access_mgir(uint8_t dev_id)
{
    sxd_reg_meta_t     reg_meta;
    struct ku_mgir_reg reg_data;

    memset(&reg_meta, 0, sizeof(reg_meta));
    memset(&reg_data, 0, sizeof(reg_data));

    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    return sxd_access_reg_mgir(&reg_data, &reg_meta, 1, NULL, NULL);
}


int system_cfg(const struct sys_params *sys_params)
{
    struct ku_sgmii_system_cfg sgmii_system_cfg;
    sxd_ctrl_pack_t            ctrl_pack;
    sxd_status_t               sxd_err;

    sxd_dpt_init(SYS_TYPE_IB, sx_vista_log_cb, SX_VERBOSITY_LEVEL_ERROR);
    init_sxd_layer();

    memset(&sgmii_system_cfg, 0, sizeof(sgmii_system_cfg));
    strcpy(sgmii_system_cfg.netdev_name, sys_params->sys_netdev_name);
    memcpy(sgmii_system_cfg.netdev_mac, sys_params->sys_netdev_mac, 6);
    sgmii_system_cfg.chassis_type =
        (sys_params->sys_cqe_ver == 0) ? KU_CHASSIS_TYPE_BARRACUDA : KU_CHASSIS_TYPE_MANTARAY;
    sgmii_system_cfg.mgmt_board = (sys_params->sys_board_number == 1) ? KU_MGMT_BOARD_1 : KU_MGMT_BOARD_2;

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_SGMII_SYSTEM_CFG;
    ctrl_pack.cmd_body = &sgmii_system_cfg;
    sxd_err = sxd_ioctl(__sxd_handle, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to set OOB system configuration (err=%u)\n", sxd_err);
        return (int)sxd_err;
    }

    printf("OOB system was initialized successfully\n");
    return 0;
}

int dev_cfg_add(const struct dev_params *dev_params)
{
    struct ku_dpt_path_add    path;
    struct ku_dpt_path_modify path_modify;
    struct ku_sgmii_init_dev  dev_init;
    sxd_ctrl_pack_t           ctrl_pack;
    dpt_path_params_t         path_params;
    sxd_status_t              sxd_err = SXD_STATUS_SUCCESS;

    init_sxd_layer();

    memset(&path, 0, sizeof(path));
    memset(&path_modify, 0, sizeof(path_modify));
    memset(&path_params, 0, sizeof(path_params));

    sxd_err = sxd_dpt_set_access_control(dev_params->dev_id, READ_WRITE);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to set device DPT access control (err=%u)\n", sxd_err);
        return (int)sxd_err;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_ADD_DEV_PATH;
    ctrl_pack.cmd_body = &path;
    path.dev_id = dev_params->dev_id;
    path.path_type = DPT_PATH_SGMII;
    memcpy(path.path_info.sx_sgmii_info.dmac, dev_params->dev_mac, 6);
    path.path_info.sx_sgmii_info.vid = dev_params->dev_vid;
    sxd_err = sxd_ioctl(__sxd_handle, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to add OOB device (dev=%u) (err=%u)\n", dev_params->dev_id, sxd_err);
        return (int)sxd_err;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_SGMII_MFT_INFO;
    ctrl_pack.cmd_body = (void*)&dev_params->dev_mft_info;
    sxd_err = sxd_ioctl(__sxd_handle, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to set OOB device (dev=%u) information (err=%u)\n", dev_params->dev_id, sxd_err);
        return (int)sxd_err;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_INIT_SGMII_DEV;
    ctrl_pack.cmd_body = &dev_init;
    dev_init.dev_id = dev_params->dev_id;
    dev_init.init_hopf = dev_params->dev_config_hopf;

    sxd_err = sxd_ioctl(__sxd_handle, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to initialize OOB device (dev=%u) with PPAD/HOPF (err=%d)\n", dev_params->dev_id, sxd_err);
        return (int)sxd_err;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_CR_ACCESS_PATH;
    ctrl_pack.cmd_body = &path_modify;
    path_modify.dev_id = dev_params->dev_id;
    path_modify.path_type = DPT_PATH_SGMII;

    sxd_err = sxd_ioctl(__sxd_handle, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to set CR-Space path to OOB device (dev=%u) (err=%u)\n", dev_params->dev_id, sxd_err);
        return (int)sxd_err;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_EMAD_PATH;
    ctrl_pack.cmd_body = &path_modify;
    path_modify.dev_id = dev_params->dev_id;
    path_modify.path_type = DPT_PATH_SGMII;

    sxd_err = sxd_ioctl(__sxd_handle, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to set MAD path to OOB device (dev=%u) (err=%u)\n", dev_params->dev_id, sxd_err);
        return (int)sxd_err;
    }

    sxd_err = sxd_dpt_path_add(dev_params->dev_id, 0, SYS_PORT_ROUTE_PATH, path_params);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to set EMAD path to OOB device (dev=%u) (err=%u)\n", dev_params->dev_id, sxd_err);
        return (int)sxd_err;
    }

    printf("dev_is_master=%d\n", dev_params->dev_is_master);
    if (dev_params->dev_is_master) {
        struct ku_sgmii_default_dev default_dev = {
            .dev_id = dev_params->dev_id,
            .hopf_on_remote_mgmt = 0
        };

        ctrl_pack.ctrl_cmd = CTRL_CMD_SET_SGMII_DEFAULT_DEV;
        ctrl_pack.cmd_body = &default_dev;
        sxd_err = sxd_ioctl(__sxd_handle, &ctrl_pack);
        if (sxd_err != SXD_STATUS_SUCCESS) {
            printf("Failed to set OOB device (dev=%u) as master (err=%u)\n", dev_params->dev_id, sxd_err);
            return (int)sxd_err;
        }
    }

    sxd_err = __access_mgir(dev_params->dev_id);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to access MGIR register through OOB device (dev=%u) (err=%u).\n", dev_params->dev_id, sxd_err);
        return (int)sxd_err;
    }

    printf("OOB device (dev=%u) was added successfully\n", dev_params->dev_id);
    return 0;
}


int dev_cfg_del(uint8_t dev_id)
{
    struct ku_dpt_path_add path;
    sxd_ctrl_pack_t        ctrl_pack;
    sxd_status_t           sxd_err = SXD_STATUS_SUCCESS;

    init_sxd_layer();

    memset(&path, 0, sizeof(path));

    ctrl_pack.ctrl_cmd = CTRL_CMD_REMOVE_DEV;
    ctrl_pack.cmd_body = &path;
    path.dev_id = dev_id;

    sxd_err = sxd_ioctl(__sxd_handle, &ctrl_pack);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        printf("Failed to delete OOB device (dev=%u) (err=%u)\n", dev_id, sxd_err);
        return (int)sxd_err;
    }

    printf("OOB device (dev=%u) was removed successfully\n", dev_id);
    return 0;
}


void usage(void)
{
    printf("USAGE:\n\n");

    printf("oob_bringup_test_tool sys_cfg <netdev_name> <netdev_mac> <board_number> <cqe_version>\n");
    printf("\tOR\n");
    printf(
        "oob_bringup_test_tool dev_add <dev_id> <dev_mac> <dev_vid> <is_master> <cfg_hopf> <mft_info_version> <mft_info_chip_type> <mft_info_fru_name> <mft_info_fru_modifier>\n");
    printf("\tOR\n");
    printf("oob_bringup_test_tool dev_del <dev_id>\n");

    printf("\n\n");

    printf("parameters\n");
    printf("==========\n");
    printf("\tMAC address in xx:xx:xx:xx:xx:xx format\n");
    printf("\tboard_number ==> 1 - master management board, 2 - slave management board\n");
    printf("\tcqe_version ==> 0 or 2\n");
    printf("\tis_master ==> 0 - no, 1 - yes\n");
    printf("\tcfg_hopf ==> 0 - no, 1 - yes\n");
    printf(
        "\tmft_info_version ==> the version number that will be shown for FORMAT_VERSION in /proc/mlnx-dev/mlnxsw-<dev_id> file\n");
    printf(
        "\tmft_info_chip_type ==> 52000 - SIB, 53000 - SIB2, 54000 - SIB3. The chip type that will be shown for DEVICE_TYPE in /proc/mlnx-dev/mlnxsw-<dev_id> file\n");
    printf(
        "\tmft_info_fru_name ==> free string. The FRU name that will be shown for FRU_NAME in /proc/mlnx-dev/mlnxsw-<dev_id> file\n");
    printf(
        "\tmft_info_fru_modifier ==> free number. The FRU modifier that will be shown for FRU_MODIFIER in /proc/mlnx-dev/mlnxsw-<dev_id> file\n");

    printf("\n\n");
}


enum test_tool_op parse_args(int argc, const char *argv[], struct sys_params *sys_params,
                             struct dev_params *dev_params)
{
    enum test_tool_op op = OP_INVALID;

    if (argc < 2) {
        goto out;
    }

    if ((strcmp(argv[1], "dev_del") == 0) && (argc == 3)) {
        op = OP_DEV_DEL;
        memset(dev_params, 0, sizeof(*dev_params));

        dev_params->dev_id = (uint8_t)atoi(argv[2]);
    } else if ((strcmp(argv[1], "sys_cfg") == 0) && (argc == 6)) {
        op = OP_SYS_CFG;
        memset(sys_params, 0, sizeof(*sys_params));

        strncpy(sys_params->sys_netdev_name, argv[2], sizeof(sys_params->sys_netdev_name) - 1);
        str_to_mac(argv[3], sys_params->sys_netdev_mac);
        sys_params->sys_board_number = atoi(argv[4]);
        sys_params->sys_cqe_ver = atoi(argv[5]);
    } else if ((strcmp(argv[1], "dev_add") == 0) && (argc == 11)) {
        op = OP_DEV_ADD;
        memset(dev_params, 0, sizeof(*dev_params));

        dev_params->dev_id = (uint8_t)atoi(argv[2]);
        str_to_mac(argv[3], dev_params->dev_mac);
        dev_params->dev_vid = atoi(argv[4]);
        dev_params->dev_is_master = !!atoi(argv[5]);
        dev_params->dev_config_hopf = !!atoi(argv[6]);
        dev_params->dev_mft_info.version = (uint16_t)atoi(argv[7]);
        dev_params->dev_mft_info.chip_type = (uint16_t)atoi(argv[8]);
        strncpy(dev_params->dev_mft_info.fru_name, argv[9], (sizeof(dev_params->dev_mft_info.fru_name) - 1));
        dev_params->dev_mft_info.fru_modifier = (uint16_t)atoi(argv[10]);
        dev_params->dev_mft_info.dev_id = dev_params->dev_id;
    }

out:
    return op;
}


int main(int argc, const char *argv[])
{
    struct sys_params sys_params;
    struct dev_params dev_params;
    enum test_tool_op op;

    op = parse_args(argc, argv, &sys_params, &dev_params);
    if (op == OP_INVALID) {
        usage();
        return 1;
    }

    switch (op) {
    case OP_SYS_CFG:
        system_cfg(&sys_params);
        break;

    case OP_DEV_ADD:
        dev_cfg_add(&dev_params);
        break;

    case OP_DEV_DEL:
        dev_cfg_del(dev_params.dev_id);
        break;

    default:
        usage();
        break;
    }

    return 0;
}
