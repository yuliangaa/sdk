-- Define your new protocol
local arn = Proto.new("ARN", "NVIDIA Adaptive Routing Notification Header")

-- Define the fields of your protocol
local version = ProtoField.uint8("arn.version", "Version", base.HEX, nil, 0xF0)
local switch_id = ProtoField.uint16("arn.switch_id", "Switch ID", base.DEC, nil, 0xFFFF)
local next_protocol = ProtoField.uint16("arn.next_protocol", "Next Protocol", base.HEX, nil, 0xFFFF)

-- Add the fields to the protocol
arn.fields = { version, switch_id, next_protocol}

-- Obtain references to the IPv4 and IPv6 dissectors
local ipv4_dissector = Dissector.get("ip")
local ipv6_dissector = Dissector.get("ipv6")

-- Dissector function
function arn.dissector(buffer, pinfo, tree)
    -- Set the protocol column to show our protocol name
    pinfo.cols.protocol = arn.name

    -- Create a subtree for our protocol
    local subtree = tree:add(arn, buffer(), "ARN Protocol Data")
	
	-- Extract the version byte, apply mask and shift
    local version_byte = buffer(0,1):uint()
    local masked_version = bit.band(version_byte, 0xF0)
    local shifted_version = bit.rshift(masked_version, 4)

    -- Add the masked and shifted version to the subtree
    subtree:add(version, buffer(0,1), shifted_version)

	-- Add the other fields to the subtree, parsing them from the buffer
    subtree:add(switch_id, buffer(1, 2))
	subtree:add(next_protocol, buffer(4, 2))
	
	-- Determine the next protocol and call the appropriate dissector
    local next_proto_value = buffer(4, 2):uint()
    local payload_buffer = buffer(8):tvb()

    if next_proto_value == 0x0800 then -- IPv4
        ipv4_dissector:call(payload_buffer, pinfo, tree)
    elseif next_proto_value == 0x86DD then -- IPv6
        ipv6_dissector:call(payload_buffer, pinfo, tree)
    else
		-- Handle other protocols or unknown values
		local expert_info = ExpertInfo.new(PI_MALFORMED, PI_ERROR, "Unknown or unsupported protocol")
		subtree:add_expert_info(expert_info)
		subtree:add(buffer(6), "Payload Data: " .. buffer(6):bytes():tohex())
	end 

end

-- Register the dissector for a specific UDP port
local udp_port = 43987
local udp_dissector_table = DissectorTable.get("udp.port")
udp_dissector_table:add(udp_port, arn)