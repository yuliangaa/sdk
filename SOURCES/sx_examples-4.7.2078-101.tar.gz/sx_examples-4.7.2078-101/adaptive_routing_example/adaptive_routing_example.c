/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sdk/sx_api_vlan.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_adaptive_routing.h>
#include <sx/sdk/sx_api_lag.h>
#include <complib/sx_log.h>


#define DEFAULT_SWID 0
#define INGRESS_VLAN 5
#define EGRESS_VLAN  9

#define IRIF_ETHER_ADDR                      \
    (sx_mac_addr_t) {                        \
        {0x00, 0x99, 0x99, 0x99, 0x99, 0x99} \
    }

#define ERIF_ETHER_ADDR                      \
    (sx_mac_addr_t) {                        \
        {0x00, 0xBB, 0xBB, 0xBB, 0xBB, 0xBB} \
    }

#define NEXT_HOP_ETHER_ADDR                  \
    (sx_mac_addr_t) {                        \
        {0x00, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA} \
    }

#define ROUTE_DIP 0x0A0A0A0A

#define NETWORK_PORT_COUNT (16)
#define LAG_COUNT          (3)
#define PORTS_PER_LAG      (4)

#define EGRESS_PORT_COUNT (NETWORK_PORT_COUNT + LAG_COUNT)

sx_port_log_id_t ingress_log_port = 0x10005;
sx_port_log_id_t network_ports[EGRESS_PORT_COUNT] = {0x10011, 0x10015, 0x10019, 0x1001d,
                                                     0x10021, 0x10025, 0x10029, 0x1002d,
                                                     0x10031, 0x10035, 0x10039, 0x1003d,
                                                     0x10041, 0x10045, 0x10049, 0x1004d};
sx_port_log_id_t lag_ports[LAG_COUNT][PORTS_PER_LAG] = {
    {0x10051, 0x10055, 0x10059, 0x1005d},
    {0x10061, 0x10065, 0x10069, 0x1006d},
    {0x10071, 0x10075, 0x10079, 0x1007d}
};

sx_port_log_id_t egress_log_ports[EGRESS_PORT_COUNT] = {0};

sx_router_interface_t ingress_rif_id = 0;
sx_router_interface_t egress_rif_id[EGRESS_PORT_COUNT] = {0};
sx_port_id_t          vports[EGRESS_PORT_COUNT] = {0};
sx_ecmp_id_t          ecmp_id = 0;

sx_status_t create_router(sx_api_handle_t api_handle)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    sx_router_general_param_t   general_params;
    sx_router_resources_param_t router_resource;
    sx_ar_init_params_t         ar_init_params;
    sx_ar_profile_key_t         profile_key;
    sx_ar_profile_attr_t        profile_attr;


    memset(&general_params, 0, sizeof(general_params));
    memset(&router_resource, 0, sizeof(router_resource));
    memset(&ar_init_params, 0, sizeof(ar_init_params));
    memset(&profile_key, 0, sizeof(profile_key));
    memset(&profile_attr, 0, sizeof(profile_attr));

    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_resource.max_virtual_routers_num = 12;
    router_resource.max_router_interfaces = 400;
    router_resource.min_ipv4_neighbor_entries = 10;
    router_resource.min_ipv6_neighbor_entries = 10;
    router_resource.min_ipv4_uc_route_entries = 10;
    router_resource.min_ipv6_uc_route_entries = 10;
    router_resource.min_ipv4_mc_route_entries = 0;
    router_resource.min_ipv6_mc_route_entries = 0;
    router_resource.max_ipv4_neighbor_entries = 1000;
    router_resource.max_ipv6_neighbor_entries = 1000;
    router_resource.max_ipv4_uc_route_entries = 1000;
    router_resource.max_ipv6_uc_route_entries = 1000;
    router_resource.max_ipv4_mc_route_entries = 0;
    router_resource.max_ipv6_mc_route_entries = 0;

    sx_status = sx_api_router_init_set(api_handle, &general_params, &router_resource);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_init_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_ar_init_set(api_handle, &ar_init_params);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_ar_init_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    profile_key.profile = SX_AR_PROFILE_0_E;
    profile_attr.mode = SX_AR_PROFILE_MODE_RANDOM_E;
    sx_status = sx_api_ar_profile_set(api_handle, SX_ACCESS_CMD_SET, &profile_key, &profile_attr);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_ar_profile_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t create_vrid(sx_api_handle_t api_handle, sx_router_id_t *vrid_p)
{
    sx_status_t            sx_status = SX_STATUS_SUCCESS;
    sx_router_attributes_t router_attr;

    memset(&router_attr, 0, sizeof(router_attr));

    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP;
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP;

    sx_status = sx_api_router_set(api_handle, SX_ACCESS_CMD_ADD, &router_attr, vrid_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}


sx_status_t create_adaptive_routing(sx_api_handle_t api_handle, sx_router_id_t vrid)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    sx_router_interface_param_t ifc_param;
    sx_interface_attributes_t   ifc_attr;
    sx_router_interface_state_t rif_state;
    sx_vlan_ports_t             vlan_port;
    uint32_t                    next_hop_cnt = 0;
    sx_next_hop_t               next_hops[EGRESS_PORT_COUNT];
    sx_ip_addr_t                ip_addr;
    sx_neigh_data_t             neigh_data;
    sx_ip_prefix_t              network_addr;
    sx_uc_route_data_t          uc_route_data;
    sx_ecmp_attributes_t        ecmp_attributes;
    uint32_t                    iii = 0;

    memset(&ifc_param, 0, sizeof(ifc_param));
    memset(&ifc_attr, 0, sizeof(ifc_attr));
    memset(&rif_state, 0, sizeof(rif_state));
    memset(&vlan_port, 0, sizeof(vlan_port));
    memset(&ip_addr, 0, sizeof(ip_addr));
    memset(&neigh_data, 0, sizeof(neigh_data));
    memset(&network_addr, 0, sizeof(network_addr));
    memset(&uc_route_data, 0, sizeof(uc_route_data));
    memset(&next_hops, 0, sizeof(next_hops));
    memset(&ecmp_attributes, 0, sizeof(ecmp_attributes));

    /* The egress port list will have both network ports and LAG ports */
    for (iii = 0; iii < NETWORK_PORT_COUNT; iii++) {
        egress_log_ports[iii] = network_ports[iii];
    }

    /* Create LAG ports each containing 4 ports */
    for (iii = 0; iii < LAG_COUNT; iii++) {
        sx_status = sx_api_lag_port_group_set(api_handle,
                                              SX_ACCESS_CMD_CREATE,
                                              DEFAULT_SWID,
                                              &egress_log_ports[NETWORK_PORT_COUNT + iii],
                                              lag_ports[iii],
                                              PORTS_PER_LAG);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_lag_port_group_set CREATE failed rc: [%s]\n", sx_status_str(sx_status));
            goto out;
        }
    }

    /* Create egress rifs from which the packet will leave the router */
    for (iii = 0; iii < EGRESS_PORT_COUNT; iii++) {
        /* Adaptive routing interfaces are defined using vports.
         * Each of the interfaces belonging to the same ECMP must have a unique physical port.
         */
        vlan_port.is_untagged = SX_TAGGED_MEMBER;
        vlan_port.log_port = egress_log_ports[iii];
        vlan_port.pass_state = SX_PORT_VLAN_BOTH_PASS_E;
        sx_status = sx_api_vlan_ports_set(api_handle, SX_ACCESS_CMD_ADD, DEFAULT_SWID, EGRESS_VLAN, &vlan_port, 1);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_vlan_ports_set ADD failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        sx_status =
            sx_api_port_vport_set(api_handle, SX_ACCESS_CMD_ADD, egress_log_ports[iii], EGRESS_VLAN, &vports[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_port_vport_set ADD failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        /* Create an adaptive routing interface using the created vport */
        ifc_param.type = SX_L2_INTERFACE_TYPE_ADAPTIVE_ROUTING;
        ifc_param.ifc.adaptive_routing.vport = vports[iii];
        ifc_attr.mtu = 1500;
        ifc_attr.mac_addr = ERIF_ETHER_ADDR;
        ifc_attr.mac_addr.ether_addr_octet[5] = iii;
        sx_status = sx_api_router_interface_set(api_handle,
                                                SX_ACCESS_CMD_ADD,
                                                vrid,
                                                &ifc_param,
                                                &ifc_attr,
                                                &egress_rif_id[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_port_vport_set ADD failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        ip_addr.version = SX_IP_VERSION_IPV4;
        ip_addr.addr.ipv4.s_addr = 0x02030002;   /* Random IP address just to resolve the next hop */

        neigh_data.rif = egress_rif_id[iii];
        neigh_data.action = SX_ROUTER_ACTION_FORWARD;
        neigh_data.mac_addr = NEXT_HOP_ETHER_ADDR;
        neigh_data.mac_addr.ether_addr_octet[5] = iii;
        sx_status = sx_api_router_neigh_set(api_handle, SX_ACCESS_CMD_ADD, egress_rif_id[iii], &ip_addr, &neigh_data);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_port_vport_set ADD failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        rif_state.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
        rif_state.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
        rif_state.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
        rif_state.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;

        sx_status = sx_api_router_interface_state_set(api_handle, egress_rif_id[iii], &rif_state);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_router_interface_state_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        /* Create all the next hop that will later be part of the ecmp */
        next_hops[iii].next_hop_key.type = SX_NEXT_HOP_TYPE_IP;
        next_hops[iii].next_hop_key.next_hop_key_entry.ip_next_hop.address.version = SX_IP_VERSION_IPV4;
        next_hops[iii].next_hop_key.next_hop_key_entry.ip_next_hop.address = ip_addr;
        next_hops[iii].next_hop_key.next_hop_key_entry.ip_next_hop.rif = egress_rif_id[iii];
        next_hops[iii].next_hop_data.action = SX_ROUTER_ACTION_FORWARD;
        next_hops[iii].next_hop_data.counter_id = SX_FLOW_COUNTER_ID_INVALID;
        next_hops[iii].next_hop_data.weight = 1;
    }


    /* Create ingress rif from which the packet will enter the router */
    memset(&ifc_param, 0, sizeof(ifc_param));
    memset(&ifc_attr, 0, sizeof(ifc_attr));

    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN;
    ifc_param.ifc.vlan.vlan = INGRESS_VLAN;
    ifc_attr.mac_addr = IRIF_ETHER_ADDR;
    ifc_attr.mtu = 1500;

    sx_status = sx_api_router_interface_set(api_handle,
                                            SX_ACCESS_CMD_ADD,
                                            vrid,
                                            &ifc_param,
                                            &ifc_attr,
                                            &ingress_rif_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_interface_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Enable the rif */
    rif_state.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    rif_state.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    rif_state.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    rif_state.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;

    sx_status = sx_api_router_interface_state_set(api_handle, ingress_rif_id, &rif_state);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_interface_state_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Add the ingress port to the VLAN */
    vlan_port.is_untagged = SX_TAGGED_MEMBER;
    vlan_port.log_port = ingress_log_port;
    sx_status = sx_api_vlan_ports_set(api_handle, SX_ACCESS_CMD_ADD, DEFAULT_SWID, INGRESS_VLAN, &vlan_port, 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_vlan_ports_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create an ECMP that will route our packet to one of the AR next hops */
    next_hop_cnt = 0;
    sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_CREATE, &ecmp_id, next_hops, &next_hop_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_set CREATE failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    ecmp_attributes.ecmp_type = SX_ECMP_TYPE_ADAPTIVE_E;
    ecmp_attributes.container_type = SX_ECMP_CONTAINER_TYPE_IP;
    ecmp_attributes.group_size = 64;
    sx_status = sx_api_router_ecmp_attributes_set(api_handle, ecmp_id, &ecmp_attributes);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_attributes_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    next_hop_cnt = EGRESS_PORT_COUNT;
    sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_SET, &ecmp_id, next_hops, &next_hop_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_set SET failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    network_addr.version = SX_IP_VERSION_IPV4;
    network_addr.prefix.ipv4.addr.s_addr = ROUTE_DIP & 0xffff0000;
    network_addr.prefix.ipv4.mask.s_addr = 0xffff0000;
    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP;
    uc_route_data.next_hop_cnt = 0;
    uc_route_data.uc_route_param.ecmp_id = ecmp_id;

    /* Create a route that will use the ECMP we have created. */
    sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &network_addr, &uc_route_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_uc_route_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t destroy_adaptive_routing(sx_api_handle_t api_handle, sx_router_id_t vrid)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    sx_router_interface_param_t ifc_param;
    sx_interface_attributes_t   ifc_attr;
    sx_router_interface_state_t rif_state;
    sx_vlan_ports_t             vlan_port;
    sx_next_hop_t               next_hop;
    uint32_t                    next_hop_cnt = 0;
    sx_ip_addr_t                ip_addr;
    sx_neigh_data_t             neigh_data;
    sx_ip_prefix_t              network_addr;
    sx_uc_route_data_t          uc_route_data;
    uint32_t                    iii = 0;

    memset(&ifc_param, 0, sizeof(ifc_param));
    memset(&ifc_attr, 0, sizeof(ifc_attr));
    memset(&rif_state, 0, sizeof(rif_state));
    memset(&vlan_port, 0, sizeof(vlan_port));
    memset(&next_hop, 0, sizeof(next_hop));
    memset(&ip_addr, 0, sizeof(ip_addr));
    memset(&neigh_data, 0, sizeof(neigh_data));
    memset(&network_addr, 0, sizeof(network_addr));
    memset(&uc_route_data, 0, sizeof(uc_route_data));

    network_addr.version = SX_IP_VERSION_IPV4;
    network_addr.prefix.ipv4.addr.s_addr = ROUTE_DIP & 0xffff0000;
    network_addr.prefix.ipv4.mask.s_addr = 0xffff0000;
    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP;
    uc_route_data.next_hop_cnt = 0;
    uc_route_data.uc_route_param.ecmp_id = ecmp_id;

    sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, &network_addr, &uc_route_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_uc_route_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_DESTROY, &ecmp_id, &next_hop, &next_hop_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_set DESTROY failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    for (iii = 0; iii < EGRESS_PORT_COUNT; iii++) {
        ip_addr.version = SX_IP_VERSION_IPV4;
        ip_addr.addr.ipv4.s_addr = 0x02030002;   /* Random IP address just to resolve the next hop */

        sx_status = sx_api_router_neigh_set(api_handle, SX_ACCESS_CMD_DELETE, egress_rif_id[iii], &ip_addr, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_port_vport_set DELETE failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        sx_status =
            sx_api_router_interface_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, NULL, NULL, &egress_rif_id[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_router_interface_set DELETE failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        sx_status = sx_api_port_vport_set(api_handle,
                                          SX_ACCESS_CMD_DELETE,
                                          egress_log_ports[iii],
                                          EGRESS_VLAN,
                                          &vports[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_port_vport_set DELETE failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        vlan_port.is_untagged = SX_TAGGED_MEMBER;
        vlan_port.log_port = egress_log_ports[iii];
        sx_status = sx_api_vlan_ports_set(api_handle, SX_ACCESS_CMD_DELETE, DEFAULT_SWID, EGRESS_VLAN, &vlan_port, 1);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_vlan_ports_set ADD failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }
    }

    /* Destroy the LAGS we've created for this purpose */
    for (iii = 0; iii < LAG_COUNT; iii++) {
        sx_status = sx_api_lag_port_group_set(api_handle,
                                              SX_ACCESS_CMD_DELETE,
                                              DEFAULT_SWID,
                                              &egress_log_ports[NETWORK_PORT_COUNT + iii],
                                              lag_ports[iii],
                                              PORTS_PER_LAG);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_lag_port_group_set DELETE failed rc: [%s]\n", sx_status_str(sx_status));
            goto out;
        }
        sx_status = sx_api_lag_port_group_set(api_handle,
                                              SX_ACCESS_CMD_DESTROY,
                                              DEFAULT_SWID,
                                              &egress_log_ports[NETWORK_PORT_COUNT + iii], NULL, 0);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_lag_port_group_set DESTROY failed rc: [%s]\n", sx_status_str(sx_status));
            goto out;
        }
    }

    vlan_port.is_untagged = SX_TAGGED_MEMBER;
    vlan_port.log_port = ingress_log_port;

    sx_status = sx_api_vlan_ports_set(api_handle, SX_ACCESS_CMD_DELETE, DEFAULT_SWID, INGRESS_VLAN, &vlan_port, 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_vlan_ports_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN;
    ifc_param.ifc.vlan.vlan = INGRESS_VLAN;

    sx_status = sx_api_router_interface_set(api_handle,
                                            SX_ACCESS_CMD_DELETE,
                                            vrid,
                                            &ifc_param,
                                            &ifc_attr,
                                            &ingress_rif_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_interface_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}


int main(int argc, char *argv[])
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    sx_api_handle_t api_handle;
    sx_router_id_t  vrid = 0;

    /* Open SDK API */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    sx_status = create_router(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed creating router. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = create_vrid(api_handle, &vrid);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed creating vrid. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Creating an adaptive routing table entry (using ECMP) */
    sx_status = create_adaptive_routing(api_handle, vrid);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed creating adaptive routing. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    char sss[22];

    printf("Enter any character and press enter to check the counter \n");
    scanf("%1s", sss);


    /* From here we REMOVE the configurations we've done so far */
    sx_status = destroy_adaptive_routing(api_handle, vrid);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed destroying adaptive routing. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    /* Delete the router that we have created (vrid) */
    sx_status = sx_api_router_set(api_handle, SX_ACCESS_CMD_DELETE, NULL, &vrid);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_set DELETE failed: [%s] \n", sx_status_str(sx_status));
    }

    sx_status = sx_api_ar_deinit_set(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_ar_deinit_set failed: [%s] \n", sx_status_str(sx_status));
        exit(1);
    }

    /* Deinit the router module */
    sx_status = sx_api_router_deinit_set(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_router_deinit_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    /* Close SDK API */
    sx_status = sx_api_close(&api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    printf("Successfully finished\n");
    return 0;
}
