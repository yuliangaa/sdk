/*
 * Copyright (c) 2023-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_lib_host_ifc.h>
#include <sx/sdk/sx_api_dbg.h>
#include <complib/cl_mem.h>


#define EVENT_SIZE_TO_STR_BUFF_SIZE(SIZE) (SIZE * 16)
#define MAX_NAME_LEN           32
#define EVENT_MONITOR_FILENAME "/tmp/event_monitor.txt"
#define SX_ASSERT(status, msg)                                                                     \
    do {                                                                                           \
        if (SX_CHECK_FAIL(status)) {                                                               \
            printf("assert [%s:%d, %s] - %s\n", __FILE__, __LINE__, SX_STATUS_MSG(status), (msg)); \
            exit(1);                                                                               \
        }                                                                                          \
    } while (0)

static void __sx_hex_dump(char* buff, uint32_t buff_size, const void* ptr, uint32_t len)
{
    char           __buff[LOG_ENTRY_SIZE_MAX];
    const uint8_t *__data = (uint8_t*)(ptr);
    uint32_t       __i = 0, __pos = 0, n = 0;

    if (buff_size < len) {
        return;
    }
    for (__i = 0; __i < len; ++__i) {
        if ((__i % 4) == 0) {
            if (__pos) {
                n = sprintf(buff, "%s\n", __buff);
                buff += n;
                __pos = 0;
            }
            snprintf(__buff + __pos, 9, "0x%04X: ", __i);
            __pos += 8;
        }
        snprintf(__buff + __pos, 4, "%02hhX ", __data[__i]);
        __pos += 3;
    }
    if (__pos) {
        n = sprintf(buff, "%s\n", __buff);
        buff += n;
    }

    buff[0] = '\0';
}

static uint16_t __event_array[] = {
    /* HW/FW EVENTS */
    SXD_TRAP_ID_MECCC,
    SXD_TRAP_ID_FSHE,
    SXD_TRAP_ID_MFDE,
    SXD_TRAP_ID_MOCS_DONE,
    SXD_TRAP_ID_PPCNT,
    SXD_TRAP_ID_MGPCB,
    SXD_TRAP_ID_PBSR,
    SXD_TRAP_ID_SBSRD,
    SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED,
    SXD_TRAP_ID_MAFBI,
    SXD_TRAP_ID_ACCU_FLOW_INC,
    SX_TRAP_ID_PTP_CLOCK_PPS_EVENT,
    SX_TRAP_ID_PUDE,
    SX_TRAP_ID_SDK_HEALTH_EVENT,
    SX_TRAP_ID_PMPE,
    SXD_TRAP_ID_IPAC_DONE,
    SXD_TRAP_ID_FSED,
    SXD_TRAP_ID_MOFRB,
    SXD_TRAP_ID_MOFTD,

    /* SDK EVENTS */
    SX_TRAP_ID_SIGNAL,
    SX_TRAP_ID_NEW_DEVICE_ADD,
    SX_TRAP_ID_NEED_TO_RESOLVE_ARP,
    SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP,
    SX_TRAP_ID_FDB_EVENT,
    SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT,
    SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT,
    SX_TRAP_ID_FDB_SRC_MISS,
    SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY,
    SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT,
    SX_TRAP_ID_ROUTER_MC_ACTIVITY,
    SX_TRAP_ID_FDB_IP_ADDR_ACTIVITY,
    SX_TRAP_ID_TRANSACTION_ERROR,
    SX_TRAP_ID_BFD_TIMEOUT_EVENT,
    SX_TRAP_ID_BFD_PACKET_EVENT,
    SX_TRAP_ID_OBJECT_DELETED_EVENT,
    SX_TRAP_ID_PORT_PROFILE_APPLY_DONE,
    SX_TRAP_ID_API_LOGGER_EVENT,
    SX_TRAP_ID_BULK_COUNTER_DONE_EVENT,
    SX_TRAP_ID_PORT_ADDED,
    SX_TRAP_ID_PORT_DELETED,
    SX_TRAP_ID_PORT_ADDED_TO_LAG,
    SX_TRAP_ID_PORT_REMOVED_FROM_LAG,
    SX_TRAP_ID_BULK_REFRESH_COUNTER_DONE_EVENT,
    SX_TRAP_ID_ACL_ACTIVITY,
    SX_TRAP_ID_SYSFS_SNIFFER,
};

int main(int argc, const char *argv[])
{
    sx_api_handle_t   sx_handle;
    sx_status_t       sx_status;
    sx_user_channel_t uc;
    sx_fd_t           sx_fd;
    /*Max size 12K */
    char            buff[12 * 1024];
    int32_t         buff_size = sizeof(buff);
    FILE           *event_monitor_file_p = NULL;
    char          * str_buff = NULL;
    uint32_t        str_buff_size;
    uint32_t        event_id;
    int             sxd_err = SXD_STATUS_SUCCESS;
    char            trap_str[40];
    uint16_t        trap_id = 0;
    struct ku_read *ku_read_p = NULL;


    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    memset(trap_str, 0, sizeof(trap_str));
    sx_status = sx_api_open(NULL, &sx_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    memset(&sx_fd, 0, sizeof(sx_fd));
    sx_status = sx_api_host_ifc_open(sx_handle, &sx_fd);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_host_ifc_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    memset(&uc, 0, sizeof(uc));
    uc.type = SX_USER_CHANNEL_TYPE_FD;
    memcpy(&uc.channel.fd, &sx_fd, sizeof(uc.channel.fd));

    for (event_id = 0; event_id < sizeof(__event_array) / sizeof(__event_array[0]); event_id++) {
        sx_status = sx_api_host_ifc_trap_id_register_set(sx_handle,
                                                         SX_ACCESS_CMD_REGISTER,
                                                         0,
                                                         __event_array[event_id],
                                                         &uc);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_host_ifc_trap_id_register_set() failed. [%s]\n", sx_status_str(sx_status));
            exit(1);
        }
    }

    event_monitor_file_p = fopen(EVENT_MONITOR_FILENAME, "a+");

    if (NULL == event_monitor_file_p) {
        printf("ERROR: File /tmp/event_monitor.txt with a+ failed to open\n");
        goto out;
    }

    event_id = 0;
    fprintf(event_monitor_file_p, "==============================\n");
    while (1) {
        buff_size = sizeof(buff);

        sxd_err = sxd_recv(sx_fd.driver_handle, buff, &buff_size);

        if (sxd_err < 0) {
            sx_status = sxd_status_to_sx_status(sxd_err);
            printf("ERROR: sxd_recv() failed failed. [%s]\n", sx_status_str(sx_status));
            goto out;
        }
        fprintf(event_monitor_file_p, "=========== Event num %d=========== :\n", event_id + 1);
        event_id++;
        /* since ku_read is the start of the buffer */
        ku_read_p = (struct ku_read *)buff;
        trap_id = ku_read_p->trap_id;

        strncpy(trap_str,  sx_host_ifc_trap_id_str(trap_id), sizeof(trap_str));
        fprintf(event_monitor_file_p, "Event: %s:\n", trap_str);

        buff_size -= sizeof(struct ku_read);

        str_buff_size = EVENT_SIZE_TO_STR_BUFF_SIZE(buff_size);
        str_buff = cl_malloc(str_buff_size);
        if (str_buff == NULL) {
            goto out;
        }

        memset(str_buff, 0, str_buff_size);

        __sx_hex_dump(str_buff, str_buff_size, buff + sizeof(struct ku_read), buff_size);
        fprintf(event_monitor_file_p, "%s\n", str_buff);

        cl_free(str_buff);
        fflush(event_monitor_file_p);
    }

out:
    sx_api_host_ifc_close(sx_handle, &sx_fd);
    sx_api_close(&sx_handle);
    if (NULL != event_monitor_file_p) {
        fflush(event_monitor_file_p);
        fclose(event_monitor_file_p);
    }
    return 0;
}
