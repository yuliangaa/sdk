/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_stateful_db.h>

static sx_stateful_db_key_id_t key_create(const sx_api_handle_t handle, uint8_t *key_size_p)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    sx_stateful_db_key_t    key;
    sx_stateful_db_key_id_t key_id = 0;
    const char            * key_name = "Stateful DB key example";

    memset(&key, 0, sizeof(key));

    strcpy(key.key_name, key_name);
    key.key_desc.acl_key_desc.acl_key_cnt = 1;
    key.key_desc.acl_key_desc.acl_key_list_p[0].key_id = FLEX_ACL_KEY_ETHERTYPE;
    key.key_desc.acl_key_desc.acl_key_list_p[0].mask.ethertype = 0xffff;

    rc = sx_api_stateful_db_key_set(handle, SX_ACCESS_CMD_CREATE, &key, &key_id);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_stateful_db_key_set create failed: [%s].\n", sx_status_str(rc));
        exit(1);
    }

    printf("key ID is %d, key_size is %d.\n", key_id, key.key_size);
    *key_size_p = key.key_size;

    return key_id;
}

static void key_destroy(const sx_api_handle_t handle, sx_stateful_db_key_id_t key_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;


    rc = sx_api_stateful_db_key_set(handle, SX_ACCESS_CMD_DESTROY, NULL, &key_id);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_stateful_db_key_set destroy failed: [%s].\n", sx_status_str(rc));
        exit(1);
    }
}

static void key_dump(const sx_api_handle_t handle, sx_stateful_db_key_id_t key_id)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sx_stateful_db_key_t key;
    uint32_t             i = 0;

    memset(&key, 0, sizeof(key));

    rc = sx_api_stateful_db_key_get(handle, SX_ACCESS_CMD_GET, key_id, &key);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_stateful_db_key_get_set failed: [%s].\n", sx_status_str(rc));
        exit(1);
    }

    printf("Dump for key ID %d\n", key_id);
    printf("Key name: %s\n", key.key_name);
    printf("Key size: %d\n", key.key_size);
    printf("Key type: %d\n", key.key_type);
    for (i = 0; i < key.key_desc.acl_key_desc.acl_key_cnt; i++) {
        printf("[%d] ACL key ID %d\n", i, key.key_desc.acl_key_desc.acl_key_list_p[i].key_id);
    }
}

static void partition_create(const sx_api_handle_t handle, sx_stateful_db_partition_id_e pid, uint8_t key_size)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_stateful_db_partition_cfg_t cfg;
    const char                   * pname = "Stateful DB partition example";

    memset(&cfg, 0, sizeof(cfg));

    cfg.max_size = 100 * key_size;
    cfg.warn_size = cfg.max_size / 2;
    strcpy(cfg.partition_name, pname);

    rc = sx_api_stateful_db_partition_set(handle, SX_ACCESS_CMD_CREATE, pid, &cfg);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_stateful_db_partition_set create failed: [%s].\n", sx_status_str(rc));
        exit(1);
    }
}

static void partition_destroy(const sx_api_handle_t handle, sx_stateful_db_partition_id_e pid)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = sx_api_stateful_db_partition_set(handle, SX_ACCESS_CMD_DESTROY, pid, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_stateful_db_partition_set destroy failed: [%s].\n", sx_status_str(rc));
        exit(1);
    }
}

static void partition_dump(const sx_api_handle_t handle, sx_stateful_db_partition_id_e pid)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_stateful_db_partition_status_t pcfg;

    memset(&pcfg, 0, sizeof(pcfg));

    rc = sx_api_stateful_db_partition_get(handle, SX_ACCESS_CMD_GET, pid, &pcfg);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_stateful_db_partition_get failed: [%s].\n", sx_status_str(rc));
        exit(1);
    }

    printf("###################################\n");
    printf("Dump for partition ID %d\n", pid);
    printf("Partition name: %s\n", pcfg.partition_cfg.partition_name);
    printf("Partition max size: %d\n", pcfg.partition_cfg.max_size);
    printf("Partition warn size: %d\n", pcfg.partition_cfg.warn_size);
    printf("Partition occupancy %d\n", pcfg.num_entries);
    printf("###################################\n");
}

static void entry_set(const sx_api_handle_t         handle,
                      sx_stateful_db_key_id_t       key_id,
                      sx_stateful_db_partition_id_e pid,
                      uint16_t                      ethr,
                      sx_stateful_db_op_e           op_db,
                      sx_stateful_db_semaphore_op_e op_sem,
                      uint64_t                      val)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    sx_stateful_db_sw_access_key_t  key;
    sx_stateful_db_sw_access_data_t data;

    memset(&key, 0, sizeof(key));
    memset(&data, 0, sizeof(data));

    key.db_op = op_db;
    key.sem_op = op_sem;
    key.key_id = key_id;
    key.partition_id = pid;
    key.key_data.acl_data.key_data_list_cnt = 1;
    key.key_data.acl_data.key_data_list_p[0].key_id = FLEX_ACL_KEY_ETHERTYPE;
    key.key_data.acl_data.key_data_list_p[0].key_value.ethertype = ethr;

    if (op_db == SX_STATEFUL_DB_OP_WRITE_E) {
        data.entry_data.db_entry_value = val;
    }

    rc = sx_api_stateful_db_entry_set(handle, SX_ACCESS_CMD_SET, &key, &data);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_stateful_db_entry_set failed: [%s].\n", sx_status_str(rc));
        return;
    }

    printf("###################################\n");
    printf("Entry data:\n");
    printf("Access status\t[%s] [%d]\n", sx_stateful_db_status_str(data.db_op_status), data.db_op_status);
    printf("Entry found?\t[%s] [%d]\n", data.entry_found ? "True" : "False", data.entry_found);
    printf("Data value\t[%" PRIu64 "]\n", data.entry_data.db_entry_value);
    printf("###################################\n");
}

static void entry_meta_get(const sx_api_handle_t         handle,
                           sx_stateful_db_key_id_t       key_id,
                           sx_stateful_db_partition_id_e pid,
                           uint16_t                      ethr)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    sx_stateful_db_sw_access_key_t  key;
    sx_stateful_db_sw_access_data_t data;
    sx_stateful_db_entry_meta_t     meta;

    memset(&key, 0, sizeof(key));
    memset(&data, 0, sizeof(data));
    memset(&meta, 0, sizeof(meta));

    key.key_id = key_id;
    key.partition_id = pid;
    key.key_data.acl_data.key_data_list_cnt = 1;
    key.key_data.acl_data.key_data_list_p[0].key_id = FLEX_ACL_KEY_ETHERTYPE;
    key.key_data.acl_data.key_data_list_p[0].key_value.ethertype = ethr;

    rc = sx_api_stateful_db_entry_meta_get(handle, SX_ACCESS_CMD_GET, &key, &data, &meta);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_stateful_db_entry_meta_get failed: [%s].\n", sx_status_str(rc));
        return;
    }

    printf("###################################\n");
    printf("Entry data:\n");
    printf("Access status\t[%s] [%d]\n", sx_stateful_db_status_str(data.db_op_status), data.db_op_status);
    printf("Entry found?\t[%s] [%d]\n", data.entry_found ? "True" : "False", data.entry_found);
    printf("Data value\t[%" PRIu64 "]\n", data.entry_data.db_entry_value);

    printf("Entry meta:\n");
    printf("Activity\t[%s] [%d]\n", meta.entry_activity ? "True" : "False", meta.entry_activity);
    printf("Semaphore state\t[%s] [%d]\n",
           meta.entry_sem_status == SX_STATEFUL_DB_SEM_LOCK_E ? "Locked" : "Unlocked",
           meta.entry_sem_status);
    printf("Semaphore count\t[%d]\n", meta.entry_sem_cnt);
    printf("###################################\n");
}

static void stateful_init(const sx_api_handle_t handle)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_stateful_db_init_param_t params;

    memset(&params, 0, sizeof(params));
    params.stateful_db_attr.max_sem_retries = 1;
    params.stateful_db_attr.entry_not_found_sem_unlock_failure = 1;

    rc = sx_api_stateful_db_init_set(handle, &params);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_stateful_db_init_set failed: [%s].\n", sx_status_str(rc));
        exit(1);
    }
}

static void stateful_deinit(const sx_api_handle_t handle)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = sx_api_stateful_db_deinit_set(handle);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_stateful_db_deinit_set failed: [%s].\n", sx_status_str(rc));
        exit(1);
    }
}

int main(int argc, char *argv[])
{
    sx_api_handle_t               handle;
    sx_status_t                   rc;
    sx_stateful_db_key_id_t       key_id = 0;
    uint8_t                       key_size = 0;
    sx_stateful_db_partition_id_e pid = 1;

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    /* Open SDK API handle */
    rc = sx_api_open(NULL, &handle);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed: [%s].\n", sx_status_str(rc));
        exit(1);
    }
    printf("SDK API: opened API handle: 0x%" PRIx64 "\n", handle);

    printf("Start example\n");
    stateful_init(handle);
    key_id = key_create(handle, &key_size);
    /* For validation purpose: dump created stateful key. */
    key_dump(handle, key_id);
    partition_create(handle, pid, key_size);
    /* For validation purpose: dump created partition. */
    partition_dump(handle, pid);
    /* For validation purpose: query non exist entry. */
    entry_meta_get(handle, key_id, pid, 0x88cc);
    /* Write new entry to stateful DB. */
    entry_set(handle, key_id, pid, 0x88cc, SX_STATEFUL_DB_OP_WRITE_E, SX_STATEFUL_DB_SEM_NOP_E, 23);
    /* Read new entry from stateful DB. */
    entry_set(handle, key_id, pid, 0x88cc, SX_STATEFUL_DB_OP_READ_E, SX_STATEFUL_DB_SEM_NOP_E, 0);
    /* Dump data and meta data of new created entry */
    entry_meta_get(handle, key_id, pid, 0x88cc);
    /* Dump partition. Partition occupancy should increase by 1. */
    partition_dump(handle, pid);

    /* Remove entry from stateful DB. */
    entry_set(handle, key_id, pid, 0x88cc, SX_STATEFUL_DB_OP_REMOVE_NO_INDICATION_E, SX_STATEFUL_DB_SEM_NOP_E, 0);

    /* For validation purpose: dump data and meta data of removed entry */
    entry_meta_get(handle, key_id, pid, 0x88cc);

    /* For validation purpose: dump partition. Partition occupancy should by 0. */
    partition_dump(handle, pid);

    printf("Cleanup configuration\n");
    partition_destroy(handle, pid);
    key_destroy(handle, key_id);
    stateful_deinit(handle);
    printf("End example\n");

    /* Close SDK API handle */
    rc = sx_api_close(&handle);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_close failed: [%s].\n", sx_status_str(rc));
        exit(1);
    }
    printf("SDK API: closed API handle: 0x%" PRIx64 ".\n", handle);

    return 0;
}
