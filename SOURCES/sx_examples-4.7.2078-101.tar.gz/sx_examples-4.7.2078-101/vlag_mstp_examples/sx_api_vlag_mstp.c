/*
 * SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_lag.h>
#include <sx/sdk/sx_api_bridge.h>
#include <sx/sdk/sx_api_mstp.h>
#include <sx/sdk/sx_api_vlan.h>
#include <sx/sdk/sx_strings.h>

#define SPECTRUM_SWID 0
#define PORT_1        0X10001
#define PORT_2        0x10003
#define PORT_3        0x10021
#define VLAN_1        5
#define VLAN_2        6

/* Virtual port create and delete */
static void vport_add_delete(const sx_api_handle_t  handle,
                             const sx_access_cmd_t  cmd,
                             const sx_port_log_id_t log_port,
                             const sx_vlan_id_t     vlan_id,
                             sx_port_log_id_t      *log_vport_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (cmd == SX_ACCESS_CMD_ADD) {
        printf("--------------- VIRTUAL PORT CREATE FOR PORT AND VLAN ------------------------------\n");
    } else if (cmd == SX_ACCESS_CMD_DELETE) {
        printf("--------------- VIRTUAL PORT DELETE FOR PORT AND VLAN ------------------------------\n");
    } else {
        printf("--------------- Wrong cmd  ------------------------------\n");
        exit(1);
    }

    printf("log port =0x%x\n", log_port);
    printf("vlan id=%d\n", vlan_id);

    rc = sx_api_port_vport_set(handle, cmd, log_port, vlan_id, log_vport_p);
    printf("sx_api_port_vport_set [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }
}

/* Bridge create/delete */
static void bridge_create_delete(const sx_api_handle_t handle,
                                 const sx_access_cmd_t cmd,
                                 sx_bridge_id_t       *bridge_id_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (cmd == SX_ACCESS_CMD_CREATE) {
        printf("--------------- BRIDGE CREATE ------------------------------\n");
    } else if (cmd == SX_ACCESS_CMD_DESTROY) {
        printf("--------------- BRIDGE DELETE ------------------------------\n");
    } else {
        printf("--------------- Wrong cmd  ------------------------------\n");
        exit(1);
    }

    rc = sx_api_bridge_set(handle, cmd, bridge_id_p);
    printf("sx_api_bridge_set [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }
}

/* Add/delete vport to/from bridge */
static void bridge_vport_add_delete(const sx_api_handle_t  handle,
                                    const sx_access_cmd_t  cmd,
                                    const sx_bridge_id_t   bridge_id,
                                    const sx_port_log_id_t log_port)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (cmd == SX_ACCESS_CMD_ADD) {
        printf("--------------- ADD VPORT TO BRIDGE ------------------------------\n");
    } else if (cmd == SX_ACCESS_CMD_DELETE) {
        printf("--------------- DELETE VPORT FROM BRIDGE ------------------------------\n");
    } else {
        printf("--------------- Wrong cmd  ------------------------------\n");
        exit(1);
    }

    rc = sx_api_bridge_vport_set(handle, cmd, bridge_id, log_port);
    printf("sx_api_bridge_vport_set [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }
}

/* LAG create/delete */
static void lag_create_delete(const sx_api_handle_t   handle,
                              const sx_access_cmd_t   cmd,
                              const sx_swid_t         swid,
                              sx_port_log_id_t       *lag_log_port_p,
                              const sx_port_log_id_t *log_port_list_p,
                              const uint32_t          log_port_cnt)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (cmd == SX_ACCESS_CMD_CREATE) {
        printf("--------------- LAG CREATE ------------------------------\n");
    } else if (cmd == SX_ACCESS_CMD_DESTROY) {
        printf("--------------- LAG DELETE ------------------------------\n");
    } else {
        printf("--------------- Wrong cmd  ------------------------------\n");
        exit(1);
    }

    rc = sx_api_lag_port_group_set(handle, cmd, swid, lag_log_port_p, log_port_list_p, log_port_cnt);
    printf("sx_api_lag_port_group_set [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }
}

/* Add/delete LAG member ports */
static void add_delete_lag_ports(const sx_api_handle_t   handle,
                                 const sx_access_cmd_t   cmd,
                                 const sx_swid_t         swid,
                                 sx_port_log_id_t       *lag_log_port_p,
                                 const sx_port_log_id_t *log_port_list_p,
                                 const uint32_t          log_port_cnt)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (cmd == SX_ACCESS_CMD_ADD) {
        printf("--------------- ADD PORTS TO LAG ------------------------------\n");
    } else if (cmd == SX_ACCESS_CMD_DELETE) {
        printf("--------------- DELETE PORTS FROM LAG ------------------------------\n");
    } else {
        printf("--------------- Wrong cmd  ------------------------------\n");
        exit(1);
    }

    rc = sx_api_lag_port_group_set(handle, cmd, swid, lag_log_port_p, log_port_list_p, log_port_cnt);
    printf("sx_api_lag_port_group_set [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }
}

/* Create/delete MSTP instance */
static void create_delete_mstp_instance(const sx_api_handle_t   handle,
                                        const sx_access_cmd_t   cmd,
                                        const sx_swid_t         swid,
                                        const sx_mstp_inst_id_t inst_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (cmd == SX_ACCESS_CMD_ADD) {
        printf("--------------- CREATE MSTP INSTANCE ------------------------------\n");
    } else if (cmd == SX_ACCESS_CMD_DELETE) {
        printf("--------------- DELETE MSTP INSTANCE ------------------------------\n");
    } else {
        printf("--------------- Wrong cmd  ------------------------------\n");
        exit(1);
    }

    rc = sx_api_mstp_inst_set(handle, cmd, swid, inst_id);
    printf("sx_api_mstp_inst_set [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }
}

int main(int argc, char *argv[])
{
    sx_api_handle_t   handle;
    sx_status_t       rc;
    sx_port_log_id_t  lag_id;
    sx_port_log_id_t  port_list[2] = {PORT_1, PORT_2};
    sx_port_log_id_t  vlag;
    sx_port_log_id_t  port_id;
    sx_port_log_id_t  vport;
    sx_bridge_id_t    bridge_id;
    sx_vlan_id_t      vlan_id;
    sx_mstp_inst_id_t inst_id;

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    /* Open SDK API handle */
    rc = sx_api_open(NULL, &handle);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(rc));
        exit(1);
    }
    printf("SDK API: opened API handle: 0x%" PRIx64 "\n", handle);

    /* Create a LAG */
    printf("Create lag\n");
    lag_create_delete(handle, SX_ACCESS_CMD_CREATE, SPECTRUM_SWID, &lag_id, NULL, 0);
    printf("lag 0x%x created\n", lag_id);
    rc = sx_api_vlan_port_ingr_filter_set(handle, lag_id, SX_INGR_FILTER_ENABLE);
    printf("sx_api_vlan_port_ingr_filter_set  [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }

    /* Add 2 ports to the above LAG */
    rc = sx_api_vlan_port_ingr_filter_set(handle, PORT_1, SX_INGR_FILTER_ENABLE);
    printf("sx_api_vlan_port_ingr_filter_set  [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }

    rc = sx_api_vlan_port_ingr_filter_set(handle, PORT_2, SX_INGR_FILTER_ENABLE);
    printf("sx_api_vlan_port_ingr_filter_set  [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }

    printf("Add port 0x%x and 0x%x to lag 0x%x\n", PORT_1, PORT_2, lag_id);
    add_delete_lag_ports(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, &lag_id, port_list, 2);
    printf("Port 0x%x and 0x%x added to lag 0x%x\n", PORT_1, PORT_2, lag_id);

    /* Create vlag with vlan 6 and lag created above */
    printf("Create vlag with lag 0x%x and vlan %d\n", lag_id, VLAN_2);
    vport_add_delete(handle, SX_ACCESS_CMD_ADD, lag_id, VLAN_2, &vlag);
    printf("virtual lag 0x%x created", vlag);

    /* Create vport with vlan 5 and port PORT_3 */
    printf("Create vport with port 0x%x and vlan %d\n", PORT_3, VLAN_1);
    port_id = PORT_3;
    vport_add_delete(handle, SX_ACCESS_CMD_ADD, port_id, VLAN_1, &vport);
    printf("virtual port 0x%x created\n", vport);

    /* Create bridge */
    printf("Bridge create\n");
    bridge_create_delete(handle, SX_ACCESS_CMD_CREATE, &bridge_id);
    printf("Bridge %d created\n", bridge_id);

    /* Add vlag to bridge */
    printf("Add vlag 0x%x to bridge %d\n", vlag, bridge_id);
    bridge_vport_add_delete(handle, SX_ACCESS_CMD_ADD, bridge_id, vlag);
    printf("Vlag 0x%x added to bridge %d\n", vlag, bridge_id);

    /* Add vport to bridge */
    printf("Add vport 0x%x to bridge %d\n", vport, bridge_id);
    bridge_vport_add_delete(handle, SX_ACCESS_CMD_ADD, bridge_id, vport);
    printf("Vport 0x%x added to bridge %d\n", vport, bridge_id);

    /* Change STP mode to MSTP */
    printf("--------------- CHANGE STP MODE TO MSTP ------------------------------\n");
    rc = sx_api_mstp_mode_set(handle, SPECTRUM_SWID, SX_MSTP_MODE_MSTP);
    printf("sx_api_mstp_mode_set [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }
    printf("MSTP mode set to SX_MSTP_MODE_MSTP\n");

    /* Create MSTP instance */
    printf("Create MSTP instance\n");
    inst_id = 2;
    create_delete_mstp_instance(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, inst_id);
    printf("MSTP instance created with instance id %d\n", inst_id);

    /* Add bridge to MSTP instance */
    printf("--------------- ADD BRIDGE TO MSTP INSTANCE ------------------------------\n");
    vlan_id = bridge_id;
    rc = sx_api_mstp_inst_vlan_list_set(handle, SX_ACCESS_CMD_ADD, SPECTRUM_SWID, inst_id, &vlan_id, 1);
    printf("sx_api_mstp_inst_vlan_list_set [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }
    printf("Added bridge %d to mstp instance created above\n", bridge_id);

    /* Bind MSTP instance to LAG */
    printf("Bind mstp %d to lag 0x%x\n", inst_id, lag_id);
    printf("--------------- BIND MSTP TO LAG ------------------------------\n");
    rc = sx_api_mstp_inst_port_state_set(handle,
                                         SPECTRUM_SWID,
                                         inst_id,
                                         lag_id,
                                         SX_MSTP_INST_PORT_STATE_FORWARDING);
    printf("sx_api_mstp_inst_port_state_set [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }
    printf("Bound mstp instance %d to lag 0x%x\n", inst_id, lag_id);

    printf("--------------- Deinit ----------------\n");

    /* Delete bridge from MSTP instance */
    printf("--------------- DELETE BRIDGE FROM MSTP INSTANCE ------------------------------\n");
    vlan_id = bridge_id;
    rc = sx_api_mstp_inst_vlan_list_set(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, inst_id, &vlan_id, 1);
    printf("sx_api_mstp_inst_vlan_list_set [rc=%d]\n", rc);
    if (rc != SX_STATUS_SUCCESS) {
        exit(1);
    }
    printf("Deleted bridge %d from mstp instance %d\n", bridge_id, inst_id);

    /* Delete MSTP instance */
    printf("Delete MSTP instance\n");
    inst_id = 2;
    create_delete_mstp_instance(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, inst_id);
    printf("Deleted MSTP instance id %d\n", inst_id);

    /* Remove vport from bridge */
    printf("Remove vport 0x%x from bridge %d\n", vport, bridge_id);
    bridge_vport_add_delete(handle, SX_ACCESS_CMD_DELETE, bridge_id, vport);
    printf("Removed vport 0x%x from bridge %d\n", vport, bridge_id);

    /* Remove vlag from bridge */
    printf("Remove vlag 0x%x from bridge %d\n", vlag, bridge_id);
    bridge_vport_add_delete(handle, SX_ACCESS_CMD_DELETE, bridge_id, vlag);
    printf("Removed vlag 0x%x from bridge %d\n", vlag, bridge_id);

    /* Delete bridge */
    printf("Delete bridge %d\n", bridge_id);
    bridge_create_delete(handle, SX_ACCESS_CMD_DESTROY, &bridge_id);
    printf("Bridge %d deleted\n", bridge_id);

    /* Delete vport created with vlan 5 and port PORT_3 */
    printf("Delete vport 0x%x\n", vport);
    port_id = PORT_3;
    vport_add_delete(handle, SX_ACCESS_CMD_DELETE, port_id, VLAN_1, &vport);
    printf("virtual port 0x%x deleted\n", vport);


    /* Delete vlag created with vlan 6 and lag created above */
    printf("Delete vlag 0x%x\n", vlag);
    vport_add_delete(handle, SX_ACCESS_CMD_DELETE, lag_id, VLAN_2, &vlag);
    printf("Virtual lag 0x%x deleted\n", vlag);

    /* Delete ports from above LAG */
    printf("Delete port 0x%x and 0x%x from lag 0x%x\n", PORT_1, PORT_2, lag_id);
    add_delete_lag_ports(handle, SX_ACCESS_CMD_DELETE, SPECTRUM_SWID, &lag_id, port_list, 2);
    printf("Port 0x%x and 0x%x deleted from lag 0x%x\n", PORT_1, PORT_2, lag_id);

    /* Delete LAG */
    printf("Delete lag 0x%x\n", lag_id);
    lag_create_delete(handle, SX_ACCESS_CMD_DESTROY, SPECTRUM_SWID, &lag_id, NULL, 0);
    printf("Lag 0x%x deleted\n", lag_id);

    /* Close SDK API handle */
    rc = sx_api_close(&handle);
    if (rc != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_close failed: [%s]\n", sx_status_str(rc));
        exit(1);
    }
    printf("SDK API: closed API handle: 0x%" PRIx64 "\n", handle);

    return 0;
}
