/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <time.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_policer.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_span.h>
#include <sx/sxd/sxd_access_register.h>
#include <resource_manager/resource_manager.h>

#define DEVICE_ID       1
#define SWID            0
#define TIME_DIMENSION  "micro seconds"
#define DEVICE_UID_TEST 200U
#define TEST_PORTS      32
static sx_port_log_id_t ports[TEST_PORTS];
static void get_time(struct timespec *time)
{
    clock_gettime(CLOCK_REALTIME, time);
}

static uint64_t get_time_delta(struct timespec *start, struct timespec *end)
{
    return (end->tv_sec * 1000000 + end->tv_nsec / 1000) - (start->tv_sec * 1000000 + start->tv_nsec / 1000);
}

static void display_time_result(struct timespec *start, struct timespec *end)
{
    uint64_t result = 0;

    result = get_time_delta(start, end);
    printf(" Total time %" PRIu64 " %s.\n", result, TIME_DIMENSION);
}

static sx_status_t __get_chip_type(sx_chip_types_t *chip_type_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mgir_reg mgir_reg;

    memset(&reg_meta, 0, sizeof(reg_meta));
    memset(&mgir_reg, 0, sizeof(mgir_reg));

    if (chip_type_p == NULL) {
        printf("ERROR: chip_type_p is NULL.\n");
        exit(1);
    }

    sxd_status = sxd_access_reg_init(0, NULL, SX_VERBOSITY_LEVEL_INFO);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        printf("ERROR: SXD API sxd_access_reg_init failed: [%s]\n", SXD_STATUS_MSG(sxd_status));
        exit(1);
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.dev_id = 1;
    memset(&mgir_reg, 0, sizeof(struct ku_mgir_reg));

    sxd_status = sxd_access_reg_mgir(&mgir_reg, &reg_meta, 1, NULL, NULL);
    if (sxd_status) {
        printf("%s: failed in get MGIR for dev_id %d, error: %d \n",
               __func__, 1, sxd_status);
    }

    switch (mgir_reg.hw_info.device_id) {
    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
        if (mgir_reg.hw_info.device_hw_revision == 0xA0) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM;
        } else if (mgir_reg.hw_info.device_hw_revision == 0xA1) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM_A1;
        } else {
            printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
            exit(1);
        }
        printf("Device type is: SPECTRUM.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM2;

        printf("Device type is: SPECTRUM2.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM3;

        printf("Device type is: SPECTRUM3.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM4;

        printf("Device type is: SPECTRUM4.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM5;

        printf("Device type is: SPECTRUM5.\n");
        break;

    default:
        printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
        exit(1);
    }

    return status;
}

static void __init_span(sx_api_handle_t handle)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    sx_span_init_params_t init_params;

    init_params.version = SX_SPAN_MIRROR_HEADER_NONE;

    rc = sx_api_span_init_set(handle, &init_params);
    if (rc != SX_STATUS_SUCCESS) {
        printf("\nERROR: SDK API sx_api_span_init_set failed rc: [%s]\n", sx_status_str(rc));
        assert(FALSE);
    }
}

static void __deinit_span(sx_api_handle_t handle)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = sx_api_span_deinit_set(handle);
    if (rc != SX_STATUS_SUCCESS) {
        printf("\nERROR: SDK API sx_api_span_deinit_set failed rc: [%s]\n", sx_status_str(rc));
        assert(FALSE);
    }
}

static sx_span_session_id_t __create_span_session(sx_api_handle_t handle)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t          cmd = SX_ACCESS_CMD_CREATE;
    sx_span_session_id_t     span_session_id = 0;
    sx_span_session_params_t span_session_param;

    memset(&span_session_param, 0, sizeof(sx_span_session_params_t));
    span_session_param.span_type = SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1;
    span_session_param.span_type_format.remote_eth_l2_type1.qos_mode = SX_SPAN_QOS_MAINTAIN;
    span_session_param.span_type_format.remote_eth_l2_type1.switch_prio = 2;
    span_session_param.truncate = FALSE;
    span_session_param.truncate_size = SX_SPAN_TRUNCATE_SIZE_MIN;

    rc = sx_api_span_session_set(handle, cmd, &span_session_param, &span_session_id);
    if (rc != SX_STATUS_SUCCESS) {
        printf("\nERROR: SDK API sx_api_span_session_set(%s) failed rc: [%s]\n", SX_ACCESS_CMD_STR(cmd),
               sx_status_str(rc));
        assert(FALSE);
    }

    return span_session_id;
}

static void __destroy_span_session(sx_api_handle_t handle, sx_span_session_id_t *span_session_id_p)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t          cmd = SX_ACCESS_CMD_DESTROY;
    sx_span_session_params_t span_session_param;

    memset(&span_session_param, 0, sizeof(sx_span_session_params_t));
    rc = sx_api_span_session_set(handle, cmd, &span_session_param, span_session_id_p);
    if (rc != SX_STATUS_SUCCESS) {
        printf("\nERROR: SDK API sx_api_span_session_set(%s) failed rc: [%s]\n", SX_ACCESS_CMD_STR(cmd),
               sx_status_str(rc));
        assert(FALSE);
    }
}

static void __manage_analyzer_port_for_span_session(sx_api_handle_t      handle,
                                                    sx_access_cmd_t      cmd,
                                                    sx_port_log_id_t     log_port,
                                                    sx_span_session_id_t session_id)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_span_analyzer_port_params_t port_params;

    port_params.cng_mng = SX_SPAN_CNG_MNG_DISCARD;

    rc = sx_api_span_analyzer_set(handle, cmd, log_port, &port_params, session_id);
    if (rc != SX_STATUS_SUCCESS) {
        printf("\nERROR: SDK API sx_api_span_analyzer_set(%s) failed rc: [%s]\n", SX_ACCESS_CMD_STR(
                   cmd), sx_status_str(rc));
        assert(FALSE);
    }
}

static void __manage_mirror_port_for_span_session(sx_api_handle_t      handle,
                                                  sx_access_cmd_t      cmd,
                                                  sx_port_log_id_t     mirror_port,
                                                  sx_span_session_id_t session_id)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    sx_mirror_direction_t mirror_direction = SX_SPAN_MIRROR_INGRESS;

    rc = sx_api_span_mirror_set(handle, cmd, mirror_port, mirror_direction, session_id);
    if (rc != SX_STATUS_SUCCESS) {
        printf("\nERROR: SDK API sx_api_span_mirror_set(%s) failed rc: [%s]\n", SX_ACCESS_CMD_STR(cmd),
               sx_status_str(rc));
        assert(FALSE);
    }
}

static void __manage_admin_state_for_span_session(sx_api_handle_t      handle,
                                                  sx_span_session_id_t session_id,
                                                  boolean_t            admin_state)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = sx_api_span_session_state_set(handle, session_id, admin_state);
    if (rc != SX_STATUS_SUCCESS) {
        printf("\nERROR: SDK API sx_api_span_session_state_set(%s) failed rc: [%s]\n",
               (admin_state == TRUE ? "enable" : "disable"), sx_status_str(rc));
        assert(FALSE);
    }
}

static void __manage_span_attributes(sx_api_handle_t handle, sx_access_cmd_t cmd, sx_span_attrs_t      *span_attrs_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;


    if (span_attrs_p == NULL) {
        printf("\nERROR: span_attrs_p is NULL.\n");
        assert(FALSE);
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        span_attrs_p->device_uid = DEVICE_UID_TEST;
        rc = sx_api_span_attributes_set(handle, span_attrs_p);
        if (rc != SX_STATUS_SUCCESS) {
            printf("\nERROR: SDK API sx_api_span_attributes_set failed rc: [%s]\n"
                   , sx_status_str(rc));
            assert(FALSE);
        }
        break;

    case SX_ACCESS_CMD_GET:
        memset(span_attrs_p, 0, sizeof(sx_span_attrs_t));
        rc = sx_api_span_attributes_get(handle, span_attrs_p);
        if (rc != SX_STATUS_SUCCESS) {
            printf("\nERROR: SDK API sx_api_span_attributes_get failed rc: [%s]\n"
                   , sx_status_str(rc));
            assert(FALSE);
        }

        if (span_attrs_p->device_uid != DEVICE_UID_TEST) {
            printf("\nERROR: __manage_span_attributes failed to query the expected value for device_uid rc: [%s]\n"
                   , sx_status_str(rc));
            assert(FALSE);
        }
        break;

    default:
        printf("\nERROR: __manage_span_attributes cmd is unsupported: [%u]\n", cmd);
        assert(FALSE);
    }
}

int main(int argc, char **argv)
{
    sx_api_handle_t       api_handle = 0;
    sx_status_t           status = SX_STATUS_SUCCESS;
    rm_resources_t        resource_limits;
    sx_chip_types_t       chip_type = SX_CHIP_TYPE_UNKNOWN;
    uint32_t              test_case_id = 0, i = 0;
    struct timespec       start_time, end_time;
    sx_span_session_id_t *span_session_id_p = NULL;
    sx_span_session_id_t  span_sessions_num = 0;
    sx_port_attributes_t *port_attr_p = NULL;
    uint32_t              port_cnt = 0, ports_to_set = 0;
    sx_span_attrs_t       span_attrs;

    memset(&start_time, 0, sizeof(start_time));
    memset(&end_time, 0, sizeof(end_time));
    memset(&resource_limits, 0, sizeof(rm_resources_t));
    memset(&span_attrs, 0, sizeof(span_attrs));

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    if (SX_STATUS_SUCCESS != __get_chip_type(&chip_type)) {
        printf("ERROR: Failed to determine the current chip type.\n");
        exit(1);
    }

    /* Open SDK */
    status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(status));
        exit(1);
    }
    printf("SDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);

    status = rm_chip_limits_get(chip_type, &resource_limits);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API rm_chip_limits_get failed: [%s]\n", sx_status_str(status));
        exit(1);
    }

    span_sessions_num = resource_limits.span_session_id_max_external + 1; /* +1 to count 0 Session ID  */

    /* allocate sufficient array to store all SPAN session IDs */
    span_session_id_p = (sx_span_session_id_t*)calloc(span_sessions_num, sizeof(sx_span_session_id_t));
    assert(span_session_id_p);

    /* let's get all (MAX) logical port ant their attributes per current chip */
    status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, NULL, &port_cnt);
    if (status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_port_device_get failed rc: [%s]\n", sx_status_str(status));
        assert(FALSE);
    }

    /* allocate required memory */
    port_attr_p = (sx_port_attributes_t*)calloc(port_cnt, sizeof(sx_port_attributes_t));
    assert(port_attr_p);

    status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, port_attr_p, &port_cnt);
    if (status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_port_device_get failed rc: [%s]\n", sx_status_str(status));
        assert(FALSE);
    }

    /* Make sure that we will not use invalid ports */
    for (i = 0; i < port_cnt && i < TEST_PORTS; i++) {
        if (port_attr_p[i].port_mode == SX_PORT_MODE_EXTERNAL) {
            ports[ports_to_set] = port_attr_p[i].log_port;
            ports_to_set++;
        }
    }

    /*  Initialize SPAN module (optional) */
    printf("\nCase_%u: Initialize SPAN module.\n", ++test_case_id);
    get_time(&start_time);

    __init_span(api_handle);

    /*for SPC4 configure device_uid - TLV 9(24 bits) of the ERSPAN_v2 header meta data*/
    if (chip_type >= SX_CHIP_TYPE_SPECTRUM4) {
        __manage_span_attributes(api_handle, SX_ACCESS_CMD_SET, &span_attrs);
        __manage_span_attributes(api_handle, SX_ACCESS_CMD_GET, &span_attrs);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    /*  Create SPAN sessions */
    printf("\nCase_%u: Create %u SPAN sessions.\n", ++test_case_id, span_sessions_num);
    get_time(&start_time);

    for (i = 0; i < span_sessions_num; i++) {
        span_session_id_p[i] = __create_span_session(api_handle);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    /*  Add analyzer port to SPAN sessions */
    printf("\nCase_%u: Add analyzer port to %u SPAN sessions.\n", ++test_case_id, span_sessions_num);
    get_time(&start_time);

    for (i = 0; i < span_sessions_num; i++) {
        __manage_analyzer_port_for_span_session(api_handle, SX_ACCESS_CMD_ADD, ports[i], span_session_id_p[i]);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    /*  Add mirror port to SPAN sessions */
    printf("\nCase_%u: Add mirror port to %u SPAN sessions.\n", ++test_case_id, span_sessions_num);
    get_time(&start_time);

    for (i = 0; i < span_sessions_num; i++) {
        __manage_mirror_port_for_span_session(api_handle,
                                              SX_ACCESS_CMD_ADD,
                                              ports[span_sessions_num + i],
                                              span_session_id_p[i]);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    /*  Enable admin state for SPAN sessions */
    printf("\nCase_%u: Enable admin state for %u SPAN sessions.\n", ++test_case_id, span_sessions_num);
    get_time(&start_time);

    for (i = 0; i < span_sessions_num; i++) {
        __manage_admin_state_for_span_session(api_handle, span_session_id_p[i], TRUE);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    /*  Remove mirror port to SPAN sessions */
    printf("\nCase_%u: Remove mirror port from %u SPAN sessions.\n", ++test_case_id, span_sessions_num);
    get_time(&start_time);

    for (i = 0; i < span_sessions_num; i++) {
        __manage_mirror_port_for_span_session(api_handle,
                                              SX_ACCESS_CMD_DELETE,
                                              ports[span_sessions_num + i],
                                              span_session_id_p[i]);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);


    /*  Disable admin state for SPAN sessions */
    printf("\nCase_%u: Disable admin state for %u SPAN sessions.\n", ++test_case_id, span_sessions_num);
    get_time(&start_time);

    for (i = 0; i < span_sessions_num; i++) {
        __manage_admin_state_for_span_session(api_handle, span_session_id_p[i], FALSE);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    /*  Remove analyzer port from SPAN sessions */
    printf("\nCase_%u: Remove analyzer port from %u SPAN sessions.\n", ++test_case_id, span_sessions_num);
    get_time(&start_time);

    for (i = 0; i < span_sessions_num; i++) {
        __manage_analyzer_port_for_span_session(api_handle, SX_ACCESS_CMD_DELETE, ports[i], span_session_id_p[i]);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    /*  Destroy SPAN sessions */
    printf("\nCase_%u: Destroy %u SPAN sessions.\n", ++test_case_id, span_sessions_num);
    get_time(&start_time);


    for (i = 0; i < span_sessions_num; i++) {
        __destroy_span_session(api_handle, &span_session_id_p[i]);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    printf("\nCase_%u: Disable SPAN module.\n", ++test_case_id);
    get_time(&start_time);

    __deinit_span(api_handle);

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    /* release used memory */
    free(span_session_id_p);

    printf("\nTest is finished.\n\n");

    return 0;
}
