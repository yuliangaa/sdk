local MLNX_ERSPAN_ETHER_TYPE = 0x8949
------- ERSPAN dissector
local mlnx_erspan = Proto.new ("MSERSPAN", "NVIDIA ERSPAN Mirror Header" )

local raw_opcode = {
	[0] = "Mirroring version 0",
	[1] = "Mirroring version 1",
	[2] = "Mirroring version 2"
}

local packet_type = {
	[1] = "MAC"
}

mlnx_erspan.fields = {}
local ersflds = mlnx_erspan.fields

ersflds.ingress_label_port = ProtoField.new("Ingress Label Port", "mlnx_erspan.ingress_label_port", ftypes.UINT16, nil, base.DEC,"0xFFF0")
ersflds.raw_opcode = ProtoField.new("raw_opcode", "mlnx_erspan.raw_opcode",ftypes.UINT8,raw_opcode,base.DEC)
ersflds.pad_count  = ProtoField.new("pad_count", "mlnx_erspan.pad_count",ftypes.UINT8,nil,base.DEC)
ersflds.flags = ProtoField.new("flags", "mlnx_erspan.flags",ftypes.UINT8,nil,base.HEX)
ersflds.packet_type = ProtoField.new("packet_type", "mlnx_erspan.packet_type",ftypes.UINT8, packet_type,base.DEC,"0xC0")
ersflds.timestamp = ProtoField.absolute_time("mlnx_erspan.timestamp", "Timestamp", base.UTC)
ersflds.original_packet_size = ProtoField.new ("original_packet_size","mlnx_erspan.original_packet_size",ftypes.UINT16,nil,base.DEC)
ersflds.egress_label_port = ProtoField.new ("egress_label_port", "mlnx_erspan.egress_label_port",ftypes.UINT16,nil,base.DEC)
ersflds.psn = ProtoField.new ("psn","mlnx_erspan.psn",ftypes.UINT16,nil,base.DEC)
ersflds.lag = ProtoField.new ("lag","mlnx_erspan.lag",ftypes.UINT8,nil,base.DEC,"0x80")
ersflds.ts = ProtoField.new ("ts","mlnx_erspan.ts",ftypes.UINT16,nil,base.DEC,"0x8000")
ersflds.padding = ProtoField.new ("padding","mlnx_erspan.padding",ftypes.UINT8,nil,base.HEX)

-- flags
ersflds.ts_valid = ProtoField.new ("ts_valid","mlnx_erspan.ts_valid",ftypes.UINT8,nil,base.DEC,"0x80")
ersflds.orig_packet_trunc = ProtoField.new ("orig_packet_truc","mlnx_erspan.original_packet_truncated",ftypes.UINT8,nil,base.DEC,"0x40")
ersflds.orig_packet_size_valid = ProtoField.new ("orig_packet_size_valid","mlnx_erspan.original_packet_size_valid",ftypes.UINT8,nil,base.DEC,"0x20")
ersflds.egress_label_port_valid = ProtoField.new ("egress_label_port_valid","mlnx_erspan.egress_label_port_valid",ftypes.UINT8,nil,base.DEC,"0x10")
ersflds.psn_valid = ProtoField.new ("psn_valid","mlnx_erspan.psn_valid",ftypes.UINT8,nil,base.DEC,"0x08")
ersflds.ingress_label_port_lag = ProtoField.new ("ingress_label_port_lag","mlnx_erspan.ingress_label_port_lag",ftypes.UINT8,nil,base.DEC,"0x04")
ersflds.egress_label_port_lag = ProtoField.new ("egress_label_port_lag","mlnx_erspan.egress_label_port_lag",ftypes.UINT8,nil,base.DEC,"0x02")
ersflds.ingress_label_port_valid = ProtoField.new ("ingress_label_port_valid","mlnx_erspan.ingress_label_port_valid",ftypes.UINT8,nil,base.DEC,"0x01")

-- tlvs
ersflds.ing_buff_occupancy = ProtoField.new ("ing_buff_occupancy","mlnx_erspan.ing_buff_occupancy",ftypes.UINT24,nil,base.DEC)
ersflds.egr_buff_occupancy = ProtoField.new ("egr_buff_occupancy","mlnx_erspan.egr_buff_occupancy",ftypes.UINT24,nil,base.DEC)
ersflds.latency = ProtoField.new ("latency","mlnx_erspan.latency",ftypes.UINT24,nil,base.DEC)
ersflds.flags_ext = ProtoField.new ("flages_ext","mlnx_erspan.flags_ext",ftypes.UINT24,nil,base.DEC)
ersflds.mirror_reason = ProtoField.new ("mirror_reason","mlnx_erspan.mirror_reason",ftypes.UINT8,nil,base.DEC)
ersflds.tcalss = ProtoField.new ("tcalss","mlnx_erspan.tcalss",ftypes.UINT8,nil,base.DEC)
ersflds.mirror_agent = ProtoField.new ("mirror_agent","mlnx_erspan.mirror_agent",ftypes.UINT8,nil,base.DEC)
ersflds.pg = ProtoField.new ("pg","mlnx_erspan.pg",ftypes.UINT8,nil,base.DEC)
ersflds.mirror_reason_ext = ProtoField.new ("mirror_reason_ext","mlnx_erspan.mirror_reason_ext",ftypes.UINT24,nil,base.DEC)
ersflds.device_uid = ProtoField.new ("device_uid","mlnx_erspan.device_uid",ftypes.UINT24,nil,base.DEC)

function mlnx_erspan.dissector(tvbuf, pktinfo, root)

	-- check header type and size 
	local hdr_version = bit.band(tvbuf(2,1):uint(),0x7f)
	local nxt_offset = 0
	local tlv_offset = 0
	local usec =0
	local nsec =0
	local sec = 0
	local nstime =0
	local length =0
	local t_erspan = 0
        local pad_count = tvbuf(3,1):uint()
	
	if hdr_version == 0 then
		t_erspan = root: add(mlnx_erspan,tvbuf:range(0,12))
		nxt_offset = 13
			
		t_erspan:add(ersflds.ingress_label_port, tvbuf(0,2))
		t_erspan:add(ersflds.lag,tvbuf(2,1))
		t_erspan:add(ersflds.pad_count,tvbuf(3,1))
		t_erspan:add(ersflds.ts,tvbuf(4,2))
		usecs = tvbuf(6,8): uint64()
		secs = (usecs / (2^30)):tonumber()
		nsecs = (usecs % (2^30)):tonumber()
		nstime = NSTime.new(secs,nsecs)
		
		t_erspan:add(ersflds.timestamp, tvbuf(6,8), nstime)	
	end
	
	if  hdr_version == 1 or hdr_version == 2 then
		nxt_offset = 22 + pad_count

		-- add tlv size - to highlight the whole header
		if hdr_version == 2 then
			local tlv_value = 0
			local tlv_last = 0
			local tlv_type  = 0  
			
		  	repeat
				tlv_value = tvbuf(nxt_offset+tlv_offset,1 ):uint()
				tlv_last = bit.band(tlv_value,0x80)
				tlv_type = bit.band(tlv_value,0x7f)
				if tlv_type >= 0 and tlv_type < 4 then
					tlv_offset = tlv_offset + 4
				end 
				if tlv_type >= 4 and tlv_type < 8 then
					tlv_offset =tlv_offset + 2
				end
				if tlv_type >= 8 and tlv_type < 10 then
					tlv_offset =tlv_offset + 4
				end
			until (tlv_last ~= 0 )	
		end

		t_erspan = root: add(mlnx_erspan,tvbuf:range(0, nxt_offset + tlv_offset))		

		t_erspan:add(ersflds.ingress_label_port, tvbuf(0,2))
		t_erspan:add(ersflds.raw_opcode,tvbuf(2,1))
		t_erspan:add(ersflds.pad_count,tvbuf(3,1))
		t_erspan:add(ersflds.flags,tvbuf(4,1))
		-- flags deftails
		t_erspan:add(ersflds.ts_valid,tvbuf(4,1))
		t_erspan:add(ersflds.orig_packet_trunc,tvbuf(4,1))
		t_erspan:add(ersflds.orig_packet_size_valid,tvbuf(4,1))
		t_erspan:add(ersflds.egress_label_port_valid,tvbuf(4,1))
		t_erspan:add(ersflds.psn_valid,tvbuf(4,1))
		t_erspan:add(ersflds.ingress_label_port_lag,tvbuf(4,1))
		t_erspan:add(ersflds.egress_label_port_lag,tvbuf(4,1))
		t_erspan:add(ersflds.ingress_label_port_valid,tvbuf(4,1))
		--
		t_erspan:add(ersflds.packet_type,tvbuf(5,1))

		--although 10B in HW only 8B
		usecs = tvbuf(8,8): uint64()
		secs = (usecs / (2^30)):tonumber()
		nsecs = (usecs % (2^30)):tonumber()
		nstime = NSTime.new(secs,nsecs)
		
		t_erspan:add(ersflds.timestamp,tvbuf(6,10), nstime)
		
		t_erspan:add(ersflds.original_packet_size,tvbuf(16,2))
		t_erspan:add(ersflds.egress_label_port,tvbuf(18,2))
		t_erspan:add(ersflds.psn,tvbuf(20,2))
        
		-- padding field is optional and depends on 'pad_count' field
		if pad_count > 0 then
			t_erspan:add(ersflds.padding,tvbuf(22,pad_count))
		end
	end

	if hdr_version == 2 then
	
		local tlv_value = 0
		local tlv_last = 0
		local tlv_type  = 0
		tlv_offset = 0
		
		repeat
			tlv_value = tvbuf(nxt_offset+tlv_offset,1 ):uint()
			tlv_last = bit.band(tlv_value,0x80)
			tlv_type = bit.band(tlv_value,0x7f)
			
			if tlv_type == 0 then
				t_erspan:add(ersflds.ing_buff_occupancy,tvbuf(nxt_offset+tlv_offset+1,3))
				tlv_offset=tlv_offset+4
			end
			if tlv_type == 1 then
				t_erspan:add(ersflds.egr_buff_occupancy,tvbuf(nxt_offset+tlv_offset+1,3))
				tlv_offset=tlv_offset+4
			end
			if tlv_type == 2 then
				t_erspan:add(ersflds.latency,tvbuf(nxt_offset+tlv_offset+1,3))
				tlv_offset=tlv_offset+4
			end
			if tlv_type == 3 then
				t_erspan:add(ersflds.flags_ext,tvbuf(nxt_offset+tlv_offset+1,3))
				tlv_offset=tlv_offset+4
			end
			if tlv_type == 4 then
				t_erspan:add(ersflds.mirror_reason,tvbuf(nxt_offset+tlv_offset+1,1))
				tlv_offset=tlv_offset+2
			end
			if tlv_type == 5 then
				t_erspan:add(ersflds.tcalss,tvbuf(nxt_offset+tlv_offset+1,1))
				tlv_offset=tlv_offset+2
			end
			if tlv_type == 6 then 
				t_erspan:add(ersflds.mirror_agent,tvbuf(nxt_offset+tlv_offset+1,1))
				tlv_offset=tlv_offset+2	
			end
			if tlv_type == 7 then 
				t_erspan:add(ersflds.pg,tvbuf(nxt_offset+tlv_offset+1,1))
				tlv_offset=tlv_offset+2	
			end
			if tlv_type == 8 then 
				t_erspan:add(ersflds.mirror_reason_ext,tvbuf(nxt_offset+tlv_offset+1, 3))
				tlv_offset=tlv_offset + 4   
			end
			if tlv_type == 9 then 
				t_erspan:add(ersflds.device_uid,tvbuf(nxt_offset+tlv_offset+1, 3))
				tlv_offset=tlv_offset + 4   
			end

		until (tlv_last ~= 0)	

	end

	nxt_offset = nxt_offset + tlv_offset
	return Dissector.get('eth_withoutfcs'):call(tvbuf(nxt_offset):tvb(), pktinfo, root)

end

gre_table=DissectorTable.get("gre.proto")
gre_table:add(MLNX_ERSPAN_ETHER_TYPE, mlnx_erspan)
DissectorTable.get("ethertype"):add(MLNX_ERSPAN_ETHER_TYPE, mlnx_erspan)
