local mlnx_span = Proto.new("MSPAN", "NVIDIA SPAN Mirror Header")
local MLNX_SPAN_ETHER_TYPE = 0x8949

mlnx_span.fields = {}
local fds = mlnx_span.fields
fds.ingress_label_port = ProtoField.new("Label Port", "mlnx_span.label_port", ftypes.UINT16, nil, base.DEC,"0xFFF0")
fds.ingress_label_port_split = ProtoField.new("Label Port Split", "mlnx_span.label_port_split", ftypes.UINT8, nil, base.DEC,"0x0F")
fds.has_timestamp = ProtoField.new("Has Timestamp", "mlnx_span.has_timestamp", ftypes.UINT8, {[1]="Yes",[0]="No"}, base.DEC, "0x80")
fds.timestamp = ProtoField.absolute_time("mlnx_span.timestamp", "Timestamp", base.UTC)


function mlnx_span.dissector(tvbuf, pktinfo, root)

	-- Dissector.get('eth_withoutfcs'):call(tvbuf(12):tvb(), pktinfo, root)

	local tree = root:add(mlnx_span, tvbuf:range(0, 14))	
	tree:add(fds.ingress_label_port, tvbuf(0, 2))
	tree:add(fds.ingress_label_port_split, tvbuf(1, 1))
	tree:add(fds.has_timestamp, tvbuf(4, 1))
    local usecs = tvbuf(6,8):uint64()
	local secs  = (usecs / (2^30)):tonumber()
	local nsecs = (usecs % (2^30)):tonumber()
	local nstime = NSTime.new(secs, nsecs)
	tree:add(fds.timestamp, tvbuf(6,8), nstime)	
	--tree:add(fds.timestamp, tvbuf(6, 8))
	
	return Dissector.get('eth_withoutfcs'):call(tvbuf(14):tvb(), pktinfo, root)
	
end

DissectorTable.get("ethertype"):add(MLNX_SPAN_ETHER_TYPE, mlnx_span)
