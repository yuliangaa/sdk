/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sys/time.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sxd/sxd_access_register.h>
#include <resource_manager/resource_manager.h>

struct timeval start_time, end_time;

#define MEASURE_TIME(val) gettimeofday(val, NULL)
#define TIME_DIMENSION "micro seconds"
#define DISPLAY_RESULTS(start_time, end_time)                                                                           \
    printf("Total time: %u %s \n",                                                                                      \
           (unsigned int)(((end_time.tv_sec - start_time.tv_sec) * 1000000) + (end_time.tv_usec - start_time.tv_usec)), \
           TIME_DIMENSION);

#define SWID      0
#define DEVICE_ID 1

static sx_status_t __get_chip_type(sx_chip_types_t *chip_type_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mgir_reg mgir_reg;

    memset(&reg_meta, 0, sizeof(reg_meta));
    memset(&mgir_reg, 0, sizeof(mgir_reg));

    if (chip_type_p == NULL) {
        printf("ERROR: chip_type_p is NULL.\n");
        exit(1);
    }

    sxd_status = sxd_access_reg_init(0, NULL, SX_VERBOSITY_LEVEL_INFO);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        printf("ERROR: SXD API sxd_access_reg_init failed: [%s]\n", SXD_STATUS_MSG(sxd_status));
        exit(1);
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.dev_id = 1;
    memset(&mgir_reg, 0, sizeof(struct ku_mgir_reg));

    sxd_status = sxd_access_reg_mgir(&mgir_reg, &reg_meta, 1, NULL, NULL);
    if (sxd_status) {
        printf("%s: failed in get MGIR for dev_id %d, error: %d \n",
               __func__, 1, sxd_status);
    }

    switch (mgir_reg.hw_info.device_id) {
    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
        if (mgir_reg.hw_info.device_hw_revision == 0xA0) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM;
        } else if (mgir_reg.hw_info.device_hw_revision == 0xA1) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM_A1;
        } else {
            printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
            exit(1);
        }
        printf("Device type is: SPECTRUM.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM2;

        printf("Device type is: SPECTRUM2.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM3;

        printf("Device type is: SPECTRUM3.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM4;

        printf("Device type is: SPECTRUM4.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM5;

        printf("Device type is: SPECTRUM5.\n");
        break;

    default:
        printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
        exit(1);
    }

    return status;
}

static void __get_port_speed(sx_api_handle_t             handle,
                             sx_port_log_id_t            log_port,
                             sx_port_mode_t              port_mode,
                             sx_port_speed_capability_t *port_speed)
{
    sx_status_t          status = SX_STATUS_SUCCESS;
    sx_port_oper_speed_t oper_speed = SX_PORT_SPEED_NA;

    /* make sure that we are calling suitable port */
    if (port_mode == SX_PORT_MODE_EXTERNAL) {
        status = sx_api_port_speed_get(handle, log_port, port_speed, &oper_speed);
        if (status != SX_STATUS_SUCCESS) {
            printf("%s ERROR: SDK API sx_api_port_speed_get failed: [%s]\n", __func__, sx_status_str(status));
            assert(FALSE); /* stop execution */
        }
    }
}

static void __set_port_speed(sx_api_handle_t             handle,
                             sx_port_log_id_t            log_port,
                             sx_port_mode_t              port_mode,
                             sx_port_speed_capability_t *port_speed)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    /* make sure that we are calling suitable port */
    if (port_mode == SX_PORT_MODE_EXTERNAL) {
        /* shut down port */
        status = sx_api_port_state_set(handle, log_port, SX_PORT_ADMIN_STATUS_DOWN);
        if (status != SX_STATUS_SUCCESS) {
            printf("%s ERROR: SDK API sx_api_port_state_set failed: [%s]\n", __func__, sx_status_str(status));
            assert(FALSE); /* stop execution */
        }

        /* set new speed */
        status = sx_api_port_speed_admin_set(handle, log_port, port_speed);
        if (status != SX_STATUS_SUCCESS) {
            printf("%s ERROR: SDK API sx_api_port_state_set failed: [%s]\n", __func__, sx_status_str(status));
            assert(FALSE); /* stop execution */
        }

        /* bring port up */
        status = sx_api_port_state_set(handle, log_port, SX_PORT_ADMIN_STATUS_UP);
        if (status != SX_STATUS_SUCCESS) {
            printf("%s ERROR: SDK API sx_api_port_state_set failed: [%s]\n", __func__, sx_status_str(status));
            assert(FALSE); /* stop execution */
        }
    }
}

static void __get_port_mtu(sx_api_handle_t handle, sx_port_log_id_t log_port, sx_port_mode_t port_mode)
{
    sx_status_t   status = SX_STATUS_SUCCESS;
    sx_port_mtu_t mtu_size = 0;
    sx_port_mtu_t oper_mtu_size = 0;

    /* make sure that we are calling suitable port */
    if (port_mode == SX_PORT_MODE_EXTERNAL) {
        status = sx_api_port_mtu_get(handle, log_port, &mtu_size, &oper_mtu_size);
        if (status != SX_STATUS_SUCCESS) {
            printf("%s ERROR: SDK API sx_api_port_mtu_get failed: [%s]\n", __func__, sx_status_str(status));
            assert(FALSE); /* stop execution */
        }
    }
}

static void __get_port_state(sx_api_handle_t handle, sx_port_log_id_t log_port, sx_port_mode_t port_mode)
{
    sx_status_t            status = SX_STATUS_SUCCESS;
    sx_port_oper_state_t   oper_state = SX_PORT_OPER_STATUS_NONE;
    sx_port_admin_state_t  admin_state = SX_PORT_ADMIN_STATUS_NONE;
    sx_port_module_state_t module_state = SX_PORT_MODULE_STATUS_INITIALIZING;

    /* make sure that we are calling suitable port */
    if (port_mode == SX_PORT_MODE_EXTERNAL) {
        status = sx_api_port_state_get(handle, log_port, &oper_state, &admin_state, &module_state);
        if (status != SX_STATUS_SUCCESS) {
            printf("%s ERROR: SDK API sx_api_port_mtu_get failed: [%s]\n", __func__, sx_status_str(status));
            assert(FALSE); /* stop execution */
        }
    }
}

int main(int argc, char **argv)
{
    sx_api_handle_t             api_handle = 0;
    sx_status_t                 status = SX_STATUS_SUCCESS;
    rm_resources_t              resource_limits;
    sx_chip_types_t             chip_type = SX_CHIP_TYPE_UNKNOWN;
    sx_port_attributes_t       *port_attr_p = NULL;
    sx_port_speed_capability_t *port_speed_p = NULL, admin_speed;
    uint32_t                    i = 0, port_cnt = 0;
    uint8_t                     case_num = 0;

    memset(&admin_speed, 0, sizeof(admin_speed));
    memset(&resource_limits, 0, sizeof(resource_limits));

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    if (SX_STATUS_SUCCESS != __get_chip_type(&chip_type)) {
        printf("ERROR: Failed to determine the current chip type.\n");
        exit(1);
    }

    /* Open SDK */
    status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(status));
        exit(1);
    }
    printf("SDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);

    status = rm_chip_limits_get(chip_type, &resource_limits);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API rm_chip_limits_get failed: [%s]\n", sx_status_str(status));
        exit(1);
    }

    /* Get number of ports on the current chip and their attributes */
    status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, NULL, &port_cnt);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_port_device_get failed: [%s].\n", sx_status_str(status));
        exit(1);
    }

    printf("\nCurrent chip has %u system ports.\n", port_cnt);

    port_attr_p = (sx_port_attributes_t*)calloc(port_cnt, sizeof(sx_port_attributes_t));
    if (port_attr_p == NULL) {
        printf("ERROR: failed to allocated memory for port attributes.\n");
        exit(1);
    }

    status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, port_attr_p, &port_cnt);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_port_device_get failed: [%s] on retrieving attributes.\n",
               sx_status_str(status));
        exit(1);
    }

    port_speed_p = (sx_port_speed_capability_t*)calloc(port_cnt, sizeof(sx_port_speed_capability_t));

    /*
     *  Measure how much time will take getting speed values
     */
    printf("\nCase_%u. Measure how much time will take getting speed values for %u ports.\n", ++case_num, port_cnt);
    MEASURE_TIME(&start_time);
    for (i = 0; i < port_cnt; i++) {
        __get_port_speed(api_handle, port_attr_p[i].log_port, port_attr_p[i].port_mode, &port_speed_p[i]);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Measure how much time will take setting speed values to 10G
     */
    printf("\nCase_%u. Measure how much time will take setting speed values for %u ports to 10G.\n",
           ++case_num,
           port_cnt);

    memset(&admin_speed, 0, sizeof(admin_speed));
    admin_speed.mode_10GB_CR = TRUE;
    admin_speed.mode_10GB_CX4_XAUI = TRUE;
    admin_speed.mode_10GB_SR = TRUE;
    admin_speed.mode_10GB_KR = TRUE;
    admin_speed.mode_10GB_ER_LR = TRUE;

    MEASURE_TIME(&start_time);
    for (i = 0; i < port_cnt; i++) {
        __set_port_speed(api_handle, port_attr_p[i].log_port, port_attr_p[i].port_mode, &admin_speed);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Measure how much time will take setting speed values to 100G
     */
    printf("\nCase_%u. Measure how much time will take setting speed values for %u ports to 100G.\n",
           ++case_num,
           port_cnt);

    memset(&admin_speed, 0, sizeof(admin_speed));
    admin_speed.mode_100GB_CR4 = TRUE;
    admin_speed.mode_100GB_SR4 = TRUE;
    admin_speed.mode_100GB_KR4 = TRUE;
    admin_speed.mode_100GB_LR4_ER4 = TRUE;

    MEASURE_TIME(&start_time);
    for (i = 0; i < port_cnt; i++) {
        __set_port_speed(api_handle, port_attr_p[i].log_port, port_attr_p[i].port_mode, &admin_speed);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Measure how much time will take setting speed values to default
     */
    printf("\nCase_%u. Measure how much time will take restoring speed values to default for %u ports.\n",
           ++case_num,
           port_cnt);
    MEASURE_TIME(&start_time);
    for (i = 0; i < port_cnt; i++) {
        __set_port_speed(api_handle, port_attr_p[i].log_port, port_attr_p[i].port_mode, &port_speed_p[i]);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Measure how much time will take getting MTU values for all ports
     */
    printf("\nCase_%u. Measure how much time will take getting MTU values for all %u ports.\n", ++case_num, port_cnt);
    MEASURE_TIME(&start_time);
    for (i = 0; i < port_cnt; i++) {
        __get_port_mtu(api_handle, port_attr_p[i].log_port, port_attr_p[i].port_mode);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Measure how much time will take getting port state for all ports
     */
    printf("\nCase_%u. Measure how much time will take getting port state values for all %u ports.\n",
           ++case_num,
           port_cnt);
    MEASURE_TIME(&start_time);
    for (i = 0; i < port_cnt; i++) {
        __get_port_state(api_handle, port_attr_p[i].log_port, port_attr_p[i].port_mode);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    free(port_speed_p);
    free(port_attr_p);

    printf("\nTest is finished.\n");

    return 0;
}
