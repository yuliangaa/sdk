/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "utils.h"

#undef  __MODULE__
#define __MODULE__ EVB_UTILS

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_INFO;

/************************************************
 *  MEMORY
 ***********************************************/
static uint32_t    evb_mem_type_count[UTILS_MEM_TYPE_ID_MAX + 1] = { 0 };
static const char *evb_mem_type_name[] = { "ALL", "EVB_MANAGER",
/* Please keep the following name last... */
                                           "TEMP MEMORY" };
static const char *evb_status2str_arr[] = {
/* EVB_STATUS_SUCCESS = 0 */
    "Success",

/* EVB_STATUS_ERROR = 1 */
    "Internal Error",

/* EVB_STATUS_NO_RESOURCES = 2 */
    "No More Resources",

/* SX_STATUS_INVALID_HANDLE = 3 */
    "Invalid Handle",

/* EVB_STATUS_NO_MEMORY = 4 */
    "No More Memory",

/* EVB_STATUS_MEMORY_ERROR = 5 */
    "Memory Error",

/* EVB_STATUS_PARAM_ERROR = 6 */
    "Parameter Error",

/* EVB_STATUS_PARSE_ERROR = 7 */
    "parse error",

/* EVB_STATUS_PARSE_ERROR = 8 */
    "SDK error",

/* SX_STATUS_PARAM_EXCEEDS_RANGE = 9 */
    "Parameter Exceeds Range"
};

/**
 * This function allocate memory
 *
 * @param[out] buf_p        - pointer to a buffer pointer
 * @param[in]  buf_size     - size of memory to allocate (in bytes)
 * @param[in]  mem_type_id  - memory type id - ascribe memory allocation for this memory type
 */
evb_status_t evb_utils_memory_get(void **buf_p, length_t buf_size, utils_mem_type_id_t mem_type_id)
{
    evb_status_t rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!M_EVB_UTILS_MEM_TYPE_ID_CHECK_RANGE(mem_type_id)) {
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_PARAM_EXCEED_RANGE);
    }

    /* O/W: */
    rc = evb_utils_check_pointer(buf_p, "Buffer pointer");
    if (EVB_CHECK_FAIL(rc)) {
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_PARAM_NULL);
    }
    /* O/W: */
    *buf_p = malloc(sizeof(length_t) + buf_size);
    if (NULL == *buf_p) {
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_NO_MEMORY);
    }

    /* O/W: */
    /* Save buffer size in the head */
    (*((length_t*)(*buf_p))) = buf_size;

    /* update mem_type_count array */
    evb_mem_type_count[mem_type_id] += (buf_size);
    evb_mem_type_count[UTILS_MEM_TYPE_ID_ALL] += (buf_size);

    /* update buffer to point after the buffer size */
    (*buf_p) += sizeof(length_t);

    SX_LOG_DBG("Allocated %u bytes for memory type %s; Total memory for this type = %u;\n",
               buf_size, evb_mem_type_name[mem_type_id], evb_mem_type_count[mem_type_id]);

    SX_LOG_EXIT();

    return rc;
}

/**
 * This function allocate memory and zero allocated memory items.
 *
 * @param[out] buf_p        - allocate memory into this buffer
 * @param[in]  items_number - number of items to allocate
 * @param[in]  item_size    - item size in bytes
 * @param[in]  mem_type_id  - memory type id - ascribe memory allocation for this memory type
 *
 * @return sx_status
 */
evb_status_t evb_utils_clr_memory_get(void              **buf_p,
                                      uint32_t            items_number,
                                      uint32_t            item_size,
                                      utils_mem_type_id_t mem_type_id)
{
    evb_status_t rc = EVB_STATUS_SUCCESS;
    uint32_t     buf_size = items_number * item_size;

    SX_LOG_ENTER();

    rc = evb_utils_memory_get(buf_p, buf_size, mem_type_id);
    if (EVB_CHECK_FAIL(rc)) {
        return M_EVB_UTILS_SX_LOG_EXIT(rc);
    }
    /* O/W: */
    /* Zero the entire buffer */
    memset(*buf_p, 0, buf_size);

    SX_LOG_EXIT();

    return rc;
}

/**
 * This function free memory using free.
 *
 * @param[in]  buf_p          - buffer to free
 * @param[in]  mem_type_id    - memory type id - ascribe memory deallocation for this memory type
 */
evb_status_t evb_utils_memory_put(void *buf_p, utils_mem_type_id_t mem_type_id)
{
    evb_status_t rc = EVB_STATUS_SUCCESS;
    void        *block_start = NULL;
    length_t     buf_size = 0;

    SX_LOG_ENTER();

    if (!M_EVB_UTILS_MEM_TYPE_ID_CHECK_RANGE(mem_type_id)) {
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_PARAM_EXCEED_RANGE);
    }
    /* O/W: */
    rc = evb_utils_check_pointer(buf_p, "Buffer pointer");
    if (EVB_CHECK_FAIL(rc)) {
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_PARAM_NULL);
    }
    /* O/W: */
    /* point to the buffer's header */
    block_start = (buf_p) - sizeof(length_t);

    /* update mem_type_count array */
    memcpy(&buf_size, block_start, sizeof(length_t));

    if (buf_size > evb_mem_type_count[mem_type_id]) {
        SX_LOG_ERR("Block size exceeds total size for memory type %s\n", evb_mem_type_name[mem_type_id]);
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_MEMORY_ERROR);
    }
    /* O/W: */
    evb_mem_type_count[mem_type_id] -= buf_size;
    evb_mem_type_count[UTILS_MEM_TYPE_ID_ALL] -= (buf_size);

    free(block_start);

    SX_LOG_DBG("Freed %u bytes for memory type %s; Total memory for this type = %u;\n",
               buf_size, evb_mem_type_name[mem_type_id], evb_mem_type_count[mem_type_id]);

    SX_LOG_EXIT();

    return rc;
}

/**
 * This function prints allocated memory for mem_type_id
 *
 * @param[in]  mem_type_id    - print memory report for this memory type. set  UTILS_MEM_TYPE_ID_ALL
 * in order to print report for all memory types.
 */
evb_status_t evb_utils_memory_print_summary(utils_mem_type_id_t mem_type_id)
{
    evb_status_t rc = EVB_STATUS_SUCCESS;
    int          i = mem_type_id;

    SX_LOG_ENTER();

    SX_LOG_DBG("====== MEMORY REPORT ======\n");

    if (mem_type_id == UTILS_MEM_TYPE_ID_ALL) {
        for (i = UTILS_MEM_TYPE_ID_MIN; i < UTILS_MEM_TYPE_ID_MAX + 1; i++) {
            SX_LOG_DBG("Allocated %d bytes for memory type %s\n",
                       evb_mem_type_count[i],
                       evb_mem_type_name[i]);
        }
    } else {
        if (!M_EVB_UTILS_MEM_TYPE_ID_CHECK_RANGE(mem_type_id)) {
            return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_PARAM_EXCEED_RANGE);
        }
        /* O/W: */
        SX_LOG_DBG("Allocated %d bytes for memory type %s\n", evb_mem_type_count[i], evb_mem_type_name[i]);
    }

    SX_LOG_EXIT();

    return rc;
}

const char* evb_utils_get_err_str(evb_status_t status)
{
    const char *err_str = "Unknown return code";

    SX_LOG_ENTER();

    if (EVB_STATUS_CHECK_RANGE(status)) {
        err_str = evb_status2str_arr[status];
    }

    SX_LOG_EXIT();

    return err_str;
}

/************************************************
 *  VALIDATION
 ***********************************************/

/**
 *  This function checks if the given pointer isn't NULL.
 *
 * @param[in] ptr - Generic pointer
 * @param[in] description - Description of what "stands behind" the pointer
 *
 * @return sx_status_t
 */
evb_status_t evb_utils_check_pointer(IN const void *ptr, IN const char *description)
{
    SX_LOG_ENTER();

    if (NULL == ptr) {
        if (NULL != description) {
            SX_LOG_ERR("NULL Pointer (%s)\n", description);
        } else {
            SX_LOG_ERR("NULL Pointer\n");
        }
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_PARAM_NULL);
    }
    /* O/W: */
    SX_LOG_EXIT();

    return EVB_STATUS_SUCCESS;
}

evb_status_t evb_utils_check_length(IN length_t len, IN const char *description)
{
    SX_LOG_ENTER();

    if (0 == len) {
        if (NULL != description) {
            SX_LOG_ERR("Zero length (%s)\n", description);
        } else {
            SX_LOG_ERR("Zero length\n");
        }
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_PARAM_EXCEED_RANGE);
    }
    /* O/W: */
    SX_LOG_EXIT();

    return EVB_STATUS_SUCCESS;
}

evb_status_t evb_utils_check_mc_id(IN sx_mc_id_t mc_id)
{
    SX_LOG_ENTER();

    if (!SX_MC_ID_CHECK_RANGE(mc_id)) {
        SX_LOG_ERR("Multicast ID (%u) exceeds range [%u..%u]\n", mc_id, SX_MC_ID_MIN, SX_MC_ID_MAX);
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_PARAM_EXCEED_RANGE);
    }
    /* O/W: */
    SX_LOG_EXIT();

    return EVB_STATUS_SUCCESS;
}

evb_status_t evb_utils_check_dev_id(IN sx_dev_id_t dev_id)
{
    SX_LOG_ENTER();

    if (!SX_DEV_ID_CHECK_RANGE(dev_id)) {
        SX_LOG_ERR("Device ID (%u) exceeds range [%u..%u]\n", dev_id, SX_DEV_ID_MIN, SX_DEV_ID_MAX);
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_PARAM_EXCEED_RANGE);
    }
    /* O/W: */
    SX_LOG_EXIT();

    return EVB_STATUS_SUCCESS;
}

evb_status_t evb_utils_check_dev_evb_type(IN sx_dev_node_type_t topo_type)
{
    SX_LOG_ENTER();

    if (!SX_DEV_NODE_TYPE_CHECK_RANGE(topo_type)) {
        SX_LOG_ERR("Device Topology Type # (%u) exceeds range [%u..%u]\n",
                   topo_type,
                   SX_DEV_NODE_TYPE_MIN,
                   SX_DEV_NODE_TYPE_MAX);
        return M_EVB_UTILS_SX_LOG_EXIT(EVB_STATUS_PARAM_EXCEED_RANGE);
    }
    /* O/W: */
    SX_LOG_EXIT();

    return EVB_STATUS_SUCCESS;
}

void evb_utils_sx_log_enter(const char *func_name)
{
    SX_LOG_FUNC_WRAP(func_name, "%s - entered\n");
}

evb_status_t evb_utils_sx_log_exit(evb_status_t rc, const char *func_name)
{
    SX_LOG_FUNC_WRAP(func_name, "%s - left\n");
    return rc;
}
