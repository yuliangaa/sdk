/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __EVB_UTILS_H__
#define __EVB_UTILS_H__

#include <stdlib.h>
#include <errno.h>
#include <complib/cl_spinlock.h>
#include <sx/sdk/sx_check.h>
#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_dev.h>
#include <complib/sx_log.h>
#include <evb_status.h>

/************************************************
 *  DEFINES
 ***********************************************/

#ifndef __EVB_UTILS_H__

#define SX_MEM_GET(dst, size)                 (dst = malloc(size))
#define SX_MEM_GET_CLR(dst, size)             (dst = calloc(1, size))
#define SX_MEM_GET_RESIZE(dst, src, new_size) (dst = realloc(src, new_size))

#define SX_MEM_PUT(src_p) (free(src_p))

#endif  /*	__EVB_UTILS_H__	*/

typedef enum evb_utils_mem_type_id {
    UTILS_MEM_TYPE_ID_ALL = 0,
    UTILS_MEM_TYPE_ID_EVB_MANAGER,
    UTILS_MEM_TYPE_ID_TEMP, /* Please keep this type last... */
    UTILS_MEM_TYPE_ID_MIN = UTILS_MEM_TYPE_ID_ALL,
    UTILS_MEM_TYPE_ID_MAX = UTILS_MEM_TYPE_ID_TEMP,
} utils_mem_type_id_t;

/************************************************
 *  MACROS
 ***********************************************/

/* This macro checks if the given memory-type is within the valid range	*/
#define M_EVB_UTILS_MEM_TYPE_ID_CHECK_RANGE(mem_type_id)                           \
    SX_CHECK_RANGE(UTILS_MEM_TYPE_ID_MIN, (int)mem_type_id, UTILS_MEM_TYPE_ID_MAX) \

/* The macro uses cl_spinlock_init function to initialize a spin lock for use */
#define M_EVB_UTILS_MUTEX_INIT(mtx_p)         \
    if (cl_spinlock_init(mtx_p)) {            \
        SX_LOG_ERR("Failed to init mutex\n"); \
        return -errno;                        \
    }                                         \

/* The macro uses cl_spinlock_destroy function to deinitialize a spin lock */
#define M_EVB_UTILS_MUTEX_DEINIT(mtx_p) cl_spinlock_destroy(mtx_p)

/* The macro uses cl_spinlock_acquire function to lock a spin lock */
#define M_EVB_UTILS_MUTEX_LOCK(mtx_p) cl_spinlock_acquire(mtx_p)

/* The macro uses cl_spinlock_release function to release a spin lock */
#define M_EVB_UTILS_MUTEX_UNLOCK(mtx_p) cl_spinlock_release(mtx_p)

/* The macro check whether a spin lock has been initialized */
#define M_EVB_UTILS_MUTEX_IS_INITIALIZED(mtx_p) ((mtx_p)->state == CL_INITIALIZED)

/* The macro calls the utils_sx_log_exit(...) function with __FUNCTION__ */
#define M_EVB_UTILS_SX_LOG_EXIT(status) (evb_utils_sx_log_exit(status, __func__))

/************************************************
 *  GLOBAL VARIABLES
 ***********************************************/

/************************************************
 *  API Functions
 ***********************************************/

/**
 * This function allocate memory and zero allocated memory items.
 *
 * @param[out] buf_p        - allocate memory into this buffer
 * @param[in]  items_number - number of items to allocate
 * @param[in]  item_size    - item size in bytes
 * @param[in]  mem_type_id  - memory type id - ascribe memory allocation for this memory type
 *
 * @return sx_status
 */
evb_status_t evb_utils_clr_memory_get(void              **buf_p,
                                      uint32_t            items_number,
                                      uint32_t            item_size,
                                      utils_mem_type_id_t mem_type_id);

/**
 * This function allocate memory
 *
 * @param[out] buf_p        - pointer to a buffer pointer
 * @param[in]  buf_size     - size of memory to allocate (in bytes)
 * @param[in]  mem_type_id  - memory type id - ascribe memory allocation for this memory type
 */
evb_status_t evb_utils_memory_get(void              **buf_p,
                                  length_t            buf_size,
                                  utils_mem_type_id_t mem_type_id);

/**
 * This function free memory using free.
 *
 * @param[in]  buf_p          - buffer to free
 * @param[in]  mem_type_id    - memory type id - ascribe memory deallocation for this memory type
 */
evb_status_t evb_utils_memory_put(void *buf_p, utils_mem_type_id_t mem_type_id);

/**
 * This function prints allocated memory for mem_type_id
 *
 * @param[in]  mem_type_id    - print memory report for this memory type. set  UTILS_MEM_TYPE_ID_ALL
 * in order to print report for all memory types.
 */
evb_status_t evb_utils_memory_print_summary(utils_mem_type_id_t mem_type_id);

/**
 * This function returns the error message (if exists)
 * that's associated with the given error status.
 *
 * @param[in]  sx_status	- The error status whose error message is to be returned.
 *
 * @return const char*		- The error message associated with the given error status.
 *
 */
const char * evb_utils_get_err_str(evb_status_t status);

/**
 * This function prints the enter (to a function) message.
 *
 * @param[in]  func_name        - Called from function name for log print
 *
 * @return void
 *
 */
void evb_utils_sx_log_enter(const char *func_name);

/**
 * This function prints the exit (from function) message
 * & returns the error status that was given to it.
 *
 * @param[in]  rc	        - The error status that needs to be returned.
 * @param[in]  func_name        - calling function name for log print
 *
 * @return sx_status_t		- The error status that was given.
 *
 */
evb_status_t evb_utils_sx_log_exit(evb_status_t rc, const char *func_name);

/**
 *  This function checks if the given pointer isn't NULL.
 *
 * @param[in] ptr - Generic pointer
 * @param[in] description - Description of what "stands behind" the pointer
 *
 * @return sx_status_t
 */
evb_status_t evb_utils_check_pointer(IN const void *ptr,
                                     IN const char *description);

/**
 *  This function checks if the given length isn't 0 (zero).
 *
 * @param[in] len - length
 * @param[in] description - Description of whose length is checked
 *
 * @return sx_status_t
 */
evb_status_t evb_utils_check_length(IN length_t len, IN const char *description);

/**
 *  This function checks if the given MC-ID is within the valid range.
 *
 * @param[in] mc_id - MC-ID
 *
 * @return sx_status_t
 */
evb_status_t evb_utils_check_mc_id(IN sx_mc_id_t mc_id);

/**
 *  This function checks if the given Device-ID is within the valid range.
 *
 * @param[in] dev_id - Device-ID
 *
 * @return sx_status_t
 */
evb_status_t evb_utils_check_dev_id(IN sx_dev_id_t dev_id);

/**
 *  This function checks if the given Device Topology-Type is within the valid range.
 *
 * @param[in] evb_type - Device Topology-Type
 *
 * @return sx_status_t
 */
evb_status_t evb_utils_check_dev_evb_type(IN sx_dev_node_type_t topo_type);

#endif /* __EVB_UTILS_H__ */
