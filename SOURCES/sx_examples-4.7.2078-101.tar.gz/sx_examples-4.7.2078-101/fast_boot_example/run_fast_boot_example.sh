#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


basedir=`readlink -f $0`
basedir=${basedir%/*}

export LD_LIBRARY_PATH=${basedir}/../lib:${basedir}/../lib64
fast_boot_file_name=/etc/fast_boot_example_file
echo "### Fast boot example script START"

echo "### Fast boot - Create file"
# Write to file
echo "fast_boot_example" > ${fast_boot_file_name}
chmod 777  ${fast_boot_file_name}
if [ $? != "0" ]; then
        echo "Error: Create file failed "
        exit 1
fi

# Stop DVS
echo "### Fast boot - stop DVS"
dvs_stop.sh

# NOTE that it is not working with current kernel version [3.10.0-54.0.8]
echo "### Fast boot - Call KEXEC"
# Call KEXEC
kexec -l /boot/vmlinuz-3.10.0-54.0.8.mlnx.evb --initrd=/boot/initrd.img-3.10.0-54.0.8.mlnx.evb --reuse-cmdline
if [ $? != "0" ]; then
        echo "Error: KEXEC failed"
        exit 1
fi
 
echo "### Fast boot - Execute KEXEC"
# Call Execute KEXEC
kexec -e
if [ $? != "0" ]; then
        echo "Error: Execute KEXEC failed"
        exit 1
fi

echo "### Fast boot example script END"

exit $?