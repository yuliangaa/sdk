/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sdk/sx_api_flex_modifier.h>
#include <sx/sdk/sx_api_flex_parser.h>
#include <sx/sdk/sx_api_register.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_dbg.h>
#include <complib/sx_log.h>

sx_acl_key_t            key_id_set_example[] = {
    FLEX_ACL_KEY_GP_REGISTER_0_OFFSET,
    FLEX_ACL_KEY_GP_REGISTER_1_OFFSET,
};
sx_acl_key_type_t       key_handle;
sx_acl_region_id_t      region_id;
sx_acl_region_group_t   acl_region_group;
sx_acl_id_t             acl_id;
sx_acl_direction_t      acl_direction = SX_ACL_DIRECTION_EGRESS;
sx_acl_id_t             acl_group_id;
sx_acl_id_t             acl_id_list[1];
sx_port_log_id_t        ingress_log_port = 0x10005;
sx_flex_acl_flex_rule_t rules_example[16];


sx_status_t create_emt_rule(sx_api_handle_t            api_handle,
                            sx_flex_modifier_emt_key_t push_emt_key,
                            sx_flex_modifier_emt_key_t edit_emt_key)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_acl_rule_offset_t offset = 0;


    /* Create key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_set_example,
                                        sizeof(key_id_set_example) / sizeof(key_id_set_example[0]),
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_CREATE,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      16,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_CREATE,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_CREATE,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    acl_id_list[0] = acl_id;
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_SET,
                                     acl_direction,
                                     acl_id_list,
                                     1,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Bind the group to the egress port */
    sx_status = sx_api_acl_port_bind_set(api_handle, SX_ACCESS_CMD_BIND, ingress_log_port, acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_port_bind_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create a rule to execute the EMT */
    sx_status = sx_lib_flex_acl_rule_init(key_handle, 1, &rules_example[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_lib_flex_acl_rule_init failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }
    rules_example[0].valid = 1;
    rules_example[0].key_desc_count = 2;
    rules_example[0].action_count = 1;

    /* Use the GP register offset as keys to this rule. This is not mandatory just an example */
    rules_example[0].key_desc_list_p[0].key_id = FLEX_ACL_KEY_GP_REGISTER_0_OFFSET;
    rules_example[0].key_desc_list_p[0].key.gp_register_offset = 42;
    rules_example[0].key_desc_list_p[0].mask.gp_register_offset = 0xFFFF;
    rules_example[0].key_desc_list_p[1].key_id = FLEX_ACL_KEY_GP_REGISTER_1_OFFSET;
    rules_example[0].key_desc_list_p[1].key.gp_register_offset = 26;
    rules_example[0].key_desc_list_p[1].mask.gp_register_offset = 0xFFFF;

    /* Set the EMT action - one push action and one edit action */
    rules_example[0].action_list_p[0].type = SX_FLEX_ACL_ACTION_SET_EMT;
    rules_example[0].action_list_p[0].fields.action_set_emt.emt_bind_action[0].emt_bind_index =
        SX_FLEX_MODIFIER_EMT_BIND_INDEX_0_E;
    rules_example[0].action_list_p[0].fields.action_set_emt.emt_bind_action[0].emt_bind_type =
        SX_FLEX_MODIFIER_BIND_TYPE_PUSH_E;
    rules_example[0].action_list_p[0].fields.action_set_emt.emt_bind_action[0].emt_bind_type_attr.emt_id =
        push_emt_key;
    rules_example[0].action_list_p[0].fields.action_set_emt.emt_bind_action[0].emt_bind_type_attr.emt_offset =
        SX_FLEX_MODIFIER_GP_REGISTER_0_OFFSET_E;
    rules_example[0].action_list_p[0].fields.action_set_emt.emt_bind_action[1].emt_bind_index =
        SX_FLEX_MODIFIER_EMT_BIND_INDEX_1_E;
    rules_example[0].action_list_p[0].fields.action_set_emt.emt_bind_action[1].emt_bind_type =
        SX_FLEX_MODIFIER_BIND_TYPE_EDIT_E;
    rules_example[0].action_list_p[0].fields.action_set_emt.emt_bind_action[1].emt_bind_type_attr.emt_id =
        edit_emt_key;
    rules_example[0].action_list_p[0].fields.action_set_emt.emt_bind_action[1].emt_bind_type_attr.emt_offset =
        SX_FLEX_MODIFIER_GP_REGISTER_1_OFFSET_E;

    sx_status = sx_api_acl_flex_rules_set(api_handle,
                                          SX_ACCESS_CMD_SET,
                                          region_id,
                                          &offset,
                                          &rules_example[0],
                                          1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_rules_set failed [%s]\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules_example[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_lib_flex_acl_rule_deinit failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }


out:
    return sx_status;
}

sx_status_t delete_emt_rule(sx_api_handle_t api_handle)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    /* Unbind from the egress port */
    sx_status = sx_api_acl_port_bind_set(api_handle, SX_ACCESS_CMD_UNBIND, ingress_log_port, acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_port_bind_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      16,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_DELETE,
                                        key_id_set_example,
                                        sizeof(key_id_set_example) / sizeof(key_id_set_example[0]),
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}


int main(int argc, char *argv[])
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_api_handle_t               api_handle;
    sx_flex_modifier_emt_key_t    push_emt_key;
    sx_flex_modifier_emt_key_t    edit_emt_key;
    sx_flex_modifier_emt_cfg_t    push_emt_cfg;
    sx_flex_modifier_emt_cfg_t    edit_emt_cfg;
    sx_flex_modifier_emt_cfg_t    temp_emt_cfg;
    sx_register_key_t             push_register_key;
    sx_register_key_t             edit_register_key;
    sx_extraction_point_t         push_ext_point;
    sx_extraction_point_t         edit_ext_point;
    uint32_t                      register_count = 0;
    uint32_t                      ext_point_count = 0;
    sx_flex_parser_param_t        parser_params;
    sx_flex_modifier_attributes_t attr_params[2];
    uint32_t                      attr_cfg_cnt = 0;

    memset(&push_emt_key, 0, sizeof(push_emt_key));
    memset(&push_emt_cfg, 0, sizeof(push_emt_cfg));
    memset(&push_register_key, 0, sizeof(push_register_key));
    memset(&push_ext_point, 0, sizeof(push_ext_point));
    memset(&edit_emt_key, 0, sizeof(edit_emt_key));
    memset(&edit_emt_cfg, 0, sizeof(edit_emt_cfg));
    memset(&edit_register_key, 0, sizeof(edit_register_key));
    memset(&edit_ext_point, 0, sizeof(edit_ext_point));
    memset(&parser_params, 0, sizeof(parser_params));
    memset(&attr_params, 0, sizeof(attr_params));

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    /* Open SDK API */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_parser_init_set(api_handle, &parser_params);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_parser_init_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Use a GP register to mark the offset of the push operation */
    push_register_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
    push_register_key.key.gp_reg.reg_id = SX_GP_REGISTER_0_E;
    register_count = 1;
    sx_status = sx_api_register_set(api_handle, SX_ACCESS_CMD_CREATE, &push_register_key, &register_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_register_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Set the push operation to be at offset 42 from the start of packet (After UDP header) */
    push_ext_point.type = SX_EXTRACTION_POINT_TYPE_L2_START_OF_HEADER_E;
    push_ext_point.offset = 42;
    ext_point_count = 1;
    /* Set the extraction point */
    sx_status = sx_api_flex_parser_reg_ext_point_set(api_handle,
                                                     SX_ACCESS_CMD_SET,
                                                     push_register_key,
                                                     &push_ext_point,
                                                     &ext_point_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_parser_reg_ext_point_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Set the EMT to push two immediate values */
    push_emt_key.emt_id = SX_FLEX_MODIFIER_EMT0_E;
    push_emt_cfg.emt_data_cnt = 2;
    push_emt_cfg.emt_data_list[0].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
    push_emt_cfg.emt_data_list[0].immediate_value = 0xDEAD;
    push_emt_cfg.emt_data_list[0].skip = FALSE;
    push_emt_cfg.emt_data_list[1].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
    push_emt_cfg.emt_data_list[1].immediate_value = 0xBEEF;
    push_emt_cfg.emt_data_list[1].skip = FALSE;
    push_emt_cfg.emt_update_cnt = 2;
    push_emt_cfg.emt_update_list[0] = SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_UDP_TCP_LENGTH_E;
    push_emt_cfg.emt_update_list[1] = SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_IPV4_LENGTH_E;


    sx_status = sx_api_flex_modifier_set(api_handle, SX_ACCESS_CMD_CREATE, push_emt_key, &push_emt_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_set create failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_modifier_set(api_handle, SX_ACCESS_CMD_SET, push_emt_key, &push_emt_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Use a GP register to mark the offset of the edit operation */
    edit_register_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
    edit_register_key.key.gp_reg.reg_id = SX_GP_REGISTER_1_E;
    register_count = 1;
    sx_status = sx_api_register_set(api_handle, SX_ACCESS_CMD_CREATE, &edit_register_key, &register_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_register_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    /* The edit will be at offset 12 from the IPv4 header - SIP & DIP fields */
    edit_ext_point.type = SX_EXTRACTION_POINT_TYPE_IPV4_START_OF_HEADER_E;
    edit_ext_point.offset = 12;
    ext_point_count = 1;

    sx_status = sx_api_flex_parser_reg_ext_point_set(api_handle,
                                                     SX_ACCESS_CMD_SET,
                                                     edit_register_key,
                                                     &edit_ext_point,
                                                     &ext_point_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_parser_reg_ext_point_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Push 4 words - immediate value and timestamps */
    edit_emt_key.emt_id = SX_FLEX_MODIFIER_EMT1_E;
    edit_emt_cfg.emt_data_cnt = 4;
    edit_emt_cfg.emt_data_list[0].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
    edit_emt_cfg.emt_data_list[0].immediate_value = 0xAABB;
    edit_emt_cfg.emt_data_list[0].skip = FALSE;
    edit_emt_cfg.emt_data_list[1].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_INGRESS_TIMESTAMP_SEC_LSB_E;
    edit_emt_cfg.emt_data_list[1].skip = FALSE;
    edit_emt_cfg.emt_data_list[2].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_INGRESS_TIMESTAMP_NSEC_MSB_E;
    edit_emt_cfg.emt_data_list[2].skip = FALSE;
    edit_emt_cfg.emt_data_list[3].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_INGRESS_TIMESTAMP_NSEC_LSB_E;
    edit_emt_cfg.emt_data_list[3].skip = FALSE;
    edit_emt_cfg.emt_update_cnt = 1;
    edit_emt_cfg.emt_update_list[0] = SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_UDP_TCP_CHECKSUM_E;


    sx_status = sx_api_flex_modifier_set(api_handle, SX_ACCESS_CMD_CREATE, edit_emt_key, &edit_emt_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_set create failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_modifier_set(api_handle, SX_ACCESS_CMD_SET, edit_emt_key, &edit_emt_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Use an ACL to bind the EMT to an egress port */
    sx_status = create_emt_rule(api_handle, push_emt_key, edit_emt_key);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed to create EMT rule. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_modifier_get(api_handle, SX_ACCESS_CMD_GET, push_emt_key, &temp_emt_cfg);
    if ((sx_status != SX_STATUS_SUCCESS) || (memcmp(&push_emt_cfg, &temp_emt_cfg, sizeof(push_emt_cfg)) != 0)) {
        printf("ERROR: Failed to get EMT. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_modifier_get(api_handle, SX_ACCESS_CMD_GET, edit_emt_key, &temp_emt_cfg);
    if ((sx_status != SX_STATUS_SUCCESS) || (memcmp(&edit_emt_cfg, &temp_emt_cfg, sizeof(edit_emt_cfg)) != 0)) {
        printf("ERROR: Failed to get EMT. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Configure port attributes port 0x10005 */
    attr_params[0].attr_type = SX_FLEX_MODIFIER_ATTR_TYPE_PORT_E;
    attr_params[0].sx_flex_modifier_attr.port_attributes.log_port = 0x10005;
    attr_params[0].sx_flex_modifier_attr.port_attributes.payload_offset_shift = 0x20;

    sx_status = sx_api_flex_modifier_attr_set(api_handle, SX_ACCESS_CMD_ADD, &attr_params[0], 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_attr_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Get port 0x10005 attributes*/
    attr_params[0].sx_flex_modifier_attr.port_attributes.payload_offset_shift = 0;
    attr_cfg_cnt = 1;
    sx_status = sx_api_flex_modifier_attr_get(api_handle, SX_ACCESS_CMD_GET, &attr_params[0], &attr_cfg_cnt);
    if ((sx_status != SX_STATUS_SUCCESS) ||
        (attr_params[0].sx_flex_modifier_attr.port_attributes.payload_offset_shift != 0x20)) {
        printf("ERROR: sx_api_flex_modifier_attr_get failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Configure port attributes port 0x10009 */
    attr_params[1].attr_type = SX_FLEX_MODIFIER_ATTR_TYPE_PORT_E;
    attr_params[1].sx_flex_modifier_attr.port_attributes.log_port = 0x10009;
    attr_params[1].sx_flex_modifier_attr.port_attributes.payload_offset_shift = 0x22;

    sx_status = sx_api_flex_modifier_attr_set(api_handle, SX_ACCESS_CMD_ADD, &attr_params[1], 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_attr_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Get All port attributes*/
    memset(&attr_params, 0, sizeof(attr_params));
    attr_cfg_cnt = 2;
    sx_status = sx_api_flex_modifier_attr_get(api_handle, SX_ACCESS_CMD_GET_ALL, attr_params, &attr_cfg_cnt);
    if ((sx_status != SX_STATUS_SUCCESS) ||
        (attr_params[0].sx_flex_modifier_attr.port_attributes.payload_offset_shift != 0x20)
        || (attr_params[1].sx_flex_modifier_attr.port_attributes.payload_offset_shift != 0x22)) {
        printf("ERROR: sx_api_flex_modifier_attr_get failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* From here we REMOVE the configurations we've done so far */

    /* Remove the ACL rule */
    sx_status = delete_emt_rule(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed to delete EMT rule. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }


    sx_status = sx_api_flex_modifier_set(api_handle, SX_ACCESS_CMD_DESTROY, edit_emt_key, &edit_emt_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_set destroy failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_parser_reg_ext_point_set(api_handle,
                                                     SX_ACCESS_CMD_UNSET,
                                                     edit_register_key,
                                                     &edit_ext_point,
                                                     &ext_point_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_parser_reg_ext_point_set unset failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_modifier_set(api_handle, SX_ACCESS_CMD_DESTROY, push_emt_key, &push_emt_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_set destroy failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_parser_reg_ext_point_set(api_handle,
                                                     SX_ACCESS_CMD_UNSET,
                                                     push_register_key,
                                                     &push_ext_point,
                                                     &ext_point_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_parser_reg_ext_point_set unset failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }


    sx_status = sx_api_flex_parser_deinit_set(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_parser_deinit_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_register_set(api_handle, SX_ACCESS_CMD_DESTROY, &push_register_key, &register_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_register_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_register_set(api_handle, SX_ACCESS_CMD_DESTROY, &edit_register_key, &register_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_register_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }


    /* Close SDK API */
    sx_status = sx_api_close(&api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    printf("Successfully finished\n");
    return 0;
}
