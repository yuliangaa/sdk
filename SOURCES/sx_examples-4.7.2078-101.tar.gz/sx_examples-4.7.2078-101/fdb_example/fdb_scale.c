/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sys/time.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_strings.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_fdb.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_lib_host_ifc.h>
#include <sx/sxd/sxd_access_register.h>
#include <resource_manager/resource_manager.h>


struct timeval        start_time, end_time;
static struct timeval mac_add_start_time;
static struct timeval mac_add_end_time;
static struct timeval mac_del_start_time;
static struct timeval mac_del_end_time;
static uint32_t       mac_add_api_calls = 0;
static uint32_t       mac_delete_api_calls = 0;

#define MEASURE_TIME(val)        gettimeofday(val, NULL)
#define CALCULATE_TIME(start_time,                                     \
                       end_time) (unsigned int)(((end_time.tv_sec -    \
                                                  start_time.tv_sec) * \
                                                 1000000) + (end_time.tv_usec - start_time.tv_usec))
#define TIME_DIMENSION "micro seconds"

#define SWID      0
#define DEVICE_ID 1

static uint32_t event_recv_cnt = 0;
static uint32_t event_mac_add_del_recv_cnt = 0;
static sx_status_t __get_chip_type(sx_chip_types_t *chip_type_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mgir_reg mgir_reg;

    memset(&reg_meta, 0, sizeof(reg_meta));
    memset(&mgir_reg, 0, sizeof(mgir_reg));

    if (chip_type_p == NULL) {
        printf("ERROR: chip_type_p is NULL.\n");
        exit(1);
    }

    sxd_status = sxd_access_reg_init(0, NULL, SX_VERBOSITY_LEVEL_INFO);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        printf("ERROR: SXD API sxd_access_reg_init failed: [%s]\n", SXD_STATUS_MSG(sxd_status));
        exit(1);
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.dev_id = 1;
    memset(&mgir_reg, 0, sizeof(struct ku_mgir_reg));

    sxd_status = sxd_access_reg_mgir(&mgir_reg, &reg_meta, 1, NULL, NULL);
    if (sxd_status) {
        printf("%s: failed in get MGIR for dev_id %d, error: %d \n",
               __func__, 1, sxd_status);
    }

    switch (mgir_reg.hw_info.device_id) {
    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
        if (mgir_reg.hw_info.device_hw_revision == 0xA0) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM;
        } else if (mgir_reg.hw_info.device_hw_revision == 0xA1) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM_A1;
        } else {
            printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
            exit(1);
        }
        printf("Device type is: SPECTRUM.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM2;

        printf("Device type is: SPECTRUM2.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM3;

        printf("Device type is: SPECTRUM3.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM4;

        printf("Device type is: SPECTRUM4.\n");
        break;


    default:
        printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
        exit(1);
    }

    return status;
}


/*
 * The purpose of the following function is to generate specified number of unique UC or MC MAC entries.
 */
sx_status_t __prepare_unique_mac_entries(sx_fdb_uc_mac_addr_params_t *mac_entry_p,
                                         sx_port_log_id_t             log_port,
                                         uint32_t                     entries_num,
                                         boolean_t                    is_mc)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    uint32_t    n = 0;
    uint32_t    octet3 = 0x00, octet4 = 0x00, octet5 = 0x00;
    uint32_t    fid_vid = 1;

    if (mac_entry_p == NULL) {
        status = SX_STATUS_PARAM_NULL;
        printf("ERROR: 'mac_entry_p' is NULL: [%s]\n", sx_status_str(status));
        goto out;
    }

    /*
     *  We don't expect to have more different MACs here than 255*255*255, hence the following assert should not happen.
     *  255 * 255 * 255 = 16581375
     */
    if (entries_num > (0xFF * 0xFF * 0xFF)) {
        status = SX_STATUS_ERROR;
        printf("ERROR: entries_num = %u and it is too big.\n", entries_num);
        goto out;
    }

    for (n = 0; n < entries_num; n++) {
        /* in MC MAC first octet must be equal to 0x01 */
        mac_entry_p[n].mac_addr.ether_addr_octet[0] = (is_mc == TRUE) ? 0x01 : 0x00;
        mac_entry_p[n].mac_addr.ether_addr_octet[1] = 0x4d;
        mac_entry_p[n].mac_addr.ether_addr_octet[2] = 0x5e;
        if (octet5 >= 0xFF) {
            octet5 = 0x00;
            octet4++;
        }
        if (octet4 >= 0xFF) {
            octet4 = 0x00;
            octet3++;
        }
        /* we don't expect to have more different MAC here than 255*255*255, hence the following assert should not happen */
        assert(octet3 < 255);
        octet5++;

        mac_entry_p[n].mac_addr.ether_addr_octet[3] = octet3;
        mac_entry_p[n].mac_addr.ether_addr_octet[4] = octet4;
        mac_entry_p[n].mac_addr.ether_addr_octet[5] = octet5;
        mac_entry_p[n].fid_vid = fid_vid;
        mac_entry_p[n].log_port = log_port;
        mac_entry_p[n].entry_type = SX_FDB_UC_STATIC; /* for MC we don't use this*/
    }

out:
    return status;
}

/*
 * The purpose of the following function is to ADD or DELETE specified UC or MC entries.
 */
static sx_status_t __handle_mac_entries(sx_api_handle_t              api_handle,
                                        sx_access_cmd_t              cmd,
                                        boolean_t                    is_mc,
                                        sx_fdb_uc_mac_addr_params_t *mac_entry_p,
                                        uint32_t                     entries_num,
                                        uint32_t                    *entries_processed)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    uint32_t    n = 0, tmp = 0;
    uint32_t    before_tmp;
    uint32_t    success_cnt;
    /* sx_fdb_uc_mac_addr_params_t mac_entry_lst[32]; */
    sx_fdb_uc_mac_addr_params_t* mac_entry_lst;
    sx_fdb_uc_mac_addr_params_t* succeed_entry_lst;
    uint32_t                     fail_iter = 0;
    uint32_t                     i;

    tmp = 32 * 1; /*10; */
    mac_entry_lst = (sx_fdb_uc_mac_addr_params_t*)malloc(sizeof(sx_fdb_uc_mac_addr_params_t) * tmp);
    memset(mac_entry_lst, 0x0, sizeof(sx_fdb_uc_mac_addr_params_t) * tmp);

    succeed_entry_lst = (sx_fdb_uc_mac_addr_params_t*)malloc(sizeof(sx_fdb_uc_mac_addr_params_t) * tmp);
    memset(succeed_entry_lst, 0x0, sizeof(sx_fdb_uc_mac_addr_params_t) * tmp);

    if (entries_processed == NULL) {
        status = SX_STATUS_PARAM_NULL;
        printf("ERROR: 'entries_processed' is NULL. [rc = %s]\n", sx_status_str(status));
        goto out;
    }

    if (mac_entry_p == NULL) {
        status = SX_STATUS_PARAM_NULL;
        printf("ERROR: 'mac_entry_p' is NULL. [rc = %s]\n", sx_status_str(status));
        goto out;
    }

    if (is_mc == TRUE) {
        for (n = 0; n < entries_num; n++) {
            status = sx_api_fdb_mc_mac_addr_set(api_handle,
                                                cmd,
                                                SWID,
                                                mac_entry_p[n].fid_vid,
                                                mac_entry_p[n].mac_addr,
                                                &mac_entry_p[n].log_port,
                                                1);
            if ((SX_STATUS_SUCCESS != status) && (SX_STATUS_ACCEPTED != status)) {
                printf("ERROR: SDK API sx_api_fdb_mc_mac_addr_set failed: [n = %u, status = %s]\n", n,
                       sx_status_str(status));
                break;
            }
        }
    } else { /* UC */
        /* we will add/delete the following number of entries per every API call */


        uint32_t cnt = 0;
        if (cmd == SX_ACCESS_CMD_ADD) {
            MEASURE_TIME(&mac_add_start_time);
        } else {
            MEASURE_TIME(&mac_del_start_time);
        }

        for (n = 0; n < entries_num; n += tmp) {
            if (cmd == SX_ACCESS_CMD_DELETE) {
                if ((n + tmp) > entries_num) {
                    tmp = entries_num - n;
                }
            }
            before_tmp = tmp;
            memcpy(mac_entry_lst, &mac_entry_p[n], sizeof(sx_fdb_uc_mac_addr_params_t) * tmp);
            memcpy(succeed_entry_lst, &mac_entry_p[n], sizeof(sx_fdb_uc_mac_addr_params_t) * tmp);
            status = sx_api_fdb_uc_mac_addr_set(api_handle,
                                                cmd,
                                                SWID,
                                                mac_entry_lst /*&mac_entry_p[n]*/,
                                                &tmp);
            if ((SX_STATUS_SUCCESS != status) && (SX_STATUS_ACCEPTED != status)) {
                printf("ERROR: SDK API sx_api_fdb_uc_mac_addr_set failed: [n = %u, status = %s]\n", n,
                       sx_status_str(status));
                if (status == SX_STATUS_NO_RESOURCES) {
                    if (cmd == SX_ACCESS_CMD_DELETE) {
                        printf(
                            "ERROR: SDK API sx_api_fdb_uc_mac_addr_set unexpected failure on : SX_ACCESS_CMD_DELETE [n = %u, status = %s]\n",
                            n,
                            sx_status_str(status));
                        exit(0);
                    }

                    uint32_t good_mac_idx = 0;
                    uint32_t failed_mac_found_cnt = 0;
                    for (i = 0; i < before_tmp; i++) {
                        /* fail_mac = mac_entry_lst[fail_iter] */
                        sx_mac_addr_t mac = mac_entry_p[n + i].mac_addr;
                        boolean_t     found_failed_mac = FALSE;
                        for (fail_iter = 0; fail_iter < tmp; fail_iter++) {
                            /* compare fail_mac with mac_entry_lst[i] . if exist remove */
                            sx_mac_addr_t failed_mac;
                            memcpy(&failed_mac, &mac_entry_lst[fail_iter].mac_addr, sizeof(sx_mac_addr_t));
                            found_failed_mac = FALSE;
                            boolean_t is_same_mac = TRUE;
                            uint32_t  j = 0;
                            for (j = 0; j < ETHER_ADDR_LEN; j++) {
                                if (failed_mac.ether_addr_octet[j] != mac.ether_addr_octet[j]) {
                                    is_same_mac = FALSE;
                                    break;
                                }
                            }
                            if (is_same_mac) {
                                found_failed_mac = TRUE;
                                failed_mac_found_cnt++;
                                break;
                            }
                        }
                        if (found_failed_mac == FALSE) {
                            memcpy(&succeed_entry_lst[good_mac_idx], &mac_entry_p[n + i],
                                   sizeof(sx_fdb_uc_mac_addr_params_t));
                            good_mac_idx++;
                        }
                    }

                    memcpy(&mac_entry_p[n], succeed_entry_lst, sizeof(sx_fdb_uc_mac_addr_params_t) * good_mac_idx);
                    success_cnt = before_tmp - tmp;
                    n += success_cnt;
                }
                break;
            }

            if (status == SX_STATUS_SUCCESS) {
                /*printf("SDK API sx_api_fdb_uc_mac_addr_set %s non async\n",(cmd == SX_ACCESS_CMD_ADD)?"Add":"Delete");*/
            } else if (status == SX_STATUS_ACCEPTED) {
                cnt++;
            }
        }

        /*if (status == SX_STATUS_ACCEPTED){*/
        if (cmd == SX_ACCESS_CMD_ADD) {
            mac_add_api_calls = cnt;
        } else {
            mac_delete_api_calls = cnt;
        }

        uint32_t     seconds = 0;
        uint32_t     microsec = 0;
        unsigned int time = 0;


        if ((mac_add_api_calls != 0) && (event_recv_cnt == mac_add_api_calls)) {
            MEASURE_TIME(&mac_add_end_time);

            printf("Received Async API Complete event for all mac addr add\n");

            time = CALCULATE_TIME(mac_add_start_time, mac_add_end_time);
            /* Convert Microseconds to seconds */
            seconds = time / 1000000;
            microsec = (time % 1000000) / 1000;
            printf("Total time: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);
            event_mac_add_del_recv_cnt = 0;
            mac_add_api_calls = 0;
        }

        /*}*/
    }

out:
    free(mac_entry_lst);
    free(succeed_entry_lst);
    if (entries_processed) {
        *entries_processed = n;
    }

    return status;
}

/*
 * The purpose of the following function is to execute full from for specified MAC type entries, which includes the following:
 *  - generate specified number of unique MAC entries
 *  - add these entries FDB and measure how much time it will take
 *  - delete these entries from FDB and measure how much time it will take
 */
static void __check_mac_handling_flow(sx_api_handle_t  handle,
                                      boolean_t        is_mc,
                                      sx_port_log_id_t log_port,
                                      uint32_t         entries_num,
                                      uint8_t         *case_num)
{
    sx_status_t                  status = SX_STATUS_SUCCESS;
    sx_fdb_uc_mac_addr_params_t *mac_entry_p = NULL;
    uint32_t                     processed_entries_num = 0;
    unsigned int                 time = 0;
    uint32_t                     seconds = 0;
    uint32_t                     microsec = 0;

    assert(case_num);

    mac_entry_p = (sx_fdb_uc_mac_addr_params_t*)calloc(entries_num, sizeof(sx_fdb_uc_mac_addr_params_t));
    if (mac_entry_p == NULL) {
        printf("ERROR: failed to allocated memory for MAC entries.\n");
        exit(1);
    }

    /* generate specified number of UC/MC unique MAC entries */
    status = __prepare_unique_mac_entries(mac_entry_p, log_port, entries_num, is_mc);
    if (status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed to generate MAC entries.\n");
        goto out;
    }


    /*********************************************************************
    *  Measure how much time will take adding specified number of entries
    *********************************************************************/
    printf("\nCase_%u. Measure how much time will take adding %u %s MAC entries.\n", ++(*case_num), entries_num,
           (is_mc == TRUE ? "MC" : "UC"));
    MEASURE_TIME(&start_time);
    status = __handle_mac_entries(handle, SX_ACCESS_CMD_ADD, is_mc, mac_entry_p, entries_num, &processed_entries_num);
    if ((status != SX_STATUS_SUCCESS) && (status != SX_STATUS_ACCEPTED)) {
        printf("ERROR: failed to ADD generated MAC entries. [status = %s]\n", sx_status_str(status));
        printf("From specified %u entries only %u were added.\n", entries_num, processed_entries_num);
    }

    MEASURE_TIME(&end_time);

    time = CALCULATE_TIME(start_time, end_time);
    /* Convert Microseconds to seconds */
    seconds = time / 1000000;
    microsec = (time % 1000000) / 1000;
    printf("Total time: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);
    printf("Time per single entry: %u %s \n", time / processed_entries_num, TIME_DIMENSION);


    /*********************************************************************
    *  Measure how much time will take deleting specified number of entries
    *********************************************************************/
    /* delete only those entries which were added */
    if (processed_entries_num != entries_num) {
        entries_num = processed_entries_num;
    }

    /*printf("XXX Skip Delete.\n");
     *  goto out;*/

    printf("\nCase_%u. Measure how much time will take deleting %u %s MAC entries.\n", ++(*case_num), entries_num,
           (is_mc == TRUE ? "MC" : "UC"));
    MEASURE_TIME(&start_time);
    status =
        __handle_mac_entries(handle, SX_ACCESS_CMD_DELETE, is_mc, mac_entry_p, entries_num, &processed_entries_num);
    if ((status != SX_STATUS_SUCCESS) && (status != SX_STATUS_ACCEPTED)) {
        printf("ERROR: failed to DELETE generated MAC entries. [status = %s]\n", sx_status_str(status));
        printf("From specified %u entries only %u were deleted.\n", entries_num, processed_entries_num);
    }
    MEASURE_TIME(&end_time);

    time = CALCULATE_TIME(start_time, end_time);
    /* Convert Microseconds to seconds */
    seconds = time / 1000000;
    microsec = (time % 1000000) / 1000;

    printf("Total time: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);
    printf("Time per single entry: %u %s \n", time / processed_entries_num, TIME_DIMENSION);


out:
    free(mac_entry_p);
}

pthread_t                sx_ver_thread;
static sx_user_channel_t user_channel;

void sx_ver_recv_thread()
{
    sx_status_t status = SX_STATUS_SUCCESS;
    boolean_t   wait_events = TRUE;
    uint32_t    seconds = 0;
    uint32_t    microsec = 0;

#define EVB_MAX_PACKET_SIZE (4 * 1024)
    if (wait_events) {
        uint8_t                               packet[EVB_MAX_PACKET_SIZE] = {0};
        uint32_t                              packet_size = EVB_MAX_PACKET_SIZE;
        sx_receive_info_t                     receive_info;
        sx_async_api_complete_notification_t *async_notify_p = NULL;
        unsigned int                          time = 0;

        while (TRUE) {
            packet_size = sizeof(sx_async_api_complete_notification_t); /* EVB_MAX_PACKET_SIZE; */
            memset(packet, 0, sizeof(packet));

            /* blocking on packet receive */
            if (event_mac_add_del_recv_cnt == 0) {
                printf("Waiting on host ifc packet receive event_recv_cnt [%d].\n",
                       event_recv_cnt);
            }
            status = sx_lib_host_ifc_recv(&user_channel.channel.fd, packet,
                                          &packet_size, &receive_info);
            if (SX_CHECK_FAIL(status)) {
                printf("Failed in sx_api_host_ifc_recv, error: %s.\n",
                       sx_status_str(status));
                goto out;
            }
            switch (receive_info.trap_id) {
            case SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT:
                async_notify_p = (sx_async_api_complete_notification_t*)packet;
                event_recv_cnt++;
                event_mac_add_del_recv_cnt++;
                if ((mac_add_api_calls != 0) && (event_mac_add_del_recv_cnt == mac_add_api_calls)) {
                    MEASURE_TIME(&mac_add_end_time);

                    printf(
                        "Received Async API Complete event for all mac addr add. type [%d] event_recv_cnt [%d] cnt [%d]\n",
                        async_notify_p->type,
                        event_recv_cnt,
                        event_mac_add_del_recv_cnt);
                    time = CALCULATE_TIME(mac_add_start_time, mac_add_end_time);
                    /* Convert Microseconds to seconds */
                    seconds = time / 1000000;
                    microsec = (time % 1000000) / 1000;
                    printf("Total time: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);
                    event_mac_add_del_recv_cnt = 0;
                    mac_add_api_calls = 0;
                }

                if ((mac_delete_api_calls != 0) && (event_mac_add_del_recv_cnt == mac_delete_api_calls)) {
                    MEASURE_TIME(&mac_del_end_time);
                    printf(
                        "Received Async API Complete event for all mac addr del. type [%d] event_recv_cnt [%d] cnt [%d]\n",
                        async_notify_p->type,
                        event_recv_cnt,
                        event_mac_add_del_recv_cnt);
                    time = CALCULATE_TIME(mac_del_start_time, mac_del_end_time);
                    /* Convert Microseconds to seconds */
                    seconds = time / 1000000;
                    microsec = (time % 1000000) / 1000;
                    printf("Total time: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);
                    event_mac_add_del_recv_cnt = 0;
                    mac_delete_api_calls = 0;
                    exit(0);
                }

                break;

            default:
                printf("Unsolicited event received with trap id [%u].\n",
                       receive_info.trap_id);
                break;
            }
        }
    }

out:
    ;
}

int main(int argc, char **argv)
{
    sx_api_handle_t       api_handle = 0;
    sx_status_t           status = SX_STATUS_SUCCESS;
    rm_resources_t        resource_limits;
    sx_chip_types_t       chip_type = SX_CHIP_TYPE_UNKNOWN;
    sx_port_attributes_t *port_attr_p = NULL;
    uint32_t              port_cnt = 0;
    uint8_t               case_num = 0;

    memset(&resource_limits, 0, sizeof(resource_limits));

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    if (SX_STATUS_SUCCESS != __get_chip_type(&chip_type)) {
        printf("ERROR: Failed to determine the current chip type.\n");
        exit(1);
    }

    /* Open SDK */
    status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(status));
        exit(1);
    }
    printf("SDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);

    /* EK remove sx_api_fdb_polling_interval_set */
#if 0
    status = sx_api_fdb_polling_interval_set(api_handle,
                                             0,
                                             9999);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: sx_api_fdb_polling_interval_set: [%s]\n", sx_status_str(status));
        exit(1);
    }
    printf("SDK API: sx_api_fdb_polling_interval_set 9999\n");
#endif


    status = sx_api_host_ifc_open(api_handle, &user_channel.channel.fd);
    if (SX_CHECK_FAIL(status)) {
        printf("Failed to open host ifc %s\n", sx_status_str(status));
        exit(1);
    }

    /* Register for port UP/DOWN event */
    user_channel.type = SX_USER_CHANNEL_TYPE_FD;
    status = sx_api_host_ifc_trap_id_register_set(api_handle, SX_ACCESS_CMD_REGISTER,
                                                  0, SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT, &user_channel);
    if (SX_CHECK_FAIL(status)) {
        printf("Failed to register for SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT event, error: %s\n", sx_status_str(status));
        exit(1);
    }
    /* create thread */
    pthread_create(&sx_ver_thread, NULL, (void*)&sx_ver_recv_thread, NULL);


    status = rm_chip_limits_get(chip_type, &resource_limits);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API rm_chip_limits_get failed: [%s]\n", sx_status_str(status));
        exit(1);
    }

    /* Get number of ports on the current chip and their attributes */
    status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, NULL, &port_cnt);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_port_device_get failed: [%s].\n", sx_status_str(status));
        exit(1);
    }

    printf("\nCurrent chip has %u system ports.\n", port_cnt);

    port_attr_p = (sx_port_attributes_t*)calloc(port_cnt, sizeof(sx_port_attributes_t));
    if (port_attr_p == NULL) {
        printf("ERROR: failed to allocated memory for port attributes.\n");
        exit(1);
    }

    status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, port_attr_p, &port_cnt);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_port_device_get failed: [%s] on retrieving attributes.\n",
               sx_status_str(status));
        exit(1);
    }

    /***********************************************************************
    *    Check UC flow:
    *        resource_limits.fdb_uc_address_max
    *        SPECTRUM2_FDB_UC_ADDRESS_MAX == 0x7D000 * 90% = 512k * 90%
    *        SPECTRUM_FDB_UC_ADDRESS_MAX == 0x3C000 * 90%  = 240k * 90% = 162k
    *
    *        Please note that during execution of the following function may be observed some Notice logs,
    *        which are expected because of the 'b8fd1119' commit. Please see 'git show b8fd1119' for more info.
    ***********************************************************************/
    /* 92160*1024 */
    /* 41,42,45, 90 - issue happened */
    /* 41 - issued happened on second time */
    /* 22,33,39,40 - works */
    /*((1024*40)+256) - sometimes works */
    /* ((1024*40)+32) - works */
    /*,((1024*40)+512) - doesn't works */
    /* ((1024*40)+512+256+128+64=41920) - doesn't work */
    /* ((1024*40)+512+256+128+32) - doesn't work */
    /* ((1024*40)+512+256+128) =41856 - doesn't work */
    /* ((1024*40)+512+256+64) - doesn't work */
    /* ((1024*40)+512+256 - 41728) - doesn't work */
    /*1024*90 = 92160 */

    __check_mac_handling_flow(api_handle,
                              FALSE,
                              port_attr_p[0].log_port,
                              ((1024 * 128 /*50*/)) /*resource_limits.fdb_uc_address_max*/,
                              &case_num);

    /***********************************************************************
    *    Check MC flow:
    *        resource_limits.fdb_mc_address_max
    *        SPECTRUM2_FDB_MC_ADDRESS_MAX == 0x7D000 * 90% = 512k * 90%
    *        SPECTRUM_FDB_MC_ADDRESS_MAX == 0x3C000 * 90%  = 240k * 90%
    *
    *        Failed to add more that 6999 entries because of the SPECTRUM_FDB_MID_MAX == 7000
    ***********************************************************************/
#if 0
    /* EK dont check MC for now. only check async */
    __check_mac_handling_flow(api_handle, TRUE, port_attr_p[0].log_port, resource_limits.fdb_mc_address_max,
                              &case_num);
#endif

    pthread_join(sx_ver_thread, NULL);
    printf("\nTest is finished.\n");

    if (status != SX_STATUS_SUCCESS) {
        exit(1);
    }
    return 0;
}
