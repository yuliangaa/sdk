/*
 * Copyright (C) 2008-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#include <stdio.h>
#include <time.h>
#include <arpa/inet.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_router.h>

/** Local macros **/
#define DEFAULT_SWID 0
#define DEFAULT_VLAN 1
#define DEFAULT_ETHER_ADDR                   \
    (sx_mac_addr_t) {                        \
        {0x00, 0x02, 0x03, 0x04, 0x05, 0x07} \
    }
#define DEFAULT_MTU 1522

#define SPECTRUM_KVD_SIZE      0x3C000
#define SPECTRUM_KVD_HASH_SIZE 0x2C000

#define SPECTRUM2_KVD_SIZE 0x7D000

void init_spectrum_router_params(sx_router_general_param_t   *general_params,
                                 sx_router_resources_param_t *router_resources)
{
    printf("\n Test is running with SPECTRUM limits. \n");

    general_params->ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params->ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params->ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE;

    router_resources->max_virtual_routers_num = 256;
    router_resources->max_router_interfaces = 1000;
    router_resources->min_ipv4_neighbor_entries = 0;
    router_resources->min_ipv6_neighbor_entries = 0;
    router_resources->min_ipv4_uc_route_entries = 0;
    router_resources->min_ipv6_uc_route_entries = 0;
    router_resources->min_ipv4_mc_route_entries = 0;
    router_resources->min_ipv6_mc_route_entries = 0;
    router_resources->max_ipv4_neighbor_entries = SPECTRUM_KVD_HASH_SIZE;
    router_resources->max_ipv6_neighbor_entries = SPECTRUM_KVD_HASH_SIZE;
    router_resources->max_ipv4_uc_route_entries = SPECTRUM_KVD_HASH_SIZE;
    router_resources->max_ipv6_uc_route_entries = SPECTRUM_KVD_HASH_SIZE;
    router_resources->max_ipv4_mc_route_entries = SPECTRUM_KVD_HASH_SIZE;
    router_resources->max_ipv6_mc_route_entries = SPECTRUM_KVD_HASH_SIZE;
}

void init_spectrum2_router_params(sx_router_general_param_t   *general_params,
                                  sx_router_resources_param_t *router_resources)
{
    printf("\n Test is running with SPECTRUM2 limits. \n");

    general_params->ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params->ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params->ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE;

    router_resources->max_virtual_routers_num = 2000;
    router_resources->max_router_interfaces = 4000;
    router_resources->min_ipv4_neighbor_entries = 0;
    router_resources->min_ipv6_neighbor_entries = 0;
    router_resources->min_ipv4_uc_route_entries = 0;
    router_resources->min_ipv6_uc_route_entries = 0;
    router_resources->min_ipv4_mc_route_entries = 0;
    router_resources->min_ipv6_mc_route_entries = 0;
    router_resources->max_ipv4_neighbor_entries = 0;
    router_resources->max_ipv6_neighbor_entries = 0;
    router_resources->max_ipv4_uc_route_entries = 0;
    router_resources->max_ipv6_uc_route_entries = 0;
    router_resources->max_ipv4_mc_route_entries = 0;
    router_resources->max_ipv6_mc_route_entries = 0;
}

sx_status_t init_router_params(sx_router_general_param_t   *general_params,
                               sx_router_resources_param_t *router_resources,
                               boolean_t                    is_spectrum2)
{
    if ((NULL == general_params) ||
        (NULL == router_resources)) {
        return SX_STATUS_ERROR;
    }

    if (TRUE == is_spectrum2) {
        init_spectrum2_router_params(general_params, router_resources);
    } else {
        init_spectrum_router_params(general_params, router_resources);
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t scale_route_operation(sx_api_handle_t api_handle, int is_spectrum2, boolean_t is_disable_l3_nh_list)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    routes_counter = 0;

    /** Router variables **/
    sx_router_general_param_t   general_params;
    sx_router_resources_param_t router_resources;

    memset(&general_params, 0, sizeof(general_params));
    memset(&router_resources, 0, sizeof(router_resources));

    /** VR variables **/
    sx_router_attributes_t router_attr;
    sx_router_id_t         vrid = 0;

    memset(&router_attr, 0, sizeof(router_attr));

    /** RIF variables **/
    sx_router_interface_param_t ifc_param;
    sx_interface_attributes_t   ifc_attr;
    sx_router_interface_t       rif = 0;

    memset(&ifc_param, 0, sizeof(ifc_param));
    memset(&ifc_attr, 0, sizeof(ifc_attr));

    /** Router variables **/
    sx_ip_prefix_t     network_addr;
    sx_uc_route_data_t uc_route_data;

    memset(&network_addr, 0, sizeof(network_addr));
    memset(&uc_route_data, 0, sizeof(uc_route_data));

    /** Time variables **/
    uint64_t        add_time_ipv4_routes = 0;
    uint64_t        del_time_ipv4_routes = 0;
    uint64_t        add_time_ipv6_routes = 0;
    uint64_t        del_time_ipv6_routes = 0;
    struct timespec tms_start;
    struct timespec tms_end;

    memset(&tms_start, 0, sizeof(tms_start));
    memset(&tms_end, 0, sizeof(tms_end));

    /** Ecmp variables **/
    sx_next_hop_t next_hop_v4_list[1];
    uint32_t      next_hop_v4_cnt;
    sx_ecmp_id_t  ecmp_id_v4 = SX_ROUTER_ECMP_ID_INVALID;

    /** Ecmp variables **/
    sx_next_hop_t next_hop_v6_list[1];
    uint32_t      next_hop_v6_cnt;
    sx_ecmp_id_t  ecmp_id_v6 = SX_ROUTER_ECMP_ID_INVALID;

    /** Init Router **/
    sx_status = init_router_params(&general_params, &router_resources, is_spectrum2);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: init_router_params failed: [%d]\n", sx_status);
        goto out;
    }

    general_params.disable_l3_nh_list = is_disable_l3_nh_list;
    sx_status = sx_api_router_init_set(api_handle, &general_params, &router_resources);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_init_set failed: [%d]\n", sx_status);
        goto out;
    }
    printf("SDK API: Router initialized\n");

    /** Creating VRID **/
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP;
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP;

    sx_status = sx_api_router_set(api_handle, SX_ACCESS_CMD_ADD, &router_attr, &vrid);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
        goto router_rollback;
    }
    printf("SDK API: VRID [%d] has been added successfully. \n", vrid);

    /** Creating RIF **/
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN;
    ifc_param.ifc.vlan.swid = DEFAULT_SWID;
    ifc_param.ifc.vlan.vlan = DEFAULT_VLAN;

    ifc_attr.mac_addr = DEFAULT_ETHER_ADDR;
    ifc_attr.mtu = DEFAULT_MTU;
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP;
    ifc_attr.multicast_ttl_threshold = 0;
    ifc_attr.loopback_enable = 1;

    sx_status = sx_api_router_interface_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &ifc_param, &ifc_attr, &rif);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_interface_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
        goto vrid_rollback;
    }
    printf("SDK API: RIF [%d] has been added successfully. \n", rif);

    /** Creating as many IPv4 UC ECMP routes as possible **/
    printf("\n Adding IPv4 UC ECMP routes... \n");

    network_addr.version = SX_IP_VERSION_IPV4;
    network_addr.prefix.ipv4.addr.s_addr = 0x0a0a0a00; /* 10.10.10.10 */
    network_addr.prefix.ipv4.mask.s_addr = 0xffffff00; /* 255.255.255.0 */

    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP;

    if (is_disable_l3_nh_list) {
        next_hop_v4_list[0].next_hop_key.type = SX_NEXT_HOP_TYPE_IP;
        next_hop_v4_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.version = SX_IP_VERSION_IPV4;
        next_hop_v4_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv4.s_addr = 0x02030002;
        next_hop_v4_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.rif = rif;
        next_hop_v4_list[0].next_hop_data.weight = 4;
        next_hop_v4_list[0].next_hop_data.action = SX_ROUTER_ACTION_FORWARD;

        sx_status = sx_api_router_ecmp_set(api_handle,
                                           SX_ACCESS_CMD_CREATE,
                                           &ecmp_id_v4,
                                           next_hop_v4_list,
                                           &next_hop_v4_cnt);
        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: SDK API sx_api_router_ecmp_set failed with cmd[SX_ACCESS_CMD_CREATE]: [%d]\n", sx_status);
            goto rif_rollback;
        }
        uc_route_data.uc_route_param.ecmp_id = ecmp_id_v4;
    }

    while (SX_STATUS_SUCCESS == sx_status) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
            break;
        }

        if (SX_STATUS_SUCCESS == sx_status) {
            routes_counter++;
            network_addr.prefix.ipv4.addr.s_addr += 0x100;
            add_time_ipv4_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        }
    }
    printf(
        " %u IPv4 UC ECMP routes have successfully been created in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
        routes_counter,
        (add_time_ipv4_routes / 1000),
        (add_time_ipv4_routes / routes_counter));

    /** Deleting all IPv4 UC ECMP routes **/
    printf("\n Deleting %d IPv4 UC ECMP routes... \n", routes_counter);

    routes_counter = 0;
    sx_status = SX_STATUS_SUCCESS;

    network_addr.prefix.ipv4.addr.s_addr = 0x0a0a0a00; /* 10.10.10.10 */

    while (SX_STATUS_SUCCESS == sx_status) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ENTRY_NOT_FOUND != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_DELETED]: [%d]\n",
                   sx_status);
            goto rif_rollback;
        }

        if (SX_STATUS_SUCCESS == sx_status) {
            routes_counter++;
            network_addr.prefix.ipv4.addr.s_addr += 0x100;
            del_time_ipv4_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        }
    }
    printf(
        " %u IPv4 UC ECMP routes have successfully been deleted in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
        routes_counter,
        (del_time_ipv4_routes / 1000),
        (del_time_ipv4_routes / routes_counter));

    /** Creating as many IPv6 UC ECMP routes as possible **/
    printf("\n Adding IPv6 UC ECMP routes... \n");

    routes_counter = 0;
    sx_status = SX_STATUS_SUCCESS;

    network_addr.version = SX_IP_VERSION_IPV6;

    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[3] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[2] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] = 0x01020000;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[0] = 0x02010101;

    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[3] = 0x0;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[2] = 0x0;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[1] = 0xffffffff;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[0] = 0xffffffff;

    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP;

    next_hop_v6_list[0].next_hop_key.type = SX_NEXT_HOP_TYPE_IP;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.version = SX_IP_VERSION_IPV6;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv6.__in6_u.__u6_addr32[3] =
        0x1234;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv6.__in6_u.__u6_addr32[2] =
        0x1234;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv6.__in6_u.__u6_addr32[1] =
        0x1234;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv6.__in6_u.__u6_addr32[0] =
        0x02008099;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.rif = rif;

    next_hop_v6_list[0].next_hop_data.weight = 4;
    next_hop_v6_list[0].next_hop_data.action = SX_ROUTER_ACTION_FORWARD;

    sx_status = sx_api_router_ecmp_set(api_handle,
                                       SX_ACCESS_CMD_CREATE,
                                       &ecmp_id_v6,
                                       next_hop_v6_list,
                                       &next_hop_v6_cnt);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_ecmp_set failed with cmd[SX_ACCESS_CMD_CREATE]: [%d]\n", sx_status);
        goto ecmp_rollback;
    }
    uc_route_data.uc_route_param.ecmp_id = ecmp_id_v6;

    while (SX_STATUS_SUCCESS == sx_status) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
            break;
        }

        if (SX_STATUS_SUCCESS == sx_status) {
            routes_counter++;
            network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] += 0x100;
            add_time_ipv6_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        }
    }
    printf(
        " %u IPv6 UC ECMP routes have successfully been created in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
        routes_counter,
        (add_time_ipv6_routes / 1000),
        (add_time_ipv6_routes / routes_counter));

    /** Deleting all IPv6 UC ECMP routes **/
    printf("\n Deleting %d IPv6 UC ECMP routes... \n", routes_counter);

    routes_counter = 0;
    sx_status = SX_STATUS_SUCCESS;

    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] = 0x01020000;

    while (SX_STATUS_SUCCESS == sx_status) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ENTRY_NOT_FOUND != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_DELETED]: [%d]\n",
                   sx_status);
            goto rif_rollback;
        }

        if (SX_STATUS_SUCCESS == sx_status) {
            routes_counter++;
            network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] += 0x100;
            del_time_ipv6_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        }
    }
    printf(
        " %u IPv6 UC ECMP routes have successfully been deleted in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
        routes_counter,
        (del_time_ipv6_routes / 1000),
        (del_time_ipv6_routes / routes_counter));

    add_time_ipv4_routes = 0;
    del_time_ipv4_routes = 0;
    add_time_ipv6_routes = 0;
    del_time_ipv6_routes = 0;

    /** Creating as many IPv4 UC local routes as possible **/
    printf("\n Adding IPv4 UC local routes... \n");

    routes_counter = 0;
    sx_status = SX_STATUS_SUCCESS;

    network_addr.version = SX_IP_VERSION_IPV4;
    network_addr.prefix.ipv4.addr.s_addr = 0x0a0a0a00; /* 10.10.10.10 */
    network_addr.prefix.ipv4.mask.s_addr = 0xffffff00; /* 255.255.255.0 */

    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL;
    uc_route_data.uc_route_param.local_egress_rif = rif;

    while (SX_STATUS_SUCCESS == sx_status) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
            break;
        }

        if (SX_STATUS_SUCCESS == sx_status) {
            routes_counter++;
            network_addr.prefix.ipv4.addr.s_addr += 0x100;
            add_time_ipv4_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        }
    }

    printf(
        " %u IPv4 UC local routes have successfully been created in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
        routes_counter,
        (add_time_ipv4_routes / 1000),
        (add_time_ipv4_routes / routes_counter));

    /** Deleting all IPv4 UC local routes **/
    printf("\n Deleting %d IPv4 UC local routes... \n", routes_counter);

    routes_counter = 0;
    sx_status = SX_STATUS_SUCCESS;

    network_addr.prefix.ipv4.addr.s_addr = 0x0a0a0a00; /* 10.10.10.10 */

    while (SX_STATUS_SUCCESS == sx_status) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ENTRY_NOT_FOUND != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_DELETED]: [%d]\n",
                   sx_status);
            goto rif_rollback;
        }

        if (SX_STATUS_SUCCESS == sx_status) {
            routes_counter++;
            network_addr.prefix.ipv4.addr.s_addr += 0x100;
            del_time_ipv4_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        }
    }
    printf(
        " %u IPv4 UC local routes have successfully been deleted in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
        routes_counter,
        (del_time_ipv4_routes / 1000),
        (del_time_ipv4_routes / routes_counter));

    /** Creating as many IPv6 UC local routes as possible **/
    printf("\n Adding IPv6 UC local routes... \n");

    routes_counter = 0;
    sx_status = SX_STATUS_SUCCESS;

    network_addr.version = SX_IP_VERSION_IPV6;

    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[3] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[2] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] = 0x01020000;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[0] = 0x02010101;

    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[3] = 0x0;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[2] = 0x0;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[1] = 0xffffffff;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[0] = 0xffffffff;

    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL;
    uc_route_data.uc_route_param.local_egress_rif = rif;

    while (SX_STATUS_SUCCESS == sx_status) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
            break;
        }

        if (SX_STATUS_SUCCESS == sx_status) {
            routes_counter++;
            network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] += 0x100;
            add_time_ipv6_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        }
    }
    printf(
        " %u IPv6 UC local routes have successfully been created in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
        routes_counter,
        (add_time_ipv6_routes / 1000),
        (add_time_ipv6_routes / routes_counter));

    /** Deleting all IPv6 UC local routes **/
    printf("\n Deleting %d IPv6 UC local routes... \n", routes_counter);

    routes_counter = 0;
    sx_status = SX_STATUS_SUCCESS;

    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] = 0x01020000;

    while (SX_STATUS_SUCCESS == sx_status) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ENTRY_NOT_FOUND != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_DELETED]: [%d]\n",
                   sx_status);
            goto rif_rollback;
        }

        if (SX_STATUS_SUCCESS == sx_status) {
            routes_counter++;
            network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] += 0x100;
            del_time_ipv6_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        }
    }
    printf(
        " %u IPv6 UC local routes have successfully been deleted in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
        routes_counter,
        (del_time_ipv6_routes / 1000),
        (del_time_ipv6_routes / routes_counter));

    printf("\nFree resources...\n");

ecmp_rollback:
    if (is_disable_l3_nh_list) {
        if (ecmp_id_v4 != SX_ROUTER_ECMP_ID_INVALID) {
            sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_DESTROY, &ecmp_id_v4, NULL, &next_hop_v4_cnt);
        }
        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: SDK API sx_api_router_ecmp_set failed with cmd[SX_ACCESS_CMD_DESTROY]: [%d]\n", sx_status);
            exit(1);
        }
        printf("SDK API: ECMP IPv4 has been deleted successfully. \n");

        if (ecmp_id_v6 != SX_ROUTER_ECMP_ID_INVALID) {
            sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_DESTROY, &ecmp_id_v6, NULL, &next_hop_v6_cnt);
        }
        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: SDK API sx_api_router_ecmp_set failed with cmd[SX_ACCESS_CMD_DESTROY]: [%d]\n", sx_status);
            exit(1);
        }
        printf("SDK API: ECMP IPv6 has been deleted successfully. \n");
    }
    /** Deleting RIF **/
rif_rollback:
    sx_status = sx_api_router_interface_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, NULL, NULL, &rif);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_interface_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: RIF [%d] has been deleted successfully. \n", rif);

vrid_rollback:
    /** Deleting VRID **/
    sx_status = sx_api_router_set(api_handle, SX_ACCESS_CMD_DELETE, NULL, &vrid);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: VRID [%d] has been deleted successfully. \n", vrid);

router_rollback:
    /** Router deinit **/
    sx_status = sx_api_router_deinit_set(api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: Failed to perform router deinit\n");
        exit(1);
    }
    printf("SDK API: Router deinit has been performed successfully\n");
out:
    return sx_status;
}

int main(int argc, char **argv)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    sx_api_handle_t api_handle = 0;
    boolean_t       is_spectrum2 = FALSE;

    /** Handle system type parameter **/
    if (argc > 2) {
        printf("ERROR: too many arguments [%d]\n", argc);
        exit(1);
    }

    if (2 == argc) {
        if (0 == strcmp(argv[1], "phoenix")) {
            is_spectrum2 = TRUE;
        } else {
            printf("ERROR: invalid parameter [%s], should be 'phoenix'\n", argv[1]);
            exit(1);
        }
    }

    /** Open SDK **/
    sx_status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_open failed: [%d]\n", sx_status);
        exit(1);
    }
    printf("\nSDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);
    printf("\nSDK Route scale test with next hop list route operations disabled");
    printf("\n*****************************************************************");
    scale_route_operation(api_handle, is_spectrum2, SX_ROUTER_ENABLE_STATE_ENABLE);

    /** Close SDK **/
    sx_status = sx_api_close(&api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_close failed: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: Close API handle: 0x%" PRIx64 "\n", api_handle);

    printf("\nEnd.\n");
    return 0;
}
