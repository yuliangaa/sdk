/*
 * Copyright (C) 2008-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#include <stdio.h>
#include <time.h>
#include <arpa/inet.h>
#include <errno.h>
#include <unistd.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sdk/sx_api_rm.h>


/** Local macros **/
#define DEFAULT_SWID 0
#define DEFAULT_VLAN 1
#define DEFAULT_ETHER_ADDR                   \
    (sx_mac_addr_t) {                        \
        {0x00, 0x02, 0x03, 0x04, 0x05, 0x07} \
    }
#define DEFAULT_MTU 1522

#define SX_MEM_CLR(src)     (memset(&(src), 0, sizeof(src)))
#define SX_MEM_CLR_P(src_p) (memset((src_p), 0, sizeof(*(src_p))))
#define TEST_COUNT 100000

void mypause(void)
{
    int prompt = 0;

    printf("Press [Enter] to continue . . .\n");
    do {
        prompt = getchar();
    } while((prompt != '\n') && (prompt != EOF));
}


sx_status_t init_router_params(sx_router_general_param_t   *general_params,
                               sx_router_resources_param_t *router_resources)
{
    printf("\n Test is running with SPECTRUM2 limits. \n");
    SX_MEM_CLR_P(general_params);
    SX_MEM_CLR_P(router_resources);


    general_params->ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params->ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params->ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->async_mode_enable = FALSE;
    general_params->router_async_params.completion_info_flush_count = 1;
    general_params->router_async_params.completion_info_send_interval = 1;

    router_resources->max_virtual_routers_num = 2000;
    router_resources->max_router_interfaces = 4000;
    router_resources->min_ipv4_neighbor_entries = 0;
    router_resources->min_ipv6_neighbor_entries = 0;
    router_resources->min_ipv4_uc_route_entries = 0;
    router_resources->min_ipv6_uc_route_entries = 0;
    router_resources->min_ipv4_mc_route_entries = 0;
    router_resources->min_ipv6_mc_route_entries = 0;
    router_resources->max_ipv4_neighbor_entries = 0;
    router_resources->max_ipv6_neighbor_entries = 0;
    router_resources->max_ipv4_uc_route_entries = 0;
    router_resources->max_ipv6_uc_route_entries = 0;
    router_resources->max_ipv4_mc_route_entries = 0;
    router_resources->max_ipv6_mc_route_entries = 0;

    return SX_STATUS_SUCCESS;
}

sx_status_t __prepare_unique_mac_entries(sx_mac_addr_t *mac_addr_p, uint32_t entries_num)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    uint32_t    n = 0;
    uint32_t    octet3 = 0x00, octet4 = 0x00, octet5 = 0x00;

    if (mac_addr_p == NULL) {
        status = SX_STATUS_PARAM_NULL;
        printf("ERROR: 'mac_entry_p' is NULL: [%s]\n", sx_status_str(status));
        goto out;
    }

    /*
     *  We don't expect to have more different MACs here than 255*255*255, hence the following assert should not happen.
     *  255 * 255 * 255 = 16581375
     */
    if (entries_num > (0xFF * 0xFF * 0xFF)) {
        status = SX_STATUS_ERROR;
        printf("ERROR: entries_num = %u and it is too big.\n", entries_num);
        goto out;
    }

    for (n = 0; n < entries_num; n++) {
        /* in MC MAC first octet must be equal to 0x01 */
        mac_addr_p[n].ether_addr_octet[0] = 0x00;
        mac_addr_p[n].ether_addr_octet[1] = 0x4d;
        mac_addr_p[n].ether_addr_octet[2] = 0x5e;
        if (octet5 >= 0xFF) {
            octet5 = 0x00;
            octet4++;
        }
        if (octet4 >= 0xFF) {
            octet4 = 0x00;
            octet3++;
        }
        /* we don't expect to have more different MAC here than 255*255*255, hence the following assert should not happen */
        assert(octet3 < 255);
        octet5++;

        mac_addr_p[n].ether_addr_octet[3] = octet3;
        mac_addr_p[n].ether_addr_octet[4] = octet4;
        mac_addr_p[n].ether_addr_octet[5] = octet5;
    }

out:
    return status;
}


sx_status_t scale_neigh_operation(sx_api_handle_t api_handle, uint32_t test_count)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    neigh_counter = 0;


    /** Router variables **/
    sx_router_general_param_t   general_params;
    sx_router_resources_param_t router_resources;


    SX_MEM_CLR(general_params);
    SX_MEM_CLR(router_resources);

    /** VR variables **/
    sx_router_attributes_t router_attr;
    sx_router_id_t         vrid = 0;

    SX_MEM_CLR(router_attr);

    /** RIF variables **/
    sx_router_interface_param_t ifc_param;
    sx_interface_attributes_t   ifc_attr;
    sx_router_interface_t       rif = 0;

    SX_MEM_CLR(ifc_param);
    SX_MEM_CLR(ifc_attr);

    /** Router variables **/
    sx_ip_addr_t       ip_addr;
    sx_ip_prefix_t     network_addr;
    sx_uc_route_data_t uc_route_data;
    sx_neigh_data_t    neigh_data;
    sx_mac_addr_t     *mac_addr_p = NULL;

    SX_MEM_CLR(network_addr);
    SX_MEM_CLR(uc_route_data);
    SX_MEM_CLR(ip_addr);
    /** Time variables **/
    uint64_t        add_time_neighbors = 0;
    uint64_t        del_time_neighbors = 0;
    struct timespec tms_start;
    struct timespec tms_end;

    SX_MEM_CLR(tms_start);
    SX_MEM_CLR(tms_end);


    /** Init Router **/
    sx_status = init_router_params(&general_params, &router_resources);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: init_router_params failed: [%d]\n", sx_status);
        goto out;
    }

    general_params.disable_l3_nh_list = TRUE;
    sx_status = sx_api_router_init_set(api_handle, &general_params, &router_resources);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_init_set failed: [%d]\n", sx_status);
        goto out;
    }
    printf("SDK API: Router initialized\n");


    /** Creating VRID **/
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP;
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP;

    sx_status = sx_api_router_set(api_handle, SX_ACCESS_CMD_ADD, &router_attr, &vrid);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
        goto router_rollback;
    }
    printf("SDK API: VRID [%d] has been added successfully. \n", vrid);

    /** Creating RIF **/
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN;
    ifc_param.ifc.vlan.swid = DEFAULT_SWID;
    ifc_param.ifc.vlan.vlan = DEFAULT_VLAN;

    ifc_attr.mac_addr = DEFAULT_ETHER_ADDR;
    ifc_attr.mtu = DEFAULT_MTU;
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP;
    ifc_attr.multicast_ttl_threshold = 0;
    ifc_attr.loopback_enable = 1;

    sx_status = sx_api_router_interface_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &ifc_param, &ifc_attr, &rif);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_interface_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
        goto vrid_rollback;
    }
    printf("SDK API: RIF [%d] has been added successfully. \n", rif);

    network_addr.version = SX_IP_VERSION_IPV4;
    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL;
    uc_route_data.uc_route_param.local_egress_rif = rif;


    network_addr.version = SX_IP_VERSION_IPV4;
    network_addr.prefix.ipv4.addr.s_addr = 0x0;
    network_addr.prefix.ipv4.mask.s_addr = 0x0;

    sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &network_addr, &uc_route_data);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
        goto vrid_rollback;
    }


    mac_addr_p = (sx_mac_addr_t *)calloc(test_count, sizeof(sx_mac_addr_t));
    if (mac_addr_p == NULL) {
        printf("ERROR: failed to allocated memory for MAC entries.\n");
        exit(1);
    }

    __prepare_unique_mac_entries(mac_addr_p, test_count);

    neigh_data.action = SX_ROUTER_ACTION_FORWARD;
    neigh_data.rif = rif;

    mypause();
    /** Creating as many IPv4 Neighbor as possible **/
    printf("Creating [%u]IPv4 Neighbors\n", test_count);

    ip_addr.version = SX_IP_VERSION_IPV4;
    ip_addr.addr.ipv4.s_addr = 0x0a0a0a00; /* 10.10.10.10 */

    while (1) {
        neigh_data.mac_addr = mac_addr_p[neigh_counter];

        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_neigh_set(api_handle, SX_ACCESS_CMD_ADD, rif, &ip_addr, &neigh_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: SDK API sx_api_router_neigh_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
            break;
        }

        if ((SX_STATUS_SUCCESS == sx_status)) {
            neigh_counter++;
            ip_addr.addr.ipv4.s_addr += 0x100;
            if (neigh_counter % 100 == 0) {
                printf("Added neighbor number :%d\r", neigh_counter);
            }
            add_time_neighbors += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                  (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        }

        if ((SX_STATUS_NO_RESOURCES == sx_status) || (neigh_counter == test_count)) {
            break;
        }
    }

    printf(
        " %u IPv4 neighbors have successfully been created in %" PRIu64 " ms, %" PRIu64 " us for one entry. \n",
        neigh_counter,
        (add_time_neighbors / 1000),
        (add_time_neighbors / neigh_counter));


    mypause();


    /* Reset IP */
    ip_addr.addr.ipv4.s_addr = 0x0a0a0a00; /* 10.10.10.10 */
    /** Deleting all IPv4 Neighbors **/
    printf("\n Deleting %u IPv4 Neighbors... \n", neigh_counter);
    neigh_counter = 0;
    sx_status = SX_STATUS_SUCCESS;
    while (1) {
        neigh_data.mac_addr = mac_addr_p[neigh_counter];
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_neigh_set(api_handle, SX_ACCESS_CMD_DELETE, rif, &ip_addr, &neigh_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ENTRY_NOT_FOUND != sx_status)) {
            printf("ERROR: SDK API sx_api_router_neigh_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n",
                   sx_status);
            break;
        }

        if (SX_STATUS_SUCCESS == sx_status) {
            neigh_counter++;
            ip_addr.addr.ipv4.s_addr += 0x100;
            if (neigh_counter % 100 == 0) {
                printf("Deleted neighbor number :%u\r", neigh_counter);
            }
            del_time_neighbors += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                  (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        } else {
            /* SX_STATUS_ENTRY_NOT_FOUND == sx_status */
            break;
        }
    }

    printf(
        " %u IPv4 Neighbors have successfully been deleted in %" PRIu64 " ms, %" PRIu64 " us for one entry. \n",
        neigh_counter,
        (del_time_neighbors / 1000),
        (del_time_neighbors / neigh_counter));


    mypause();

    /** Creating as many IPv6 Neighbor as possible **/
    printf("Creating [%u]IPv6 Neighbors\n", test_count);

    neigh_counter = 0;
    del_time_neighbors = 0;
    add_time_neighbors = 0;

    sx_status = SX_STATUS_SUCCESS;
    ip_addr.version = SX_IP_VERSION_IPV6;

    ip_addr.addr.ipv6.__in6_u.__u6_addr32[3] = 0x0;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[2] = 0x0;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[1] = 0x01020000;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[0] = 0x02010101;

    ip_addr.addr.ipv6.__in6_u.__u6_addr32[3] = 0x0;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[2] = 0x0;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[1] = 0xffffffff;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[0] = 0xffffffff;

    while (1) {
        neigh_data.mac_addr = mac_addr_p[neigh_counter];
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_neigh_set(api_handle, SX_ACCESS_CMD_ADD, rif, &ip_addr, &neigh_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);


        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: SDK API sx_api_router_neigh_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
            break;
        }

        if ((SX_STATUS_SUCCESS == sx_status)) {
            neigh_counter++;
            ip_addr.addr.ipv6.__in6_u.__u6_addr32[1] += 0x100;
            if (neigh_counter % 100 == 0) {
                printf("Added neighbor number :%u\r", neigh_counter);
            }
            add_time_neighbors += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                  (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        }

        if ((SX_STATUS_NO_RESOURCES == sx_status) || (neigh_counter == test_count)) {
            break;
        }
    }

    printf(
        " %u IPv6 neighbors have successfully been created in %" PRIu64 " ms, %" PRIu64 " us for one entry. \n",
        neigh_counter,
        (add_time_neighbors / 1000),
        (add_time_neighbors / neigh_counter));

    mypause();

    del_time_neighbors = 0;
    add_time_neighbors = 0;
    neigh_counter = 0;
    sx_status = SX_STATUS_SUCCESS;
    ip_addr.version = SX_IP_VERSION_IPV6;

    ip_addr.addr.ipv6.__in6_u.__u6_addr32[3] = 0x0;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[2] = 0x0;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[1] = 0x01020000;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[0] = 0x02010101;

    ip_addr.addr.ipv6.__in6_u.__u6_addr32[3] = 0x0;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[2] = 0x0;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[1] = 0xffffffff;
    ip_addr.addr.ipv6.__in6_u.__u6_addr32[0] = 0xffffffff;
    while (1) {
        neigh_data.mac_addr = mac_addr_p[neigh_counter];
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_neigh_set(api_handle, SX_ACCESS_CMD_DELETE, rif, &ip_addr, &neigh_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ENTRY_NOT_FOUND != sx_status)) {
            printf("ERROR: SDK API sx_api_router_neigh_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n",
                   sx_status);
            break;
        }

        if (SX_STATUS_SUCCESS == sx_status) {
            neigh_counter++;
            ip_addr.addr.ipv6.__in6_u.__u6_addr32[1] += 0x100;
            if (neigh_counter % 100 == 0) {
                printf("Deleted neighbor number :%u\r", neigh_counter);
            }
            del_time_neighbors += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                  (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        } else {
            /* SX_STATUS_ENTRY_NOT_FOUND == sx_status */
            break;
        }
    }

    printf(
        " %u IPv6 neighbors have successfully been deleted in %" PRIu64 " ms, %" PRIu64 " us for one entry. \n",
        neigh_counter,
        (del_time_neighbors / 1000),
        (del_time_neighbors / neigh_counter));


    printf("\nFree resources...\n");
    mypause();


    sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, &network_addr, &uc_route_data);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n", sx_status);
        exit(1);
    }

    printf("SDK API: IPv4 Local route has been deleted successfully. \n");

    /** Deleting RIF **/
    sx_status = sx_api_router_interface_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, NULL, NULL, &rif);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_interface_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: RIF [%d] has been deleted successfully. \n", rif);

vrid_rollback:
    /** Deleting VRID **/
    sx_status = sx_api_router_set(api_handle, SX_ACCESS_CMD_DELETE, NULL, &vrid);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: VRID [%d] has been deleted successfully. \n", vrid);

router_rollback:
    /** Router deinit **/
    sx_status = sx_api_router_deinit_set(api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: Failed to perform router deinit\n");
        exit(1);
    }


    printf("SDK API: Router deinit has been performed successfully\n");

out:
    if (mac_addr_p != NULL) {
        free(mac_addr_p);
    }


    return sx_status;
}

int main(int argc, char **argv)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    sx_api_handle_t api_handle = 0;
    uint32_t        test_count = TEST_COUNT;

    if (argc > 2) {
        printf("ERROR: too many arguments [%d]\n", argc);
        exit(1);
    }

    if (argc == 2) {
        test_count = atoi(argv[1]);
        if (test_count <= 0) {
            test_count = TEST_COUNT;
        }
    }

    /** Open SDK **/
    sx_status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_open failed: [%d]\n", sx_status);
        exit(1);
    }

    printf("\nSDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);
    printf("\n*****************************************************************");
    scale_neigh_operation(api_handle, test_count);

    /** Close SDK **/
    sx_status = sx_api_close(&api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_close failed: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: Close API handle: 0x%" PRIx64 "\n", api_handle);


    printf("\nEnd.\n");
    return 0;
}
