/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <time.h>
#include <arpa/inet.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sdk/sx_api_port.h>

/** Local macros **/
#define MAX_VRID          4000
#define MAX_RIF           8000
#define MAX_VALID_VLAN_ID 4094
#define VRID_INDEX        0
#define DEVICE_ID         1
#define SWID              0
#define DEFAULT_ETHER_ADDR                   \
    (sx_mac_addr_t) {                        \
        {0x00, 0x02, 0x03, 0x04, 0x05, 0x07} \
    }

boolean_t is_reduced_rif_cntr_mode = FALSE;
boolean_t is_enhanced_rif_cntr = FALSE;

sx_status_t get_spectrum_resources(uint32_t *max_vrs, uint32_t *max_rifs)
{
    if ((NULL == max_vrs) ||
        (NULL == max_rifs)) {
        return SX_STATUS_ERROR;
    }

    *max_vrs = 256;
    *max_rifs = 1000;

    return SX_STATUS_SUCCESS;
}

sx_status_t get_spectrum2_resources(uint32_t *max_vrs, uint32_t *max_rifs)
{
    if ((NULL == max_vrs) ||
        (NULL == max_rifs)) {
        return SX_STATUS_ERROR;
    }

    *max_vrs = 2000;
    *max_rifs = 4000;

    return SX_STATUS_SUCCESS;
}

sx_status_t get_spectrum4_resources(uint32_t *max_vrs, uint32_t *max_rifs)
{
    if ((NULL == max_vrs) ||
        (NULL == max_rifs)) {
        return SX_STATUS_ERROR;
    }

    *max_vrs = 4000;
    *max_rifs = 8000;

    return SX_STATUS_SUCCESS;
}

sx_status_t init_router_params(sx_router_general_param_t   *general_params,
                               sx_router_resources_param_t *router_resources,
                               sx_chip_types_t              chip_type)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    max_vrs = 0;
    uint32_t    max_rifs = 0;

    if ((NULL == general_params) ||
        (NULL == router_resources)) {
        return SX_STATUS_ERROR;
    }

    if (chip_type == SX_CHIP_TYPE_SPECTRUM2) {
        sx_status = get_spectrum2_resources(&max_vrs, &max_rifs);
    } else if ((chip_type == SX_CHIP_TYPE_SPECTRUM4) || (chip_type == SX_CHIP_TYPE_SPECTRUM5)) {
        sx_status = get_spectrum4_resources(&max_vrs, &max_rifs);
    } else {
        sx_status = get_spectrum_resources(&max_vrs, &max_rifs);
    }

    if (SX_STATUS_SUCCESS != sx_status) {
        return sx_status;
    }

    general_params->ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params->ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE;

    router_resources->max_virtual_routers_num = max_vrs;
    router_resources->max_router_interfaces = max_rifs;
    router_resources->min_ipv4_neighbor_entries = 10;
    router_resources->min_ipv6_neighbor_entries = 10;
    router_resources->min_ipv4_uc_route_entries = 10;
    router_resources->min_ipv6_uc_route_entries = 10;
    router_resources->min_ipv4_mc_route_entries = 0;
    router_resources->min_ipv6_mc_route_entries = 0;
    router_resources->max_ipv4_neighbor_entries = max_rifs;
    router_resources->max_ipv6_neighbor_entries = max_rifs;
    router_resources->max_ipv4_uc_route_entries = max_rifs;
    router_resources->max_ipv6_uc_route_entries = max_rifs;
    router_resources->max_ipv4_mc_route_entries = 0;
    router_resources->max_ipv6_mc_route_entries = 0;
    if (is_reduced_rif_cntr_mode) {
        router_resources->reduced_rif_counters = TRUE;
    }

    return SX_STATUS_SUCCESS;
}


int main(int argc, char **argv)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    sx_api_handle_t       api_handle = 0;
    uint32_t              vr_counter = 0;
    uint32_t              rif_counter = 0;
    sx_port_log_id_t      vport = 0;
    sx_vlan_id_t          vlan_id = 0;
    sx_port_log_id_t      log_port = 0;
    uint32_t              i = 0;
    uint32_t              port_cnt = 0;
    sx_port_attributes_t *port_attr_p = NULL;
    sx_chip_types_t       chip_type = SX_CHIP_TYPE_UNKNOWN;

    /** Router variables **/
    sx_router_general_param_t   general_params;
    sx_router_resources_param_t router_resources;

    memset(&general_params, 0, sizeof(general_params));
    memset(&router_resources, 0, sizeof(router_resources));

    /** VR variables **/
    sx_router_attributes_t router_attr;
    sx_router_id_t         vrids_table[MAX_VRID];

    memset(&router_attr, 0, sizeof(router_attr));
    memset(vrids_table, 0, sizeof(vrids_table));

    /** RIF variables **/
    sx_router_interface_param_t ifc_param;
    sx_interface_attributes_t   ifc_attr;
    sx_router_interface_t       rifs_table[MAX_RIF];
    sx_router_counter_id_t      rif_cntrs[MAX_RIF];

    memset(&ifc_param, 0, sizeof(ifc_param));
    memset(&ifc_attr, 0, sizeof(ifc_attr));
    memset(rifs_table, 0, sizeof(rifs_table));

    /** Time variables **/
    uint64_t        add_time_vrs = 0;
    uint64_t        add_time_rifs = 0;
    uint64_t        edit_time_vrs = 0;
    uint64_t        edit_time_rifs = 0;
    uint64_t        get_time_vrs = 0;
    uint64_t        get_time_rifs = 0;
    uint64_t        del_time_vrs = 0;
    uint64_t        del_time_rifs = 0;
    struct timespec tms_start;
    struct timespec tms_end;

    memset(&tms_start, 0, sizeof(tms_start));
    memset(&tms_end, 0, sizeof(tms_end));


    /** Handle system type parameter **/
    if (argc >= 2) {
        if ((0 == strcmp(argv[1], "phoenix")) ||
            (0 == strcmp(argv[1], "firebird"))) {
            chip_type = SX_CHIP_TYPE_SPECTRUM2;  /* number of VRIDs and RIFs is the same */
        } else if (0 == strcmp(argv[1], "griffin")) {
            chip_type = SX_CHIP_TYPE_SPECTRUM4;
        } else if (0 == strcmp(argv[1], "flamingo")) {
            chip_type = SX_CHIP_TYPE_SPECTRUM5;
        } else {
            chip_type = SX_CHIP_TYPE_SPECTRUM;
        }
    }
    if (argc > 2) {
        if (chip_type >= SX_CHIP_TYPE_SPECTRUM4) {
            if (0 == strcmp(argv[2], "reduced")) {
                is_reduced_rif_cntr_mode = TRUE;
            }
            if (argc > 3) {
                if (0 == strcmp(argv[3], "extended")) {
                    is_enhanced_rif_cntr = TRUE;
                }
            }
        } else {
            printf("ERROR: too many arguments [%d]\n", argc);
            exit(1);
        }
    }


    /** Open SDK **/
    sx_status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("\nSDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);


    /** Init Router **/
    sx_status = init_router_params(&general_params, &router_resources, chip_type);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: init_router_params failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_router_init_set(api_handle, &general_params, &router_resources);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_init_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: Router initialized\n");


    /** Creating as many VRs as possible **/
    printf("\nCreating as many unicast IPv4 VRs as possible...\n");

    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP;
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP;

    while (SX_STATUS_SUCCESS == sx_status) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_set(api_handle,
                                      SX_ACCESS_CMD_ADD,
                                      &router_attr,
                                      &(vrids_table[vr_counter]));
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: Failed to create VR, iteration #%u\n", vr_counter);
            exit(1);
        }

        add_time_vrs += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                        (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        vr_counter++;
    }
    vr_counter--;
    printf("%u VRs have successfully been created in %" PRIu64 " ms.\n", vr_counter, (add_time_vrs / 1000));


    /** Editing all VRs **/
    printf("\nEditing each VR...\n");

    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP;
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP;

    for (i = 0; i < vr_counter; i++) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_set(api_handle,
                                      SX_ACCESS_CMD_EDIT,
                                      &router_attr,
                                      &(vrids_table[i]));
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: Failed to edit VR, iteration #%u\n", i);
            exit(1);
        }

        edit_time_vrs += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                         (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
    }
    printf("%u VRs have successfully been edited in %" PRIu64 " ms.\n", vr_counter, (edit_time_vrs / 1000));


    /** Creating as many RIFs as possible **/
    printf("\nCreating as many RIFs as possible...\n");
    sx_status = SX_STATUS_SUCCESS;

    /* To verify scale for the Griffin we need to create 8K RIFs, what is impossible with VLAN type of RIFs,
     *  because every RIF need to use different VLAN ID. So the maximum number of RIFs with type SX_L2_INTERFACE_TYPE_VLAN is 4094.
     *  RIFs with type SX_L2_INTERFACE_TYPE_VPORT don't have such limitation, because VPORT is a combination of VLAN + log_port.
     */

    if (chip_type >= SX_CHIP_TYPE_SPECTRUM4) {
        ifc_param.type = SX_L2_INTERFACE_TYPE_VPORT;

        sx_status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, NULL, &port_cnt);
        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: SDK API sx_api_port_device_get failed: [%s].\n", sx_status_str(sx_status));
            exit(1);
        }

        port_attr_p = (sx_port_attributes_t*)calloc(port_cnt, sizeof(sx_port_attributes_t));
        if (port_attr_p == NULL) {
            printf("ERROR: failed to allocated memory for port attributes.\n");
            exit(1);
        }

        sx_status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, port_attr_p, &port_cnt);
        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: SDK API sx_api_port_device_get failed: [%s] on retrieving attributes.\n",
                   sx_status_str(sx_status));
            exit(1);
        }
    } else {
        ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN;
        ifc_param.ifc.vlan.swid = 0;
    }

    ifc_attr.mac_addr = DEFAULT_ETHER_ADDR;
    ifc_attr.mtu = 2000;
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP;
    ifc_attr.multicast_ttl_threshold = 0;
    ifc_attr.loopback_enable = 1;


    while (SX_STATUS_SUCCESS == sx_status) {
        /* create related counters */
        if (is_enhanced_rif_cntr) {
            sx_router_counter_attributes_t cntr_attributes;
            cntr_attributes.type = SX_ROUTER_COUNTER_TYPE_ENHANCED;
            sx_status =
                sx_api_router_counter_extended_set(api_handle, SX_ACCESS_CMD_CREATE, cntr_attributes,
                                                   &(rif_cntrs[rif_counter]));
        } else {
            sx_status = sx_api_router_counter_set(api_handle, SX_ACCESS_CMD_CREATE, &(rif_cntrs[rif_counter]));
        }
        if (sx_status != SX_STATUS_SUCCESS) {
            if (SX_STATUS_NO_RESOURCES != sx_status) {
                printf("ERROR: SDK API sx_api_router_counter_set CREATE failed: [%s], rif_counter:%u\n",
                       sx_status_str(sx_status), rif_counter);
                exit(1);
            }
            printf("DBG: no more resource: total created %d rif counters.\n", rif_counter);
            break;
        }

        if (chip_type >= SX_CHIP_TYPE_SPECTRUM4) {
            if (rif_counter >= MAX_VALID_VLAN_ID) {
                vlan_id = rif_counter + 1 - MAX_VALID_VLAN_ID;
                log_port = port_attr_p[1].log_port;
            } else {
                vlan_id = rif_counter + 1;
                log_port = port_attr_p[0].log_port;
            }

            sx_status = sx_api_port_vport_set(api_handle, SX_ACCESS_CMD_ADD, log_port, vlan_id, &vport);
            if (SX_STATUS_SUCCESS != sx_status) {
                printf("ERROR: Failed to create VPORT, iteration #%u, VLAN_ID %d, log_port 0x%x\n",
                       rif_counter,
                       vlan_id,
                       log_port);
                exit(1);
            }

            ifc_param.ifc.vport.vport = vport;
        } else {
            /* You can create only one RIF per VLAN */
            ifc_param.ifc.vlan.vlan = rif_counter + 1;
        }

        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_interface_set(api_handle,
                                                SX_ACCESS_CMD_ADD,
                                                vrids_table[VRID_INDEX],
                                                &ifc_param,
                                                &ifc_attr,
                                                &(rifs_table[rif_counter]));
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: Failed to create RIF, iteration #%u\n", rif_counter);
            exit(1);
        }

        add_time_rifs += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                         (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        sx_status = sx_api_router_interface_counter_bind_set(api_handle,
                                                             SX_ACCESS_CMD_BIND,
                                                             rif_cntrs[rif_counter],
                                                             rifs_table[rif_counter]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_router_counter_set BIND failed: [%s], rif_counter:%u \n",
                   sx_status_str(sx_status), rif_counter);
            exit(1);
        }

        rif_counter++;
    }
    printf("%u RIFs have successfully been created in %" PRIu64 " ms.\n", rif_counter, (add_time_rifs / 1000));

    /** Editing all RIFs **/
    printf("\nEditing each RIF...\n");

    ifc_attr.mac_addr = DEFAULT_ETHER_ADDR;
    ifc_attr.mtu = 1500;
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP;
    ifc_attr.multicast_ttl_threshold = 0;
    ifc_attr.loopback_enable = 0;

    for (i = 0; i < rif_counter; i++) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_interface_set(api_handle,
                                                SX_ACCESS_CMD_EDIT,
                                                vrids_table[VRID_INDEX],
                                                &ifc_param,
                                                &ifc_attr,
                                                &(rifs_table[i]));
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: Failed to edit RIF, iteration #%u\n", i);
            exit(1);
        }

        edit_time_rifs += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                          (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
    }
    printf("%u RIFs have successfully been edited in %" PRIu64 " ms.\n", rif_counter, (edit_time_rifs / 1000));


    /** Performing GET for all VRs **/
    printf("\nGetting each VR...\n");
    for (i = 0; i < vr_counter; i++) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_get(api_handle,
                                      vrids_table[i],
                                      &router_attr);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: Failed to get VR info, iteration #%u\n", i);
            exit(1);
        }

        get_time_vrs += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                        (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
    }
    printf("Info for %u VRs have successfully been retrieved in %" PRIu64 " ms.\n", vr_counter, (get_time_vrs / 1000));


    /** Performing GET for all RIFs **/
    printf("\nGetting each RIF...\n");
    for (i = 0; i < rif_counter; i++) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_interface_get(api_handle,
                                                rifs_table[i],
                                                &(vrids_table[VRID_INDEX]),
                                                &ifc_param,
                                                &ifc_attr);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: Failed to get RIF info, iteration #%u\n", i);
            exit(1);
        }

        get_time_rifs += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                         (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
    }
    printf("Info for %u RIFs have successfully been retrieved in %" PRIu64 " ms.\n",
           rif_counter,
           (get_time_rifs / 1000));


    /** Destroy all RIFs **/
    printf("\nDestroying all RIFs...\n");
    for (i = 0; i < rif_counter; i++) {
        sx_status = sx_api_router_interface_counter_bind_set(api_handle,
                                                             SX_ACCESS_CMD_UNBIND,
                                                             rif_cntrs[i],
                                                             rifs_table[i]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_router_counter_set UNBIND failed: [%s], , rif_counter:%u \n",
                   sx_status_str(sx_status), i);
            exit(1);
        }
        if (is_enhanced_rif_cntr) {
            sx_router_counter_attributes_t cntr_attributes;
            cntr_attributes.type = SX_ROUTER_COUNTER_TYPE_ENHANCED;
            sx_status =
                sx_api_router_counter_extended_set(api_handle, SX_ACCESS_CMD_DESTROY, cntr_attributes,
                                                   &(rif_cntrs[i]));
        } else {
            sx_status = sx_api_router_counter_set(api_handle, SX_ACCESS_CMD_DESTROY, &(rif_cntrs[i]));
        }
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_router_counter_set DESTROY failed: [%s], rif_counter:%u \n",
                   sx_status_str(sx_status), i);
            exit(1);
        }

        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_interface_set(api_handle,
                                                SX_ACCESS_CMD_DELETE,
                                                vrids_table[VRID_INDEX],
                                                NULL,
                                                NULL,
                                                &(rifs_table[i]));
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: Failed to destroy RIF, iteration #%u\n", i);
            exit(1);
        }

        del_time_rifs += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                         (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
    }
    printf("%u RIFs have successfully been destroyed in %" PRIu64 " ms.\n", rif_counter, (del_time_rifs / 1000));

    /* Remove VPORTs if needed */
    if (chip_type >= SX_CHIP_TYPE_SPECTRUM4) {
        /* Delete all VPORTs for the used log_ports */
        for (i = 0; i < 2; i++) {
            sx_status = sx_api_port_vport_set(api_handle,
                                              SX_ACCESS_CMD_DELETE_ALL,
                                              port_attr_p[i].log_port,
                                              vlan_id,
                                              &vport);
            if (SX_STATUS_SUCCESS != sx_status) {
                printf("ERROR: Failed to create VPORT, iteration #%u, VLAN_ID %d, log_port 0x%x\n",
                       rif_counter,
                       vlan_id,
                       log_port);
                exit(1);
            }
            if (rif_counter < MAX_VALID_VLAN_ID) {
                break;
            }
        }
    }

    /** Destroy all VRs **/
    printf("\nDestroying all VRs...\n");
    for (i = 0; i < vr_counter; i++) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_set(api_handle,
                                      SX_ACCESS_CMD_DELETE,
                                      NULL,
                                      &(vrids_table[i]));
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: Failed to destroy VR, iteration #%u\n", i);
            exit(1);
        }

        del_time_vrs += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                        (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
    }
    printf("%u VRs have successfully been deleted in %" PRIu64 " ms.\n", vr_counter, (del_time_vrs / 1000));

    printf("\nFree resources...\n");

    /** Router deinit **/
    sx_status = sx_api_router_deinit_set(api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: Failed to perform router deinit\n");
        exit(1);
    }
    printf("\nSDK API: Router deinit has been performed successfully\n");


    /** Close SDK **/
    sx_status = sx_api_close(&api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_close failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: Close API handle: 0x%" PRIx64 "\n", api_handle);

    printf("\nEnd.\n");
    return 0;
}
