/*
 * Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_issu.h>
#include <getopt.h>

static struct option s_sdk_pause_resume_options_arr[] = {
    {"pause",  no_argument, NULL, 'p'},
    {"resume", no_argument, NULL, 'r'},
    {"help",   no_argument, NULL, 'h'},
    {0,        0,           0,    0}
};
static void show_help(const char* prog_name)
{
    printf("\tUsage: %s <options>\n\n"
           "\t(-p|--pause)  - Pause SDK\n"
           "\t(-r|--resume) - Resume SDK\n"
           "\t(-h|--help)   - Show this help message and exit.\n", prog_name);
}

static void show_error()
{
    printf("Bad parameter(s). Use --help to get parameters summary\n");
}

int main(int argc, char* argv[])
{
    sx_api_handle_t  handle = SX_API_INVALID_HANDLE;
    sx_status_t      err = SX_STATUS_SUCCESS;
    boolean_t        pause_sdk = FALSE;
    boolean_t        resume_sdk = FALSE;
    sx_issu_pause_t  pause_params;
    sx_issu_resume_t resume_params;
    boolean_t        sx_api_opened = FALSE;
    int              c = 0;

    while (TRUE) {
        int option_index = 0;

        c = getopt_long(argc, argv, "hpr", s_sdk_pause_resume_options_arr, &option_index);
        if (c == -1) {
            if ((!pause_sdk) && (!resume_sdk)) {
                printf("Either \"--pause\" or \"--resume\" muse be provided.\n");
                goto out;
            } else if (pause_sdk && resume_sdk) {
                printf("\"--pause\" and \"--resume\" can't be provided at the same time.\n");
                goto out;
            }
            break;
        }

        switch (c) {
        case 'p':
            pause_sdk = TRUE;
            break;

        case 'r':
            resume_sdk = TRUE;
            break;

        case 'h':
        case '?':
            show_help(argv[0]);
            goto out;

        default:
            show_error();
            goto out;
        }
    }

    err = sx_api_open(NULL, &handle);
    if (err != SX_STATUS_SUCCESS) {
        printf("Failed to open SX-API (%s)\n", sx_status_str(err));
        goto out;
    }
    sx_api_opened = TRUE;

    if (pause_sdk) {
        memset(&pause_params, 0, sizeof(pause_params));
        err = sx_api_issu_pause_set(handle, &pause_params);
        if (err != SX_STATUS_SUCCESS) {
            printf("sx_api_pause_set failed, rc = %d\n", err);
            goto out;
        }
    } else {
        memset(&resume_params, 0, sizeof(resume_params));
        err = sx_api_issu_resume_set(handle, &resume_params);
        if (err != SX_STATUS_SUCCESS) {
            printf("sx_api_resume_set failed, rc = %d\n", err);
            goto out;
        }
    }

out:
    if (sx_api_opened) {
        err = sx_api_close(&handle);
        if (err != SX_STATUS_SUCCESS) {
            printf("Failed to close SX-API (%s)\n", sx_status_str(err));
        }
    }

    return err;
}
