/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef EVB_STATUS_H__
#define EVB_STATUS_H__

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * evb_status_t
 * Enumerated type - Used to provide function return values.
 */
typedef enum evb_status {
    EVB_STATUS_SUCCESS = 0,
    EVB_STATUS_ERROR,
    EVB_STATUS_NO_RESOURCES,
    EVB_STATUS_NO_MEMORY,
    EVB_STATUS_MEMORY_ERROR,
    EVB_STATUS_PARAM_ERROR,
    EVB_STATUS_PARAM_NULL,
    EVB_STATUS_PARSE_ERROR,
    EVB_STATUS_SDK_ERROR,
    EVB_STATUS_PARAM_EXCEED_RANGE,
    EVB_STATUS_MIN = EVB_STATUS_SUCCESS,
    EVB_STATUS_MAX = EVB_STATUS_PARAM_EXCEED_RANGE
} evb_status_t;


/************************************************
 *  Macro definitions
 ***********************************************/

#define EVB_STATUS_CHECK_RANGE(STATUS) (EVB_STATUS_MIN <= (int)STATUS && EVB_STATUS_MAX >= STATUS)
/**
 * Macro is used to test if status isn't success.
 */
#ifndef EVB_CHECK_FAIL
#define EVB_CHECK_FAIL(STATUS) (EVB_STATUS_SUCCESS != (STATUS))
#endif  /*	EVB_CHECK_FAIL	*/

#endif /* EVB_STATUS_H__ */
