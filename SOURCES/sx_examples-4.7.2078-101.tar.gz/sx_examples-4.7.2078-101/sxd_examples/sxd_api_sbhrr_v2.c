/*
 * Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <getopt.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sxd/sxd_access_register.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api_init.h>
#include <arpa/inet.h>

#define SWID                      0
#define QUEUE_DEPTH_TRAFFIC_CLASS 0x1000

static struct option long_options[] = {
    {"local_port",      required_argument,  NULL,   'l'                       },
    {"dir",             required_argument,  NULL,   'd'                       },
    {"pg_or_tc",        required_argument,  NULL,   'p'                       },
    {"clr",             no_argument,        NULL,   'c'                       },
    {"help",            no_argument,        NULL,   'h'                       },
    {0,                         0,                  0,      0                         },
};
uint32_t             local_port;
uint32_t             dir;
uint32_t             pg_tc;
uint32_t             clr;
static void __show_help()
{
    printf("\tOptions:\n"
           "\t--local_port|-l       Local port\n"
           "\t--dir|-d              0 - Ingress, 1 - Egress\n"
           "\t--pg_tc|-p            PR or TC number\n"
           "\t--clr|-c              Clear\n"
           "\t(-h|--help)           - show this help message and exit.\n"
           "\tExample: ./sxd_api_sbhrr_v2 -l 1 -d 1 -p 0 \n"
           "\tExample: ./sxd_api_sbhrr_v2 -l 1 -d 1 -p 0 -c\n"


           );
    exit(0);
}

#define LOG(format, ...) printf("%s[%d]:" format, __func__, __LINE__, ## __VA_ARGS__)

int get_options(int argc, char **argv)
{
    int rc = 0;
    int c;

    if (argc < 4) {
        __show_help();
    }

    while (1) {
        int option_index = 0;

        c = getopt_long(argc, argv, "l:d:p:ch", long_options, &option_index);

        /* Detect the end of the options. */
        if (c == -1) {
            break;
        }

        switch (c) {
        case 'l':
            rc = sscanf(optarg, "%u", &local_port);
            LOG("\t\t Local port: %u\n", local_port);
            break;

        case 'd':
            rc = sscanf(optarg, "%u", &dir);
            LOG("\t\t Dir: %u\n", dir);
            break;

        case 'p':
            rc = sscanf(optarg, "%u", &pg_tc);
            LOG("\t\t pg_tc: %u\n", pg_tc);
            break;

        case 'c':
            clr = 1;
            LOG("\t\t clr: %u\n", clr);
            break;

        case 'h':
        case '?':
        default:
            /* getopt_long already printed an error message. */
            __show_help();
            return 1;
        }

        if (rc != 1) {
            LOG("COMMAND LINE PARAMETERS ERROR\n");
            __show_help();
            return 1;
        }
    }

    return 0;
}

int main(int argc, char *argv[])
{
    struct  ku_sbhrr_v2_reg sbhrrv2;
    sxd_status_t            sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t          reg_meta;

    if (get_options(argc, argv)) {
        exit(1);
    }

    sxd_status = sxd_access_reg_init(0, NULL, SX_VERBOSITY_LEVEL_DEBUG);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        printf("ERROR: SXD API sxd_access_reg_init failed: [%s]\n", SXD_STATUS_MSG(sxd_status));
        exit(1);
    }

    memset(&reg_meta, 0, sizeof(reg_meta));
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.dev_id = 1;

    memset(&sbhrrv2, 0, sizeof(struct ku_sbhrr_v2_reg));
    sbhrrv2.local_port = local_port;
    sbhrrv2.dir = dir;
    sbhrrv2.pg_buff = pg_tc;
    sbhrrv2.clr = clr;
    sbhrrv2.hist_type = QUEUE_DEPTH_TRAFFIC_CLASS;

    sxd_status = sxd_access_reg_sbhrr_v2(&sbhrrv2, &reg_meta, 1, NULL, NULL);
    if (sxd_status) {
        printf("%s: failed in get SBHRR for dev_id %d, error: [%s] \n",
               __func__, 1, SXD_STATUS_MSG(sxd_status));
        exit(1);
    }

    LOG("\t\tlocal_port: %#x\n", sbhrrv2.local_port);
    LOG("\t\tpg_buff: %#x\n", sbhrrv2.pg_buff);
    LOG("\t\tdir: %#x\n", sbhrrv2.dir);
    LOG("\t\tclr: %#x\n", sbhrrv2.clr);
    LOG("\t\tmax_sampled_high: %#x\n", sbhrrv2.max_sampled_high);
    LOG("\t\tmax_sampled_low: %#x\n", sbhrrv2.max_sampled_low);
    LOG("\t\t bin[0]: %#lx\n", sbhrrv2.bin[0]);
    LOG("\t\t bin[1]: %#lx\n", sbhrrv2.bin[1]);
    LOG("\t\t bin[2]: %#lx\n", sbhrrv2.bin[2]);
    LOG("\t\t bin[3]: %#lx\n", sbhrrv2.bin[3]);
    LOG("\t\t bin[4]: %#lx\n", sbhrrv2.bin[4]);
    LOG("\t\t bin[5]: %#lx\n", sbhrrv2.bin[5]);
    LOG("\t\t bin[6]: %#lx\n", sbhrrv2.bin[6]);
    LOG("\t\t bin[7]: %#lx\n", sbhrrv2.bin[7]);
    LOG("\t\t bin[8]: %#lx\n", sbhrrv2.bin[8]);
    LOG("\t\t bin[9]: %#lx\n", sbhrrv2.bin[9]);

    return 0;
}
