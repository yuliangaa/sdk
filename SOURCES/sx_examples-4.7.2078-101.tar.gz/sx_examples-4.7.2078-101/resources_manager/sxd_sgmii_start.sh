#!/bin/bash
#
 # Copyright (C) 2008-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


basedir=`readlink -f $0`
basedir=${basedir%/*}

config_file=${basedir}/../share/sxd_sgmii.xml

export LD_LIBRARY_PATH=${basedir}/../lib:${basedir}/../lib64

ex()
{
	echo "$@"
	eval "$@" || exit 1
}

ex ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel start

ex ${evb_resources_manager_prefix} ${basedir}/sgmii_manager ${evb_resources_manager_suffix} ${config_file} || exit 1