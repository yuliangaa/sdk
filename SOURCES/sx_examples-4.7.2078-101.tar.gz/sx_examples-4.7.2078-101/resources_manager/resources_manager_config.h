/*
 * Copyright (c) 2009-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __RESOURCES_MAMAGER_CONFIG_H__
#define __RESOURCES_MAMAGER_CONFIG_H__

#include <sx/sxd/kernel_user.h>

/*****************************************************
 *		    RDQ PROPERTIES
 ******************************************************/
#define RDQ_IB_QP0_DEFAULT_SIZE 350      /* QP0 only, no N+1 port */
#define RDQ_IB_QP1_DEFAULT_SIZE 4096      /* QP0 (Switch port 0), QP0+QP1 (Switch N+1 port) */
#define RDQ_IB_UD_DEFAULT_SIZE  4200

#define RDQ_ETH_DEFAULT_SIZE          4200
#define RDQ_ETH_LARGE_SIZE_LEGACY     (SX_ETH_RDQ_MAX_MSG_SIZE_LEGACY)
#define RDQ_ETH_LARGE_SIZE_SPC2       (SX_ETH_RDQ_MAX_MSG_SIZE_SPC2)
#define RDQ_ETH_LARGE_SIZE_SPC3       (RDQ_ETH_LARGE_SIZE_SPC2)
#define RDQ_ETH_LARGE_SIZE_SPC4       (RDQ_ETH_LARGE_SIZE_SPC2)
#define RDQ_DEFAULT_NUMBER_OF_ENTRIES 1024
#define RDQ_MAD_NUMBER_OF_ENTRIES     RDQ_DEFAULT_NUMBER_OF_ENTRIES

/* weights */
#define RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT 10
#define RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT  10
#define RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT  10
#define RDQ_IB_MULTI_SWID_DEFAULT_WEIGHT   10
#define RDQ_VPI_SINGLE_SWID_DEFAULT_WEIGHT 10

#define RDQ_IB_MULTI_SWID_NUMBER   24
#define RDQ_IB_SINGLE_SWID_NUMBER  3
#define RDQ_ETH_MULTI_SWID_NUMBER  9
#define RDQ_ETH_SINGLE_SWID_NUMBER 3
#define RDQ_VPI_SINGLE_SWID_NUMBER 6


#define DEVICE_PROFILE_MASK_SET_MAX_VEPA_CHANNELS 0x01
#define DEVICE_PROFILE_MASK_SET_MAX_LAG           0x02
#define DEVICE_PROFILE_MASK_SET_MAX_PORTS_PER_LAG 0x04
#define DEVICE_PROFILE_MASK_SET_MAX_MID           0x08
#define DEVICE_PROFILE_MASK_SET_MAX_PGT           0x10
#define DEVICE_PROFILE_MASK_SET_MAX_SYSTEM_PORT   0x20
#define DEVICE_PROFILE_MASK_SET_MAX_ACTIVE_VLANS  0x40
#define DEVICE_PROFILE_MASK_SET_MAX_REGIONS       0x80
#define DEVICE_PROFILE_MASK_SET_FID_BASED         0x100
#define DEVICE_PROFILE_MASK_SET_MAX_FLOOD_TABLES  0x200
#define DEVICE_PROFILE_MASK_SET_MAX_IB_MC         0x1000
#define DEVICE_PROFILE_MASK_SET_MAX_PKEY          0x2000

/***********************
 * SYSTEM PROFILE      *
 **********************/

typedef enum sys_profile {
    SYS_PROFILE_IB_SINGLE_SWID,
    SYS_PROFILE_IB_MULTI_SWID,
    SYS_PROFILE_EN_SINGLE_SWID,
    SYS_PROFILE_EN_MULTI_SWID,
    SYS_PROFILE_VPI_SINGLE_SWID,
    SYS_PROFILE_VPI_MULTI_SWID,
    SYS_PROFILE_MIN = SYS_PROFILE_IB_SINGLE_SWID,
    SYS_PROFILE_MAX = SYS_PROFILE_VPI_SINGLE_SWID,
} sys_profile_t;

#define SYS_PROFILE_DEFAULT SYS_PROFILE_IB_SINGLE_SWID
#define SYS_PROFILE_MIN_MAX SYS_PROFILE_MIN, SYS_PROFILE_MAX
#define SYS_PROFILE_CHECK_RANGE(profile) (profile <= SYS_PROFILE_MAX)

static const char    *sys_profile_str[] = {
    "IB SINGLE SWID",
    "IB MULTI SWID",
    "EN SINGLE SWID",
    "EN MULTI SWID",
    "VPI SINGLE SWID",
    "VPI MULTI SWID"
};
static const uint32_t sys_profile_str_len = sizeof(sys_profile_str) / sizeof(char*);

#define SYS_PROFILE_STR(index) ((sys_profile_str_len > index) ? sys_profile_str[index] : "UNKNOWN")

extern struct rdq_properties rdq_properties[NUMBER_OF_RDQS];

/*****************************************************
 *		    SDQ -> CPU EGRESS TCLASS
 ******************************************************/
extern uint8_t cpu_egress_tclass[NUMBER_OF_SDQS];

/*****************************************************
 *		    SINGLE PARTITION ETH
 ******************************************************/
extern struct sx_pci_profile pci_profile_single_eth;
extern struct sx_pci_profile pci_profile_single_eth_spectrum;
extern struct sx_pci_profile pci_profile_single_eth_spectrum2;
extern struct sx_pci_profile pci_profile_single_eth_spectrum3;
extern struct sx_pci_profile pci_profile_single_eth_spectrum4;
extern struct sx_pci_profile pci_profile_single_eth_spectrum5;
extern struct ku_profile     single_part_eth_device_profile;
extern struct ku_profile     single_part_eth_device_profile_a2;
extern struct ku_profile     single_part_eth_device_profile_spectrum;
extern struct ku_profile     single_part_eth_device_profile_reserved;

/*****************************************************
 *		    MULTI PARTITION ETH
 ******************************************************/
extern struct sx_pci_profile pci_profile_multi_eth;
extern struct ku_profile     multi_part_eth_device_profile;
extern struct ku_profile     multi_part_eth_device_profile_a2;

/*****************************************************
 *		    SINGLE PARTITION IB
 ******************************************************/
extern struct sx_pci_profile pci_profile_single_ib;
extern struct ku_profile     single_part_ib_device_profile;
extern struct ku_profile     single_part_ib_device_profile_switchib;
extern struct ku_profile     single_part_ib_device_profile_switchib2;
extern struct ku_profile     single_part_ib_device_profile_quantum;
extern struct ku_profile     single_part_ib_device_profile_quantum2;
extern struct ku_profile     single_part_ib_device_profile_quantum3;

/*****************************************************
 *		    MULTI PARTITION IB
 ******************************************************/
extern struct sx_pci_profile pci_profile_multi_ib;
extern struct ku_profile     multi_part_ib_device_profile;

/*****************************************************
 *		    VPI
 ******************************************************/
extern struct sx_pci_profile pci_profile_vpi;
extern struct ku_profile     vpi_device_profile;
extern struct ku_profile     vpi_device_profile_a2;


#endif /* __RESOURCES_MAMAGER_CONFIG_H__ */
