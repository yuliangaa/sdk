/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sys/types.h>
#include <getopt.h>
#include <errno.h>
#include <string.h>
#include <sx/sxd/sxdev.h>
#include <sx/sdk/sx_dev.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_access_register_init.h>
#include <complib/sx_log.h>
#include <complib/sx_xml.h>
#include "resources_manager_config.h"

#define DEV_NOT_PRESENT -99

#define EVB_XML_PARSE_UINT(sx_xml_element_t, uint_var, var_name, rc)                   \
    do {                                                                               \
        if (sx_xml_element_t != NULL) {                                                \
            uint_var = strtoul(sx_xml_element_content_get(sx_xml_element_t), NULL, 0); \
        } else {                                                                       \
            SX_LOG_ERR("Error parsing %s\n", var_name);                                \
            rc = EVB_STATUS_PARSE_ERROR;                                               \
        }                                                                              \
    } while (0)

#define EVB_XML_PARSE_MAC_ADDR(mac_element, mac_var, var_name, rc)                   \
    do {                                                                             \
        if (mac_element != NULL) {                                                   \
            memcpy(mac_var, ether_aton(sx_xml_element_content_get(mac_element)), 6); \
            if (mac_var == NULL) {                                                   \
                SX_LOG_ERR("Error parsing MAC address %s\n", var_name);              \
                rc = EVB_STATUS_PARSE_ERROR;                                         \
            }                                                                        \
        }                                                                            \
    } while (0)


#define EVB_XML_PARSE_IP_ADDR(ip_element, ip_var, var_name, rc)                 \
    do {                                                                        \
        struct in_addr network;                                                 \
        if (inet_aton(sx_xml_element_content_get(ip_element), &network) == 0) { \
            SX_LOG_ERR("Error parsing network IP\n");                           \
            rc = EVB_STATUS_PARSE_ERROR;                                        \
        }                                                                       \
        ip_var = ntohl(network.s_addr);                                         \
    } while (0);

static sxd_handle handle = 0;
uint64_t          smac = 0;
uint8_t           use_sgmii = TRUE;
sx_xml_reader_t  *__reader_p = NULL;           /* XML file reader */
sx_xml_parser_t  *__parser_p = NULL;           /* XML file parser */
sx_xml_tree_t    *__tree_p = NULL;        /* XML tree        */
uint64_t          __sgmii_smac = 0;      /* device's sgmii source mac */
uint64_t          __sgmii_dmac[SX_DEV_ID_MAX]; /* device's sgmii destination mac */
static int        __devices_state[SX_DEV_ID_MAX]; /* device's state*/
static int __kernel_dpt_set(uint8_t device_idx);
static int __user_space_dpt_set(uint8_t device_idx);
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

void log_cb(sx_log_severity_t severity, const char *module_name, char *msg);


/*****************************************************************************/
/*		       LOCAL GENERIC FUNCTIONS DECLARATIONS		     */
/*****************************************************************************/

/**
 * open configuration file
 * @param[in] path_p - path to configuration file
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
static int __open_configuration_file(IN char * const path_p);

/*****************************************************************************/
/*		       XML PARSING FUNCTIONS DECLARATIONS		     */
/*****************************************************************************/

/**
 * This function parse the device state section
 *
 * @param[in]   child_p                - device xml section
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */

int __parse_eth_device_state_section(IN sx_xml_element_t *child_p, OUT int *device_id_p, OUT int *device_state_p);

/**
 * This function parse the source MAC address section
 *
 * @param[in]   child_p                - device xml section
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */

int __parse_eth_sgmii_smac_section(sx_xml_element_t const *tree, OUT uint64_t *__sgmii_smac_p);

/**
 * This function parse the number of devices section
 *
 * @param[in]   child_p                - device xml section
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */

int __parse_eth_num_of_devices_section(sx_xml_element_t const *tree, OUT int * number_of_devices_p);

/*****************************************************************************/
/*		       XML PARSING FUNCTIONS IMPL			     */
/*****************************************************************************/

int __parse_eth_device_state_section(sx_xml_element_t *child_p, int *device_id_p, int *device_state_p)
{
    sx_xml_element_t *child_dev_state = NULL;
    sx_xml_element_t *child_dev_number = NULL;

    child_dev_number = sx_xml_element_by_name_get(child_p, "device-number");
    if (child_dev_number) {
        device_id_p[0] = atoi(sx_xml_element_content_get(child_dev_number));
    } else {
        printf("Error parsing dev_number\n");
        return -1;
    }

    child_dev_state = sx_xml_element_by_name_get(child_p, "device-state");
    if (child_dev_state) {
        device_state_p[0] = atoi(sx_xml_element_content_get(child_dev_state));
    } else {
        printf("Error parsing dev_state\n");
        return -1;
    }

    return 0;
}

int __parse_eth_device_sgmii_dmac_section(sx_xml_element_t *child_p, uint64_t *__sgmii_dmac_p)
{
    sx_xml_element_t *child_sgmii_dmac = NULL;

    child_sgmii_dmac = sx_xml_element_by_name_get(child_p, "sgmii-dmac");
    if (child_sgmii_dmac) {
        __sgmii_dmac_p[0] = strtoull(sx_xml_element_content_get(child_sgmii_dmac), NULL, 0);
    } else {
        /* if SGMII DMAC is not in the XML, we will read it using SPAD register later */
        __sgmii_dmac_p[0] = 0;
    }

    return 0;
}

int __parse_eth_sgmii_smac_section(sx_xml_element_t const *tree, uint64_t *__sgmii_smac_p)
{
    sx_xml_element_t *child_sgmii_smac = sx_xml_element_by_name_get(tree, "sgmii-smac");

    if (child_sgmii_smac != NULL) {
        __sgmii_smac_p[0] = strtoull(sx_xml_element_content_get(child_sgmii_smac), NULL, 0);
        return 0;
    }

    return -1;
}

int __parse_eth_num_of_devices_section(sx_xml_element_t const *tree, OUT int * number_of_devices_p)
{
    sx_xml_element_t *child_number_of_devices = sx_xml_element_by_name_get(tree, "number-of-devices");

    if (child_number_of_devices != NULL) {
        number_of_devices_p[0] = atoi(sx_xml_element_content_get(child_number_of_devices));
        return 0;
    }
    return -1;
}

int __open_configuration_file(IN char * const path_p)
{
    int ret = 0;

    if (path_p == NULL) {
        printf("Can't open configuration file , empty file name\n");
        ret = -1;
        goto out;
    }

    sx_xml_log_function_set(log_cb);
    sx_xml_log_verbosity_level_set(LOG_VAR_NAME(__MODULE__));

    /* Creates an XML parser. This is the first function to call. */
    __parser_p = sx_xml_parser_create();
    if (__reader_p == NULL) {
        printf("Failed to create an XML parser\n");
        ret = -1;
        goto out;
    }

    sx_xml_parser_ignore_whitespaces(__parser_p);

    /* Loads an XML file. */
    __reader_p = sx_xml_reader_create(path_p);
    if (__reader_p == NULL) {
        printf("Unable to load the XML file %s\n", path_p);
        ret = -1;
        goto out;
    }

    __tree_p = sx_xml_tree_create(__parser_p, __reader_p);
    if (__tree_p == NULL) {
        printf("Unable to parse the XML file %s\n", path_p);

        /* Frees the XML parser and reader. */
        sx_xml_reader_free(__reader_p);
        sx_xml_parser_free(__parser_p);
        ret = -1;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return ret;
}

int rsrc_mng_dev_init(uint8_t device_idx)
{
    int ret = 0;

    /* set kernel dpt */
    ret = __kernel_dpt_set(device_idx);
    if (ret == DEV_NOT_PRESENT) {
        return 0;
    }

    if (ret) {
        printf("Failed in set kernel DPT\n");
        return ret;
    }

    /* set user dpt */
    ret = __user_space_dpt_set(device_idx);
    if (ret) {
        printf("Failed in set user space DPT\n");
        return ret;
    }

    return ret;
}

int main(int argc, char **argv)
{
    char              dev_name[MAX_SX_DEVS][MAX_NAME_LEN];
    char             *dev_name_p[MAX_SX_DEVS];
    uint32_t          dev_num = MAX_SX_DEVS;
    uint8_t           device_idx = 1;
    sys_type_t        sys_type = SYS_TYPE_EN;
    sxd_ctrl_pack_t   ctrl_pack;
    int               i = 0;
    int               ret = 0;
    sx_xml_list_t    *list = NULL, *list_head = NULL;   /* XML list object - used to iterate device nodes */
    sx_xml_element_t *child, *tree_root;
    int               dev_info_index = 0, number_of_devices = 0, device_state = 0;
    int               num_found_devs = 0;

    memset(&ctrl_pack, 0, sizeof(ctrl_pack));

    /* Check remaining command line arguments (not options). */
    if (argc != 2) {
        printf("Wrong number of arguments\n");
        return -1;
    }

    /* query local devices names */
    for (i = 0; i < MAX_SX_DEVS; ++i) {
        dev_name_p[i] = dev_name[i];
    }

    ret = sxd_get_dev_list(dev_name_p, &dev_num);
    if (ret < 0) {
        printf("sxd_get_dev_list error: %s\n", strerror(errno));
        return ret;
    } else if (ret > 0) {
        printf("Unsupported SX device number: %u\n", ret);
        return ret;
    }

    if (device_idx > dev_num) {
        printf("SX device [%u] not found\n", device_idx);
        return -1;
    }

    /* open device and reset it */
    ret = sxd_open_device(dev_name[device_idx - 1], &handle);
    if (ret) {
        printf("sxd_open_device error: %s\n", strerror(errno));
        return ret;
    }

    /*****************************************************************************/
    /*		               PARSING SECTION				     */
    /*****************************************************************************/
    /* open configuration file */
    ret = __open_configuration_file(argv[1]);
    if (ret < 0) {
        printf("Failed opening the configuration file\n");
        return -1;
    }

    tree_root = sx_xml_tree_root_element_get(__tree_p);
    if (use_sgmii == TRUE) {
        ret = __parse_eth_sgmii_smac_section(tree_root, &__sgmii_smac);
        if (ret < 0) {
            printf("Failed to parse sgmii source MAC address\n");
            return -1;
        }
    }

    ret = __parse_eth_num_of_devices_section(tree_root, &number_of_devices);
    if (ret < 0) {
        printf("Failed to parse number of devices\n");
        return -1;
    }

    /* get the list of devices from the XML file */
    list_head = sx_xml_element_shallow_list_by_name_get(tree_root, "device");
    list = list_head;
    while (list != NULL && num_found_devs < number_of_devices) {
        child = sx_xml_element_list_data(list);
        /* Check the device state - do not handle disabled devices*/
        ret = __parse_eth_device_state_section(child, &dev_info_index, &device_state);
        if (ret < 0) {
            printf("Failed to parse device's state\n");
            return -1;
        }

        if (dev_info_index >= SX_DEV_ID_MAX) {
            printf("Device id %d is not valid\n", dev_info_index);
            return -1;
        }

        __devices_state[dev_info_index] = device_state;
        if (device_state) {
            num_found_devs++;
        }

        ret = __parse_eth_device_sgmii_dmac_section(child, &__sgmii_dmac[dev_info_index]);
        if (ret < 0) {
            __sgmii_dmac[dev_info_index] = 0;
        }

        list = sx_xml_element_list_next(list);
    }

    /* initialize user space DPT */
    ret = sxd_dpt_init(sys_type, log_cb, LOG_VAR_NAME(__MODULE__));
    if (SXD_CHECK_FAIL(ret)) {
        printf("%s: failed to init user space DPT , error: %d\n", __func__, ret);
        return ret;
    }

    /* open access reg handle */
    ret = sxd_access_reg_init(0, log_cb, LOG_VAR_NAME(__MODULE__));
    if (SXD_CHECK_FAIL(ret)) {
        printf("%s: failed to init access register , error: %d\n",
               __func__, ret);
        return ret;
    }

    /*==============================
     *
     *    DEVICE INIT SECTION
     *
     *  ===============================*/
    for (i = 1; i < SX_DEV_ID_MAX; i++) {
        static int count = 0;
        if (__devices_state[i] == 0) {
            continue;
        }

        printf("Going to configure dev %d\n", i);
        ret = rsrc_mng_dev_init(i);
        if (ret) {
            printf("Failed in rsrc_mng_dev_init for dev %d\n", i);
            return ret;
        }

        if (++count == num_found_devs) {
            break;
        }
    }

    /* close access reg handle */
    ret = sxd_access_reg_deinit();
    if (SXD_CHECK_FAIL(ret)) {
        printf("%s: failed to deinit access register , error: %d\n",
               __func__, ret);
        return ret;
    }

    return 0;
}

int __kernel_dpt_set(uint8_t device_idx)
{
    struct ku_dpt_path_add    path;
    struct ku_dpt_path_modify path_modify;
    sxd_ctrl_pack_t           ctrl_pack;
    int                       sxd_err = 0;
    int                       i = device_idx;

    memset(&ctrl_pack, 0, sizeof(sxd_ctrl_pack_t));

    printf("KDPT: Going to set path for device id: %d\n", device_idx);

    ctrl_pack.ctrl_cmd = CTRL_CMD_ADD_DEV_PATH;
    ctrl_pack.cmd_body = (void*)&(path);
    path.dev_id = device_idx;
    path.path_type = DPT_PATH_SGMII;
    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (sxd_err != 0) {
        printf("failed to add dev path to DP table \n");
        return -1;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_EMAD_PATH;
    ctrl_pack.cmd_body = (void*)&(path_modify);
    path_modify.dev_id = i;
    path_modify.path_type = DPT_PATH_SGMII;
    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (sxd_err != 0) {
        printf("failed to set EMAD path in DP table \n");
        return -1;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_CR_ACCESS_PATH;
    ctrl_pack.cmd_body = (void*)&(path_modify);
    path_modify.dev_id = i;
    path_modify.path_type = DPT_PATH_SGMII;
    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (sxd_err != 0) {
        printf("failed to set EMAD path in DP table \n");
        return -1;
    }

    return 0;
}

int __user_space_dpt_set(uint8_t device_idx)
{
    dpt_path_params_t path_params;
    sxd_status_t      status;
    int               ret = 0;

    printf("UDPT: Going to set path for device id: %d\n", device_idx);

    ret = sxd_dpt_set_access_control(device_idx, READ_WRITE);
    if (SXD_CHECK_FAIL(ret)) {
        printf("failed to set access control in user space DPT, "
               "for device %d. error: %s\n", device_idx,
               SXD_STATUS_MSG(ret));
        return ret;
    }

    path_params.sys_port_params.sys_port = 0;
    status = sxd_dpt_path_add(device_idx, 0, SYS_PORT_ROUTE_PATH, path_params);
    if (status != SXD_STATUS_SUCCESS) {
        printf("failed to set sys port path in user space DPT, "
               "for device %d, swid %d. error: %s\n", device_idx, 0,
               SXD_STATUS_MSG(status));
        return -1;
    }

    return ret;
}

void log_cb(sx_log_severity_t severity, const char *module_name, char *msg)
{
    sx_verbosity_level_t verbosity = 0;

    SEVERITY_LEVEL_TO_VERBOSITY_LEVEL(severity, verbosity);
    printf("[%-20s][%s] : %s", module_name, SX_VERBOSITY_LEVEL_STR(verbosity), msg);

    return;
}
