#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

basedir=`readlink -f $0`
basedir=${basedir%/*}

profile=${1:-"eth-single"}
target=${2:-"dvk"}
boot_mode="${BOOT_MODE:-DISABLED}"
use_internal_init_flow="${USE_INTERNAL_INIT_FLOW:-1}"

if [ "$SDK_VERBOSITY" == "no" ]; then
    verbosity_flags="-n"
else
    if [ "$SDK_VERBOSITY" != "" ]; then
        verbosity_flags="-l$SDK_VERBOSITY"
    fi
fi

config_file=${basedir}/../share/dvs_manager_${profile%-*}_${target}.xml

wait_resource_manager_ready() {
   while screen -ls | grep -q resource_manager_gdb; do
        sleep 0.001
   done
}

resources_manager_cmd="${basedir}/resources_manager ${evb_resources_manager_suffix} ${profile} ${config_file} --boot_mode ${boot_mode} --use_internal_init_flow ${use_internal_init_flow} ${verbosity_flags}"
if [ "${START_RSC_MANAGER_WITH_GDB}" != "" ]; then
echo "========================================================================================================"
screen -dmS "resource_manager_gdb" bash -c "${evb_resources_manager_prefix} gdb -ex 'set pagination off' -ex=start -q -tui --args ${resources_manager_cmd} || exit 1"
echo "Please attach GDB screen with following command below to continue"
echo "screen -r resource_manager_gdb"
echo "========================================================================================================"
wait_resource_manager_ready
else
${evb_resources_manager_prefix} ${resources_manager_cmd} || exit 1
fi