#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


basedir=`readlink -f $0`
basedir=${basedir%/*}

profile=${1:-"eth-single"}
target=${2:-"dvk"}

config_file=${basedir}/../share/dvs_manager_${profile%-*}_${target}.xml

${basedir}/resources_manager --device=1 --use-sgmii ${profile} ${config_file} || exit 1