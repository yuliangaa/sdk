/*
 * Copyright (c) 2009-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "resources_manager_config.h"
#include <sx/sdk/sx_dev.h>

/*****************************************************
 *		    PCI PROFILES
 ******************************************************/

/*****************************************************
 *		    SINGLE PARTITION ETH
 ******************************************************/

/* <stclass,sdq> */

/*		|ETC0	  |ETC1	    |ETC2     |ETC3	|ETC4	  |ETC5	    |ETC6     |ETC7
 * ------------------------------------------------------------------------------------
 * Swid 0	|<0,0>	  |<1,1>    |<2,2>    |<3,3>    |<4,4>	  |<5,5>    |<6,6>    |<6,7>
 * Swid 1	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 2	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 3	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 4	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 5	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 6	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 7	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 *
 * */

struct sx_pci_profile pci_profile_single_eth = {
    /*profile enum*/
    .pci_profile = PCI_PROFILE_EN_SINGLE_SWID,
    /*tx_prof: <swid,etclass> -> <stclass,sdq> */
    .tx_prof = {
        {
            {0, 2}, /*-0-best effort*/
            {1, 2}, /*-1-low prio*/
            {2, 2}, /*-2-medium prio*/
            {3, 2}, /*-3-*/
            {4, 2}, /*-4-*/
            {5, 1}, /*-5-high prio*/
            {6, 0}, /*-6-critical prio*/
            {6, 0} /*-7-*/
        },
        {
            {0, 6}, /*-0-best effort*/
            {1, 6}, /*-1-low prio*/
            {2, 6}, /*-2-medium prio*/
            {3, 6}, /*-3-*/
            {4, 6}, /*-4-*/
            {5, 5}, /*-5-high prio*/
            {6, 4}, /*-6-critical prio*/
            {6, 4} /*-7-*/
        }
    },
    /* emad_tx_prof */
    .emad_tx_prof = {
        7, 8
    },
    /* swid_type */
    .swid_type = {
        SX_KU_L2_TYPE_ETH,
        SX_KU_L2_TYPE_ROUTER_PORT,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE
    },
    /* rdq_count */
    .rdq_count = {
        4,
        4,
        0,
        0,
        0,
        0,
        0,
        0
    },
    /* rdq */
    .rdq = {
        {
            /* swid 0 - ETH */
            0,
            1,
            2,
            3
        },
        /* swid 1 - RP */
        {
            4,
            5,
            6,
            7
        }
    },
    /* emad_rdq */
    .emad_rdq = 21,
    /* rdq_properties */
    .rdq_properties = {
        /* SWID 0 */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},      /*-0-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-1-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},      /*-2-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-3-high priority*/
        /* SWID 1 */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},      /*-4-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-5-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},      /*-6-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-7-high priority*/
        {0, 0, 0, 0}, /*-8-*/
        {0, 0, 0, 0}, /*-9-*/
        {0, 0, 0, 0}, /*-10-*/
        {0, 0, 0, 0}, /*-11-*/
        {0, 0, 0, 0}, /*-12-*/
        {0, 0, 0, 0}, /*-13-*/
        {0, 0, 0, 0}, /*-14-*/
        {0, 0, 0, 0}, /*-15-*/
        {0, 0, 0, 0}, /*-16-*/
        {0, 0, 0, 0}, /*-17-*/
        {0, 0, 0, 0}, /*-18-*/
        {0, 0, 0, 0}, /*-19-*/
        {0, 0, 0, 0}, /*-20-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-21-critical priority*/
        {0, 0, 0, 0}, /*-22-*/
        {0, 0, 0, 0} /*-23-*/
    },
    /* cpu_egress_tclass */
    .cpu_egress_tclass = {
        2, /*-0-critical prio*/
        1, /*-1-high prio*/
        0, /*-2-all other prios*/
        0, /*-3-*/
        0, /*-4-*/
        0, /*-5-*/
        0, /*-6-*/
        0, /*-7-*/
        4, /*-8-EMADs*/
        0, /*-9-*/
        0, /*-10-*/
        0, /*-11-*/
        0, /*-12-*/
        0, /*-13-*/
        0, /*-14-*/
        0, /*-15-*/
        0, /*-16-*/
        0, /*-17-*/
        0, /*-18-*/
        0, /*-19-*/
        0, /*-20-*/
        0, /*-21-*/
        0, /*-22-*/
        0 /*-23-*/
    }
};
struct sx_pci_profile pci_profile_single_eth_spectrum = {
    /*profile enum*/
    .pci_profile = PCI_PROFILE_EN_SINGLE_SWID,
    /*tx_prof: <swid,etclass> -> <stclass,sdq> */
    .tx_prof = {
        {
            {0, 2}, /*-0-best effort*/
            {1, 2}, /*-1-low prio*/
            {2, 2}, /*-2-medium prio*/
            {3, 2}, /*-3-*/
            {4, 2}, /*-4-*/
            {5, 1}, /*-5-high prio*/
            {6, 1}, /*-6-critical prio*/
            {6, 1} /*-7-*/
        }
    },
    /* emad_tx_prof */
    .emad_tx_prof = {
        0, 0
    },
    /* swid_type */
    .swid_type = {
        SX_KU_L2_TYPE_ETH,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE
    },
    /* rdq_count */
    .rdq_count = {
        37,     /* swid 0 */
        0,
        0,
        0,
        0,
        0,
        0,
        0
    },
    /* rdq */
    .rdq = {
        {
            /* swid 0 - ETH */
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            24,
            25,
            26,
            27,
            28,
            29,
            30,
            31,
            32,
            34,
            35,
            36
        },
    },
    /* emad_rdq */
    .emad_rdq = 33,
    /* rdq_properties */
    .rdq_properties = {
        /* SWID 0 */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-0-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-1-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-2-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-3-high priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-4-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-5-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-6-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-7-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-8-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-9-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-10-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-11-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-12-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-13-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-14-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-15-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-16-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-17-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-18-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-19-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-20-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-21-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-22-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-23-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-24-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-25-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-26-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-27-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-28-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-29-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-30-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-31-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-32-mirror agent*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-33-emad*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-34 - special */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-35 - special */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-36 - special */
    },
    /* cpu_egress_tclass per SDQ */
    .cpu_egress_tclass = {
        2, /*-0-EMAD SDQ */
        1, /*-1-Control SDQ */
        0, /*-2-Data SDQ */
        0, /*-3-*/
        0, /*-4-*/
        0, /*-5-*/
        0, /*-6-*/
        0, /*-7-*/
        0, /*-8-*/
        0, /*-9-*/
        0, /*-10-*/
        0, /*-11-*/
        0, /*-12-*/
        0, /*-13-*/
        0, /*-14-*/
        0, /*-15-*/
        0, /*-16-*/
        0, /*-17-*/
        0, /*-18-*/
        0, /*-19-*/
        0, /*-20-*/
        0, /*-21-*/
        0, /*-22-*/
        0 /*-23-55*/
    }
};

/* device profile */
struct ku_profile single_part_eth_device_profile = {
    .set_mask_0_63 = 0x73ff,    /* bit 9 and bits 10-11 are turned off*/
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 64,           /* 600,/ *TODO: PRM should define this field* / */
    .max_port_per_lag = 16, /*TODO: PRM should define this field*/
    .max_mid = 7000,
    .max_pgt = 0,
    .max_system_port = 48000,   /*TODO: PRM IS NOT UPDATED*/
    .max_active_vlans = 127,
    .max_regions = 400,
    .max_flood_tables = 2,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 2,
    .max_ib_mc = 0,
    .max_pkey = 0,
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .chip_type = SXD_CHIP_TYPE_SWITCHX_A1,
};
struct ku_profile single_part_eth_device_profile_a2 = {
    .set_mask_0_63 = 0x73ff,    /* bit 9 and bits 10-11 are turned off*/
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 64,           /* 600,/ *TODO: PRM should define this field* / */
    .max_port_per_lag = 16, /*TODO: PRM should define this field*/
    .max_mid = 7000,
    .max_pgt = 0,
    .max_system_port = 48000,   /*TODO: PRM IS NOT UPDATED*/
    .max_active_vlans = 127,
    .max_regions = 400,
    .max_flood_tables = 2,
    .max_per_vid_flood_tables = 1,
    .flood_mode = 3,
    .max_ib_mc = 0,
    .max_pkey = 0,
    .ar_sec = 0,
    .adaptive_routing_group_cap = 0,
    .arn = 0,
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ROUTER_PORT
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },

    .chip_type = SXD_CHIP_TYPE_SWITCHX_A2,
};
struct ku_profile single_part_eth_device_profile_spectrum = {
    .set_mask_0_63 = 0,         /* All bits are set during the init as follows:
                                 * bits 0-2   - reserved;
                                 * bit 3      - disabled (max_mid);
                                 * bits 4-7   - reserved;
                                 * bits 8     - enabled (set_flood_mode);
                                 * bits 9     - disabled (set_flood_tables);
                                 * bit 10     - disabled (set_max_fid);
                                 * bits 11-20 - reserved;
                                 * bit 22     - enabled (ubridge);
                                 * bits 23    - reserved;
                                 * bits 24    - enabled (set_kvd_linear_size);
                                 * bits 25    - enabled (set_kvd_hash_single_size);
                                 * bits 26    - enabled (set_kvd_hash_double_size);
                                 * bits 27-31 - reserved;
                                 * bit 32     - enabled (set cqe_version);
                                 * bits 33-63 - reserved; */
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,             /* reserved */
    .max_lag = 0,                       /* reserved */
    .max_port_per_lag = 0,              /* reserved */
    .max_mid = 0,                       /* value is calculated during init with RM values */
    .max_pgt = 0,                       /* reserved */
    .max_system_port = 0,               /* reserved */
    .max_active_vlans = 0,              /* reserved */
    .max_regions = 0,                   /* reserved */
    .max_flood_tables = 0,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 4,
    .max_ib_mc = 0,                     /* reserved */
    .max_pkey = 0,                      /* reserved */
    .ar_sec = 0,                        /* reserved */
    .adaptive_routing_group_cap = 0,    /* reserved */
    .arn = 0,                           /* reserved */
    .kvd_linear_size = 0x10000, /* 64K */
    .kvd_hash_single_size = 0x20000, /* 128K */
    .kvd_hash_double_size = 0xC000, /* 24K*2 = 48K */
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },

    .chip_type = SXD_CHIP_TYPE_SPECTRUM,
    .ubridge_mode = 1,
};
struct ku_profile single_part_eth_device_profile_reserved = {
    .set_mask_0_63 = 0,                 /* All bits are set during the init as follows:
                                         * bits 0-2   - reserved;
                                         * bit 3      - disabled (max_mid);
                                         * bits 4-7   - reserved;
                                         * bits 8     - enabled (set_flood_mode);
                                         * bits 9     - disabled (set_flood_tables);
                                         * bit 10     - disabled (set_max_fid);
                                         * bits 11-20 - reserved;
                                         * bit 21     - disabled (rfid);
                                         * bit 22     - enabled (ubridge);
                                         * bits 23-31 - reserved;
                                         * bit 32     - enabled (set cqe_version);
                                         * bits 33-63 - reserved; */
    .set_mask_64_127 = 0,               /* reserved */
    .max_vepa_channels = 0,             /* reserved */
    .max_lag = 0,                       /* reserved */
    .max_port_per_lag = 0,              /* reserved */
    .max_mid = 0,                       /* value is calculated during init with RM values */
    .max_pgt = 0,                       /* reserved */
    .max_system_port = 0,               /* reserved */
    .max_active_vlans = 0,              /* reserved */
    .max_regions = 0,                   /* reserved */
    .max_flood_tables = 0,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 4,
    .max_ib_mc = 0,                     /* reserved */
    .max_pkey = 0,                      /* reserved */
    .ar_sec = 0,                        /* reserved */
    .adaptive_routing_group_cap = 0,    /* reserved */
    .arn = 0,                           /* reserved */
    .ubridge_mode = 1,
    .kvd_linear_size = 0,               /* reserved */
    .kvd_hash_single_size = 0,          /* reserved */
    .kvd_hash_double_size = 0,          /* reserved */
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
};

/*****************************************************
 *		    MULTI PARTITION ETH
 ******************************************************/

/* <stclass,sdq> */

/*		|ETC0	  |ETC1	    |ETC2     |ETC3	|ETC4	  |ETC5	    |ETC6     |ETC7
 * ------------------------------------------------------------------------------------
 * Swid 0	|<0,0>	  |<1,1>    |<2,2>    |<3,3>    |<4,4>	  |<5,5>    |<6,6>    |<6,7>
 * Swid 1	|<0,8>    |<1,9>    |<2,10>   |<3,11>	|<4,12>   |<5,13>   |<6,14>   |<6,15>
 * Swid 2	|<0,16>   |<1,17>   |<2,18>   |<3,19>	|<4,20>   |<5,21>   |<6,22>   |<6,23>
 * Swid 3	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 4	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 5	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 6	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 7	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 *
 * */
/* Need to update when relevant */
struct sx_pci_profile pci_profile_multi_eth = {
    /*profile enum*/
    .pci_profile = PCI_PROFILE_EN_MULTI_SWID,
    /*tx_prof */
    .tx_prof = {
        {
            /**** swid 0 ****/
            {0, 0}, /*-0-*/
            {1, 1}, /*-1-*/
            {2, 2}, /*-2-*/
            {3, 3}, /*-3-*/
            {4, 4}, /*-4-*/
            {5, 5}, /*-5-*/
            {6, 6}, /*-6-*/
            {6, 7}, /*-7-*/
        },
        { /**** swid 1 ****/
            {0, 8}, /*-0-*/
            {1, 9}, /*-1-*/
            {2, 10}, /*-2-*/
            {3, 11}, /*-3-*/
            {4, 12}, /*-4-*/
            {5, 13}, /*-5-*/
            {6, 14}, /*-6-*/
            {6, 15}, /*-7-*/
        },
        { /**** swid 2 ****/
            {0, 16}, /*-0-*/
            {1, 20}, /*-1-*/
            {2, 21}, /*-2-*/
            {3, 22}, /*-3-*/
            {4, 23}, /*-4-*/
            {5, 21}, /*-5-*/
            {6, 22}, /*-6-*/
            {6, 23} /*-7-*/
        }
    },
    /* emad_tx_prof */
    .emad_tx_prof = {
        7, 16
    },
    /* swid_type */
    .swid_type = {
        SX_KU_L2_TYPE_ETH,
        SX_KU_L2_TYPE_ETH,
        SX_KU_L2_TYPE_ETH,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE
    },
    /* rdq_count */
    .rdq_count = {
        3,
        3,
        3,
        0,
        0,
        0,
        0,
        0
    },
    /* rdq */
    .rdq = {
        /* swid 0 */
        {0, 1, 2},
        /* swid 1 */
        {3, 4, 5},
        /* swid 2 */
        {6, 7, 8},
        /* swid 3 */
    },
    /* emad rdq  */
    .emad_rdq = 21,
    /* rdq_properties */
    .rdq_properties = {
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-0-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-1-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-2-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-3-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-4-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-5-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-6-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-7-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-8-*/
        {0, 0, 0, 0}, /*-9-*/
        {0, 0, 0, 0}, /*-10-*/
        {0, 0, 0, 0}, /*-11-*/
        {0, 0, 0, 0}, /*-12-*/
        {0, 0, 0, 0}, /*-13-*/
        {0, 0, 0, 0}, /*-14-*/
        {0, 0, 0, 0}, /*-15-*/
        {0, 0, 0, 0}, /*-16-*/
        {0, 0, 0, 0}, /*-17-*/
        {0, 0, 0, 0}, /*-18-*/
        {0, 0, 0, 0}, /*-19-*/
        {0, 0, 0, 0}, /*-20-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-21-*/
        {0, 0, 0, 0}, /*-22-*/
        {0, 0, 0, 0} /*-23-*/
    },
    /* cpu_egress_tclass */
    .cpu_egress_tclass = {
        0, /*-0-*/
        1, /*-1-*/
        1, /*-2-*/
        0, /*-3-*/
        2, /*-4-*/
        2, /*-5-*/
        0, /*-6-*/
        3, /*-7-*/
        3, /*-8-*/
        0, /*-9-*/
        4, /*-10-*/
        4, /*-11-*/
        0, /*-12-*/
        5, /*-13-*/
        5, /*-14-*/
        0, /*-15-*/
        6, /*-16-*/
        6, /*-17-*/
        0, /*-18-*/
        7, /*-19-*/
        7, /*-20-*/
        0, /*-21-*/
        8, /*-22-*/
        8 /*-23-*/
    }
};

/* device profile */
struct ku_profile multi_part_eth_device_profile = {
    .set_mask_0_63 = 0x73ff,    /* bit 9 and bits 10-11 are turned off*/
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 500,          /*TODO: PRM should define this field*/
    .max_port_per_lag = 8, /*TODO: PRM should define this field*/
    .max_mid = 2455,
    .max_pgt = 0,
    .max_system_port = 48000,   /*TODO: PRM IS NOT UPDATED*/
    .max_active_vlans = 4095,
    .max_regions = 400,
    .max_flood_tables = 2,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 1,
    .max_ib_mc = 0,
    .max_pkey = 0,
    .ar_sec = 0,
    .adaptive_routing_group_cap = 0,
    .arn = 0,
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },

    .chip_type = SXD_CHIP_TYPE_SWITCHX_A1,
};

/* device profile */
struct ku_profile multi_part_eth_device_profile_a2 = {
    .set_mask_0_63 = 0x73ff,    /* bit 9 and bits 10-11 are turned off*/
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 500,          /*TODO: PRM should define this field*/
    .max_port_per_lag = 8, /*TODO: PRM should define this field*/
    .max_mid = 2455,
    .max_pgt = 0,
    .max_system_port = 48000,   /*TODO: PRM IS NOT UPDATED*/
    .max_active_vlans = 4095,
    .max_regions = 400,
    .max_flood_tables = 2,
    .max_per_vid_flood_tables = 1,
    .flood_mode = 3,
    .max_ib_mc = 0,
    .max_pkey = 0,
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .chip_type = SXD_CHIP_TYPE_SWITCHX_A2,
};

/*****************************************************
 *		    SINGLE PARTITION IB
 ******************************************************/

/*		|QP0(SMI) |QP1(GSI) |QP2(UD1) |QP3(UD2)
 * ----------------------------------------------------
 * Swid 0	|0	  |1        |2        |2
 * Swid 1	|Disabled |Disabled |Disabled |Disabled
 * Swid 2	|Disabled |Disabled |Disabled |Disabled
 * Swid 3	|Disabled |Disabled |Disabled |Disabled
 * Swid 4	|Disabled |Disabled |Disabled |Disabled
 * Swid 5	|Disabled |Disabled |Disabled |Disabled
 * Swid 6	|Disabled |Disabled |Disabled |Disabled
 * Swid 7	|Disabled |Disabled |Disabled |Disabled
 *
 * */

/*		|number of RDQs | RDQs
 * ----------------------------------------------------
 * Swid 0	|3              | 0,1,2
 * Swid 1	|Disabled       |Disabled
 * Swid 2	|Disabled       |Disabled
 * Swid 3	|Disabled       |Disabled
 * Swid 4	|Disabled       |Disabled
 * Swid 5	|Disabled       |Disabled
 * Swid 6	|Disabled       |Disabled
 * Swid 7	|Disabled       |Disabled
 *
 * */
struct sx_pci_profile pci_profile_single_ib = {
    /*profile enum*/
    .pci_profile = PCI_PROFILE_IB_SINGLE_SWID,
    /*tx_prof */
    /* !!! IB DOES NOT HAVE STCLASS !!!*/
    .tx_prof = {
        { /**** swid 0 ****/
            {0, 2}, /*-0-*/
            {0, 2}, /*-1-*/
            {0, 2}, /*-2-*/
            {0, 2}, /*-3-*/
            {0, 2}, /*-4-for UD QPs*/
            {0, 1}, /*-5-for QP1*/
            {0, 0}, /*-6-for QP0*/
            {0, 2}, /*-7-*/
        }
    },
    /* emad_tx_prof */
    .emad_tx_prof = {0, 0},
    /* swid_type */
    .swid_type = {
        SX_KU_L2_TYPE_IB,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE
    },
    /* rdq_count */
    .rdq_count = {
        5,
        0,
        0,
        0,
        0,
        0,
        0,
        0
    },
    /* rdq */
    .rdq = {
        {
            0,
            1,
            2,
            3,
            4
        }
    },
    /* emad_rdq (for events) */
    .emad_rdq = 21,
    /* rdq_properties */
    .rdq_properties = {
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_UD_DEFAULT_SIZE, RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-0-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_UD_DEFAULT_SIZE, RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-1-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_UD_DEFAULT_SIZE, RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-2-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_UD_DEFAULT_SIZE, RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-3-high priority*/
        {RDQ_MAD_NUMBER_OF_ENTRIES, RDQ_IB_QP0_DEFAULT_SIZE, RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-4-critical priority*/
        {0, 0, 0, 0}, /*-5-*/
        {0, 0, 0, 0}, /*-6-*/
        {0, 0, 0, 0}, /*-7-*/
        {0, 0, 0, 0}, /*-8-*/
        {0, 0, 0, 0}, /*-9-*/
        {0, 0, 0, 0}, /*-10-*/
        {0, 0, 0, 0}, /*-11-*/
        {0, 0, 0, 0}, /*-12-*/
        {0, 0, 0, 0}, /*-13-*/
        {0, 0, 0, 0}, /*-14-*/
        {0, 0, 0, 0}, /*-15-*/
        {0, 0, 0, 0}, /*-16-*/
        {0, 0, 0, 0}, /*-17-*/
        {0, 0, 0, 0}, /*-18-*/
        {0, 0, 0, 0}, /*-19-*/
        {0, 0, 0, 0}, /*-20-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-21-*/
        {0, 0, 0, 0}, /*-22-*/
        {0, 0, 0, 0} /*-23-*/
    },
    /* cpu_egress_tclass */
    .cpu_egress_tclass = {
        2, /*-0-for QP0*/
        1, /*-1-for QP1*/
        0, /*-2-for UD QPs*/
        0, /*-3-*/
        0, /*-4-*/
        0, /*-5-*/
        0, /*-6-*/
        0, /*-7-*/
        0, /*-8-*/
        0, /*-9-*/
        0, /*-10-*/
        0, /*-11-*/
        0, /*-12-*/
        0, /*-13-*/
        0, /*-14-*/
        0, /*-15-*/
        0, /*-16-*/
        0, /*-17-*/
        0, /*-18-*/
        0, /*-19-*/
        0, /*-20-*/
        0, /*-21-*/
        0, /*-22-*/
        0 /*-23-*/
    }
};
struct ku_profile     single_part_ib_device_profile = {
    .set_mask_0_63 = 0xf3ff,
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 0,
    .max_port_per_lag = 0,
    .max_mid = 0,
    .max_pgt = 0,
    .max_system_port = 0,
    .max_active_vlans = 0,
    .max_regions = 0,
    .max_flood_tables = 0,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 0,
    .max_ib_mc = 27,
    .max_pkey = 126,
    .ar_sec = 1,
    .adaptive_routing_group_cap = 2048,
    .arn = 0,
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .chip_type = SXD_CHIP_TYPE_SWITCHX_A2,
};

/* device profile */
struct ku_profile single_part_ib_device_profile_switchib = {
    .set_mask_0_63 = 0xf3ff,
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 0,
    .max_port_per_lag = 0,
    .max_mid = 0,
    .max_pgt = 0,
    .max_system_port = 0,
    .max_active_vlans = 0,
    .max_regions = 0,
    .max_flood_tables = 0,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 0,
    .max_ib_mc = 27,
    .max_pkey = 32,
    .ar_sec = 2,
    .adaptive_routing_group_cap = 256,
    .arn = 1,
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .chip_type = SXD_CHIP_TYPE_SWITCH_IB,
};


/* device profile */
struct ku_profile single_part_ib_device_profile_switchib2 = {
    .set_mask_0_63 = 0xf3ff,
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 0,
    .max_port_per_lag = 0,
    .max_mid = 0,
    .max_pgt = 0,
    .max_system_port = 0,
    .max_active_vlans = 0,
    .max_regions = 0,
    .max_flood_tables = 0,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 0,
    .max_ib_mc = 27,
    .max_pkey = 32,
    .ar_sec = 2,
    .adaptive_routing_group_cap = 256,
    .arn = 1,
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .chip_type = SXD_CHIP_TYPE_SWITCH_IB,
};


/* device profile */
struct ku_profile single_part_ib_device_profile_quantum = {
    .set_mask_0_63 = 0x10f3ff,
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 0,
    .max_port_per_lag = 0,
    .max_mid = 0,
    .max_pgt = 0,
    .max_system_port = 0,
    .max_active_vlans = 0,
    .max_regions = 0,
    .max_flood_tables = 0,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 0,
    .max_ib_mc = 27,
    .max_pkey = 32,
    .ar_sec = 2,
    .adaptive_routing_group_cap = 256,
    .arn = 1,
    .swid0_config_type = {
        .mask = 3,
        .type = KU_SWID_TYPE_INFINIBAND,
        .properties = 0
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .chip_type = SXD_CHIP_TYPE_QUANTUM,

    /* For now FW has issue with running SM with split ports.
     *  Temporary disabling it. Need to update XML once it's enabled. */
    .split_ready = 0,
};
struct ku_profile single_part_ib_device_profile_quantum2 = {
    .set_mask_0_63 = 0x10f3ff,
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 0,
    .max_port_per_lag = 0,
    .max_mid = 0,
    .max_pgt = 0,
    .max_system_port = 0,
    .max_active_vlans = 0,
    .max_regions = 0,
    .max_flood_tables = 0,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 0,
    .max_ib_mc = 27,
    .max_pkey = 32,
    .ar_sec = 2,
    .adaptive_routing_group_cap = 256,
    .arn = 1,
    .swid0_config_type = {
        .mask = 3,
        .type = KU_SWID_TYPE_INFINIBAND,
        .properties = 0
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .chip_type = SXD_CHIP_TYPE_QUANTUM2,

    /* For now FW has issue with running SM with split ports.
     *  Temporary disabling it. Need to update XML once it's enabled. */
    .split_ready = 0,
};
struct ku_profile single_part_ib_device_profile_quantum3 = {
    .set_mask_0_63 = 0x10f3ff,
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 0,
    .max_port_per_lag = 0,
    .max_mid = 0,
    .max_pgt = 0,
    .max_system_port = 0,
    .max_active_vlans = 0,
    .max_regions = 0,
    .max_flood_tables = 0,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 0,
    .max_ib_mc = 27,
    .max_pkey = 32,
    .ar_sec = 2,
    .adaptive_routing_group_cap = 256,
    .arn = 1,
    .swid0_config_type = {
        .mask = 3,
        .type = KU_SWID_TYPE_INFINIBAND,
        .properties = 0
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .chip_type = SXD_CHIP_TYPE_QUANTUM3,

    /* For now FW has issue with running SM with split ports.
     *      *  Temporary disabling it. Need to update XML once it's enabled. */
    .split_ready = 0,
};

/*****************************************************
 *		    MULTI PARTITION IB
 ******************************************************/

/*		|QP0(SMI) |QP1(GSI) |QP2(UD1) |QP3(UD2)
 * ----------------------------------------------------
 * Swid 0	|0        |1        |2        |2
 * Swid 1	|3        |4        |5        |5
 * Swid 2	|6        |7        |8        |8
 * Swid 3	|9        |10       |11       |11
 * Swid 4	|12       |13       |14       |14
 * Swid 5	|15       |16       |17       |17
 * Swid 6	|18       |19       |20       |20
 * Swid 7	|21       |22       |23       |23
 *
 * */


/*		|number of RDQs | RDQs
 * ----------------------------------------------------
 * Swid 0	|3              | 0,1,2
 * Swid 1	|3              | 3,4,5
 * Swid 2	|3              | 6,7,8
 * Swid 3	|3              | 9,10,11
 * Swid 4	|3              | 12,13,14
 * Swid 5	|3              | 15,16,17
 * Swid 6	|3              | 18,19,20
 * Swid 7	|3              | 21,22,23
 *
 * */

/* Need to update when relevant */
struct sx_pci_profile pci_profile_multi_ib = {
    /*profile enum*/
    .pci_profile = PCI_PROFILE_IB_MULTI_SWID,
    /*tx_prof */
    /* !!! IB DOES NOT HAVE STCLASS !!!*/
    .tx_prof = {
        { /**** swid 0 ****/
            {0, 0}, /*-0-*/
            {0, 1}, /*-1-*/
            {0, 2}, /*-2-*/
            {0, 2}, /*-3-*/
        },
        { /**** swid 1 ****/
            {0, 3}, /*-0-*/
            {0, 4}, /*-1-*/
            {0, 5}, /*-2-*/
            {0, 5}, /*-3-*/
        },
        { /**** swid 2 ****/
            {0, 6}, /*-0-*/
            {0, 7}, /*-1-*/
            {0, 8}, /*-2-*/
            {0, 8}, /*-3-*/
        },
        { /**** swid 3 ****/
            {0, 9}, /*-0-*/
            {0, 10}, /*-1-*/
            {0, 11}, /*-2-*/
            {0, 11}, /*-3-*/
        },
        { /**** swid 4 ****/
            {0, 12}, /*-0-*/
            {0, 13}, /*-1-*/
            {0, 14}, /*-2-*/
            {0, 14}, /*-3-*/
        },
        { /**** swid 5 ****/
            {0, 15}, /*-0-*/
            {0, 16}, /*-1-*/
            {0, 17}, /*-2-*/
            {0, 17}, /*-3-*/
        },
        { /**** swid 6 ****/
            {0, 18}, /*-0-*/
            {0, 19}, /*-1-*/
            {0, 20}, /*-2-*/
            {0, 20}, /*-3-*/
        },
        { /**** swid 7 ****/
            {0, 21}, /*-0-*/
            {0, 22}, /*-1-*/
            {0, 23}, /*-2-*/
            {0, 23} /*-3-*/
        }
    },
    /* no emad_tx_prof */
    .emad_tx_prof = {0, 0},
    /* swid_type */
    .swid_type = {
        SX_KU_L2_TYPE_IB,
        SX_KU_L2_TYPE_IB,
        SX_KU_L2_TYPE_IB,
        SX_KU_L2_TYPE_IB,
        SX_KU_L2_TYPE_IB,
        SX_KU_L2_TYPE_IB,
        SX_KU_L2_TYPE_IB,
        SX_KU_L2_TYPE_IB
    },
    /* rdq_count */
    .rdq_count = {
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2
    },
    /* rdq */
    .rdq = {
        /* swid 0 */
        {0, 1},
        /* swid 1 */
        {2, 3},
        /* swid 2 */
        {4, 5},
        /* swid 3 */
        {6, 7},
        /* swid 4 */
        {8, 9},
        /* swid 5 */
        {10, 11},
        /* swid 6 */
        {12, 13},
        /* swid 7 */
        {14, 15}
    },
    /* emad_rdq (for events)*/
    .emad_rdq = 21,
    /* rdq_properties */
    .rdq_properties = {
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_QP0_DEFAULT_SIZE, RDQ_IB_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-0-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_UD_DEFAULT_SIZE, RDQ_IB_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-1-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_QP0_DEFAULT_SIZE, RDQ_IB_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-2-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_UD_DEFAULT_SIZE, RDQ_IB_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-3-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_QP0_DEFAULT_SIZE, RDQ_IB_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-4-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_UD_DEFAULT_SIZE, RDQ_IB_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-5-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_QP0_DEFAULT_SIZE, RDQ_IB_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-6-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_UD_DEFAULT_SIZE, RDQ_IB_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-7-*/
        {0, 0, 0, 0}, /*-8-*/
        {0, 0, 0, 0}, /*-9-*/
        {0, 0, 0, 0}, /*-10-*/
        {0, 0, 0, 0}, /*-11-*/
        {0, 0, 0, 0}, /*-12-*/
        {0, 0, 0, 0}, /*-13-*/
        {0, 0, 0, 0}, /*-14-*/
        {0, 0, 0, 0}, /*-15-*/
        {0, 0, 0, 0}, /*-16-*/
        {0, 0, 0, 0}, /*-17-*/
        {0, 0, 0, 0}, /*-18-*/
        {0, 0, 0, 0}, /*-19-*/
        {0, 0, 0, 0}, /*-20-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_MULTI_SWID_DEFAULT_WEIGHT, 0}, /*-21-*/
        {0, 0, 0, 0}, /*-22-*/
        {0, 0, 0, 0}, /*-23-*/
    },
    /* cpu_egress_tclass */
    .cpu_egress_tclass = {
        0, /*-0-*/
        1, /*-1-*/
        1, /*-2-*/
        0, /*-3-*/
        2, /*-4-*/
        2, /*-5-*/
        0, /*-6-*/
        3, /*-7-*/
        3, /*-8-*/
        0, /*-9-*/
        4, /*-10-*/
        4, /*-11-*/
        0, /*-12-*/
        5, /*-13-*/
        5, /*-14-*/
        0, /*-15-*/
        6, /*-16-*/
        6, /*-17-*/
        0, /*-18-*/
        7, /*-19-*/
        7, /*-20-*/
        0, /*-21-*/
        8, /*-22-*/
        8 /*-23-*/
    }
};

/* device profile */
struct ku_profile multi_part_ib_device_profile = {
    .set_mask_0_63 = 0x73ff,    /* bit 9 and bits 10-11 are turned off*/
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 0,
    .max_port_per_lag = 0,
    .max_mid = 0,
    .max_pgt = 0,
    .max_system_port = 0,
    .max_active_vlans = 0,
    .max_regions = 0,
    .max_ib_mc = 3,        /*TODO: PRM should define this field*/
    .max_pkey = 126,
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .swid2_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_INFINIBAND
    },
    .chip_type = SXD_CHIP_TYPE_SWITCHX_A2,
};


/*****************************************************
 *		    VPI
 ******************************************************/

/*		|QP0(SMI) |QP1(GSI) |QP2(UD1) |QP3(UD2)
 * ----------------------------------------------------
 * Swid 0	|               E T H
 * Swid 1	|0	  |1        |2        |2
 * Swid 2	|Disabled |Disabled |Disabled |Disabled
 * Swid 3	|Disabled |Disabled |Disabled |Disabled
 * Swid 4	|Disabled |Disabled |Disabled |Disabled
 * Swid 5	|Disabled |Disabled |Disabled |Disabled
 * Swid 6	|Disabled |Disabled |Disabled |Disabled
 * Swid 7	|Disabled |Disabled |Disabled |Disabled
 *
 * */

/*		|ETC0	  |ETC1	    |ETC2     |ETC3	|ETC4	  |ETC5	    |ETC6     |ETC7
 * ------------------------------------------------------------------------------------
 * Swid 0	|<1,3>	  |<1,4>    |<2,5>    |<3,6>    |<4,7>	  |<5,8>    |<6,9>    |<7,10>
 * Swid 1	|	                     I N F I N B A N D
 * Swid 2	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 3	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 4	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 5	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 6	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 * Swid 7	|Disabled |Disabled |Disabled |Disabled	|Disabled |Disabled |Disabled |Disabled
 *
 * */


/*		|number of RDQs | RDQs
 * ----------------------------------------------------
 * Swid 0	|3              | 0,1,2
 * Swid 1	|5	        | 3,4,5,6,7
 * Swid 2	|Disabled       |Disabled
 * Swid 3	|Disabled       |Disabled
 * Swid 4	|Disabled       |Disabled
 * Swid 5	|Disabled       |Disabled
 * Swid 6	|Disabled       |Disabled
 * Swid 7	|Disabled       |Disabled
 *
 * */
struct sx_pci_profile pci_profile_vpi = {
    /*profile enum*/
    .pci_profile = PCI_PROFILE_VPI_SINGLE_SWID,
    /*tx_prof */
    .tx_prof = {
        { /**** swid 0 ETH ****/
          /* stclass,SDQ */
            {0, 5}, /*-0-*/
            {1, 5}, /*-1-*/
            {2, 5}, /*-2-*/
            {3, 5}, /*-3-*/
            {4, 5}, /*-4-*/
            {5, 4}, /*-5-*/
            {6, 3}, /*-6-*/
            {6, 3}, /*-7-*/
        },
        { /**** swid 1 Router Port ****/
          /* stclass,SDQ */
            {0, 8}, /*-0-*/
            {1, 8}, /*-1-*/
            {2, 8}, /*-2-*/
            {3, 8}, /*-3-*/
            {4, 8}, /*-4-*/
            {5, 7}, /*-5-*/
            {6, 6}, /*-6-*/
            {6, 6}, /*-7-*/
        },
        { /**** swid 2 IB ****/
            {0, 2},   /*-0-*/
            {0, 2},   /*-1-*/
            {0, 2},   /*-2-*/
            {0, 2},   /*-3-*/
            {0, 2},   /*-4-for UD QPs*/
            {0, 1},   /*-5-for QP1*/
            {0, 0},   /*-6-for QP0*/
            {0, 2},   /*-7-*/
        }
    },
    /* emad_tx_prof */
    .emad_tx_prof = {7, 11},
    /* swid_type */
    .swid_type = {
        SX_KU_L2_TYPE_ETH,
        SX_KU_L2_TYPE_ROUTER_PORT,
        SX_KU_L2_TYPE_IB,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE
    },
    .ipoib_router_port_enable = {
        0,
        0,
        1,
        0,
        0,
        0,
        0,
        0,
    },
    .max_pkey = 126,
    /* rdq_count (per SWID)*/
    .rdq_count = {
        4,
        4,
        5,
        0,
        0,
        0,
        0,
        0
    },
    /* rdq */
    .rdq = {
        {0, 1, 2, 3}, /* RDQs for swid 0 (ETH) */
        {4, 5, 6, 7}, /* RDQs for swid 1 (RP) */
        {8, 9, 10, 11, 12}  /* RDQs for swid 2 (IB)  */
    },
    /* emad_rdq */
    .emad_rdq = 21,
    /* rdq_properties */
    .rdq_properties = {
        /* swid 0 - ETH */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},      /*-0-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-1-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},      /*-2-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-3-high priority*/
        /* swid 1 - ETH RP */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},      /*-4-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-5-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},      /*-6-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-7-high priority*/
        /* swid 2 - IB */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_UD_DEFAULT_SIZE, RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT, 0},     /*-8-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT, 0},  /*-9-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_IB_UD_DEFAULT_SIZE, RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT, 0},     /*-10-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_LEGACY, RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT, 0},  /*-11-high priority*/
        {RDQ_MAD_NUMBER_OF_ENTRIES, RDQ_IB_QP0_DEFAULT_SIZE, RDQ_IB_SINGLE_SWID_DEFAULT_WEIGHT, 0},        /*-12-critical priority*/

        {0, 0, 0, 0}, /*-13-*/
        {0, 0, 0, 0}, /*-14-*/
        {0, 0, 0, 0}, /*-15-*/
        {0, 0, 0, 0}, /*-16-*/
        {0, 0, 0, 0}, /*-17-*/
        {0, 0, 0, 0}, /*-18-*/
        {0, 0, 0, 0}, /*-19-*/
        {0, 0, 0, 0}, /*-20-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_DEFAULT_SIZE, RDQ_VPI_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-21-critical priority*/
        {0, 0, 0, 0}, /*-22-*/
        {0, 0, 0, 0} /*-23-*/
    },
    /* cpu_egress_tclass */
    .cpu_egress_tclass = {
        2, /*-0-IB QP0*/
        1, /*-1-IB QP1*/
        0, /*-2-IB UD QPs*/
        3, /*-3-ETH Etclass 6 L2 data+ctrl*/
        1, /*-4-ETH Etclass 5 Netdevice packets*/
        0, /*-5-ETH Etclasses 0,1,2 (low, med, best effort prios)*/
        0, /*-6-*/
        0, /*-7-*/
        0, /*-8-*/
        0, /*-9-*/
        0, /*-10-*/
        4, /*-11-EMADs*/
        0, /*-12-*/
        0, /*-13-*/
        0, /*-14-*/
        0, /*-15-*/
        0, /*-16-*/
        0, /*-17-*/
        0, /*-18-*/
        0, /*-19-*/
        0, /*-20-*/
        0, /*-21-*/
        0, /*-22-*/
        0 /*-23-*/
    }
};

/* VPI_SINGLE_SWITCH */
struct ku_profile     vpi_device_profile = {
    .set_mask_0_63 = 0x73ff,
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 64,
    .max_port_per_lag = 16,
    .max_mid = 4450,
    .max_pgt = 0,
    .max_system_port = 48000,
    .max_active_vlans = 127,
    .max_regions = 400,
    .max_flood_tables = 2,
    .max_per_vid_flood_tables = 0,
    .flood_mode = 1,
    .max_ib_mc = 6,
    .max_pkey = 0,
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED,
    },
    .swid2_config_type = {
        .mask = 3,
        .type = KU_SWID_TYPE_INFINIBAND,
        .properties = 1,
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .chip_type = SXD_CHIP_TYPE_SWITCHX_A1,
};
struct ku_profile     vpi_device_profile_a2 = {
    .set_mask_0_63 = 0x73ff,
    .set_mask_64_127 = 0,
    .max_vepa_channels = 0,
    .max_lag = 64,
    .max_port_per_lag = 16,
    .max_mid = 4450,
    .max_pgt = 0,
    .max_system_port = 48000,
    .max_active_vlans = 127,
    .max_regions = 400,
    .max_flood_tables = 2,
    .max_per_vid_flood_tables = 1,
    .flood_mode = 3,
    .max_ib_mc = 6,
    .max_pkey = 0,
    .ar_sec = 0,
    .adaptive_routing_group_cap = 0,
    .arn = 0,
    .swid0_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ETHERNET
    },
    .swid1_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_ROUTER_PORT,
    },
    .swid2_config_type = {
        .mask = 3,
        .type = KU_SWID_TYPE_INFINIBAND,
        .properties = 1,
    },
    .swid3_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid4_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid5_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid6_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .swid7_config_type = {
        .mask = 1,
        .type = KU_SWID_TYPE_DISABLED
    },
    .chip_type = SXD_CHIP_TYPE_SWITCHX_A2,
};
struct sx_pci_profile pci_profile_single_eth_spectrum2 = {
    /*profile enum*/
    .pci_profile = PCI_PROFILE_EN_SINGLE_SWID,
    /*tx_prof: <swid,etclass> -> <stclass,sdq> */
    .tx_prof = {
        {
            {0}
        }
    },                   /* reserved */

    /* emad_tx_prof */
    .emad_tx_prof = {0}, /* reserved */

    /* swid_type */
    .swid_type = {
        SX_KU_L2_TYPE_ETH,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE
    },
    /* rdq_count */
    .rdq_count = {
        56,
        0,
        0,
        0,
        0,
        0,
        0,
        0
    },
    /* rdq */
    .rdq = {
        {
            /* swid 0 - ETH */
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            24,
            25,
            26,
            27,
            28,
            29,
            30,
            31,
            32,
            34,
            35,
            36,
            37,
            38,
            39,
            40,
            41,
            42,
            43,
            44,
            45,
            46,
            47,
            48,
            49,
            50,
            51,
            52,
            53,
            54,
            55
        },
    },
    /* emad_rdq */
    .emad_rdq = 33,
    /* rdq_properties */
    .rdq_properties = {
        /* SWID 0 */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-0-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},   /*-1-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-2-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},   /*-3-high priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-4-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-5-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-6-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-7-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-8-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-9-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-10-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-11-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-12-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-13-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-14-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-15-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-16-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-17-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-18-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-19-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-20-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-21-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-22-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-23-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-24-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-25-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-26-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-27-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-28-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-29-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-30-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-31-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-32-mirror agent*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-33-emad*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-34-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-35-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-36-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-37-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-38-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-39-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-40-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-41-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-42-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-43-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-44-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-45-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-46-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-47-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-48-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-49-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-50-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-51-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-52-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-53-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-54-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC2, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-55-*/
    },
    /* cpu_egress_tclass per SDQ */
    .cpu_egress_tclass = {
        2, /*-0-EMAD SDQ */
        1, /*-1-Control SDQ */
        0, /*-2-Data SDQ */
        0, /*-3-*/
        0, /*-4-*/
        0, /*-5-*/
        0, /*-6-*/
        0, /*-7-*/
        0, /*-8-*/
        0, /*-9-*/
        0, /*-10-*/
        0, /*-11-*/
        0, /*-12-*/
        0, /*-13-*/
        0, /*-14-*/
        0, /*-15-*/
        0, /*-16-*/
        0, /*-17-*/
        0, /*-18-*/
        0, /*-19-*/
        0, /*-20-*/
        0, /*-21-*/
        0, /*-22-*/
        0 /*-23-55*/
    }
};
struct sx_pci_profile pci_profile_single_eth_spectrum3 = {
    /*profile enum*/
    .pci_profile = PCI_PROFILE_EN_SINGLE_SWID,
    /*tx_prof: <swid,etclass> -> <stclass,sdq> */
    .tx_prof = {
        {
            {0}
        }
    },                   /* reserved */

    /* emad_tx_prof */
    .emad_tx_prof = {0}, /* reserved */

    /* swid_type */
    .swid_type = {
        SX_KU_L2_TYPE_ETH,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE
    },
    /* rdq_count */
    .rdq_count = {
        56,
        0,
        0,
        0,
        0,
        0,
        0,
        0
    },
    /* rdq */
    .rdq = {
        {
            /* swid 0 - ETH */
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            24,
            25,
            26,
            27,
            28,
            29,
            30,
            31,
            32,
            34,
            35,
            36,
            37,
            38,
            39,
            40,
            41,
            42,
            43,
            44,
            45,
            46,
            47,
            48,
            49,
            50,
            51,
            52,
            53,
            54,
            55
        },
    },
    /* emad_rdq */
    .emad_rdq = 33,
    /* rdq_properties */
    .rdq_properties = {
        /* SWID 0 */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-0-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},   /*-1-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-2-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},   /*-3-high priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-4-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-5-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-6-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-7-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-8-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-9-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-10-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-11-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-12-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-13-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-14-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-15-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-16-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-17-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-18-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-19-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-20-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-21-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-22-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-23-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-24-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-25-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-26-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-27-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-28-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-29-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-30-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-31-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-32-mirror agent*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-33-emad*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-34-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-35-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-36-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-37-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-38-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-39-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-40-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-41-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-42-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-43-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-44-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-45-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-46-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-47-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-48-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-49-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-50-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-51-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-52-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-53-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-54-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC3, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-55-*/
    },
    /* cpu_egress_tclass per SDQ */
    .cpu_egress_tclass = {
        2, /*-0-EMAD SDQ */
        1, /*-1-Control SDQ */
        0, /*-2-Data SDQ */
        0, /*-3-*/
        0, /*-4-*/
        0, /*-5-*/
        0, /*-6-*/
        0, /*-7-*/
        0, /*-8-*/
        0, /*-9-*/
        0, /*-10-*/
        0, /*-11-*/
        0, /*-12-*/
        0, /*-13-*/
        0, /*-14-*/
        0, /*-15-*/
        0, /*-16-*/
        0, /*-17-*/
        0, /*-18-*/
        0, /*-19-*/
        0, /*-20-*/
        0, /*-21-*/
        0, /*-22-*/
        0 /*-23-55*/
    }
};
struct sx_pci_profile pci_profile_single_eth_spectrum4 = {
    /*profile enum*/
    .pci_profile = PCI_PROFILE_EN_SINGLE_SWID,
    /*tx_prof: <swid,etclass> -> <stclass,sdq> */
    .tx_prof = {
        {
            {0}
        }
    },                   /* reserved */

    /* emad_tx_prof */
    .emad_tx_prof = {0}, /* reserved */

    /* swid_type */
    .swid_type = {
        SX_KU_L2_TYPE_ETH,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE
    },
    /* rdq_count */
    .rdq_count = {
        56,
        0,
        0,
        0,
        0,
        0,
        0,
        0
    },
    /* rdq */
    .rdq = {
        {
            /* swid 0 - ETH */
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            24,
            25,
            26,
            27,
            28,
            29,
            30,
            31,
            32,
            34,
            35,
            36,
            37,
            38,
            39,
            40,
            41,
            42,
            43,
            44,
            45,
            46,
            47,
            48,
            49,
            50,
            51,
            52,
            53,
            54,
            55
        },
    },
    /* emad_rdq */
    .emad_rdq = 33,
    /* rdq_properties */
    .rdq_properties = {
        /* SWID 0 */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-0-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},   /*-1-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-2-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},   /*-3-high priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-4-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-5-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-6-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-7-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-8-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-9-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-10-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-11-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-12-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-13-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-14-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-15-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-16-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-17-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-18-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-19-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-20-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-21-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-22-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-23-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-24-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-25-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-26-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-27-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-28-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-29-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-30-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-31-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-32-mirror agent*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-33-emad*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-34-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-35-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-36-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-37-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-38-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-39-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-40-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-41-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-42-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-43-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-44-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-45-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-46-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-47-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-48-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-49-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-50-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-51-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-52-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-53-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-54-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-55-*/
    },
    /* cpu_egress_tclass per SDQ */
    .cpu_egress_tclass = {
        2, /*-0-EMAD SDQ */
        1, /*-1-Control SDQ */
        0, /*-2-Data SDQ */
        0, /*-3-*/
        0, /*-4-*/
        0, /*-5-*/
        0, /*-6-*/
        0, /*-7-*/
        0, /*-8-*/
        0, /*-9-*/
        0, /*-10-*/
        0, /*-11-*/
        0, /*-12-*/
        0, /*-13-*/
        0, /*-14-*/
        0, /*-15-*/
        0, /*-16-*/
        0, /*-17-*/
        0, /*-18-*/
        0, /*-19-*/
        0, /*-20-*/
        0, /*-21-*/
        0, /*-22-*/
        0 /*-23-55*/
    }
};
struct sx_pci_profile pci_profile_single_eth_spectrum5 = {
    /*profile enum*/
    .pci_profile = PCI_PROFILE_EN_SINGLE_SWID,
    /*tx_prof: <swid,etclass> -> <stclass,sdq> */
    .tx_prof = {
        {
            {0}
        }
    },                   /* reserved */

    /* emad_tx_prof */
    .emad_tx_prof = {0}, /* reserved */

    /* swid_type */
    .swid_type = {
        SX_KU_L2_TYPE_ETH,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE,
        SX_KU_L2_TYPE_DONT_CARE
    },
    /* rdq_count */
    .rdq_count = {
        56,
        0,
        0,
        0,
        0,
        0,
        0,
        0
    },
    /* rdq */
    .rdq = {
        {
            /* swid 0 - ETH */
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            24,
            25,
            26,
            27,
            28,
            29,
            30,
            31,
            32,
            34,
            35,
            36,
            37,
            38,
            39,
            40,
            41,
            42,
            43,
            44,
            45,
            46,
            47,
            48,
            49,
            50,
            51,
            52,
            53,
            54,
            55
        },
    },
    /* emad_rdq */
    .emad_rdq = 33,
    /* rdq_properties */
    .rdq_properties = {
        /* SWID 0 */
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-0-best effort priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},   /*-1-low priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-2-medium priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0},   /*-3-high priority*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-4-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-5-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-6-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-7-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-8-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-9-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-10-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-11-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-12-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-13-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-14-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-15-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-16-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-17-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-18-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-19-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-20-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-21-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-22-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-23-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-24-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-25-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-26-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-27-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-28-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-29-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-30-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-31-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-32-mirror agent*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-33-emad*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-34-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-35-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-36-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-37-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-38-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-39-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-40-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-41-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-42-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-43-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-44-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-45-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-46-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-47-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-48-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-49-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-50-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-51-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-52-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-53-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-54-*/
        {RDQ_DEFAULT_NUMBER_OF_ENTRIES, RDQ_ETH_LARGE_SIZE_SPC4, RDQ_ETH_SINGLE_SWID_DEFAULT_WEIGHT, 0}, /*-55-*/
    },
    /* cpu_egress_tclass per SDQ */
    .cpu_egress_tclass = {
        2, /*-0-EMAD SDQ */
        1, /*-1-Control SDQ */
        0, /*-2-Data SDQ */
        0, /*-3-*/
        0, /*-4-*/
        0, /*-5-*/
        0, /*-6-*/
        0, /*-7-*/
        0, /*-8-*/
        0, /*-9-*/
        0, /*-10-*/
        0, /*-11-*/
        0, /*-12-*/
        0, /*-13-*/
        0, /*-14-*/
        0, /*-15-*/
        0, /*-16-*/
        0, /*-17-*/
        0, /*-18-*/
        0, /*-19-*/
        0, /*-20-*/
        0, /*-21-*/
        0, /*-22-*/
        0 /*-23-55*/
    }
};
