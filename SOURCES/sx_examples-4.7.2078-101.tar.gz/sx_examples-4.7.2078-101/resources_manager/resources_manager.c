/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sys/types.h>
#include <getopt.h>
#include <errno.h>
#include <string.h>
#include <libgen.h>
#include <sx/sxd/sxdev.h>
#include <sx/sdk/sx_dev.h>
#include <sx/sdk/sx_mac.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_access_register_init.h>
#include <complib/sx_log.h>
#include <complib/sx_xml.h>
#include "resources_manager_config.h"
#include <netinet/ether.h>
#include <sx/sdk/sx_init.h>
#include <linux/limits.h>

#define SWITCHX_PCI_ID          0xc738
#define SWITCHIB_PCI_ID         0xcb20
#define SPECTRUM_PCI_ID         0xcb84
#define DONT_CARE_ETH_SWID      254
#define EMAD_TRAP_GROUP         4
#define MAD_TRAP_GROUP          4
#define OTHER_QP_TRAP_GROUP     1
#define EXTERNAL_SMA_TRAP_GROUP 4 /* Same as switch QP0 trap group */
#define DEFAULT_CPU_TCLASS      7
#define QP1_OTHER_QP_CPU_TCLASS 8
#define DEFAULT_STACKING_TCLASS 7
#define MAX_BOOT_MODE_NAME      25

#define DEV_NOT_PRESENT -99

#define EVB_XML_PARSE_UINT(sx_xml_element_t, uint_var, var_name, rc)                   \
    do {                                                                               \
        if (sx_xml_element_t != NULL) {                                                \
            uint_var = strtoul(sx_xml_element_content_get(sx_xml_element_t), NULL, 0); \
        } else {                                                                       \
            SX_LOG_ERR("Error parsing %s\n", var_name);                                \
            rc = EVB_STATUS_PARSE_ERROR;                                               \
        }                                                                              \
    } while (0)

#define EVB_XML_PARSE_MAC_ADDR(mac_element, mac_var, var_name, rc)                   \
    do {                                                                             \
        if (mac_element != NULL) {                                                   \
            memcpy(mac_var, ether_aton(sx_xml_element_content_get(mac_element)), 6); \
            if (mac_var == NULL) {                                                   \
                SX_LOG_ERR("Error parsing MAC address %s\n", var_name);              \
                rc = EVB_STATUS_PARSE_ERROR;                                         \
            }                                                                        \
        }                                                                            \
    } while (0)


#define EVB_XML_PARSE_IP_ADDR(ip_element, ip_var, var_name, rc)                 \
    do {                                                                        \
        struct in_addr network;                                                 \
        if (inet_aton(sx_xml_element_content_get(ip_element), &network) == 0) { \
            SX_LOG_ERR("Error parsing network IP\n");                           \
            rc = EVB_STATUS_PARSE_ERROR;                                        \
        }                                                                       \
        ip_var = ntohl(network.s_addr);                                         \
    } while (0);


static struct option sx_core_long_options[] = {
    {"smac",                    required_argument,  NULL,   'm' },
    {"device",                  required_argument,  NULL,   'd' },
    {"dpt-all-devices",         no_argument,        NULL,   'a' },
    {"use-sgmii",               no_argument,        NULL,   's' },
    {"boot_mode",               required_argument,  NULL,   'b' },
    {"use_internal_init_flow",  required_argument,  NULL,   'u' },
    {"version",                 no_argument,        NULL,   'v' },
    {"help",                    no_argument,        NULL,   'h' },
    {"verbosity",               required_argument,  NULL,   'l' },
    {"no_verbosity",            no_argument,        NULL,   'n' },
    {0,             0,          0,  0   }
};
int                  dev_id_to_dpt_id_map[] = {
    1,
    2,
    19,
    20,
    21,
    22,
    23,
    24
};
int                  dev_id_to_i2c_dev_id_map[] = {
    0, /* invalid, no such device id */
    0x420248, /* 1 = spine 1 */
    0x430248, /* 2 = spine 2 */
    0x440248, /* 3 = spine 3 */
    0x450248, /* 4 = spine 4 */
    0x460248, /* 5 = spine 5 */
    0x470248, /* 6 = spine 6 */
    0x480248, /* 7 = spine 7 */
    0x490248, /* 8 = spine 8 */
    0x3a0248, /* 9 = spine 9 */
    0x3b0248, /* 10 = spine 10 */
    0x3c0248, /* 11 = spine 11 */
    0x3d0248, /* 12 = spine 12 */
    0x3e0248, /* 13 = spine 13 */
    0x3f0248, /* 14 = spine 14 */
    0x400248, /* 15 = spine 15 */
    0x410248, /* 16 = spine 16 */
    0x320248, /* 17 = spine 17 */
    0x330248, /* 18 = spine 18 */
    0x220248, /* 19 = leaf 1 */
    0x230248, /* 20 = leaf 2 */
    0x240248, /* 21 = leaf 3 */
    0x250248, /* 22 = leaf 4 */
    0x260248, /* 23 = leaf 5 */
    0x270248, /* 24 = leaf 6 */
    0x280248, /* 25 = leaf 7 */
    0x290248, /* 26 = leaf 8 */
    0x1a0248, /* 27 = leaf 9 */
    0x1b0248, /* 28 = leaf 10 */
    0x1c0248, /* 29 = leaf 11 */
    0x1d0248, /* 30 = leaf 12 */
    0x1e0248, /* 31 = leaf 13 */
    0x1f0248, /* 32 = leaf 14 */
    0x200248, /* 33 = leaf 15 */
    0x210248, /* 34 = leaf 16 */
    0x120248, /* 35 = leaf 17 */
    0x130248, /* 36 = leaf 18 */
    0x140248, /* 37 = leaf 19 */
    0x150248, /* 38 = leaf 20 */
    0x160248, /* 39 = leaf 21 */
    0x170248, /* 40 = leaf 22 */
    0x180248, /* 41 = leaf 23 */
    0x190248, /* 42 = leaf 24 */
    0x0a0248, /* 43 = leaf 25 */
    0x0b0248, /* 44 = leaf 26 */
    0x0c0248, /* 45 = leaf 27 */
    0x0d0248, /* 46 = leaf 28 */
    0x0e0248, /* 47 = leaf 29 */
    0x0f0248, /* 48 = leaf 30 */
    0x100248, /* 49 = leaf 31 */
    0x110248, /* 50 = leaf 32 */
    0x2a0248, /* 51 = leaf 33 */
    0x2b0248, /* 52 = leaf 34 */
    0x2c0248, /* 53 = leaf 35 */
    0x2d0248, /* 54 = leaf 36 */
    0x420248, /* 55 = spine 1 */
    0x430248, /* 56 = spine 2 */
    0x440248, /* 57 = spine 3 */
    0x450248, /* 58 = spine 4 */
    0x460248, /* 59 = spine 5 */
    0x470248, /* 60 = spine 6 */
    0x480248, /* 61 = spine 7 */
    0x490248, /* 62 = spine 8 */
    0x3a0248, /* 63 = spine 9 */
    0x3b0248, /* 64 = spine 10 */
    0x3c0248, /* 65 = spine 11 */
    0x3d0248, /* 66 = spine 12 */
    0x3e0248, /* 67 = spine 13 */
    0x3f0248, /* 68 = spine 14 */
    0x400248, /* 69 = spine 15 */
    0x410248, /* 70 = spine 16 */
    0x320248, /* 71 = spine 17 */
    0x330248, /* 72 = spine 18 */
    0x220248, /* 73 = leaf 1 */
    0x230248, /* 74 = leaf 2 */
    0x240248, /* 75 = leaf 3 */
    0x250248, /* 76 = leaf 4 */
    0x260248, /* 77 = leaf 5 */
    0x270248, /* 78 = leaf 6 */
    0x280248, /* 79 = leaf 7 */
    0x290248, /* 80 = leaf 8 */
    0x1a0248, /* 81 = leaf 9 */
    0x1b0248, /* 82 = leaf 10 */
    0x1c0248, /* 83 = leaf 11 */
    0x1d0248, /* 84 = leaf 12 */
    0x1e0248, /* 85 = leaf 13 */
    0x1f0248, /* 86 = leaf 14 */
    0x200248, /* 87 = leaf 15 */
    0x210248, /* 88 = leaf 16 */
    0x120248, /* 89 = leaf 17 */
    0x130248, /* 90 = leaf 18 */
    0x140248, /* 91 = leaf 19 */
    0x150248, /* 92 = leaf 20 */
    0x160248, /* 93 = leaf 21 */
    0x170248, /* 94 = leaf 22 */
    0x180248, /* 95 = leaf 23 */
    0x190248, /* 96 = leaf 24 */
    0x0a0248, /* 97 = leaf 25 */
    0x0b0248, /* 98 = leaf 26 */
    0x0c0248, /* 99 = leaf 27 */
    0x0d0248, /* 100 = leaf 28 */
    0x0e0248, /* 101 = leaf 29 */
    0x0f0248, /* 102 = leaf 30 */
    0x100248, /* 103 = leaf 31 */
    0x110248, /* 104 = leaf 32 */
    0x2a0248, /* 105 = leaf 33 */
    0x2b0248, /* 106 = leaf 34 */
    0x2c0248, /* 107 = leaf 35 */
    0x2d0248, /* 108 = leaf 36 */
    0x0d0248, /* 109 = leaf 28 */
    0x0e0248, /* 110 = leaf 29 */
    0x0f0248, /* 111 = leaf 30 */
    0x100248, /* 112 = leaf 31 */
    0x110248, /* 113 = leaf 32 */
    0x2a0248, /* 114 = leaf 33 */
    0x2b0248, /* 115 = leaf 34 */
    0x2c0248, /* 116 = leaf 35 */
    0x2d0248, /* 117 = leaf 36 */
    0x0d0248, /* 118 = leaf 28 */
    0x0e0248, /* 119 = leaf 29 */
    0x0f0248, /* 120 = leaf 30 */
    0x100248, /* 121 = leaf 31 */
    0x110248, /* 122 = leaf 32 */
    0x2a0248, /* 123 = leaf 33 */
    0x2b0248, /* 124 = leaf 34 */
    0x2c0248, /* 125 = leaf 35 */
    0x2d0248, /* 126 = leaf 36 */
    0x2d0248, /* 127 = leaf 36 */
};
static sxd_handle    handle = 0;
uint64_t             smac = 0;
uint8_t              use_sgmii = FALSE;
uint8_t              swid_num = 0;
sx_boot_mode_e       boot_mode = SX_BOOT_MODE_DISABLED_E;
static int __configure_sgmii(const sxd_dev_id_t dev_id);
sx_xml_reader_t *__reader_p = NULL;            /* XML file reader */
sx_xml_parser_t *__parser_p = NULL;            /* XML file parser */
sx_xml_tree_t   *__tree_p = NULL;         /* XML tree        */
uint64_t         __sgmii_smac = 0;       /* device's sgmii source mac */
uint64_t         __sgmii_dmac[SX_DEV_ID_MAX]; /* device's sgmii destination mac */
int              __i2c_dev_id[SX_DEV_ID_MAX];    /* device's i2c id*/
static int       __devices_state[SX_DEV_ID_MAX]; /* device's state*/
uint64_t         __device_mac_address[SX_DEV_ID_MAX];
static int __kernel_dpt_set(uint8_t device_idx);
static int __user_space_dpt_set(uint8_t             device_idx,
                                const sys_profile_t profile);
static int __pci_profile_prepare(const sys_profile_t    profile,
                                 sxd_dev_id_t           dev_id,
                                 struct sx_pci_profile *pci_profile_p);
static int __golden_profile_set(const sys_profile_t *profile_arr_p,
                                const sxd_dev_id_t  *device_arr_p,
                                const uint8_t        arr_len);
static int __emad_traps_set(const sxd_dev_id_t dev_id);
static int __mad_traps_set(const sxd_dev_id_t           dev_id,
                           const sxd_swid_t            *swid_arr_p,
                           const uint8_t                swid_arr_len,
                           const struct sx_pci_profile *pci_profile_p);
static int __traps_set(const sxd_dev_id_t  dev_id,
                       const sys_profile_t profile);
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

void log_cb(sx_log_severity_t severity, const char *module_name, char *msg);
static boolean_t is_fast_boot_mode(void);

static boolean_t is_device_local(uint8_t device_idx)
{
    UNUSED_PARAM(device_idx);
    return TRUE;
}

/*****************************************************************************/
/*		       LOCAL GENERIC FUNCTIONS DECLARATIONS		     */
/*****************************************************************************/

/**
 * open configuration file
 * @param[in] path_p - path to configuration file
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
static int __open_configuration_file(IN char * const path_p);

/*****************************************************************************/
/*		       XML PARSING FUNCTIONS DECLARATIONS		     */
/*****************************************************************************/

/**
 * This function parse the device state section
 *
 * @param[in]   child_p                - device xml section
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */

int __parse_eth_device_state_section(IN sx_xml_element_t *child_p, OUT int *device_id_p, OUT int *device_state_p,
                                     uint64_t *device_mac_p, sys_type_t sys_type);

/**
 * This function parse the i2c device id section
 *
 * @param[in]   child_p                - device xml section
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */

int __parse_eth_i2c_dev_id_section(IN sx_xml_element_t *child_p, OUT int *__i2c_dev_id_p);

/**
 * This function parse the source MAC address section
 *
 * @param[in]   child_p                - device xml section
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */

int __parse_eth_sgmii_smac_section(sx_xml_element_t const *tree, OUT uint64_t *__sgmii_smac_p);

/**
 * This function parse the number of devices section
 *
 * @param[in]   child_p                - device xml section
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */

int __parse_eth_num_of_devices_section(sx_xml_element_t const *tree, OUT int * number_of_devices_p);

/*****************************************************************************/
/*		       XML PARSING FUNCTIONS IMPL			     */
/*****************************************************************************/

int __parse_eth_device_state_section(sx_xml_element_t *child_p,
                                     int              *device_id_p,
                                     int              *device_state_p,
                                     uint64_t         *device_mac_p,
                                     sys_type_t        sys_type)
{
    sx_xml_element_t *child_dev_state = NULL;
    sx_xml_element_t *child_dev_number = NULL;
    sx_xml_element_t *child_dev_mac_address = NULL;
    sx_mac_addr_t    *base_mac_addr = NULL;

    child_dev_number = sx_xml_element_by_name_get(child_p, "device-number");
    if (child_dev_number) {
        device_id_p[0] = atoi(sx_xml_element_content_get(child_dev_number));
    } else {
        printf("Error parsing dev_number\n");
        return -1;
    }

    child_dev_state = sx_xml_element_by_name_get(child_p, "device-state");
    if (child_dev_state) {
        device_state_p[0] = atoi(sx_xml_element_content_get(child_dev_state));
    } else {
        printf("Error parsing dev_state\n");
        return -1;
    }

    if (sys_type != SYS_TYPE_IB) {
        child_dev_mac_address = sx_xml_element_by_name_get(child_p, "device-mac-address");
        if (child_dev_mac_address) {
            base_mac_addr = ether_aton(sx_xml_element_content_get(child_dev_mac_address));
            if (base_mac_addr == NULL) {
                printf("Error parsing device mac address\n");
                return -1;
            }
            device_mac_p[0] = SX_MAC_TO_U64(*base_mac_addr);
        } else {
            printf("Error parsing device_mac_address\n");
            return -1;
        }
    }

    return 0;
}

int __parse_eth_device_sgmii_dmac_section(sx_xml_element_t *child_p, uint64_t *__sgmii_dmac_p)
{
    sx_xml_element_t *child_sgmii_dmac = NULL;

    child_sgmii_dmac = sx_xml_element_by_name_get(child_p, "sgmii-dmac");
    if (child_sgmii_dmac) {
        __sgmii_dmac_p[0] = strtoull(sx_xml_element_content_get(child_sgmii_dmac), NULL, 0);
    } else {
        /* if SGMII DMAC is not in the XML, we will read it using SPAD register later */
        __sgmii_dmac_p[0] = 0;
    }

    return 0;
}

int __parse_eth_i2c_dev_id_section(IN sx_xml_element_t *child_p, int *__i2c_dev_id_p)
{
    sx_xml_element_t *child_dev_state = NULL;

    child_dev_state = sx_xml_element_by_name_get(child_p, "i2c-dev-id");
    if (child_dev_state) {
        __i2c_dev_id_p[0] = atoi(sx_xml_element_content_get(child_dev_state));
        return 0;
    }
    return -1;
}

int __parse_eth_sgmii_smac_section(sx_xml_element_t const *tree, uint64_t *__sgmii_smac_p)
{
    sx_xml_element_t *child_sgmii_smac = sx_xml_element_by_name_get(tree, "sgmii-smac");

    if (child_sgmii_smac != NULL) {
        __sgmii_smac_p[0] = strtoull(sx_xml_element_content_get(child_sgmii_smac), NULL, 0);
        return 0;
    }

    return -1;
}

int __parse_eth_num_of_devices_section(sx_xml_element_t const *tree, OUT int * number_of_devices_p)
{
    sx_xml_element_t *child_number_of_devices = sx_xml_element_by_name_get(tree, "number-of-devices");

    if (child_number_of_devices != NULL) {
        number_of_devices_p[0] = atoi(sx_xml_element_content_get(child_number_of_devices));
        return 0;
    }
    return -1;
}

int __open_configuration_file(IN char * const path_p)
{
    int ret = 0;

    if (path_p == NULL) {
        printf("Can't open configuration file , empty file name\n");
        ret = -1;
        goto out;
    }

    sx_xml_log_function_set(log_cb);
    sx_xml_log_verbosity_level_set(LOG_VAR_NAME(__MODULE__));

    /* Creates an XML parser. This is the first function to call. */
    __parser_p = sx_xml_parser_create();
    if (__parser_p == NULL) {
        printf("Unable to create an XML parser \n");
        ret = -1;
        goto out;
    }
    sx_xml_parser_ignore_whitespaces(__parser_p);
    /* Loads an XML file. */
    __reader_p = sx_xml_reader_create(path_p);
    if (__reader_p == NULL) {
        printf("Unable to load the XML file %s\n", path_p);
        ret = -1;
        goto out;
    }

    __tree_p = sx_xml_tree_create(__parser_p, __reader_p);
    if (__tree_p == NULL) {
        printf("Unable to parse the XML file %s\n", path_p);
        ret = -1;
        goto out;
    }

out:
    if (ret != 0) {
        if (__tree_p != NULL) {
            sx_xml_tree_free(__tree_p);
            __tree_p = NULL;
        }
        if (__reader_p != NULL) {
            sx_xml_reader_free(__reader_p);
            __reader_p = NULL;
        }
        if (__parser_p != NULL) {
            sx_xml_parser_free(__parser_p);
            __parser_p = NULL;
        }
    }
    SX_LOG_EXIT();
    return ret;
}

static inline void __show_help()
{
    printf("\tNVIDIA Switch Resources Manager.\n"
           "\t===================================\n"
           "\tUsage: resources_manager [options]            <profile type> <configuration file>\n\n"
           "\t<profile type>                                Set profile type to: eth-single|eth-multi|ib-single|switchib-single|ib-multi|vpi-single|vpi-multi.\n"
           "\t<configuration file>                          EVB Configuration file.\n"
           "\tOptions:\n"
           "\t(-s|--use-sgmii)                              Use SGMII to configure the devices.\n"
           "\t(-m|--smac) <source-mac>                      Set the source MAC address for SGMII use (the ConnectX MAC).\n"
           "\t(-v|--version)                                Report version and exit.\n"
           "\t(-l|--verbosity)<level>                       Set verbosity level to: NONE=0,ERROR=1,WARNING=2,INFO=3,VERBOSE=4,DEBUG=5,ALL=6.\n"
           "\t(-h|--help)                                   Show this help message and exit.\n");
}

static inline void __show_error()
{
    printf("Bad parameter(s). Use --help to get parameters summary\n");
    exit(1);
}

int rsrc_mng_dev_init(uint8_t device_idx, sys_profile_t profile_type)
{
    sxd_ctrl_pack_t        ctrl_pack;
    unsigned long          i = 0;
    int                    ret = 0;
    struct ku_swid_details swid_details;

    /* Set READ_WRITE for local device so we can access it. Can't set sysport path
     * yet because first htgt and hpkt must be sent through CMD IFC */


    ret = sxd_dpt_set_access_control(device_idx, READ_WRITE);
    if (SXD_CHECK_FAIL(ret)) {
        printf("failed to set access control in user space DPT, "
               "for device %d. error: %s\n", device_idx,
               SXD_STATUS_MSG(ret));
        return ret;
    }

    /* set kernel dpt */
    ret = __kernel_dpt_set(device_idx);
    if (ret == DEV_NOT_PRESENT) {
        return 0;
    }

    if (ret) {
        printf("Failed in set kernel DPT\n");
        return ret;
    }

    if ((!is_fast_boot_mode() &&
         (boot_mode == SX_BOOT_MODE_DISABLED_E)) ||
        ((boot_mode == SX_BOOT_MODE_NORMAL_E) || (boot_mode == SX_BOOT_MODE_ISSU_NORMAL_E))) {
        if (is_device_local(device_idx)) {
            ret = __golden_profile_set(&(profile_type), &(device_idx), 1);
            if (ret) {
                printf("Failed in set golden profile\n");
                return ret;
            }
        }

        if (is_device_local(device_idx)) {
            if ((profile_type == SYS_PROFILE_IB_SINGLE_SWID) || (profile_type == SYS_PROFILE_IB_MULTI_SWID)) {
                ret = sxd_set_mad_demux(device_idx, 1);
                if (ret) {
                    printf("MAD DEMUX failed: %s\n", strerror(errno));
                    return ret;
                } else {
                    printf("MAD DEMUX set successfully on device %d\n", device_idx);
                }
            }

            /* enable device's swid */
            swid_details.dev_id = device_idx;
            ctrl_pack.cmd_body = (void*)&(swid_details);
            ctrl_pack.ctrl_cmd = CTRL_CMD_ENABLE_SWID;
            for (i = 0; i < swid_num; ++i) {
                swid_details.swid = i;
                swid_details.iptrap_synd = 0x1c0 + i;
                swid_details.mac = __device_mac_address[device_idx];

                ret = sxd_ioctl(handle, &ctrl_pack);
                if (ret) {
                    printf("ENABLE_SWID error: %s\n", strerror(errno));
                    return ret;
                }
            }
        }

        /* traps set */
        ret = __traps_set(device_idx, profile_type);
        if (ret) {
            printf("Failed in set traps\n");
            return ret;
        }
    }

    /* set user dpt */
    ret = __user_space_dpt_set(device_idx, profile_type);
    if (ret) {
        printf("Failed in set user space DPT\n");
        return ret;
    }

    if (use_sgmii == TRUE) {
        ret = __configure_sgmii(device_idx);
        if (ret) {
            printf("Failed in configuring SGMII\n");
            return ret;
        }
    }

    return ret;
}

static boolean_t is_fast_boot_mode(void)
{
    boolean_t ret = FALSE;
    char      fast_boot;
    int       rc;
    int       fd = open("/sys/module/sx_core/parameters/fast_boot", O_RDONLY);

    if (fd < 0) {
        printf("fast_boot mode sysfs file was not found\n");
        return FALSE;
    }

    rc = read(fd, &fast_boot, sizeof(fast_boot));
    if (rc <= 0) {
        printf("failed to read fast_boot mode from file (errno=%d)\n", errno);
        goto out;
    }

    ret = (fast_boot == '1');

out:
    close(fd);
    return ret;
}
#define RSRC_MGR_DEFAULT_DEVICE_COUNT  1
#define RSRC_MGR_DEFAULT_DEVICE_ID     1
#define RSRC_MGR_DEFAULT_BASE_XML_FILE "device_base.xml"

int __res_mgr_self_init(char *platform_xml, int *num_found_devs_p, sys_type_t sys_type)
{
    sx_xml_list_t    *list_head_p = NULL;   /* XML list object - used to iterate device nodes */
    sx_xml_element_t *child_p, *tree_root;
    int               number_of_devices = RSRC_MGR_DEFAULT_DEVICE_COUNT;
    int               dev_info_index = RSRC_MGR_DEFAULT_DEVICE_ID;
    sx_xml_element_t *child_dev_mac_address = NULL;
    sx_mac_addr_t    *base_mac_addr = NULL;
    int               ret = 0;
    uint64_t          dev_mac = 0;
    int               i2c_dev_id = 0;
    char             *basedir = NULL;
    char              filepath[PATH_MAX];
    char             *slash = "/";
    size_t            path_length = 0;


    SX_LOG_ENTER();

    memset(filepath, 0, sizeof(filepath));
    basedir = dirname(platform_xml);

    path_length = strlen(basedir) + strlen(slash) + strlen(RSRC_MGR_DEFAULT_BASE_XML_FILE) + 1;
    if (path_length > PATH_MAX) {
        printf("Failed opening the default device base xml configuration file, the path is too long: %lu > %u \n",
               path_length, PATH_MAX);
        return -1;
    }

    strcat(filepath, basedir);
    strcat(filepath, slash);
    strcat(filepath, RSRC_MGR_DEFAULT_BASE_XML_FILE);

    /* open configuration file */
    printf("Platform xml not present, rsrc manager initializing using defaults %s\n", filepath);
    ret = __open_configuration_file(filepath);
    if (ret < 0) {
        printf("Failed opening the default device base xml configuration file\n");
        return -1;
    }

    *num_found_devs_p = number_of_devices;

    tree_root = sx_xml_tree_root_element_get(__tree_p);
    if (use_sgmii == TRUE) {
        if (smac) { /* If we got is as a module parameter no need to read it from the XML */
            __sgmii_smac = smac;
        } else {
            ret = __parse_eth_sgmii_smac_section(tree_root, &__sgmii_smac);
            if (ret < 0) {
                printf("Failed to parse sgmii source MAC address\n");
                return -1;
            }
        }
    }
    list_head_p = sx_xml_element_shallow_list_by_name_get(tree_root, "device"); /* get the list of devices from the XML file */
    child_p = sx_xml_element_list_data(list_head_p);

    if (sys_type != SYS_TYPE_IB) {
        child_dev_mac_address = sx_xml_element_by_name_get(child_p, "device-mac-address");
        if (child_dev_mac_address) {
            base_mac_addr = ether_aton(sx_xml_element_content_get(child_dev_mac_address));
            if (base_mac_addr == NULL) {
                printf("Error parsing device mac address\n");
                sx_xml_element_shallow_list_free(list_head_p);
                return -1;
            }
            dev_mac = SX_MAC_TO_U64(*base_mac_addr);
        } else {
            printf("Error parsing device_mac_address\n");
            sx_xml_element_shallow_list_free(list_head_p);
            return -1;
        }
    }

    __devices_state[dev_info_index] = 1;
    __device_mac_address[dev_info_index] = dev_mac;
    ret = __parse_eth_i2c_dev_id_section(child_p, &i2c_dev_id);
    if (ret < 0) {
        if (use_sgmii == FALSE) {
            i2c_dev_id = 0;
        } else {
            printf("Failed to parse device's i2c id\n");
            sx_xml_element_shallow_list_free(list_head_p);
            return -1;
        }
    }

    __i2c_dev_id[dev_info_index] = i2c_dev_id;

    if (use_sgmii) {
        __sgmii_dmac[dev_info_index] = 0;
    }
    sx_xml_element_shallow_list_free(list_head_p);
    return 0;
}

int __res_mgr_xml_init(int *num_found_devs_p, sys_type_t sys_type)
{
    sx_xml_list_t    *list = NULL, *list_head = NULL;   /* XML list object - used to iterate device nodes */
    sx_xml_element_t *child, *tree_root;
    int               ret = 0;
    int               number_of_devices = 0, dev_info_index = 0;
    int               num_found_devs = 0, device_state = 0, i2c_dev_id = 0;
    uint64_t          dev_mac = 0;

    tree_root = sx_xml_tree_root_element_get(__tree_p);
    if (use_sgmii == TRUE) {
        if (smac) { /* If we got is as a module parameter no need to read it from the XML */
            __sgmii_smac = smac;
        } else {
            ret = __parse_eth_sgmii_smac_section(tree_root, &__sgmii_smac);
            if (ret < 0) {
                printf("Failed to parse sgmii source MAC address\n");
                return -1;
            }
        }
    }

    ret = __parse_eth_num_of_devices_section(tree_root, &number_of_devices);
    if (ret < 0) {
        printf("Failed to parse number of devices\n");
        return -1;
    }

    list_head = sx_xml_element_shallow_list_by_name_get(tree_root, "device"); /* get the list of devices from the XML file */
    list = list_head;
    while (list != NULL && num_found_devs < number_of_devices) {
        child = sx_xml_element_list_data(list);
        /* Check the device state - do not handle disabled devices*/
        ret = __parse_eth_device_state_section(child, &dev_info_index, &device_state, &dev_mac, sys_type);
        if (ret < 0) {
            printf("Failed to parse device's state\n");
            sx_xml_element_shallow_list_free(list_head);
            return -1;
        }

        if (dev_info_index >= SX_DEV_ID_MAX) {
            printf("Device id %d is not valid\n", dev_info_index);
            sx_xml_element_shallow_list_free(list_head);
            return -1;
        }

        __devices_state[dev_info_index] = device_state;
        if (device_state) {
            (*num_found_devs_p)++;
        }

        __device_mac_address[dev_info_index] = dev_mac;

        ret = __parse_eth_i2c_dev_id_section(child, &i2c_dev_id);
        if (ret < 0) {
            if (use_sgmii == FALSE) {
                i2c_dev_id = 0;
            } else {
                printf("Failed to parse device's i2c id\n");
                sx_xml_element_shallow_list_free(list_head);
                return -1;
            }
        }

        __i2c_dev_id[dev_info_index] = i2c_dev_id;

        if (use_sgmii) {
            ret = __parse_eth_device_sgmii_dmac_section(child, &__sgmii_dmac[dev_info_index]);
            if (ret < 0) {
                __sgmii_dmac[dev_info_index] = 0;
            }
        }

        list = sx_xml_element_list_next(list);
    }
    sx_xml_element_shallow_list_free(list_head);
    return 0;
}

int main(int argc, char **argv)
{
    char                 dev_name[MAX_SX_DEVS][MAX_NAME_LEN];
    char                *dev_name_p[MAX_SX_DEVS];
    uint32_t             dev_num = MAX_SX_DEVS;
    char                 boot_mode_name[MAX_BOOT_MODE_NAME] = {0};
    uint8_t              device_idx = 1;
    sys_profile_t        profile_type = SYS_PROFILE_EN_SINGLE_SWID;
    sys_type_t           sys_type;
    sxd_ctrl_pack_t      ctrl_pack;
    int                  i = 0;
    int                  c, ret = 0;
    int                  num_found_devs = 0;
    sx_verbosity_level_t verbosity_level = SX_VERBOSITY_LEVEL_NOTICE;
    boolean_t            set_verbosity = TRUE;
    boolean_t            use_internal_init_flow = FALSE;

    memset(&ctrl_pack, 0, sizeof(ctrl_pack));
    while (1) {
        int option_index = 0;

        c = getopt_long(argc, argv, "adml:vhn", sx_core_long_options, &option_index);

        /* Detect the end of the options. */
        if (c == -1) {
            break;
        }

        switch (c) {
        case 's':
            use_sgmii = TRUE;
            break;

        case 'm':
            ret = sscanf(optarg, "%llx", (unsigned long long*)&smac);
            break;

        case 'd':
            break;

        case 'b':
            ret = sscanf(optarg, "%s", boot_mode_name);
            break;

        case 'u':
            ret = sscanf(optarg, "%u", &use_internal_init_flow);
            break;

        case 'v':
            printf("NVIDIA Switch Resources Manager, version 1.0.0\n");
            exit(0);

        case 'h':
            __show_help();
            exit(0);

        case 'l':
            ret = sscanf(optarg, "%u", &verbosity_level);
            break;

        case 'n':
            set_verbosity = FALSE;
            break;

        /* fall through */
        case '?':
        default:
            /* getopt_long already printed an error message. */
            __show_error();
        }
    }

    /* Check remaining command line arguments (not options). */
    if (optind + 2 != argc) {
        __show_error();
    }

    if (set_verbosity) {
        /* set module verbosity*/
        LOG_VAR_NAME(__MODULE__) = verbosity_level;
        /* SXD LIBS VERBOSITY */
        ret = sxd_access_reg_log_verbosity_level(SXD_ACCESS_CMD_SET, &verbosity_level);
        if (SXD_CHECK_FAIL(ret)) {
            printf("Failed to set log level , SXD LIBS.\n");
            return ret;
        }
    }

    if (!strcmp(argv[optind], "eth-single") || !strcmp(argv[optind], "ETH-SINGLE")) {
        profile_type = SYS_PROFILE_EN_SINGLE_SWID;
    } else if (!strcmp(argv[optind], "eth-multi") || !strcmp(argv[optind], "ETH-MULTI")) {
        profile_type = SYS_PROFILE_EN_MULTI_SWID;
    } else if (!strcmp(argv[optind], "ib-single") || !strcmp(argv[optind], "IB-SINGLE") ||
               !strcmp(argv[optind], "quantum-single") || !strcmp(argv[optind], "QUANTUM-SINGLE") ||
               !strcmp(argv[optind], "quantum2-single") || !strcmp(argv[optind], "QUANTUM2-SINGLE") ||
               !strcmp(argv[optind], "quantum3-single") || !strcmp(argv[optind], "QUANTUM3-SINGLE") ||
               !strcmp(argv[optind], "switchib2-single") || !strcmp(argv[optind], "SWITCHIB2-SINGLE") ||
               !strcmp(argv[optind], "switchib-single") || !strcmp(argv[optind], "SWITCHIB-SINGLE")) {
        profile_type = SYS_PROFILE_IB_SINGLE_SWID;
    } else if (!strcmp(argv[optind], "ib-multi") || !strcmp(argv[optind], "IB-MULTI")) {
        profile_type = SYS_PROFILE_IB_MULTI_SWID;
    } else if (!strcmp(argv[optind], "vpi-single") || !strcmp(argv[optind], "VPI-SINGLE")) {
        profile_type = SYS_PROFILE_VPI_SINGLE_SWID;
    } else if (!strcmp(argv[optind], "vpi-multi") || !strcmp(argv[optind], "VPI-MULTI")) {
        profile_type = SYS_PROFILE_VPI_MULTI_SWID;
    } else {
        __show_error();
    }

    if (!strcmp(boot_mode_name, "NORMAL")) {
        boot_mode = SX_BOOT_MODE_NORMAL_E;
    } else if (!strcmp(boot_mode_name, "FAST")) {
        boot_mode = SX_BOOT_MODE_FAST_E;
    } else if (!strcmp(boot_mode_name, "ISSU_NORMAL")) {
        boot_mode = SX_BOOT_MODE_ISSU_NORMAL_E;
    } else if (!strcmp(boot_mode_name, "ISSU_FAST")) {
        boot_mode = SX_BOOT_MODE_ISSU_FAST_E;
    } else if (!strcmp(boot_mode_name, "ISSU_STARTED")) {
        boot_mode = SX_BOOT_MODE_ISSU_STARTED_E;
    } else if (!strcmp(boot_mode_name, "DISABLED")) {
        boot_mode = SX_BOOT_MODE_DISABLED_E;
    } else {
        printf("Unsupported boot_mode parameter: %s \n", boot_mode_name);
        return -1;
    }

    if (use_internal_init_flow) {
        /* all the work will be done in resources-manager within SDK */
        printf("##################### User determined to run the init flow internally in SDK ############\n");
        return 0;
    }

    /* calculate system type and device's swid num */
    switch (profile_type) {
    case SYS_PROFILE_IB_SINGLE_SWID:
        sys_type = SYS_TYPE_IB;
        break;

    case SYS_PROFILE_IB_MULTI_SWID:
        sys_type = SYS_TYPE_IB;
        break;

    case SYS_PROFILE_EN_SINGLE_SWID:
        sys_type = SYS_TYPE_EN;
        break;

    case SYS_PROFILE_EN_MULTI_SWID:
        sys_type = SYS_TYPE_EN;
        break;

    case SYS_PROFILE_VPI_SINGLE_SWID:
        sys_type = SYS_TYPE_VPI;
        break;

    default:
        printf("Profile [%s] is not supported yet.\n", argv[optind]);
        return -1;
    }

    optind++;


    /* query local devices names */
    for (i = 0; i < MAX_SX_DEVS; ++i) {
        dev_name_p[i] = dev_name[i];
    }

    ret = sxd_get_dev_list(dev_name_p, &dev_num);
    if (ret < 0) {
        printf("sxd_get_dev_list error: %s\n", strerror(errno));
        return ret;
    } else if (ret > 0) {
        printf("Unsupported SX device number: %u\n", ret);
        return ret;
    }

    if (device_idx > dev_num) {
        printf("SX device [%u] not found\n", device_idx);
        return -1;
    }

    /* open device and reset it */
    ret = sxd_open_device(dev_name[device_idx - 1], &handle);
    if (ret) {
        printf("sxd_open_device error: %s\n", strerror(errno));
        return ret;
    }

    /*****************************************************************************/
    /*		               PARSING SECTION				                         */
    /*****************************************************************************/
    /* open configuration file */
    ret = __open_configuration_file(argv[optind]);
    if (ret < 0) {
        ret = __res_mgr_self_init(argv[optind], &num_found_devs, sys_type);
        if (ret < 0) {
            printf("Failed opening the configuration file\n");
            return -1;
        }
    } else {
        ret = __res_mgr_xml_init(&num_found_devs, sys_type);
        if (SXD_CHECK_FAIL(ret)) {
            printf("%s: failed to init from xml , error: %d\n",
                   __func__, ret);
            return ret;
        }
    }

    /* open user space DPT handle */
    ret = sxd_dpt_init(sys_type, log_cb, LOG_VAR_NAME(__MODULE__));
    if (SXD_CHECK_FAIL(ret)) {
        printf("%s: failed to init user space DPT , error: %d\n",
               __func__, ret);
        return ret;
    }

    /* open access reg handle */
    ret = sxd_access_reg_init(0, log_cb, LOG_VAR_NAME(__MODULE__));
    if (SXD_CHECK_FAIL(ret)) {
        printf("%s: failed to init access register , error: %d\n",
               __func__, ret);
        return ret;
    }

    /*==============================
     *
     *    DEVICE INIT SECTION
     *
     *  ===============================*/
    for (i = 1; i < SX_DEV_ID_MAX; i++) {
        static int count = 0;
        if (__devices_state[i] == 0) {
            continue;
        }

        printf("Going to configure dev %d\n", i);
        ret = rsrc_mng_dev_init(i, profile_type);
        if (ret) {
            printf("Failed in rsrc_mng_dev_init for dev %d\n", i);
            return ret;
        }

        if (++count == num_found_devs) {
            break;
        }
    }

    /* close access reg handle */
    ret = sxd_access_reg_deinit();
    if (SXD_CHECK_FAIL(ret)) {
        printf("%s: failed to deinit access register , error: %d\n",
               __func__, ret);
        return ret;
    }

    return 0;
}

int __kernel_dpt_set(uint8_t device_idx)
{
    struct ku_dpt_path_add    path;
    struct ku_dpt_path_modify path_modify;
    sxd_ctrl_pack_t           ctrl_pack;
    int                       sxd_err = 0;
    int                       i = device_idx;

    memset(&ctrl_pack, 0, sizeof(sxd_ctrl_pack_t));

    printf("KDPT: Going to set path for device id: %d\n", device_idx);

    /*********** path add for each tunnel type ***********/
    ctrl_pack.ctrl_cmd = CTRL_CMD_ADD_DEV_PATH;
    ctrl_pack.cmd_body = (void*)&(path);
    memset(&path, 0, sizeof(struct ku_dpt_path_add));
    path.dev_id = i;

    /*********** path add for I2C ***********/
    path.path_type = DPT_PATH_I2C;
    if (dev_id_to_i2c_dev_id_map[i] == 0) {
        printf("Unsupported device ID (%d)\n", i);
        return -1;
    }

    path.path_info.sx_i2c_info.sx_i2c_dev = dev_id_to_i2c_dev_id_map[i];
    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (sxd_err != 0) {
        printf("KDPT: device %d is not present\n", device_idx);
        return DEV_NOT_PRESENT;
    }

    /*********** path add for PCI ***********/
    ctrl_pack.ctrl_cmd = CTRL_CMD_ADD_DEV_PATH;
    ctrl_pack.cmd_body = (void*)&(path);
    path.path_type = DPT_PATH_PCI_E;
    if (is_device_local(device_idx)) {
        path.is_local = 1;
    } else {
        path.is_local = 0;
    }

    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (sxd_err != 0) {
        printf("failed to add PCI dev path to DP table"
               ", error: %s\n", strerror(errno));
        return -1;
    }

    if (is_device_local(device_idx)) {
        /* only for local devices set CMD path to PCI */
        path_modify.path_type = DPT_PATH_PCI_E;
        ctrl_pack.ctrl_cmd = CTRL_CMD_SET_CMD_PATH;
        sxd_err = sxd_ioctl(handle, &ctrl_pack);
        if (sxd_err != 0) {
            printf("failed to set cmd_ifc path in DP table to PCI, "
                   "error: %s\n", strerror(errno));
            return -1;
        }
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_CMD_PATH;
    ctrl_pack.cmd_body = (void*)&(path_modify);
    path_modify.dev_id = i;
    path_modify.path_type = DPT_PATH_PCI_E;
    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (sxd_err != 0) {
        printf("failed to set cmd path in DP table to I2C, "
               "dev_id = %d", i);
        return -1;
    }

    /*********** path set for each packet type ***********/
    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_EMAD_PATH;
    ctrl_pack.cmd_body = (void*)&(path_modify);
    path_modify.dev_id = i;
    if (use_sgmii == TRUE) {
        path_modify.path_type = DPT_PATH_SGMII;
    } else {
        path_modify.path_type = DPT_PATH_PCI_E;
    }

    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (sxd_err != 0) {
        printf("failed to set EMAD path in DP table \n");
        return -1;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_MAD_PATH;
    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (sxd_err != 0) {
        printf("failed to set MAD path in DP table \n");
        return -1;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_CR_ACCESS_PATH;
    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (sxd_err != 0) {
        printf("failed to set CR ACCESS path in DP table \n");
        return -1;
    }

    return 0;
}

int __user_space_dpt_set(uint8_t device_idx, const sys_profile_t profile)
{
#if 0
    int               num_of_eth_swids = 0;
    dpt_path_params_t path_params;
    int               j = 0;
#endif
    sxd_status_t status;

    UNUSED_PARAM(profile);
#if 0
    switch (profile) {
    case SYS_PROFILE_VPI_SINGLE_SWID:
    case SYS_PROFILE_EN_SINGLE_SWID:
        num_of_eth_swids = 1;
        break;

    case SYS_PROFILE_EN_MULTI_SWID:
        num_of_eth_swids = 8;
        break;

    default:
        return 0;
    }
#endif
    printf("UDPT: Going to set path for device id: %d\n", device_idx);
#if 0
    path_params.sys_port_params.sys_port = 0;
#endif
    status = sxd_dpt_set_access_control(device_idx, READ_WRITE);
    if (status != SXD_STATUS_SUCCESS) {
        printf("failed to set access control in user space DPT, "
               "for device %d. error: %s\n", device_idx, SXD_STATUS_MSG(status));
        return -1;
    }
#if 0 /* The SDK does it on initialization */
    for (j = 0; j < num_of_eth_swids; j++) {
        status = sxd_dpt_path_add(device_idx, j, SYS_PORT_ROUTE_PATH, path_params);
        if (status != SXD_STATUS_SUCCESS) {
            printf("failed to set sys port path in user space DPT, "
                   "for device %d, swid %d. error: %s\n",
                   device_idx, j, SXD_STATUS_MSG(status));
            return -1;
        }
    }
#endif
#if 0
    /* We only support IB DR configuration for a single device for now */
    if (profile == SYS_PROFILE_IB_SINGLE_SWID) {
        local_to_ib_map_t ports_map;
        dpt_path_params_t path_params;
        dr_path_t         dr_path;

        ports_map.ib_port = 0;
        ports_map.local_port = 0;
        status = sxd_dpt_add_ports_map(device_idx, &ports_map, 1);
        if (status != SXD_STATUS_SUCCESS) {
            printf("failed to add ports map to user space DPT, "
                   "for device %d, error: %s\n",
                   device_idx, SXD_STATUS_MSG(status));
            return -1;
        }

        dr_path.path_device_id = (uint16_t*)&device_idx;
        dr_path.path_len = 0;
        dr_path.path_ports = NULL;
        path_params.dr_params.num_of_paths = 1;
        path_params.dr_params.dr_path = &dr_path;
        status = sxd_dpt_path_add(device_idx, 0, DR_PATH, path_params);
        if (status != SXD_STATUS_SUCCESS) {
            printf("failed to set DR path in user space DPT, "
                   "for device %d, swid 0. error: %s\n",
                   device_idx, SXD_STATUS_MSG(status));
            return -1;
        }
    }
#endif
    return 0;
}

sxd_status_t __get_chip_type(sxd_dev_id_t dev_id, enum sxd_chip_types* chip_type)
{
    sxd_status_t       ret = SXD_STATUS_SUCCESS;
    struct ku_dev_info dev_info;

    memset(&dev_info, 0, sizeof(dev_info));
    dev_info.dev_id = dev_id;
    ret = sxd_get_device_info(&dev_info);
    if (ret != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get device information (err=%d)\n", ret);
        return ret;
    }

    *chip_type = dev_info.dev_info.dev_info_ro.chip_type;
    return 0;
}

int __pci_profile_prepare(const sys_profile_t profile, sxd_dev_id_t dev_id, struct sx_pci_profile *pci_profile_p)
{
    enum sxd_chip_types chip_type = 0;
    sxd_status_t        sxd_status = 0;

    /* set default chip type */
    sxd_status = __get_chip_type(dev_id, &chip_type);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        printf("__get_chip_type failed (%s)\n", SXD_STATUS_MSG(sxd_status));
        return sxd_status_to_sx_status(sxd_status);
    }

    /* init pci profile with 0 */
    memset(pci_profile_p, 0, sizeof(struct sx_pci_profile));

    switch (profile) {
    case SYS_PROFILE_IB_SINGLE_SWID:
        swid_num = 1;
        memcpy(pci_profile_p, &(pci_profile_single_ib), sizeof(struct sx_pci_profile));
        break;

    case SYS_PROFILE_IB_MULTI_SWID:
        swid_num = 8;
        memcpy(pci_profile_p, &(pci_profile_multi_ib), sizeof(struct sx_pci_profile));
        break;

    case SYS_PROFILE_EN_SINGLE_SWID:
        swid_num = 1;

        if ((chip_type == SXD_CHIP_TYPE_SPECTRUM) || (chip_type == SXD_CHIP_TYPE_SPECTRUM_A1)) {
            memcpy(pci_profile_p, &(pci_profile_single_eth_spectrum), sizeof(struct sx_pci_profile));
        } else if (chip_type == SXD_CHIP_TYPE_SPECTRUM2) {
            memcpy(pci_profile_p, &(pci_profile_single_eth_spectrum2), sizeof(struct sx_pci_profile));
        } else if (chip_type == SXD_CHIP_TYPE_SPECTRUM3) {
            memcpy(pci_profile_p, &(pci_profile_single_eth_spectrum3), sizeof(struct sx_pci_profile));
        } else if (chip_type == SXD_CHIP_TYPE_SPECTRUM4) {
            memcpy(pci_profile_p, &(pci_profile_single_eth_spectrum4), sizeof(struct sx_pci_profile));
        } else if (chip_type == SXD_CHIP_TYPE_SPECTRUM5) {
            memcpy(pci_profile_p, &(pci_profile_single_eth_spectrum5), sizeof(struct sx_pci_profile));
        } else if ((chip_type == SXD_CHIP_TYPE_SWITCHX_A2) || (chip_type == SXD_CHIP_TYPE_SWITCHX_A1)) {
            swid_num = 2;
            memcpy(pci_profile_p, &(pci_profile_single_eth), sizeof(struct sx_pci_profile));
        } else {
            printf("%s: EN Single SWID is not supported for this chip type\n", __func__);
            return -1;
        }
        break;

    case SYS_PROFILE_EN_MULTI_SWID:
        swid_num = 3;
        memcpy(pci_profile_p, &(pci_profile_multi_eth), sizeof(struct sx_pci_profile));
        break;

    case SYS_PROFILE_VPI_SINGLE_SWID:
        swid_num = 3;
        memcpy(pci_profile_p, &(pci_profile_vpi), sizeof(struct sx_pci_profile));
        break;

    case SYS_PROFILE_VPI_MULTI_SWID:
        printf("%s: VPI Multi SWID is not supported\n", __func__);
        return -1;

    default:
        printf("%s: reached default case on PCI profile switch\n", __func__);
        return -1;
    }

    pci_profile_p->dev_id = dev_id;

    return 0;
}

int __golden_profile_set(const sys_profile_t *profile_arr_p, const sxd_dev_id_t *device_arr_p, const uint8_t arr_len)
{
    int                           sxd_err = 0, ret_value = 0, i = 0;
    unsigned long                 temp_dev_id = 0;
    sxd_ctrl_pack_t               ctrl_pack;
    int                           rc = 0;
    static struct sx_pci_profile *pci_profile_arr;

    printf("%s: RESOURCE MNG:  SET GOLDEN PROFILE\n", __func__);

    if ((NULL != device_arr_p) && (!is_device_local(device_arr_p[0]))) {
        printf("%s: ERROR : device_arr_p[0] isn't local .\n", __func__);
        rc = -1;
        goto out;
    }

    if (profile_arr_p == NULL) {
        printf("%s: ERROR : profile_arr_p is NULL\n", __func__);
        rc = -1;
        goto out;
    }

    if (device_arr_p == NULL) {
        printf("%s: ERROR : device_arr_p is NULL\n", __func__);
        rc = -1;
        goto out;
    }

    if (arr_len == 0) {
        printf("%s: ERROR : device array length is 0\n", __func__);
        rc = -1;
        goto out;
    }

    memset(&ctrl_pack, 0, sizeof(sxd_ctrl_pack_t));

    /* allocate space for the arrays */
    pci_profile_arr = calloc(arr_len, sizeof(struct sx_pci_profile));
    if (pci_profile_arr == NULL) {
        printf("%s: ERROR : failed to allocate memory\n",
               __func__);
        rc = -1;
        goto out;
    }

    for (; i < arr_len; i++) {
        /******* input check *******/

        if (SYS_PROFILE_CHECK_RANGE(profile_arr_p[i]) == FALSE) {
            printf("%s: ERROR : invalid profile , profile: %s\n",
                   __func__, SYS_PROFILE_STR(profile_arr_p[i]));
            rc = -1;
            goto out;
        }

        printf("%s: INFO : selected profile: %s\n", __func__,
               SYS_PROFILE_STR(profile_arr_p[i]));

        /******* reset sx core *******/
        ctrl_pack.ctrl_cmd = CTRL_CMD_RESET;
        temp_dev_id = device_arr_p[i];
        ctrl_pack.cmd_body = (void*)temp_dev_id;

        sxd_err = sxd_ioctl(handle, &ctrl_pack);
        if (sxd_err != 0) {
            printf("%s: ERROR : failed to reset sx core \n", __func__);
            rc = -1;
            goto out;
        }

        /******* prepare profile *******/
        ret_value = __pci_profile_prepare(profile_arr_p[i],
                                          device_arr_p[i],
                                          &(pci_profile_arr[i]));
        if (ret_value != 0) {
            printf("%s: ERROR : failed to build sx core profile\n",
                   __func__);
            rc = -1;
            goto out;
        }

        /******* set profile *******/

        ctrl_pack.ctrl_cmd = CTRL_CMD_SET_PCI_PROFILE;
        ctrl_pack.cmd_body = (void*)&(pci_profile_arr[i]);

        sxd_err = sxd_ioctl(handle, &ctrl_pack);
        if (sxd_err != 0) {
            printf("%s: failed to set pci profile in sx core \n", __func__);
            rc = -1;
            goto out;
        }
    }

out:
    printf("%s: RESOURCE MNG:  SET GOLDEN PROFILE DONE [Return value: %d]\n", __func__, rc);
    return rc;
}

int __emad_traps_set(const sxd_dev_id_t dev_id)
{
    sxd_status_t       sxd_ret = SXD_STATUS_SUCCESS;
    int                rc = 0;
    struct ku_htgt_reg htgt_reg;
    struct ku_hpkt_reg hpkt_reg;
    sxd_reg_meta_t     reg_meta;

    return 0;
    /* coverity[unreachable] */
    memset(&htgt_reg, 0, sizeof(struct ku_htgt_reg));
    memset(&hpkt_reg, 0, sizeof(struct ku_hpkt_reg));

    /* locally attached device*/

    htgt_reg.swid = DONT_CARE_ETH_SWID;
    htgt_reg.type = SXD_HTGT_TYPE_LOCAL_E;
    htgt_reg.trap_group = EMAD_TRAP_GROUP;
    htgt_reg.pide = 0;
    htgt_reg.pid = 0;

    htgt_reg.path.cpu_tclass = DEFAULT_CPU_TCLASS;
    htgt_reg.path.rdq = pci_profile_single_eth.emad_rdq;

    hpkt_reg.action = SXD_HPKT_ACTION_TRAP_E;
    hpkt_reg.trap_group = EMAD_TRAP_GROUP; /* EMAD TRAP GROUP */
    hpkt_reg.trap_id = SXD_TRAP_ID_GENERAL_ETH_EMAD;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.dev_id = dev_id;
    reg_meta.swid = 0;

    /* set HTGT register */
    sxd_ret = sxd_access_reg_htgt(&htgt_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_ret)) {
        printf("%s: Failed to set HTGT register (EMAD configuration) , error: %d\n",
               __func__, sxd_ret);
        rc = -1;
        goto out;
    }

    sxd_ret = sxd_access_reg_hpkt(&hpkt_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_ret)) {
        printf("%s: Failed to set HPKT register (EMAD configuration), error: %d\n",
               __func__, sxd_ret);
        rc = -1;
        goto out;
    }
out:
    printf("%s: RESOURCE MNG: emad_traps_set [Return value: %d]\n", __func__, rc);
    return rc;
}

int __mad_traps_set(const sxd_dev_id_t           dev_id,
                    const sxd_swid_t            *swid_arr_p,
                    const uint8_t                swid_arr_len,
                    const struct sx_pci_profile *pci_profile_p)
{
    sxd_status_t       sxd_ret = SXD_STATUS_SUCCESS;
    int                rc = 0;
    int                i = 0;
    int                is_ipoib_enabled = 0;
    struct ku_htgt_reg htgt_reg;
    struct ku_hpkt_reg hpkt_reg;
    sxd_reg_meta_t     reg_meta;

    return 0;
    /* coverity[unreachable] */
    memset(&htgt_reg, 0, sizeof(struct ku_htgt_reg));
    memset(&hpkt_reg, 0, sizeof(struct ku_hpkt_reg));
    memset(&reg_meta, 0, sizeof(sxd_reg_meta_t));

    htgt_reg.type = SXD_HTGT_TYPE_LOCAL_E;
    htgt_reg.pide = 0;
    htgt_reg.pid = 0;

    /* SET HTGT REGISTER FOR EACH IB SWID */
    for (i = 0; i < swid_arr_len; i++) {
        htgt_reg.swid = swid_arr_p[i];
        if (pci_profile_p->ipoib_router_port_enable[swid_arr_p[i]]) {
            is_ipoib_enabled = 1;
        }

        /* SET GROUP 0 FOR QP0 TRAP ID */
        htgt_reg.trap_group = MAD_TRAP_GROUP;
        if (htgt_reg.type == SXD_HTGT_TYPE_LOCAL_E) {
            htgt_reg.path.rdq = pci_profile_p->rdq[htgt_reg.swid][0];
            htgt_reg.path.cpu_tclass = DEFAULT_CPU_TCLASS;
        }

        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        reg_meta.dev_id = dev_id;
        reg_meta.swid = swid_arr_p[i];
        sxd_ret = sxd_access_reg_htgt(&htgt_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_ret)) {
            printf("%s: Failed to set HTGT register (MAD configuration) , SWID : [%d] , error: %d\n",
                   __func__, swid_arr_p[i], sxd_ret);
            rc = -1;
            goto out;
        }

        /* SET GROUP 1 FOR TRAP ID QP1 / SXD_TRAP_ID_INFINIBAND_OTHER_QPS */
        htgt_reg.trap_group = OTHER_QP_TRAP_GROUP;
        if (htgt_reg.type == SXD_HTGT_TYPE_LOCAL_E) {
            htgt_reg.path.rdq = pci_profile_p->rdq[htgt_reg.swid][1];
            htgt_reg.path.cpu_tclass = QP1_OTHER_QP_CPU_TCLASS;
        }
        sxd_ret = sxd_access_reg_htgt(&htgt_reg, &reg_meta, 1, NULL, NULL);

        if (SXD_CHECK_FAIL(sxd_ret)) {
            printf("%s: Failed to set HTGT register (MAD configuration) , SWID : [%d] , error: %d\n",
                   __func__, swid_arr_p[i], sxd_ret);
            rc = -1;
            goto out;
        }
    }

    hpkt_reg.action = SXD_HPKT_ACTION_TRAP_E;

    /* SET HPKT FOR QP0 -> RDQ0*/
    hpkt_reg.trap_group = MAD_TRAP_GROUP;
    hpkt_reg.trap_id = SXD_TRAP_ID_INFINIBAND_QP0;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.dev_id = dev_id;
    reg_meta.swid = 0;
    sxd_ret = sxd_access_reg_hpkt(&hpkt_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_ret)) {
        printf("%s: Failed to set HPKT register (MAD configuration - FWD BY FDB), error: %d\n",
               __func__, sxd_ret);
        rc = -1;
        goto out;
    }

    /* SET HPKT FOR QP1 -> RDQ1 (trap group SRM_OTHER_QP_TRAP_GROUP) */
    hpkt_reg.trap_group = OTHER_QP_TRAP_GROUP;
    hpkt_reg.trap_id = SXD_TRAP_ID_INFINIBAND_QP1;
    sxd_ret = sxd_access_reg_hpkt(&hpkt_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_ret)) {
        printf("%s: Failed to set HPKT register (MAD configuration - FWD BY FDB), error: %d\n",
               __func__, sxd_ret);
        rc = -1;
        goto out;
    }

    /* SET HPKT FOR SXD_TRAP_ID_INFINIBAND_OTHER_QPS -> RDQ1 (trap group SRM_OTHER_QP_TRAP_GROUP) */
    hpkt_reg.trap_group = OTHER_QP_TRAP_GROUP;
    hpkt_reg.trap_id = SXD_TRAP_ID_INFINIBAND_OTHER_QPS;
    sxd_ret = sxd_access_reg_hpkt(&hpkt_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_ret)) {
        printf("%s: Failed to set HPKT register (MAD configuration - FWD BY FDB), error: %d\n",
               __func__, sxd_ret);
        rc = -1;
        goto out;
    }

    if (is_ipoib_enabled) {
        /* SET HPKT FOR SX_TRAP_ID_INFINIBAND_EXTERNAL_SMA -> RDQ0 */
        hpkt_reg.trap_group = EXTERNAL_SMA_TRAP_GROUP;
        hpkt_reg.trap_id = SXD_TRAP_ID_INFINIBAND_EXTERNAL_SMA;
        sxd_ret = sxd_access_reg_hpkt(&hpkt_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_ret)) {
            printf("%s: Failed to set HPKT register (SXD_TRAP_ID_INFINIBAND_OTHER_QPS), error: %d\n",
                   __func__, sxd_ret);
            rc = -1;
            goto out;
        }
    }

out:
    printf("%s: RESOURCE MNG: mad_traps_set [Return value: %d]\n", __func__, rc);
    return rc;
}

int __traps_set(const sxd_dev_id_t dev_id, const sys_profile_t profile)
{
    sxd_swid_t swid_arr[NUMBER_OF_SWIDS];
    int        rc = 0;

    /*set HTGT & HPKT according to the current profile*/

    switch (profile) {
    case SYS_PROFILE_IB_SINGLE_SWID:
        swid_arr[0] = 0;
        rc = __mad_traps_set(dev_id, swid_arr, 1, &(pci_profile_single_ib));
        if (rc != 0) {
            printf("%s: Failed in __mad_traps_set [IB SINGLE SWID] , return value : [%d]\n",
                   __func__, rc);
            rc = -1;
            goto out;
        }

        break;

    case SYS_PROFILE_IB_MULTI_SWID:
        swid_arr[0] = 0;
        swid_arr[1] = 1;
        swid_arr[2] = 2;
        swid_arr[3] = 3;
        swid_arr[4] = 4;
        swid_arr[5] = 5;
        swid_arr[6] = 6;
        swid_arr[7] = 7;

        rc = __mad_traps_set(dev_id, swid_arr, 8,
                             &(pci_profile_multi_ib));
        if (rc != 0) {
            printf("%s: Failed in __mad_traps_set [IB MULTI SWID] , return value : [%d]",
                   __func__, rc);
            rc = -1;
            goto out;
        }

        break;

    case SYS_PROFILE_EN_SINGLE_SWID:
    case SYS_PROFILE_EN_MULTI_SWID:
        rc = __emad_traps_set(dev_id);
        if (rc != 0) {
            printf("%s: Failed in __emad_traps_set [ETH SINGLE/MULTI SWID] , return value : [%d]",
                   __func__, rc);
            rc = -1;
            goto out;
        }


        break;

    case SYS_PROFILE_VPI_SINGLE_SWID:
        rc = __emad_traps_set(dev_id);
        if (rc != 0) {
            printf("%s: Failed in __emad_traps_set [VPI ETH SWID] , return value : [%d]",
                   __func__, rc);
            rc = -1;
            goto out;
        }

        swid_arr[0] = 1;
        rc = __mad_traps_set(dev_id, swid_arr, 1,
                             &(pci_profile_vpi));
        if (rc != 0) {
            printf("%s: Failed in __mad_traps_set [VPI IB SWID] , return value : [%d]",
                   __func__, rc);
            rc = -1;
            goto out;
        }

        break;

    case SYS_PROFILE_VPI_MULTI_SWID:
        printf("%s: VPI Multi SWID is not supported\n",
               __func__);
        rc = -1;
        goto out;

    default:
        printf("%s: reached default case on PCI profile switch\n",
               __func__);
        rc = -1;
        goto out;
    }

out:
    printf("%s: RESOURCE MNG: SET TRAPS DONE [Return value: %d]\n", __func__, rc);
    return rc;
}


static int __configure_sgmii(const sxd_dev_id_t dev_id)
{
    /* TBD */

    UNUSED_PARAM(dev_id);
    return 0;
}


void log_cb(sx_log_severity_t severity, const char *module_name, char *msg)
{
    sx_verbosity_level_t verbosity = 0;

    SEVERITY_LEVEL_TO_VERBOSITY_LEVEL(severity, verbosity);
    printf("[%-20s][%s] : %s", module_name, SX_VERBOSITY_LEVEL_STR(verbosity), msg);

    return;
}
