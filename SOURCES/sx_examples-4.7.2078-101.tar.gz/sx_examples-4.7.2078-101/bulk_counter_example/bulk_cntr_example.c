/*
 * Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

/*
 *   This example demonstrates bulk-read of flow counters
 *   - Ports in use: 0x10041 and 0x10005
 *   - Each port is bound to two pairs of ACL rules
 *    (only one rule per-pair is active at the time, depends on port-user-memory value).
 *   - 4 consecutive flow counter IDs are: cntr_id0-cntr_id3
 *
 *   [port-user-memory 0: cntr_id0, cntrid_1]
 *   [port-user-memory 1: cntr_id2, cntr_id3]
 *
 *   0x10041 ------+
 *                 +---------> Bound ingress ACL rules
 *   0x10005 ------+           [Key]                             [Action]
 *                             [L4_port=8080,port-user-memory=0] [Counter-ID cntr_id0]
 *                             [L4_port=8081,port-user-memory=0] [Counter-ID cntr_id1]
 *                             [L4_port=8080,port-user-memory=1] [Counter-ID cntr_id2]
 *                             [L4_port=8081,port-user-memory=1] [Counter-ID cntr_id3]
 *
 *   Example flow:
 *       1) create a file descriptor and register for the SX_TRAP_ID_BULK_COUNTER_DONE_EVENT
 *          event (this event is received when bulk-counter-read operation is done).
 *       2) allocate 16 flow counters with consecutive IDs (the only way to assure consecutive
 *          IDs is to use the bulk counter allocation API, and the minimum possible bulk size
 *          is 16). This example needs only 4 counters.
 *       3) Allocate bulk-counter-read buffer
 *       4) Create ingress ACL region, group, 4 rules.
 *       5) Bind ACL rules to both ports.
 *       6) Set port-user-memory to 0 on both ports.
 *
 *       7) At this phase, user can run traffic on these ports in order to hit the ACL
 *          rules and increment the flow counters.
 *          The example waits for user key-press to read the counters. On user input,
 *          port-user-memory is changed so the flow counters of the previous port-user-memory will
 *          stop counting and counters can be retrieved.
 *          The example does this twice: for port-user-memory=0 and then for port-user-memory=1.
 *
 *       8) Example cleanup.
 */

#include <stdio.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_lib_host_ifc.h>
#include <sx/sdk/sx_api_flow_counter.h>
#include <sx/sdk/sx_api_bulk_counter.h>

#define TEST_NUM_KEYS          2
#define TEST_NUM_ACLS_IN_GROUP 1
#define TEST_NUM_RULES         4
#define TEST_NUM_FLOW_COUNTERS (TEST_NUM_RULES)
#define TEST_NUM_ACTIONS       1
#define TEST_NUM_PORTS         2

#define TEST_ASSERT(cond, msg)                                                                 \
    if (!(cond)) {                                                                             \
        if (errno) {                                                                           \
            printf("ERROR [%s:%d]: %s [%s]\n", __FUNCTION__, __LINE__, #msg, strerror(errno)); \
        }                                                                                      \
        else {                                                                                 \
            printf("ERROR [%s:%d]: %s\n", __FUNCTION__, __LINE__, #msg);                       \
        }                                                                                      \
        exit(1);                                                                               \
    }

#define TEST_SX_ASSERT(sx_status, msg)                                                              \
    if (SX_CHECK_FAIL(sx_status)) {                                                                 \
        printf("ERROR [%s:%d]: %s [%s]\n", __FUNCTION__, __LINE__, #msg, sx_status_str(sx_status)); \
        exit(1);                                                                                    \
    }

typedef struct test_data {
    /* acl data */
    sx_acl_key_t            acl_keys[TEST_NUM_KEYS];
    sx_acl_key_type_t       acl_key_handle;
    sx_acl_region_id_t      acl_region_id;
    sx_acl_region_group_t   acl_region_group;
    sx_acl_id_t             acl_id;
    sx_acl_id_t             acl_group_id;
    sx_acl_id_t             acl_id_list[TEST_NUM_ACLS_IN_GROUP];
    sx_acl_rule_offset_t    acl_offsets_list[TEST_NUM_RULES];
    sx_flex_acl_flex_rule_t acl_rules_list[TEST_NUM_RULES];

    /* flow counters allocation */
    sx_flow_counter_bulk_attr_t bulk_attr;
    sx_flow_counter_bulk_data_t bulk_data;

    /* bulk read of flow counters */
    sx_bulk_cntr_buffer_key_t bulk_read_key;
    sx_bulk_cntr_buffer_t     bulk_read_buff;

    /* ports */
    sx_port_id_t ingress_ports[TEST_NUM_PORTS];

    /* file descriptor */
    sx_fd_t sx_fd;
} test_data_t;


void __allocate_flow_counters(sx_api_handle_t api_handle, test_data_t *test_data)
{
    sx_status_t sx_status;

    test_data->bulk_attr.counter_type = SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES;
    test_data->bulk_attr.counter_num = 4 * TEST_NUM_FLOW_COUNTERS;
    sx_status = sx_api_flow_counter_bulk_set(api_handle,
                                             SX_ACCESS_CMD_CREATE,
                                             test_data->bulk_attr,
                                             &test_data->bulk_data);
    TEST_SX_ASSERT(sx_status, "sx_api_flow_counter_bulk_set()");
    printf("Allocated %d flow counters\n", TEST_NUM_FLOW_COUNTERS);
}


void __init_rule_with_counter(sx_flex_acl_flex_rule_t *rule,
                              uint16_t                 layer4_port,
                              sx_port_user_memory_t    port_user_memory,
                              sx_flow_counter_id_t     counter_id)
{
    rule->valid = 1;
    rule->key_desc_count = TEST_NUM_KEYS;
    rule->key_desc_list_p[0].key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT;
    rule->key_desc_list_p[0].key.l4_destination_port = layer4_port;
    rule->key_desc_list_p[0].mask.l4_destination_port = 0xffff;
    rule->key_desc_list_p[1].key_id = FLEX_ACL_KEY_PORT_USER_MEMORY;
    rule->key_desc_list_p[1].key.port_user_memory = port_user_memory;
    rule->key_desc_list_p[1].mask.port_user_memory = 0xff;
    rule->action_count = TEST_NUM_ACTIONS;
    rule->action_list_p[0].type = SX_FLEX_ACL_ACTION_COUNTER;
    rule->action_list_p[0].fields.action_counter.counter_id = counter_id;
}


void __create_acl(sx_api_handle_t api_handle, test_data_t *test_data)
{
    sx_status_t sx_status;
    int         i;

    /* create ACL key handle */
    test_data->acl_keys[0] = FLEX_ACL_KEY_L4_DESTINATION_PORT;
    test_data->acl_keys[1] = FLEX_ACL_KEY_PORT_USER_MEMORY;
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_CREATE,
                                        test_data->acl_keys,
                                        TEST_NUM_KEYS,
                                        &test_data->acl_key_handle);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_flex_key_set()");
    printf("Created ACL key handle\n");

    /* create ACL region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_CREATE,
                                      test_data->acl_key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      TEST_NUM_RULES,
                                      &test_data->acl_region_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_region_set()");
    printf("Created ACL region\n");

    /* create ACL */
    test_data->acl_region_group.regions.acl_packet_agnostic.region = test_data->acl_region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_CREATE,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               SX_ACL_DIRECTION_INGRESS,
                               &test_data->acl_region_group,
                               &test_data->acl_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_set()");
    printf("Created ACL\n");

    /* create ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_CREATE,
                                     SX_ACL_DIRECTION_INGRESS,
                                     test_data->acl_id_list,
                                     0,
                                     &test_data->acl_group_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_group_set()");
    printf("Created ACL group\n");

    /* Link ACL to ACL group */
    test_data->acl_id_list[0] = test_data->acl_id;
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_SET,
                                     SX_ACL_DIRECTION_INGRESS,
                                     test_data->acl_id_list,
                                     TEST_NUM_ACLS_IN_GROUP,
                                     &test_data->acl_group_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_group_set()");
    printf("Linked ACL to ACL group\n");

    /* initialize ACL rules */
    for (i = 0; i < TEST_NUM_RULES; i++) {
        test_data->acl_offsets_list[i] = i;

        sx_status = sx_lib_flex_acl_rule_init(test_data->acl_key_handle,
                                              TEST_NUM_ACTIONS,
                                              &test_data->acl_rules_list[i]);
        TEST_SX_ASSERT(sx_status, "sx_lib_flex_acl_rule_init()");
    }

    __init_rule_with_counter(&test_data->acl_rules_list[0], 8080, 0, test_data->bulk_data.base_counter_id);
    __init_rule_with_counter(&test_data->acl_rules_list[1], 8081, 0, test_data->bulk_data.base_counter_id + 1);
    __init_rule_with_counter(&test_data->acl_rules_list[2], 8080, 1, test_data->bulk_data.base_counter_id + 2);
    __init_rule_with_counter(&test_data->acl_rules_list[3], 8081, 1, test_data->bulk_data.base_counter_id + 3);
    printf("Initialized %d ACL rules\n", TEST_NUM_RULES);

    /* set ACL rules */
    sx_status = sx_api_acl_flex_rules_set(api_handle,
                                          SX_ACCESS_CMD_SET,
                                          test_data->acl_region_id,
                                          test_data->acl_offsets_list,
                                          test_data->acl_rules_list,
                                          TEST_NUM_RULES);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_flex_rules_set()");
    printf("Set ACL rules\n");

    /* bind ACL rules to ports */
    for (i = 0; i < TEST_NUM_PORTS; i++) {
        sx_status = sx_api_acl_port_bind_set(api_handle,
                                             SX_ACCESS_CMD_BIND,
                                             test_data->ingress_ports[i],
                                             test_data->acl_group_id);
        TEST_SX_ASSERT(sx_status, "sx_api_acl_port_bind_set()");
    }
    printf("Bound ACL rules to ingress ports\n");
}


void __delete_acl(sx_api_handle_t api_handle, test_data_t *test_data)
{
    sx_status_t sx_status;
    int         i;

    /* unbind ACL group from ports */
    for (i = 0; i < TEST_NUM_PORTS; i++) {
        sx_status = sx_api_acl_port_bind_set(api_handle,
                                             SX_ACCESS_CMD_UNBIND,
                                             test_data->ingress_ports[i],
                                             test_data->acl_group_id);
        TEST_SX_ASSERT(sx_status, "sx_api_acl_port_bind_set()");
    }

    /* delete ACL rules */
    sx_status = sx_api_acl_flex_rules_set(api_handle,
                                          SX_ACCESS_CMD_DELETE,
                                          test_data->acl_region_id,
                                          test_data->acl_offsets_list,
                                          test_data->acl_rules_list,
                                          TEST_NUM_RULES);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_flex_rules_set()");

    /* deinitialize ACL rules structure */
    for (i = 0; i < TEST_NUM_RULES; i++) {
        sx_status = sx_lib_flex_acl_rule_deinit(&test_data->acl_rules_list[i]);
        TEST_SX_ASSERT(sx_status, "sx_lib_flex_acl_rule_deinit()");
    }

    /* destroy ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     SX_ACL_DIRECTION_INGRESS,
                                     test_data->acl_id_list,
                                     TEST_NUM_ACLS_IN_GROUP,
                                     &test_data->acl_group_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_group_set()");

    /* destroy ACL */
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               SX_ACL_DIRECTION_INGRESS,
                               &test_data->acl_region_group,
                               &test_data->acl_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_set()");

    /* destroy ACL region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      test_data->acl_key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      TEST_NUM_RULES,
                                      &test_data->acl_region_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_region_set()");

    /* delete ACL key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_DELETE,
                                        test_data->acl_keys,
                                        TEST_NUM_KEYS,
                                        &test_data->acl_key_handle);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_flex_key_set()");
}


void __deallocate_flow_counters(sx_api_handle_t api_handle, test_data_t *test_data)
{
    sx_status_t sx_status;

    sx_status = sx_api_flow_counter_bulk_set(api_handle,
                                             SX_ACCESS_CMD_DESTROY,
                                             test_data->bulk_attr,
                                             &test_data->bulk_data);
    TEST_SX_ASSERT(sx_status, "sx_api_flow_counter_bulk_set()");
}


void __click_any_key_to_continue(const char *msg)
{
    printf("\nCLICK ANY KEY TO %s", msg);
    getchar();
}


void __set_port_user_memory(sx_api_handle_t api_handle, test_data_t *test_data, uint8_t pum)
{
    sx_port_user_memory_params_t port_params_list[TEST_NUM_PORTS];
    sx_status_t                  sx_status;
    int                          i;

    memset(port_params_list, 0, sizeof(port_params_list));

    for (i = 0; i < TEST_NUM_PORTS; i++) {
        port_params_list[i].log_port = test_data->ingress_ports[i];
        port_params_list[i].port_user_memory_value = pum;
        port_params_list[i].port_user_memory_mask = 0xff;
    }

    sx_status = sx_api_port_user_memory_set(api_handle, SX_ACCESS_CMD_SET, port_params_list, TEST_NUM_PORTS);
    TEST_SX_ASSERT(sx_status, "sx_api_port_user_memory_set()");

    printf("Set port-user-memory to %u\n", pum);
}


void __allocate_buffer_for_bulk_counter_read(sx_api_handle_t api_handle, test_data_t *test_data)
{
    sx_status_t sx_status;

    test_data->bulk_read_key.type = SX_BULK_CNTR_KEY_TYPE_FLOW_E;
    test_data->bulk_read_key.key.flow_key.base_counter_id = test_data->bulk_data.base_counter_id;
    test_data->bulk_read_key.key.flow_key.num_of_counters = TEST_NUM_FLOW_COUNTERS;
    sx_status = sx_api_bulk_counter_buffer_set(api_handle,
                                               SX_ACCESS_CMD_CREATE,
                                               &test_data->bulk_read_key,
                                               &test_data->bulk_read_buff);
    TEST_SX_ASSERT(sx_status, "sx_api_bulk_counter_buffer_set()");
}


void __deallocate_buffer_of_bulk_counter_read(sx_api_handle_t api_handle, test_data_t *test_data)
{
    sx_status_t sx_status;

    sx_status = sx_api_bulk_counter_buffer_set(api_handle,
                                               SX_ACCESS_CMD_DESTROY,
                                               NULL,
                                               &test_data->bulk_read_buff);
    TEST_SX_ASSERT(sx_status, "sx_api_bulk_counter_buffer_set()");
}


void __read_flow_counters(sx_api_handle_t api_handle, test_data_t *test_data)
{
    uint8_t                 buff[1024] = { 0 };
    uint32_t                buff_size = sizeof(buff);
    sx_receive_info_t       receive_info;
    sx_bulk_cntr_data_t     counter_bulk;
    sx_bulk_cntr_read_key_t key_get;
    sx_status_t             sx_status;
    fd_set                  r_fds;
    struct timeval          tv;
    int                     i, err;

    memset(&receive_info, 0, sizeof(receive_info));
    memset(&counter_bulk, 0, sizeof(counter_bulk));

    sx_status = sx_api_bulk_counter_transaction_set(api_handle,
                                                    SX_ACCESS_CMD_READ,
                                                    &test_data->bulk_read_buff);
    TEST_SX_ASSERT(sx_status, "sx_api_bulk_counter_transaction_set(READ)");

    /* wait up to 10sec for counters to be ready */
    FD_ZERO(&r_fds);
    FD_SET(test_data->sx_fd.fd, &r_fds);
    tv.tv_sec = 10;
    tv.tv_usec = 0;
    err = select(test_data->sx_fd.fd + 1, &r_fds, NULL, NULL, &tv);
    TEST_ASSERT(err > 0, "select()");

    sx_status = sx_lib_host_ifc_recv(&test_data->sx_fd, buff, &buff_size, &receive_info);
    TEST_SX_ASSERT(sx_status, "sx_lib_host_ifc_recv()");

    for (i = 0; i < TEST_NUM_FLOW_COUNTERS; i++) {
        /* read the counter */
        memset(&key_get, 0, sizeof(key_get));
        key_get.type = SX_BULK_CNTR_KEY_TYPE_FLOW_E;
        key_get.key.flow_key.cntr_id = test_data->bulk_data.base_counter_id + i;
        sx_status = sx_api_bulk_counter_transaction_get(api_handle,
                                                        &key_get,
                                                        &test_data->bulk_read_buff,
                                                        &counter_bulk);
        TEST_SX_ASSERT(sx_status, "sx_api_bulk_counter_transaction_get()");

        printf("Counter [%u]: packets=%" PRIu64 ", bytes=%" PRIu64 "\n",
               test_data->bulk_data.base_counter_id + i,
               counter_bulk.data.flow_counters.flow_cntr_p->flow_counter_packets,
               counter_bulk.data.flow_counters.flow_cntr_p->flow_counter_bytes);
    }

    printf("\n");
}


void __open_file_descriptor(sx_api_handle_t api_handle, test_data_t *test_data)
{
    sx_user_channel_t uc;
    sx_status_t       sx_status;

    sx_status = sx_api_host_ifc_open(api_handle, &test_data->sx_fd);
    TEST_SX_ASSERT(sx_status, "sx_api_host_ifc_open()");

    memset(&uc, 0, sizeof(uc));
    uc.type = SX_USER_CHANNEL_TYPE_FD;
    memcpy(&uc.channel.fd, &test_data->sx_fd, sizeof(uc.channel.fd));
    sx_status = sx_api_host_ifc_trap_id_register_set(api_handle,
                                                     SX_ACCESS_CMD_REGISTER,
                                                     0,
                                                     SX_TRAP_ID_BULK_COUNTER_DONE_EVENT,
                                                     &uc);
    TEST_SX_ASSERT(sx_status, "sx_api_host_ifc_trap_id_register_set()");
}


void __close_file_descriptor(sx_api_handle_t api_handle, test_data_t *test_data)
{
    sx_status_t sx_status;

    sx_status = sx_api_host_ifc_close(api_handle, &test_data->sx_fd);
    TEST_SX_ASSERT(sx_status, "sx_api_host_ifc_close()");
}


int main(int argc, const char *argv[])
{
    sx_api_handle_t api_handle;
    sx_status_t     sx_status;
    test_data_t     test_data;

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    memset(&test_data, 0, sizeof(test_data));
    test_data.ingress_ports[0] = 0x10041;
    test_data.ingress_ports[1] = 0x10005;

    /* open SDK */
    sx_status = sx_api_open(NULL, &api_handle);
    TEST_SX_ASSERT(sx_status, "sx_api_open()");

    __open_file_descriptor(api_handle, &test_data);

    /* set test configuration */
    __allocate_flow_counters(api_handle, &test_data);
    __allocate_buffer_for_bulk_counter_read(api_handle, &test_data);
    __create_acl(api_handle, &test_data);

    __set_port_user_memory(api_handle, &test_data, 0);
    __click_any_key_to_continue("read counters when port-user-memory=0");
    __read_flow_counters(api_handle, &test_data);

    __set_port_user_memory(api_handle, &test_data, 1);
    __click_any_key_to_continue("read counters when port-user-memory=1");
    __read_flow_counters(api_handle, &test_data);

    /* unset test configuration */
    __delete_acl(api_handle, &test_data);
    __deallocate_buffer_of_bulk_counter_read(api_handle, &test_data);
    __deallocate_flow_counters(api_handle, &test_data);

    __close_file_descriptor(api_handle, &test_data);

    /* close SDK */
    sx_api_close(&api_handle);
    return 0;
}
