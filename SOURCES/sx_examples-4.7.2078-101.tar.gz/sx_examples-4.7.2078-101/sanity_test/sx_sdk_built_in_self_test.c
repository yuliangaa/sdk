/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <arpa/inet.h>
#include <linux/if_packet.h>
#include <linux/if_vlan.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/ether.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_trap_id.h>
#include <complib/sx_log.h>

#define DEFAULT_IF "p10001"
#define BUF_SIZ    1024

const unsigned char my_dst_mac[] = { 0x23, 0x8a, 0x07, 0x5c, 0xd8, 0xf1 };

struct vlan_ethhdr {
    uint8_t  h_dest[ETH_ALEN]; /* destination eth addr */
    uint8_t  h_source[ETH_ALEN]; /* source ether addr    */
    uint16_t h_vlan_proto;
    uint16_t h_vlan_TCI;
    uint16_t h_vlan_encapsulated_proto;
};

static int __health_running_counter_get(void)
{
    int   counter = -1;
    FILE* in_file = fopen("/sys/module/sx_core/health_check_running_counter", "r");    /* read only */

    if (!in_file) {  /* equivalent to saying if ( in_file == NULL ) */
        printf("Failed to open health_check_running_counter file\n");
        goto out;
    }

    if (1 != fscanf(in_file, "%d", &counter)) {
        printf("Reading health_check_running_counter failed\n");
        goto close_file;
    }

    if (!counter) {
        printf("ERROR: health_check_running_counter is 0\n");
    }

close_file:
    fclose(in_file);

out:
    return counter;
}

/* Testing health-check running counter */
static int __check_health_running_counter(void)
{
    int prev_cnt, new_cnt;

    prev_cnt = __health_running_counter_get();
    if (prev_cnt == -1) {
        printf("could not read health running counter\n");
        return 1;
    }

    sleep(2);   /* every 1 second counter is increase by 1 */


    new_cnt = __health_running_counter_get();
    if (new_cnt == -1) {
        printf("could not read health running counter\n");
        return 1;
    }

    if (prev_cnt == new_cnt) {
        printf("health running counter is stuck, last read value %d\n", new_cnt);
        return 1;
    }

    return 0;
}

#define IP_FILENAME_PATH   "/tmp/ip_routing_check.txt"
#define NEW_IP_TOOL_SUFFIX "sx-netdev"
#define OLD_IP_TOOL_SUFFIX "_mlnx"
static boolean_t __is_patched_iproute_installed(void)
{
    char        cmd[1024] = {0};
    char        ip_ver_str[100] = { 0 };
    FILE       *ip_check_file = NULL;
    int         err = 0;
    const char *ret = NULL;
    boolean_t   is_patched = FALSE;

    /* Writing the ip version to the file */
    snprintf(cmd, sizeof(cmd), "ip -V > %s", IP_FILENAME_PATH);
    err = system(cmd);
    if (err) {
        printf("failed to write the ip version to ip_route_check file\n");
        return FALSE;
    }

    ip_check_file = fopen(IP_FILENAME_PATH, "r");  /* read only */
    if (!ip_check_file) {
        printf("failed to open the ip_route_check file\n");
        return FALSE;
    }

    ret = fgets(ip_ver_str, 100, ip_check_file);
    if (ret == NULL) {
        printf("failed to getch iproute version from file\n");
        goto close_file;
    }

    ret = strstr(ip_ver_str, OLD_IP_TOOL_SUFFIX);
    if (ret == NULL) {
        ret = strstr(ip_ver_str, NEW_IP_TOOL_SUFFIX);
        if (ret == NULL) {
            printf("ip-route does not support SX netdev\n");
            goto close_file;
        }
    }

    is_patched = TRUE;

close_file:
    if (fclose(ip_check_file)) {
        printf("failed to close ip_check_file file\n");
    }

    return is_patched;
}

static int __port_admin_set(sx_api_handle_t api_handle, sx_port_log_id_t log_port, boolean_t is_up)
{
    sx_port_admin_state_t admin_state = is_up ? SX_PORT_ADMIN_STATUS_UP : SX_PORT_ADMIN_STATUS_DOWN;
    sx_status_t           sx_status = sx_api_port_state_set(api_handle, log_port, admin_state);

    if (sx_status != SX_STATUS_SUCCESS) {
        printf("failed to set port 0x%x state to %s [err=%s]\n",
               log_port,
               ((is_up) ? "UP" : "DOWN"),
               sx_status_str(sx_status));
        return 1;
    }

    return 0;
}

static int __port_loopback_set(sx_api_handle_t api_handle, sx_port_log_id_t log_port, boolean_t is_up)
{
    sx_port_phys_loopback_t phys_loopback = is_up ? SX_PORT_PHYS_LOOPBACK_ENABLE_INTERNAL :
                                            SX_PORT_PHYS_LOOPBACK_DISABLE;
    sx_status_t sx_status = sx_api_port_phys_loopback_set(api_handle, log_port, phys_loopback);

    if (sx_status != SX_STATUS_SUCCESS) {
        printf("failed to set loopback port 0x%x state to %s [err=%s]\n",
               log_port,
               ((is_up) ? "LOOPBACK" : "DISABLED"),
               sx_status_str(sx_status));
        return 1;
    }

    return 0;
}

static int __config_port(sx_api_handle_t api_handle, sx_port_log_id_t log_port, boolean_t is_up)
{
    int rc = 0;

    rc = __port_admin_set(api_handle, log_port, FALSE);
    if (rc) {
        goto out;
    }

    rc = __port_loopback_set(api_handle, log_port, is_up);
    if (rc) {
        goto lb_set_failed;
    }

    rc = __port_admin_set(api_handle, log_port, TRUE);
    if (rc) {
        goto admin_set_up_failed;
    }

    return 0;

admin_set_up_failed:
    __port_loopback_set(api_handle, log_port, FALSE);
lb_set_failed:
    __port_admin_set(api_handle, log_port, TRUE);
out:
    return 1;
}

static int __netdev_ioctl(int cmd, struct ifreq *ifr)
{
    int fd, err = 0;

    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) {
        printf("cannot open socket to call ioctl(%d) (errno=%d)\n", cmd, errno);
        return 1;
    }

    err = ioctl(fd, cmd, ifr);
    if (err) {
        printf("ioctl(%d) failed (errno=%d)\n", cmd, errno);
    }

    close(fd);
    return err;
}

static int __netdev_set(sx_port_log_id_t log_port, const char *netdev_name, boolean_t is_up)
{
    char        cmd[1024] = {0};
    const char *op = is_up ? "add" : "del";
    int         err = 0;

    snprintf(cmd, sizeof(cmd), "ip link %s %s type sx_netdev port 0x%x", op, netdev_name, log_port);
    err = system(cmd);
    if (err) {
        printf("ERROR:failed to %s port0x%X to sx_netdev\n", op, log_port);
        return 1;
    }

    return 0;
}

static int __netdev_admin_set(const char *netdev_name, boolean_t is_up)
{
    struct ifreq ifr;
    int          err = 0;

    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, netdev_name, IFNAMSIZ - 1);

    err = __netdev_ioctl(SIOCGIFFLAGS, &ifr);
    if (err) {
        printf("failed to get netdev flags [netdev=%s]\n", netdev_name);
        return 1;
    }

    if (is_up) {
        ifr.ifr_flags |= IFF_UP;
    } else {
        ifr.ifr_flags &= ~IFF_UP;
    }

    err = __netdev_ioctl(SIOCSIFFLAGS, &ifr);
    if (err) {
        printf("failed to set netdev flags [netdev=%s]\n", netdev_name);
        return 1;
    }

    return 0;
}

static int __netdev_show(const char *netdev_name)
{
    char cmd[1024] = {0};
    int  err = 0;

    snprintf(cmd, sizeof(cmd), "ifconfig %s", netdev_name);
    err = system(cmd);
    if (err) {
        printf("ERROR:failed to do ifconfig %s.\n", netdev_name);
        return 1;
    }

    return 0;
}

static int __init_netdev(sx_port_log_id_t log_port, const char *netdev_name)
{
    int err;

    /* we disable swid0_eth for the whole duration of the test because it may send some
     * IPv6 packets that will do noise and fail the test */
    err = __netdev_admin_set("swid0_eth", FALSE);
    if (err) {
        goto swid0_eth_failed;
    }

    err = __netdev_set(log_port, netdev_name, TRUE);
    if (err) {
        goto netdev_set_failed;
    }

    err = __netdev_admin_set(netdev_name, TRUE);
    if (err) {
        goto netdev_admin_set_failed;
    }

    return 0;

netdev_admin_set_failed:
    __netdev_set(log_port, netdev_name, FALSE);
netdev_set_failed:
    __netdev_admin_set("swid0_eth", TRUE);
swid0_eth_failed:
    return 1;
}

static int __deinit_netdev(sx_port_log_id_t log_port, const char *netdev_name)
{
    int err = 0;

    err |= __netdev_admin_set("swid0_eth", TRUE);
    err |= __netdev_admin_set(netdev_name, FALSE);
    err |= __netdev_set(log_port, netdev_name, FALSE);
    return err;
}

static int __open_raw_socket(const char *netdev_name, int *fd, char *buff, size_t *buff_size, /* in/out parameter */
                             struct sockaddr_ll *sll)
{
    struct ifreq        if_idx;
    struct ifreq        if_mac;
    struct vlan_ethhdr *vlan_header = (struct vlan_ethhdr *)buff;
    int                 sockfd;
    int                 priority;
    size_t              tx_len = 0, tx_left = *buff_size;
    int                 err = 0;

    /* Open RAW socket to send on */
    if ((sockfd = socket(AF_PACKET, SOCK_RAW, IPPROTO_RAW)) == -1) {
        printf("ERROR:opening socket.\n");
        goto socket_failed;
    }

    if (setsockopt(sockfd, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority)) < 0) {
        printf("setsockopt(SO_PRIORITY) failed.\n");
        goto close_sock;
    }

    /* Get the index of the interface to send on */
    memset(&if_idx, 0, sizeof(struct ifreq));
    strncpy(if_idx.ifr_name, netdev_name, IFNAMSIZ - 1);
    err = __netdev_ioctl(SIOCGIFINDEX, &if_idx);
    if (err) {
        printf("failed to get netdev ifindex\n");
        goto close_sock;
    }

    /* Get the MAC address of the interface to send on */
    memset(&if_mac, 0, sizeof(struct ifreq));
    strncpy(if_mac.ifr_name, netdev_name, IFNAMSIZ - 1);
    err = __netdev_ioctl(SIOCGIFHWADDR, &if_mac);
    if (err) {
        printf("failed to get netdev MAC address\n");
        goto close_sock;
    }

    /* Construct the Ethernet header */
    memset(buff, 0, *buff_size);

    if (tx_left < sizeof(struct vlan_ethhdr)) {
        printf("buffer is too short for VLAN header\n");
        goto close_sock;
    }

    /* Ethernet header */
    memcpy(vlan_header->h_source, &if_mac.ifr_hwaddr, 6);
    memcpy(vlan_header->h_dest, my_dst_mac, 6);

    /* Ethertype field */
    /* vlan tagged pcp 7 vlan 1 */
    vlan_header->h_vlan_proto = htons(ETH_P_8021Q);
    vlan_header->h_vlan_TCI = htons(0xe001);
    vlan_header->h_vlan_encapsulated_proto = htons(0x88cc);

    tx_left -= sizeof(struct vlan_ethhdr);
    tx_len += sizeof(struct vlan_ethhdr);

    if (tx_left < 100) {
        printf("buffer is too short for packet data\n");
        goto close_sock;
    }

    /* Packet data */
    memset(buff + tx_len, 0x55, 100);
    tx_left -= 100;
    tx_len += 100;

    memset(sll, 0, sizeof(*sll));
    sll->sll_ifindex = if_idx.ifr_ifindex; /* Index of the network device */
    sll->sll_halen = ETH_ALEN;             /* Address length*/
    memcpy(sll->sll_addr, my_dst_mac, 6);  /* Destination MAC */

    *fd = sockfd;
    *buff_size = tx_len;
    return 0;

close_sock:
    close(sockfd);

socket_failed:
    return 1;
}

static int __check_swid0_eth_is_down(void)
{
    struct ifreq ifr;

    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, "swid0_eth", IFNAMSIZ - 1);
    if (__netdev_ioctl(SIOCGIFFLAGS, &ifr)) {
        printf("failed to get swid0_eth flags\n");
        return 1;
    }

    if (ifr.ifr_flags & IFF_UP) {
        printf("swid0_eth is UP and should be DOWN!\n");
        __netdev_admin_set("swid0_eth", FALSE);
    }

    return 0;
}

#define MIN_TIMES_EQUAL  (3)  /* minimum consecutive samples to be sure that the counters are stable */
#define MAX_TIME_TO_WAIT (10) /* maximum time to wait (in seconds) for the port counters to be stable */

static int __wait_for_counters_to_stop(sx_api_handle_t                api_handle,
                                       sx_port_log_id_t               log_port,
                                       sx_port_cntr_ieee_802_dot_3_t *counters)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sx_port_cntr_t last_counter = 0;
    int            eq_counter = 0;
    int            ret = 1;
    int            round = 0;

    while (1) {
        if (round >= MAX_TIME_TO_WAIT) {
            printf("\twaited too long for the counters to stop\n");
            break;
        }

        round++;
        printf("\tround=%d, eq_counter=%d\n", round, eq_counter);

        memset(counters, 0, sizeof(*counters));
        sx_status = sx_api_port_counter_ieee_802_dot_3_get(api_handle,
                                                           SX_ACCESS_CMD_READ,
                                                           log_port,
                                                           counters);

        if (sx_status != SX_STATUS_SUCCESS) {
            printf("\tERROR: SDK API sx_api_port_counter_ieee_802_dot_3_get failed: [%s] \n",
                   sx_status_str(sx_status));
            break;
        }

        if (counters->a_frames_received_ok == last_counter) {
            eq_counter++; /* increment consecutive samples that the counters are equal */
        } else {
            printf("\tcounters are not equal: last_counter=%lu, current_counter=%lu\n",
                   last_counter,
                   counters->a_frames_received_ok);
            eq_counter = 0; /* reset consecutive samples that the counters are equal */

            if (__check_swid0_eth_is_down() != 0) {
                break;
            }
        }

        if (eq_counter >= MIN_TIMES_EQUAL) { /* counters are stable, go out */
            ret = 0;
            break;
        }

        last_counter = counters->a_frames_received_ok;
        sleep(1);
    }

    return ret;
}

int main(void)
{
    boolean_t                     iproute_support = FALSE;
    int                           sockfd = 0;
    sx_api_handle_t               api_handle = 0;
    sx_status_t                   sx_status = 0;
    struct sockaddr_ll            socket_address;
    char                          sendbuf[BUF_SIZ] = {0};
    size_t                        buflen = sizeof(sendbuf);
    int                           log_port = 0x10001;
    int                           err = 0;
    sx_port_cntr_ieee_802_dot_3_t new_cntr_ieee_802_dot_3;
    sx_port_cntr_ieee_802_dot_3_t prev_cntr_ieee_802_dot_3;
    int                           test_res = 0;

    test_res = __check_health_running_counter();
    if (test_res != 0) {
        printf("Test 'health check running counter' failed (test_res=%d)\n", test_res);
        goto out;
    }

    iproute_support = __is_patched_iproute_installed();

    /* Open SDK API */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        test_res = 1;
        goto out;
    }

    test_res = __config_port(api_handle, log_port, TRUE);
    if (test_res != 0) {
        printf("Test 'config port UP' failed (test_res=%d)\n", test_res);
        goto close_handle;
    }

    if (!iproute_support) {
        goto cleanup_port;
    }

    test_res = __init_netdev(log_port, DEFAULT_IF);
    if (test_res != 0) {
        printf("Test 'config netdev' failed (test_res=%d)\n", test_res);
        goto cleanup_port;
    }

    test_res = __open_raw_socket(DEFAULT_IF, &sockfd, sendbuf, &buflen, &socket_address);
    if (test_res) {
        printf("Test 'open raw socket' failed (test_res=%d)\n", test_res);
        goto deinit_netdev;
    }

    printf("Current state of net-devices\n");
    __netdev_show("swid0_eth");
    __netdev_show(DEFAULT_IF);

    printf("waiting for counters to be stable before sending\n");
    test_res = __wait_for_counters_to_stop(api_handle, log_port, &prev_cntr_ieee_802_dot_3);
    if (test_res) {
        printf("Test 'wait for counters to stop (prev)' failed (test_res=%d)\n", test_res);
        __netdev_show("swid0_eth");
        __netdev_show(DEFAULT_IF);
        goto close_socket;
    }

    /* Send packet */
    if (sendto(sockfd, sendbuf, buflen, 0, (struct sockaddr*)&socket_address, sizeof(struct sockaddr_ll)) < 0) {
        printf("Send failed\n");
        test_res = 1;
        goto close_socket;
    }

    printf("waiting for counters to be stable after sending\n");
    test_res = __wait_for_counters_to_stop(api_handle, log_port, &new_cntr_ieee_802_dot_3);
    if (test_res) {
        printf("Test 'wait for counters to stop (new)' failed (test_res=%d)\n", test_res);
        __netdev_show("swid0_eth");
        __netdev_show(DEFAULT_IF);
        goto close_socket;
    }

    if (new_cntr_ieee_802_dot_3.a_frames_received_ok == (prev_cntr_ieee_802_dot_3.a_frames_received_ok + 1)) {
        printf("Test passed\n");
    } else {
        printf("Test failed [prev_counter=%lu, new_counter=%lu]\n",
               prev_cntr_ieee_802_dot_3.a_frames_received_ok,
               new_cntr_ieee_802_dot_3.a_frames_received_ok);
        test_res = 1;
        goto close_socket;
    };

    /*clear all port counters */
    sx_api_port_counter_clear_set(api_handle, log_port, 1, SX_PORT_CNTR_GRP_ALL);

close_socket:
    close(sockfd);

deinit_netdev:
    err = __deinit_netdev(log_port, DEFAULT_IF);
    if (err) {
        printf("Test 'deinit netdev' failed (test_res=%d)\n", err);
        test_res = 1;
    }

cleanup_port:
    err = __config_port(api_handle, log_port, FALSE);
    if (err) {
        printf("Test 'config port Down' failed (test_res=%d)\n", err);
        test_res = 1;
    }

close_handle:
    /* Close SDK API */
    sx_status = sx_api_close(&api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        test_res = 1;
    }

out:
    return test_res;
};
