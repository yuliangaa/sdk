#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

# Basic Python SDK API Import Test for SDK Installation
# Tests lists:
#   1. Python3 SDK API Import test
#   2. Python3 Py-Compile test for SDK Examples

py_compile_failed_examples=""

error_exit() {
    local err_msg=$1
    echo -e "[ERROR] ${err_msg}"
    echo -e "\nPython3 SDK API Sanity Tests FAILED - Check log"
    exit 1
}

python_test() {
    echo "Testing Python3 SDK API Import"
    python3 -c "from python_sdk_api.sx_api import *; from python_sdk_api.sxd_api import *" || error_exit "Python3 SDK API Import test failed"
}

py_compile() {
  local pattern="${1}"
  if ! ls -l /usr/bin/${pattern}.py > /dev/null 2>&1; then
      error_exit "Python examples matching pattern '${pattern}.py' not found under /usr/bin"
  fi

  for example in /usr/bin/${pattern}.py; do
      if ! python3 -m py_compile "${example}"; then
          echo -e "[ERROR] 'python3 -m py_compile ${example}' failed\n" && py_compile_failed_examples+="${example} "
      fi
  done
}

py_examples_compile() {
    echo -e "Testing Python3 SDK API Examples syntax (py_compile)\n"
    shopt -s globstar   # for whitespace-safety
    py_compile "sx_*"
    py_compile "sxd_api_*"
    py_compile "*wjh*"
    py_compile "test_infra_common"
    py_compile "flex_acl_common"

    if test -n "${py_compile_failed_examples}"; then
        echo -e "\n[ERROR] Examples which failed py_compile test:"
        for example in ${py_compile_failed_examples}; do echo "${example}"; done
        echo
        error_exit "Python3 py_compile test for SDK Python examples failed | Check log | To reproduce: 'python3 -m py_compile <example>'"
    fi
}

if ! which sx_sdk 2>&1 > /dev/null; then
    error_exit "SDK Not installed"
fi

if ! which python3 > /dev/null 2>&1; then
    error "Python3 does not exist on the setup"
fi

sdk_info=$(sx_sdk --info)
python_ver=$(python3 --version)
echo -e "Python3 SDK API Sanity Tests started\n"
echo -e "Python3 Full Version:\n${python_ver}\n"
echo -e "SDK Under test info:\n${sdk_info}\n"

python_test
py_examples_compile

echo -e "\nPython3 SDK API Sanity Tests passed SUCCESS"
