/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_strings.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_fdb.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_api_bridge.h>
#include <sx/sdk/sx_lib_host_ifc.h>
#include <sx/sxd/sxd_access_register.h>
#include <resource_manager/resource_manager.h>
#include <getopt.h>


#define MEASURE_TIME(val)        gettimeofday(val, NULL)
#define CALCULATE_TIME(start_time,                                     \
                       end_time) (unsigned int)(((end_time.tv_sec -    \
                                                  start_time.tv_sec) * \
                                                 1000000) + (end_time.tv_usec - start_time.tv_usec))
#define TIME_DIMENSION "micro seconds"

#define SWID      0
#define DEVICE_ID 1

static sx_status_t __get_chip_type(sx_chip_types_t *chip_type_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mgir_reg mgir_reg;

    memset(&reg_meta, 0, sizeof(reg_meta));
    memset(&mgir_reg, 0, sizeof(mgir_reg));

    if (chip_type_p == NULL) {
        printf("ERROR: chip_type_p is NULL.\n");
        exit(1);
    }

    sxd_status = sxd_access_reg_init(0, NULL, SX_VERBOSITY_LEVEL_INFO);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        printf("ERROR: SXD API sxd_access_reg_init failed: [%s]\n", SXD_STATUS_MSG(sxd_status));
        exit(1);
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.dev_id = 1;
    memset(&mgir_reg, 0, sizeof(struct ku_mgir_reg));

    sxd_status = sxd_access_reg_mgir(&mgir_reg, &reg_meta, 1, NULL, NULL);
    if (sxd_status) {
        printf("%s: failed in get MGIR for dev_id %d, error: %d \n",
               __func__, 1, sxd_status);
    }

    switch (mgir_reg.hw_info.device_id) {
    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
        if (mgir_reg.hw_info.device_hw_revision == 0xA0) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM;
        } else if (mgir_reg.hw_info.device_hw_revision == 0xA1) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM_A1;
        } else {
            printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
            exit(1);
        }
        printf("Device type is: SPECTRUM.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM2;

        printf("Device type is: SPECTRUM2.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM3;
        printf("Device type is: SPECTRUM3.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM4;
        printf("Device type is: SPECTRUM4.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM5;
        printf("Device type is: SPECTRUM5.\n");
        break;

    default:
        printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
        exit(1);
    }

    return status;
}

/*
 *   we assume the vport_array size be : log_port_num * vlan_num.
 */
sx_status_t __vport_scale_set(const sx_api_handle_t handle,
                              sx_access_cmd_t       cmd,
                              sx_port_log_id_t     *log_port_array,
                              sx_port_log_id_t     *vport_array,
                              uint32_t              log_port_num,
                              uint32_t              vlan_start_id,
                              uint32_t              vlan_num)
{
    sx_port_log_id_t vport = 0;
    sx_status_t      status = SX_STATUS_SUCCESS;
    uint32_t         i, j;

    if (cmd == SX_ACCESS_CMD_ADD) {
        for (i = 0; i < vlan_num; i++) {
            for (j = 0; j < log_port_num; j++) {
                status = sx_api_port_vport_set(handle, cmd, log_port_array[j], vlan_start_id + i, &vport);
                if (SX_CHECK_FAIL(status)) {
                    goto out;
                }
                vport_array[i * log_port_num + j] = vport;
            }
        }
    } else {
        for (i = 0; i < vlan_num; i++) {
            for (j = 0; j < log_port_num; j++) {
                vport = vport_array[i * log_port_num + j];
                status = sx_api_port_vport_set(handle, cmd, log_port_array[j], vlan_start_id + i, &vport);
                if (SX_CHECK_FAIL(status)) {
                    goto out;
                }
            }
        }
    }
out:
    if (SX_CHECK_FAIL(status)) {
        printf("%s: Failed in running cmd:%u, seq (vlan:%u, log_port:0x%x), vport:0x%x, error: %s.\n",
               __func__, cmd, i, j, vport, sx_status_str(status));
    }
    return status;
}

sx_status_t __bridge_scale_set(const sx_api_handle_t handle, sx_access_cmd_t cmd, sx_bridge_id_t *array, uint32_t num)
{
    sx_bridge_id_t bridge_id = 0;
    sx_status_t    status = SX_STATUS_SUCCESS;
    uint32_t       i;

    if (cmd == SX_ACCESS_CMD_DESTROY) {
        for (i = 0; i < num; i++) {
            bridge_id = array[i];
            status = sx_api_bridge_set(handle, cmd, &bridge_id);
            if (SX_CHECK_FAIL(status)) {
                goto out;
            }
        }
    } else {
        for (i = 0; i < num; i++) {
            status = sx_api_bridge_set(handle, cmd, &bridge_id);
            if (SX_CHECK_FAIL(status)) {
                goto out;
            }
            array[i] = bridge_id;
        }
    }
out:
    if (SX_CHECK_FAIL(status)) {
        printf("%s: Failed in running cmd:%u, seq (%u), bridge_id:%u, error: %s.\n",
               __func__, cmd, i, bridge_id, sx_status_str(status));
    }
    return status;
}

/* vport list is 1k*port_cnt array, add every prot_cnt vports into each bridge respectively */
sx_status_t __vport_bridge_scale_set(const sx_api_handle_t handle,
                                     sx_access_cmd_t       cmd,
                                     sx_bridge_id_t       *bridge_array,
                                     sx_port_log_id_t     *vport_array,
                                     uint32_t              bridge_num,
                                     uint32_t              log_port_num)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    uint32_t    i, j;

    if (cmd == SX_ACCESS_CMD_ADD) {
        for (i = 0; i < bridge_num; i++) {
            for (j = 0; j < log_port_num; j++) {
                status =
                    sx_api_bridge_vport_set(handle, SX_ACCESS_CMD_ADD, bridge_array[i],
                                            vport_array[i * log_port_num + j]);
                if (SX_CHECK_FAIL(status)) {
                    printf("ERROR in %s: failed to add vport(0x%x) to bridge(0x%x), i:%u, j:%u, error = %s.\n",
                           __func__, vport_array[i * log_port_num + j], bridge_array[i], i, j, sx_status_str(status));
                    goto out;
                }
            }
        }
    } else {
        for (i = 0; i < bridge_num; i++) {
            for (j = 0; j < log_port_num; j++) {
                status =
                    sx_api_bridge_vport_set(handle,
                                            SX_ACCESS_CMD_DELETE,
                                            bridge_array[i],
                                            vport_array[i * log_port_num + j]);
                if (SX_CHECK_FAIL(status)) {
                    printf("ERROR in %s: failed to delete vport(0x%x) from bridge(0x%x), i:%u, j:%u, error = %s.\n",
                           __func__, vport_array[i * log_port_num + j], bridge_array[i], i, j, sx_status_str(status));
                    goto out;
                }
            }
        }
    }
out:
    return status;
}

void __display_usage()
{
    printf("bridge_vport_scale -b bridge_num -v vlan_num -p port_num\n");
}


int main(int argc, char **argv)
{
    sx_api_handle_t       api_handle = 0;
    sx_status_t           status = SX_STATUS_SUCCESS;
    rm_resources_t        resource_limits;
    sx_chip_types_t       chip_type = SX_CHIP_TYPE_UNKNOWN;
    sx_port_attributes_t *port_attr_p = NULL;
    uint32_t              port_cnt = 0;
    sx_bridge_id_t       *bridge_ids;
    sx_port_log_id_t     *log_ports;
    sx_port_log_id_t     *vports;
    uint32_t              bridge_num = 0, vlan_num = 0, vport_num = 0, port_num = 0;
    uint32_t              i;
    unsigned int          time = 0;
    uint32_t              seconds = 0;
    uint32_t              microsec = 0;
    struct timeval        start_time, end_time, vport_end_time,
                          bridge_end_time, add_vport_bridge_end_time,
                          del_vport_bridge_end_time, vport_delete_end_time;
    int                 opt = 0;
    const char* const   short_options = "b:v:p:h";
    const struct option long_options[] = {
        { "bridge_num",    0, NULL, 'b' },
        { "vlan_num",    1, NULL, 'v' },
        { "port_num",    1, NULL, 'p' },
        { "help",    0, NULL, 'h' },
        { NULL,       0, NULL, 0   }
    };

    do {
        opt = getopt_long(argc, argv, short_options, long_options, NULL);
        switch (opt) {
        case 'b':
            bridge_num = atoi(optarg);
            break;

        case 'v':
            vlan_num = atoi(optarg);
            break;

        case 'p':
            port_num = atoi(optarg);
            break;

        case 'h':
        case '?':
        default:
            __display_usage();
            break;
        }
    } while (opt != -1);

    memset(&resource_limits, 0, sizeof(resource_limits));

    if (SX_STATUS_SUCCESS != __get_chip_type(&chip_type)) {
        printf("ERROR: Failed to determine the current chip type.\n");
        exit(1);
    }

    /* Open SDK */
    status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(status));
        exit(1);
    }
    printf("SDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);

    status = rm_chip_limits_get(chip_type, &resource_limits);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API rm_chip_limits_get failed: [%s]\n", sx_status_str(status));
        exit(1);
    }

    /* Get number of ports on the current chip and their attributes */
    status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, NULL, &port_cnt);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_port_device_get failed: [%s].\n", sx_status_str(status));
        exit(1);
    }

    printf("\nCurrent chip has %u system ports.\n", port_cnt);

    port_attr_p = (sx_port_attributes_t*)calloc(port_cnt, sizeof(sx_port_attributes_t));
    if (port_attr_p == NULL) {
        printf("ERROR: failed to allocated memory for port attributes.\n");
        exit(1);
    }

    status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, port_attr_p, &port_cnt);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_port_device_get failed: [%s] on retrieving attributes.\n",
               sx_status_str(status));
        exit(1);
    }
    /*
     *   1. create 1k different vlan vports for each port(up to 48), total 48k vports
     *   2. create 1k bridges
     *   3. add vport to each bridge
     */

    if (bridge_num == 0) {
        bridge_num = 1000;
    }
    assert(bridge_num <= resource_limits.bridge_num_max);
    if (vlan_num == 0) {
        vlan_num = bridge_num;
    }
    assert(vlan_num <= 4095);
    if (port_num == 0) {
        port_num = port_cnt;
    }
    assert(port_num <= port_cnt);

    printf("Input bridge num: %u, vlan num: %u, port num: %u.\n", bridge_num, vlan_num, port_num);

    bridge_ids = (sx_bridge_id_t*)calloc(bridge_num, sizeof(sx_bridge_id_t));
    if (bridge_ids == NULL) {
        printf("ERROR: failed to allocated memory for %d bridge instances.\n", bridge_num);
        exit(1);
    }

    log_ports = (sx_port_log_id_t*)calloc(port_num, sizeof(sx_port_log_id_t));
    if (bridge_ids == NULL) {
        printf("ERROR: failed to allocated memory for %d port array.\n", port_num);
        exit(1);
    }
    for (i = 0; i < port_num; i++) {
        log_ports[i] = port_attr_p[i].log_port;
    }

    vport_num = vlan_num * port_num;
    vports = (sx_port_log_id_t*)calloc(vport_num, sizeof(sx_port_log_id_t));
    if (bridge_ids == NULL) {
        printf("ERROR: failed to allocated memory for %d vport array.\n", vport_num);
        goto out;
    }

    MEASURE_TIME(&start_time);
    __vport_scale_set(api_handle, SX_ACCESS_CMD_ADD, log_ports, vports, port_num, 2, vlan_num);
    MEASURE_TIME(&vport_end_time);
    __bridge_scale_set(api_handle, SX_ACCESS_CMD_CREATE, bridge_ids, bridge_num);
    MEASURE_TIME(&bridge_end_time);
    __vport_bridge_scale_set(api_handle, SX_ACCESS_CMD_ADD, bridge_ids, vports, bridge_num, port_num);
    MEASURE_TIME(&add_vport_bridge_end_time);

    printf("Continue to purge setups...");

    __vport_bridge_scale_set(api_handle, SX_ACCESS_CMD_DELETE, bridge_ids, vports, bridge_num, port_num);
    MEASURE_TIME(&del_vport_bridge_end_time);

out:
    __vport_scale_set(api_handle, SX_ACCESS_CMD_DELETE, log_ports, vports, port_num, 2, vlan_num);
    MEASURE_TIME(&vport_delete_end_time);
    __bridge_scale_set(api_handle, SX_ACCESS_CMD_DESTROY, bridge_ids, bridge_num);
    MEASURE_TIME(&end_time);

    time = CALCULATE_TIME(start_time, vport_end_time);
    /* Convert Microseconds to seconds */
    seconds = time / 1000000;
    microsec = (time % 1000000) / 1000;
    printf("vport setup time\t: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);

    time = CALCULATE_TIME(vport_end_time, bridge_end_time);
    seconds = time / 1000000;
    microsec = (time % 1000000) / 1000;
    printf("bridge setup time\t: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);

    time = CALCULATE_TIME(bridge_end_time, add_vport_bridge_end_time);
    seconds = time / 1000000;
    microsec = (time % 1000000) / 1000;
    printf("add vport to bridge time: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);

    time = CALCULATE_TIME(add_vport_bridge_end_time, del_vport_bridge_end_time);
    seconds = time / 1000000;
    microsec = (time % 1000000) / 1000;
    printf("del vport of bridge time: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);

    time = CALCULATE_TIME(del_vport_bridge_end_time, vport_delete_end_time);
    seconds = time / 1000000;
    microsec = (time % 1000000) / 1000;
    printf("vport deletion time\t: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);

    time = CALCULATE_TIME(vport_delete_end_time, end_time);
    seconds = time / 1000000;
    microsec = (time % 1000000) / 1000;
    printf("bridge deletion: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);

    time = CALCULATE_TIME(start_time, end_time);
    seconds = time / 1000000;
    microsec = (time % 1000000) / 1000;
    printf("Total time: %u %s , %u.%u seconds \n", time, TIME_DIMENSION, seconds, microsec);

    printf("\nTest is finished.\n");

    if (status != SX_STATUS_SUCCESS) {
        exit(1);
    }

    /** Close SDK **/
    status = sx_api_close(&api_handle);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_close failed: [%s]\n", sx_status_str(status));
        exit(1);
    }

    return 0;
}
