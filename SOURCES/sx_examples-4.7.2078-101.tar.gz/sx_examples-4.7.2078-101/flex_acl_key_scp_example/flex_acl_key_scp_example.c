/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <stdio.h>
#include <sx/sdk/sx_api_flex_acl.h>

#include "flex_acl_gen_def.h"
#include "flex_acl_keys_scp.h"


int main(int argc, char *argv[])
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_acl_key_t       acl_keys[] = {FLEX_ACL_KEY_SIPV6, FLEX_ACL_KEY_TTL, FLEX_ACL_KEY_DMAC};
    uint32_t           keys_count = sizeof(acl_keys) / sizeof(sx_acl_key_t);
    uint32_t           hw_key_cnt = 12;
    sx_acl_hw_key_e    hw_keys[hw_key_cnt];
    uint32_t           key_blocks_count = 12;
    sx_acl_key_block_e key_blocks[key_blocks_count];
    acl_stage_e        acl_stages[] = {ACL_STAGE_FLEX, ACL_STAGE_FLEX2, ACL_STAGE_FLEX3, ACL_STAGE_FLEX4};
    uint8_t            acl_stages_cnt = sizeof(acl_stages) / sizeof(acl_stage_e);
    uint8_t            i = 0;

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    for (i = 0; i < acl_stages_cnt; i++) {
        /* Initialize the SCP to work with the keys of this acl stage */
        sx_status = flex_acl_scp_init(acl_stages[i]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("Failed to init SCP; acl_stage %u\n", acl_stages[i]);
            exit(1);
        }

        /* Generate the HW keys corresponding with the SW keys */
        sx_status = flex_acl_get_hw_keys(acl_stages[i], acl_keys, keys_count, hw_keys, &hw_key_cnt);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("Failed to get HW keys; acl_stage %u\n", acl_stages[i]);
            exit(1);
        }

        printf("Generated %u HW keys; acl_stage %u\n", hw_key_cnt, acl_stages[i]);

        /* Generate the key blocks that can contain all the above keys */
        sx_status = flex_acl_scp_calc(acl_stages[i], hw_keys, hw_key_cnt, key_blocks, &key_blocks_count, FALSE, TRUE);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("Failed to get blocks that contain the specified keys; acl_stage %u\n", acl_stages[i]);
            exit(1);
        }

        printf("Generated %u key blocks; acl_stage %u\n", key_blocks_count, acl_stages[i]);
    }

    printf("Successfully finished\n");

    return 0;
}
