local NVIDIA_TAC_ETHER_TYPE = 0x8932
------- tacPAN disector
local nvidia_tac = Proto.new ("TAC", "NVIDIA TAC Header" )

local tac_cmd = {
	[1] = "flush all"
}

local tac_type = {
    [1] = "New TAC event",
    [2] = "Aggregated TAC event"
}

local type = {
	[3] = "TAC msg",
}

local evc = {
	[0] = "reported",
	[1] = "reported and evicted",
}

nvidia_tac.fields = {}
local tacflds = nvidia_tac.fields

tacflds.version = ProtoField.new("version", "nvidia_tac.version", ftypes.UINT8, nil, base.HEX,"0xF0")
tacflds.msg_type = ProtoField.new("msg_type", "nvidia_tac.msg_type", ftypes.UINT8, nil, base.HEX,"0x0F")
tacflds.msg_length = ProtoField.new("msg_length", "nvidia_tac.msg_length", ftypes.UINT8, nil, base.HEX,"0xFF")
--opt
tacflds.uid_lsb = ProtoField.new("uid_lsb", "nvidia_tac.uid_lsb", ftypes.UINT16, nil, base.DEC,"0xFFFF")
tacflds.uid_msb = ProtoField.new("uid_msb", "nvidia_tac.uid_msb", ftypes.UINT16, nil, base.DEC,"0xFFFF")
tacflds.max_lifetime = ProtoField.new("max_lifetime", "nvidia_tac.max_lifetime", ftypes.UINT16, nil, base.DEC,"0xFFFF")
tacflds.tac_cmd = ProtoField.new("tac_cmd", "nvidia_tac.tac_cmd", ftypes.UINT16, tac_cmd, base.DEC,"0xFFFF")

tacflds.type = ProtoField.new("type", "nvidia_tac.type", ftypes.UINT8, type, base.DEC,"0xF8")
tacflds.tac_type = ProtoField.new("tac_type", "nvidia_tac.type", ftypes.UINT8, tac_type, base.DEC,"0xF8")
tacflds.tac_ver = ProtoField.new("tac_ver", "nvidia_tac.tac_ver", ftypes.UINT8, nil, base.DEC,"0x0F")

-- tac header
tacflds.signature_high = ProtoField.new("signature_high", "nvidia_tac.signature_high", ftypes.UINT32, nil, base.HEX,"0xFFFFFFFF")
tacflds.signature_low = ProtoField.new("signature_low", "nvidia_tac.signature_low", ftypes.UINT32, nil, base.HEX,"0xFFFFFFFF")
tacflds.egress_buf_fill_level = ProtoField.new("egress_buf_fill_level", "nvidia_tac.egress_buf_fill_level", ftypes.UINT16, nil, base.DEC,"0xFFFF")
tacflds.timestamp = ProtoField.absolute_time("nvidia_tac.timestamp", "Timestamp", base.UTC)
tacflds.egress_port = ProtoField.new("egress port", "nvidia_tac.egress_port", ftypes.UINT16, nil, base.DEC,"0xFF80")
tacflds.egress_portv1 = ProtoField.new("egress port", "nvidia_tac.egress_port", ftypes.UINT16, nil, base.DEC,"0xFFC0")
tacflds.traffic_class = ProtoField.new("traffic class", "nvidia_tac.traffic_class", ftypes.UINT16, nil, base.DEC,"0x001F")
tacflds.mirror_reason = ProtoField.new("mirror_reason", "nvidia_tac.mirror_reason", ftypes.UINT8, nil, base.DEC,"0xFF")
tacflds.user_key = ProtoField.new("user_key", "nvidia_tac.user_key", ftypes.UINT8, nil, base.DEC,"0x1F")
tacflds.ts_type = ProtoField.new("ts_type", "nvidia_tac.ts_type", ftypes.UINT8, nil, base.DEC,"0x03")
tacflds.rdq = ProtoField.new("rdq", "nvidia_tac.rdq", ftypes.UINT8, nil, base.DEC,"0x3F")
tacflds.trap_id = ProtoField.new("trap_id", "nvidia_tac.trap_id", ftypes.UINT16, nil, base.DEC,"0x03FF")
tacflds.e2e_latency = ProtoField.new("e2e_latency", "nvidia_tac.e2e_latency", ftypes.UINT24, nil, base.DEC,"0x0FFFFFF")
tacflds.ele = ProtoField.new("ele", "nvidia_tac.ele", ftypes.UINT8, nil, base.DEC,"0xC0")
tacflds.pe2cqe_token = ProtoField.new("pe2cqe_token", "nvidia_tac.pe2cqe_token", ftypes.UINT8, nil, base.DEC,"0x1F")
tacflds.trap_cookie = ProtoField.new("trap_cookie", "nvidia_tac.trap_cookie", ftypes.UINT24, nil, base.DEC,"0x03FFFF")
tacflds.ingress_port = ProtoField.new("ingress port", "nvidia_tac.ingress_port", ftypes.UINT16, nil, base.DEC,"0xFF80")
tacflds.ingress_portv1 = ProtoField.new("ingress port", "nvidia_tac.ingress_port", ftypes.UINT16, nil, base.DEC,"0xFFC0")
tacflds.packet_length = ProtoField.new("packet_length", "nvidia_tac.packet_length", ftypes.UINT16, nil, base.DEC,"0xFFFF")

tacflds.packet_count = ProtoField.new("packet_count", "nvidia_tac.packet_count", ftypes.UINT32, nil, base.DEC,"0xFFFFFFFF")
tacflds.burst_score = ProtoField.new("burst_score", "nvidia_tac.burst_score", ftypes.UINT16, nil, base.DEC,"0x3FF")
tacflds.evc = ProtoField.new("evc", "nvidia_tac.evc", ftypes.UINT8, evc, base.DEC,"0x80")
tacflds.byte_count = ProtoField.new("byte_count", "nvidia_tac.byte_count", ftypes.UINT64, nil, base.DEC,"0xFFFFFFFFFF")

tacflds.port_label_map = ProtoField.string("nvidia_tac.port_label_mapping", "Port Label Mapping")
tacflds.tlv_type = ProtoField.string("nvidia_tac.tlv_type", "tlv_type")
tacflds.tlv_len = ProtoField.new("nvidia_tac.tlv_len", "tlv_len", ftypes.UINT8, nil, base.DEC,"0")

function nvidia_tac.dissector(tvbuf, pktinfo, root)
	local nxt_offset = 2
	local msg_length = 0
	local tac_type = 0
	local tac_ver = 0
	local msg_type = 0
    length = tvbuf:len()
    t_tac = root: add(nvidia_tac, tvbuf(), "Nvidia TAC")

    t_tac:add(tacflds.version, tvbuf(nxt_offset,1))
    msg_type = tvbuf(nxt_offset,1):uint() % 16
    t_tac:add(tacflds.msg_type, tvbuf(nxt_offset,1))    
    nxt_offset = nxt_offset + 1
    t_tac:add(tacflds.msg_length, tvbuf(nxt_offset,1))
    msg_length = tvbuf(nxt_offset,1): uint()
    nxt_offset = nxt_offset + 3
    
    -- msg_length is in 4Bytes units
    msg_length = msg_length*4
    local tlv_data_len = 0
    local total_tlv_len = 0
    if msg_length > 0 then
        repeat
            local type = tvbuf(nxt_offset,1): uint()
            if nxt_offset + 4 > length then
                print("nxt_offset: " .. nxt_offset .. "is too large")
                return
            end    
            nxt_offset = nxt_offset + 1
           
            --type 0xFF is used for padding only , it can be also single byte 
            if type == 0xFF then
               --there is no data for padding tlv so no need to extract the len 
               tlv_data_len = 0
               total_tlv_len = 1
           else 
               tlv_data_len = tvbuf(nxt_offset,1): uint()
               nxt_offset = nxt_offset + 1
               total_tlv_len = 2 + tlv_data_len
           end
           --t_tac:add(tacflds.tlv_len,tlv_data_len)          
           --t_tac:add(tacflds.debug,22)          

            -- tlv : TYPE 1 byte, LENGTH 1 byte , DATA of LENGTH bytes
            if type == 1 then
                t_tac:add(tacflds.uid_lsb, tvbuf(nxt_offset, tlv_data_len))
            elseif type == 2 then
                t_tac:add(tacflds.uid_msb, tvbuf(nxt_offset, tlv_data_len))
            elseif type == 3 then
                t_tac:add(tacflds.max_lifetime, tvbuf(nxt_offset, tlv_data_len))
            elseif type == 4 then
                -- cmd tlv
                t_tac:add(tacflds.tlv_type,"TAC CMD")
                t_tac:add(tacflds.tac_cmd, tvbuf(nxt_offset, tlv_data_len))
            elseif type == 5 then
                -- port label mapping tlv
                t_tac:add(tacflds.tlv_type,"TAC Port Label Mapping")
                port_label_tlv_len = tlv_data_len
                num_of_mappings = port_label_tlv_len/4
                -- we don't update nxt_offset here becasue it will be updated for the whole map array after that block
                -- all port_label_array map block offset calculation we will do in port_label_offset
                port_label_offset = nxt_offset+2
                for i = 1, num_of_mappings do
                --for i = 1,3 do
                  local_port = tvbuf(port_label_offset, 2):uint()
                  port_label_offset = port_label_offset + 2
                  label_port = tvbuf(port_label_offset, 2):uint()
                  port_label_offset = port_label_offset + 2
                  local port_label_map = string.format("local 0x%x, label 0x%x", local_port, label_port)                  
                  t_tac:add(tacflds.port_label_map, port_label_map)
                end
            elseif type > 0xbb or  type < 0xdd then
                 -- user defined tlv
                 t_tac:add(tacflds.tlv_type,"TAC User Defined TLV")
            end
            nxt_offset = nxt_offset + tlv_data_len
            msg_length = msg_length - total_tlv_len
        until (msg_length == 0 )
    end   

    --continue only if msg type isn't 1 (TAC SW header)
    --TAC OOB message (msg_type 2) doesn't have data to parse exept TLVs  
    if msg_type ~= 1 then
       return 
    end

    --tac header start
    t_tac:add(tacflds.type, tvbuf(nxt_offset,1))
    nxt_offset = nxt_offset + 4
    t_tac:add(tacflds.tac_type, tvbuf(nxt_offset,1))
    tac_type = tvbuf(nxt_offset,1): uint()
    tac_type = bit.rshift(tac_type,3) 
    nxt_offset = nxt_offset + 3

    t_tac:add(tacflds.tac_ver, tvbuf(nxt_offset,1))
    tac_ver = tvbuf(nxt_offset,1): uint()
    tac_ver = bit.rshift(tac_type,4)

    nxt_offset = nxt_offset + 1
    --tac header
    t_tac:add(tacflds.signature_high, tvbuf(nxt_offset,4))
    nxt_offset = nxt_offset + 4
    t_tac:add(tacflds.signature_low, tvbuf(nxt_offset,4))
    nxt_offset = nxt_offset + 4
    egress_buf_fill_level = tvbuf(nxt_offset,2):uint()
    if egress_buf_fill_level ~= 0xffff then
       t_tac:add(tacflds.egress_buf_fill_level, tvbuf(nxt_offset,2))
    end
    --reserved 2
    nxt_offset = nxt_offset + 2

    secs = tvbuf(nxt_offset,6): uint64()
    nsecs = tvbuf(nxt_offset+6,4): uint64()
    secs = secs:tonumber()
    nsecs = nsecs:tonumber()
    nstime = NSTime.new(secs,nsecs)
    t_tac:add(tacflds.timestamp, tvbuf(nxt_offset,10), nstime)
    nxt_offset = nxt_offset + 10

    local egress_port = tvbuf(nxt_offset,2): uint()
    if tac_ver == 0 then
        --9bits, its value: local_port - 1. All 1 means invalid egress port
        egress_port = bit.rshift(egress_port,7) + 1
        egress_port = bit.band(egress_port, 0x1ff)
        egress_port = bit.lshift(egress_port,7)
        print("egress_port: " .. egress_port)
        if egress_port ~= 0 then
            t_tac:add(tacflds.egress_port, egress_port)
        end
    elseif tac_ver == 1 then
        --10 bits
        egress_port = bit.rshift(egress_port,6) + 1
        egress_port = bit.band(egress_port, 0x3ff)
        egress_port = bit.lshift(egress_port,6)
        if egress_port ~= 0 then
            t_tac:add(tacflds.egress_portv1, egress_port)
        end
    end


    -- If the trap happens before traffic_class was assigned, the value of this field will be 0x1f.
    local traffic_class = tvbuf(nxt_offset,2): uint()
    traffic_class = bit.band(traffic_class, 0x1f)
    print("traffic_class: " .. traffic_class)

    if traffic_class ~= 0x1f then
        t_tac:add(tacflds.traffic_class, tvbuf(nxt_offset,2))
    end
    nxt_offset = nxt_offset + 2

    -- Mirror reason 0: Not-valid (used by for non-mirror packets arrived to TAC)
    local mirror_reason = tvbuf(nxt_offset,1):uint()
    if mirror_reason ~= 0 then
       t_tac:add(tacflds.mirror_reason, tvbuf(nxt_offset,1))
    end
    nxt_offset = nxt_offset + 1

    t_tac:add(tacflds.user_key, tvbuf(nxt_offset,1))
    nxt_offset = nxt_offset + 1
    t_tac:add(tacflds.ts_type, tvbuf(nxt_offset,1))
    nxt_offset = nxt_offset + 1
    t_tac:add(tacflds.rdq, tvbuf(nxt_offset,1))
    nxt_offset = nxt_offset + 1
    t_tac:add(tacflds.trap_id, tvbuf(nxt_offset,2))
    nxt_offset = nxt_offset + 2
    --t_tac:add(tacflds.e2e_latency, tvbuf(nxt_offset,4)) --not supported
    nxt_offset = nxt_offset + 4

    if tac_type == 1 then   -- new TAC event
        t_tac:add(tacflds.ele, tvbuf(nxt_offset,1))
        --t_tac:add(tacflds.pe2cqe_token, tvbuf(nxt_offset,1)) - reserved
        nxt_offset = nxt_offset + 1
        --t_tac:add(tacflds.trap_cookie, tvbuf(nxt_offset,3)) - reserved
        nxt_offset = nxt_offset + 3

        local ingress_port = tvbuf(nxt_offset,2): uint()
        if tac_ver == 0 then
            ingress_port = bit.rshift(ingress_port,7) + 1
            ingress_port = bit.lshift(ingress_port,7)
            -- print("ingress_port: " .. ingress_port)
            t_tac:add(tacflds.ingress_port, ingress_port)
        elseif tac_ver == 1 then
            ingress_port = bit.rshift(ingress_port,6) + 1
            ingress_port = bit.lshift(ingress_port,6)
            -- print("ingress_port v1: " .. ingress_port)
            t_tac:add(tacflds.ingress_portv1, ingress_port)
        end
        nxt_offset = nxt_offset + 2
        t_tac:add(tacflds.packet_length, tvbuf(nxt_offset,2))
        nxt_offset = nxt_offset + 2
        return Dissector.get('eth_withoutfcs'):call(tvbuf(nxt_offset):tvb(), pktinfo, root)
    elseif tac_type == 2 then -- aggregated TAC event
        t_tac:add(tacflds.packet_count, tvbuf(nxt_offset,4))
        nxt_offset = nxt_offset + 4
        t_tac:add(tacflds.burst_score, tvbuf(nxt_offset,2))
        nxt_offset = nxt_offset + 2
        t_tac:add(tacflds.evc, tvbuf(nxt_offset,1))
        nxt_offset = nxt_offset + 1
        t_tac:add(tacflds.byte_count, tvbuf(nxt_offset,5))
        nxt_offset = nxt_offset + 5
    end
end

DissectorTable.get("ethertype"):add(NVIDIA_TAC_ETHER_TYPE, nvidia_tac)

