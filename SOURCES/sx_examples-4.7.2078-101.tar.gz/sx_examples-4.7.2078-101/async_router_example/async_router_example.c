/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#include <stdio.h>
#include <time.h>
#include <arpa/inet.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_lib_host_ifc.h>
#include <sx/sdk/sx_api_rm.h>


/*
 * Example of Async Router add/delete operation.
 * The SDK needs to be started in Async mode for this test to run.
 */


/** Local macros **/
#define DEFAULT_SWID 0
#define DEFAULT_VLAN 1
#define DEFAULT_ETHER_ADDR                   \
    (sx_mac_addr_t) {                        \
        {0x00, 0x02, 0x03, 0x04, 0x05, 0x07} \
    }
#define DEFAULT_MTU 1522


boolean_t g_async_mode = TRUE;
boolean_t g_wait_events = TRUE;

#define SX_MEM_CLR(src) (memset(&(src), 0, sizeof(src)))

pthread_t                sx_ver_thread;
static sx_user_channel_t user_channel;
static sx_user_channel_t write_user_channel;

#define EVB_MAX_PACKET_SIZE (4 * 1024)

static sx_trap_id_t trap_ids[] = {SX_TRAP_ID_SIGNAL,
                                  SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT};
static uint32_t     trap_ids_count = sizeof(trap_ids) / sizeof(trap_ids[0]);


static sx_status_t __get_chip_type(sx_chip_types_t *chip_type_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mgir_reg mgir_reg;

    memset(&reg_meta, 0, sizeof(reg_meta));
    memset(&mgir_reg, 0, sizeof(mgir_reg));

    if (chip_type_p == NULL) {
        printf("ERROR: chip_type_p is NULL.\n");
        exit(1);
    }

    sxd_status = sxd_access_reg_init(0, NULL, SX_VERBOSITY_LEVEL_INFO);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        printf("ERROR: SXD API sxd_access_reg_init failed: [%s]\n", SXD_STATUS_MSG(sxd_status));
        exit(1);
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.dev_id = 1;
    memset(&mgir_reg, 0, sizeof(struct ku_mgir_reg));

    sxd_status = sxd_access_reg_mgir(&mgir_reg, &reg_meta, 1, NULL, NULL);
    if (sxd_status) {
        printf("%s: failed in get MGIR for dev_id %d, error: %d \n",
               __func__, 1, sxd_status);
    }

    switch (mgir_reg.hw_info.device_id) {
    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
        if (mgir_reg.hw_info.device_hw_revision == 0xA0) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM;
        } else if (mgir_reg.hw_info.device_hw_revision == 0xA1) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM_A1;
        } else {
            printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
            exit(1);
        }
        printf("Device type is: SPECTRUM.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM2;

        printf("Device type is: SPECTRUM2.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM3;

        printf("Device type is: SPECTRUM3.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM4;

        printf("Device type is: SPECTRUM4.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM5;

        printf("Device type is: SPECTRUM5.\n");
        break;


    default:
        printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
        exit(1);
    }

    return status;
}


void init_router_params(sx_router_general_param_t *general_params, sx_router_resources_param_t *router_resources)
{
    general_params->ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params->ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params->ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    general_params->async_mode_enable = g_async_mode;
    general_params->disable_l3_nh_list = TRUE;
    general_params->router_async_params.completion_info_send_interval = 1;
    general_params->router_async_params.completion_info_flush_count = 1;
    general_params->router_async_params.disable_flush_on_last_route = FALSE;
    router_resources->max_virtual_routers_num = 256;
    router_resources->max_router_interfaces = 1000;
    router_resources->min_ipv4_neighbor_entries = 0;
    router_resources->min_ipv6_neighbor_entries = 0;
    router_resources->min_ipv4_uc_route_entries = 0;
    router_resources->min_ipv6_uc_route_entries = 0;
    router_resources->min_ipv4_mc_route_entries = 0;
    router_resources->min_ipv6_mc_route_entries = 0;
    router_resources->max_ipv4_neighbor_entries = 0;
    router_resources->max_ipv6_neighbor_entries = 0;
    router_resources->max_ipv4_uc_route_entries = 0;
    router_resources->max_ipv6_uc_route_entries = 0;
    router_resources->max_ipv4_mc_route_entries = 0;
    router_resources->max_ipv6_mc_route_entries = 0;
    /* Init the short/long uc route types so we can use these instead of the min_ipv6_uc_route_entries type */
    router_resources->min_ipv6_short_uc_route_entries = 1;
    router_resources->min_ipv6_long_uc_route_entries = 1;
}

static sx_status_t __events_listener_wakeup()
{
    char        buffer[10];
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(buffer);

    err = sx_lib_host_ifc_loopback_ctrl_send(&write_user_channel.channel.fd,
                                             buffer,
                                             sizeof(buffer),
                                             DEFAULT_SWID,
                                             SX_TRAP_ID_SIGNAL,
                                             0x10001,
                                             FALSE,
                                             SX_INVALID_PORT);
    if (SX_CHECK_FAIL(err)) {
        printf("Failed to send SX_TRAP_ID_SIGNAL to stop the receive thread, err: %s\n",
               sx_status_str(err));
        goto out;
    }
out:
    return err;
}

/* This is an example of a thread that can listen to and read the Async completion trap*/
void sx_ver_recv_thread()
{
    sx_status_t                           status = SX_STATUS_SUCCESS;
    static int                            event_recv_cnt = 0;
    uint8_t                               packet[EVB_MAX_PACKET_SIZE] = {0};
    uint32_t                              packet_size = EVB_MAX_PACKET_SIZE;
    sx_receive_info_t                     receive_info;
    sx_async_api_complete_notification_t *async_notify_p = NULL;

    while (g_wait_events) {
        packet_size = sizeof(sx_async_api_complete_notification_t);     /* EVB_MAX_PACKET_SIZE; */
        memset(packet, 0, sizeof(packet));

        /* blocking on packet receive */
        status = sx_lib_host_ifc_recv(&user_channel.channel.fd, packet,
                                      &packet_size, &receive_info);
        if (SX_CHECK_FAIL(status)) {
            printf("Failed in sx_api_host_ifc_recv, error: %s.\n",
                   sx_status_str(status));
            goto out;
        }

        switch (receive_info.trap_id) {
        case SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT:
            async_notify_p = (sx_async_api_complete_notification_t*)packet;
            event_recv_cnt++;
            if (event_recv_cnt % 1000 == 0) {
                printf("Received User Cookie %" PRIu64 "\r",
                       async_notify_p->data.uc_route_set_data.user_cookie);
            }
            break;

        case SX_TRAP_ID_SIGNAL:
            printf("Received end signal, terminating\n");
            g_wait_events = FALSE;
            break;

        default:
            printf("Unsolicited event received with trap id [%u].\n",
                   receive_info.trap_id);
            break;
        }
    }


out:
    ;
}


sx_status_t scale_route_operation(sx_api_handle_t api_handle,  sx_chip_types_t chip_type)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    routes_counter = 0;
    uint32_t    async_routes_counter = 0;


    /** Router variables **/
    sx_router_general_param_t   general_params;
    sx_router_resources_param_t router_resources;

    SX_MEM_CLR(general_params);
    SX_MEM_CLR(router_resources);

    /** VR variables **/
    sx_router_attributes_t router_attr;
    sx_router_id_t         vrid = 0;

    SX_MEM_CLR(router_attr);

    /** RIF variables **/
    sx_router_interface_param_t ifc_param;
    sx_interface_attributes_t   ifc_attr;
    sx_router_interface_t       rif = 0;

    SX_MEM_CLR(ifc_param);
    SX_MEM_CLR(ifc_attr);

    /** Router variables **/
    sx_ip_addr_t       ip_addr;
    sx_ip_prefix_t     network_addr;
    sx_uc_route_data_t uc_route_data;

    SX_MEM_CLR(network_addr);
    SX_MEM_CLR(uc_route_data);
    SX_MEM_CLR(ip_addr);

    /** Ecmp variables **/
    sx_next_hop_t next_hop_v4_list[1];
    uint32_t      next_hop_v4_cnt = 0;
    sx_ecmp_id_t  ecmp_id_v4 = SX_ROUTER_ECMP_ID_INVALID;
    sx_next_hop_t next_hop_v6_list[1];
    uint32_t      next_hop_v6_cnt;
    sx_ecmp_id_t  ecmp_id_v6 = SX_ROUTER_ECMP_ID_INVALID;

    /** Time variables **/
    uint64_t        add_time_ipv4_routes = 0;
    uint64_t        del_time_ipv4_routes = 0;
    uint64_t        add_time_ipv6_short_routes = 0;
    uint64_t        del_time_ipv6_short_routes = 0;
    uint64_t        add_time_ipv6_long_routes = 0;
    uint64_t        del_time_ipv6_long_routes = 0;
    struct timespec tms_start;
    struct timespec tms_end;

    SX_MEM_CLR(tms_start);
    SX_MEM_CLR(tms_end);

    /* Completion attributes*/
    sx_router_req_completion_info_get_entry_t completion_info;
    sx_fd_t_attributes_t                      fd_attrs;
    sx_trap_group_attributes_t                trap_grp;
    sx_host_ifc_trap_key_t                    trap_key;
    sx_host_ifc_trap_attr_t                   trap_attr;
    uint32_t                                  trap_group = 1;
    uint32_t                                  i = 0;

    /* Resource estimates*/
    uint32_t num_ipv4 = 0;
    uint32_t num_ipv6_short = 0;
    uint32_t num_ipv4_to_add = 0;
    uint32_t num_ipv6_short_to_add = 0;
    uint32_t num_ipv6_long_added = 0;


    SX_MEM_CLR(trap_grp);
    SX_MEM_CLR(trap_key);
    SX_MEM_CLR(trap_attr);
    SX_MEM_CLR(completion_info);
    SX_MEM_CLR(next_hop_v4_list);
    SX_MEM_CLR(fd_attrs);

    sx_status = sx_api_host_ifc_open(api_handle, &user_channel.channel.fd);
    if (SX_CHECK_FAIL(sx_status)) {
        printf("Failed to open host ifc %s\n", sx_status_str(sx_status));
        exit(1);
    }

    fd_attrs.queue_type = SX_FD_QUEUE_TYPE_HEAD_DROP;
    sx_status = sx_lib_host_ifc_fd_attributes_set(&user_channel.channel.fd,
                                                  &fd_attrs);
    if (SX_CHECK_FAIL(sx_status)) {
        printf("Failed to set FD attributes %s\n", sx_status_str(sx_status));
        exit(1);
    }

    trap_grp.control_type = SX_CONTROL_TYPE_DEFAULT;
    trap_grp.prio = 1;
    trap_grp.truncate_mode = SX_TRUNCATE_MODE_DISABLE;
    trap_grp.truncate_size = 0;
    trap_grp.is_monitor = FALSE;
    sx_status = sx_api_host_ifc_trap_group_ext_set(api_handle, SX_ACCESS_CMD_SET, DEFAULT_SWID, trap_group, &trap_grp);
    if (SX_CHECK_FAIL(sx_status)) {
        printf("Failed to set Trap group with error: %s\n", sx_status_str(sx_status));
        exit(1);
    }

    user_channel.type = SX_USER_CHANNEL_TYPE_FD;

    write_user_channel.type = SX_USER_CHANNEL_TYPE_FD;
    sx_status = sx_api_host_ifc_open(api_handle, &write_user_channel.channel.fd);
    if (SX_CHECK_FAIL(sx_status)) {
        printf("Failed to open the write host ifc FD, sx_status: %s\n", sx_status_str(sx_status));
        goto out;
    }
    for (i = 0; i < trap_ids_count; i++) {
        SX_MEM_CLR(trap_key);
        SX_MEM_CLR(trap_attr);

        trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E;
        trap_key.trap_key_attr.trap_id = trap_ids[i];

        trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU;
        trap_attr.attr.trap_id_attr.trap_group = trap_group;

        sx_status = sx_api_host_ifc_trap_id_ext_set(api_handle, SX_ACCESS_CMD_SET, &trap_key, &trap_attr);
        if (SX_CHECK_FAIL(sx_status)) {
            printf("Failed to set trap ID %u, sx_status: %s\n", trap_ids[i], sx_status_str(sx_status));
            goto out;
        }
        sx_status = sx_api_host_ifc_trap_id_register_set(api_handle,
                                                         SX_ACCESS_CMD_REGISTER,
                                                         DEFAULT_SWID,
                                                         trap_ids[i],
                                                         &user_channel);
        if (SX_CHECK_FAIL(sx_status)) {
            printf("Failed to register trap ID %u, sx_status: %s\n", trap_ids[i], sx_status_str(sx_status));
            goto out;
        }
    }

    /** Init Router **/
    init_router_params(&general_params, &router_resources);

    sx_status = sx_api_router_init_set(api_handle, &general_params, &router_resources);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_init_set failed: [%d]\n", sx_status);
        goto out;
    }
    printf("SDK API: Router initialized\n");


    /** Creating VRID **/
    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    /* Router default action can be DROP/TRAP.
     *  If it is set to trap, then the SX_TRAP_ID_L3_UC_IP_BASE can be listened to trap
     *  lpm miss packets
     */
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP;
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP;

    sx_status = sx_api_router_set(api_handle, SX_ACCESS_CMD_ADD, &router_attr, &vrid);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
        goto router_rollback;
    }
    printf("SDK API: VRID [%d] has been added successfully. \n", vrid);

    /** Creating RIF **/
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN;
    ifc_param.ifc.vlan.swid = DEFAULT_SWID;
    ifc_param.ifc.vlan.vlan = DEFAULT_VLAN;

    ifc_attr.mac_addr = DEFAULT_ETHER_ADDR;
    ifc_attr.mtu = DEFAULT_MTU;
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP;
    ifc_attr.multicast_ttl_threshold = 0;
    ifc_attr.loopback_enable = 1;

    sx_status = sx_api_router_interface_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &ifc_param, &ifc_attr, &rif);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_interface_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
        goto vrid_rollback;
    }
    printf("SDK API: RIF [%d] has been added successfully. \n", rif);

    /* create thread which will listen to the Async completion Trap*/
    pthread_create(&sx_ver_thread, NULL, (void*)&sx_ver_recv_thread, NULL);

    /* Get an estimate of the number of routes possible to add */
    sx_status = sx_api_rm_free_entries_by_type_get(api_handle, RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E, &num_ipv4);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_rm_free_entries_by_type_get failed: [%d]\n", sx_status);
        goto rif_rollback;
    }

    /* Let us add half the possible v4 entries and reserve the rest of the KVD for v6 entries*/
    num_ipv4_to_add = num_ipv4 / 2;
    printf("\n Adding [%u] IPv4 UC ECMP routes... \n", num_ipv4_to_add);

    network_addr.version = SX_IP_VERSION_IPV4;
    network_addr.prefix.ipv4.addr.s_addr = 0x0a0a0a00; /* 10.10.10.10 */
    network_addr.prefix.ipv4.mask.s_addr = 0xffffff00; /* 255.255.255.0 */
    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP;
    memset(&next_hop_v4_list, 0, sizeof(next_hop_v4_list));

    next_hop_v4_list[0].next_hop_key.type = SX_NEXT_HOP_TYPE_IP;
    next_hop_v4_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.version = SX_IP_VERSION_IPV4;
    next_hop_v4_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv4.s_addr = 0x02030002;
    next_hop_v4_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.rif = rif;
    next_hop_v4_list[0].next_hop_data.weight = 1;
    next_hop_v4_list[0].next_hop_data.action = SX_ROUTER_ACTION_FORWARD;

    sx_status = sx_api_router_ecmp_set(api_handle,
                                       SX_ACCESS_CMD_CREATE,
                                       &ecmp_id_v4,
                                       next_hop_v4_list,
                                       &next_hop_v4_cnt);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_ecmp_set failed with cmd[SX_ACCESS_CMD_CREATE]: [%d]\n", sx_status);
        goto rif_rollback;
    }
    uc_route_data.uc_route_param.ecmp_id = ecmp_id_v4;

    while (SX_STATUS_SUCCESS == sx_status || SX_STATUS_ACCEPTED == sx_status) {
        uc_route_data.user_cookie = routes_counter + 1;
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);


        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ACCEPTED != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
            break;
        }
        if ((SX_STATUS_SUCCESS == sx_status) || (SX_STATUS_ACCEPTED == sx_status)) {
            routes_counter++;
            network_addr.prefix.ipv4.addr.s_addr += 0x100;
            if (routes_counter % 100 == 0) {
                printf("Added route number :%d\r", routes_counter);
            }
            if (SX_STATUS_ACCEPTED == sx_status) {
                async_routes_counter++;
                add_time_ipv4_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                        (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
            }
        }

        /* Break if limit reached */
        if (routes_counter >= num_ipv4_to_add) {
            break;
        }
    }

    if (async_routes_counter != 0) {
        printf(
            " %u of %u IPv4 UC ECMP routes have created asynchronously in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
            async_routes_counter,
            routes_counter,
            (add_time_ipv4_routes / 1000),
            (add_time_ipv4_routes / async_routes_counter));
    } else {
        printf(
            " %u IPv4 UC ECMP routes have successfully been created\n",
            routes_counter);
    }


    sx_status = sx_api_router_req_completion_info_get(api_handle,
                                                      &completion_info);
    if ((SX_STATUS_SUCCESS != sx_status)) {
        printf("ERROR: SDK API sx_api_router_req_completion_info_get failed with  [%d]\n",
               sx_status);
    }

    printf("Last completed operation cookie: %" PRIu64 "\n", completion_info.uc_route_info.user_cookie);

    /*Add IPv6 short entries */
    sx_status = sx_api_rm_free_entries_by_type_get(api_handle, RM_SDK_TABLE_TYPE_FIB_IPV6_SHORT_UC_E, &num_ipv6_short);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_rm_free_entries_by_type_get failed: [%d]\n", sx_status);
        goto rif_rollback;
    }

    /* Spectrum 1 uses a separate table for IPv6 long resources so we can use all the leftover space.
     *  For others, leave some space for long entries */
    if ((chip_type == SX_CHIP_TYPE_SPECTRUM) || (chip_type == SX_CHIP_TYPE_SPECTRUM_A1)) {
        num_ipv6_short_to_add = num_ipv6_short;
    } else {
        num_ipv6_short_to_add = num_ipv6_short / 2;
    }

    printf("\n Adding [%u] IPv6 UC Short ECMP routes... \n", num_ipv6_short_to_add);

    routes_counter = 0;
    async_routes_counter = 0;

    network_addr.version = SX_IP_VERSION_IPV6;

    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[3] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[2] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] = 0x01020000;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[0] = 0x02010101;

    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[3] = 0x0;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[2] = 0x0;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[1] = 0xffffffff;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[0] = 0xffffffff;

    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP;

    next_hop_v6_list[0].next_hop_key.type = SX_NEXT_HOP_TYPE_IP;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.version = SX_IP_VERSION_IPV6;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv6.__in6_u.__u6_addr32[3] =
        0x1234;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv6.__in6_u.__u6_addr32[2] =
        0x1234;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv6.__in6_u.__u6_addr32[1] =
        0x1234;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.address.addr.ipv6.__in6_u.__u6_addr32[0] =
        0x02008099;
    next_hop_v6_list[0].next_hop_key.next_hop_key_entry.ip_next_hop.rif = rif;

    next_hop_v6_list[0].next_hop_data.weight = 4;
    next_hop_v6_list[0].next_hop_data.action = SX_ROUTER_ACTION_FORWARD;

    sx_status = sx_api_router_ecmp_set(api_handle,
                                       SX_ACCESS_CMD_CREATE,
                                       &ecmp_id_v6,
                                       next_hop_v6_list,
                                       &next_hop_v6_cnt);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_ecmp_set failed with cmd[SX_ACCESS_CMD_CREATE]: [%d]\n", sx_status);
        goto ecmp_rollback;
    }
    uc_route_data.uc_route_param.ecmp_id = ecmp_id_v6;

    while (SX_STATUS_SUCCESS == sx_status || SX_STATUS_ACCEPTED == sx_status) {
        uc_route_data.user_cookie = routes_counter + 1;
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);


        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ACCEPTED != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
            break;
        }
        if ((SX_STATUS_SUCCESS == sx_status) || (SX_STATUS_ACCEPTED == sx_status)) {
            routes_counter++;
            network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] += 0x100;

            if (routes_counter % 100 == 0) {
                printf("Added route number :%d\r", routes_counter);
            }
            if (SX_STATUS_ACCEPTED == sx_status) {
                async_routes_counter++;
                add_time_ipv6_short_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                              (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
            }
        }

        /* Break if limit reached */
        if (routes_counter >= num_ipv6_short_to_add) {
            break;
        }
    }

    if (async_routes_counter != 0) {
        printf(
            " %u of %u IPv6 UC ECMP short routes have been created asynchronously %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
            async_routes_counter,
            routes_counter,
            (add_time_ipv6_short_routes / 1000),
            (add_time_ipv6_short_routes / async_routes_counter));
    } else {
        printf(
            " %u IPv6 UC ECMP short routes have successfully been created\n",
            routes_counter);
    }


    sx_status = sx_api_router_req_completion_info_get(api_handle,
                                                      &completion_info);
    if ((SX_STATUS_SUCCESS != sx_status)) {
        printf("ERROR: SDK API sx_api_router_req_completion_info_get failed with  [%d]\n",
               sx_status);
    }

    printf("Last completed operation cookie: %" PRIu64 "\n", completion_info.uc_route_info.user_cookie);


    printf("\n Adding IPv6 UC Long Local routes... \n");
    routes_counter = 0;
    async_routes_counter = 0;

    network_addr.version = SX_IP_VERSION_IPV6;

    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[3] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[2] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] = 0x01020000;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[0] = 0x02010101;

    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[3] = 0xffffff00;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[2] = 0xffffffff;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[1] = 0xffffffff;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[0] = 0xffffffff;

    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL;
    uc_route_data.uc_route_param.local_egress_rif = rif;

    while (SX_STATUS_SUCCESS == sx_status || SX_STATUS_ACCEPTED == sx_status) {
        uc_route_data.user_cookie = routes_counter + 1;
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);


        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ACCEPTED != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_ADD]: [%d]\n", sx_status);
            break;
        }
        if ((SX_STATUS_SUCCESS == sx_status) || (SX_STATUS_ACCEPTED == sx_status)) {
            routes_counter++;
            network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] += 0x100;

            if (routes_counter % 100 == 0) {
                printf("Added route number :%d\r", routes_counter);
            }
            if (SX_STATUS_ACCEPTED == sx_status) {
                async_routes_counter++;
                add_time_ipv6_long_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                             (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
            }
        }
    }

    if (async_routes_counter != 0) {
        printf(
            " %u of %u IPv6 UC local long routes have created asynchronously in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
            async_routes_counter,
            routes_counter,
            (add_time_ipv6_long_routes / 1000),
            (add_time_ipv6_long_routes / async_routes_counter));
    } else {
        printf(
            " %u IPv6 UC local long routes have successfully been created\n",
            routes_counter);
    }

    num_ipv6_long_added = routes_counter;

    sx_status = sx_api_router_req_completion_info_get(api_handle,
                                                      &completion_info);
    if ((SX_STATUS_SUCCESS != sx_status)) {
        printf("ERROR: SDK API sx_api_router_req_completion_info_get failed with  [%d]\n",
               sx_status);
    }

    printf("Last completed operation cookie: %" PRIu64 "\n", completion_info.uc_route_info.user_cookie);

    /** Deleting all IPv4 UC ECMP routes **/
    printf("\n Deleting %d IPv4 UC ECMP routes... \n", num_ipv4_to_add);
    routes_counter = 0;
    async_routes_counter = 0;
    sx_status = SX_STATUS_SUCCESS;
    network_addr.version = SX_IP_VERSION_IPV4;
    network_addr.prefix.ipv4.addr.s_addr = 0x0a0a0a00; /* 10.10.10.10 */
    network_addr.prefix.ipv4.mask.s_addr = 0xffffff00; /* 255.255.255.0 */
    uc_route_data.uc_route_param.ecmp_id = ecmp_id_v4;
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP;

    while (SX_STATUS_SUCCESS == sx_status || SX_STATUS_ACCEPTED == sx_status) {
        uc_route_data.user_cookie = routes_counter + 1;
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);


        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ACCEPTED != sx_status) &&
            (SX_STATUS_ENTRY_NOT_FOUND != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n",
                   sx_status);
            break;
        }

        if ((SX_STATUS_SUCCESS == sx_status) || (SX_STATUS_ACCEPTED == sx_status)) {
            routes_counter++;
            network_addr.prefix.ipv4.addr.s_addr += 0x100;
            if (routes_counter % 100 == 0) {
                printf("Deleted route number :%d\r", routes_counter);
            }
            if (SX_STATUS_ACCEPTED == sx_status) {
                async_routes_counter++;
                del_time_ipv4_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                        (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
            }
        }

        if (SX_STATUS_ENTRY_NOT_FOUND == sx_status) {
            break;
        }
    }
    if (async_routes_counter != 0) {
        printf(
            " %u IPv4 UC ECMP routes have successfully been deleted in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
            async_routes_counter,
            (del_time_ipv4_routes / 1000),
            (del_time_ipv4_routes / async_routes_counter));
    } else {
        printf(
            " %u IPv4 UC ECMP routes have successfully been deleted\n",
            routes_counter);
    }


    /** Deleting all IPv6 UC ECMP routes **/
    printf("\n Deleting %d IPv6 UC ECMP routes... \n", num_ipv6_short_to_add);
    routes_counter = 0;
    async_routes_counter = 0;
    sx_status = SX_STATUS_SUCCESS;
    network_addr.version = SX_IP_VERSION_IPV6;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[3] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[2] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] = 0x01020000;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[0] = 0x02010101;

    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[3] = 0x0;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[2] = 0x0;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[1] = 0xffffffff;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[0] = 0xffffffff;
    uc_route_data.uc_route_param.ecmp_id = ecmp_id_v6;
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP;


    while (SX_STATUS_SUCCESS == sx_status || SX_STATUS_ACCEPTED == sx_status) {
        uc_route_data.user_cookie = routes_counter + 1;
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);


        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ACCEPTED != sx_status) &&
            (SX_STATUS_ENTRY_NOT_FOUND != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n",
                   sx_status);
            break;
        }

        if ((SX_STATUS_SUCCESS == sx_status) || (SX_STATUS_ACCEPTED == sx_status)) {
            routes_counter++;
            network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] += 0x100;
            if (routes_counter % 100 == 0) {
                printf("Deleted route number :%d\r", routes_counter);
            }
            if (SX_STATUS_ACCEPTED == sx_status) {
                async_routes_counter++;
                del_time_ipv6_short_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                              (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
            }
        }

        if (SX_STATUS_ENTRY_NOT_FOUND == sx_status) {
            break;
        }
    }
    if (async_routes_counter != 0) {
        printf(
            " %u IPv6 UC ECMP routes have successfully been deleted in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
            async_routes_counter,
            (del_time_ipv6_short_routes / 1000),
            (del_time_ipv6_short_routes / async_routes_counter));
    } else {
        printf(
            " %u IPv6 UC ECMP routes have successfully been deleted\n",
            routes_counter);
    }

    /** Deleting all IPv6 long UC local routes **/
    printf("\n Deleting [%u] IPv6 long local routes... \n", num_ipv6_long_added);
    routes_counter = 0;
    async_routes_counter = 0;
    sx_status = SX_STATUS_SUCCESS;
    network_addr.version = SX_IP_VERSION_IPV6;

    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[3] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[2] = 0x0;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] = 0x01020000;
    network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[0] = 0x02010101;

    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[3] = 0xffffff00;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[2] = 0xffffffff;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[1] = 0xffffffff;
    network_addr.prefix.ipv6.mask.__in6_u.__u6_addr32[0] = 0xffffffff;
    uc_route_data.type = SX_UC_ROUTE_TYPE_LOCAL;
    uc_route_data.uc_route_param.local_egress_rif = rif;


    while (SX_STATUS_SUCCESS == sx_status || SX_STATUS_ACCEPTED == sx_status) {
        uc_route_data.user_cookie = routes_counter + 1;
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, &network_addr, &uc_route_data);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);


        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_ACCEPTED != sx_status) &&
            (SX_STATUS_ENTRY_NOT_FOUND != sx_status)) {
            printf("ERROR: SDK API sx_api_router_uc_route_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n",
                   sx_status);
            break;
        }

        if ((SX_STATUS_SUCCESS == sx_status) || (SX_STATUS_ACCEPTED == sx_status)) {
            routes_counter++;
            network_addr.prefix.ipv6.addr.__in6_u.__u6_addr32[1] += 0x100;
            if (routes_counter % 100 == 0) {
                printf("Deleted route number :%d\r", routes_counter);
            }
            if (SX_STATUS_ACCEPTED == sx_status) {
                async_routes_counter++;
                del_time_ipv6_long_routes += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                                             (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
            }
        }

        if (SX_STATUS_ENTRY_NOT_FOUND == sx_status) {
            break;
        }
    }
    if (async_routes_counter != 0) {
        printf(
            " %u IPv6 UC local routes have successfully been deleted in %" PRIu64 " ms, %" PRIu64 " us for one route. \n",
            async_routes_counter,
            (del_time_ipv6_long_routes / 1000),
            (del_time_ipv6_long_routes / async_routes_counter));
    } else {
        printf(
            " %u IPv6 UC long routes have successfully been deleted\n",
            routes_counter);
    }


    /* This loop ensures that all the routes have been deleted from HW before we start freeing
     *  router resources */
    do {
        usleep(600);

        sx_status = sx_api_router_req_completion_info_get(api_handle,
                                                          &completion_info);
        if ((SX_STATUS_SUCCESS != sx_status)) {
            printf("ERROR: SDK API sx_api_router_req_completion_info_get failed with  [%d]\n",
                   sx_status);
        }

        printf("Last completed operation cookie: %" PRIu64 "\n", completion_info.uc_route_info.user_cookie);
    }while (completion_info.uc_route_info.user_cookie != num_ipv6_long_added);

    printf("\nFree resources...\n");

ecmp_rollback:
    if (ecmp_id_v4 != SX_ROUTER_ECMP_ID_INVALID) {
        sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_DESTROY, &ecmp_id_v4, NULL, &next_hop_v4_cnt);
    }
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_ecmp_set failed with cmd[SX_ACCESS_CMD_DESTROY]: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: ECMP IPv4 has been deleted successfully. \n");

    if (ecmp_id_v6 != SX_ROUTER_ECMP_ID_INVALID) {
        sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_DESTROY, &ecmp_id_v6, NULL, &next_hop_v6_cnt);
    }
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_ecmp_set failed with cmd[SX_ACCESS_CMD_DESTROY]: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: ECMP IPv6 has been deleted successfully. \n");


rif_rollback:
    /** Deleting RIF **/
    sx_status = sx_api_router_interface_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, NULL, NULL, &rif);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_interface_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: RIF [%d] has been deleted successfully. \n", rif);

vrid_rollback:
    /** Deleting VRID **/
    sx_status = sx_api_router_set(api_handle, SX_ACCESS_CMD_DELETE, NULL, &vrid);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_router_set failed with cmd[SX_ACCESS_CMD_DELETE]: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: VRID [%d] has been deleted successfully. \n", vrid);

router_rollback:
    /** Router deinit **/
    sx_status = sx_api_router_deinit_set(api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: Failed to perform router deinit\n");
        exit(1);
    }

    printf("SDK API: Router deinit has been performed successfully\n");


    g_wait_events = FALSE;

    /* Wake up listener thread so it can exit*/
    __events_listener_wakeup();
    pthread_join(sx_ver_thread, NULL);

    /* Free configured traps*/
    for (i = 0; i < trap_ids_count; i++) {
        SX_MEM_CLR(trap_key);
        SX_MEM_CLR(trap_attr);

        trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E;
        trap_key.trap_key_attr.trap_id = trap_ids[i];

        trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_IGNORE;
        trap_attr.attr.trap_id_attr.trap_group = trap_group;

        sx_status = sx_api_host_ifc_trap_id_ext_set(api_handle, SX_ACCESS_CMD_UNSET, &trap_key, &trap_attr);
        if (SX_CHECK_FAIL(sx_status)) {
            printf("Failed to unset trap ID %u, sx_status: %s\n", trap_ids[i], sx_status_str(sx_status));
            goto out;
        }

        sx_status = sx_api_host_ifc_trap_id_register_set(api_handle,
                                                         SX_ACCESS_CMD_DEREGISTER,
                                                         DEFAULT_SWID,
                                                         trap_ids[i],
                                                         &user_channel);
        if (SX_CHECK_FAIL(sx_status)) {
            printf("Failed to register trap ID %u, sx_status: %s\n", trap_ids[i], sx_status_str(sx_status));
            goto out;
        }
    }

    sx_status =
        sx_api_host_ifc_trap_group_ext_set(api_handle, SX_ACCESS_CMD_UNSET, DEFAULT_SWID, trap_group, &trap_grp);
    if (SX_CHECK_FAIL(sx_status)) {
        printf("Failed to set Trap group with error: %s\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_host_ifc_close(api_handle, &user_channel.channel.fd);
    if (SX_CHECK_FAIL(sx_status)) {
        printf("Failed to close host ifc %s\n", sx_status_str(sx_status));
        exit(1);
    }


    sx_status = sx_api_host_ifc_close(api_handle, &write_user_channel.channel.fd);
    if (SX_CHECK_FAIL(sx_status)) {
        printf("Failed to close host ifc %s\n", sx_status_str(sx_status));
        exit(1);
    }


out:
    return sx_status;
}

int main(int argc, char **argv)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_api_handle_t      api_handle = 0;
    sx_api_sx_sdk_init_t sdk_init_params;
    sx_chip_types_t      chip_type = SX_CHIP_TYPE_UNKNOWN;

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    if (SX_STATUS_SUCCESS != __get_chip_type(&chip_type)) {
        printf("ERROR: Failed to determine the current chip type.\n");
        exit(1);
    }

    /** Open SDK **/
    sx_status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_open failed: [%d]\n", sx_status);
        exit(1);
    }

    sx_status = sx_api_sdk_init_params_get(api_handle, &sdk_init_params);
    if (sdk_init_params.async_params.enabled != TRUE) {
        printf("ERROR: This example is only valid when SDK Async mode is enabled\n");
        exit(1);
    }

    printf("\nSDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);
    printf("\n*****************************************************************");
    scale_route_operation(api_handle, chip_type);

    /** Close SDK **/
    sx_status = sx_api_close(&api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_close failed: [%d]\n", sx_status);
        exit(1);
    }
    printf("SDK API: Close API handle: 0x%" PRIx64 "\n", api_handle);


    printf("\nEnd.\n");
    return 0;
}
