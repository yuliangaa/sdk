/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sys/time.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_policer.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_lag.h>
#include <sx/sxd/sxd_access_register.h>
#include <resource_manager/resource_manager.h>

struct timeval start_time, end_time;

#define MEASURE_TIME(val) gettimeofday(val, NULL)
#define TIME_DIMENSION "micro seconds"
#define DISPLAY_RESULTS(start_time, end_time)                                                                           \
    printf("Total time: %u %s \n",                                                                                      \
           (unsigned int)(((end_time.tv_sec - start_time.tv_sec) * 1000000) + (end_time.tv_usec - start_time.tv_usec)), \
           TIME_DIMENSION);

#define SWID                             0
#define SX_POLICER_MAX_POLICERS_PER_PORT 5

static sx_policer_id_t __create_policer(sx_api_handle_t handle, boolean_t is_host_ifc_policer)
{
    sx_status_t             status = SX_STATUS_SUCCESS;
    sx_policer_id_t         policer_id = SX_POLICER_ID_INVALID;
    sx_policer_attributes_t policer_attr;

    memset(&policer_attr, 0, sizeof(policer_attr));

    policer_attr.meter_type = SX_POLICER_METER_TRAFFIC;
    policer_attr.cbs = 10;
    policer_attr.ebs = 10;
    policer_attr.cir = 1000;
    policer_attr.yellow_action = SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR;
    policer_attr.red_action = SX_POLICER_ACTION_DISCARD;
    policer_attr.eir = 1000;
    policer_attr.rate_type = SX_POLICER_RATE_TYPE_SINGLE_RATE_E;
    policer_attr.color_aware = 0;
    policer_attr.is_host_ifc_policer = is_host_ifc_policer;
    policer_attr.ir_units = SX_POLICER_IR_UNITS_10_POWER_6_E;

    status = sx_api_policer_set(handle, SX_ACCESS_CMD_CREATE, &policer_attr, &policer_id);
    if (status != SX_STATUS_SUCCESS) {
        printf("%s ERROR: SDK API sx_api_policer_set failed: [%s]\n", __func__, sx_status_str(status));
        assert(FALSE); /* stop execution */
    }

    return policer_id;
}

static void __get_policer(sx_api_handle_t handle, sx_policer_id_t policer_id)
{
    sx_status_t             status = SX_STATUS_SUCCESS;
    sx_policer_attributes_t policer_attr;

    memset(&policer_attr, 0, sizeof(policer_attr));

    status = sx_api_policer_get(handle, policer_id, &policer_attr);
    if (status != SX_STATUS_SUCCESS) {
        printf("%s ERROR: SDK API sx_api_policer_get failed: [%s]\n", __func__, sx_status_str(status));
        assert(FALSE); /* stop execution */
    }
}

static void __delete_policer(sx_api_handle_t handle, sx_policer_id_t policer_id)
{
    sx_status_t             status = SX_STATUS_SUCCESS;
    sx_policer_attributes_t policer_attr;

    memset(&policer_attr, 0, sizeof(policer_attr));

    status = sx_api_policer_set(handle, SX_ACCESS_CMD_DESTROY, &policer_attr, &policer_id);
    if (status != SX_STATUS_SUCCESS) {
        printf("%s ERROR: SDK API sx_api_policer_set failed: [%s]\n", __func__, sx_status_str(status));
        assert(FALSE); /* stop execution */
    }
}

void __create_storm_control_policer(sx_api_handle_t            handle,
                                    sx_port_log_id_t           log_port,
                                    sx_port_storm_control_id_t storm_control_id,
                                    boolean_t                  is_host_ifc_policer)
{
    sx_status_t                    status = SX_STATUS_SUCCESS;
    sx_port_storm_control_params_t storm_control_params;

    memset(&storm_control_params, 0, sizeof(storm_control_params));

    storm_control_params.packet_types.uc = FALSE;
    storm_control_params.packet_types.mc = FALSE;
    storm_control_params.packet_types.bc = FALSE;
    storm_control_params.packet_types.uuc = FALSE;
    storm_control_params.packet_types.umc = FALSE;

    switch (storm_control_id) {
    case 1:
        storm_control_params.packet_types.uc = TRUE;
        break;

    case 2:
        storm_control_params.packet_types.mc = TRUE;
        break;

    case 3:
        storm_control_params.packet_types.bc = TRUE;
        break;

    case 4:
        storm_control_params.packet_types.uuc = TRUE;
        break;

    default:
        storm_control_params.packet_types.umc = TRUE;
    }

    storm_control_params.policer_params.meter_type = SX_POLICER_METER_PACKETS;
    storm_control_params.policer_params.cbs = 10;
    storm_control_params.policer_params.ebs = 10;
    storm_control_params.policer_params.cir = 1000;
    storm_control_params.policer_params.yellow_action = SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR;
    storm_control_params.policer_params.red_action = SX_POLICER_ACTION_DISCARD;
    storm_control_params.policer_params.eir = 1000;
    storm_control_params.policer_params.rate_type = SX_POLICER_RATE_TYPE_SINGLE_RATE_E;
    storm_control_params.policer_params.color_aware = is_host_ifc_policer;
    storm_control_params.policer_params.is_host_ifc_policer = FALSE;
    storm_control_params.policer_params.ir_units = SX_POLICER_IR_UNITS_10_POWER_3_E;

    status =
        sx_api_port_storm_control_set(handle, SX_ACCESS_CMD_ADD, log_port, storm_control_id, &storm_control_params);
    if (status != SX_STATUS_SUCCESS) {
        printf("%s ERROR: SDK API sx_api_policer_set failed: [%s] \n", __func__, sx_status_str(status));
        assert(FALSE); /* stop execution */
    }
}

static void __get_storm_control_policer(sx_api_handle_t            handle,
                                        sx_port_log_id_t           log_port,
                                        sx_port_storm_control_id_t storm_control_id)
{
    sx_status_t                    status = SX_STATUS_SUCCESS;
    sx_port_storm_control_params_t storm_control_params;

    memset(&storm_control_params, 0, sizeof(storm_control_params));

    status = sx_api_port_storm_control_get(handle, log_port, storm_control_id, &storm_control_params);
    if (status != SX_STATUS_SUCCESS) {
        printf("%s ERROR: SDK API sx_api_policer_get failed: [%s]\n", __func__, sx_status_str(status));
        assert(FALSE); /* stop execution */
    }
}

static void __delete_storm_control_policer(sx_api_handle_t            handle,
                                           sx_port_log_id_t           log_port,
                                           sx_port_storm_control_id_t storm_control_id)
{
    sx_status_t                    status = SX_STATUS_SUCCESS;
    sx_port_storm_control_params_t storm_control_params;

    memset(&storm_control_params, 0, sizeof(storm_control_params));

    status = sx_api_port_storm_control_set(handle,
                                           SX_ACCESS_CMD_DELETE,
                                           log_port,
                                           storm_control_id,
                                           &storm_control_params);
    if (status != SX_STATUS_SUCCESS) {
        printf("%s ERROR: SDK API sx_api_policer_set failed: [%s]\n", __func__, sx_status_str(status));
        assert(FALSE); /* stop execution */
    }
}


static sx_status_t __get_chip_type(sx_chip_types_t *chip_type_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mgir_reg mgir_reg;

    memset(&reg_meta, 0, sizeof(reg_meta));
    memset(&mgir_reg, 0, sizeof(mgir_reg));

    if (chip_type_p == NULL) {
        printf("ERROR: chip_type_p is NULL.\n");
        exit(1);
    }

    sxd_status = sxd_access_reg_init(0, NULL, SX_VERBOSITY_LEVEL_INFO);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        printf("ERROR: SXD API sxd_access_reg_init failed: [%s]\n", SXD_STATUS_MSG(sxd_status));
        exit(1);
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.dev_id = 1;
    memset(&mgir_reg, 0, sizeof(struct ku_mgir_reg));

    sxd_status = sxd_access_reg_mgir(&mgir_reg, &reg_meta, 1, NULL, NULL);
    if (sxd_status) {
        printf("%s: failed in get MGIR for dev_id %d, error: %d \n",
               __func__, 1, sxd_status);
    }

    switch (mgir_reg.hw_info.device_id) {
    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
        if (mgir_reg.hw_info.device_hw_revision == 0xA0) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM;
        } else if (mgir_reg.hw_info.device_hw_revision == 0xA1) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM_A1;
        } else {
            printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
            exit(1);
        }
        printf("Device type is: SPECTRUM.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM2;

        printf("Device type is: SPECTRUM2.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM3;

        printf("Device type is: SPECTRUM3.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM4;

        printf("Device type is: SPECTRUM4.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM5;

        printf("Device type is: SPECTRUM5.\n");
        break;

    default:
        printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
        exit(1);
    }

    return status;
}

int main(int argc, char **argv)
{
    sx_api_handle_t   api_handle = 0;
    sx_status_t       status = SX_STATUS_SUCCESS;
    rm_resources_t    resource_limits;
    sx_chip_types_t   chip_type = SX_CHIP_TYPE_UNKNOWN;
    sx_policer_id_t  *policer_id_p = NULL;
    uint32_t          port_num = 0, i = 0;
    sx_port_log_id_t *lags = NULL;
    boolean_t         is_host_ifc_policer = FALSE;
    uint32_t          needed_num_ports = 0;

    memset(&resource_limits, 0, sizeof(rm_resources_t));

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    if (SX_STATUS_SUCCESS != __get_chip_type(&chip_type)) {
        printf("ERROR: Failed to determine the current chip type.\n");
        exit(1);
    }

    /* Open SDK */
    status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(status));
        exit(1);
    }
    printf("SDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);

    status = rm_chip_limits_get(chip_type, &resource_limits);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API rm_chip_limits_get failed: [%s]\n", sx_status_str(status));
        exit(1);
    }

    /*
     *  Case 1.1. Let's check global policer type
     */
    printf("\nCase 1.1. Measure how many %s will take creating of %u global policers.\n",
           TIME_DIMENSION,
           resource_limits.policer_pool_size);
    is_host_ifc_policer = FALSE;
    policer_id_p = (sx_policer_id_t*)calloc(resource_limits.policer_pool_size, sizeof(sx_policer_id_t));

    MEASURE_TIME(&start_time);
    for (i = 0; i < resource_limits.policer_pool_size; i++) {
        policer_id_p[i] = __create_policer(api_handle, is_host_ifc_policer);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Case 1.2. Let's get attributes for global policer type
     */
    printf("\nCase 1.2. Measure how many %s will take reading data for %u global policers.\n",
           TIME_DIMENSION,
           resource_limits.policer_pool_size);
    MEASURE_TIME(&start_time);
    for (i = 0; i < resource_limits.policer_pool_size; i++) {
        __get_policer(api_handle, policer_id_p[i]);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Case 1.3. Let's delete all global policers
     */
    printf("\nCase 1.3. Measure how many %s will take destroying of %u global policers.\n",
           TIME_DIMENSION,
           resource_limits.policer_pool_size);

    MEASURE_TIME(&start_time);
    for (i = 0; i < resource_limits.policer_pool_size; i++) {
        __delete_policer(api_handle, policer_id_p[i]);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    free(policer_id_p);

    /*
     *  Case 2.1. Let's check host interface policer type
     */
    printf("\nCase 2.1. Measure how many %s will take creating of %u host interface policers.\n",
           TIME_DIMENSION,
           resource_limits.policer_host_ifc_pool_size);
    is_host_ifc_policer = TRUE;
    policer_id_p = (sx_policer_id_t*)calloc(resource_limits.policer_host_ifc_pool_size, sizeof(sx_policer_id_t));

    MEASURE_TIME(&start_time);
    for (i = 0; i < resource_limits.policer_host_ifc_pool_size; i++) {
        policer_id_p[i] = __create_policer(api_handle, is_host_ifc_policer);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Case 2.2. Let's get attributes for host interface policer type
     */
    printf("\nCase 2.2. Measure how many %s will take reading data for %u host interface policers.\n",
           TIME_DIMENSION,
           resource_limits.policer_host_ifc_pool_size);
    MEASURE_TIME(&start_time);
    for (i = 0; i < resource_limits.policer_host_ifc_pool_size; i++) {
        __get_policer(api_handle, policer_id_p[i]);
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Case 2.3. Let's delete all host interface policers
     */
    printf("\nCase 2.3. Measure how many %s will take destroying of %u host interface policers.\n",
           TIME_DIMENSION,
           resource_limits.policer_host_ifc_pool_size);

    MEASURE_TIME(&start_time);
    for (i = 0; i < resource_limits.policer_host_ifc_pool_size; i++) {
        __delete_policer(api_handle, policer_id_p[i]);
    }

    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    free(policer_id_p);

    /*
     *  Check Storm Control policers.
     *  Prepare for relevant testing.
     */

    lags = (sx_port_log_id_t*)calloc(resource_limits.lag_num_max, sizeof(sx_port_log_id_t));

    /* let's create all required LAGs */
    for (i = 0; i < resource_limits.lag_num_max; i++) {
        status = sx_api_lag_port_group_set(api_handle, SX_ACCESS_CMD_CREATE, SWID, &lags[i], NULL, 0);
        if (status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_lag_port_group_set failed rc: [%s]\n", sx_status_str(status));
            assert(FALSE);
        }
    }

    /*
     *  Case 3.1. Let's check storm control policer type
     */

    /* calculate number of ports that needed to max storm policers */
    if (resource_limits.lag_num_max * SX_POLICER_MAX_POLICERS_PER_PORT >
        resource_limits.policer_storm_control_pool_size) {
        needed_num_ports = resource_limits.policer_storm_control_pool_size / SX_POLICER_MAX_POLICERS_PER_PORT;
    } else {
        needed_num_ports = resource_limits.lag_num_max;
    }

    printf("\nCase 3.1. Measure how many %s will take creating of %u storm control policers (actually %u).\n",
           TIME_DIMENSION,
           resource_limits.policer_storm_control_pool_size,
           needed_num_ports * SX_POLICER_MAX_POLICERS_PER_PORT);

    MEASURE_TIME(&start_time);
    for (port_num = 0; port_num < needed_num_ports; port_num++) {
        for (i = 0; i < SX_POLICER_MAX_POLICERS_PER_PORT; i++) {
            __create_storm_control_policer(api_handle, lags[port_num], i, FALSE);
        }
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Case 3.2. Let's get attributes for storm control policer type
     */
    printf("\nCase 3.2. Measure how many %s will take reading data for %u storm control policers.\n",
           TIME_DIMENSION,
           resource_limits.policer_storm_control_pool_size);
    MEASURE_TIME(&start_time);
    for (port_num = 0; port_num < needed_num_ports; port_num++) {
        for (i = 0; i < SX_POLICER_MAX_POLICERS_PER_PORT; i++) {
            __get_storm_control_policer(api_handle, lags[port_num], i);
        }
    }
    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /*
     *  Case 3.3. Destroy storm control policers
     */
    printf("\nCase 3.3. Measure how many %s will take destroying of %u storm control policers.\n",
           TIME_DIMENSION,
           resource_limits.policer_storm_control_pool_size);

    MEASURE_TIME(&start_time);

    for (port_num = 0; port_num < needed_num_ports; port_num++) {
        for (i = 0; i < SX_POLICER_MAX_POLICERS_PER_PORT; i++) {
            __delete_storm_control_policer(api_handle, lags[port_num], i);
        }
    }

    MEASURE_TIME(&end_time);
    DISPLAY_RESULTS(start_time, end_time);

    /* Delete all LAGs */
    for (i = 0; i < resource_limits.lag_num_max; i++) {
        status = sx_api_lag_port_group_set(api_handle, SX_ACCESS_CMD_DESTROY, SWID, &lags[i], NULL, 0);

        if (status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_lag_port_group_set failed rc: [%s]\n", sx_status_str(status));
            assert(FALSE);
        }
    }

    free(lags);

    printf("\nTest is finished.\n");

    return 0;
}
