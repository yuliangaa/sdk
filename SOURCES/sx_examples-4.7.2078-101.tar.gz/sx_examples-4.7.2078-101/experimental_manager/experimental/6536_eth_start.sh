#!/bin/bash
#
 # Copyright (C) 2008-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


relative_dir=`dirname $0`
pushd ${relative_dir} > /dev/null
absolute_dir=`pwd`
popd > /dev/null

module=${1:-"l2-l3"}

killall -9 sx_sdk vpi > /dev/null 2>&1
> /var/log/messages
dmesg -c > /dev/null

${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel start
fllv start_with_dpt 536
run_resources_sgmii.sh eth-single 6536
sx_sdk &
sleep 5
run_chassis.sh ${module}
run_dvs_manager.sh eth 6536