#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #

#!/bin/bash

# use this script to stop emad-dump tool that was invoked together with dvs_start.sh  (dvs_start.sh --emad-dump)

if [ -f /tmp/emad_dump.lock ]; then
    # The file holds the PID of the shell that runs emad_dump.sh. Killing the shell will send a signal to emad_dump.sh that in turn will clean up all child processes gracefully.
    kill -SIGTERM `cat /tmp/emad_dump.lock`
else
    echo emad_dump.sh is not running. ignoring.
fi