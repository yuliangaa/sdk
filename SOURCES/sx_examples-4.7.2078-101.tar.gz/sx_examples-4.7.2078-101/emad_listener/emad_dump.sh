#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #

#!/bin/bash

PROGNAME=$0
EMAD_DUMP_RX=0
EMAD_DUMP_TX=0
EMAD_DUMP_IF=emad_dump

if [ -z "$RESET_TRIGGER" ]; then
    RESET_TRIGGER=1
fi

wait_for_sx_core() {
    # wait 10 seconds for the driver to load. terminate on timeout.
    wait_interval=10
    while [ ${wait_interval} -gt 0 ]; do
        if [ -f /sys/module/sx_core/parameters/reset_trigger ]; then
            break;
        fi

        sleep 1
        ((wait_interval=wait_interval-1))
    done

    if [ ${wait_interval} -eq 0 ]; then
        error_exit "seems like driver is stuck on loading"
    fi
}

start_emad_dump() {
    if [ "$DIRECTIONS" = "RX_TX" ] || [ "$DIRECTIONS" = "RX" ]; then
        EMAD_DUMP_RX=1
    fi

    if [ "$DIRECTIONS" = "RX_TX" ] || [ "$DIRECTIONS" = "TX" ]; then
        EMAD_DUMP_TX=1
    fi

    /sbin/modprobe sx_emad_dump emad_dump_rx=${EMAD_DUMP_RX} emad_dump_tx=${EMAD_DUMP_TX}
    if [ $? != 0 ]; then
        error_exit "failed to load sx_emad_dump module"
    fi

    # write the PID of the shell to the file so emad_dump_stop.sh can terminate it.
    echo $$ > /tmp/emad_dump.lock
	
    ifconfig ${EMAD_DUMP_IF} up

    emad_listener ${PCAP_FILE} &
    EMAD_LISTENER_PID=$!

    echo Recording EMAD.

    if [ ${RESET_TRIGGER} -eq 0 ]; then
        echo 1 > /sys/module/sx_core/parameters/reset_trigger
    fi
}

end_emad_dump() {
    kill ${EMAD_LISTENER_PID}
	
    ifconfig ${EMAD_DUMP_IF} down
    rmmod sx_emad_dump
    rm -rf /tmp/emad_dump.lock
	
    ls -l ${PCAP_FILE}
    echo
}

handle_signal() {
    end_emad_dump
	exit 0
}

error_exit() {
    echo "${PROGNAME}: $1"
    echo
    echo
    exit 1
}

usage() {
    echo "Usage: ${PROGNAME} <RX_TX | RX | TX> <pcap-file>"
    echo
}


##################################################################
# HERE WE START

if [ $# != "2" ]; then
    usage
    error_exit "directions and .pcap file must be specified"
fi

DIRECTIONS=$1
PCAP_FILE=$2

if [ -f /tmp/emad_dump.lock ]; then
    error_exit "an insntace of this script is already running ..."
fi

if [ "$DIRECTIONS" != "RX_TX" ] && [ "$DIRECTIONS" != "RX" ] && [ "$DIRECTIONS" != "TX" ]; then
    usage
    error_exit "invalid directions specified"
fi

trap handle_signal HUP INT TERM

wait_for_sx_core
start_emad_dump

if [ ${RESET_TRIGGER} -eq 0 ]; then
    # emad_dump_stop.sh will terminate this script.
    while true
    do
        sleep 1
    done
else
    echo Press any key to stop.
    read _
fi
end_emad_dump