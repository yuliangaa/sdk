#!/usr/bin/env python3
# -*- coding: latin-1 -*-

import math
import xmltodict
import operator
import argparse
import string


def toint(esize):
    r = int(esize.split('.', 2)[1])
    if '0x' in esize:
        r += int(esize.split('.', 2)[0], 16) * 8
    return r


class EBasic(object):
    def __init__(self):
        self._name = None
        self._size = 0

    def __init__(self, name, size):
        self._name = name
        self._size = size

    @property
    def name(self):
        return self._name.replace('/', '_').replace(' ', '').replace('-', '_').replace('[', '_').replace(':', '_').replace(']', '_')

    @name.setter
    def name(self, name):
        self._name = name

    @property
    def size(self):
        return max(toint(self._size) / 8, 1)

    @property
    def size_bit(self):
        return toint(self._size)

    @size.setter
    def size(self, size):
        self._size = size


class ENode(EBasic):
    def __init__(self):
        self._is_union = False

    def __init__(self, name, size):
        self._is_union = False
        super(ENode, self).__init__(name, size)

    def __init__(self, name, size, fields):
        self._is_union = False
        super(ENode, self).__init__(name, size)
        if not isinstance(fields, list):
            fields = [fields]
        self._field = {}
        for field in fields:
            s = ""
            if '@subnode' in field.keys():
                s = field['@subnode']
            f = EField(field['@name'], field['@size'],
                       field['@offset'], s,
                       field['@descr'])
            if '@enum' in field.keys():
                f.enum = field['@enum']

            if '@low_bound' in field.keys():
                f.low_bound = field['@low_bound']

            if '@high_bound' in field.keys():
                f.high_bound = field['@high_bound']

            self._field[f.name] = f

    def print_proto_field(self, nodes, dname, field_name):
        data = []

        if field_name == '':
            if len(self.name) > 4 and self.name[-4:] == '_reg':
                self_name = self.name[:-4]
            else:
                self_name = self.name
        else:
            self_name = field_name

        data.append('{dname}.fields.pf_{name} = ProtoField.bytes("{dname}.{name}", "{dname}.{name}")'.format(
            name=self_name,
            dname=dname))

        for f in self.fields:
            if f.subnode not in nodes.keys():
                if f.size_bit <= 32:
                    if len(f.enum):
                        data.append('{dname}.fields.pf_{name} = ProtoField.new("{dname}.{name}", "{dname}.{name}", ftypes.UINT32, {enum}, base.DEC)'.format(
                            name=f.name,
                            dname=dname,
                            enum=f.enum_str))
                    else:
                        data.append('{dname}.fields.pf_{name} = ProtoField.uint32("{dname}.{name}", "{dname}.{name}", nil, nil, nil, "{descr}")'.format(
                            name=f.name,
                            dname=dname,
                            descr=f.descr))
                else:
                    data.append('{dname}.fields.pf_{name} = ProtoField.bytes("{dname}.{name}", "{dname}.{name}")'.format(
                        name=f.name,
                        dname=dname))
            else:
                data.extend(nodes[f.subnode].print_proto_field(nodes, dname, f.name))

        return data

    def __get_sbit(self, offset, size):
        """Return start bit of field in u32.

        offset: Field PRM bit offset
        size: Field PRM size (in bits)
        """
        return (32 - (offset % 32) - size)

    def __get_sbyte(self, offset, sbit):
        """Return start byte of field.

        offset: Field PRM bit offset
        sbit: Field start bit in u32
        """
        return (((int)(offset / 32)) * 4 + (int)(sbit / 8))

    def __get_ebyte(self, sbyte, size, sbit):
        """Return end byte of field.

        sbyte: Field start byte.
        size: Field PRM size (in bits)
        sbit: Field start bit in u32
        """
        return (sbyte + int(math.ceil((sbit - ((sbyte % 4) * 8) + size) / 8.0)))

    def print_subnode_function(self, nodes, dname, field_name):
        data = ['']

        for f in self.fields:
            if f.subnode in nodes.keys():
                data.extend(nodes[f.subnode].print_subnode_function(nodes, dname, f.name))

        if field_name == '':
            if len(self.name) > 4 and self.name[-4:] == '_reg':
                self_name = self.name[:-4]
            else:
                self_name = self.name
        else:
            self_name = field_name

        data.append('-- function for node_{name}'.format(name=self_name))
        data.append('function node_{dname}_{name}(tvbuf, tree)'.format(dname=dname, name=self_name))
        data.append('\t subtree_{dname}_{name} = tree:add({dname}.fields.pf_{name}, tvbuf())'.format(
            dname=dname,
            name=self_name))
        for f in self.fields:
            if f.subnode in nodes.keys():
                for i in range(f.low_bound, f.high_bound + 1):
                    data.append('\t node_{dname}_{name}(tvbuf({offset}, {size}), subtree_{dname}_{sname})'.format(
                        dname=dname,
                        sname=self_name,
                        name=f.name,
                        offset=f.offset + (i * nodes[f.subnode].size),
                        size=nodes[f.subnode].size))
            else:
                if f.size_bit <= 32:
                    sbit = self.__get_sbit(f.offset_bit, f.size_bit)
                    ebit = sbit + f.size_bit - 1
                    sbyte = self.__get_sbyte(f.offset_bit, sbit)
                    ebyte = self.__get_ebyte(sbyte, f.size_bit, sbit)
                    data.append('\t subtree_{dname}_{sname}:add({dname}.fields.pf_{name}, tvbuf({offset}, {size}), tvbuf({offset}, {size}):bitfield({sbit}, {bsize}))'.format(
                        sname=self_name, dname=dname, name=f.name, offset=sbyte, size=ebyte - sbyte,
                        sbit=sbit - 8 * (sbyte % 4), bsize=ebit - sbit + 1))
                else:
                    data.append('\t if tvbuf:len() <= {offset} then'.format(offset=f.offset))
                    data.append('\t\t subtree_{dname}_{sname}:add({dname}.fields.pf_{name}, tvbuf({offset}, 0))'.format(dname=dname, sname=self_name, name=f.name, offset=f.offset))
                    data.append('\t else')
                    data.append('\t\t if (({offset} + {size}) > tvbuf:len()) then'.format(offset=f.offset, size=f.size))
                    data.append('\t\t\t subtree_{dname}_{sname}:add({dname}.fields.pf_{name}, tvbuf({offset}, (tvbuf:len() - {offset})))'.format(dname=dname, sname=self_name, name=f.name, offset=f.offset))
                    data.append('\t\t else')
                    data.append('\t\t\t subtree_{dname}_{sname}:add({dname}.fields.pf_{name}, tvbuf({offset}, {size}))'.format(dname=dname, sname=self_name, name=f.name, offset=f.offset, size=f.size))
                    data.append('\t\t end')
                    data.append('\t end')

        data.extend(['end', ''])

        return data

    @property
    def fields(self):
        return sorted(self._field.values(), key=operator.attrgetter('offset'))
        # return ' '.join(self._field.keys())


class EField(EBasic):
    def __init__(self):
        pass

    def __init__(self, name, size, offset, subnode, descr):
        self._offset = offset
        self._subnode = subnode
        self._descr = descr
        self._enum = {}
        self._low_bound = 0
        self._high_bound = 0
        super(EField, self).__init__(name, size)

    @property
    def descr(self):
        return self._descr.replace('\\', '').replace('\"', '')

    @property
    def offset(self):
        return toint(self._offset) / 8

    @property
    def offset_bit(self):
        return toint(self._offset)

    @property
    def subnode(self):
        return self._subnode

    @property
    def enum(self):
        return self._enum

    @property
    def enum_str(self):
        return '{ ' + (', '.join('[{v}] = "{k}"'.format(k=k, v=v) for k, v in self.enum.items())) + ' }'

    @property
    def enum_str_hex(self):
        return '{ ' + (', '.join('[{v}] = "{k}"'.format(k=k, v=hex(v)) for k, v in self.enum.items())) + ' }'

    @enum.setter
    def enum(self, val):
        ll = val.split(',')
        for l in ll:
            n = l.split('=')[0]
            v = l.split('=')[1]
            if '0x' in v:
                v = int(v, 16)
            self._enum[n] = v

    @property
    def low_bound(self):
        return self._low_bound

    @low_bound.setter
    def low_bound(self, val):
        self._low_bound = int(val, 10)

    @property
    def high_bound(self):
        return self._high_bound

    @high_bound.setter
    def high_bound(self, val):
        if val == "VARIABLE":
            self._high_bound = 0
        else:
            self._high_bound = int(val, 10)


def print_node(node, nodes, l):
    for f in node.fields:
        print('\t' * l + f.name + '(' + f.subnode + ')' + '\t size:' + str(f.size) + ', offset:' + str(f.offset))
        if f.subnode in nodes.keys():
            print_node(nodes[f.subnode], nodes, l + 1)


def print_proto(node, rid, nodes):
    data = []
    if len(node.name) > 4 and node.name[-4:] == '_reg':
        reg_name = node.name[:-4]
    else:
        reg_name = node.name
    data.append('{name} = Proto("{name}_mlnx", "{name} Register")'.format(
        name=reg_name))

    data.append('')
    data.extend(node.print_proto_field(nodes, reg_name, ''))

    data.extend(node.print_subnode_function(nodes, reg_name, ''))

    data.append('function {name}.dissector(tvbuf, pktinfo, root)'.format(name=reg_name))
    #data.append('\tsubtree = root:add ({name}, tvbuff())'.format(name=reg_name))
    data.append('\tpktinfo.cols.protocol:set("EMAD.{name}")'.format(name=reg_name))
    data.append('\tnode_{name}_{name}(tvbuf, root)'.format(name=reg_name))
    data.extend(['end', ''])

    data.append('')
    data.append('function {name}.init()'.format(name=reg_name))
    data.append('\tDissectorTable.get("emad_regs"):add({rid}, {proto})'.format(
        proto=reg_name,
        rid=rid))
    data.extend(['end', ''])
    data.append('')
    print('\n'.join(i for i in data if i is not None))

    pass


def print_reg_proto(nodes, reg_ids):
    for name, enode in nodes.items():
        if name.upper() in reg_ids:
            v = reg_ids[name.upper()]
        elif len(name) > 4 and name[-4:] == '_reg' and name[:-4].upper() in reg_ids:
            v = reg_ids[name[:-4].upper()]
        else:
            continue

        print_proto(nodes[name], v, nodes)


def main():
    nodes = {}
    reg_ids = {}

    parser = argparse.ArgumentParser()
    parser.add_argument('adb_file_name', metavar='a', help='.adb file name to parse')

    args = parser.parse_args()

    with open(args.adb_file_name, 'r') as fd:
        nd = xmltodict.parse(fd.read())
    for node in nd['NodesDefinition']['node']:
        if 'field' not in node.keys():
            continue

        if node['@name'] == 'access_reg_summary_ctrl':
            reg_ids_str = node['field']['@enum']
            for pair in reg_ids_str.split(','):
                reg_id_str = pair.split('=')[0]
                reg_id = int(pair.split('=')[1], 0)
                reg_ids[reg_id_str] = reg_id
        else:
            n = ENode(node['@name'], node['@size'], node['field'])
            nodes[n.name] = n

    print_reg_proto(nodes, reg_ids)


if __name__ == '__main__':
    main()
