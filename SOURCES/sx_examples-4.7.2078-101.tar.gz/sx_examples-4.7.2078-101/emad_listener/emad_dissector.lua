local emad = Proto("emad", "Mellanox EMAD configuration packets")
local EMAD_ETHER_TYPE = 0x8932

local EMAD_TLV_TYPE = {
    [0x0] = "End",
    [0x1] = "Operation",
    [0x2] = "String",
    [0x3] = "Reg",
    [0x4] = "Latency"
}

----------------------EMAD_header_fields----------------------
pf_eth_hdr_mlx_proto = ProtoField.uint8("eth_hdr.mlx_proto", "Mellanox protocol", base.HEX)
pf_eth_hdr_ver = ProtoField.uint8("eth_hdr.ver", "Protocol version", base.HEX)

----------------------operation_tlv_fields----------------------
local OP_TLV_STATUS = {
    [0x0] = "Operation performed",
    [0x1] = "Device is busy",
    [0x2] = "Version not supported",
    [0x3] = "Unknown TLV",
    [0x4] = "Register not supported",
    [0x5] = "Class not supported",
    [0x6] = "Method not supported",
    [0x7] = "Bad parameter",
    [0x8] = "Resource not available",
    [0x9] = "Acknowledged",
    [0xA] = "Retry",
    [0x70] = "Internal error"
}

local OP_TLV_REG_ID = {
    [0x2000] = "SGCR",
    [0x2001] = "SCAR",
    [0x2002] = "SPAD",
    [0x2006] = "SMPU",
    [0x2007] = "SMID",
    [0x2008] = "SSPR",
    [0x2009] = "SFDAT",
    [0x200A] = "SFD",
    [0x200B] = "SFN",
    [0x200C] = "SPGT",
    [0x200D] = "SPMS",
    [0x200E] = "SPVID",
    [0x200F] = "SPVM",
    [0x2010] = "SPAFT",
    [0x2011] = "SFGC",
    [0x2012] = "SFTR",
    [0x2013] = "SFDF",
    [0x2014] = "SLDR",
    [0x2015] = "SLCR",
    [0x2016] = "SLCOR",
    [0x2017] = "SLECR",
    [0x2018] = "SPMLR",
    [0x2019] = "SVMLR",
    [0x201A] = "SPMCR",
    [0x201C] = "SVFA",
    [0x201D] = "SPVTR",
    [0x201E] = "SVPE",
    [0x201F] = "SFMR",
    [0x2020] = "SPVMLR",
    [0x2021] = "SLCR_V2",
    [0x2022] = "SFDT",
    [0x2023] = "SPFSR",
    [0x2025] = "SVER",
    [0x2026] = "SPVC",
    [0x2028] = "SFDB",
    [0x2029] = "SFFP",
    [0x202A] = "SPEVET",
    [0x202B] = "SMPE",
    [0x202C] = "SMPEB",
    [0x202D] = "SFDB_V2",
    [0x202F] = "SFTR_V2",
    [0x2032] = "SPMS_V2",
    [0x2034] = "SMID_V2",
    [0x2801] = "CWGCR",
    [0x2802] = "CWTP",
    [0x2803] = "CWTPM",
    [0x2804] = "CWPP",
    [0x2805] = "CWPPM",
    [0x2806] = "CPQE",
    [0x2810] = "CHLTR",
    [0x2811] = "CHLTM",
    [0x2812] = "CHLMM",
    [0x2820] = "CEGCR",
    [0x2821] = "CEPC",
    [0x2822] = "CEDR",
    [0x2823] = "CEER",
    [0x3001] = "PGCR",
    [0x3002] = "PPBT",
    [0x3003] = "PVBT",
    [0x3004] = "PACL",
    [0x3005] = "PAGT",
    [0x3006] = "PTAR",
    [0x3007] = "PTCE",
    [0x3008] = "PPRR",
    [0x3009] = "PVGT",
    [0x300A] = "PFCA",
    [0x300B] = "PFCNT",
    [0x300C] = "PPBS",
    [0x300D] = "PRCR",
    [0x300E] = "PUET",
    [0x300F] = "PEFA",
    [0x3010] = "PECB",
    [0x3011] = "PEMB",
    [0x3012] = "PPBMI",
    [0x3013] = "PRBT",
    [0x3014] = "PEMRBT",
    [0x3017] = "PTCE2",
    [0x3021] = "PERPT",
    [0x3022] = "PEABFE",
    [0x3026] = "PERAR",
    [0x3027] = "PTCE3",
    [0x3028] = "PTCEAD",
    [0x3029] = "PEFAAD",
    [0x302A] = "PERCR",
    [0x302B] = "PERERP",
    [0x302D] = "PEAPS",
    [0x302E] = "PEVPB",
    [0x3030] = "PECNRE",
    [0x3031] = "PECNRR",
    [0x3032] = "PECNEE",
    [0x3033] = "PECNER",
    [0x3801] = "IGCR",
    [0x3802] = "IDDD",
    [0x3804] = "IEDR",
    [0x3805] = "IEDS",
    [0x3810] = "IFBO",
    [0x3811] = "IICR",
    [0x3813] = "IHSR",
    [0x38F0] = "ICSR",
    [0x4001] = "QCAP",
    [0x4002] = "QPTS",
    [0x4004] = "QPCR",
    [0x4007] = "QPDP",
    [0x4008] = "QPRT",
    [0x4009] = "QSPTC",
    [0x400A] = "QTCT",
    [0x400B] = "QSTCT",
    [0x400C] = "QPBR",
    [0x400D] = "QEEC",
    [0x400E] = "QSPIP",
    [0x400F] = "QRWE",
    [0x4010] = "QPEM",
    [0x4011] = "QPDSM",
    [0x4012] = "QPPM",
    [0x4013] = "QPDPM",
    [0x4014] = "QEPM",
    [0x4015] = "QSLL",
    [0x4016] = "QHLL",
    [0x4017] = "QPDPC",
    [0x401A] = "QTCTM",
    [0x401B] = "QPSC",
    [0x401E] = "QSPCP",
    [0x4040] = "QTTTL",
    [0x4041] = "QTQCR",
    [0x4042] = "QTQDR",
    [0x4043] = "QTEEM",
    [0x4044] = "QTDEM",
    [0x4801] = "FPUMS",
    [0x4880] = "FPHHC",
    [0x4881] = "FPPC",
    [0x4882] = "FPFTT",
    [0x4883] = "FPHTT",
    [0x4884] = "FPTS",
    [0x4901] = "FMTC",
    [0x4902] = "FMTE",
    [0x4903] = "FMTM",
    [0x4926] = "FSHE",
    [0x5001] = "PCAP",
    [0x5002] = "PMLP",
    [0x5003] = "PMTU",
    [0x5004] = "PTYS",
    [0x5005] = "PPAD",
    [0x5006] = "PAOS",
    [0x5007] = "PFCC",
    [0x5008] = "PPCNT",
    [0x5009] = "PUDE",
    [0x500A] = "PLIB",
    [0x500B] = "PPTB",
    [0x500C] = "PBMC",
    [0x500D] = "PSPA",
    [0x500E] = "PELC",
    [0x500F] = "PVLC",
    [0x5011] = "PPSC",
    [0x5012] = "PMAOS",
    [0x5013] = "PMPR",
    [0x5015] = "PLBF",
    [0x5016] = "PIFR",
    [0x5018] = "PPLR",
    [0x501A] = "PMTDB",
    [0x501B] = "PMECR",
    [0x501C] = "PMLPE",
    [0x501D] = "PMSC",
    [0x501F] = "PMPC",
    [0x5022] = "PLPC",
    [0x5023] = "PPLM",
    [0x5024] = "PMPE",
    [0x5031] = "PDDR",
    [0x5036] = "PPTT",
    [0x5037] = "PPRT",
    [0x5038] = "PBSR",
    [0x5040] = "PPAOS",
    [0x5041] = "PCMR",
    [0x5043] = "PFSC",
    [0x5044] = "PMMP",
    [0x5045] = "PMCR",
    [0x5049] = "PCSR",
    [0x504A] = "PLLP",
    [0x5050] = "PCNR",
    [0x5051] = "PPBMP",
    [0x5052] = "PPBMC",
    [0x5053] = "PPBME",
    [0x5055] = "PTER",
    [0x5058] = "PREI",
    [0x5060] = "PMTPS",
    [0x5067] = "PMTM",
    [0x5068] = "PLAR",
    [0x50E0] = "PIFR_V2",
    [0x6002] = "SPZR",
    [0x6003] = "IBFMR",
    [0x6004] = "IBFMRC",
    [0x7000] = "HGCR",
    [0x7001] = "HCAP",
    [0x7002] = "HTGT",
    [0x7003] = "HPKT",
    [0x7004] = "HDRT",
    [0x7005] = "HESPR",
    [0x7022] = "HRDQT",
    [0x7023] = "HTACG",
    [0x7081] = "HOPF",
    [0x7083] = "HCTR",
    [0x7084] = "HMON",
    [0x7085] = "HTAC",
    [0x7087] = "HCOT",
    [0x7801] = "XGCR",
    [0x7802] = "XLTQ",
    [0x7803] = "XMDR",
    [0x7804] = "XLKBU",
    [0x7810] = "XRMT",
    [0x7811] = "XRALTA",
    [0x7812] = "XRALST",
    [0x7813] = "XRALTB",
    [0x8000] = "RCAP",
    [0x8001] = "RGCR",
    [0x8002] = "RITR",
    [0x8003] = "RIGR",
    [0x8004] = "RTAR",
    [0x8005] = "RECR",
    [0x8006] = "RUFT",
    [0x8007] = "RMFT",
    [0x8008] = "RATR",
    [0x8009] = "RDPM",
    [0x800A] = "RICA",
    [0x800B] = "RICNT",
    [0x800C] = "RUHT",
    [0x800D] = "RTCA",
    [0x800E] = "RTPS",
    [0x800F] = "RRCR",
    [0x8010] = "RALTA",
    [0x8011] = "RALST",
    [0x8012] = "RALTB",
    [0x8013] = "RALUE",
    [0x8014] = "RAUHT",
    [0x8015] = "RALEU",
    [0x8016] = "RALBU",
    [0x8017] = "RALCM",
    [0x8018] = "RAUHTD",
    [0x8020] = "RTDP",
    [0x8021] = "RIPS",
    [0x8022] = "RATRAD",
    [0x8023] = "RIGRV2",
    [0x8025] = "RECRV2",
    [0x8027] = "RMFTV2",
    [0x8028] = "RMFTAD",
    [0x8030] = "RMID",
    [0x8031] = "RMPE",
    [0x8032] = "RMPU",
    [0x8033] = "RMEIR",
    [0x8034] = "REIV",
    [0x8036] = "RMID_V2",
    [0x8050] = "RXLTE",
    [0x8051] = "RXLTM",
    [0x8052] = "RXLTCC",
    [0x8053] = "RLCME",
    [0x8054] = "RLCMLE",
    [0x8055] = "RLCMLD",
    [0x8060] = "RARPC",
    [0x8061] = "RARPR",
    [0x8062] = "RARCL",
    [0x8064] = "RARFT",
    [0x8065] = "RARLPGT",
    [0x8066] = "RSNH",
    [0x8068] = "RARLU",
    [0x8069] = "RARSR",
    [0x8401] = "FCAP",
    [0x8801] = "MPGCR",
    [0x8802] = "MPILM",
    [0x8803] = "MPIBE",
    [0x8804] = "MPNHLFE",
    [0x9001] = "MFCR",
    [0x9002] = "MFSC",
    [0x9003] = "MFSM",
    [0x9004] = "MFSL",
    [0x9007] = "FORE",
    [0x9008] = "MCAS",
    [0x9009] = "MTCAP",
    [0x900A] = "MTMP",
    [0x900B] = "MTWE",
    [0x900F] = "MTBR",
    [0x9010] = "MFPA",
    [0x9011] = "MFBA",
    [0x9012] = "MFBE",
    [0x9013] = "MFMC",
    [0x9014] = "MCIA",
    [0x9016] = "MMIA",
    [0x9017] = "MMDIO",
    [0x901A] = "MPAT",
    [0x901B] = "MPAR",
    [0x901D] = "MFM",
    [0x901E] = "MHSR",
    [0x901F] = "MJTAG",
    [0x9020] = "MGIR",
    [0x9021] = "MSGI",
    [0x9023] = "MRSR",
    [0x902A] = "MSCI",
    [0x902B] = "MLCR",
    [0x9052] = "MCION",
    [0x9055] = "MTUTC",
    [0x905A] = "MPCIR",
    [0x9061] = "MCQI",
    [0x9062] = "MCC",
    [0x9063] = "MCDA",
    [0x9080] = "MPSC",
    [0x9081] = "MGPC",
    [0x9083] = "MPRS",
    [0x9084] = "MDRI",
    [0x9086] = "MOGCR",
    [0x9087] = "MRRR",
    [0x9089] = "MPAGR",
    [0x908A] = "MAFCR",
    [0x908B] = "MAFTI",
    [0x908C] = "MAFRI",
    [0x908D] = "MOMTE",
    [0x9090] = "MTPPPC",
    [0x9091] = "MTPPTR",
    [0x9095] = "MOCS",
    [0x9097] = "MAFBI",
    [0x90F0] = "MFGD",
    [0x90F4] = "MONI",
    [0x90F8] = "MOFS",
    [0x90F9] = "MOLP",
    [0x9100] = "MGPIR",
    [0x9101] = "MDFCR",
    [0x910B] = "MTEWE",
    [0x910C] = "MTSDE",
    [0x9120] = "MBCT",
    [0x9160] = "MDDT",
    [0x9161] = "MDDQ",
    [0x9163] = "MDDC",
    [0x9200] = "MFDE",
    [0xA001] = "TNGCR",
    [0xA002] = "TNCR",
    [0xA003] = "TNUMT",
    [0xA004] = "TNCR_V2",
    [0xA010] = "TNQCR",
    [0xA011] = "TNQDR",
    [0xA012] = "TNEEM",
    [0xA013] = "TNDEM",
    [0xA014] = "TNIFR",
    [0xA017] = "TNIFR_V2",
    [0xA020] = "TNPC",
    [0xA021] = "TNGEE",
    [0xA801] = "TIGCR",
    [0xA810] = "TIQCR",
    [0xA811] = "TIQDR",
    [0xA812] = "TIEEM",
    [0xA813] = "TIDEM",
    [0xB000] = "SBGCR",
    [0xB001] = "SBPR",
    [0xB002] = "SBCM",
    [0xB003] = "SBPM",
    [0xB004] = "SBMM",
    [0xB005] = "SBSR",
    [0xB006] = "SBIB",
    [0xB007] = "SBDCC",
    [0xB008] = "SBDCM",
    [0xB00A] = "SBHBR",
    [0xB00B] = "SBHRR",
    [0xB00C] = "SBCTC",
    [0xB00D] = "SBCTR",
    [0xB011] = "SBHBR_V2",
    [0xB012] = "SBHRR_V2",
    [0xB013] = "SBHPC",
    [0xB015] = "SBSRD",
    [0xB020] = "SBSNT",
    [0xB021] = "SBSNS",
    [0xB022] = "SBSNTE"
}

local OP_TLV_R = {
    [0x0] = "Request",
    [0x1] = "Response"
}

local OP_TLV_METHOD = {
    [0x1] = "Query",
    [0x2] = "Write",
    [0x5] = "Event"
}

local OP_TLV_CLASS = {
    [0x0] = "Reserved",
    [0x1] = "Reg access"
}

DissectorTable.new("emad_regs", "emad_regs", ftypes.UINT16, base.DEC)

pf_op_tlv_type = ProtoField.uint8("op_tlv.type", "Type", base.HEX, EMAD_TLV_TYPE)
pf_op_tlv_len = ProtoField.uint16("op_tlv.len", "Len", base.HEX)
pf_op_tlv_status = ProtoField.uint8("op_tlv.status", "Status", base.HEX, OP_TLV_STATUS)
pf_op_tlv_register_id = ProtoField.uint16("op_tlv.register_id", "Register ID", base.HEX, OP_TLV_REG_ID)
pf_op_tlv_r = ProtoField.uint8("op_tlv.r", "Request/Response", base.HEX, OP_TLV_R)
pf_op_tlv_method = ProtoField.uint8("op_tlv.method", "Method", base.HEX, OP_TLV_METHOD)
pf_op_tlv_class = ProtoField.uint8("op_tlv.class", "Class", base.HEX, OP_TLV_CLASS)
pf_op_tlv_tid = ProtoField.uint64("op_tlv.tid", "Transaction ID", base.HEX)

----------------------string_tlv_fields----------------------
pf_string_tlv_type = ProtoField.uint8("string_tlv.type", "Type", base.HEX, EMAD_TLV_TYPE)
pf_string_tlv_len = ProtoField.uint16("string_tlv.len", "Len", base.HEX)
pf_string_tlv_string = ProtoField.string("string_tlv.string", "String", base.ASCII)

----------------------latency_tlv_fields----------------------
pf_latency_tlv_type = ProtoField.uint8("latency_tlv.type", "Type", base.HEX, EMAD_TLV_TYPE)
pf_latency_tlv_len = ProtoField.uint16("latency_tlv.len", "Len", base.HEX)
pf_latency_tlv_payload = ProtoField.bytes("latency_tlv.payload", "Latency payload")

----------------------reg_tlv_fields----------------------
pf_reg_tlv_type = ProtoField.uint8("reg_tlv.type", "Type", base.HEX, EMAD_TLV_TYPE)
pf_reg_tlv_len = ProtoField.uint16("reg_tlv.len", "Len", base.HEX)
pf_reg_tlv_switch_register = ProtoField.bytes("reg_tlv.switch_register", "Register payload")
pf_reg_tlv_register_fields = ProtoField.bytes("reg_tlv.register_fields", "Register fields")

----------------------end_tlv_fields----------------------
pf_end_tlv_type = ProtoField.uint8("end_tlv.type", "Type", base.HEX, EMAD_TLV_TYPE)
pf_end_tlv_len = ProtoField.uint16("end_tlv.len", "Len", base.HEX)

function emad_header(tvbuf, tree)
    tree:add(pf_eth_hdr_mlx_proto, tvbuf:range(0, 1))
    tree:add(pf_eth_hdr_ver, tvbuf:range(1, 1), tvbuf(1,1):bitfield(4, 4))
end

emad.fields = {
    pf_eth_hdr_mlx_proto,
    pf_eth_hdr_ver,
    pf_op_tlv_type,
    pf_op_tlv_len,
    pf_op_tlv_status,
    pf_op_tlv_register_id,
    pf_op_tlv_r,
    pf_op_tlv_method,
    pf_op_tlv_class,
    pf_op_tlv_tid,
    pf_string_tlv_type,
    pf_string_tlv_len,
    pf_string_tlv_string,
    pf_latency_tlv_type,
    pf_latency_tlv_len,
    pf_latency_tlv_payload,
    pf_reg_tlv_type,
    pf_reg_tlv_len,
    pf_reg_tlv_switch_register,
    pf_reg_tlv_register_fields,
    pf_end_tlv_type,
    pf_end_tlv_len
}

function emad_tlv_len_add(tvbuf, tree, proto_field)
    -- The len is represnted by number of dwords, have to multiply by 4
    local len_dwords = tvbuf(0, 2):bitfield(5, 11)
    local len_str = tostring(len_dwords * 4) .. 'B'

    tree:add(proto_field, tvbuf(0, 2), tvbuf(0, 2):bitfield(5, 11)):
        append_text(" (" .. len_str .. ")")
end

function emad_tlv_len_get(tvbuf)
    -- The len is represnted by number of dwords, have to multiply by 4
    local len_dwords = tvbuf(0, 2):bitfield(5, 11)
    return len_dwords * 4
end

function emad_op_tlv(tvbuf, tree)
    tree:add(pf_op_tlv_type, tvbuf(0, 1), tvbuf(0, 1):bitfield(0, 5))
    emad_tlv_len_add(tvbuf, tree, pf_op_tlv_len)
    tree:add(pf_op_tlv_status, tvbuf(2, 1), tvbuf(2, 1):bitfield(1, 7))
    tree:add(pf_op_tlv_register_id, tvbuf(4, 2))
    tree:add(pf_op_tlv_r, tvbuf(6, 1), tvbuf(6, 1):bitfield(0, 1))
    tree:add(pf_op_tlv_method, tvbuf(6, 1), tvbuf(6, 1):bitfield(1, 7))
    tree:add(pf_op_tlv_class, tvbuf(7, 1), tvbuf(7, 1):bitfield(4, 4))
    tree:add(pf_op_tlv_tid, tvbuf(8, 8))
    return tvbuf(4, 2):uint()
end

function emad_op_tlv_method_is_event(tvbuf)
    local method = tvbuf(6, 1):bitfield(1, 7)
    return OP_TLV_METHOD[method] == "Event"
end

function emad_string_tlv(tvbuf, tree)
    tree:add(pf_string_tlv_type, tvbuf(0, 1), tvbuf(0, 1):bitfield(0, 5))
    emad_tlv_len_add(tvbuf, tree, pf_string_tlv_len)
    tree:add(pf_string_tlv_string, tvbuf(2))
end

function emad_latency_tlv(tvbuf, tree, len)
    tree:add(pf_latency_tlv_type, tvbuf(0, 1), tvbuf(0, 1):bitfield(0, 5))
    emad_tlv_len_add(tvbuf, tree, pf_latency_tlv_len)
    tree:add(pf_latency_tlv_payload, tvbuf(2))
end

function emad_reg_tlv(tvbuf, tree, pktinfo, reg_id)
    tree:add(pf_reg_tlv_type, tvbuf(0, 1), tvbuf(0, 1):bitfield(0, 5))
    emad_tlv_len_add(tvbuf, tree, pf_reg_tlv_len)
    reg_tree = tree:add(pf_reg_tlv_switch_register, tvbuf(2))
    emad_regs = DissectorTable.get("emad_regs")
    emad_regs:try(reg_id, tvbuf(4):tvb(), pktinfo, reg_tree)
end

function emad_end_tlv(tvbuf, tree)
    tree:add(pf_end_tlv_type, tvbuf(0, 1), tvbuf(0, 1):bitfield(0, 5))
    emad_tlv_len_add(tvbuf, tree, pf_end_tlv_len)
end

function emad.dissector(tvbuf, pktinfo, root)
    length = tvbuf:len()
    if length == 0 then
        return
    end

    pktinfo.cols.protocol:set("EMAD")
    local current_index = 0

    -- EMAD_header --
    local emad_header_len = 2
    local emad_header_subtree = root:add(emad, tvbuf:range(current_index, emad_header_len), "EMAD header")
    emad_header(tvbuf(current_index, emad_header_len), emad_header_subtree)
    current_index = current_index + emad_header_len

    local subtree = root:add(emad, tvbuf:range(current_index), "EMAD Protocol Data")

    -- operation_tlv --
    local op_tlv_len = emad_tlv_len_get(tvbuf:range(current_index))
    local op_tlv_subtree = subtree:add(emad, tvbuf:range(current_index, op_tlv_len), "Operation TLV")
    local reg_id = emad_op_tlv(tvbuf(current_index, op_tlv_len), op_tlv_subtree)
    local is_event = emad_op_tlv_method_is_event(tvbuf(current_index, op_tlv_len))
    current_index = current_index + op_tlv_len

    -- string_tlv --
    local has_string_tlv = (tvbuf(current_index, 1):bitfield(0, 5) == 0x2)
    if (not is_event and has_string_tlv) then
        local string_tlv_len = emad_tlv_len_get(tvbuf:range(current_index))
        local string_tlv_subtree = subtree:add(emad, tvbuf:range(current_index, string_tlv_len), "String TLV")
        emad_string_tlv(tvbuf(current_index, string_tlv_len), string_tlv_subtree)
        current_index = current_index + string_tlv_len
    end

    -- latency_tlv --
    local has_latency_tlv = (tvbuf(current_index, 1):bitfield(0, 5) == 0x4)
    if has_latency_tlv then
        local latency_tlv_len = emad_tlv_len_get(tvbuf:range(current_index))
        local latency_tlv_subtree = subtree:add(emad, tvbuf:range(current_index, latency_tlv_len), "Latency TLV")
        emad_latency_tlv(tvbuf(current_index, latency_tlv_len), latency_tlv_subtree)
        current_index = current_index + latency_tlv_len
    end

    -- reg_tlv --
    local reg_tlv_len = emad_tlv_len_get(tvbuf:range(current_index))
    local reg_tlv_subtree = subtree:add(emad, tvbuf:range(current_index, reg_tlv_len), "Reg TLV")
    emad_reg_tlv(tvbuf(current_index, reg_tlv_len), reg_tlv_subtree, pktinfo, reg_id)
    current_index = current_index + reg_tlv_len

    -- end_tlv --
    if not is_event then
        local end_tlv_len = emad_tlv_len_get(tvbuf:range(current_index))
        local end_tlv_subtree = subtree:add(emad, tvbuf:range(current_index, end_tlv_len), "End TLV")
        emad_end_tlv(tvbuf(current_index, end_tlv_len), end_tlv_subtree)
    end
end

--- Invoke our dissector only for packets with specific EtherType
DissectorTable.get("ethertype"):add(EMAD_ETHER_TYPE, emad)
