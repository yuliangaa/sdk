/*
 * Copyright (C) 2009-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sys/socket.h>
#include <linux/netlink.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>

#include <sx/sxd/kernel_user.h>

#define MAX_PAYLOAD        (64 * 1024)
#define PCAP_VERSION_MAJOR (2)
#define PCAP_VERSION_MINOR (4)
#define PCAP_MAGIC         (0xa1b2c3d4)

#define PCAP_ERRBUF_SIZE  (256)
#define PCAP_MAX_SNAPLEN  (65535)
#define LINKTYPE_ETHERNET (1)

typedef struct pcap_file_header {
    uint32_t magic;
    uint16_t version_major;
    uint16_t version_minor;
    int32_t  thiszone;
    uint32_t sigfigs;
    uint32_t snaplen;
    uint32_t linktype;
} pcap_file_header_t;

typedef struct pcap_pkthdr {
    uint32_t tv_sec;
    uint32_t tv_usec;
    uint32_t caplen;
    uint32_t len;
} pcap_pkthdr_t;

int main(int argc, const char **argv)
{
    struct sockaddr_nl nl_addr;
    char               buff[NLMSG_SPACE(MAX_PAYLOAD)];
    int                fd = -1;
    int                rc = 0;
    int                len = 0;
    struct nlmsghdr   *nlh = NULL;
    struct nlattr     *nla = NULL;
    int                remaining = 0;
    char              *emad_start = NULL;
    int                emad_len = 0;
    FILE              *pcap_file = NULL;
    pcap_file_header_t header;
    pcap_pkthdr_t      pkt_header;
    struct timeval     ts;

    if ((argc != 2) || (argv[1] == NULL)) {
        printf("Invalid argument, Usage: %s pcap_file_path\n", argv[0]);
        rc = EINVAL;
        goto out;
    }

    pcap_file = fopen(argv[1], "w");
    if (pcap_file == NULL) {
        printf("Failed to open pcap file %s (error=%s)\n", argv[1], strerror(errno));
        rc = errno;
        goto out;
    }

    /* Writing the PCAP Header */
    memset(&header, 0, sizeof(header));
    header.magic = PCAP_MAGIC;
    header.version_major = PCAP_VERSION_MAJOR;
    header.version_minor = PCAP_VERSION_MINOR;
    header.thiszone = 0;
    header.sigfigs = 0;
    header.snaplen = NLMSG_SPACE(MAX_PAYLOAD);
    header.linktype = LINKTYPE_ETHERNET;

    if (fwrite(&header, 1, sizeof(header), pcap_file) != sizeof(header)) {
        printf("Failed to write pcap header (error=%s)\n", strerror(errno));
        rc = errno;
        goto close_pcap_file;
    }

    if (fflush(pcap_file) != 0) {
        printf("Failed to flush pcap file (error=%s)\n", strerror(errno));
        rc = errno;
        goto close_pcap_file;
    }

    fd = socket(AF_NETLINK, SOCK_DGRAM, NETLINK_EMAD_DUMP);
    if (fd < 0) {
        printf("failed to create netlink socket (error=%s)\n", strerror(errno));
        rc = errno;
        goto close_pcap_file;
    }

    memset(&nl_addr, 0, sizeof(nl_addr));
    nl_addr.nl_family = AF_NETLINK;
    nl_addr.nl_pid = getpid();
    nl_addr.nl_groups = SX_NL_GRP_EMAD_DUMP;

    rc = bind(fd, (struct sockaddr*)&nl_addr, sizeof(nl_addr));
    if (rc) {
        printf("failed to bind netlink socket to EMAD group (error=%s)\n", strerror(errno));
        goto close_fd;
    }

    /* Do not print any error message in the following loop, in case the error is due to the receiving of a signal, i.e. SIGINT. */
    while (1) {
        len = recv(fd, buff, sizeof(buff), 0);
        if (len < 0) {
            break;
        }

        /*
         * The EMAD dump netlink message format (Pad may not exist, it depends on the size of the headers):
         * +-----------------+-----+-------------------------------+-----+---------------+-----+------+------
         * | struct nlmsghdr | Pad | struct sx_emad_dump_nl_msghdr | Pad | struct nlattr | Pad | EMAD | ....
         * +-----------------+-----+-------------------------------+-----+---------------+-----+------+------
         */
        nlh = (struct nlmsghdr*)buff;
        if (!NLMSG_OK(nlh, len)) {
            break;
        }

        if ((int)(NLMSG_HDRLEN + NLMSG_ALIGN(sizeof(struct sx_emad_dump_nl_msghdr))) > len) {
            break;
        }

        remaining = len - (NLMSG_HDRLEN + NLMSG_ALIGN(sizeof(struct sx_emad_dump_nl_msghdr)));
        nla = (struct nlattr*)(buff + (NLMSG_HDRLEN + NLMSG_ALIGN(sizeof(struct sx_emad_dump_nl_msghdr))));
        if ((remaining < (int)sizeof(struct nlattr)) ||
            (nla->nla_len < NLA_HDRLEN) ||
            (nla->nla_len > remaining)) {
            break;
        }

        emad_start = (char*)(nla) + NLA_HDRLEN;
        emad_len = nla->nla_len - NLA_HDRLEN;

        /* Writing PCAP packet header */
        if (gettimeofday(&ts, NULL) != 0) {
            break;
        }
        memset(&pkt_header, 0, sizeof(pkt_header));
        pkt_header.tv_sec = (uint32_t)(ts.tv_sec);
        pkt_header.tv_usec = (uint32_t)(ts.tv_usec);
        pkt_header.caplen = emad_len;
        pkt_header.len = emad_len;

        if (fwrite(&pkt_header, 1, sizeof(pkt_header), pcap_file) != sizeof(pkt_header)) {
            break;
        }

        /* Writing EMAD into pcap */
        if (fwrite(emad_start, 1, emad_len, pcap_file) != (size_t)emad_len) {
            break;
        }

        if (fflush(pcap_file) != 0) {
            break;
        }
    }

    rc = 0;

close_fd:
    if ((fd != -1) && (close(fd) != 0)) {
        printf("Failed to close the netlink socket (error=%s)\n", strerror(errno));
    }

close_pcap_file:
    if ((pcap_file != NULL) && (fclose(pcap_file) != 0)) {
        printf("Failed to close the pcap file (error=%s)\n", strerror(errno));
    }

out:
    return rc;
}
