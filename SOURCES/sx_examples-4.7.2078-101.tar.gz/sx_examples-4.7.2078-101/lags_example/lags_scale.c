/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <time.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_policer.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_lag.h>
#include <sx/sdk/sx_api_vlan.h>
#include <sx/sxd/sxd_access_register.h>
#include <resource_manager/resource_manager.h>

#define SWID           0
#define DEVICE_ID      1
#define TIME_DIMENSION "micro seconds"

static void get_time(struct timespec *time)
{
    clock_gettime(CLOCK_REALTIME, time);
}

static uint64_t get_time_delta(struct timespec *start, struct timespec *end)
{
    return (end->tv_sec * 1000000 + end->tv_nsec / 1000) - (start->tv_sec * 1000000 + start->tv_nsec / 1000);
}

static void display_time_result(struct timespec *start, struct timespec *end)
{
    uint64_t result = 0;

    result = get_time_delta(start, end);
    printf(" Total time %" PRIu64 " %s.\n", result, TIME_DIMENSION);
}

static sx_status_t __get_chip_type(sx_chip_types_t *chip_type_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_mgir_reg mgir_reg;

    memset(&reg_meta, 0, sizeof(reg_meta));
    memset(&mgir_reg, 0, sizeof(mgir_reg));

    if (chip_type_p == NULL) {
        printf("ERROR: chip_type_p is NULL.\n");
        exit(1);
    }

    sxd_status = sxd_access_reg_init(0, NULL, SX_VERBOSITY_LEVEL_INFO);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        printf("ERROR: SXD API sxd_access_reg_init failed: [%s]\n", SXD_STATUS_MSG(sxd_status));
        exit(1);
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.dev_id = 1;
    memset(&mgir_reg, 0, sizeof(struct ku_mgir_reg));

    sxd_status = sxd_access_reg_mgir(&mgir_reg, &reg_meta, 1, NULL, NULL);
    if (sxd_status) {
        printf("%s: failed in get MGIR for dev_id %d, error: %d \n",
               __func__, 1, sxd_status);
    }

    switch (mgir_reg.hw_info.device_id) {
    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
        if (mgir_reg.hw_info.device_hw_revision == 0xA0) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM;
        } else if (mgir_reg.hw_info.device_hw_revision == 0xA1) {
            *chip_type_p = SX_CHIP_TYPE_SPECTRUM_A1;
        } else {
            printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
            exit(1);
        }
        printf("Device type is: SPECTRUM.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM2;

        printf("Device type is: SPECTRUM2.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM3;

        printf("Device type is: SPECTRUM3.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM4;

        printf("Device type is: SPECTRUM4.\n");
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        *chip_type_p = SX_CHIP_TYPE_SPECTRUM5;

        printf("Device type is: SPECTRUM5.\n");
        break;

    default:
        printf("Device ID %u is not expected.\n", mgir_reg.hw_info.device_id);
        exit(1);
    }

    return status;
}

static void __handle_lag_instance(sx_api_handle_t handle, sx_access_cmd_t cmd, sx_port_log_id_t *lag)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    if (cmd == SX_ACCESS_CMD_CREATE) {
        /* create new LAG */
        status = sx_api_lag_port_group_set(handle, cmd, SWID, lag, NULL, 0);
        if (status != SX_STATUS_SUCCESS) {
            printf("\nERROR: SDK API sx_api_lag_port_group_set failed rc: [%s]\n", sx_status_str(status));
            assert(FALSE);
        }

        /* to be able to add member logical ports we must have the same ingress filter for created LAG */
        status = sx_api_vlan_port_ingr_filter_set(handle, *lag, SX_INGR_FILTER_ENABLE);
        if (status != SX_STATUS_SUCCESS) {
            printf("\nERROR: SDK API sx_api_vlan_port_ingr_filter_set failed rc: [%s]\n", sx_status_str(status));
            assert(FALSE);
        }
    } else if (cmd == SX_ACCESS_CMD_DESTROY) {
        /* destroy specified LAG */
        status = sx_api_lag_port_group_set(handle, cmd, SWID, lag, NULL, 0);
        if (status != SX_STATUS_SUCCESS) {
            printf("\nERROR: SDK API sx_api_lag_port_group_set failed rc: [%s]\n", sx_status_str(status));
            assert(FALSE);
        }
    } else {
        printf("\nError: '%s' is unexpected command.\n", SX_ACCESS_CMD_STR(cmd));
        assert(FALSE);
    }
}

static void __handle_lag_member_ports(sx_api_handle_t   handle,
                                      sx_access_cmd_t   cmd,
                                      sx_port_log_id_t *lag,
                                      sx_port_log_id_t *log_port_list_p,
                                      uint32_t          ports_num)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    status = sx_api_lag_port_group_set(handle, cmd, SWID, lag, log_port_list_p, ports_num);
    if (status != SX_STATUS_SUCCESS) {
        printf("\nERROR: SDK API sx_api_lag_port_group_set - %s failed rc: [%s]\n", sx_status_str(
                   status), SX_ACCESS_CMD_STR(cmd));
        assert(FALSE);
    }
}


int main(int argc, char **argv)
{
    sx_api_handle_t       api_handle = 0;
    sx_status_t           status = SX_STATUS_SUCCESS;
    rm_resources_t        resource_limits;
    sx_chip_types_t       chip_type = SX_CHIP_TYPE_UNKNOWN;
    uint32_t              test_case_id = 0, i = 0;
    sx_port_log_id_t     *lags = NULL;
    sx_port_attributes_t *port_attr_p = NULL;
    sx_port_log_id_t     *log_port_list_p = NULL;
    uint32_t              port_cnt = 0, ports_to_set = 0;
    struct timespec       start_time, end_time;
    uint64_t              create_total_time = 0;
    uint64_t              delete_total_time = 0;

    memset(&start_time, 0, sizeof(start_time));
    memset(&end_time, 0, sizeof(end_time));
    memset(&resource_limits, 0, sizeof(rm_resources_t));

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    if (SX_STATUS_SUCCESS != __get_chip_type(&chip_type)) {
        printf("ERROR: Failed to determine the current chip type.\n");
        exit(1);
    }

    /* Open SDK */
    status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(status));
        exit(1);
    }
    printf("SDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);

    status = rm_chip_limits_get(chip_type, &resource_limits);
    if (SX_STATUS_SUCCESS != status) {
        printf("ERROR: SDK API rm_chip_limits_get failed: [%s]\n", sx_status_str(status));
        exit(1);
    }

    lags = (sx_port_log_id_t*)calloc(resource_limits.lag_num_max, sizeof(sx_port_log_id_t));
    assert(lags);

    /* let's get all (MAX) logical port ant their attributes per current chip */
    status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, NULL, &port_cnt);
    if (status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_port_device_get failed rc: [%s]\n", sx_status_str(status));
        assert(FALSE);
    }

    /* allocate required memory */
    port_attr_p = (sx_port_attributes_t*)calloc(port_cnt, sizeof(sx_port_attributes_t));
    assert(port_attr_p);

    status = sx_api_port_device_get(api_handle, DEVICE_ID, SWID, port_attr_p, &port_cnt);
    if (status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_port_device_get failed rc: [%s]\n", sx_status_str(status));
        assert(FALSE);
    }

    log_port_list_p = (sx_port_log_id_t*)calloc(port_cnt, sizeof(sx_port_log_id_t));
    assert(log_port_list_p);

    /* Make sure that we will not use invalid ports */
    for (i = 0; i < port_cnt; i++) {
        if (port_attr_p[i].port_mode == SX_PORT_MODE_EXTERNAL) {
            log_port_list_p[ports_to_set] = port_attr_p[i].log_port;
            ports_to_set++;
        }
    }

    /* make sure that ports number is valid */
    ports_to_set =
        (ports_to_set < resource_limits.lag_port_members_max) ? ports_to_set : resource_limits.lag_port_members_max;

    /* ********************************************************************************
    *  Create MAX num of LAGs for the current chip type - without member logical ports
    * ********************************************************************************/
    printf("\nCase_%u: Create MAX number (%u) of LAGs WITHOUT member logical ports.\n",
           ++test_case_id,
           resource_limits.lag_num_max);
    get_time(&start_time);

    for (i = 0; i < resource_limits.lag_num_max; i++) {
        __handle_lag_instance(api_handle, SX_ACCESS_CMD_CREATE, &lags[i]);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    /* Delete all created LAGs */
    printf("\nCase_%u: Delete MAX number (%u) of LAGs WITHOUT member logical ports.\n",
           ++test_case_id,
           resource_limits.lag_num_max);
    get_time(&start_time);

    for (i = 0; i < resource_limits.lag_num_max; i++) {
        __handle_lag_instance(api_handle, SX_ACCESS_CMD_DESTROY, &lags[i]);
    }

    get_time(&end_time);
    display_time_result(&start_time, &end_time);

    /* ********************************************************************************
    *  Create MAX num of LAGs for the current chip type - with member logical ports
    * ********************************************************************************/

    /* Go through every LAG and add/delete maximum number of member logical ports to it. */
    printf("\nCase_%u: Go through every LAG (%u) and add/delete to it relevant number of logical member ports (%u).\n",
           ++test_case_id,
           resource_limits.lag_num_max,
           ports_to_set);

    for (i = 0; i < resource_limits.lag_num_max; i++) {
        printf("\r Processing of the %u LAG ....", SX_PORT_LAG_ID_GET(lags[i]) + 1);
        fflush(stdout);

        /* create LAG and add relevant number of member ports to it */
        get_time(&start_time);
        __handle_lag_instance(api_handle, SX_ACCESS_CMD_CREATE, &lags[i]);
        __handle_lag_member_ports(api_handle, SX_ACCESS_CMD_ADD, &lags[i], log_port_list_p, ports_to_set);
        get_time(&end_time);
        create_total_time += get_time_delta(&start_time, &end_time);

        /* Delete specified LAGs */
        get_time(&start_time);
        __handle_lag_member_ports(api_handle, SX_ACCESS_CMD_DELETE, &lags[i], log_port_list_p, ports_to_set);
        __handle_lag_instance(api_handle, SX_ACCESS_CMD_DESTROY, &lags[i]);
        get_time(&end_time);
        delete_total_time += get_time_delta(&start_time, &end_time);
    }
    printf("\n");
    printf(
        "  Total time needed to create %u LAGs and add %u logical members to every of them is equal to %" PRIu64 " %s.\n",
        resource_limits.lag_num_max,
        ports_to_set,
        create_total_time,
        TIME_DIMENSION);
    printf("  Average time to create single LAG and add %u logical members to it is equal to %" PRIu64 " %s.\n",
           ports_to_set,
           (create_total_time / resource_limits.lag_num_max),
           TIME_DIMENSION);
    printf("\n");
    printf(
        "  Total time needed to delete %u LAGs and remove %u logical members for every of them is equal to %" PRIu64 " %s.\n",
        resource_limits.lag_num_max,
        ports_to_set,
        delete_total_time,
        TIME_DIMENSION);
    printf("  Average time to delete single LAG and remove %u logical members from it is equal to %" PRIu64 " %s.\n",
           ports_to_set,
           (delete_total_time / resource_limits.lag_num_max),
           TIME_DIMENSION);

    /* release all used memory */
    free(log_port_list_p);
    free(port_attr_p);
    free(lags);

    printf("\nTest is finished.\n\n");

    return 0;
}
