#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #

# script expects the following variables:
# ---------------------------------------
# switch_prepare_env parameters:
# 	PTP_MODE ==> polling | events
# 	PTP_TYPE ==> layer2 | ipv4 | ipv6
# 	PTP_LOG_PORT
# 	PTP_VLAN_ID
# 	PTP_LOCAL_ADDR
# 	PTP_NET_ADDR
# 	PTP_NET_ADDR_MASK

# netdev parameters:
# 	PTP_NET_PREFIX (should be aligned with PTP_NET_ADDR_MASK)
# 	PTP_NETDEV_NAME

# local params
#       PTP_CONFIG_TYPE ==> L2 | UDPv4 | UDPv6

if [[ ${PTP_TYPE} == "layer2" ]]; then
	PTP_CONFIG_TYPE=L2
elif [[ ${PTP_TYPE} == "ipv4" ]]; then
	PTP_CONFIG_TYPE=UDPv4
else
	PTP_CONFIG_TYPE=UDPv6
fi

> "$CONFIG_FILE_PATH"
echo "[global]"                              >> "$CONFIG_FILE_PATH"
#echo "time_stamping onestep"                >> "$CONFIG_FILE_PATH"
#echo "twoStepFlag 0"                         >> "$CONFIG_FILE_PATH"
echo "domainNumber 127"                      >> "$CONFIG_FILE_PATH" 
echo "priority1 12"                          >> "$CONFIG_FILE_PATH"
echo "priority2 128"                         >> "$CONFIG_FILE_PATH"
echo "use_syslog 1"                          >> "$CONFIG_FILE_PATH"
echo "logging_level 7"                       >> "$CONFIG_FILE_PATH"
echo "verbose       1"                       >> "$CONFIG_FILE_PATH"

echo "[" ${PTP_NETDEV_NAME} "]"              >> "$CONFIG_FILE_PATH"
echo "logAnnounceInterval -2"                >> "$CONFIG_FILE_PATH"
echo "announceReceiptTimeout 3"              >> "$CONFIG_FILE_PATH"
echo "logSyncInterval -3"                    >> "$CONFIG_FILE_PATH"
echo "logMinDelayReqInterval -3"             >> "$CONFIG_FILE_PATH"
echo "delay_mechanism P2P"                   >> "$CONFIG_FILE_PATH"
echo "network_transport " ${PTP_CONFIG_TYPE} >> "$CONFIG_FILE_PATH"
echo "fault_reset_interval -128"             >> "$CONFIG_FILE_PATH"