#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #

# script expects the following variables:
# ---------------------------------------
# switch_prepare_env parameters:
# 	PTP_MODE ==> polling | events
# 	PTP_TYPE ==> layer2 | ipv4 | ipv6
# 	PTP_TS_SRC ==> ts_linux | ts_hw_utc
# 	PTP_LOG_PORT
# 	PTP_VLAN_ID
# 	PTP_LOCAL_ADDR
# 	PTP_NET_ADDR
# 	PTP_NET_ADDR_MASK

# netdev parameters:
# 	PTP_NET_PREFIX (should be aligned with PTP_NET_ADDR_MASK)
# 	PTP_NETDEV_NAME

PTP_ROOT_DIR=`dirname $0`

export PTP_NETDEV_NAME=${PTP_NETDEV_NAME}_ptp_test
export CONFIG_FILE_PATH="/tmp/ptp4l_test.conf"

${PTP_ROOT_DIR}/build_config.sh

echo preparing PTP environment on switch
if [[ ${PTP_TYPE} == "layer2" ]]; then
	${PTP_ROOT_DIR}/switch_prepare_env/switch_prepare_env --ptp_mode=${PTP_MODE} --ptp_type=${PTP_TYPE} --ts_src=${PTP_TS_SRC} --log_port=${PTP_LOG_PORT} --vlan_id=${PTP_VLAN_ID} 
else
	${PTP_ROOT_DIR}/switch_prepare_env/switch_prepare_env --ptp_mode=${PTP_MODE} --ptp_type=${PTP_TYPE} --ts_src=${PTP_TS_SRC} --log_port=${PTP_LOG_PORT} --vlan_id=${PTP_VLAN_ID} --local_addr=${PTP_LOCAL_ADDR} --net_addr=${PTP_NET_ADDR} --net_addr_mask=${PTP_NET_ADDR_MASK} 
fi

echo creating net-device ${PTP_NETDEV_NAME}
ip link add ${PTP_NETDEV_NAME} type sx_netdev swid 0 port ${PTP_LOG_PORT}

echo set net-device admin-state up
ifconfig ${PTP_NETDEV_NAME} up

echo enabling ipv6 on net-device
if [[ ${PTP_TYPE} == "ipv6" ]]; then
	echo 0 > /proc/sys/net/ipv6/conf/${PTP_NETDEV_NAME}/disable_ipv6
fi

echo assigning address on net-device: ${PTP_LOCAL_ADDR}/${PTP_NET_PREFIX}
if [[ ${PTP_TYPE} == "ipv6" ]]; then
	ip -6 addr add ${PTP_LOCAL_ADDR}/${PTP_NET_PREFIX} dev ${PTP_NETDEV_NAME}
elif [[ ${PTP_TYPE} == "ipv4" ]]; then
	ip addr add ${PTP_LOCAL_ADDR}/${PTP_NET_PREFIX} dev ${PTP_NETDEV_NAME}
fi

sx_api_port_phys_loopback.py --force --log_port=${PTP_LOG_PORT} --loopback_type=2

sleep 3

phc_ctl ${PTP_HW_CLOCK} set $(date +%s)

echo running ptp4l
ptp4l -f ${CONFIG_FILE_PATH} -p ${PTP_HW_CLOCK} -i ${PTP_NETDEV_NAME}