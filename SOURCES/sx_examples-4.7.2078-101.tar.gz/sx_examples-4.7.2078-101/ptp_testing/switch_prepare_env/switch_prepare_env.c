/*
 * Copyright (C) 2009-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <unistd.h>
#include <getopt.h>

#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sdk/sx_api_vlan.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_api_policer.h>
#include <sx/sdk/sx_api_ptp.h>

#define ARR_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#define SX_ASSERT(status)                                                               \
    do {                                                                                \
        if ((status) != SX_STATUS_SUCCESS) {                                            \
            printf("assert [%s:%d] - %s\n", __FILE__, __LINE__, SX_STATUS_MSG(status)); \
            exit(1);                                                                    \
        }                                                                               \
    } while (0)

#define RIF_MAC_ADDR           { 0x00, 0x02, 0x03, 0x04, 0x05, 0x40 }
#define TRAP_GROUP_PTP_PACKETS (1)
#define TRAP_GROUP_PTP_FIFO    (2)
#define TRAP_GROUP_OTHER       (3)

/****************************************************************************************
* TEST CONFIG
****************************************************************************************/

enum test_ptp_type {
    TEST_PTP_TYPE_L2,
    TEST_PTP_TYPE_IPV4,
    TEST_PTP_TYPE_IPV6
};
struct test_ip_config {
    char local_addr[100];
    char net_addr[100];
    char net_addr_mask[100];
};
struct test_config {
    sx_chip_types_t              chip_type;
    sx_ptp_mode_t                ptp_mode;
    enum test_ptp_type           ptp_type;
    sx_packet_timestamp_source_e ts_src;
    sx_port_log_id_t             log_port;
    sx_vlan_id_t                 vlan_id;
    struct test_ip_config        ip_config;
} g_test_config;
enum test_param_mask {
    TEST_PARAM_MASK_PTP_MODE         = (1 << 0),
    TEST_PARAM_MASK_PTP_TYPE         = (1 << 1),
    TEST_PARAM_MASK_TIMESTAMP_SOURCE = (1 << 2),
    TEST_PARAM_MASK_LOG_PORT         = (1 << 3),
    TEST_PARAM_MASK_VLAN_ID          = (1 << 4),
    TEST_PARAM_MASK_LOCAL_ADDR       = (1 << 5),
    TEST_PARAM_MASK_NET_ADDR         = (1 << 6),
    TEST_PARAM_MASK_NET_ADDR_MASK    = (1 << 7),

    TEST_PARAM_L2_MASK_MUST = TEST_PARAM_MASK_PTP_MODE | TEST_PARAM_MASK_PTP_TYPE | TEST_PARAM_MASK_TIMESTAMP_SOURCE |
                              TEST_PARAM_MASK_LOG_PORT |
                              TEST_PARAM_MASK_VLAN_ID,
    TEST_PARAM_IP_MASK_MUST = TEST_PARAM_L2_MASK_MUST | TEST_PARAM_MASK_LOCAL_ADDR | TEST_PARAM_MASK_NET_ADDR |
                              TEST_PARAM_MASK_NET_ADDR_MASK
};

void error_and_exit(const char *argv0, const char *origin_func, int origin_line)
{
    printf("ERROR from %s:%d\n\n", origin_func, origin_line);

    printf("USAGE:\n");
    printf("%s --ptp_mode=<ptp_mode> --ptp_type=<ptp_type> --log_port=<log_port> --vlan_id=<vlan_id> "
           "[--local_addr=<local addr> --net_addr=<net_addr> --net_addr_mask=<net_addr_mask>]\n\n", argv0);
    printf("\tptp_mode = polling | events\n");
    printf("\tptp_type = layer2 | ipv4 | ipv6\n");
    printf("\tlocal_addr = ipv4/ipv6 address\n");
    printf("\tnet_addr = ipv4/ipv6 network address\n");
    printf("\tnet_addr_mask = ipv4/ipv6 network address mask\n");
    printf("\n\n");
    printf("EXAMPLE: %s --ptp_mode=events --ptp_type=ipv4 --vlan_id=3 --local_addr=10.1.1.1 "
           "--net_addr=10.1.1.0 --net_addr_mask=255.255.255.0\n\n", argv0);

    exit(1);
}

#define ERROR_AND_EXIT do { error_and_exit(argv[0], __FUNCTION__, __LINE__); } while (0)

int build_test_config(sx_api_handle_t handle, int argc, char *argv[])
{
    struct option    long_options[] = {
        { "ptp_mode", required_argument, 0, TEST_PARAM_MASK_PTP_MODE },
        { "ptp_type", required_argument, 0, TEST_PARAM_MASK_PTP_TYPE },
        { "ts_src", required_argument, 0, TEST_PARAM_MASK_TIMESTAMP_SOURCE },
        { "log_port", required_argument, 0, TEST_PARAM_MASK_LOG_PORT },
        { "vlan_id", required_argument, 0, TEST_PARAM_MASK_VLAN_ID },
        { "local_addr", required_argument, 0, TEST_PARAM_MASK_LOCAL_ADDR },
        { "net_addr", required_argument, 0, TEST_PARAM_MASK_NET_ADDR },
        { "net_addr_mask", required_argument, 0, TEST_PARAM_MASK_NET_ADDR_MASK },
        { NULL, 0, NULL, 0 }
    };
    sx_status_t      sx_st;
    sx_device_info_t dev_info;
    uint32_t         dev_info_num = 1;
    int              ret;
    int              index;
    int              option_mask = 0;

    if (argc == 0) {
        ERROR_AND_EXIT;
    }

    printf("RUNNING:\n");
    for (index = 0; index < argc; index++) {
        printf("%s ", argv[index]);
    }
    printf("\n\n");

    sx_st = sx_api_port_device_list_get(handle, &dev_info, &dev_info_num);
    if ((sx_st != SX_STATUS_SUCCESS) || (dev_info_num == 0)) {
        printf("cannot get chip type\n");
        ERROR_AND_EXIT;
    }

    g_test_config.chip_type = dev_info.dev_type;

    while (1) {
        ret = getopt_long(argc, argv, "", long_options, &index);

        switch (ret) {
        case -1: /* parsed successfully all arguments */
            goto done;

        case '?':
            ERROR_AND_EXIT;

        case TEST_PARAM_MASK_PTP_MODE:
            if (strcmp(optarg, "polling") == 0) {
                g_test_config.ptp_mode = SX_PTP_MODE_POLLING;
                printf("ptp_mode = SX_PTP_MODE_POLLING\n");
            } else if (strcmp(optarg, "events") == 0) {
                g_test_config.ptp_mode = SX_PTP_MODE_EVENTS;
                printf("ptp_mode = SX_PTP_MODE_EVENTS\n");
            } else {
                printf("invalid ptp mode\n");
                ERROR_AND_EXIT;
            }

            break;

        case TEST_PARAM_MASK_PTP_TYPE:
            if (strcmp(optarg, "layer2") == 0) {
                g_test_config.ptp_type = TEST_PTP_TYPE_L2;
                printf("ptp_type = SX_PTP_TYPE_L2\n");
            } else if (strcmp(optarg, "ipv4") == 0) {
                g_test_config.ptp_type = TEST_PTP_TYPE_IPV4;
                printf("ptp_type = SX_PTP_TYPE_IPV4\n");
            } else if (strcmp(optarg, "ipv6") == 0) {
                g_test_config.ptp_type = TEST_PTP_TYPE_IPV6;
                printf("ptp_type = SX_PTP_TYPE_IPV6\n");
            } else {
                printf("invalid ptp type\n");
                ERROR_AND_EXIT;
            }

            break;

        case TEST_PARAM_MASK_TIMESTAMP_SOURCE:
            if (strcmp(optarg, "ts_linux") == 0) {
                g_test_config.ts_src = SX_PACKET_TIMESTAMP_SOURCE_LINUX_E;
                printf("ts_src = SX_PACKET_TIMESTAMP_SOURCE_LINUX_E\n");
            } else if (strcmp(optarg, "ts_hw_utc") == 0) {
                g_test_config.ts_src = SX_PACKET_TIMESTAMP_SOURCE_HW_UTC_E;
                printf("ts_src = SX_PACKET_TIMESTAMP_SOURCE_HW_UTC_E\n");
            } else {
                printf("invalid timestamp source\n");
                ERROR_AND_EXIT;
            }

        case TEST_PARAM_MASK_LOG_PORT:
            sscanf(optarg, "0x%x", &g_test_config.log_port);
            break;

        case TEST_PARAM_MASK_VLAN_ID:
            g_test_config.vlan_id = atoi(optarg);
            if (g_test_config.vlan_id > 0xfff) {
                printf("invalid vlan id\n");
                ERROR_AND_EXIT;
            }

            break;

        case TEST_PARAM_MASK_LOCAL_ADDR:
            if ((option_mask & TEST_PARAM_MASK_PTP_TYPE) && (g_test_config.ptp_type != TEST_PTP_TYPE_L2)) {
                strcpy(g_test_config.ip_config.local_addr, optarg);
            } else {
                printf("local_addr: either 'ptp_type' is not determined before or it is L2\n");
                ERROR_AND_EXIT;
            }

            break;

        case TEST_PARAM_MASK_NET_ADDR:
            if ((option_mask & TEST_PARAM_MASK_PTP_TYPE) && (g_test_config.ptp_type != TEST_PTP_TYPE_L2)) {
                strcpy(g_test_config.ip_config.net_addr, optarg);
            } else {
                printf("local_addr: either 'ptp_type' is not determined before or it is L2\n");
                ERROR_AND_EXIT;
            }

            break;

        case TEST_PARAM_MASK_NET_ADDR_MASK:
            if ((option_mask & TEST_PARAM_MASK_PTP_TYPE) && (g_test_config.ptp_type != TEST_PTP_TYPE_L2)) {
                strcpy(g_test_config.ip_config.net_addr_mask, optarg);
            } else {
                printf("local_addr: either 'ptp_type' is not determined before or it is L2\n");
                ERROR_AND_EXIT;
            }

            break;

        default:
            ERROR_AND_EXIT;
        }

        option_mask |= ret;
    }

done:
    if (!(option_mask & TEST_PARAM_MASK_PTP_TYPE)) {
        ERROR_AND_EXIT;
    }

    if (g_test_config.ptp_type == TEST_PTP_TYPE_L2) {
        if ((option_mask & TEST_PARAM_L2_MASK_MUST) != TEST_PARAM_L2_MASK_MUST) {
            ERROR_AND_EXIT;
        }
    } else {
        if ((option_mask & TEST_PARAM_IP_MASK_MUST) != TEST_PARAM_IP_MASK_MUST) {
            ERROR_AND_EXIT;
        }
    }

    return 0;
}

void __str_to_ipv4(const char *str_ip, sx_ip_v4_addr_t *addr)
{
    addr->s_addr = ntohl(inet_addr(str_ip));
}


void __str_to_ipv6(const char *str_ip, sx_ip_v6_addr_t *addr)
{
    uint32_t *p;
    int       i;

    inet_pton(AF_INET6, str_ip, addr);
    for (i = 0; i < 4; i++) {
        p = (uint32_t*)&addr->__in6_u.__u6_addr8[i * 4];
        *p = ntohl(*p);
    }
}

sx_router_id_t __create_vrid(sx_api_handle_t sx_handle)
{
    sx_router_attributes_t router_attr;
    sx_router_id_t         vrid;
    sx_status_t            sx_status;

    memset(&router_attr, 0, sizeof(router_attr));

    if (g_test_config.ptp_type == TEST_PTP_TYPE_IPV4) {
        router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
        router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    } else { /* PTP_TYPE_IPV6 */
        router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
        router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    }

    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP;
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP;

    sx_status = sx_api_router_set(sx_handle, SX_ACCESS_CMD_ADD, &router_attr, &vrid);
    SX_ASSERT(sx_status);

    return vrid;
}


void __router_init(sx_api_handle_t sx_handle)
{
    sx_router_general_param_t   general_params;
    sx_router_resources_param_t router_resource;
    sx_status_t                 sx_status;

    memset(&general_params, 0, sizeof(general_params));
    memset(&router_resource, 0, sizeof(router_resource));

    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_resource.max_virtual_routers_num = 10;
    router_resource.max_router_interfaces = 10;
    router_resource.max_ecmp_block_size = 64;

    if (g_test_config.ptp_type == TEST_PTP_TYPE_IPV4) {
        general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
        general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
        router_resource.min_ipv4_neighbor_entries = 10;
        router_resource.min_ipv4_uc_route_entries = 10;
        router_resource.min_ipv4_mc_route_entries = 10;
        router_resource.max_ipv4_neighbor_entries = 100;
        router_resource.max_ipv4_uc_route_entries = 100;
        router_resource.max_ipv4_mc_route_entries = 100;
    } else { /* PTP_TYPE_IPV6 */
        general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
        general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
        router_resource.min_ipv6_neighbor_entries = 10;
        router_resource.min_ipv6_uc_route_entries = 10;
        router_resource.min_ipv6_mc_route_entries = 10;
        router_resource.max_ipv6_neighbor_entries = 100;
        router_resource.max_ipv6_uc_route_entries = 100;
        router_resource.max_ipv6_mc_route_entries = 100;
    }

    sx_status = sx_api_router_init_set(sx_handle, &general_params, &router_resource);
    SX_ASSERT(sx_status);
}


sx_router_interface_t __create_vlan_rif(sx_api_handle_t      sx_handle,
                                        sx_router_id_t       vrid,
                                        const sx_mac_addr_t *mac_addr,
                                        sx_vlan_id_t         vlan)
{
    sx_router_interface_param_t ifc_param;
    sx_interface_attributes_t   ifc_attr;
    sx_router_interface_t       rif;
    sx_status_t                 sx_status;

    memset(&ifc_param, 0, sizeof(ifc_param));
    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN;
    ifc_param.ifc.vlan.swid = 0;
    ifc_param.ifc.vlan.vlan = vlan;

    memset(&ifc_attr, 0, sizeof(ifc_attr));
    memcpy(ifc_attr.mac_addr.ether_addr_octet, mac_addr, sizeof(ifc_attr.mac_addr.ether_addr_octet));
    ifc_attr.mtu = 1500;
    ifc_attr.qos_mode = SX_ROUTER_QOS_MODE_NOP;
    ifc_attr.multicast_ttl_threshold = 0;
    ifc_attr.loopback_enable = 1;

    sx_status = sx_api_router_interface_set(sx_handle, SX_ACCESS_CMD_ADD, vrid, &ifc_param, &ifc_attr, &rif);
    SX_ASSERT(sx_status);

    return rif;
}


void __add_ports_to_vlan(sx_api_handle_t sx_handle, sx_port_log_id_t log_port, sx_vlan_id_t vlan)
{
    sx_vlan_ports_t vlan_port;
    sx_status_t     sx_status;

    memset(&vlan_port, 0, sizeof(vlan_port));
    vlan_port.log_port = log_port;
    vlan_port.is_untagged = SX_TAGGED_MEMBER;
    vlan_port.pass_state = SX_PORT_VLAN_BOTH_PASS_E;

    sx_status = sx_api_vlan_ports_set(sx_handle, SX_ACCESS_CMD_ADD, 0, vlan, &vlan_port, 1);
    SX_ASSERT(sx_status);
}


void __set_rif_state(sx_api_handle_t sx_handle, sx_router_interface_t rif, boolean_t enable)
{
    sx_router_interface_state_t rif_state;
    sx_status_t                 sx_status;

    memset(&rif_state, 0, sizeof(rif_state));

    if (g_test_config.ptp_type == TEST_PTP_TYPE_IPV4) {
        rif_state.ipv4_enable = (enable) ? SX_ROUTER_ENABLE_STATE_ENABLE : SX_ROUTER_ENABLE_STATE_DISABLE;
        rif_state.ipv4_mc_enable = (enable) ? SX_ROUTER_ENABLE_STATE_ENABLE : SX_ROUTER_ENABLE_STATE_DISABLE;
    } else {
        rif_state.ipv6_enable = (enable) ? SX_ROUTER_ENABLE_STATE_ENABLE : SX_ROUTER_ENABLE_STATE_DISABLE;
        rif_state.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    }

    sx_status = sx_api_router_interface_state_set(sx_handle, rif, &rif_state);
    SX_ASSERT(sx_status);
}


void __create_local_route(sx_api_handle_t       sx_handle,
                          sx_router_id_t        vrid,
                          sx_router_interface_t rif,
                          const char          * ip_addr,
                          const char          * ip_addr_mask)
{
    sx_ip_prefix_t     prefix;
    sx_uc_route_data_t route_data;
    sx_status_t        sx_status;

    memset(&route_data, 0, sizeof(route_data));
    route_data.action = SX_ROUTER_ACTION_FORWARD;
    route_data.type = SX_UC_ROUTE_TYPE_LOCAL;
    route_data.uc_route_param.local_egress_rif = rif;

    memset(&prefix, 0, sizeof(prefix));

    if (g_test_config.ptp_type == TEST_PTP_TYPE_IPV4) {
        prefix.version = SX_IP_VERSION_IPV4;
        __str_to_ipv4(ip_addr, &prefix.prefix.ipv4.addr);
        __str_to_ipv4(ip_addr_mask, &prefix.prefix.ipv4.mask);
    } else { /* TEST_PTP_TYPE_IPV6 */
        prefix.version = SX_IP_VERSION_IPV6;
        __str_to_ipv6(ip_addr, &prefix.prefix.ipv6.addr);
        __str_to_ipv6(ip_addr_mask, &prefix.prefix.ipv6.mask);
    }

    sx_status = sx_api_router_uc_route_set(sx_handle, SX_ACCESS_CMD_ADD, vrid, &prefix, &route_data);
    SX_ASSERT(sx_status);
}


void __create_ip2me_route(sx_api_handle_t       sx_handle,
                          sx_router_id_t        vrid,
                          sx_router_interface_t rif,
                          const char          * ip_addr)
{
    sx_ip_prefix_t     prefix;
    sx_uc_route_data_t route_data;
    sx_status_t        sx_status;

    memset(&route_data, 0, sizeof(route_data));
    route_data.action = SX_ROUTER_ACTION_TRAP;
    route_data.trap_attr.prio = SX_TRAP_PRIORITY_LOW;
    route_data.type = SX_UC_ROUTE_TYPE_IP2ME;
    route_data.uc_route_param.local_egress_rif = rif;

    memset(&prefix, 0, sizeof(prefix));

    if (g_test_config.ptp_type == TEST_PTP_TYPE_IPV4) {
        prefix.version = SX_IP_VERSION_IPV4;
        __str_to_ipv4(ip_addr, &prefix.prefix.ipv4.addr);
        __str_to_ipv4("255.255.255.255", &prefix.prefix.ipv4.mask);
    } else { /* TEST_PTP_TYPE_IPV6 */
        prefix.version = SX_IP_VERSION_IPV6;
        __str_to_ipv6(ip_addr, &prefix.prefix.ipv6.addr);
        __str_to_ipv6("FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF", &prefix.prefix.ipv6.mask);
    }

    sx_status = sx_api_router_uc_route_set(sx_handle, SX_ACCESS_CMD_ADD, vrid, &prefix, &route_data);
    SX_ASSERT(sx_status);
}


static void __set_policer(sx_api_handle_t sx_handle, sx_trap_group_t trap_group, int pps)
{
    sx_policer_attributes_t policer_attr;
    sx_policer_id_t         policer_id;
    sx_status_t             sx_status;

    memset(&policer_attr, 0, sizeof(policer_attr));
    policer_attr.meter_type = SX_POLICER_METER_PACKETS;
    policer_attr.cbs = 16;
    policer_attr.ebs = 16;
    policer_attr.cir = pps;
    policer_attr.yellow_action = SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR;
    policer_attr.red_action = SX_POLICER_ACTION_DISCARD;
    policer_attr.eir = pps;
    policer_attr.rate_type = SX_POLICER_RATE_TYPE_SINGLE_RATE_E;
    policer_attr.color_aware = 0;
    policer_attr.is_host_ifc_policer = 1;
    policer_attr.ir_units = SX_POLICER_IR_UNITS_10_POWER_3_E;

    sx_status = sx_api_policer_set(sx_handle, SX_ACCESS_CMD_CREATE, &policer_attr, &policer_id);
    SX_ASSERT(sx_status);

    sx_status = sx_api_host_ifc_policer_bind_set(sx_handle, SX_ACCESS_CMD_BIND, 0, trap_group, policer_id);
    SX_ASSERT(sx_status);
}


void set_group_and_traps(sx_api_handle_t handle, int group_id, sx_trap_id_t *traps_arr, int trap_arr_size)
{
    int                        i;
    sx_trap_group_attributes_t trap_group_attributes = {
        .prio = SX_TRAP_PRIORITY_HIGH,
        .truncate_mode = SX_TRUNCATE_MODE_DISABLE,
        .add_timestamp = TRUE,
        .timestamp_source = g_test_config.ts_src
    };
    sx_user_channel_t          user_channel = {
        .type = SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV,
    };
    sx_host_ifc_trap_key_t     trap_key;
    sx_host_ifc_trap_attr_t    trap_attr;

    if (sx_api_host_ifc_trap_group_set(handle, 0, group_id, &trap_group_attributes) != SX_STATUS_SUCCESS) {
        printf("maybe we're on SPC1, no HW timestamp. reconfigure trap group to Linux timestamp\n");
        trap_group_attributes.timestamp_source = 0; /* maybe on SPC1, no HW timestamp */
        sx_api_host_ifc_trap_group_set(handle, 0, group_id, &trap_group_attributes);
    }

    __set_policer(handle, group_id, 10000);

    memset(&trap_key, 0, sizeof(trap_key));
    memset(&trap_attr, 0, sizeof(trap_attr));
    trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E;
    trap_attr.attr.trap_id_attr.trap_group = group_id;
    trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU;

    for (i = 0; i < trap_arr_size; i++) {
        trap_key.trap_key_attr.trap_id = traps_arr[i];
        sx_api_host_ifc_trap_id_ext_set(handle, SX_ACCESS_CMD_SET, &trap_key, &trap_attr);
        sx_api_host_ifc_trap_id_register_set(handle, SX_ACCESS_CMD_REGISTER, 0, traps_arr[i], &user_channel);
    }
}


void __register_traps(sx_api_handle_t handle, sx_ptp_mode_t ptp_mode)
{
    sx_trap_id_t traps_events[] = {
        SX_TRAP_ID_PTP_EVENT,
        SX_TRAP_ID_PTP_GENERAL,
        SX_TRAP_ID_ETH_L2_LLDP
    };
    sx_trap_id_t traps_records[] = {
        SX_TRAP_ID_PTP_EGR_EVENT,
        SX_TRAP_ID_PTP_ING_EVENT /* must be last in the array */
    };
    sx_trap_id_t other_ipv4[] = {
        SX_TRAP_ID_ARP_REQUEST,
        SX_TRAP_ID_ARP_RESPONSE,
        SX_TRAP_ID_IP2ME,
        SX_TRAP_ID_PING_IPV4
    };
    sx_trap_id_t other_ipv6[] = {
        SX_TRAP_ID_IP2ME,
        SX_TRAP_ID_PING_IPV6,
        SX_TRAP_ID_IPV6_UNSPECIFIED_SIP,
        SX_TRAP_ID_IPV6_UNSPECIFIED_DIP,
        SX_TRAP_ID_IPV6_LINK_LOCAL_DST,
        SX_TRAP_ID_IPV6_LINK_LOCAL_SRC,
        SX_TRAP_ID_IPV6_ALL_NODES_LINK,
        SX_TRAP_ID_IPV6_ROUTER_SOLICITATION,
        SX_TRAP_ID_IPV6_ROUTER_ADVERTISEMENT,
        SX_TRAP_ID_IPV6_NEIGHBOR_SOLICITATION,
        SX_TRAP_ID_IPV6_NEIGHBOR_ADVERTISEMENT,
        SX_TRAP_ID_IPV6_REDIRECTION,
        SX_TRAP_ID_IPV6_ALL_ROUTERS_LINK
    };

    if (g_test_config.ptp_type == TEST_PTP_TYPE_IPV4) {
        set_group_and_traps(handle, TRAP_GROUP_OTHER, other_ipv4, ARR_SIZE(other_ipv4));
    } else if (g_test_config.ptp_type == TEST_PTP_TYPE_IPV6) {
        set_group_and_traps(handle, TRAP_GROUP_OTHER, other_ipv6, ARR_SIZE(other_ipv6));
    }

    set_group_and_traps(handle, TRAP_GROUP_PTP_PACKETS, traps_events, ARR_SIZE(traps_events));

    if (g_test_config.chip_type == SX_CHIP_TYPE_SPECTRUM) {
        if (ptp_mode == SX_PTP_MODE_EVENTS) {
            set_group_and_traps(handle, TRAP_GROUP_PTP_FIFO, traps_records, ARR_SIZE(traps_records));
        } else {
            set_group_and_traps(handle, TRAP_GROUP_PTP_FIFO, traps_records, ARR_SIZE(traps_records) - 1);
        }
    }
}

int main(int argc, char *argv[])
{
    sx_api_handle_t       sx_handle;
    sx_ptp_params_t       ptp_params;
    sx_status_t           sx_status;
    uint8_t               mac[] = RIF_MAC_ADDR;
    sx_router_id_t        vrid;
    sx_mac_addr_t         mac_addr;
    sx_router_interface_t rif;
    int                   err;

    sx_status = sx_api_open(NULL, &sx_handle);
    SX_ASSERT(sx_status);

    err = build_test_config(sx_handle, argc, argv);
    if (err) {
        goto out;
    }

    __add_ports_to_vlan(sx_handle, g_test_config.log_port, g_test_config.vlan_id);

    if (g_test_config.ptp_type != TEST_PTP_TYPE_L2) {
        __router_init(sx_handle);
        vrid = __create_vrid(sx_handle);

        memcpy(mac_addr.ether_addr_octet, mac, sizeof(mac_addr.ether_addr_octet));
        rif = __create_vlan_rif(sx_handle, vrid, &mac_addr, g_test_config.vlan_id);
        __set_rif_state(sx_handle, rif, 1);

        __create_local_route(sx_handle,
                             vrid,
                             rif,
                             g_test_config.ip_config.net_addr,
                             g_test_config.ip_config.net_addr_mask);
        __create_ip2me_route(sx_handle, vrid, rif, g_test_config.ip_config.local_addr);
    }

    /* let the parsing depth be 192 bytes for PTP on IPv6 */
    sx_status = sx_api_port_parsing_depth_set(sx_handle, 192);
    SX_ASSERT(sx_status);

    __register_traps(sx_handle, g_test_config.ptp_mode);

    memset(&ptp_params, 0, sizeof(ptp_params));
    ptp_params.ptp_mode = g_test_config.ptp_mode;
    sx_api_ptp_init_set(sx_handle, &ptp_params);

out:
    sx_api_close(&sx_handle);
    return err;
}
