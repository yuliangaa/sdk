This example is to set a PTP environment on a switch and start ptp4l.

On SPC1 the environment is a little bit different than on SPC2/3. Therefore, there are
two directories - spc1 and spc2_3 - that contains scripts to run the environment. Each
script is for a different protocol layer: L2, IPv4 and IPv6.

First step is to compile the 'switch_prepare_env' script:

# cd switch_prepare_env
# make

After that, the environment can be set up. For example, to run PTP-IPv4 on SPC2, do the following:

# cd spc2_3
# ./ptp_ipv4.sh

