#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


export PTP_MODE=events
export PTP_TYPE=ipv6
export PTP_TS_SRC=ts_linux
export PTP_LOG_PORT=0x10005
export PTP_VLAN_ID=1
export PTP_LOCAL_ADDR=2001:10:5:10::1
export PTP_NET_ADDR=2001:10:5:10::0
export PTP_NET_ADDR_MASK=FFFF:FFFF:FFFF:FFFF::
export PTP_NET_PREFIX=64
export PTP_NETDEV_NAME=eth5
export PTP_HW_CLOCK=/dev/ptp2

`dirname $0`/../start_ptp_on_switch.sh