#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#


basedir=`readlink -f $0`
basedir=${basedir%/*}

profile=${1:-"eth-single"}
sdk_applibs_modules=${2:-"all"}
sdk_mode=${3:-"802.1Q"}
max_vlan=${4:-"0"}
acl_search_type=${5:-"SERIAL"}
lazy_delete="${LAZY_DELETE:-1}"
echo "============== lazy_delete =  $lazy_delete ==============="
boot_mode="${BOOT_MODE:-DISABLED}"
use_internal_init_flow="${USE_INTERNAL_INIT_FLOW:-1}"
pipeline_latency_size=""
verbosity_flags=""
fatal_error_flag=""
fdb_async_mode=""
sdk_async_mode=""
sys_acl_drop_trap_en=""
pdb_lag_init=""
pdb_port_map_init=""
acl_manual_unbind=""
urmcv6_enable=""
roaming_mac_notif_en=""
cos_max_buff_mode=""
emad_timeout=""
port_profiles_num=""
port_profiles_total_memory=""
port_speed_rate_mode="${PORT_SPEED_RATE_MODE:-DEFAULT}"
use_xm=""
accuflow_max_number=""
max_bridge_opt=""
max_rifs_opt=""
module_support_type=""
fuse_enable=""
fuse_dir_path=""
enable_ib_split=""
enable_ib_router=""
health_check_log_enable=""
sdk_sys_info_path=""
transaction_mode_disable=""

if [ "${MAX_BRIDGE_NUM}" != "" ]; then
    max_bridge_opt="--max_bridge ${MAX_BRIDGE_NUM}"
fi

if [ "${MAX_PORT_ROUTER_INTERFACE_NUM}" != "" ]; then
    max_rifs_opt="--max_port_router ${MAX_PORT_ROUTER_INTERFACE_NUM}"
fi
echo "max_brdige_opt:$max_bridge_opt"
echo "max_rifs_opt:$max_rifs_opt"

if [ "${FUSE_ENABLE}" != "" ]; then
    fuse_enable="--fuse_enable"
    fuse_dir_path="--fuse_dir_path ${FUSE_DIR_PATH}"
fi

if [ "x${SDK_SYS_INFO_PATH}" != "x" ]; then
    sdk_sys_info_path="--sdk_sys_info_path ${SDK_SYS_INFO_PATH}"
else
    sdk_sys_info_path="--sdk_sys_info_path /var/log/sdk_dbg"
fi
echo "${sdk_sys_info_path}"

if [ "${ENABLE_IB_SPLIT}" != "" ]; then
    enable_ib_split="--enable_ib_split"
fi

if [ "${ENABLE_IB_ROUTER}" != "" ]; then
    enable_ib_router="--enable_ib_router"
fi

if [ "$SDK_VERBOSITY" == "no" ]; then
    verbosity_flags="--no_verbosity"
else
    if [ "$SDK_VERBOSITY" != "" ]; then
        verbosity_flags="--verbosity $SDK_VERBOSITY"
    fi
fi

kvd_flags=""
if [ "$KVD_LINEAR_SIZE" != "" ]; then
	kvd_flags+="--kvd_linear_size $KVD_LINEAR_SIZE "
fi

if [ "$KVD_SINGLE_SIZE" != "" ]; then
        kvd_flags+="--kvd_single_size $KVD_SINGLE_SIZE "
fi

if [ "$KVD_DOUBLE_SIZE" != "" ]; then
        kvd_flags+="--kvd_double_size $KVD_DOUBLE_SIZE "
fi

if [ "$FDB_ASYNC_MODE" != "" ]; then
	fdb_async_mode="--fdb_async_mode $FDB_ASYNC_MODE "
fi

if [ "$SDK_ASYNC_MODE" != "" ]; then
	sdk_async_mode="--sdk_async_mode $SDK_ASYNC_MODE "
fi

if [ "$PIPELINE_LATENCY_SIZE" != "" ]; then
        pipeline_latency_size="--pipeline_latency_size $PIPELINE_LATENCY_SIZE "
fi

if [ "$FATAL_ERROR_MODE" == "1" ]; then
        echo "============== fatal error mode is enabled ==============="
        fatal_error_flag="--fatal_error_mode "
fi

if [ "$SYS_ACL_DROP_TRAP_EN" == "1" ]; then
        echo "============== Trapping Pkts Dropped by System ACL is ON ==============="
        sys_acl_drop_trap_en="--sys_acl_drop_trap_en "
fi

if [ "$PDB_LAG_INIT" != "" ]; then
        echo "============== PDB LAG init is enabled ==============="
        pdb_lag_init="--pdb_lag_init "
fi

if [ "$PDB_PORT_MAP_INIT" != "" ]; then
        echo "============== PDB port map init is enabled ==============="
        pdb_port_map_init="--pdb_port_map_init "
fi

if [ "$ACL_MANUAL_UNBIND" != "" ]; then
        echo "============== ACL manual unbind is enabled ==============="
        acl_manual_unbind="--acl_manual_unbind "
fi

if [ "$URMCV6_ENABLE" != "" ]; then
        echo "============== URMCV6  is enabled ==============="
        urmcv6_enable="--urmcv6_enable "
fi

if [ "$MODULE_SUPPORT_TYPE" != "" ]; then
        echo "============== Module support type is set to $MODULE_SUPPORT_TYPE ==============="
        module_support_type="--module_support_type $MODULE_SUPPORT_TYPE "
fi

if [ "$ROAMING_MAC_NOTIF_EN" != "" ]; then
        echo "============== Set roaming flag is enabled ==============="
        roaming_mac_notif_en="--roaming_mac_notif_en "
fi

if [ "$COS_BUFF_MAX_MODE" != "" ]; then
        cos_max_buff_mode="--cos_max_buff_mode $COS_BUFF_MAX_MODE "
fi

if [ "$PORT_PROFILES_NUM" != "" ]; then
        port_profiles_num="--port_profiles_num $PORT_PROFILES_NUM "
fi

if [ "$PORT_PROFILES_TOTAL_MEMORY" != "" ]; then
        port_profiles_total_memory="--port_profiles_total_memory $PORT_PROFILES_TOTAL_MEMORY "
fi

if [ "$EMAD_TIMEOUT" != "" ]; then
        emad_timeout="--emad_timeout $EMAD_TIMEOUT "
fi

if [ "$USE_XM" != "" ]; then
        echo "============== USE XM is enabled ==============="
        use_xm="--use_xm "
fi
if [ "$ACCUFLOW_MAX_NUMBER" != "" ]; then
        accuflow_max_number="--accuflow_max_number $ACCUFLOW_MAX_NUMBER"
fi

if [ "$ENABLE_HEALTH_CHECK_LOG" != "" ]; then
        echo "============== health check log enabled ==============="
        health_check_log_enable="--health_check_log_enable"
fi

if [ "$TRANSACTION_MODE_DISABLE" != "" ]; then
        echo "============== Transaction Mode Disable Flag Is True ==============="
        transaction_mode_disable="--transaction_mode_disable"
fi

case ${sdk_applibs_modules} in
	"l2")
		mask=0x10f ;;
	"l2-l3")
		mask=0x11f ;;
	"l2-acl")
		mask=0x12f ;;
	"ib")
		mask=0x0f ;;
	"gw")
		mask=0xdf ;;
	"all")
		mask=0x17f ;;
	*)
		echo "no such sx sdk modules option \"${sdk_applibs_modules}\""
		exit 1
		;;
esac

wait_chassis_manager_ready() {
   while screen -ls | grep -q chassis_manager_gdb; do
        sleep 0.001
   done
}

chassis_manager_cmd="${basedir}/chassis_manager ${evb_chassis_manager_suffix} --sdk_applibs_mask ${mask} --sdk_mode ${sdk_mode} \
                                                         --max_vlan ${max_vlan} ${max_bridge_opt} ${max_rifs_opt} --acl_search_type ${acl_search_type} --lazy_delete ${lazy_delete} \
                                                         --use_internal_init_flow ${use_internal_init_flow} --boot_mode ${boot_mode} --port_speed_rate_mode ${port_speed_rate_mode} ${kvd_flags} ${pipeline_latency_size} ${fdb_async_mode} \
                                                         ${sdk_async_mode} ${verbosity_flags} ${profile} ${fatal_error_flag} ${sys_acl_drop_trap_en} \
                                                         ${pdb_lag_init} ${pdb_port_map_init} ${acl_manual_unbind} ${cos_max_buff_mode} ${urmcv6_enable} \
                                                         ${roaming_mac_notif_en} ${module_support_type} ${emad_timeout} ${accuflow_max_number}  \
                                                         ${port_profiles_num} ${port_profiles_total_memory} ${use_xm} ${fuse_enable} ${fuse_dir_path} ${enable_ib_split} ${enable_ib_router} ${health_check_log_enable} ${transaction_mode_disable} ${sdk_sys_info_path}"
if [ "${START_CHASSIS_MANAGER_WITH_GDB}" != "" ]; then
echo "========================================================================================================"
screen -dmS "chassis_manager_gdb" bash -c "${evb_chassis_manager_prefix} gdb -ex 'set pagination off' -ex=start -q -tui --args ${chassis_manager_cmd} || exit 1"
echo "Please attach GDB screen with following command below to continue"
echo "screen -r chassis_manager_gdb"
echo "========================================================================================================"
wait_chassis_manager_ready
else
${evb_chassis_manager_prefix} ${chassis_manager_cmd} || exit 1
fi