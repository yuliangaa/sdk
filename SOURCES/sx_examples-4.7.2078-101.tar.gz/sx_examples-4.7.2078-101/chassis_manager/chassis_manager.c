/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "chassis_manager.h"
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_access_register_init.h>
#include "resources_manager/resources_manager_config.h"
#include <resource_manager/resource_manager.h>

int vm_flag = FALSE;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t max_port_router_interfaces_num_is_set = FALSE;
rm_resources_t   resource_limits;

/* SDK log -> CHASSIS MANAGER log callback */
void chassis_log_cb(sx_log_severity_t severity, const char *module_name, char *msg);

enum {
    ARG_SDK_APP_ID = 1000,
    ARG_SDK_APPLIBS_MASK,
    ARG_SDK_MODE,
    ARG_CHIP_TYPE,
    ARG_MAX_DEVICE_ID,
    ARG_MAX_PHYSICAL_BITS,
    ARG_MAX_MULTIPATH_BITS,
    ARG_MAX_VEPA_BITS,
    ARG_MAX_PORTS_PER_LAG,
    ARG_DEFAULT_LAG_HASH,
    ARG_DEFAULT_VLAN,
    ARG_MSTP_MODE,
    ARG_POLICER_PRIORITY_GROUPS,
    ARG_VERBOSITY_LEVEL,
    ARG_NO_VERBOSITY,
    ARG_MAX_SWID_ID,
    ARG_MAX_ACL_RULES,
    ARG_MIN_ACL_RULES,
    ARG_MAX_VLAN,
    ARG_MAX_BRIDGE,
    ARG_MAX_PORT_ROUTER,
    ARG_ACL_SEARCH_TYPE,
    ARG_LAZY_DELETE,
    ARG_TCAM_OPT_MODE,
    ARG_TCAM_OPT_MODE_PARAM,
    ARG_KVD_LINEAR_SIZE,
    ARG_KVD_SINGLE_SIZE,
    ARG_KVD_DOUBLE_SIZE,
    ARG_PIPELINE_LATENCY_SIZE,
    ARG_QINIQ_PRIO_TAG_MODE,
    ARG_USE_INTERNAL_INIT_FLOW,
    ARG_BOOT_MODE,
    ARG_FATAL_ERROR_MODE,
    ARG_FDB_ASYNC_MODE,
    ARG_SDK_ASYNC_MODE,
    ARG_SYS_ACL_DROP_TRAP_EN,
    ARG_PDB_LAG_INIT,
    ARG_PDB_PORT_MAPPING_INIT,
    ARG_ACL_MANUAL_UNBIND,
    ARG_URMCV6_ENABLE,
    ARG_ROAMNG_MAC_NOTIF_EN,
    ARG_COS_MAX_BUFFER_MODE,
    ARG_EMAD_TIMEOUT,
    ARG_PORT_PROFILES_NUM,
    ARG_PORT_PROFILES_TOTAL_MEMORY,
    ARG_PORT_SPEED_RATE_MODE,
    ARG_USE_XM,
    ARG_ACCUFLOW_MAX_NUMBER,
    ARG_MODULE_SUPPORT_TYPE,
    ARG_FUSE_ENABLE,
    ARG_FUSE_DIR_PATH,
    ARG_IB_ENABLE_SPLIT,
    ARG_IB_ENABLE_ROUTER,
    ARG_HEALTH_CHECK_LOG_ENABLE,
    ARG_TRANSACTION_MODE_DISABLE,
    ARG_SDK_SYS_INFO_PATH,
};

static struct option long_options[] = {
    {"sdk_app_id",                  required_argument,  NULL,   ARG_SDK_APP_ID                  },
    {"sdk_applibs_mask",            required_argument,  NULL,   ARG_SDK_APPLIBS_MASK            },
    {"sdk_mode",                    required_argument,  NULL,   ARG_SDK_MODE                    },
    {"chip_type",                   required_argument,  NULL,   ARG_CHIP_TYPE                   },
    {"max_device_id",               required_argument,  NULL,   ARG_MAX_DEVICE_ID               },
    {"max_physical_bits",           required_argument,  NULL,   ARG_MAX_PHYSICAL_BITS           },
    {"max_multipath_bits",          required_argument,  NULL,   ARG_MAX_MULTIPATH_BITS          },
    {"max_vepa_bits",               required_argument,  NULL,   ARG_MAX_VEPA_BITS               },
    {"max_ports_per_lag",           required_argument,  NULL,   ARG_MAX_PORTS_PER_LAG           },
    {"default_lag_hash",            required_argument,  NULL,   ARG_DEFAULT_LAG_HASH            },
    {"default_vlan",                required_argument,  NULL,   ARG_DEFAULT_VLAN                },
    {"mstp_mode",                   required_argument,  NULL,   ARG_MSTP_MODE                   },
    {"policer_priority_groups",     required_argument,  NULL,   ARG_POLICER_PRIORITY_GROUPS     },
    {"verbosity_level",             required_argument,  NULL,   ARG_VERBOSITY_LEVEL             },
    {"no_verbosity",                no_argument,        NULL,   ARG_NO_VERBOSITY                },
    {"max_swid_id",                 required_argument,  NULL,   ARG_MAX_SWID_ID                 },
    {"max_acl_rules",               required_argument,  NULL,   ARG_MAX_ACL_RULES,              },
    {"min_acl_rules",               required_argument,  NULL,   ARG_MIN_ACL_RULES,              },
    {"max_vlan",                    required_argument,  NULL,   ARG_MAX_VLAN,                   },
    {"max_bridge",                  required_argument,  NULL,   ARG_MAX_BRIDGE,                 },
    {"max_port_router",             required_argument,  NULL,   ARG_MAX_PORT_ROUTER,            },
    {"acl_search_type",             required_argument,  NULL,   ARG_ACL_SEARCH_TYPE             },
    {"lazy_delete",                 required_argument,  NULL,   ARG_LAZY_DELETE                 },
    {"tcam_opt_mode",               required_argument,  NULL,   ARG_TCAM_OPT_MODE               },
    {"tcam_opt_mode_param",         required_argument,  NULL,   ARG_TCAM_OPT_MODE_PARAM         },
    {"kvd_linear_size",             required_argument,  NULL,   ARG_KVD_LINEAR_SIZE,            },
    {"kvd_single_size",             required_argument,  NULL,   ARG_KVD_SINGLE_SIZE,            },
    {"kvd_double_size",             required_argument,  NULL,   ARG_KVD_DOUBLE_SIZE,            },
    {"pipeline_latency_size",       required_argument,  NULL,   ARG_PIPELINE_LATENCY_SIZE,      },
    {"qinq_prio_tag_mode",          required_argument,  NULL,   ARG_QINIQ_PRIO_TAG_MODE,        },
    {"use_internal_init_flow",      required_argument,  NULL,   ARG_USE_INTERNAL_INIT_FLOW,     },
    {"boot_mode",                   required_argument,  NULL,   ARG_BOOT_MODE,                  },
    {"fatal_error_mode",            no_argument,        NULL,   ARG_FATAL_ERROR_MODE            },
    {"fdb_async_mode",              required_argument,  NULL,   ARG_FDB_ASYNC_MODE,             },
    {"sdk_async_mode",              required_argument,  NULL,   ARG_SDK_ASYNC_MODE,             },
    {"sys_acl_drop_trap_en",        no_argument,        NULL,   ARG_SYS_ACL_DROP_TRAP_EN,       },
    {"pdb_lag_init",                no_argument,        NULL,   ARG_PDB_LAG_INIT,               },
    {"pdb_port_map_init",           no_argument,        NULL,   ARG_PDB_PORT_MAPPING_INIT,      },
    {"acl_manual_unbind",           no_argument,        NULL,   ARG_ACL_MANUAL_UNBIND,          },
    {"urmcv6_enable",               no_argument,        NULL,   ARG_URMCV6_ENABLE,              },
    {"roaming_mac_notif_en",        no_argument,        NULL,   ARG_ROAMNG_MAC_NOTIF_EN,        },
    {"cos_max_buff_mode",           required_argument,  NULL,   ARG_COS_MAX_BUFFER_MODE,        },
    {"emad_timeout",                required_argument,  NULL,   ARG_EMAD_TIMEOUT,               },
    {"port_profiles_num",           required_argument,  NULL,   ARG_PORT_PROFILES_NUM,          },
    {"port_profiles_total_memory",  required_argument,  NULL,   ARG_PORT_PROFILES_TOTAL_MEMORY, },
    {"port_speed_rate_mode",        required_argument,  NULL,   ARG_PORT_SPEED_RATE_MODE,       },
    {"accuflow_max_number",         required_argument,  NULL,   ARG_ACCUFLOW_MAX_NUMBER         },
    {"use_xm",                      no_argument,        NULL,   ARG_USE_XM,                     },
    {"module_support_type",         required_argument,  NULL,   ARG_MODULE_SUPPORT_TYPE,        },
    {"fuse_enable",                 no_argument,        NULL,   ARG_FUSE_ENABLE,                },
    {"fuse_dir_path",               required_argument,  NULL,   ARG_FUSE_DIR_PATH,              },
    {"enable_ib_split",             no_argument,        NULL,   ARG_IB_ENABLE_SPLIT,            },
    {"enable_ib_router",            no_argument,        NULL,   ARG_IB_ENABLE_ROUTER,           },
    {"health_check_log_enable",     no_argument,        NULL,   ARG_HEALTH_CHECK_LOG_ENABLE,    },
    {"transaction_mode_disable",     no_argument,        NULL,   ARG_TRANSACTION_MODE_DISABLE,  },
    {"sdk_sys_info_path",           required_argument,  NULL,   ARG_SDK_SYS_INFO_PATH,          },
    {"help",                        no_argument,        NULL,   'h'                             },
    {0,                             0,                  0,      0                               },
};
static inline void __show_help()
{
    printf("\tNVIDIA Switch SDK - Chassis Manager example.\n"
           "\t===============================================\n"
           "\tUsage: chassis_manager [options] <profile type>\n\n"
           "\t<profile type> - Set profile type to: eth-single|eth-multi|ib-single|ib-multi|vpi-single|vpi-multi.\n"
           "\tOptions:\n"
           "\t--sdk_app_id <app id>                                                    SDK     - Application ID\n"
           "\t--sdk_applibs_mask <applibs mask>                                        SDK     - Application libraries\n"
           "\t    bitwise OR of {L2=0x01, L3=0x02, ACL=0x04}\n"
           "\t--sdk_mode <802.1Q | 802.1D | HYBRID>                                    SDK     - SDK mode\n"
           "\t--chip_type <SWITCHX_A1 | SWITCHX_A2 | SWITCH_IB | SPECTRUM>             SDK     - Chip type\n"
           "\t--max_device_id <max device id>                                          PORT    - Max device ID\n"
           "\t--max_physical_bits <max port physical bits>                             PORT    - Max port physical bits\n"
           "\t--max_multipath_bits <max multipath bits>                                PORT    - Max multipath bits\n"
           "\t--max_vepa_channel_bits <max vepa channel bits>                          PORT    - Max vepa channel bits\n"
           "\t--max_ports_per_lag <ports number>                                       LAG     - Max ports per LAG\n"
           "\t--default_lag_hash <lag_hash>                                            LAG     - LAG hash\n"
           "\t--default_vlan <vlan number>                                             VLAN    - Default VLAN\n"
           "\t--max_vlan <max number of .1Q vlans (Supported devices: Spectrum)>       VLAN    - Number of VLANs\n"
           "\t--max_bridge <max number of bridges (Supported devices: Spectrum)>       BRIDGE  - number of bridges\n"
           "\t--max_rifs <max number of port routers (Supported devices: Spectrum)>    ROUTER  - number of sub port rifs\n"
           "\t--mstp_mode <0=NONE, 1=MSTP, 2=RSTP>                                     MSTP    - Active mode\n"
           "\t--policer_priority_groups <num of groups>                                POLICER - Priority groups\n"
           "\t--verbosity_level <NONE=0,ERROR=1,WARNING=2,INFO=3,                      SDK     - Verbosity level\n"
           "\t    VERBOSE=4,DEBUG=5,ALL=6>\n"
           "\t--acl_search_type <SERIAL, PARALLEL>                                     ACL     - ACL search type, default is serial\n"
           "\t--tcam_opt_mode <DYNAMIC=0, STATIC=1, DISABLED=2>                        SDK     - TCAM optimization mode, default=DYNAMIC\n"
           "\t--tcam_opt_mode_param <NONE=0, 64B=1, 128B=2, 256B=3, 512B=4, 1024=5>    SDK     - TCAM optimization mode parameter, default=NONE\n"
           "\t--kvd_linear_size <size>                                                 SDK     - KVD linear size\n"
           "\t--kvd_single_size <size>                                                 SDK     - KVD single hash size\n"
           "\t--kvd_double_size <size>                                                 SDK     - KVD double hash size\n"
           "\t--pipeline_latency_size <size>                                           SDK     - Shared buffer pipeline latency size, default=217 (in cells)\n"
           "\t--qinq_prio_tag_mode <PUSH=0, OVERWRITE=1>                               SDK     - QinQ ingress priority tag processing mode \n"
           "\t--no-verbosity                                                           SDK     - Do not set log verbosity in SDK\n"
           "\t--use_internal_init_flow <0=No, 1=Yes>                                   SDK     - Determines if to run resources-manager externally or within SDK\n"
           "\t--boot_mode <NORMAL | FAST | ISSU_NORMAL | ISSU_FAST | ISSU_STARTED>     SDK     - Set fast-boot and/or ISSU mode\n"
           "\t--fatal_error_mode                                                       SDK     - Fatal Error mode\n"
           "\t--fdb_async_mode                                                         SDK     - FDB Async mode\n"
           "\t--pdb_lag_init                                                           SDK     - PDB LAG Init mode\n"
           "\t--acl_manual_unbind                                                      ACL     - Enable/Disable acl manually unbinding when binding point removed\n"
           "\t--urmcv6_enable                                                          FDB     - Enable Unregister MC IPv6 separate vector \n"
           "\t--roaming_mac_notif_en                                                   FDB     - FDB notification will provide roaming flag \n"
           "\t--pdb_port_map_init                                                      SDK     - PDB port map Init mode\n"
           "\t--cos_max_buff_mode <0=GUARANTEED, 1=TOTAL>                              COS     - Cos Init max buff mode\n"
           "\t--emad_timeout <emad timeout time in microseconds>                       SDK     - EMAD timeout time in microseconds\n"
           "\t--accuflow_max_number <1..400>                                           SDK     - Maximum number of accumulated counter-sets, default=400 (in K (1024) units)\n"
           "\t--port_profiles_num                                                      SDK     - Number of port profiles\n"
           "\t--port_profiles_total_memory                                             SDK     - Size of memory allocated for port profile in 4KB pages. default=64\n"
           "\t--port_speed_rate_mode <DEFAULT | SPEED | RATE>                          SDK     - Use port_admin_speed / port_rate set / get\n"
           "\t--use_xm                                                                 SDK     - Use external memory (Pitbull)\n"
           "\t--module_support_type <DEPENDENT | INDEPENDENT | STANDALONE>             SDK     - Configure module support type in SDK\n"
           "\t--fuse_enable                                                            SDK     - Enable FUSE debug dump\n"
           "\t--fuse_dir_path                                                          SDK     - FUSE debug dump mount directory\n"
           "\t--enable_ib_split                                                        SDK     - Configure switch profile with split_en\n"
           "\t--enable_ib_router                                                       SDK     - Configure switch profile with ib_rtr_en\n"
           "\t--health_check_log_enable                                                SDK     - Enable host ifc health check event deparse and log\n"
           "\t--sdk_sys_info_path                                                      SDK     - SDK information files directories\n"
           "\t--transaction_mode_disable                                               SDK     - Disable transaction mode, Default is enable\n"
           "\t(-h|--help)                                                              HELP    - Show this help message and exit\n");
    exit(0);
}

static inline void __show_error()
{
    SX_LOG_ERR("Bad parameter(s). Use --help to get parameters summary\n");
    exit(1);
}

static sx_status_t __check_port_router_num_range(enum sxd_chip_types chip_type, uint32_t port_router_interfaces_num)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    if ((chip_type == SXD_CHIP_TYPE_SPECTRUM) ||
        (chip_type == SXD_CHIP_TYPE_SPECTRUM_A1)) {
        if (port_router_interfaces_num > 1000) {
            status = SX_STATUS_PARAM_ERROR;
        }
    } else if ((chip_type == SXD_CHIP_TYPE_SPECTRUM4) || (chip_type == SXD_CHIP_TYPE_SPECTRUM5)) {
        /* SPC4: max_router_interface may now be limited to 4000, here is 8000 for CI test, to be checked in SPC4 implementations */
        if (port_router_interfaces_num > 8000) {
            status = SX_STATUS_PARAM_ERROR;
        }
    } else {
        if (port_router_interfaces_num > 4000) {
            status = SX_STATUS_PARAM_ERROR;
        }
    }
    return status;
}

static inline void __sdk_default_params(sx_api_sx_sdk_init_t *param)
{
    /* General defaults */
    param->app_id = htonl(*((uint32_t*)"SDK1"));

    /* Policer defaults */
    param->policer_params.priority_group_num = 3;

    /* Port defaults */
    param->port_params.max_dev_id = SX_DEV_ID_MAX;

    /* Topo defaults */
    param->topo_params.max_num_of_tree_per_chip = 18; /* MAX num of trees */

    /* LAG defaults */
    param->lag_params.max_ports_per_lag = 0;
    param->lag_params.default_lag_hash = SX_LAG_DEFAULT_LAG_HASH;

    /* VLAN defaults */
    param->vlan_params.def_vid = SX_VLAN_DEFAULT_VID;
    param->vlan_params.max_swid_id = 0;
    param->vlan_params.num_of_active_vlans = 0;

    /* FDB defaults */
    param->fdb_params.max_mc_group = SX_FDB_MAX_MC_GROUPS;

    /* MSTP defaults */
    param->mstp_params.mode = SX_MSTP_MODE_MSTP;

    /* Router defaults */
    param->router_profile_params.min_router_counters = 16;

    /* ACL defaults */
    param->acl_params.max_swid_id = 0;
    param->acl_params.max_acl_ingress_groups = 95;
    param->acl_params.max_acl_egress_groups = 31;
    param->acl_params.acl_search_type = SX_API_ACL_SEARCH_TYPE_SERIAL;
    param->acl_params.min_acl_rules = 0;
    param->acl_params.max_acl_rules = 0;
    param->acl_params.acl_manual_unbind = FALSE;

    /* Bridge defaults */
    param->bridge_init_params.sdk_mode = SX_MODE_802_1Q;
    param->bridge_init_params.sdk_mode_params.mode_1D.max_bridge_num = 512;
    param->bridge_init_params.sdk_mode_params.mode_1D.max_virtual_ports_num = 512;
    param->bridge_init_params.sdk_mode_params.mode_1D.multiple_vlan_bridge_mode =
        SX_BRIDGE_MULTIPLE_VLAN_MODE_HOMOGENOUS;
    param->bridge_init_params.sdk_mode_params.mode_hybrid.max_bridge_num = 512;

    /* TCAM defaults */
    param->tcam_opt_params.tcam_opt_mode = SX_TCAM_OPT_MODE_DYNAMIC;
    param->tcam_opt_params.tcam_opt_mode_param = SX_TCAM_OPT_MODE_PARAM_NONE;

    /* GC defaults */
    param->gc_params.disable_sw_lazy_delete = FALSE;

    /* Boot mode defaults */
    param->boot_mode_params.boot_mode = SX_BOOT_MODE_DISABLED_E;
    param->boot_mode_params.pdb_lag_init = FALSE;
    param->boot_mode_params.pdb_port_map_init = FALSE;
    param->boot_mode_params.use_xm = FALSE;
    param->router_params.max_port_router_interfaces_num = 0;
    max_port_router_interfaces_num_is_set = FALSE;
    /* Flow counter defaults */
    /* Note: Defaults can be reset by the user's input and later
     *       by the function that validates chip's capabilities.
     *       See: __sdk_default_params_by_chip()
     */
    param->flow_counter_params.flow_counter_accumulated_type_max_number = 400;
}

static inline void __sdk_default_params_by_chip(sx_api_sx_sdk_init_t *param, sx_chip_types_t chip_type)
{
    uint8_t port_phy_bits_num;
    uint8_t port_pth_bits_num;
    uint8_t port_sub_bits_num;

    param->profile.chip_type = (enum sxd_chip_types)chip_type;

    if ((param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM) ||
        (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM_A1) ||
        (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM2) ||
        (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM3) ||
        (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM4) ||
        (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM5)) {
        port_phy_bits_num = SX_PORT_UCR_ID_PHY_NUM_OF_BITS;
        port_pth_bits_num = 16;
        port_sub_bits_num = 0;

        param->acl_params.max_swid_id = 0;
    } else {
        port_phy_bits_num = SX_PORT_UCR_ID_PHY_NUM_OF_BITS;
        port_pth_bits_num = 6;
        port_sub_bits_num = 4;
    }

    if ((param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM2) ||
        (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM3) ||
        (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM4) ||
        (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM5)) {
        param->acl_params.min_acl_rules = 0;
    }

    if (param->acl_params.max_acl_rules == 0) {
        if ((param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM2) ||
            (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM3) ||
            (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM4) ||
            (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM5)) {
            param->acl_params.max_acl_rules = 240000;
        } else {
            param->acl_params.max_acl_rules = 18000;
        }
    }

    param->flow_counter_params.flow_counter_byte_type_min_number = 0;
    param->flow_counter_params.flow_counter_packet_type_min_number = 0;
    if ((param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM) ||
        (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM_A1)) {
        /* Set default MAX values */
        param->flow_counter_params.flow_counter_byte_type_max_number = 8000;
        param->flow_counter_params.flow_counter_packet_type_max_number = 8000;

        /* We override default values because AccuFlow counters are not supported
         * by Spectrum or Spectrum_A1 */
        param->flow_counter_params.flow_counter_accumulated_type_max_number = 0;
    } else if ((param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM2) ||
               (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM3) ||
               (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM4) ||
               (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM5)) {
        /* Max number of flow counters is 40K.
         * For the first stage we are decreasing it by 10% for internal usage.
         * This limit should be removed afterwards
         */
        param->flow_counter_params.flow_counter_byte_type_max_number = 18000;
        param->flow_counter_params.flow_counter_packet_type_max_number = 18000;
        /* AccuFlow counters are not supported by spectrum5*/
        if (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM5) {
            param->flow_counter_params.flow_counter_accumulated_type_max_number = 0;
        }

        /* Note: Here we do not change AccuFlow parameters. They were configured with
         *       default values in the __sdk_default_params(). If user provided other
         *       values for them, they will override default ones.
         */
    } else {
        /* Set default MAX values */
        param->flow_counter_params.flow_counter_byte_type_max_number = 100;
        param->flow_counter_params.flow_counter_packet_type_max_number = 155;

        /* We override default values because AccuFlow counters are not supported
         * by SwitchX, Quantum and others */
        param->flow_counter_params.flow_counter_accumulated_type_max_number = 0;
    }

    if (param->port_params.port_phy_bits_num == 0) {
        param->port_params.port_phy_bits_num = port_phy_bits_num;
    }

    if (param->port_params.port_pth_bits_num == 0) {
        param->port_params.port_pth_bits_num = port_pth_bits_num;
    }

    if (param->port_params.port_sub_bits_num == 0) {
        param->port_params.port_sub_bits_num = port_sub_bits_num;
    }

    switch (param->bridge_init_params.sdk_mode) {
    case SX_MODE_802_1Q:
        break;

    case SX_MODE_802_1D:
        param->bridge_init_params.sdk_mode_params.mode_1D.max_bridge_num = 512;
        param->bridge_init_params.sdk_mode_params.mode_1D.max_virtual_ports_num = 512;
        param->bridge_init_params.sdk_mode_params.mode_1D.multiple_vlan_bridge_mode =
            SX_BRIDGE_MULTIPLE_VLAN_MODE_HOMOGENOUS;
        break;

    case SX_MODE_HYBRID:
        break;

    default:
        SX_LOG_ERR("sdk mode unsupported.\n");
    }

    /* consider SPC4 default port_router_interface_num same as SPC2/3 */
    if (!max_port_router_interfaces_num_is_set) {
        if ((param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM4) ||
            (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM5)) {
            if (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM4) {
                param->router_params.max_port_router_interfaces_num = resource_limits.router_rifs_max;
            } else {
                param->router_params.max_port_router_interfaces_num = 3000;
            }
            if ((param->boot_mode_params.boot_mode == SX_BOOT_MODE_ISSU_NORMAL_E) ||
                (param->boot_mode_params.boot_mode == SX_BOOT_MODE_ISSU_FAST_E) ||
                (param->boot_mode_params.boot_mode == SX_BOOT_MODE_ISSU_STARTED_E)) {
                param->router_params.max_port_router_interfaces_num = 2000;
                if (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM5) {
                    param->router_params.max_port_router_interfaces_num = 1000;
                    param->vlan_params.num_of_active_vlans = 2000;
                }
            }
        }
    }

    if (param->profile.chip_type == SXD_CHIP_TYPE_SPECTRUM) {
        if ((param->boot_mode_params.boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) ||
            (param->boot_mode_params.boot_mode == SX_BOOT_MODE_ISSU_FAST_E) ||
            (param->boot_mode_params.boot_mode == SX_BOOT_MODE_ISSU_NORMAL_E)) {
            param->acl_params.max_acl_ingress_groups = 100;
            param->acl_params.max_acl_egress_groups = 100;
        } else {
            param->acl_params.max_acl_ingress_groups = 200;
            param->acl_params.max_acl_egress_groups = 200;
        }
    }

    /* Set the correct default number of MC group (depends on bridge mode)
     *  and the max number of VLAN groups.
     *  The max MC group = PGT size - flooding table size for VLAN (for DOT1Q bridge mode)
     *  and for other modes max MC group = PGT size - flooding table size for every VLAN - flooding table size for every FID
     */

    switch (param->profile.chip_type) {
    case SXD_CHIP_TYPE_SPECTRUM:
    case SXD_CHIP_TYPE_SPECTRUM_A1:
        param->fdb_params.max_mc_group = (param->bridge_init_params.sdk_mode == SX_MODE_802_1Q) ? 14851 : 16384;
        param->acl_params.max_vlan_groups = 127;
        break;

    case SXD_CHIP_TYPE_SPECTRUM2:
    case SXD_CHIP_TYPE_SPECTRUM3:
    case SXD_CHIP_TYPE_SPECTRUM4:
    case SXD_CHIP_TYPE_SPECTRUM5:
        param->fdb_params.max_mc_group = 0;
        param->acl_params.max_vlan_groups = 127;
        break;

    case SXD_CHIP_TYPE_SWITCHX_A0:
    case SXD_CHIP_TYPE_SWITCHX_A1:
    case SXD_CHIP_TYPE_SWITCHX_A2:
        param->fdb_params.max_mc_group = 7000;
        param->acl_params.max_vlan_groups = 127;
        break;

    default:
        param->fdb_params.max_mc_group = 0;
        param->acl_params.max_vlan_groups = 0;
        break;
    }
}

int main(int argc, char **argv)
{
    sx_api_handle_t          handle = SX_API_INVALID_HANDLE;
    sx_api_sx_sdk_init_t     sdk_init_params;
    sx_verbosity_level_t     verbosity_level = SX_VERBOSITY_LEVEL_NOTICE;
    boolean_t                set_verbosity = TRUE;
    int                      c, ret = 0;
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_device_hw_info_t      dev_hw_info;
    enum sxd_chip_types      chip_type;
    boolean_t                set_linear = FALSE;
    uint32_t                 kvd_linear_size = 0;
    boolean_t                set_single = FALSE;
    uint32_t                 kvd_single_size = 0;
    boolean_t                set_double = FALSE;
    uint32_t                 kvd_double_size = 0;
    uint32_t                 pipeline_latency_size = 0;
    uint32_t                 qinq_prio_tag_mode = 0;
    boolean_t                fatal_error_mode = FALSE;
    uint32_t                 fdb_async_mode = 0;
    boolean_t                sys_acl_drop_trap_en = FALSE;
    sx_cos_max_buffer_mode_t cos_init_max_buff_mode = SX_COS_MAX_BUFFER_CAP_GUARANTEED_E;
    uint32_t                 emad_timeout = 0;
    uint8_t                  port_profiles_num = 0;
    uint16_t                 port_profiles_total_memory = 0;
    uint32_t                 accuflow_max_number = 0;
    boolean_t                ib_split_en = FALSE;
    boolean_t                ib_rtr_en = FALSE;
    boolean_t                use_internal_init_flow = FALSE;
    boolean_t                health_check_log_enable = FALSE;
    boolean_t                transaction_mode_disable = FALSE;
    sys_type_t               sys_type = SYS_TYPE_EN;

    sx_log_init(TRUE, NULL, chassis_log_cb);

    /* open api to SDK */
    err = sx_api_open(chassis_log_cb, &handle);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to open SX-API (%s)\n", sx_status_str(err));
        goto out;
    }

    err = sx_api_device_hw_info_get(handle, &dev_hw_info);
    if (err != SX_STATUS_SUCCESS) {
        switch (err) {
        case SX_STATUS_FW_INIT_FAILURE:
            SX_LOG_ERR("FW initialization failure\n");
            break;

        case SX_STATUS_DEVICE_UNRECOVERABLE:
            SX_LOG_ERR("Device is in unrecoverable state\n");
            break;

        default:
            SX_LOG_ERR("Failed to get device HW information (%s)\n", sx_status_str(err));
            break;
        }

        goto out;
    }

    chip_type = (enum sxd_chip_types)dev_hw_info.chip_type;

    memset(&resource_limits, 0, sizeof(resource_limits));

    err = rm_chip_limits_get(dev_hw_info.chip_type, &resource_limits);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("ERROR: SDK API rm_chip_limits_get failed: [%s]\n", sx_status_str(err));
        goto out;
    }

    memset(&sdk_init_params, 0, sizeof(sdk_init_params));

    /* Fill SDK default options . */
    __sdk_default_params(&sdk_init_params);

    while (1) {
        int option_index = 0;

        c = getopt_long(argc, argv, "h", long_options, &option_index);

        /* Detect the end of the options. */
        if (c == -1) {
            break;
        }

        switch (c) {
        case ARG_SDK_APP_ID:
            ret = sscanf(optarg, "%u", &(sdk_init_params.app_id));
            break;

        case ARG_SDK_APPLIBS_MASK:
            ret = sscanf(optarg, "%x", &(sdk_init_params.applibs_mask));
            break;

        case ARG_CHIP_TYPE:
            if (!strcmp(optarg, "SWITCHX_A1")) {
                chip_type = SXD_CHIP_TYPE_SWITCHX_A1;
            } else if (!strcmp(optarg, "SWITCHX_A2")) {
                chip_type = SXD_CHIP_TYPE_SWITCHX_A2;
            } else if (!strcmp(optarg, "SWITCH_IB")) {
                chip_type = SXD_CHIP_TYPE_SWITCH_IB;
                sys_type = SYS_TYPE_IB;
            } else if (!strcmp(optarg, "SPECTRUM")) {
                chip_type = SXD_CHIP_TYPE_SPECTRUM;
            } else if (!strcmp(optarg, "SPECTRUM_A1")) {
                chip_type = SXD_CHIP_TYPE_SPECTRUM_A1;
            } else if (!strcmp(optarg, "SPECTRUM2")) {
                chip_type = SXD_CHIP_TYPE_SPECTRUM2;
            } else if (!strcmp(optarg, "QUANTUM")) {
                chip_type = SXD_CHIP_TYPE_QUANTUM;
                sys_type = SYS_TYPE_IB;
            } else if (!strcmp(optarg, "QUANTUM2")) {
                chip_type = SXD_CHIP_TYPE_QUANTUM2;
                sys_type = SYS_TYPE_IB;
            } else if (!strcmp(optarg, "QUANTUM3")) {
                chip_type = SXD_CHIP_TYPE_QUANTUM3;
                sys_type = SYS_TYPE_IB;
            } else if (!strcmp(optarg, "SPECTRUM3")) {
                chip_type = SXD_CHIP_TYPE_SPECTRUM3;
            } else if (!strcmp(optarg, "SPECTRUM4")) {
                chip_type = SXD_CHIP_TYPE_SPECTRUM4;
            } else if (!strcmp(optarg, "SPECTRUM5")) {
                chip_type = SXD_CHIP_TYPE_SPECTRUM5;
            } else {
                SX_LOG_ERR("Unsupported chip type : %s \n", optarg);
                goto out;
            }
            break;

        case ARG_SDK_MODE:
            if (!strcmp(optarg, "802.1Q")) {
                sdk_init_params.bridge_init_params.sdk_mode = SX_MODE_802_1Q;
            }
            if (!strcmp(optarg, "802.1D")) {
                sdk_init_params.bridge_init_params.sdk_mode = SX_MODE_802_1D;
            }
            if (!strcmp(optarg, "HYBRID") && ((chip_type == SXD_CHIP_TYPE_SPECTRUM) ||
                                              (chip_type == SXD_CHIP_TYPE_SPECTRUM_A1) ||
                                              (chip_type == SXD_CHIP_TYPE_SPECTRUM2) ||
                                              (chip_type == SXD_CHIP_TYPE_SPECTRUM3) ||
                                              (chip_type == SXD_CHIP_TYPE_SPECTRUM4) ||
                                              (chip_type == SXD_CHIP_TYPE_SPECTRUM5))) {
                sdk_init_params.bridge_init_params.sdk_mode = SX_MODE_HYBRID;
            }
            break;

        case ARG_MAX_ACL_RULES:
            ret = sscanf(optarg, "%u", &(sdk_init_params.acl_params.max_acl_rules));
            break;

        case ARG_MIN_ACL_RULES:
            ret = sscanf(optarg, "%u", &(sdk_init_params.acl_params.min_acl_rules));
            break;

        case ARG_ACL_SEARCH_TYPE:
            if (!strcmp(optarg, "SERIAL")) {
                sdk_init_params.acl_params.acl_search_type = SX_API_ACL_SEARCH_TYPE_SERIAL;
            } else if (!strcmp(optarg, "PARALLEL")) {
                sdk_init_params.acl_params.acl_search_type = SX_API_ACL_SEARCH_TYPE_PARALLEL;
            } else {
                SX_LOG_ERR("Unsupported search type : %s \n", optarg);
                goto out;
            }

            break;

        case ARG_LAZY_DELETE:
            if (!strcmp(optarg, "1")) {
                sdk_init_params.gc_params.disable_sw_lazy_delete = FALSE;
            } else {
                sdk_init_params.gc_params.disable_sw_lazy_delete = TRUE;
            }

            break;

        case ARG_MAX_DEVICE_ID:
            ret = sscanf(optarg, "%hhu", &(sdk_init_params.port_params.max_dev_id));
            break;

        case ARG_MAX_PHYSICAL_BITS:
            ret = sscanf(optarg, "%hhu", &(sdk_init_params.port_params.port_phy_bits_num));
            break;

        case ARG_MAX_MULTIPATH_BITS:
            ret = sscanf(optarg, "%hhu", &(sdk_init_params.port_params.port_pth_bits_num));
            break;

        case ARG_MAX_VEPA_BITS:
            ret = sscanf(optarg, "%hhu", &(sdk_init_params.port_params.port_sub_bits_num));
            break;

        case ARG_MAX_PORTS_PER_LAG:
            ret = sscanf(optarg, "%u", &(sdk_init_params.lag_params.max_ports_per_lag));
            break;

        case ARG_DEFAULT_LAG_HASH:
            ret = sscanf(optarg, "%u", &(sdk_init_params.lag_params.default_lag_hash));
            break;

        case ARG_MAX_VLAN:
            ret = sscanf(optarg, "%u", &(sdk_init_params.vlan_params.num_of_active_vlans));
            break;

        case ARG_MAX_BRIDGE:
            ret =
                sscanf(optarg, "%u", &(sdk_init_params.bridge_init_params.sdk_mode_params.mode_hybrid.max_bridge_num));
            break;

        case ARG_MAX_PORT_ROUTER:
            ret = sscanf(optarg, "%u", &(sdk_init_params.router_params.max_port_router_interfaces_num));
            if (__check_port_router_num_range(chip_type,
                                              sdk_init_params.router_params.max_port_router_interfaces_num) !=
                SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Unsupported max_rifs : %s \n", optarg);
                goto out;
            }
            /* being zero equals to no parameter setting, and we will fetch the default value. */
            if (sdk_init_params.router_params.max_port_router_interfaces_num != 0) {
                max_port_router_interfaces_num_is_set = TRUE;
            }
            break;

        case ARG_DEFAULT_VLAN:
            ret = sscanf(optarg, "%hu", &(sdk_init_params.vlan_params.def_vid));
            break;

        case ARG_MSTP_MODE:
            ret = sscanf(optarg, "%d", (int*)&(sdk_init_params.mstp_params.mode));
            break;

        case ARG_POLICER_PRIORITY_GROUPS:
            ret = sscanf(optarg, "%hhu", &(sdk_init_params.policer_params.priority_group_num));
            break;

        case ARG_VERBOSITY_LEVEL:
            ret = sscanf(optarg, "%u", &(verbosity_level));
            SX_LOG_INF("verbosity level: %u\n", verbosity_level);
            break;

        case ARG_NO_VERBOSITY:
            if (set_verbosity) {
                SX_LOG_INF("Skipping verbosity set\n");
                set_verbosity = FALSE;
            }
            break;

        case ARG_FATAL_ERROR_MODE:
            fatal_error_mode = TRUE;
            break;

        case ARG_MAX_SWID_ID:
            ret = sscanf(optarg, "%hhu", &(sdk_init_params.vlan_params.max_swid_id));
            break;

        case ARG_TCAM_OPT_MODE:
            ret = sscanf(optarg, "%d", (int*)&(sdk_init_params.tcam_opt_params.tcam_opt_mode));
            SX_LOG_DBG("ARG_TCAM_OPT_MODE: %s \n", optarg);
            break;

        case ARG_TCAM_OPT_MODE_PARAM:
            ret = sscanf(optarg, "%d", (int*)&(sdk_init_params.tcam_opt_params.tcam_opt_mode_param));
            SX_LOG_DBG("ARG_TCAM_OPT_MODE_PARAM: %s \n", optarg);
            break;

        case ARG_KVD_LINEAR_SIZE:
            ret = sscanf(optarg, "0x%x", &(kvd_linear_size));
            if (!ret) {
                ret = sscanf(optarg, "%u", &(kvd_linear_size));
                if (!ret) {
                    SX_LOG_ERR("kvd_linear_size couldn't be retrieved\n");
                    goto out;
                }
            }
            set_linear = TRUE;
            break;

        case ARG_KVD_SINGLE_SIZE:
            ret = sscanf(optarg, "0x%x", &(kvd_single_size));
            if (!ret) {
                ret = sscanf(optarg, "%u", &(kvd_single_size));
                if (!ret) {
                    SX_LOG_ERR("kvd_single_size couldn't be retrieved\n");
                    goto out;
                }
            }
            set_single = TRUE;
            break;

        case ARG_KVD_DOUBLE_SIZE:
            ret = sscanf(optarg, "0x%x", &(kvd_double_size));
            if (!ret) {
                ret = sscanf(optarg, "%u", &(kvd_double_size));
                if (!ret) {
                    SX_LOG_ERR("kvd_double_size couldn't be retrieved\n");
                    goto out;
                }
            }
            set_double = TRUE;
            break;

        case ARG_PIPELINE_LATENCY_SIZE:
            ret = sscanf(optarg, "%u", &(pipeline_latency_size));
            sdk_init_params.cos_params.pipeline_latency.size = pipeline_latency_size;
            sdk_init_params.cos_params.pipeline_latency.pipeline_latency_valid = TRUE;
            break;

        case ARG_QINIQ_PRIO_TAG_MODE:
            ret = sscanf(optarg, "%u", &(qinq_prio_tag_mode));
            sdk_init_params.vlan_params.qinq_prio_tag_mode = qinq_prio_tag_mode;
            break;

        case ARG_USE_INTERNAL_INIT_FLOW:
            ret = sscanf(optarg, "%u", &use_internal_init_flow);
            sdk_init_params.boot_mode_params.use_internal_init_flow = use_internal_init_flow;
            printf("use_internal_init_flow=%u\n", use_internal_init_flow);
            break;

        case ARG_BOOT_MODE:
            if (!strcmp(optarg, "NORMAL")) {
                sdk_init_params.boot_mode_params.boot_mode = SX_BOOT_MODE_NORMAL_E;
            } else if (!strcmp(optarg, "FAST")) {
                sdk_init_params.boot_mode_params.boot_mode = SX_BOOT_MODE_FAST_E;
            } else if (!strcmp(optarg, "ISSU_NORMAL")) {
                sdk_init_params.boot_mode_params.boot_mode = SX_BOOT_MODE_ISSU_NORMAL_E;
            } else if (!strcmp(optarg, "ISSU_FAST")) {
                sdk_init_params.boot_mode_params.boot_mode = SX_BOOT_MODE_ISSU_FAST_E;
            } else if (!strcmp(optarg, "ISSU_STARTED")) {
                sdk_init_params.boot_mode_params.boot_mode = SX_BOOT_MODE_ISSU_STARTED_E;
            } else if (!strcmp(optarg, "DISABLED")) {
                sdk_init_params.boot_mode_params.boot_mode = SX_BOOT_MODE_DISABLED_E;
            } else {
                SX_LOG_ERR("Unsupported boot_mode parameter : %s \n", optarg);
                goto out;
            }
            break;

        case ARG_FDB_ASYNC_MODE:
            ret = sscanf(optarg, "%u", &(fdb_async_mode));
            sdk_init_params.fdb_params.async_mode = fdb_async_mode;
            break;

        case ARG_SDK_ASYNC_MODE:
            if (!strcmp(optarg, "SYNC")) {
                sdk_init_params.async_params.enabled = FALSE;
                sdk_init_params.async_params.accepted_return_status = SX_STATUS_SUCCESS;
            } else if (!strcmp(optarg, "ASYNC_RETURN_STATUS_SUCCESS")) {
                sdk_init_params.async_params.enabled = TRUE;
                sdk_init_params.async_params.accepted_return_status = SX_STATUS_SUCCESS;
            } else if (!strcmp(optarg, "ASYNC_RETURN_STATUS_ACCEPTED")) {
                sdk_init_params.async_params.enabled = TRUE;
                sdk_init_params.async_params.accepted_return_status = SX_STATUS_ACCEPTED;
            } else {
                SX_LOG_ERR("Unsupported sdk_async_mode parameter : %s \n", optarg);
                goto out;
            }


            break;

        case ARG_PDB_LAG_INIT:
            sdk_init_params.boot_mode_params.pdb_lag_init = TRUE;
            ret = 1;
            break;

        case ARG_PDB_PORT_MAPPING_INIT:
            sdk_init_params.boot_mode_params.pdb_port_map_init = TRUE;
            ret = 1;
            break;

        case ARG_USE_XM:
            sdk_init_params.boot_mode_params.use_xm = TRUE;
            ret = 1;
            break;

        case ARG_SYS_ACL_DROP_TRAP_EN:
            sys_acl_drop_trap_en = TRUE;
            break;

        case ARG_ACL_MANUAL_UNBIND:
            sdk_init_params.acl_params.acl_manual_unbind = TRUE;
            break;

        case ARG_URMCV6_ENABLE:
            sdk_init_params.fdb_params.unreg_mc_ipv6_flood_en = 1;
            break;

        case ARG_ROAMNG_MAC_NOTIF_EN:
            sdk_init_params.fdb_params.roaming_mac_notif_en = TRUE;
            break;

        case ARG_COS_MAX_BUFFER_MODE:
            ret = sscanf(optarg, "%u", &(cos_init_max_buff_mode));
            sdk_init_params.cos_params.max_buffer_mode = cos_init_max_buff_mode;
            break;

        case ARG_EMAD_TIMEOUT:
            ret = sscanf(optarg, "%u", &(emad_timeout));
            break;

        case ARG_PORT_PROFILES_NUM:
            ret = sscanf(optarg, "%hhu", &(port_profiles_num));
            break;

        case ARG_PORT_PROFILES_TOTAL_MEMORY:
            ret = sscanf(optarg, "%hu", &(port_profiles_total_memory));
            break;

        case ARG_PORT_SPEED_RATE_MODE:
            if (!strcmp(optarg, "DEFAULT")) {
                sdk_init_params.port_params.port_speed_rate_mode = SX_PORT_SPEED_RATE_MODE_DEFAULT_E;
            } else if (!strcmp(optarg, "SPEED")) {
                sdk_init_params.port_params.port_speed_rate_mode = SX_PORT_SPEED_RATE_MODE_SPEED_E;
            } else if (!strcmp(optarg, "RATE")) {
                sdk_init_params.port_params.port_speed_rate_mode = SX_PORT_SPEED_RATE_MODE_RATE_E;
            } else {
                SX_LOG_ERR("Unsupported port_speed_rate_mode parameter : %s \n", optarg);
                goto out;
            }
            break;

        case ARG_ACCUFLOW_MAX_NUMBER:
            ret = sscanf(optarg, "%u", &accuflow_max_number);
            sdk_init_params.flow_counter_params.flow_counter_accumulated_type_max_number = accuflow_max_number &
                                                                                           0xFFFF;
            break;

        case ARG_MODULE_SUPPORT_TYPE:
            if (!strcasecmp(optarg, "DEPENDENT") || !strcasecmp(optarg, "ENABLED")) {
                sdk_init_params.mgmt_params.support_type = SX_MGMT_MODULE_SUPPORT_ENABLED_E;
            } else if (!strcasecmp(optarg, "INDEPENDENT")) {
                sdk_init_params.mgmt_params.support_type = SX_MGMT_MODULE_SUPPORT_INDEPENDENT_E;
            } else if (!strcasecmp(optarg, "STANDALONE")) {
                sdk_init_params.mgmt_params.support_type = SX_MGMT_MODULE_SUPPORT_STANDALONE_E;
            } else {
                SX_LOG_ERR("Unsupported module support type : %s \n", optarg);
                goto out;
            }

            break;

        case ARG_FUSE_ENABLE:
            sdk_init_params.fuse_params.fuse_enable = TRUE;
            break;

        case ARG_FUSE_DIR_PATH:
            if (strlen(optarg) < SX_API_DIR_NAME_MAX_LEN) {
                sscanf(optarg, "%s", (sdk_init_params.fuse_params.fuse_path_name));
            }
            break;

        case ARG_IB_ENABLE_SPLIT:
            ib_split_en = TRUE;
            break;

        case ARG_IB_ENABLE_ROUTER:
            ib_rtr_en = TRUE;
            break;

        case ARG_SDK_SYS_INFO_PATH:
            if (strlen(optarg) < SX_API_DIR_NAME_MAX_LEN) {
                sscanf(optarg, "%s", (sdk_init_params.sdk_sys_info_params.sdk_sys_info_path));
            }
            break;

        case ARG_HEALTH_CHECK_LOG_ENABLE:
            health_check_log_enable = TRUE;
            break;

        case ARG_TRANSACTION_MODE_DISABLE:
            transaction_mode_disable = TRUE;
            break;

        case 'h':
        case '?':
            __show_help();

        /* fall through */
        default:
            /* getopt_long already printed an error message. */
            __show_error();
        }

        if (ret != 1) {
            __show_error();
        }
    }

    /* Check remaining command line arguments (not options). */
    __sdk_default_params_by_chip(&sdk_init_params, (sx_chip_types_t)chip_type);

    /* Check remaining command line arguments (not options). */
    if (optind + 1 != argc) {
        __show_error();
    }


    if (!strcmp(argv[optind], "eth-single") || !strcmp(argv[optind], "ETH-SINGLE")) {
        /* depend on the profile */
        if ((chip_type == SXD_CHIP_TYPE_SPECTRUM) || (chip_type == SXD_CHIP_TYPE_SPECTRUM_A1)) {
            memcpy(&(sdk_init_params.profile), &single_part_eth_device_profile_spectrum, sizeof(struct ku_profile));
            if (set_linear) {
                sdk_init_params.profile.kvd_linear_size = kvd_linear_size;
            }
            if (set_single) {
                sdk_init_params.profile.kvd_hash_single_size = kvd_single_size;
            }
            if (set_double) {
                sdk_init_params.profile.kvd_hash_double_size = kvd_double_size;
            }

            memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_eth_spectrum, sizeof(struct sx_pci_profile));
            /* for Condor ONLY limited applibs modules is supported */
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_ACL | SX_API_MGMT_LIB;
        } else if ((chip_type == SXD_CHIP_TYPE_SPECTRUM2) ||
                   (chip_type == SXD_CHIP_TYPE_SPECTRUM3) ||
                   (chip_type == SXD_CHIP_TYPE_SPECTRUM4) ||
                   (chip_type == SXD_CHIP_TYPE_SPECTRUM5)) {
            memcpy(&(sdk_init_params.profile), &single_part_eth_device_profile_reserved, sizeof(struct ku_profile));
            if (set_linear) {
                sdk_init_params.profile.kvd_linear_size = kvd_linear_size;
            }
            if (set_single) {
                sdk_init_params.profile.kvd_hash_single_size = kvd_single_size;
            }
            if (set_double) {
                sdk_init_params.profile.kvd_hash_double_size = kvd_double_size;
            }
            single_part_eth_device_profile_reserved.chip_type = chip_type;

            if (chip_type == SXD_CHIP_TYPE_SPECTRUM2) {
                memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_eth_spectrum2,
                       sizeof(struct sx_pci_profile));
            } else if (chip_type == SXD_CHIP_TYPE_SPECTRUM3) {
                memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_eth_spectrum3,
                       sizeof(struct sx_pci_profile));
            } else if (chip_type == SXD_CHIP_TYPE_SPECTRUM4) {
                memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_eth_spectrum4,
                       sizeof(struct sx_pci_profile));
            } else { /*chip_type == SXD_CHIP_TYPE_SPECTRUM5*/
                memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_eth_spectrum5,
                       sizeof(struct sx_pci_profile));
            }
            /* for Condor ONLY limited applibs modules is supported */
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_ACL | SX_API_MGMT_LIB;
        } else if (chip_type == SXD_CHIP_TYPE_SWITCHX_A2) {
            memcpy(&(sdk_init_params.profile), &single_part_eth_device_profile_a2, sizeof(struct ku_profile));
            memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_eth, sizeof(struct sx_pci_profile));
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_ACL | SX_API_MGMT_LIB;
        } else {
            memcpy(&(sdk_init_params.profile), &single_part_eth_device_profile, sizeof(struct ku_profile));
            memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_eth, sizeof(struct sx_pci_profile));
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_ACL | SX_API_MGMT_LIB;
        }
    } else if (!strcmp(argv[optind], "eth-multi") || !strcmp(argv[optind], "ETH-MULTI")) {
        if (chip_type == SXD_CHIP_TYPE_SWITCHX_A2) {
            memcpy(&(sdk_init_params.profile), &multi_part_eth_device_profile_a2, sizeof(struct ku_profile));
            memcpy(&(sdk_init_params.pci_profile), &pci_profile_multi_eth, sizeof(struct sx_pci_profile));
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_ACL | SX_API_MGMT_LIB;
        } else {
            memcpy(&(sdk_init_params.profile), &multi_part_eth_device_profile, sizeof(struct ku_profile));
            memcpy(&(sdk_init_params.pci_profile), &pci_profile_multi_eth, sizeof(struct sx_pci_profile));
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_ACL | SX_API_MGMT_LIB;
        }
    } else if (!strcmp(argv[optind], "ib-single") || !strcmp(argv[optind], "IB-SINGLE")) {
        if (chip_type == SXD_CHIP_TYPE_QUANTUM) {
            memcpy(&(sdk_init_params.profile), &single_part_ib_device_profile_quantum, sizeof(struct ku_profile));
            memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_ib, sizeof(struct sx_pci_profile));
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_IB | SX_API_MGMT_LIB;
        } else if (chip_type == SXD_CHIP_TYPE_QUANTUM2) {
            memcpy(&(sdk_init_params.profile), &single_part_ib_device_profile_quantum2, sizeof(struct ku_profile));
            memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_ib, sizeof(struct sx_pci_profile));
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_IB | SX_API_MGMT_LIB;
        } else if (chip_type == SXD_CHIP_TYPE_QUANTUM3) {
            memcpy(&(sdk_init_params.profile), &single_part_ib_device_profile_quantum3, sizeof(struct ku_profile));
            memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_ib, sizeof(struct sx_pci_profile));
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_IB | SX_API_MGMT_LIB;
        } else {
            memcpy(&(sdk_init_params.profile), &single_part_ib_device_profile_switchib, sizeof(struct ku_profile));
            memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_ib, sizeof(struct sx_pci_profile));
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_IB | SX_API_MGMT_LIB;
        }

        if (ib_split_en) {
            sdk_init_params.profile.split_ready = 1; /* split ready to 2X */
            /* Since we now have double the ports, we need to have less MC FDB entries per switch partition
             * FW code verifies that max_ib_mc doesn't exceed mc table size. This value depends on FW configurations
             * Such as number of subgroups in AR group. For that reason, we'll configure max_ib_mc to be 2 as default -
             * which is a small enough value in any case. */
            sdk_init_params.profile.max_ib_mc = 2;

            if (chip_type == SXD_CHIP_TYPE_QUANTUM3) {
                sdk_init_params.profile.split_ready = 2; /* split ready to 1X */
            }
        } else {
            if (chip_type == SXD_CHIP_TYPE_QUANTUM3) {
                /* QTM3 should always be split ready - either for 2X or 1X */
                sdk_init_params.profile.split_ready = 1; /* split ready to 2X */
            }
        }

        if (ib_rtr_en) {
            sdk_init_params.profile.ib_router_en = 1;
            sdk_init_params.profile.swid0_config_type.properties = 4; /* IB Router Port */
        }
    } else if (!strcmp(argv[optind], "switchib-single") || !strcmp(argv[optind], "SWITCHIB-SINGLE")) {
        memcpy(&(sdk_init_params.profile), &single_part_ib_device_profile_switchib, sizeof(struct ku_profile));
        memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_ib, sizeof(struct sx_pci_profile));
        sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                       SX_API_ETH_L2 | SX_API_ACL | SX_API_IB | SX_API_MGMT_LIB;
    } else if (!strcmp(argv[optind], "switchib2-single") || !strcmp(argv[optind], "SWITCHIB2-SINGLE")) {
        memcpy(&(sdk_init_params.profile), &single_part_ib_device_profile_switchib2, sizeof(struct ku_profile));
        memcpy(&(sdk_init_params.pci_profile), &pci_profile_single_ib, sizeof(struct sx_pci_profile));
        sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                       SX_API_ETH_L2 | SX_API_IB | SX_API_MGMT_LIB;
    } else if (!strcmp(argv[optind], "ib-multi") || !strcmp(argv[optind], "IB-MULTI")) {
        memcpy(&(sdk_init_params.profile), &multi_part_ib_device_profile, sizeof(struct ku_profile));
        memcpy(&(sdk_init_params.pci_profile), &pci_profile_multi_ib, sizeof(struct sx_pci_profile));
        sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                       SX_API_ETH_L2 | SX_API_IB | SX_API_MGMT_LIB;
    } else if (!strcmp(argv[optind], "vpi-single") || !strcmp(argv[optind], "VPI-SINGLE")) {
        if (chip_type == SXD_CHIP_TYPE_SWITCHX_A2) {
            memcpy(&(sdk_init_params.profile), &vpi_device_profile_a2, sizeof(struct ku_profile));
            memcpy(&(sdk_init_params.pci_profile), &pci_profile_vpi, sizeof(struct sx_pci_profile));
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_ACL | SX_API_IB | SX_API_MGMT_LIB;
        } else {
            memcpy(&(sdk_init_params.profile), &vpi_device_profile, sizeof(struct ku_profile));
            memcpy(&(sdk_init_params.pci_profile), &pci_profile_vpi, sizeof(struct sx_pci_profile));
            sdk_init_params.applibs_mask = SX_API_FLOW_COUNTER | SX_API_POLICER | SX_API_HOST_IFC | SX_API_SPAN |
                                           SX_API_ETH_L2 | SX_API_ACL | SX_API_IB | SX_API_MGMT_LIB;
        }
    } else if (!strcmp(argv[optind], "vpi-multi") || !strcmp(argv[optind], "VPI-MULTI")) {
        printf("profile [%s ]is not supported yet.\n", argv[optind]);
        return -1;
    } else {
        __show_error();
    }

    /* The following condition is True only for Backward compatible flow */
    if ((sdk_init_params.acl_params.max_vlan_groups == 0) && (sdk_init_params.profile.max_active_vlans != 0)) {
        sdk_init_params.acl_params.max_vlan_groups = sdk_init_params.profile.max_active_vlans;
    }

    /* The following condition is True only for Backward compatible flow */
    if ((sdk_init_params.fdb_params.max_mc_group == 0) && (sdk_init_params.profile.max_mid != 0)) {
        sdk_init_params.fdb_params.max_mc_group = sdk_init_params.profile.max_mid;
    }

    if (fatal_error_mode == TRUE) {
        SX_LOG_NTC("*** Fatal Error mode configured in CHASSIS Manager ***\n");
        sdk_init_params.log_params.fatal_error_mode_enable = TRUE;
    }
    if (sys_acl_drop_trap_en == TRUE) {
        sdk_init_params.acl_params.sys_acl_drop_trap_enable = TRUE;
    }

    if (health_check_log_enable == TRUE) {
        SX_LOG_NTC("*** health_check_log_enable configured in CHASSIS Manager ***\n");
        sdk_init_params.log_params.health_check_log_enable = TRUE;
    }

    /* Set the EMAD timeout. Zero value indicates to use the default value */
    sdk_init_params.boot_mode_params.emad_timeout = emad_timeout;
    sdk_init_params.pci_profile.dev_id = 1;
    sdk_init_params.profile.dev_id = 1;
    /* set the chip type in profile */
    sdk_init_params.profile.chip_type = chip_type;
    /* Set port profile number */
    sdk_init_params.profile.port_profile_num = (uint8_t)port_profiles_num;

    /* Set port profile total memory */
    sdk_init_params.port_params.port_profiles_total_memory = (uint16_t)port_profiles_total_memory;

    /* set verbosity */
    if (set_verbosity) {
        LOG_VAR_NAME(__MODULE__) = verbosity_level;
        err = sx_api_system_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_BOTH,
                                                    verbosity_level, verbosity_level);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set SDK log verbosity level: (%s)\n", sx_status_str(err));
            goto out;
        } else {
            SX_LOG_INF("SDK Log verbosity level was set successfully, verbosity level : [%s]\n",
                       SX_VERBOSITY_LEVEL_STR(verbosity_level));
        }
    }

    if (!use_internal_init_flow && (sdk_init_params.boot_mode_params.boot_mode == SX_BOOT_MODE_ISSU_STARTED_E)) {
        /* open user space DPT handle - DO NOT REMOVE!!
         * Users are always calling sxd_dpt_init outside of SDK in ISSU_STARTED boot mode.
         * We need to make sure we are calling sxd_dpt_init also for use_internal_init_flow = 0 ( use_legacy_init_flow = 1).*/
        sxd_dpt_init(sys_type, chassis_log_cb, LOG_VAR_NAME(__MODULE__));
    }

    err = sx_api_sdk_init_set(handle, &sdk_init_params);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialize SDK (%s)\n", sx_status_str(err));
        goto out;
    } else {
        SX_LOG_NTC("SDK initialized successfully\n");
    }

    /* Set Async mode to ENABLE */
    if (!vm_flag && !transaction_mode_disable) {
#if defined(PD_BU)
        SX_LOG_NTC("*** CHASSIS Manager - Transaction mode = DISABLE on Palladium ***\n");
#else
        SX_LOG_NTC("*** CHASSIS Manager - Transaction mode = ENABLE ***\n");
        err = sx_api_transaction_mode_set(handle, SX_ACCESS_CMD_ENABLE);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to sx_api_transaction_mode_set(ENABLE) (%s)\n", sx_status_str(err));
            goto out;
        }
#endif /* defined(PD_BU) */
    } else {
        SX_LOG_NTC("*** CHASSIS Manager - Transaction mode = DISABLE ***\n");
    }


    err = sx_api_close(&handle);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to close SX-API (%s)\n", sx_status_str(err));
        goto out;
    }

    SX_LOG_NTC("*** CHASSIS Manager successfully configured the SDK ***\n");

out:
    /* close log */
    sx_log_close();
    return err;
}

void chassis_log_cb(sx_log_severity_t severity, const char *module_name, char *msg)
{
    sx_verbosity_level_t verbosity = 0;

    SEVERITY_LEVEL_TO_VERBOSITY_LEVEL(severity, verbosity);
    printf("[%-20s][%s] : %s", module_name, SX_VERBOSITY_LEVEL_STR(verbosity), msg);

    return;
}
