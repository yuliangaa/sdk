/*
 * SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "cJSON.h"
#include "uthash.h"
#include "tac_collector_adapter.h"

/*NOTE: The adapter is standalone and as such should not include SDK dependencies*/

#undef DUMP_PKT

#define SX_GENERATE_ENUM(ENUM, STR)   ENUM,
#define SX_GENERATE_STRING(ENUM, STR) STR,

#define COMPILE_TIME_ASSERT(EXPRESSION) \
    switch (0) {                        \
    case 0:                             \
    case (EXPRESSION):                  \
        ; }

#define timespecsub(tsp, usp, vsp)                        \
    do {                                                  \
        (vsp)->tv_sec = (tsp)->tv_sec - (usp)->tv_sec;    \
        (vsp)->tv_nsec = (tsp)->tv_nsec - (usp)->tv_nsec; \
        if ((vsp)->tv_nsec < 0) {                         \
            (vsp)->tv_sec--;                              \
            (vsp)->tv_nsec += 1000000000L;                \
        }                                                 \
    } while (0)


/* GLobals*/
struct tac_ht_elem   *tac_ht = NULL;
struct port_map_elem *port_map_ht = NULL;
pthread_rwlock_t      hash_table_rwlock;

/* Forward defines */
void flush_record(tac_entry_type_t* tac_entry_type_p);

void add_entry(uint64_t sig_hash, uint32_t uid, tac_entry_type_t entry)
{
    tac_ht_elem_t l, *p = NULL;

    memset(&l, 0, sizeof(tac_ht_elem_t));
    l.key.sig_hash = sig_hash;
    l.key.uid = uid;
    HASH_FIND(hh, tac_ht, &l.key, sizeof(record_key_t), p);
    if (p == NULL) {
        p = (struct tac_ht_elem*)malloc(sizeof *p);
        p->key.sig_hash = sig_hash;
        p->key.uid = uid;
        HASH_ADD(hh, tac_ht, key, sizeof(record_key_t), p);  /* key is the name of the key field */
    }
    p->tac_entry = entry;
}

struct tac_ht_elem* lookup_entry(uint64_t sig_hash, uint32_t uid)
{
    tac_ht_elem_t l, *p = NULL;

    memset(&l, 0, sizeof(tac_ht_elem_t));
    l.key.sig_hash = sig_hash;
    l.key.uid = uid;
    HASH_FIND(hh, tac_ht, &l.key, sizeof(record_key_t), p);
    return p;
}

void delete_entry(uint64_t sig_hash, uint32_t uid)
{
    tac_ht_elem_t *s;

    s = lookup_entry(sig_hash, uid);
    if (s != NULL) {
        HASH_DEL(tac_ht, s);
        free(s);
    }
}


void add_port_map_entry(uint16_t local_port, uint16_t label_port)
{
    struct port_map_elem *s;
    uint32_t              local_port_32 = (uint32_t)local_port;
    uint32_t              label_port_32 = (uint32_t)label_port;

    HASH_FIND_INT(port_map_ht, &local_port_32, s);
    if (s == NULL) {
        s = (struct port_map_elem*)malloc(sizeof *s);
        s->local_port = local_port_32;
        HASH_ADD_INT(port_map_ht, local_port, s);  /* local_port is the key field */
    }
    s->label_port = label_port_32;
}


void delete_port_map_entry(uint16_t local_port)
{
    struct port_map_elem *s;
    uint32_t              local_port_32 = (uint32_t)local_port;

    HASH_FIND_INT(port_map_ht, &local_port_32, s);
    if (s != NULL) {
        HASH_DEL(port_map_ht, s);
        free(s);
    }
}

void lookup_port_map_entry(uint16_t local_port, uint16_t *label_port)
{
    struct port_map_elem *s;
    uint32_t              local_port_32 = (uint32_t)local_port;

    HASH_FIND_INT(port_map_ht, &local_port_32, s);
    if (s != NULL) {
        *label_port = (uint16_t)s->label_port;
    } else {
        *label_port = LOG_INVALID_PORT;
    }
}

void flush_all_records()
{
    struct tac_ht_elem *s;
    struct tac_ht_elem *tmp;

    pthread_rwlock_wrlock(&hash_table_rwlock);
    HASH_ITER(hh, tac_ht, s, tmp) {
        flush_record(&s->tac_entry);
        HASH_DEL(tac_ht, s);      /* delete it (s advances to next) */
        free(s);                 /* free it */
    }

    pthread_rwlock_unlock(&hash_table_rwlock);
}
#ifdef DUMP_PKT
static void DumpHex(const void* data, size_t size)
{
    char   ascii[17];
    size_t i, j;

    ascii[16] = '\0';
    for (i = 0; i < size; ++i) {
        printf("%02X ", ((unsigned char*)data)[i]);
        if ((((unsigned char*)data)[i] >= ' ') && (((unsigned char*)data)[i] <= '~')) {
            ascii[i % 16] = ((unsigned char*)data)[i];
        } else {
            ascii[i % 16] = '.';
        }
        if (((i + 1) % 8 == 0) || (i + 1 == size)) {
            printf(" ");
            if ((i + 1) % 16 == 0) {
                printf("|  %s \n", ascii);
            } else if (i + 1 == size) {
                ascii[(i + 1) % 16] = '\0';
                if ((i + 1) % 16 <= 8) {
                    printf(" ");
                }
                for (j = (i + 1) % 16; j < 16; ++j) {
                    printf("   ");
                }
                printf("|  %s \n", ascii);
            }
        }
    }
}

#endif


static void __process_event_type_tac_new(uint8_t* tac_packet, uint16_t record_time, boolean_t flush_all, uint32_t uid)
{
    uint8_t         *buff_ptr = (uint8_t*)tac_packet;
    uint64_t         signature_hash;
    tac_entry_type_t tac_entry;

    memset(&tac_entry, 0, sizeof(tac_entry));
    struct tac_ht_elem *s;
    struct ethhdr      *eth;


    if (flush_all == TRUE) {
        flush_all_records();
        goto out;
    }

    buff_ptr += 3;
    /* Read version*/
    tac_entry.version = (*buff_ptr) & 0xF;
    buff_ptr += 1;
    /* Start of TAC Header*/
    memcpy(&signature_hash, buff_ptr, 8);

    pthread_rwlock_rdlock(&hash_table_rwlock);
    /* Lookup in HT*/
    s = lookup_entry(signature_hash, uid);
    if (s != NULL) {
        /* Duplicate entry, ignore*/
        goto out;
    }

    pthread_rwlock_unlock(&hash_table_rwlock);

    tac_entry.record_complete = FALSE;
    tac_entry.record_time = record_time;
    clock_gettime(CLOCK_MONOTONIC, &tac_entry.record_init_time);
    buff_ptr += 8; /* Move past Sig hash */

    tac_entry.mirror_congestion = *((uint16_t*)buff_ptr);
    buff_ptr += 2;
    memcpy(tac_entry.utc_time_stamp, buff_ptr, 10);
    buff_ptr += 10;

    /*TX port, 9 bits for v0, 10 bits for v1*/
    tac_entry.tx = (*buff_ptr) & 0xFF;
    buff_ptr += 1;
    if (tac_entry.version == 0) {
        tac_entry.tx = (tac_entry.tx) << 1 | ((*buff_ptr) & (0x1 << 7));
    } else {
        tac_entry.tx = (tac_entry.tx) << 1 | ((*buff_ptr) & (0XC0));
    }
    if ((tac_entry.tx != TX_PORT_MC) && (tac_entry.tx != TX_PORT_UNKNOWN)) {
        tac_entry.tx += 1; /*Local port -1 */
    }
    tac_entry.tx += 1;
    tac_entry.traffic_class = (*buff_ptr) & 0X1F;
    buff_ptr += 1;
    tac_entry.mirror_reason = *buff_ptr;
    buff_ptr += 1;
    tac_entry.user_key_or_time = (*buff_ptr) & 0X1F;
    buff_ptr += 3;
    tac_entry.trap_id = (*buff_ptr) & 0x3;
    buff_ptr += 1;
    tac_entry.trap_id = (tac_entry.trap_id) << 8 | ((*buff_ptr) & 0xFF);
    buff_ptr += 5;
    tac_entry.is_elephant = (boolean_t)((*buff_ptr) & 0xC0);
    buff_ptr += 1;
    memcpy(&tac_entry.trap_cookie, buff_ptr, 3);
    tac_entry.trap_cookie = ntohl(tac_entry.trap_cookie);

    tac_entry.trap_cookie = tac_entry.trap_cookie & 0xFFFFF;
    buff_ptr += 3;
    tac_entry.rq = (*buff_ptr) & 0xFF;
    buff_ptr += 1;
    if (tac_entry.version == 0) {
        tac_entry.rq = (tac_entry.rq) << 1 | ((*buff_ptr) & 0x1) << 7;
    } else {
        tac_entry.rq = (tac_entry.rq) << 1 | ((*buff_ptr) & (0XC0));
    }
    tac_entry.rq += 1;
    buff_ptr += 1;
    tac_entry.packet_length = (*buff_ptr) & 0xFF;
    buff_ptr += 1;
    tac_entry.packet_length = tac_entry.packet_length << 8 | (*buff_ptr);
    buff_ptr += 1;

    /* Truncated packet begins*/
    /* Read SMAC & DMAC */
    eth = (struct ethhdr *)(buff_ptr);
    memcpy(&tac_entry.dmac, buff_ptr, ETHER_ADDR_LEN);
    buff_ptr += ETHER_ADDR_LEN;
    memcpy(&tac_entry.smac, buff_ptr, ETHER_ADDR_LEN);
    buff_ptr += ETHER_ADDR_LEN;
    buff_ptr += (ethernet_header_length - 2 * ETHER_ADDR_LEN);
    if (ntohs(eth->h_proto) == DOT1Q_ETHERTYPE) {
        buff_ptr += vlan_header_length;
    }
    /* Copy sip & dip, move past ip header crud to address*/
    buff_ptr += 12;
    memcpy(&tac_entry.dip, buff_ptr, 4);
    buff_ptr += 4;
    memcpy(&tac_entry.sip, buff_ptr, 4);


    pthread_rwlock_wrlock(&hash_table_rwlock);
    add_entry(signature_hash, uid, tac_entry);

out:
    pthread_rwlock_unlock(&hash_table_rwlock);

    return;
}

static void __process_event_type_tac_agg(uint8_t* tac_packet,  boolean_t flush_all,  uint32_t uid)
{
    uint8_t            *buff_ptr = (uint8_t*)tac_packet;
    uint64_t            signature_hash;
    struct tac_ht_elem *s;

    if (flush_all == TRUE) {
        flush_all_records();
        goto out;
    }


    buff_ptr += 4;
    /* Start of TAC Header*/
    memcpy(&signature_hash, buff_ptr, 8);
    /* Lookup in HT*/
    pthread_rwlock_rdlock(&hash_table_rwlock);
    s = lookup_entry(signature_hash, uid);
    if (s == NULL) {
        goto out; /* Missing new entry, ignoring*/
    }

    s->tac_entry.record_complete = TRUE;
    buff_ptr += 8; /* Move past Sig hash */

    s->tac_entry.mirror_congestion = *((uint16_t*)buff_ptr);
    buff_ptr += 2;
    memcpy(s->tac_entry.utc_time_stamp, buff_ptr, 10);
    buff_ptr += 10;

    s->tac_entry.tx = (*buff_ptr) & 0xFF;
    buff_ptr += 1;
    if (s->tac_entry.version == 0) {
        s->tac_entry.tx = (s->tac_entry.tx) << 1 | ((*buff_ptr) & (0x1 << 7));
    } else {
        s->tac_entry.tx = (s->tac_entry.tx) << 1 | ((*buff_ptr) & (0XC0));
    }
    if ((s->tac_entry.tx != TX_PORT_MC) && (s->tac_entry.tx != TX_PORT_UNKNOWN)) {
        s->tac_entry.tx += 1; /*Local port -1 */
    }
    s->tac_entry.traffic_class = (*buff_ptr) & 0X1F;
    buff_ptr += 1;
    s->tac_entry.mirror_reason = *buff_ptr;
    buff_ptr += 1;
    s->tac_entry.user_key_or_time = (*buff_ptr) & 0X1F;
    buff_ptr += 3;
    s->tac_entry.trap_id = (*buff_ptr) & 0x3;
    buff_ptr += 1;
    s->tac_entry.trap_id = (s->tac_entry.trap_id) << 8 | ((*buff_ptr) & 0xFF);
    buff_ptr += 5;
    memcpy(&s->tac_entry.packet_count, buff_ptr, 4);
    s->tac_entry.packet_count = ntohl(s->tac_entry.packet_count);
    buff_ptr += 6;
    s->tac_entry.evc = (*buff_ptr) & 0X80;
    buff_ptr += 1;
    s->tac_entry.byte_count = 0;
    memcpy(&(s->tac_entry.byte_count), buff_ptr, 5);

out:
    pthread_rwlock_unlock(&hash_table_rwlock);
    return;
}


static void __process_event_type_tac_packet(uint8_t* tac_packet)
{
    uint8_t  *buff_ptr = (uint8_t*)tac_packet;
    uint8_t   msg_len = *(buff_ptr + 1);
    uint16_t  record_time = 0; /* default which means infinite*/
    uint16_t  tac_cmd = 0;
    boolean_t flush_all = FALSE;
    uint8_t   tac_type;
    uint32_t  uid = 0;

    buff_ptr += 4;

    /* Process options*/
    do {
        switch (*buff_ptr) {
        case OPT_TYPE_UID_LSB:
            uid = ntohs(*((uint16_t*)(buff_ptr + 2)));
            break;

        case OPT_TYPE_UID_MSB:
            uid = uid + ((ntohs(*((uint16_t*)(buff_ptr + 2)))) << 16);
            break;

        case OPT_TYPE_RECORD_TIME:
            record_time = ntohs(*((uint16_t*)(buff_ptr + 2)));
            break;

        case OPT_TYPE_TAC_CMD:
            tac_cmd = ntohs(*((uint16_t*)(buff_ptr + 2)));
            if (tac_cmd == TAC_FLUSH_ALL_CMD) {
                flush_all = TRUE;
            }
            break;

        case OPT_TYPE_NOP:
        default:

            break;
        }
        buff_ptr += 4;
    }while(msg_len-- != 0);

    /*pointer is at start identify if New or Aggregate*/
    tac_type = ((*buff_ptr) & 0xF8) >> 3;


    if (tac_type == TAC_NEW_ENTRY_TYPE) {
        __process_event_type_tac_new(buff_ptr, record_time, flush_all, uid);
    } else if (tac_type == TAC_AGG_ENTRY_TYPE) {
        __process_event_type_tac_agg(buff_ptr, flush_all, uid);
    }
}

static void __process_oob_tac_packet(uint8_t* tac_packet)
{
    /* Pointer is at start of TAC header*/
    uint8_t  *buff_ptr = (uint8_t*)tac_packet;
    uint8_t   msg_len = *(buff_ptr + 1); /* Unit of 4B*/
    uint16_t  tac_cmd = 0;
    boolean_t flush_all = FALSE;
    uint16_t  opt_len = 0; /*Unit of Bytes*/
    uint16_t  local_port = 0;
    uint16_t  label_port = 0;

    buff_ptr += 4; /* Move past reserved*/

    /* Process options*/
    do {
        switch (*buff_ptr) {
        case OPT_TYPE_TAC_CMD:
            tac_cmd = ntohs(*((uint16_t*)(buff_ptr + 2)));
            if (tac_cmd == TAC_FLUSH_ALL_CMD) {
                flush_all = TRUE;
            }
            break;

        case OPT_TYPE_PORT_MAPPING:
            opt_len = ntohs(*((uint16_t*)(buff_ptr + 2)));
            opt_len -= 2; /*Length contains reserved bit also*/
            buff_ptr += 4; /* Start of the port mapping*/
            do {
                local_port = ntohs(*((uint16_t*)(buff_ptr)));
                label_port = ntohs(*((uint16_t*)(buff_ptr + 2)));
                add_port_map_entry(local_port, label_port);
                buff_ptr += 4; /* Move to next entry */
            }while(opt_len -= 4 != 0);

        case OPT_TYPE_NOP:
        default:

            break;
        }
        buff_ptr += 4;
    }while(msg_len-- != 0);


    if (flush_all == TRUE) {
        flush_all_records();
    }
}

static void process_tac_packet(uint8_t* tac_packet)
{
    /* TAC packet has IP (next proto 0x2F) -> GRE (next proto 0x6558) -> TAC event header (8*32) with type 1 or 2 -> TAC / Agg event*/

    /* Lets first verify it is TAC */

    struct iphdr *ip = (struct iphdr*)(tac_packet);

    if (ip->protocol != IP_HDR_GRE_PROTO_TYPE) {
        printf("NOT gre packet [%u], ignore\n", ip->protocol);
        goto out;
    }
    uint8_t       *buff_ptr = (uint8_t*)tac_packet;
    struct ethhdr *eth;

    /* Extract ethertype*/
    /* Move past GRE*/
    buff_ptr += (gre_header_length + ip_header_length);

    eth = (struct ethhdr *)(buff_ptr);
    if (ntohs(eth->h_proto) != NVIDIA_TAC_ETHERTYPE) {
        printf("NOT tac packet [%u], ignore\n", eth->h_proto);
        goto out;
    }

    /* Move past inner ETh header + reserved byte*/
    buff_ptr += (ethernet_header_length + 2);
    #ifdef DUMP_PKT
    DumpHex(buff_ptr, 16);
    #endif

    /* We have verified that the packet is TAC, identify message type*/
    if ((*buff_ptr & 0x0F) == TAC_MSG_TYPE_EVENT) {
        /* Handle event type */
        __process_event_type_tac_packet(buff_ptr);
    } else if ((*buff_ptr & 0x0F) == TAC_MSG_TYPE_OOB) {
        /* Handle OOB messages */
        __process_oob_tac_packet(buff_ptr);
    } else {
        printf("Unknown TAC Message type [%u], ignoring\n", (*buff_ptr & 0x0F));
        goto out;
    }


out:
    return;
}


void packet_callback(u_char *args, const struct pcap_pkthdr* pkthdr, const u_char*  packet)
{
    UNUSED_PARAM(args);
    UNUSED_PARAM(pkthdr);

    struct ether_header *eptr;

    eptr = (struct ether_header *)packet;
    if (ntohs(eptr->ether_type) == ETHERTYPE_VLAN) {
        process_tac_packet((uint8_t*)packet + vlan_header_length + ethernet_header_length);
    } else if (ntohs(eptr->ether_type) == ETHERTYPE_IP) {
        process_tac_packet((uint8_t*)packet + ethernet_header_length);
    }
    /* Ignore everything else*/
}

/* Flush record, send collector
 * Currently we are writing to a JSON file.
 */

void flush_record(tac_entry_type_t* tac_entry_type_p)
{
    cJSON          *root = cJSON_CreateObject();
    FILE           *fp;
    char            mac[18];
    struct in_addr  ip;
    char            addr[INET_ADDRSTRLEN];
    struct timespec ts;
    char            buff[100];
    char            timestamp[128];
    uint16_t        logical_port = LOG_INVALID_PORT;


    cJSON_AddStringToObject(root, "MetricName", "TAC");
    /* UTC format Bits [79:32] Sec Bits [31:0] nSec with value up to 10^9-1 */
    ts.tv_sec = *(uint64_t*)tac_entry_type_p->utc_time_stamp;
    memcpy(&ts.tv_nsec, &tac_entry_type_p->utc_time_stamp[6], 4);
    asctime_r(gmtime(&ts.tv_sec), buff);
    snprintf(timestamp, 127, "%s.%09ld", buff, ts.tv_nsec);
    cJSON_AddStringToObject(root, "UTC Timestamp", timestamp);
    cJSON_AddNumberToObject(root, "egress_buf_fill_level", tac_entry_type_p->mirror_congestion);
    cJSON_AddNumberToObject(root, "egress_local_port", tac_entry_type_p->tx);
    lookup_port_map_entry(tac_entry_type_p->tx, &logical_port);
    if (logical_port != LOG_INVALID_PORT) {
        cJSON_AddNumberToObject(root, "egress_logical_port", logical_port);
    }
    cJSON_AddNumberToObject(root, "traffic_class", tac_entry_type_p->traffic_class);
    cJSON_AddStringToObject(root,
                            "mirror_reason",
                            (tac_entry_type_p->mirror_reason <
                             SX_SPAN_MIRROR_REASON_MAX_ID_E) ? sx_span_mirror_reason_str_s[tac_entry_type_p->
                                                                                           mirror_reason] : "Invalid");
    cJSON_AddNumberToObject(root, "user_key_or_time", tac_entry_type_p->user_key_or_time);
    cJSON_AddStringToObject(root,
                            "trap_id",
                            (tac_entry_type_p->trap_id <
                             TAC_TRAP_ID_MAX) ? tac_trap_id_str_s[tac_entry_type_p->trap_id] : "Invalid");
    cJSON_AddStringToObject(root, "is_elephant", (tac_entry_type_p->is_elephant == 0) ? "No" : "Yes");
    cJSON_AddNumberToObject(root, "trap_cookie_or_orig_packet_len", tac_entry_type_p->trap_cookie);
    cJSON_AddNumberToObject(root, "ingress_local_port", tac_entry_type_p->rq);
    lookup_port_map_entry(tac_entry_type_p->rq, &logical_port);
    if (logical_port != LOG_INVALID_PORT) {
        cJSON_AddNumberToObject(root, "ingress_logical_port", logical_port);
    }
    cJSON_AddNumberToObject(root, "packet_length", tac_entry_type_p->packet_length);
    cJSON_AddNumberToObject(root, "packet_count", tac_entry_type_p->packet_count);
    cJSON_AddStringToObject(root, "evc", (tac_entry_type_p->evc == 0) ? "just_reported" : "reported_and_evicted");

    snprintf(mac,
             18,
             "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X",
             tac_entry_type_p->smac[0],
             tac_entry_type_p->smac[1],
             tac_entry_type_p->smac[2],
             tac_entry_type_p->smac[3],
             tac_entry_type_p->smac[4],
             tac_entry_type_p->smac[5]);
    cJSON_AddStringToObject(root, "smac", mac);
    snprintf(mac,
             18,
             "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X",
             tac_entry_type_p->dmac[0],
             tac_entry_type_p->dmac[1],
             tac_entry_type_p->dmac[2],
             tac_entry_type_p->dmac[3],
             tac_entry_type_p->dmac[4],
             tac_entry_type_p->dmac[5]);
    cJSON_AddStringToObject(root, "dmac", mac);
    ip.s_addr = tac_entry_type_p->sip;
    if (!inet_ntop(AF_INET, &ip, addr, INET_ADDRSTRLEN)) {
        strcpy(addr, "???");
    }
    cJSON_AddStringToObject(root, "sip", addr);
    ip.s_addr = tac_entry_type_p->dip;
    if (!inet_ntop(AF_INET, &ip, addr, INET_ADDRSTRLEN)) {
        strcpy(addr, "???");
    }
    cJSON_AddStringToObject(root, "dip", addr);


    fp = fopen("/var/output.json", "w");
    fprintf(fp, "%s", cJSON_PrintUnformatted(root));
    fclose(fp);

    cJSON_Delete(root);
}


void * timerThreadcb(void *arg)
{
    struct timespec currtimespec, deltatime;

    UNUSED_PARAM(arg);

    memset(&currtimespec, 0, sizeof(currtimespec));
    memset(&deltatime, 0, sizeof(deltatime));
    struct tac_ht_elem *s, *tmp;
    uint64_t            delta = 0;

    while (1) {
        /* Acquire read lock*/
        clock_gettime(CLOCK_MONOTONIC, &currtimespec);
        pthread_rwlock_wrlock(&hash_table_rwlock);

        HASH_ITER(hh, tac_ht, s, tmp) {
            if (s->tac_entry.record_complete && (s->tac_entry.record_time != 0)) {
                timespecsub(&currtimespec, &s->tac_entry.record_init_time, &deltatime);
                delta = deltatime.tv_sec * 1000 + (deltatime.tv_nsec / 1000000);
                if (delta > 2 * s->tac_entry.record_time) {
                    flush_record(&s->tac_entry);
                    HASH_DEL(tac_ht, s);  /* delete it (tac_ht advances to next) */
                    free(s);
                }
            }
        }
        /* Release  lock*/
        pthread_rwlock_unlock(&hash_table_rwlock);
        sleep(1);
    }
}


int main(int argc, char **argv)
{
    char       error[PCAP_ERRBUF_SIZE];
    pcap_if_t *interfaces, *temp;
    int        i = 0;
    char       dev[25];
    pcap_t   * descr;
    pthread_t  timerThread;

#ifdef SDK_BUILD_ENV
    COMPILE_TIME_ASSERT((uint32_t)SXD_TRAP_ID_MAX == (uint32_t)TAC_TRAP_ID_MAX);
#endif


    if (argc < 2) {
        printf("ERROR: too few arguments [%d]\n", argc);
        printf("Usage: tac_collector_adapter <interface> <optional-vlan>\n");
        exit(1);
    }

    if (argc >= 2) {
        strncpy(dev, argv[1], 24);
        descr = pcap_open_live(dev, BUFSIZ, 0, -1, error);
        if (descr == NULL) {
            printf("pcap_open_live(): %s\n", error);
            if (pcap_findalldevs(&interfaces, error) == -1) {
                printf("\nerror in pcap find all devs");
                return -1;
            }

            printf("\n the interfaces present on the system are:");
            for (temp = interfaces; temp; temp = temp->next) {
                printf("\n%d  :  %s", i++, temp->name);
            }
            exit(1);
        }
    }

    pthread_rwlock_init(&hash_table_rwlock, NULL);

    if (pthread_create(&timerThread, NULL, timerThreadcb, NULL) != 0) {
        perror("pthread_create");
        return 1;
    }

    /* Start listening to packets*/
    pcap_loop(descr, -1, packet_callback, NULL);

    return 0;
}
