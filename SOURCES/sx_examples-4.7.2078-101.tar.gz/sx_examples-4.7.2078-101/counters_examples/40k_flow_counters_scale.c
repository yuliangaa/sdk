/*
 * Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <time.h>
#include <arpa/inet.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_flow_counter.h>

/** Local macros **/
#define TOTAL_COUNTERS_NUM 100000

int main(int argc, char **argv)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    sx_api_handle_t api_handle = 0;
    uint32_t        counter = 0;
    uint32_t        total_num = 0;

    /** Flow Counter variables */
    sx_flow_counter_type_t counter_type = SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES;
    sx_flow_counter_id_t   counter_id[TOTAL_COUNTERS_NUM] = {0};
    sx_flow_counter_set_t  counter_get[TOTAL_COUNTERS_NUM] = {
        {0}
    };

    /** Time variables **/
    uint64_t        add_time = 0;
    uint64_t        get_time = 0;
    uint64_t        del_time = 0;
    struct timespec tms_start;
    struct timespec tms_end;

    memset(&tms_start, 0, sizeof(tms_start));
    memset(&tms_end, 0, sizeof(tms_end));

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    /** Open SDK **/
    sx_status = sx_api_open(NULL, &api_handle);
    if (SX_STATUS_SUCCESS != sx_status) {
        printf("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);

    /** Creating as many flow counters as possible **/
    printf("\nCreating flow counters...\n");
    while (SX_STATUS_SUCCESS == sx_status) {
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_flow_counter_set(api_handle, SX_ACCESS_CMD_CREATE, counter_type, &counter_id[counter]);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if ((SX_STATUS_SUCCESS != sx_status) &&
            (SX_STATUS_NO_RESOURCES != sx_status)) {
            printf("ERROR: Failed to create flow counter[%s], iteration #%u\n", sx_status_str(sx_status), counter);
            exit(1);
        }

        add_time += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
        counter++;
    }
    total_num = counter - 1;
    printf("%u flow counters have successfully been created in %" PRIu64 " ms.\n", total_num, (add_time / 1000));

    /** Destroying the counters **/
    printf("\nDestroying the counters...\n");
    for (counter = 0; counter < total_num; counter++) {
        /* Get counters before destroying */
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status =
            sx_api_flow_counter_get(api_handle, SX_ACCESS_CMD_READ, counter_id[counter], &counter_get[counter]);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: Failed to get flow counter[%s], iteration #%u\n", sx_status_str(sx_status), counter);
            exit(1);
        }

        get_time += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);

        /* Destroy all counters */
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        sx_status = sx_api_flow_counter_set(api_handle, SX_ACCESS_CMD_DESTROY, counter_type, &counter_id[counter]);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);

        if (SX_STATUS_SUCCESS != sx_status) {
            printf("ERROR: Failed to delete flow counter[%s], iteration #%u\n", sx_status_str(sx_status), counter);
            exit(1);
        }

        del_time += (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                    (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);
    }
    printf("%u flow counters have successfully been retrieved in %" PRIu64 " ms.\n", counter, (get_time / 1000));
    printf("%u flow counters have successfully been deleted in %" PRIu64 " ms.\n", counter, (del_time / 1000));

    printf("\nEnd.\n");
    return 0;
}
