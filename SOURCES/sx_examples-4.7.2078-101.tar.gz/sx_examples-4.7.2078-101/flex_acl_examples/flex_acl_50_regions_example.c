/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_dbg.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_trap_id.h>
#include <complib/sx_log.h>
#include <arpa/inet.h>

/*
 * Example of FLEX ACL rules creation/deletion
 */

/*
 * Local test definitions
 */
#define REGION_SIZE 18
#define NUM_RULES   REGION_SIZE
#define NUM_REGIONS 50

void set_rules_example(sx_flex_acl_flex_rule_t *rules);

sx_acl_key_t              key_id_set_example[] = {
    FLEX_ACL_KEY_DMAC,
    FLEX_ACL_KEY_SMAC,
    FLEX_ACL_KEY_ETHERTYPE,
    FLEX_ACL_KEY_VLAN_ID,
    FLEX_ACL_KEY_DIP,
    FLEX_ACL_KEY_SIP,
    FLEX_ACL_KEY_IP_PROTO,
    FLEX_ACL_KEY_TTL,
    FLEX_ACL_KEY_L4_DESTINATION_PORT,
    FLEX_ACL_KEY_L4_SOURCE_PORT
};
sx_acl_key_fields_t       key_value_set_example[] = {
    {.dmac = {
         {0x00, 0x25, 0x90, 0xd1, 0xd9, 0x3e}
     }
    },
    {.smac = {
         {0x00, 0x25, 0x90, 0xd1, 0xd9, 0x3f}
     }
    },
    {.ethertype = 0x1234},
    {.vlan_id = 0x567},
    {.dip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xC0A80101}
             }
     }
    },
    {.sip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xC0A80101}
             }
     }
    },
    {.ip_proto = 1},
    {.ttl = 1},
    {.l4_destination_port = 100},
    {.l4_source_port = 101},
};
sx_acl_mask_fields_t      key_mask_set_example[] = {
    {.dmac = {
         {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}
     }
    },
    {.smac = {
         {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}
     }
    },
    {.ethertype = 0xFFFF},
    {.vlan_id = 0xFFF},
    {.dip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xFFFFFFFF}
             }
     }
    },
    {.sip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xFFFFFFFF}
             }
     }
    },
    {.ip_proto = 0xFF},
    {.ttl = 0xFF},
    {.l4_destination_port = 0xFFFF},
    {.l4_source_port = 0xFFFF},
};
sx_flex_acl_flex_action_t action_set_example[] = {
    {.type = SX_FLEX_ACL_ACTION_FORWARD, .fields =
     {.action_forward = {.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_TRAP, .fields =
     {.action_trap = {.action = SX_ACL_TRAP_ACTION_TYPE_TRAP, .trap_id = SX_TRAP_ID_ACL_MIN}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_PRIO, .fields = {.action_set_prio = {.prio_val = 10}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_VLAN, .fields =
     {.action_set_vlan = {.cmd = SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH, .vlan_id = 0x888}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_DSCP, .fields = {.action_set_dscp = {.dscp_val = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_DSCP, .fields = {.action_set_dscp = {.dscp_val = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_DSCP, .fields = {.action_set_dscp = {.dscp_val = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_TC, .fields = {.action_set_tc = {.tc_val = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_TTL, .fields = {.action_set_ttl = {.ttl_val = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_DEC_TTL, .fields = {.action_dec_ttl = {.ttl_val = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_COLOR, .fields = {.action_set_color = {.color_val = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_ECN, .fields = {.action_set_ecn = {.ecn_val = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_USER_TOKEN, .fields = {.action_set_user_token = {.user_token = 0, .mask = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_DONT_LEARN},
    {.type = SX_FLEX_ACL_ACTION_GOTO, .fields = {.action_goto = {.goto_action_cmd = SX_ACL_ACTION_GOTO_TERMINATE}
     }
    },
};
int                       num_keys_ex = sizeof(key_id_set_example) / sizeof(key_id_set_example[0]);
int                       num_actions_ex = sizeof(action_set_example) / sizeof(action_set_example[0]);
sx_flex_acl_flex_rule_t   rules_example[NUM_RULES];
sx_acl_rule_offset_t      offset_list_example[REGION_SIZE];

int main(int argc, char *argv[])
{
    sx_status_t           sx_status;
    sx_api_handle_t       api_handle;
    sx_acl_key_type_t     key_handle;
    int                   iii;
    int                   rules_to_send = 0;
    int                   rule_count = 0;
    int                   rule_count_start = 0;
    sx_acl_region_id_t    region_id[NUM_REGIONS];
    sx_acl_region_group_t acl_region_group;
    sx_acl_id_t           acl_id[NUM_REGIONS];
    sx_acl_direction_t    acl_direction = SX_ACL_DIRECTION_INGRESS;
    sx_acl_id_t           acl_group_id[NUM_REGIONS];
    sx_acl_id_t           acl_id_list[1];
    char                  sss[8];

    memset(&rules_example, 0, sizeof(rules_example));
    memset(&offset_list_example, 0, sizeof(offset_list_example));

    UNUSED_PARAM(argc);

    /* Open SDK API */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Create key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_set_example,
                                        num_keys_ex,
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
        exit(1);
    }

    /* Create region */
    for (iii = 0; iii < NUM_REGIONS; iii++) {
        sx_status = sx_api_acl_region_set(api_handle,
                                          SX_ACCESS_CMD_CREATE,
                                          key_handle,
                                          SX_ACL_ACTION_TYPE_EXTENDED,
                                          REGION_SIZE,
                                          &region_id[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
            exit(1);
        }

        /* Create ACL */
        acl_region_group.regions.acl_packet_agnostic.region = region_id[iii];
        sx_status = sx_api_acl_set(api_handle,
                                   SX_ACCESS_CMD_CREATE,
                                   SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                   acl_direction,
                                   &acl_region_group,
                                   &acl_id[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
            exit(1);
        }

        /* Create ACL group */
        sx_status = sx_api_acl_group_set(api_handle,
                                         SX_ACCESS_CMD_CREATE,
                                         acl_direction,
                                         acl_id_list,
                                         0,
                                         &acl_group_id[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            exit(1);
        }

        acl_id_list[0] = acl_id[iii];
        sx_status = sx_api_acl_group_set(api_handle,
                                         SX_ACCESS_CMD_SET,
                                         acl_direction,
                                         acl_id_list,
                                         1,
                                         &acl_group_id[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            exit(1);
        }
    }
    /* Initialize rules array */
    for (iii = 0; iii < NUM_RULES; iii++) {
        /* Each rule is initialized to max number of keys and max number of actions */
        sx_status = sx_lib_flex_acl_rule_init(key_handle, num_actions_ex, &rules_example[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_lib_flex_acl_rule_init failed: [%s] \n", sx_status_str(sx_status));
            exit(1);
        }
    }

    /* Set example rule values: keys and actions */
    set_rules_example(rules_example);

    /* Create rules in SDK */
    rule_count = REGION_SIZE;
    rule_count_start = 0;
    rules_to_send = 20;

    for (iii = 0; iii < NUM_REGIONS; iii++) {
        sx_status = sx_api_acl_flex_rules_set(api_handle,
                                              SX_ACCESS_CMD_SET,
                                              region_id[iii],
                                              offset_list_example,
                                              rules_example,
                                              REGION_SIZE);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_acl_flex_rules_set failed [%s]\n", sx_status_str(sx_status));
            exit(1);
        }
    }

    /* De-Initialize rules array */
    for (iii = 0; iii < NUM_RULES; iii++) {
        /* Each rule is initialized to max number of keys and max number of actions */
        sx_status = sx_lib_flex_acl_rule_deinit(&rules_example[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_lib_flex_acl_rule_deinit failed: [%s] \n", sx_status_str(sx_status));
            exit(1);
        }
    }

    printf("%s: configuration created.\n", argv[0]);
    printf("Enter any character and press enter to create debug dump \n");
    scanf("%1s", sss);

    /* Create Debug Dump */
    sx_status = sx_api_dbg_generate_dump(api_handle, "/tmp/sdkdump1.test");
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_dbg_generate_dump failed [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    printf("Enter any character and press enter to proceed to cleanup \n");
    scanf("%1s", sss);

    /* Delete rules in SDK */
    rule_count = NUM_RULES;
    rule_count_start = 0;
    rules_to_send = 20;
    while (rule_count > 0) {
        if (rule_count < rules_to_send) {
            rules_to_send = rule_count;
        }
        printf("DBG: Deleting %d rules: start:%d rules left:%d \n", rules_to_send, rule_count_start, rule_count);
        sx_status = sx_api_acl_flex_rules_set(api_handle,
                                              SX_ACCESS_CMD_DELETE,
                                              region_id[0],
                                              &offset_list_example[rule_count_start],
                                              NULL,
                                              rules_to_send);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_api_acl_flex_rules_set failed [%s]\n", sx_status_str(sx_status));
            exit(1);
        }

        rule_count -= rules_to_send;
        rule_count_start += rules_to_send;
    }

    /* Delete ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        exit(1);
    }

    /* Delete ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id[0];
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
        exit(1);
    }

    /* Delete region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      NUM_RULES,
                                      &region_id[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
        exit(1);
    }

    /* Delete key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_DELETE,
                                        key_id_set_example,
                                        num_keys_ex,
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
        exit(1);
    }

    /* Close SDK API */
    sx_status = sx_api_close(&api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    printf("Successfully finished\n");
    return 0;
}

/* Set rules example values */
void set_rules_example(sx_flex_acl_flex_rule_t *rules_example)
{
    uint32_t iii, jjj;

    printf("Generated rules example: %d rules\n", NUM_RULES);
    for (iii = 0; iii < NUM_RULES; iii++) {
        printf("Rule %d: \n", iii);
        /* Take random number between [0,num_keys_example] */
        /* coverity[dont_call] */
        rules_example[iii].key_desc_count = rand() % (num_keys_ex);
        printf("\t Keys count: %d\n", rules_example[iii].key_desc_count);
        for (jjj = 0; jjj < rules_example[iii].key_desc_count; jjj++) {
            rules_example[iii].key_desc_list_p[jjj].key_id = key_id_set_example[jjj];
            rules_example[iii].key_desc_list_p[jjj].key = key_value_set_example[jjj];
            rules_example[iii].key_desc_list_p[jjj].mask = key_mask_set_example[jjj];
            printf("\t\t Key %d: key_id:%d\n", jjj, rules_example[iii].key_desc_list_p[jjj].key_id);
        }

        rules_example[iii].action_count = rand() % num_actions_ex;
        printf("\t Actions count: %d\n", rules_example[iii].action_count);
        for (jjj = 0; jjj < rules_example[iii].action_count; jjj++) {
            rules_example[iii].action_list_p[jjj] = action_set_example[jjj];
            printf("\t\t Action %d: action type:%d\n", jjj, rules_example[iii].action_list_p[jjj].type);
        }

        rules_example[iii].valid = 1;
        offset_list_example[iii] = iii % REGION_SIZE;
    }
    for (iii = 0; iii < REGION_SIZE; iii++) {
        offset_list_example[iii] = iii;
    }
    printf("End of rules example: %d rules\n", NUM_RULES);
}
