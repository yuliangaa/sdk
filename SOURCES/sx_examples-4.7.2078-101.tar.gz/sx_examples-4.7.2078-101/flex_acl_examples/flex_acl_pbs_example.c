/*
 * Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api_init.h>
#include <arpa/inet.h>
#include <sx/sdk/sx_api_flow_counter.h>
#include <sx/sdk/sx_lib_flex_acl.h>

#define NUM_KEYS          3
#define NUM_ACLS_IN_GROUP 1
#define NUM_RULES         1
#define NUM_ACTIONS       2
#define SWID              0

int main(int argc, char *argv[])
{
    sx_api_handle_t         api_handle;
    sx_status_t             sx_status;
    sx_acl_key_t            keys[NUM_KEYS];
    sx_acl_key_type_t       key_handle;
    sx_acl_region_id_t      region_id;
    sx_acl_region_group_t   acl_region_group;
    sx_acl_id_t             acl_id;
    sx_acl_id_t             acl_id_list[NUM_ACLS_IN_GROUP];
    sx_acl_id_t             acl_group_id;
    sx_port_log_id_t        src_port = 0x10001;
    sx_port_log_id_t        bind_port = 0x10001;
    sx_acl_rule_offset_t    offsets_list[NUM_RULES];
    sx_flex_acl_flex_rule_t rules_list[NUM_RULES];
    int                     iii;
    sx_flow_counter_id_t    counter_id;
    sx_acl_pbs_entry_t      pbs_entry;
    sx_port_log_id_t        pbs_ports[1];
    sx_acl_pbs_id_t         pbs_id;
    sx_flow_counter_set_t   counter_set;
    char                    sss[8];

    UNUSED_PARAM(argc);

    /* Open SDK */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);

    /* Create ACL key handle */
    keys[0] = FLEX_ACL_KEY_SRC_PORT;
    keys[1] = FLEX_ACL_KEY_DIP;
    keys[2] = FLEX_ACL_KEY_IP_PROTO;
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_CREATE,
                                        keys,
                                        NUM_KEYS,
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created ACL key handle: %#x \n", key_handle);

    /* Create ACL region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_CREATE,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      NUM_RULES,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created ACL region: %#x \n", region_id);

    /* Create ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_CREATE,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               SX_ACL_DIRECTION_INGRESS,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created ACL Id: %#x \n", acl_id);

    /* Create ACL Group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_CREATE,
                                     SX_ACL_DIRECTION_INGRESS,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created ACL Group Id: %#x \n", acl_group_id);

    /* Set ACL to ACL Group */
    acl_id_list[0] = acl_id;
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_SET,
                                     SX_ACL_DIRECTION_INGRESS,
                                     acl_id_list,
                                     NUM_ACLS_IN_GROUP,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: ACL Id %#x added to ACL Group Id: %#x \n", acl_id, acl_group_id);

    /* Create Flow Counter */
    sx_status = sx_api_flow_counter_set(api_handle, SX_ACCESS_CMD_CREATE, SX_FLOW_COUNTER_TYPE_PACKETS, &counter_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flow_counter_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created Flow Counter id: %#x \n", counter_id);

    /* Create PBS entry */
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_UNICAST;
    pbs_entry.port_num = 1;
    pbs_entry.log_ports = pbs_ports;
    pbs_ports[0] = 0x10025;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created PBS entry id: %#x \n", pbs_id);

    /* Initialize ACL rules structure */
    for (iii = 0; iii < NUM_RULES; iii++) {
        sx_status = sx_lib_flex_acl_rule_init(key_handle, NUM_ACTIONS, &rules_list[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_lib_flex_acl_rule_init failed: [%s]\n", sx_status_str(sx_status));
            exit(1);
        }
    }
    printf("SDK API: %d ACL rules initialized \n", NUM_RULES);

    /* Create ACL rule */
    offsets_list[0] = 0;
    rules_list[0].valid = 1;
    rules_list[0].key_desc_count = 1;
    rules_list[0].key_desc_list_p[0].key_id = FLEX_ACL_KEY_SRC_PORT;
    rules_list[0].key_desc_list_p[0].key.src_port = src_port;
    rules_list[0].key_desc_list_p[0].mask.src_port = 0x1;

    rules_list[0].action_count = 2;
    rules_list[0].action_list_p[0].type = SX_FLEX_ACL_ACTION_COUNTER;
    rules_list[0].action_list_p[0].fields.action_counter.counter_id = counter_id;

    rules_list[0].action_list_p[1].type = SX_FLEX_ACL_ACTION_PBS;
    rules_list[0].action_list_p[1].fields.action_pbs.pbs_id = pbs_id;

    sx_status = sx_api_acl_flex_rules_set(api_handle,
                                          SX_ACCESS_CMD_SET,
                                          region_id,
                                          offsets_list,
                                          rules_list,
                                          NUM_RULES);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_rules_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: ACL rule offset %d set in region %#x\n", offsets_list[0], region_id);

    /* Bind ACL group to port */
    sx_status = sx_api_acl_port_bind_set(api_handle,
                                         SX_ACCESS_CMD_BIND,
                                         bind_port,
                                         acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_port_bind_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: ACL group id %#x bound to port %#x\n", acl_group_id, bind_port);

    printf("%s: configuration created.\n", argv[0]);
    printf("Enter any character and press enter to check the counter \n");
    scanf("%1s", sss);

    /* Get flow counter value */
    sx_status = sx_api_flow_counter_get(api_handle, SX_ACCESS_CMD_READ, counter_id, &counter_set);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flow_counter_get failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: Flow counter id %#x value: %" PRIu64 "\n", counter_id, counter_set.flow_counter_packets);

    printf("Enter any character and press enter to proceed to cleanup \n");
    scanf("%1s", sss);

    /* Unbind ACL group from port */
    sx_status = sx_api_acl_port_bind_set(api_handle,
                                         SX_ACCESS_CMD_UNBIND,
                                         bind_port,
                                         acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_port_bind_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: ACL group id %#x unbound from port %#x\n", acl_group_id, bind_port);

    /* Delete rules */
    sx_status = sx_api_acl_flex_rules_set(api_handle,
                                          SX_ACCESS_CMD_DELETE,
                                          region_id,
                                          offsets_list,
                                          rules_list,
                                          NUM_RULES);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_rules_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: %d ACL rules deleted\n", NUM_RULES);

    /* De-initialize ACL rules structure */
    for (iii = 0; iii < NUM_RULES; iii++) {
        sx_status = sx_lib_flex_acl_rule_deinit(&rules_list[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR: SDK API sx_lib_flex_acl_rule_deinit failed: [%s]\n", sx_status_str(sx_status));
            exit(1);
        }
    }
    printf("SDK API: ACL rules structure de-initialized\n");

    /* Delete PBS entry */
    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_DELETE,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: PBS entry deleted \n");

    /* Delete Flow Counter */
    sx_status = sx_api_flow_counter_set(api_handle, SX_ACCESS_CMD_DESTROY, SX_FLOW_COUNTER_TYPE_PACKETS, &counter_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flow_counter_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: Flow counter deleted \n");

    /* Destroy ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     SX_ACL_DIRECTION_INGRESS,
                                     acl_id_list,
                                     NUM_ACLS_IN_GROUP,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: ACL group destroyed \n");

    /* Destroy ACL */
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               SX_ACL_DIRECTION_INGRESS,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: ACL destroyed \n");

    /* Destroy ACL region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      NUM_RULES,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: ACL region destroyed \n");

    /* Delete ACL Key Handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_DELETE,
                                        keys,
                                        NUM_KEYS,
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: ACL key handle deleted \n");

    return 0;
}
