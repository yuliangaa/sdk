/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_dbg.h>
#include <complib/sx_log.h>

sx_acl_key_t            key_id_set_example[] = {
    FLEX_ACL_KEY_ETHERTYPE,
};
sx_acl_key_type_t       key_handle;
sx_acl_region_id_t      region_id;
sx_acl_region_group_t   acl_region_group;
sx_acl_id_t             acl_id;
sx_acl_id_t             acl_group_id_ingress;
sx_acl_id_t             acl_group_id_egress;
sx_acl_id_t             acl_id_list[1];
sx_port_log_id_t        log_ports[] = {0x10001, 0x10005, 0x10009};
sx_flex_acl_flex_rule_t rules_example[16];


sx_status_t create_acl_region_group(sx_api_handle_t api_handle)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_acl_rule_offset_t offset = 0;
    sx_acl_attributes_t  acl_attributes;


    /* Create key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_set_example,
                                        sizeof(key_id_set_example) / sizeof(key_id_set_example[0]),
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_CREATE,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      16,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_CREATE,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               SX_ACL_DIRECTION_MULTI_POINTS_E,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Set the ACL as multi direction - needed for this example only. Not mandatory for all RBB */
    memset(&acl_attributes, 0,  sizeof(acl_attributes));
    acl_attributes.multi_direction.acl_direction_bitmap =
        (1 << SX_ACL_DIRECTION_INGRESS) | (1 << SX_ACL_DIRECTION_EGRESS);
    sx_status = sx_api_acl_attributes_set(api_handle, SX_ACCESS_CMD_SET, acl_id, acl_attributes);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_attributes_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create ACL group for ingress */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_CREATE,
                                     SX_ACL_DIRECTION_INGRESS,
                                     acl_id_list,
                                     0,
                                     &acl_group_id_ingress);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    acl_id_list[0] = acl_id;
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_SET,
                                     SX_ACL_DIRECTION_INGRESS,
                                     acl_id_list,
                                     1,
                                     &acl_group_id_ingress);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create ACL group for ingress */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_CREATE,
                                     SX_ACL_DIRECTION_EGRESS,
                                     acl_id_list,
                                     0,
                                     &acl_group_id_egress);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    acl_id_list[0] = acl_id;
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_SET,
                                     SX_ACL_DIRECTION_EGRESS,
                                     acl_id_list,
                                     1,
                                     &acl_group_id_egress);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }


    /* Create a rule just for the example */
    sx_status = sx_lib_flex_acl_rule_init(key_handle, 1, &rules_example[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_lib_flex_acl_rule_init failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }
    rules_example[0].valid = 1;
    rules_example[0].key_desc_count = 1;
    rules_example[0].action_count = 1;

    /* Use the GP register offset as keys to this rule. This is not mandatory just an example */
    rules_example[0].key_desc_list_p[0].key_id = FLEX_ACL_KEY_ETHERTYPE;
    rules_example[0].key_desc_list_p[0].key.ethertype = 0x800;
    rules_example[0].key_desc_list_p[0].mask.ethertype = 0xFFFF;

    /* Set the EMT action */

    rules_example[0].action_list_p[0].type = SX_FLEX_ACL_ACTION_SET_TTL;
    rules_example[0].action_list_p[0].fields.action_set_ttl.ttl_val = 0x77;

    sx_status = sx_api_acl_flex_rules_set(api_handle,
                                          SX_ACCESS_CMD_SET,
                                          region_id,
                                          &offset,
                                          &rules_example[0],
                                          1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_rules_set failed [%s]\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules_example[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_lib_flex_acl_rule_deinit failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }


out:
    return sx_status;
}

sx_status_t delete_acl_region_group(sx_api_handle_t api_handle)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    /* Delete ACL groups */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     SX_ACL_DIRECTION_EGRESS,
                                     acl_id_list,
                                     0,
                                     &acl_group_id_egress);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     SX_ACL_DIRECTION_INGRESS,
                                     acl_id_list,
                                     0,
                                     &acl_group_id_ingress);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               SX_ACL_DIRECTION_MULTI_POINTS_E,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      16,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_DELETE,
                                        key_id_set_example,
                                        sizeof(key_id_set_example) / sizeof(key_id_set_example[0]),
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}


int main(int argc, char *argv[])
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_api_handle_t              api_handle;
    sx_acl_rbb_rule_id_t         ingress_rbb_rule;
    sx_acl_rbb_rule_id_t         egress_rbb_rule;
    sx_acl_rbb_classifier_attr_t ingress_classifier;
    sx_acl_rbb_classifier_attr_t egress_classifier;
    sx_acl_rbb_ports_group_cfg_t rbb_ports_group_cfg;

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    /* Open SDK API */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Create the ACL region along with two ACL groups: One for ingress and one for egress */
    sx_status = create_acl_region_group(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed creating ACL region or group. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Create two rules that will be used for the RBB binding later */
    memset(&ingress_rbb_rule, 0, sizeof(ingress_rbb_rule));
    memset(&egress_rbb_rule, 0, sizeof(egress_rbb_rule));

    ingress_rbb_rule.rule_direction = SX_ACL_RBB_DIRECTION_INGRESS_E;
    ingress_rbb_rule.rule_offset = SX_ACL_RBB_RULE_OFFSET_2_E;
    sx_status = sx_api_acl_rbb_rules_set(api_handle, SX_ACCESS_CMD_CREATE, &ingress_rbb_rule, 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_rules_set create. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    egress_rbb_rule.rule_direction = SX_ACL_RBB_DIRECTION_EGRESS_E;
    egress_rbb_rule.rule_offset = SX_ACL_RBB_RULE_OFFSET_0_E;
    sx_status = sx_api_acl_rbb_rules_set(api_handle, SX_ACCESS_CMD_CREATE, &egress_rbb_rule, 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_rules_set create. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Set some ports to two port groups */
    memset(&rbb_ports_group_cfg, 0, sizeof(rbb_ports_group_cfg));
    rbb_ports_group_cfg.direction = SX_ACL_RBB_DIRECTION_EGRESS_E;
    rbb_ports_group_cfg.port_group = SX_ACL_RBB_PORT_GROUP_1_E;
    rbb_ports_group_cfg.port_list_p = &log_ports[0];
    rbb_ports_group_cfg.port_list_cnt = 2;
    sx_status = sx_api_acl_rbb_ports_group_set(api_handle, SX_ACCESS_CMD_ADD, &rbb_ports_group_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_ports_group_set set. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    memset(&rbb_ports_group_cfg, 0, sizeof(rbb_ports_group_cfg));
    rbb_ports_group_cfg.direction = SX_ACL_RBB_DIRECTION_EGRESS_E;
    rbb_ports_group_cfg.port_group = SX_ACL_RBB_PORT_GROUP_2_E;
    rbb_ports_group_cfg.port_list_p = &log_ports[2];
    rbb_ports_group_cfg.port_list_cnt = 1;
    sx_status = sx_api_acl_rbb_ports_group_set(api_handle, SX_ACCESS_CMD_ADD, &rbb_ports_group_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_ports_group_set set. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    memset(&ingress_classifier, 0, sizeof(ingress_classifier));

    ingress_classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_list[0] = log_ports[0];
    ingress_classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_list[1] = log_ports[2];
    ingress_classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_cnt = 2;
    ingress_classifier.bind_object_classifiers.ingress_port_classifiers.rbb_tunnel_port_list[0] =
        SX_TUNNEL_PORT_ID_NVE;
    ingress_classifier.bind_object_classifiers.ingress_port_classifiers.rbb_tunnel_port_cnt = 1;
    ingress_classifier.l3_type_classifiers = SX_ACL_RBB_CLASSIFIER_L3_TYPE_IPV4_E |
                                             SX_ACL_RBB_CLASSIFIER_L3_TYPE_MPLS_E;
    ingress_classifier.l4_type_classifiers = SX_ACL_RBB_CLASSIFIER_L4_TYPE_UDP_E |
                                             SX_ACL_RBB_CLASSIFIER_L4_TYPE_ICMP_E;
    sx_status = sx_api_acl_rbb_bind_set(api_handle,
                                        SX_ACCESS_CMD_BIND,
                                        ingress_rbb_rule,
                                        &ingress_classifier,
                                        acl_group_id_ingress);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_bind_set bind. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    memset(&egress_classifier, 0, sizeof(egress_classifier));

    egress_classifier.bind_object_classifiers.egress_port_classifiers.rbb_port_group_list[0] =
        SX_ACL_RBB_PORT_GROUP_1_E;
    egress_classifier.bind_object_classifiers.egress_port_classifiers.rbb_port_group_list[1] =
        SX_ACL_RBB_PORT_GROUP_2_E;
    egress_classifier.bind_object_classifiers.egress_port_classifiers.rbb_port_group_cnt = 2;
    egress_classifier.bind_object_classifiers.egress_port_classifiers.rbb_tunnel_port_list[0] =
        SX_TUNNEL_PORT_ID_FLEX1;
    egress_classifier.bind_object_classifiers.egress_port_classifiers.rbb_tunnel_port_cnt = 1;
    egress_classifier.l3_type_classifiers = SX_ACL_RBB_CLASSIFIER_L3_TYPE_IPV6_E;
    egress_classifier.l3_multicast_classifiers = SX_ACL_RBB_CLASSIFIER_L3_MULTICAST_NOT_MC_E;
    egress_classifier.flex_parser_fpp_classifiers = SX_ACL_RBB_CLASSIFIER_FLEX_PARSER_FPP_4_E |
                                                    SX_ACL_RBB_CLASSIFIER_FLEX_PARSER_FPP_6_E;

    sx_status = sx_api_acl_rbb_bind_set(api_handle,
                                        SX_ACCESS_CMD_BIND,
                                        egress_rbb_rule,
                                        &egress_classifier,
                                        acl_group_id_egress);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_bind_set bind. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* We're done with the configuration. Now we delete everything. */


    /* Remove the binding */
    sx_status = sx_api_acl_rbb_bind_set(api_handle,
                                        SX_ACCESS_CMD_UNBIND,
                                        ingress_rbb_rule,
                                        &ingress_classifier,
                                        acl_group_id_ingress);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_bind_set unbind. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_acl_rbb_bind_set(api_handle,
                                        SX_ACCESS_CMD_UNBIND,
                                        egress_rbb_rule,
                                        &egress_classifier,
                                        acl_group_id_egress);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_bind_set unbind. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Remove ports to from groups - not strictly necessary */
    memset(&rbb_ports_group_cfg, 0, sizeof(rbb_ports_group_cfg));
    rbb_ports_group_cfg.direction = SX_ACL_RBB_DIRECTION_EGRESS_E;
    rbb_ports_group_cfg.port_group = SX_ACL_RBB_PORT_GROUP_1_E;
    rbb_ports_group_cfg.port_list_p = &log_ports[0];
    rbb_ports_group_cfg.port_list_cnt = 2;
    sx_status = sx_api_acl_rbb_ports_group_set(api_handle, SX_ACCESS_CMD_DELETE, &rbb_ports_group_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_ports_group_set unset. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    memset(&rbb_ports_group_cfg, 0, sizeof(rbb_ports_group_cfg));
    rbb_ports_group_cfg.direction = SX_ACL_RBB_DIRECTION_EGRESS_E;
    rbb_ports_group_cfg.port_group = SX_ACL_RBB_PORT_GROUP_2_E;
    rbb_ports_group_cfg.port_list_p = &log_ports[2];
    rbb_ports_group_cfg.port_list_cnt = 1;
    sx_status = sx_api_acl_rbb_ports_group_set(api_handle, SX_ACCESS_CMD_DELETE, &rbb_ports_group_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_ports_group_set unset. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Destroy the rules */
    sx_status = sx_api_acl_rbb_rules_set(api_handle, SX_ACCESS_CMD_DESTROY, &ingress_rbb_rule, 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_rules_set destroy. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    sx_status = sx_api_acl_rbb_rules_set(api_handle, SX_ACCESS_CMD_DESTROY, &egress_rbb_rule, 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed sx_api_acl_rbb_rules_set destroy. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = delete_acl_region_group(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: failed deleting ACL region or group. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Close SDK API */
    sx_status = sx_api_close(&api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    printf("Successfully finished\n");
    return 0;
}
