/*
 * SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <stdio.h>
#include <unistd.h>
#include <poll.h>
#include <fcntl.h>
#include <string.h>

#define SX_NETDEV_PREFIX                 "/sys/module/sx_netdev/"
#define SX_NETDEV_PRESENT_SUFFIX         "/module/present"
#define SX_CORE_MODULE_PREFIX            "/sys/module/sx_core/asic0/module"
#define SX_CORE_MODULE_PRESENT_SUFFIX    "/present"
#define SX_CORE_MODULE_HW_PRESENT_SUFFIX "/hw_present"
#define SX_PORT_INTERFACE_MAX_LEN        16
#define SX_MODULE_ID_MAX_LEN             4
#define SX_VDATA_LEN                     64

static void __display_usage(FILE *stream, char *cmd)
{
    fprintf(stream, "Usage:\n\t %s [ -p <netdev port> ] [ -m <module id> ] [ -d < independent module id> ]\n", cmd);
}

int main(int argc, char **argv)
{
    int               rc = 0;
    int               opt = 0;
    const char* const short_options = "p:m:d:h";
    char            * port = NULL;
    char            * module_id = NULL;
    char              port_path[128];
    char              module_path[128];
    struct pollfd     ufds[2];
    char            * sysfs_node[2];
    char              vdata[SX_VDATA_LEN + 1];
    ssize_t           len = 0;
    int               i = 0;
    int               count = 0;

    memset(port_path, 0, 128);
    memset(module_path, 0, 128);

    if (argc < 2) {
        sysfs_node[0] = "/sys/module/sx_netdev/p10049/module/present";
        sysfs_node[1] = "/sys/module/sx_core/asic0/module24/present";
        count = 2;
        printf("Listen on default path [%s] and [%s]\n", sysfs_node[0], sysfs_node[1]);
    } else {
        do {
            opt = getopt(argc, argv, short_options);
            switch (opt) {
            case 'p':
                port = optarg;
                strncpy(port_path, SX_NETDEV_PREFIX, strlen(SX_NETDEV_PREFIX));
                strncat(port_path, port, SX_PORT_INTERFACE_MAX_LEN);
                strcat(port_path, SX_NETDEV_PRESENT_SUFFIX);
                printf("Listen on [%s]\n", port_path);
                sysfs_node[count++] = port_path;
                break;

            case 'm':
                module_id = optarg;
                strncpy(module_path, SX_CORE_MODULE_PREFIX, strlen(SX_CORE_MODULE_PREFIX));
                strncat(module_path, module_id, SX_MODULE_ID_MAX_LEN);
                strcat(module_path, SX_CORE_MODULE_PRESENT_SUFFIX);
                printf("Listen on [%s]\n", module_path);
                sysfs_node[count++] = module_path;
                break;

            case 'd':
                module_id = optarg;
                strncpy(module_path, SX_CORE_MODULE_PREFIX, strlen(SX_CORE_MODULE_PREFIX));
                strncat(module_path, module_id, SX_MODULE_ID_MAX_LEN);
                strcat(module_path, SX_CORE_MODULE_HW_PRESENT_SUFFIX);
                printf("Listen on [%s]\n", module_path);
                sysfs_node[count++] = module_path;
                break;

            case -1:
                break;

            case 'h':
            case '?':
            default:
                __display_usage(stdout, argv[0]);
                goto out;
            }
        } while (opt != -1);
    }

    for (i = 0; i < count; i++) {
        memset(vdata, 0, sizeof(vdata));
        ufds[i].fd = open(sysfs_node[i], O_RDONLY);
        ufds[i].events = POLLERR | POLLPRI;
        /* dummy read first before poll since there's always sys_notify event when sysfs node created */
        len = pread(ufds[i].fd, vdata, SX_VDATA_LEN, 0);
    }

    while (1) {
        rc = poll(ufds, count, -1);
        if (rc > 0) {
            for (i = 0; i < count; i++) {
                if (ufds[i].revents & POLLPRI) {
                    memset(vdata, 0, sizeof(vdata));
                    len = pread(ufds[i].fd, vdata, SX_VDATA_LEN, 0);
                    printf("Got event on [%s]: present = %s, len = %ld\n", sysfs_node[i], vdata, len);
                }
            }
        }
    }

out:
    return 0;
}
