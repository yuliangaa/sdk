/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/pcc/sx_pcc_types.h>
#include <sx/pcc/sx_pcc.h>


int main(int argc, char *argv[])
{
    pcc_status_t          pcc_status = PCC_STATUS_SUCCESS;
    pcc_app_init_params_t app_params;
    pcc_app_id_t          app_id = 0;
    uint16_t              num_ports = 0;
    pcc_port_log_id_t    *ports = NULL;
    pcc_app_port_data_t   port_data;
    uint32_t              i = 0;

    if (argc != 0) {
        num_ports = argc - 1;
        ports = (pcc_port_log_id_t *)malloc(num_ports * sizeof(pcc_port_log_id_t));
        if (ports == NULL) {
            pcc_status = PCC_STATUS_NO_RESOURCES;
            printf("ERROR: Failed to allocate memory for port list. [%s]\n", pcc_status_str(pcc_status));
            exit(1);
        }
        for (i = 0; i < num_ports; ++i) {
            if (1 != sscanf(argv[i + 1], "%x", &ports[i])) {
                pcc_status = PCC_STATUS_ERROR;
                printf("ERROR:  Failed to parse argument [%d]. [%s]\n", (i + 1), pcc_status_str(pcc_status));
                exit(1);
            }
        }
    }

    pcc_status = pcc_api_init_set();
    if (pcc_status != PCC_STATUS_SUCCESS) {
        printf("ERROR: SDK API pcc_api_init_set failed. [%s]\n", pcc_status_str(pcc_status));
        exit(1);
    }

    /* Create an HPCC APP */
    app_params.pcc_app_type = PCC_APP_HPCC;
    app_params.pcc_app_params.hpcc_params.app_params.device_id = 1;
    app_params.pcc_app_params.hpcc_params.app_resources.emts_data.emt_num = 8;
    for (i = 0; i < 8; i++) {
        app_params.pcc_app_params.hpcc_params.app_resources.emts_data.emts[i] = i;
    }

    app_params.pcc_app_params.hpcc_params.app_resources.gp_registers_data.reg_num = 10;
    for (i = 0; i < 10; i++) {
        app_params.pcc_app_params.hpcc_params.app_resources.gp_registers_data.registers[i] = i;
    }

    pcc_status = pcc_api_app_set(PCC_ACCESS_CMD_ADD_E, &app_params, &app_id);
    if (pcc_status != PCC_STATUS_SUCCESS) {
        printf("ERROR: SDK API pcc_api_app_set failed on create. [%s]\n", pcc_status_str(pcc_status));
        exit(1);
    }


    pcc_status = pcc_api_app_state_set(app_id, PCC_APP_STATE_ENABLE);
    if (pcc_status != PCC_STATUS_SUCCESS) {
        printf("ERROR: SDK API pcc_api_app_state_set failed on create. [%s]\n", pcc_status_str(pcc_status));
        exit(1);
    }

    port_data.cntr_id = 0;
    port_data.port_speed = PCC_PORT_SPEED_100GB;
    if (num_ports) {
        for (i = 0; i < num_ports; ++i) {
            pcc_status = pcc_api_app_port_set(PCC_ACCESS_CMD_ADD_E, app_id, ports[i], &port_data);
            if (pcc_status != PCC_STATUS_SUCCESS) {
                printf("ERROR: SDK API pcc_api_app_port_set failed on add port 0x%08X. [%s]\n",
                       ports[i],
                       pcc_status_str(pcc_status));
                exit(1);
            }
        }
    }

    printf("Successfully finished\n");
    return 0;
}
