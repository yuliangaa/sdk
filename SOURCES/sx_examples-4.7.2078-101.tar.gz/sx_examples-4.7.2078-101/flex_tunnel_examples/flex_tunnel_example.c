/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sdk/sx_api_flex_modifier.h>
#include <sx/sdk/sx_api_flex_parser.h>
#include <sx/sdk/sx_api_register.h>
#include <sx/sdk/sx_api_tunnel.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sdk/sx_api_vlan.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_dbg.h>
#include <complib/sx_log.h>


#define DEFAULT_SWID 0
#define DEFAULT_VLAN 7

#define LOOPBACK_ETHER_ADDR                  \
    (sx_mac_addr_t) {                        \
        {0x00, 0x99, 0x99, 0x99, 0x99, 0x99} \
    }

#define VLAN_RIF_ETHER_ADDR                  \
    (sx_mac_addr_t) {                        \
        {0x00, 0xBB, 0xBB, 0xBB, 0xBB, 0xBB} \
    }

#define NEXT_HOP_ETHER_ADDR                  \
    (sx_mac_addr_t) {                        \
        {0x00, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA} \
    }

#define TUNNEL_DIP 0x0A0A0A0A

sx_acl_key_t            key_id_set_example[] = {
    FLEX_ACL_KEY_ETHERTYPE,
};
sx_acl_key_type_t       key_handle;
sx_acl_region_id_t      region_id;
sx_acl_region_group_t   acl_region_group;
sx_acl_id_t             acl_id;
sx_acl_direction_t      acl_direction = SX_ACL_DIRECTION_INGRESS;
sx_acl_id_t             acl_group_id;
sx_acl_id_t             acl_id_list[1];
sx_port_log_id_t        ingress_log_port = 0x10005;
sx_port_log_id_t        egress_log_port = 0x10009;
sx_router_interface_t   underlay_rif_id = 0;
sx_ecmp_id_t            underlay_ecmp_id = 0;
sx_flex_acl_flex_rule_t rules_example[16];


sx_status_t create_tunnel_pbs_rule(sx_api_handle_t api_handle, sx_ecmp_id_t ecmp_id)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_acl_rule_offset_t offset = 0;


    /* Create key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_set_example,
                                        sizeof(key_id_set_example) / sizeof(key_id_set_example[0]),
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_CREATE,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      16,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_CREATE,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_CREATE,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    acl_id_list[0] = acl_id;
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_SET,
                                     acl_direction,
                                     acl_id_list,
                                     1,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Bind the group to the ingress port */
    sx_status = sx_api_acl_port_bind_set(api_handle, SX_ACCESS_CMD_BIND, ingress_log_port, acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_port_bind_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create a rule that will send the packet to the flex tunnel inside the ecmp we've created */
    sx_status = sx_lib_flex_acl_rule_init(key_handle, 2, &rules_example[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_lib_flex_acl_rule_init failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }
    rules_example[0].valid = 1;
    rules_example[0].key_desc_count = 1;
    rules_example[0].action_count = 1;

    rules_example[0].valid = 1;
    rules_example[0].key_desc_count = 1;
    rules_example[0].key_desc_list_p[0].key_id = FLEX_ACL_KEY_ETHERTYPE;  /* Dummy key - all packets will match */
    rules_example[0].action_count = 2;
    /* Use the TTL as the NVGRE VSID in this example - we set the TTL at offset 8 to fit in the VSID. */
    rules_example[0].action_list_p[0].type = SX_FLEX_ACL_ACTION_ALU_FIELD;
    rules_example[0].action_list_p[0].fields.action_alu_field.command = SX_ACL_ACTION_ALU_FIELD_COMMAND_SET;
    rules_example[0].action_list_p[0].fields.action_alu_field.dst_offset = 8;
    rules_example[0].action_list_p[0].fields.action_alu_field.dst_register = SX_GP_REGISTER_1_E;
    rules_example[0].action_list_p[0].fields.action_alu_field.src_field = SX_FLEX_ACL_FIELD_SELECT_TTL;
    rules_example[0].action_list_p[0].fields.action_alu_field.src_field_offset = 0;
    rules_example[0].action_list_p[0].fields.action_alu_field.size = 8;

    rules_example[0].action_list_p[1].type = SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP;
    rules_example[0].action_list_p[1].fields.action_nve_tunnel_encap.encap_type =
        SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_ECMP;
    rules_example[0].action_list_p[1].fields.action_nve_tunnel_encap.ecmp_id = ecmp_id;

    sx_status = sx_api_acl_flex_rules_set(api_handle,
                                          SX_ACCESS_CMD_SET,
                                          region_id,
                                          &offset,
                                          &rules_example[0],
                                          1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_rules_set failed [%s]\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules_example[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_lib_flex_acl_rule_deinit failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }


out:
    return sx_status;
}

sx_status_t delete_tunnel_pbs_rule(sx_api_handle_t api_handle)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    /* Unbind from the egress port */
    sx_status = sx_api_acl_port_bind_set(api_handle, SX_ACCESS_CMD_UNBIND, ingress_log_port, acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_port_bind_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      16,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_DELETE,
                                        key_id_set_example,
                                        sizeof(key_id_set_example) / sizeof(key_id_set_example[0]),
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t create_router(sx_api_handle_t api_handle)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    sx_router_general_param_t   general_params;
    sx_router_resources_param_t router_resource;

    memset(&general_params, 0, sizeof(general_params));
    memset(&router_resource, 0, sizeof(router_resource));

    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.rpf_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_resource.max_virtual_routers_num = 12;
    router_resource.max_router_interfaces = 400;
    router_resource.min_ipv4_neighbor_entries = 10;
    router_resource.min_ipv6_neighbor_entries = 10;
    router_resource.min_ipv4_uc_route_entries = 10;
    router_resource.min_ipv6_uc_route_entries = 10;
    router_resource.min_ipv4_mc_route_entries = 0;
    router_resource.min_ipv6_mc_route_entries = 0;
    router_resource.max_ipv4_neighbor_entries = 1000;
    router_resource.max_ipv6_neighbor_entries = 1000;
    router_resource.max_ipv4_uc_route_entries = 1000;
    router_resource.max_ipv6_uc_route_entries = 1000;
    router_resource.max_ipv4_mc_route_entries = 0;
    router_resource.max_ipv6_mc_route_entries = 0;

    sx_status = sx_api_router_init_set(api_handle, &general_params, &router_resource);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_init_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t create_vrid(sx_api_handle_t api_handle, sx_router_id_t *vrid_p)
{
    sx_status_t            sx_status = SX_STATUS_SUCCESS;
    sx_router_attributes_t router_attr;

    memset(&router_attr, 0, sizeof(router_attr));

    router_attr.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    router_attr.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    router_attr.uc_default_rule_action = SX_ROUTER_ACTION_DROP;
    router_attr.mc_default_rule_action = SX_ROUTER_ACTION_DROP;

    sx_status = sx_api_router_set(api_handle, SX_ACCESS_CMD_ADD, &router_attr, vrid_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t create_loopback_rif(sx_api_handle_t         api_handle,
                                sx_router_id_t          vrid,
                                sx_router_interface_t  *rif_id_p,
                                sx_router_counter_id_t *counter_p)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    sx_router_interface_param_t ifc_param;
    sx_interface_attributes_t   ifc_attr;

    memset(&ifc_param, 0, sizeof(ifc_param));
    memset(&ifc_attr, 0, sizeof(ifc_attr));

    ifc_param.type = SX_L2_INTERFACE_TYPE_LOOPBACK;
    ifc_attr.mac_addr = LOOPBACK_ETHER_ADDR;
    ifc_attr.mtu = 1500;
    ifc_attr.loopback_enable = FALSE;

    sx_status = sx_api_router_interface_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &ifc_param, &ifc_attr, rif_id_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_interface_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_router_counter_set(api_handle, SX_ACCESS_CMD_CREATE, counter_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_counter_set CREATE failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_router_interface_counter_bind_set(api_handle, SX_ACCESS_CMD_BIND, *counter_p, *rif_id_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_counter_set BIND failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }


out:
    return sx_status;
}

sx_status_t destroy_loopback_rif(sx_api_handle_t        api_handle,
                                 sx_router_id_t         vrid,
                                 sx_router_interface_t  rif_id,
                                 sx_router_counter_id_t counter)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    sx_status = sx_api_router_interface_counter_bind_set(api_handle, SX_ACCESS_CMD_UNBIND, counter, rif_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_counter_set UNBIND failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_router_counter_set(api_handle, SX_ACCESS_CMD_DESTROY, &counter);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_counter_set DESTROY failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_router_interface_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, NULL, NULL, &rif_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_interface_set DELETE failed: [%s] \n", sx_status_str(sx_status));
        exit(1);
    }

out:
    return sx_status;
}


sx_status_t create_underlay_routing(sx_api_handle_t api_handle, sx_router_id_t vrid)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    sx_router_interface_param_t ifc_param;
    sx_interface_attributes_t   ifc_attr;
    sx_router_interface_state_t rif_state;
    sx_vlan_ports_t             vlan_port;
    sx_next_hop_t               next_hop;
    uint32_t                    next_hop_cnt = 0;
    sx_ip_addr_t                ip_addr;
    sx_neigh_data_t             neigh_data;
    sx_ip_prefix_t              network_addr;
    sx_uc_route_data_t          uc_route_data;

    memset(&ifc_param, 0, sizeof(ifc_param));
    memset(&ifc_attr, 0, sizeof(ifc_attr));
    memset(&rif_state, 0, sizeof(rif_state));
    memset(&vlan_port, 0, sizeof(vlan_port));
    memset(&next_hop, 0, sizeof(next_hop));
    memset(&ip_addr, 0, sizeof(ip_addr));
    memset(&neigh_data, 0, sizeof(neigh_data));
    memset(&network_addr, 0, sizeof(network_addr));
    memset(&uc_route_data, 0, sizeof(uc_route_data));

    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN;
    ifc_param.ifc.vlan.vlan = DEFAULT_VLAN;
    ifc_attr.mac_addr = VLAN_RIF_ETHER_ADDR;
    ifc_attr.mtu = 1500;

    /* Create an egress rif that will be used to route the underlay packet with */
    sx_status = sx_api_router_interface_set(api_handle,
                                            SX_ACCESS_CMD_ADD,
                                            vrid,
                                            &ifc_param,
                                            &ifc_attr,
                                            &underlay_rif_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_interface_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    rif_state.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    rif_state.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    rif_state.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    rif_state.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;

    sx_status = sx_api_router_interface_state_set(api_handle, underlay_rif_id, &rif_state);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_interface_state_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    vlan_port.is_untagged = SX_TAGGED_MEMBER;
    vlan_port.log_port = egress_log_port;

    sx_status = sx_api_vlan_ports_set(api_handle, SX_ACCESS_CMD_ADD, DEFAULT_SWID, DEFAULT_VLAN, &vlan_port, 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_vlan_ports_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create an ECMP that will route our underlay packet to the next hop */
    sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_CREATE, &underlay_ecmp_id, &next_hop, &next_hop_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_set CREATE failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    ip_addr.version = SX_IP_VERSION_IPV4;
    ip_addr.addr.ipv4.s_addr = 0x02030002;   /* Random IP address just to resolve the next hop */

    next_hop.next_hop_key.type = SX_NEXT_HOP_TYPE_IP;
    next_hop.next_hop_key.next_hop_key_entry.ip_next_hop.address.version = SX_IP_VERSION_IPV4;
    next_hop.next_hop_key.next_hop_key_entry.ip_next_hop.address = ip_addr;
    next_hop.next_hop_key.next_hop_key_entry.ip_next_hop.rif = underlay_rif_id;
    next_hop.next_hop_data.action = SX_ROUTER_ACTION_FORWARD;
    next_hop.next_hop_data.counter_id = SX_FLOW_COUNTER_ID_INVALID;
    next_hop.next_hop_data.weight = 1;
    next_hop_cnt = 1;

    sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_SET, &underlay_ecmp_id, &next_hop, &next_hop_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_set SET failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    neigh_data.action = SX_ROUTER_ACTION_FORWARD;
    neigh_data.mac_addr = NEXT_HOP_ETHER_ADDR;
    neigh_data.rif = underlay_rif_id;
    sx_status = sx_api_router_neigh_set(api_handle, SX_ACCESS_CMD_ADD, underlay_rif_id, &ip_addr, &neigh_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_neigh_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    network_addr.version = SX_IP_VERSION_IPV4;
    network_addr.prefix.ipv4.addr.s_addr = TUNNEL_DIP & 0xffff0000;
    network_addr.prefix.ipv4.mask.s_addr = 0xffff0000;
    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP;
    uc_route_data.uc_route_param.ecmp_id = underlay_ecmp_id;

    /* Create a route with the address of the underlay to be routed to the next hop */
    sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_ADD, vrid, &network_addr, &uc_route_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_uc_route_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t destroy_underlay_routing(sx_api_handle_t api_handle, sx_router_id_t vrid)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    sx_router_interface_param_t ifc_param;
    sx_interface_attributes_t   ifc_attr;
    sx_router_interface_state_t rif_state;
    sx_vlan_ports_t             vlan_port;
    sx_next_hop_t               next_hop;
    uint32_t                    next_hop_cnt = 0;
    sx_ip_addr_t                ip_addr;
    sx_neigh_data_t             neigh_data;
    sx_ip_prefix_t              network_addr;
    sx_uc_route_data_t          uc_route_data;

    memset(&ifc_param, 0, sizeof(ifc_param));
    memset(&ifc_attr, 0, sizeof(ifc_attr));
    memset(&rif_state, 0, sizeof(rif_state));
    memset(&vlan_port, 0, sizeof(vlan_port));
    memset(&next_hop, 0, sizeof(next_hop));
    memset(&ip_addr, 0, sizeof(ip_addr));
    memset(&neigh_data, 0, sizeof(neigh_data));
    memset(&network_addr, 0, sizeof(network_addr));
    memset(&uc_route_data, 0, sizeof(uc_route_data));

    network_addr.version = SX_IP_VERSION_IPV4;
    network_addr.prefix.ipv4.addr.s_addr = TUNNEL_DIP & 0xffff0000;
    network_addr.prefix.ipv4.mask.s_addr = 0xffff0000;
    uc_route_data.action = SX_ROUTER_ACTION_FORWARD;
    uc_route_data.type = SX_UC_ROUTE_TYPE_NEXT_HOP;
    uc_route_data.uc_route_param.ecmp_id = underlay_ecmp_id;

    sx_status = sx_api_router_uc_route_set(api_handle, SX_ACCESS_CMD_DELETE, vrid, &network_addr, &uc_route_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_uc_route_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    ip_addr.version = SX_IP_VERSION_IPV4;
    ip_addr.addr.ipv4.s_addr = 0x02030002;

    neigh_data.action = SX_ROUTER_ACTION_FORWARD;
    neigh_data.mac_addr = NEXT_HOP_ETHER_ADDR;
    neigh_data.rif = underlay_rif_id;
    sx_status = sx_api_router_neigh_set(api_handle, SX_ACCESS_CMD_DELETE, underlay_rif_id, &ip_addr, &neigh_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_neigh_set DELETE failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_DESTROY, &underlay_ecmp_id, &next_hop, &next_hop_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_set DESTROY failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    vlan_port.is_untagged = SX_TAGGED_MEMBER;
    vlan_port.log_port = egress_log_port;

    sx_status = sx_api_vlan_ports_set(api_handle, SX_ACCESS_CMD_DELETE, DEFAULT_SWID, DEFAULT_VLAN, &vlan_port, 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_vlan_ports_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    ifc_param.type = SX_L2_INTERFACE_TYPE_VLAN;
    ifc_param.ifc.vlan.vlan = DEFAULT_VLAN;

    sx_status = sx_api_router_interface_set(api_handle,
                                            SX_ACCESS_CMD_DELETE,
                                            vrid,
                                            &ifc_param,
                                            &ifc_attr,
                                            &underlay_rif_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_interface_set ADD failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t create_tunnel_ecmp(sx_api_handle_t api_handle, sx_tunnel_id_t tunnel_id, sx_ecmp_id_t *ecmp_id_p)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_next_hop_t        next_hop;
    uint32_t             next_hop_cnt = 0;
    sx_ecmp_attributes_t ecmp_attributes;

    memset(&ecmp_attributes, 0, sizeof(ecmp_attributes));
    memset(&next_hop, 0, sizeof(next_hop));

    sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_CREATE, ecmp_id_p, &next_hop, &next_hop_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_set CREATE failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    ecmp_attributes.ecmp_type = SX_ECMP_TYPE_STATIC_E;
    /* The SX_ECMP_CONTAINER_TYPE_NVE_FLOOD or SX_ECMP_CONTAINER_TYPE_NVE_MC container should be
     * used to create ECMP containing tunnels. NVE and flex tunnels can reside in the same ECMP.
     */
    ecmp_attributes.container_type = SX_ECMP_CONTAINER_TYPE_NVE_FLOOD;
    sx_status = sx_api_router_ecmp_attributes_set(api_handle, *ecmp_id_p, &ecmp_attributes);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_attributes_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    next_hop.next_hop_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP;
    next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id = tunnel_id;
    next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip.version = SX_IP_VERSION_IPV4;
    next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip.addr.ipv4.s_addr = TUNNEL_DIP;
    next_hop.next_hop_data.action = SX_ROUTER_ACTION_FORWARD;
    next_hop.next_hop_data.counter_id = SX_FLOW_COUNTER_ID_INVALID;
    next_hop.next_hop_data.weight = 1;
    next_hop_cnt = 1;

    /* This ECMP is used for the encapsulation only. The routing itself is done using the underlay ECMP. */
    sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_SET, ecmp_id_p, &next_hop, &next_hop_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_set SET failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}


sx_status_t tunnel_init(sx_api_handle_t api_handle)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    sx_tunnel_general_params_t params;

    memset(&params, 0, sizeof(params));
    params.nve.encap_sport = 0;
    params.nve.encap_flowlabel = 0;
    params.nve.flood_ecmp_enabled = FALSE;

    sx_status = sx_api_tunnel_init_set(api_handle, &params);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_tunnel_init_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

int main(int argc, char *argv[])
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_api_handle_t              api_handle;
    sx_flex_modifier_emt_key_t   emt_key;
    sx_flex_modifier_emt_cfg_t   emt_cfg;
    sx_register_key_t            register_key;
    uint32_t                     register_count = 0;
    sx_tunnel_flex_header_cfg_t  flex_tunnel_header_cfg;
    sx_tunnel_flex_header_id_t   flex_tunnel_header_id = 0;
    sx_tunnel_attribute_t        tunnel_attr;
    sx_tunnel_id_t               tunnel_id = 0;
    sx_router_interface_t        loopback_rif_id = 0;
    sx_router_counter_id_t       loopback_counter_id = 0;
    sx_router_id_t               vrid = 0;
    sx_ecmp_id_t                 ecmp_id = 0;
    uint32_t                     next_hop_cnt = 0;
    sx_tunnel_decap_entry_key_t  decap_key;
    sx_tunnel_decap_entry_data_t decap_data;
    sx_flex_parser_param_t       parser_params;
    sx_router_interface_state_t  rif_state;
    sx_tunnel_counter_t          tunnel_counter;

    memset(&emt_key, 0, sizeof(emt_key));
    memset(&emt_cfg, 0, sizeof(emt_cfg));
    memset(&register_key, 0, sizeof(register_key));
    memset(&flex_tunnel_header_cfg, 0, sizeof(flex_tunnel_header_cfg));
    memset(&tunnel_attr, 0, sizeof(tunnel_attr));
    memset(&decap_key, 0, sizeof(decap_key));
    memset(&decap_data, 0, sizeof(decap_data));
    memset(&rif_state, 0, sizeof(rif_state));
    memset(&tunnel_counter, 0, sizeof(tunnel_counter));

    memset(&parser_params, 0, sizeof(parser_params));

    /* Open SDK API */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_parser_init_set(api_handle, &parser_params);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_parser_init_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = create_router(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed creating router. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = create_vrid(api_handle, &vrid);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed creating vrid. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* The loopback rif is the entry point to the router that will be used for the underlay */
    sx_status = create_loopback_rif(api_handle, vrid, &loopback_rif_id, &loopback_counter_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed creating loopback rif. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Creating a routing table entry (with ECMP) that will be used to route the newly create underlay */
    sx_status = create_underlay_routing(api_handle, vrid);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed creating underlay routing. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = tunnel_init(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed initializing tunnel module. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Use a GP register to contain the Virtual subnet ID (VSID) for the Flex-NVGRE  */
    register_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
    register_key.key.gp_reg.reg_id = SX_GP_REGISTER_1_E;
    register_count = 1;
    sx_status = sx_api_register_set(api_handle, SX_ACCESS_CMD_CREATE, &register_key, &register_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_register_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /*
     *  GRE Header:
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |0|0|1|0|   Reserved0     | Ver |   Protocol Type 0x6558        |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     |               Virtual Subnet ID (VSID)        |   Flow ID     |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     */
    /* Create an EMT That mimic a NVGRE header */
    emt_key.emt_id = SX_FLEX_MODIFIER_EMT0_E;
    emt_cfg.emt_data_cnt = 4;
    emt_cfg.emt_data_list[0].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
    emt_cfg.emt_data_list[0].immediate_value = 0x2000;
    emt_cfg.emt_data_list[1].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;       /* Used to set the protocol type */
    emt_cfg.emt_data_list[1].immediate_value = 0x6558;
    emt_cfg.emt_data_list[2].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
    emt_cfg.emt_data_list[2].immediate_value = 0x0;
    emt_cfg.emt_data_list[3].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_1_E;   /* Used to set the VSID + Flow ID */

    sx_status = sx_api_flex_modifier_set(api_handle, SX_ACCESS_CMD_CREATE, emt_key, &emt_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_set create failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_modifier_set(api_handle, SX_ACCESS_CMD_SET, emt_key, &emt_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Create the flex tunnel header with the EMT we've just created*/
    flex_tunnel_header_cfg.ip_version = SX_IP_VERSION_IPV4;
    flex_tunnel_header_cfg.underlay_ip_enc.uipv4.flags = 0;
    flex_tunnel_header_cfg.underlay_ip_enc.uipv4.id = 0x123;
    flex_tunnel_header_cfg.enc_ip_next_header = 0x2F;  /* GRE IP protocol number */
    flex_tunnel_header_cfg.tunnel_header_emt_id.emt_id = emt_key.emt_id;

    sx_status = sx_api_tunnel_flex_header_set(api_handle,
                                              SX_ACCESS_CMD_CREATE,
                                              &flex_tunnel_header_cfg,
                                              &flex_tunnel_header_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_tunnel_flex_header_set CREATE failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }


    /* Create the flex tunnel with the flex tunnel header defined above */
    tunnel_attr.type = SX_TUNNEL_TYPE_L2_FLEX;
    tunnel_attr.direction = SX_TUNNEL_DIRECTION_SYMMETRIC;
    tunnel_attr.attributes.l2_flex.log_port = SX_TUNNEL_PORT_ID_FLEX1;
    tunnel_attr.attributes.l2_flex.encap.tunnel_flex_header_id = flex_tunnel_header_id;
    tunnel_attr.attributes.l2_flex.encap.underlay_rif = loopback_rif_id;
    tunnel_attr.attributes.l2_flex.tunnel_qos_profile.profile_id = SX_COS_TQ_PROFILE_ID_3_E;  /* Profiles 2 & 3 are configured by default */
    tunnel_attr.attributes.l2_flex.encap.underlay_sip.version = SX_IP_VERSION_IPV4;
    tunnel_attr.attributes.l2_flex.encap.underlay_sip.addr.ipv4.s_addr = 0x64646464;    /* IP address 100.100.100.100 */
    tunnel_attr.attributes.l2_flex.decap.tag_mode = SX_VLAN_TAG_MODE_802_1Q_E;
    tunnel_attr.attributes.l2_flex.decap.underlay_rif = loopback_rif_id;
    sx_status = sx_api_tunnel_set(api_handle, SX_ACCESS_CMD_CREATE, &tunnel_attr, &tunnel_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_tunnel_set CREATE failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Enable the loopback rif - must be done after tunnel enable */
    rif_state.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    rif_state.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    rif_state.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    rif_state.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_DISABLE;
    sx_status = sx_api_router_interface_state_set(api_handle, loopback_rif_id, &rif_state);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_interface_state_set failed: [%s] \n", sx_status_str(sx_status));
        exit(1);
    }

    /* Incorporate the new tunnel into an ECMP container which will be utilized for the encapsulation */
    sx_status = create_tunnel_ecmp(api_handle, tunnel_id, &ecmp_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: ecmp create failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Use an ACL to capture all packet on the ingress port and send them to the tunnel */
    sx_status = create_tunnel_pbs_rule(api_handle, ecmp_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed to create EMT rule. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Add a decap rule for this flex tunnel */
    decap_key.tunnel_type = SX_TUNNEL_TYPE_L2_FLEX;
    decap_key.underlay_vrid = vrid;
    decap_key.underlay_dip.version = SX_IP_VERSION_IPV4;
    decap_key.underlay_dip.addr.ipv4.s_addr = 0x0A0A4040;   /* IP address 10.10.64.64 */
    decap_key.type = SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP;
    decap_data.action = SX_ROUTER_ACTION_FORWARD;
    decap_data.tunnel_id = tunnel_id;
    sx_status = sx_api_tunnel_decap_rules_set(api_handle, SX_ACCESS_CMD_CREATE, &decap_key, &decap_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_tunnel_decap_rules_set CREATE failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Read the tunnel counters */
    sx_status = sx_api_tunnel_counter_get(api_handle, SX_ACCESS_CMD_READ, tunnel_id, &tunnel_counter);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_tunnel_counter_get failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    printf("Tunnel encapsulated packets: %lu\n", tunnel_counter.counter.nve.encapsulated_pkts);
    printf("Tunnel decapsulated packets: %lu\n", tunnel_counter.counter.nve.decapsulated_pkts);
    printf("Tunnel decapsulated errors: %lu\n", tunnel_counter.counter.nve.decapsulated_errors);
    printf("Tunnel decapsulated discards: %lu\n", tunnel_counter.counter.nve.decapsulated_discards);


    /* From here we REMOVE the configurations we've done so far */

    sx_status = sx_api_tunnel_decap_rules_set(api_handle, SX_ACCESS_CMD_DESTROY, &decap_key, &decap_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_tunnel_decap_rules_set DESTROY failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Remove the ACL rule */
    sx_status = delete_tunnel_pbs_rule(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed to delete EMT rule. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_router_ecmp_set(api_handle, SX_ACCESS_CMD_DESTROY, &ecmp_id, NULL, &next_hop_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_ecmp_set DESTROY failed: [%s] \n", sx_status_str(sx_status));
        exit(1);
    }

    /* Destroy the flex tunnel we've created */
    sx_status = sx_api_tunnel_set(api_handle, SX_ACCESS_CMD_DESTROY, &tunnel_attr, &tunnel_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_tunnel_set DESTROY failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Destroy the flex tunnel header we've created */
    sx_status = sx_api_tunnel_flex_header_set(api_handle,
                                              SX_ACCESS_CMD_DESTROY,
                                              &flex_tunnel_header_cfg,
                                              &flex_tunnel_header_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_tunnel_flex_header_set DESTROY failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_tunnel_deinit_set(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_tunnel_deinit_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = destroy_loopback_rif(api_handle, vrid, loopback_rif_id, loopback_counter_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: destroy_loopback_rif failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }


    sx_status = destroy_underlay_routing(api_handle, vrid);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed creating underlay routing. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_router_set(api_handle, SX_ACCESS_CMD_DELETE, NULL, &vrid);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_router_set DELETE failed: [%s] \n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_router_deinit_set(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_router_deinit_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_modifier_set(api_handle, SX_ACCESS_CMD_DESTROY, emt_key, &emt_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_modifier_set destroy failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_register_set(api_handle, SX_ACCESS_CMD_DESTROY, &register_key, &register_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_register_set set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_parser_deinit_set(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: sx_api_flex_parser_deinit_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Close SDK API */
    sx_status = sx_api_close(&api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    printf("Successfully finished\n");
    return 0;
}
