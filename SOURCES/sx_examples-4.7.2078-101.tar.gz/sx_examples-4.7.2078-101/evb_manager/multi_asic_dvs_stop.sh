#!/bin/bash
#
 # Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #

usage()
{
    echo "The script disables EVB software"
    echo "Usage: ${me} [--skip_driver_unload]"
    echo "--skip_driver_unload       Skip SDK Driver unloading - Unload SDK Only"
}

skip_driver_unload=""
terminate_timeout=30

while [ "`echo $1 | cut -c1`" = "-" ]
do
    flag="${1%=*}"

    case "${flag}" in
        --skip_driver_unload)
            skip_driver_unload="--skip_driver_unload"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "${flag}" in
        -h | --help)
            usage
            exit 0
            ;;
        *)
            usage
            echo -e "-E- Unrecognized argument: '${flag}'. Check usage info above."
            exit 1
            ;;
    esac
done

dvs_stop.sh ${skip_driver_unload}
dvs_stop_rc=$?

containers="$(docker ps -a | grep asicd | awk '{print $1;}' | tr '\n' ' ' | awk '{$1=$1};1')"   # Replace newline with space, remove trailing whitespace
if test -n "${containers}"; then
    if timeout ${terminate_timeout} docker stop ${containers}; then
        echo "Multi ASIC Docker containers '${containers}' were stopped"
    else
        dvs_stop_rc=2
        echo "ERROR: docker containers did not stop after ${terminate_timeout} seconds, running docker kill.."
        docker kill ${containers}
    fi
else
    echo "No multi ASIC Docker containers are running"
fi

docker system prune -f
exit $dvs_stop_rc
