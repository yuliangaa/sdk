#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

me=$(basename "$0")
start_cmd_log=/tmp/dvs.start.cmd.log    # As defined in dvs_start.sh
sdk_sys_info_path="/var/log/sdk_dbg"    # Default val. override using --sdk_sys_info_path=/other/path

usage()
{
    echo "The script disables EVB software"
    echo "Usage: ${me} [--checkpoint] [--sdk_sys_info_path=PATH] [--skip_driver_unload] [--skip_minimal_driver_check]"
    echo "--checkpoint         When checkpoint flag is given, the SDK will be checkpointed."
    echo "--sdk_sys_info_path        Delete given SDK system debug path of storing system information. Default: ${sdk_sys_info_path}"
    echo "--skip_driver_unload       Skip SDK Driver unloading - Unload SDK Only"
    echo "--skip_minimal_driver_check       Skip the sanity check for HW-MGMT Minimal driver unloading"
}

if test -n "$(pidof sx_sdk)"; then                             # SDK Alive -> Determine syslog based on arguments of the process
    syslog="$(! ps -p `pidof sx_sdk` -o args --no-headers 2> /dev/null | grep -qs -- ' -s'; echo $?)"    # -s found: Syslog -> 1
else                                                           # SDK Not Alive -> Fallback to checking start_cmd_log
    syslog="$(grep -qs 'syslog=0' ${start_cmd_log}; echo $?)"  # 'syslog=0' not found in start_cmd_log -> syslog=X [x != 0]
fi

if [[ "${syslog}" != "0" ]]; then   # Log all dvs_stop output to syslog
    if test -n "${KUBERNETES_SERVICE_HOST}" || test -e /.dockerenv; then
        echo "Running over docker container - Will skip syslog logging"
    else
        exec 1> >(logger --stderr --tag ${me}) 2>&1
    fi
fi

basedir=`readlink -f $0`
basedir=${basedir%/*}
checkpoint=0
skip_minimal_driver_check=0
skip_driver_unload=0
dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
sdk_criu_dir=/root/.sdk_criu
dvs_stop_rc=0


while [ "`echo $1 | cut -c1`" = "-" ]
do
    flag=${1%=*}
    param=${1#*=}

    case "$flag" in
        --checkpoint)
            checkpoint=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --skip_minimal_driver_check)
            skip_minimal_driver_check=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --skip_driver_unload)
            skip_driver_unload=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --sdk_sys_info_path)
            param=${1#*=}
            sdk_sys_info_path=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        -h | --help)
            usage
            exit 0
            ;;
        *)
            usage
            echo -e "-E- Unrecognized argument: '${flag}'. Check usage info above."
            exit 1
            ;;
    esac
done

echo "*** DVS Stop started ***"
echo ${me} ${*}

lsmod | grep sx_ib > /dev/null
if [ $? == 0 ]; then
    is_eth=0
else
    is_eth=1
fi

if [ $checkpoint == 1 ]; then
    `pidof sx_sdk > /dev/null`;
    if [ $? != "0" ]; then
        echo "Error: could not checkpoint sdk : sx_sdk process is not running !"
        exit 1
    fi  

    $dir/sdk_pause_resume --pause || exit 1
    mkdir -p $sdk_criu_dir/sdk || exit 1
    mkdir -p $sdk_criu_dir/shm || exit 1
    rm -rf $sdk_criu_dir/sdk/* || exit 1
    rm -rf $sdk_criu_dir/shm/* || exit 1
    ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel stop || exit 1
    criu dump -D $sdk_criu_dir/sdk -t `pidof sx_sdk` --shell-job || exit 1
    cp -rf /var/run/shm/* $sdk_criu_dir/shm/ || exit 1
    echo -e "\nSDK has been successfully checkpointed.\n"
    exit 0
fi

dump_sdk_usages() {
    local open_fds=$(timeout -s SIGKILL 10s lsof -VnPX 2> /dev/null | grep -s /dev/sxdevs | grep -v grep || true)
    test -n "${open_fds}" && echo -e "Open files for /dev/sxdevs:\n${open_fds}"

    driver_fd_dump="$(tail +5 /proc/dbg_dump/fd_dump 2>/dev/null || true)" # first 5 lines are just headers
    test -n "${driver_fd_dump}" && echo -e "Driver FD Dump:\n$(tail +2 /proc/dbg_dump/fd_dump 2>/dev/null | grep -s .)"
    local sx_core_dep=$(lsmod 2> /dev/null | grep -s sx_core | grep -v grep || true)
    test -n "${sx_core_dep}" && echo -e "Loaded kernel modules related to sx_core:\n${sx_core_dep}"

    local sdk_proc=$(ps -ef 2> /dev/null | grep -s $(which sx_sdk) | grep -v grep || true)
    test -n "${sdk_proc}" && echo -e "Running SDK Processes:\n${sdk_proc}"
}

sdk_not_down_rc=99    # Specific RC To indicate waiting for SDK Down has failed

wait_sx_sdk_down() {
    local terminate_timeout="${1}"
    echo
    echo "wait for sx_sdk to properly terminate up to ${terminate_timeout} seconds"
    timeout "${terminate_timeout}" bash -c -- "while pidof 'sx_sdk' > /dev/null; do printf "."; sleep .01; done"

    if [ $? == 0 ]; then
        echo
        echo 'sx_sdk is down'
    else
        echo
        dump_sdk_usages
        echo "ERROR: sx_sdk did not terminate after ${terminate_timeout} seconds | Check output for usages detected"
        dvs_stop_rc=$sdk_not_down_rc
    fi
}

killall dvs_manager sx_sdk opensm     #killall -w flag is not supported on all platforms
if ! emad_dump_stop.sh; then
    echo "ERROR: Failed to execute emad_dump_stop.sh"
    dvs_stop_rc=1
fi

lsmod | grep "spice" > /dev/null
if [ $? == "0" ]; then
    echo "kill spice module !"
    rmmod sx_spice_dump
fi

wait_sx_sdk_down "50"
if test "${dvs_stop_rc}" -eq "${sdk_not_down_rc}"; then
    gdb_bt="$(gdb -p `pidof sx_sdk` --batch --quiet -ex 'thread apply all bt' -ex 'quit' $(which sx_sdk))"
    echo -e "\nSDK Process GDB Backtrace:\n${gdb_bt}\m"
    echo "sx_sdk did not terminate | Check GDB Backtrace above | Sending SIGKILL To force kill it"
    pkill -9 sx_sdk
    wait_sx_sdk_down "10"
fi

# the following loop is to wait for remaining references on the driver to be released
if [ -f /tmp/sx_core_min_dep_file ]; then
	echo 
	echo 'wait for all references to the driver to be released'
	wait_iterations=0
	max_wait_iterations=5000 # 50 seconds with interval of one centisecond
	sx_core_min_dep=`cat /tmp/sx_core_min_dep_file`
	rm -rf /tmp/sx_core_min_dep_file
	sx_core_dep=`lsmod | grep '^sx_core' | awk '{print $3}'`
	while (( sx_core_min_dep < sx_core_dep && wait_iterations < max_wait_iterations )); do
		sx_core_dep=`lsmod | grep '^sx_core' | awk '{print $3}'`
		printf "."
		sleep .01
		((wait_iterations=wait_iterations+1))
	done
	echo
	if test "${wait_iterations}" -eq "${max_wait_iterations}"; then
	    dump_sdk_usages
	    echo "-E- Not all references to the driver were released | Check output for usages detected"
	    exit 1
	fi
fi

if [[ "${skip_driver_unload}" == "1" ]]; then
    echo "User requested to skip driver unload - Nothing more to do."
    exit ${dvs_stop_rc}
fi

mod_support_use=`grep -s 'mod_support_use' /proc/dbg_dump/fw_and_board_info_dump | awk '{print $3}'`    # Check before unloading driver

if test -x ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel && ! ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel stop; then
    dump_sdk_usages
    echo "-E- Failed to stop sxdkernel | Check output for usages detected"
    exit 1
fi

if [ $is_eth == 0 ]; then
    /etc/init.d/openibd stop || exit 1
fi

# umount dump_fuse folder, in case SDK terminated without proper deinit
umount -f $(mount | grep dump_fuse | cut -d' ' -f3 || true) 2>/dev/null || true

# cleanup sxd sniffer shared memory, in case SDK terminated without proper deinit
shm_sxd_path="/dev/shm/sxd_recording"
shm_sxd_lsof="$(timeout -s SIGKILL 10s lsof -VnPX 2> /dev/null | grep ${shm_sxd_path} || true)"
if test -z "${shm_sxd_lsof}"; then                    # If references still exist, it means we cannot delete the SHM.
    if test -e "${shm_sxd_path}"; then
        echo "-W- SHM ${shm_sxd_path} still exists, although no references for it found, deleting it"
        rm -rf ${shm_sxd_path}
    fi

    # Remove the named semaphore on the FS As well, no need to check/warn - Its obsolete without the actual sxd_shm
    rm -rf /dev/shm/sem.sxd_sniffer_sem
fi

# Folder patterns for backup defined in dvs_stop & dvs_start scripts
if ls /var/issu_*.json > /dev/null 2>&1 && ls ${sdk_sys_info_path}/sx_sdk_*.pcap* > /dev/null 2>&1; then
    issu_first_life_backup_path="${sdk_sys_info_path}_first_life"
    echo "Backing up ISSU 1st life pcap recordings from ${sdk_sys_info_path} to ${issu_first_life_backup_path}"
    rm -rf ${issu_first_life_backup_path} && mkdir -p ${issu_first_life_backup_path} && cp -f ${sdk_sys_info_path}/sx_sdk_*.pcap* ${issu_first_life_backup_path}
fi

rm -f ${start_cmd_log}
rm -rf ${sdk_sys_info_path}

# HW-MGMT / Minimal driver related conditions

svc_state="$(systemctl is-active hw-management || true)"
hw_mgmt_run_path="/var/run/hw-management"
if ! test -e "${hw_mgmt_run_path}"; then
    echo "Skipping minimal driver validation since '${hw_mgmt_run_path}' doesn't exist. Assuming underlying platform not supported"
    skip_minimal_driver_check=1
elif ! test -z "${mod_support_use}" && test "${mod_support_use}" != "dependent"; then
    echo "Skipping minimal driver validation due to '${mod_support_use}' module management mode"
    skip_minimal_driver_check=1
    if systemctl is-enabled --quiet hw-management-tc && ! systemctl is-active --quiet hw-management-tc; then
        echo "Restarting hw-management-tc service after it was stopped due to ${mod_support_use} module management mode"
        systemctl start hw-management-tc &
    fi
elif test "${skip_minimal_driver_check}" -eq "1"; then
    echo "Skipping minimal driver validation due to explicit user choice"
elif ! test -x ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel; then
    echo "Skipping minimal driver validation since SDK Kernel driver not installed"
    skip_minimal_driver_check=1
elif test "${svc_state}" != "active"; then
    echo -e "\nhw-management service is in '${svc_state}' state, service status for debug:"
    systemctl status hw-management --no-pager -l || true
    echo -e "Skipping minimal driver validation since hw-management service is in '${svc_state}' state\n"
    skip_minimal_driver_check=1
fi

if test "${skip_minimal_driver_check}" -eq "0"; then
    interval=0.05
    wait_cnt=0
    max_wait_cnt=600    # 30 Seconds, 0.05 Interval
    timeout=$(echo "$max_wait_cnt $interval" | awk '{print $1 * $2}')

    echo "Waiting minimal driver to finish deinit, up to ${timeout} sec"

    asics_init_done="${hw_mgmt_run_path}/config/asics_init_done"
    if test "$(uname -r)" == "4.19.81-OpenNetworkLinux"; then     # Old DVS - Use module counter instead
        asics_init_done="${hw_mgmt_run_path}/config/module_counter"
    fi

    while test -f ${asics_init_done} && test "$(cat ${asics_init_done})" -ne "0" && (( wait_cnt < max_wait_cnt )); do
        printf "." && sleep ${interval} && ((wait_cnt=wait_cnt+1))
    done
    (( wait_cnt > 0 )) && echo || true      # Add empty line in case '.' was printed
    (( wait_cnt < max_wait_cnt )) && echo "Minimal driver finished deinit" \
        || echo "-W- Minimal driver did not finish deinit (${asics_init_done} != 0) after ${timeout} sec"
fi

echo "*** DVS Stop finished with rc ${dvs_stop_rc} ***"
exit $dvs_stop_rc
