#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

set -eE

error() {
    echo -e "-E- ${1}"; exit 1
}

me=$(basename "$0")
basedir=`readlink -f $0`
basedir=${basedir%/*}

# If EVB_SYSLOG Was set - User wants to redirect script output to syslog
# Useful when running it directly, and not using dvs_start.sh --syslog.
# Cannot use SDK_SYSLOG, Because its used by dvs_start.sh - Which already redirects script's output to syslog using exec
if test -n "${EVB_SYSLOG}"; then
    exec 1> >(logger --stderr --tag ${me}) 2>&1   # Log script execution to syslog and stderr
fi

if test -n "${SDK_SYSLOG}" || test -n "${EVB_SYSLOG}"; then
    syslog_flags="-s"
fi

export LD_LIBRARY_PATH=${basedir}/../lib:${basedir}/../lib64

profile=${1:-"eth-single"}
target=${2:-"dvk"}
sdk_applibs_modules=${3:-"all"}
sdk_mode=${4:-"802.1Q"}
max_vlan=${5:-"0"}
acl_search_type=${6:-"SERIAL"}
type=${profile%-*}
reset_trigger=${RESET_TRIGGER:-1}
spice=${SPICE:-0}
fast_boot=${FAST_BOOT:-0}
boot_mode="${BOOT_MODE:-DISABLED}"
use_internal_init_flow="${USE_INTERNAL_INIT_FLOW:-1}"
port_speed_rate_mode="${PORT_SPEED_RATE_MODE:-DEFAULT}"
ready_file=${SDK_READY_FILE:-/tmp/sdk_ready}
system_type=${7:-"non-modular"}
disable_modular_chassis_init="${DISABLE_MODULAR_CHASSIS_INIT:-0}"

if [ "${SDK_VERBOSITY}" == "no" ]; then
    verbosity_flags=""
else
    if [ "${SDK_VERBOSITY}" != "" ]; then
        verbosity_flags="-v${SDK_VERBOSITY}"
    fi
fi

if [[ -z ${PORT_PROFILES_NUM} ]];then
    export PORT_PROFILES_NUM=2
fi

ex()
{
	echo "$@"
	eval "$@" || exit 1
}

wait_sdk_ready() {
   while [[ ! -e  ${ready_file} ]]; do
        sleep 0.001
   done
}

if pidof sx_sdk > /dev/null; then
    error "Could not run evb_start.sh: sx_sdk process is running"
fi

if [ ${reset_trigger} == 0 ]; then
    emad_dump.sh ${EMAD_DUMP_DIR} ${EMAD_DUMP_PCAP_FILE} &
    EMAD_DUMP_PID=$!
fi

if [[ -z "${PREDEFINED_DEV}" ]]; then
    if [ ${type} != "eth" ]; then
        ex /etc/init.d/openibd force-start || error "Failed to force-start openibd"
    fi
    ex ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel start || error "Failed to load driver"
fi

if [ $? != "0" ]; then
	echo "Error: could not load drivers"
	exit 1
fi

lsmod | grep '^sx_core' | awk '{print $3}' > /tmp/sx_core_min_dep_file

rm -f ${ready_file}

sdk_start_time=$(($(date +%s%N)/1000000))
dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
if [ "${START_SX_SDK_WITH_GDB}" != "" ]; then
echo "========================================================================================================"
screen -dmS "sx_sdk_gdb" bash -c "${evb_sx_sdk_prefix} gdb -ex 'set pagination off' -ex=start -q -tui --args $dir/sx_sdk ${evb_sx_sdk_suffix} ${verbosity_flags} ${syslog_flags}"
echo "Please attach GDB screen with following command below to continue"
echo "screen -r sx_sdk_gdb"
echo "========================================================================================================"
else
ex ${evb_sx_sdk_prefix} $dir/sx_sdk ${evb_sx_sdk_suffix} ${verbosity_flags} ${syslog_flags} &
fi

# wait until SDK is ready for configuration. (by checking existence of ${ready_file} file)
wait_sdk_ready

sdk_end_time=$(($(date +%s%N)/1000000))
echo "SDK ready after $((${sdk_end_time}-${sdk_start_time})) ms"
ex sync

if [[ ( "${fast_boot}" == "1" && "${boot_mode}" == "DISABLED" ) || "${boot_mode}" == "FAST" || "${boot_mode}" == "ISSU_FAST" || "${boot_mode}" == "ISSU_STARTED" ]]; then
    echo "SDK in fast boot mode - resource manager will NOT be called"
else
	ex $dir/run_resources.sh ${profile} ${target}
fi

# If evb_skip_init is not set:
if [ "x${evb_skip_init}" == "x" ]; then
    if [ "${OVERRIDE_DEFAULT_FLOOD_MODE}" == "1" ]; then
        export OVERRIDE_DEFAULT_FLOOD_MODE
    fi
    if [ "${OVERRIDE_DEFAULT_LAG_MODE}" == "1" ]; then
        export OVERRIDE_DEFAULT_LAG_MODE
    fi
	ex $dir/run_chassis.sh ${profile} ${sdk_applibs_modules} ${sdk_mode} ${max_vlan} ${acl_search_type}
	ex $dir/run_dvs_manager.sh ${profile} ${target} ${sdk_mode} ${max_vlan} 
    if [ ${system_type} == "modular" ]; then
        if [ ${disable_modular_chassis_init} == 0 ]; then
            echo "Modular system: running modular chassis manager"
            ex $dir/run_modular_chassis.sh ${profile} ${target}
        else
            echo "Modular system: skipping modular chassis manager initialization"
        fi
    fi
fi

if [ ${spice} == 1 ]; then
    ex /sbin/modprobe sx_spice_dump > /dev/null || error "Failed to load sx_spice_dump"
fi

if [ ${type} != "eth" ]; then
	ex /sbin/modprobe ib_ipoib > /dev/null  || error "Failed to load ib_ipoib"
fi
