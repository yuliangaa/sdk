/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "evb_manager.h"
#include "topo_parse_manager.h"
#include "evb_manager_eth.h"
#include "evb_manager_ib.h"

#undef  __MODULE__
#define __MODULE__ EVB_MANAGER_EXAMPLE


/*****************************************************************************/
/*			       LOCAL VARIABLES                               */
/*****************************************************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE; /* EVB MANAGER log verbosity level */
sx_xml_reader_t     *__reader_p = NULL;        /* XML file reader */
sx_xml_parser_t     *__parser_p = NULL;        /* XML file parser */
sx_xml_tree_t       *__tree_p = NULL;        /* XML tree        */
sx_api_handle_t      __handle = 0;         /* SDK handle */
device_t            *__device_db_p = NULL; /* Devices Database  */
int                  __device_count = 0;    /* Number of devices in __device_db_p */
sx_swid_t           *__swids_db_p_ib = NULL;  /* SWIDs Database */
int                  __swids_count_ib = 0;     /* Number of SWIDs in __swids_db_p */
sx_swid_t           *__swids_db_p_eth = NULL;  /* SWIDs Database */
int                  __swids_count_eth = 0;    /* Number of SWIDs in __swids_db_p */
uint32_t             evb_manager_app_id = 100;    /* application unique identifier (random) */
static struct option __evb_manager_long_options_arr[] = {
    {"wait-for-events",      no_argument,        NULL,   'e'                         },
    {"sdk_mode",             required_argument,  NULL,   EVB_ARG_MODE                },
    {"max_vlan",             required_argument,  NULL,   EVB_ARG_MAX_VLAN            },
    {"log-file",             required_argument,  NULL,   EVB_ARG_LOG_FILE            },
    {"log-lib",              required_argument,  NULL,   EVB_ARG_LOG_LIB             },
    {"boot_mode",            required_argument,  NULL,   EVB_ARG_BOOT_MODE           },
    {"pdb_lag_init",         no_argument,        NULL,   EVB_ARG_PDB_LAG_INIT        },
    {"port_state_down_mode", no_argument,        NULL,   EVB_ARG_PORT_STATE_DOWN_MODE},
    {"port_speed_rate_mode", required_argument,  NULL,   EVB_ARG_PORT_SPEED_RATE_MODE},
    {"pdb_port_map_init",    no_argument,        NULL,   EVB_ARG_PDB_PORT_MAP_INIT   },
    {"fw_fatal_event_mode",  required_argument,  NULL,   EVB_ARG_FW_FATAL_EVENT_MODE },
    {"disable_health_check", no_argument,        NULL,   EVB_ARG_DISABLE_HEALTH_CHECK},
    {"verbosity_level",      required_argument,  NULL,   ARG_VERBOSITY_LEVEL         },
    {"no_verbosity",         no_argument,        NULL,   ARG_NO_VERBOSITY            },
    {"use_2nd_bonus_port",   no_argument,        NULL,   EVB_ARG_USE_2ND_BONUS_PORT  },
    {"do_not_init_with_port_profile",   no_argument,        NULL,   EVB_ARG_DO_NOT_INIT_WITH_PORT_PROFILE  },
    {"help",                 no_argument,        NULL,   'h'                         },
    {0,                  0,                   0,      0                              }
};
static FILE         *log_file = NULL;
static sx_log_cb_t   log_lib_cb = NULL;
sx_bridge_mode_t     sdk_bridge_mode = SX_MODE_802_1Q;
uint32_t             num_of_active_vlans = 0;
boolean_t            do_not_init_with_port_profile = FALSE;
boolean_t            is_eth_from_xml_init = FALSE;


int wait_events = 0;

/*****************************************************************************/
/*		       LOCAL GENERIC FUNCTIONS DECLARATIONS		     */
/*****************************************************************************/

/**
 * open configuration file
 * @param[in] path_p - path to configuration file
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
static evb_status_t __open_configuration_file(IN char * const path_p);

/**
 * This function cleans memory , close API handles , close log
 * @param[in]   device_count - number of devices
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
static evb_status_t __manager_close(IN int device_count);

/**
 * This function counts a specific char occurrence within a string
 * @param[in]  str - input string
 * @param[in]  ch  - char to count
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
static int __count_chars(IN char *str,
                         IN char  ch);

/**
 * This function is a callback function passed to inner libraries, command
 * interface, host interface and sx api for logging.
 * @param[in]  severity     - log print severity
 * @param[in]  module_name  - name of the message source module
 * @param[in]  msg          - log message
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
void __evb_log_cb(IN sx_log_severity_t severity,
                  IN const char       *module_name,
                  IN char             *msg);

/*****************************************************************************/
/*		       XML PARSING FUNCTIONS DECLARATIONS		     */
/*****************************************************************************/


/*****************************************************************************/
/*	             INTERNAL MACROS & HELPER FUNCTIONS			     */
/*****************************************************************************/

/*
 * Show help message to the user
 */
static inline void __show_help()
{
    printf("\tNVIDIA Switch EVB Manager.\n"
           "\t===================================\n"
           "\tUsage: dvs_manager [options] <profile type> <configuration file>\n\n"
           "\t<profile type>                            Set profile type to: eth-single|eth-multi|ib-single|ib-multi.\n"
           "\t<configuration file>                      EVB Configuration file.\n"
           "\tOptions:\n"
           "\t(-e|--wait-for-events)                    Trap events at the end and log them.\n"
           "\t--log-file <log file>                     Direct log lines into <log file>. Mutual exclusive with --log-lib.\n"
           "\t--log-lib <log library>                   Direct log lines into log_cb() from <log library>. Mutual exclusive with --log-file.\n"
           "\t--verbosity_level <level>                 Set verbosity level to: NONE=0,ERROR=1,WARNING=2,INFO=3,VERBOSE=4,DEBUG=5,ALL=6.\n"
           "\t(-h|--help)                               Show This help message and exit.\n");
    exit(0);
}

/*
 * Show error message to the user
 */

static inline void __show_error()
{
    printf("Bad parameter(s). Use --help to get parameters summary\n");
    exit(1);
}


/*
 * Default device initialization - part of sdk self init
 */
static evb_status_t __evb_sdk_self_init_device_defaults()
{
    int          device_index = 0;      /* Device index */
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();

    __device_count = EVB_DEFAULT_DEVICE_COUNT;
    /* allocate memory for device DB */
    evb_rc = EVB_UTILS_CLR_MEM_GET(&__device_db_p, __device_count, sizeof(device_t));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to allocate memory for devices array , error: %s\n",  evb_utils_get_err_str(evb_rc));
        goto out;
    }

    __device_db_p[device_index].device_info.dev_id = EVB_DEFAULT_DEVICE_NUMBER;
    __device_db_p[device_index].device_info.node_type = EVB_DEFAULT_NODE_TYPE;


out:
    SX_LOG_EXIT();
    return evb_rc;
}

/*
 * utility api to get the swid type
 */
enum ku_swid_type get_swid_type(int profile)
{
    if (profile == PROFILE_IB) {
        return KU_SWID_TYPE_INFINIBAND;
    }

    return KU_SWID_TYPE_ETHERNET;
}

/*
 * Default port initialization - part of sdk self init
 */
evb_status_t __evb_sdk_self_init_port_defaults(port_info_t *port_info_p)
{
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();


    if (port_info_p == NULL) {
        printf("__evb_sdk_self_init_port_defaults null parameter\n");
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    port_info_p->port_mapping.mapping_mode = EVB_DEFAULT_MAPPING_MODE;
    port_info_p->mstp_port_state = EVB_DEFAULT_RSTP_STATE;
    port_info_p->port_state = EVB_DEFAULT_PORT_STATE;
    port_info_p->vid = EVB_DEFAULT_PORT_VID;
    port_info_p->phys_loopback = EVB_DEFAULT_LOOPBACK_MODE;

out:
    SX_LOG_EXIT();
    return evb_rc;
}

/*****************************************************************************/
/*		       LOCAL GENERIC FUNCTIONS IMPLEMENTATION		     */
/*****************************************************************************/

sx_status_t __get_chip_type(const sx_api_handle_t handle, sx_chip_types_t* chip_type)
{
    sx_status_t         ret = SX_STATUS_SUCCESS;
    sx_device_hw_info_t dev_hw_info;

    memset(&dev_hw_info, 0, sizeof(dev_hw_info));
    ret = sx_api_device_hw_info_get(handle, &dev_hw_info);
    if (SX_CHECK_FAIL(ret)) {
        SX_LOG_ERR("Failed to get device HW info, err: %s\n", sx_status_str(ret));
        return ret;
    }

    *chip_type = dev_hw_info.chip_type;
    return SX_STATUS_SUCCESS;
}


evb_status_t __port_device_set(device_t *__device_db_p, port_info_t *port_info_p, uint32_t port_cnt)
{
    uint32_t                   i = 0;
    sx_port_attributes_t      *port_attributes_p = NULL;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    evb_status_t               evb_rc = EVB_STATUS_SUCCESS;
    evb_status_t               rollback_evb_rc = EVB_STATUS_SUCCESS;
    uint32_t                   port_attr_cnt = 0;
    sx_chip_types_t            chip_type = SX_CHIP_TYPE_UNKNOWN;
    uint32_t                   max_local_ports;
    boolean_t                 *port_locals_p = NULL;
    boolean_t                  is_split_supported = FALSE;
    struct ku_query_board_info board_info;
    uint32_t                   xm_port_index = 0;

    memset(&board_info, 0, sizeof(struct ku_query_board_info));
    board_info.dev_id = __device_db_p->device_info.dev_id;

    rc = __get_chip_type(__handle, &chip_type);
    if (SX_CHECK_FAIL(rc)) {
        printf("__get_chip_type failed (%s)\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

    switch (chip_type) {
    case SX_CHIP_TYPE_SWITCHX_A0:
    case SX_CHIP_TYPE_SWITCHX_A1:
    case SX_CHIP_TYPE_SWITCHX_A2:
    case SX_CHIP_TYPE_SPECTRUM:
    case SX_CHIP_TYPE_SPECTRUM_A1:
        max_local_ports = 64;
        is_split_supported = TRUE;
        break;

    case SX_CHIP_TYPE_SPECTRUM2:
    case SX_CHIP_TYPE_SPECTRUM3:
        max_local_ports = 128;
        is_split_supported = TRUE;
        break;

    case SX_CHIP_TYPE_SPECTRUM4:
        max_local_ports = 258;
        is_split_supported = TRUE;
        break;

    case SX_CHIP_TYPE_SPECTRUM5:
        max_local_ports = 516;
        is_split_supported = TRUE;
        break;

    case SX_CHIP_TYPE_QUANTUM:
        max_local_ports = 80;
        is_split_supported = TRUE;
        break;

    case SX_CHIP_TYPE_QUANTUM2:
        max_local_ports = 128;
        is_split_supported = TRUE;
        break;

    case SX_CHIP_TYPE_QUANTUM3:
        max_local_ports = 148;
        is_split_supported = TRUE;
        break;

    default:
        max_local_ports = 64;
        is_split_supported = FALSE;
    }

    evb_rc = EVB_UTILS_CLR_MEM_GET(&port_attributes_p,
                                   max_local_ports + DEFAULT_NVE_PORT_COUNT,   /* + NVE Port + L2 Flex Tunnel Ports */
                                   sizeof(sx_port_attributes_t));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to allocate memory for port attributes array , error: %s\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }

    evb_rc = EVB_UTILS_CLR_MEM_GET(&port_locals_p,
                                   max_local_ports + DEFAULT_NVE_PORT_COUNT,   /* + NVE Port + L2 Flex Tunnel Ports */
                                   sizeof(boolean_t));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to allocate memory for port locals array , error: %s\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* Check if XM present and what are the attached ports (not part of SWID) */
    rc = sxd_status_to_sx_status(sxd_access_reg_query_board_info(&board_info));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to query board info (%s)\n", sx_status_str(rc));
        goto out;
    }

    for (i = 0; i < port_cnt; i++) {
        if (board_info.xm_exists == TRUE) {
            for (xm_port_index = 0; xm_port_index < board_info.xm_num_local_ports; xm_port_index++) {
                if (port_info_p[i].port_mapping.local_port == board_info.xm_local_ports[xm_port_index]) {
                    port_info_p[i].swid = SX_SWID_ID_DEFAULT;
                    continue;
                }
            }
        }

        printf("local port %d, map_mode:%d, slot:%d, module:%d, width:%d, lan_bmp:%d, port mode: %d \n",
               port_info_p[i].port_mapping.local_port,
               port_info_p[i].port_mapping.mapping_mode,
               port_info_p[i].port_mapping.slot,
               port_info_p[i].port_mapping.module_port,
               port_info_p[i].port_mapping.width,
               port_info_p[i].port_mapping.lane_bmap,
               port_info_p[i].port_mode);
    }

    for (i = 0; i < port_cnt; i++) {
        port_attributes_p[i].port_mode = port_info_p[i].port_mode;
        port_attributes_p[i].port_mapping = port_info_p[i].port_mapping;

        if (port_attributes_p[i].port_mapping.local_port > max_local_ports) {
            printf("ERROR: Invalid port local %d after ports initialization. Index:%d\n ",
                   port_attributes_p[i].port_mapping.local_port, i);
            continue;
        }
        /* Tunnel ports are not considered part of the local ports */
        if (port_attributes_p[i].port_mode != SX_PORT_MODE_TUNNEL) {
            port_locals_p[port_attributes_p[i].port_mapping.local_port] = TRUE;
            if (is_eth_from_xml_init == TRUE) {
                port_attributes_p[port_attr_cnt].usr_label_info.port_label =
                    __device_db_p->port_info_arr_eth[i].label_port << 4;
            }
        }
        port_attr_cnt++;
    }

    if (is_split_supported) {
        for (i = 1; i < max_local_ports + 1; i++) { /* Local port 0 NA here */
            if ((chip_type == SX_CHIP_TYPE_SPECTRUM5) && ((i == 514) || (i == 516))) {
                continue;
            }
            if (port_locals_p[i] == FALSE) {
                port_attributes_p[port_attr_cnt].port_mode = SX_PORT_MODE_EXTERNAL;
                port_attributes_p[port_attr_cnt].port_mapping.local_port = i;
                port_attributes_p[port_attr_cnt].port_mapping.mapping_mode = SX_PORT_MAPPING_MODE_DISABLE;
                port_attributes_p[port_attr_cnt].port_mapping.module_port = 0;
                port_attributes_p[port_attr_cnt].port_mapping.slot = 0;
                port_attributes_p[port_attr_cnt].port_mapping.width = 0;
                port_attributes_p[port_attr_cnt].port_mapping.lane_bmap = 0;
                port_attr_cnt++;
            }
        }
    }

    /* add device to the SDK */
    printf("adding device: %d, port_arr_len: %d \n",
           __device_db_p->device_info.dev_id, port_attr_cnt);

/*
 *   for (i = 0; i < port_attr_cnt; i++) {
 *       printf("i:%d local port %d, map_mode:%d, module:%d, width:%d, lan_bmp:%d, port mode: %d \n",i,
 *              port_attributes_p[i].port_mapping.local_port,
 *              port_attributes_p[i].port_mapping.mapping_mode,
 *              port_attributes_p[i].port_mapping.module_port,
 *              port_attributes_p[i].port_mapping.width,
 *              port_attributes_p[i].port_mapping.lane_bmap,
 *              port_attributes_p[i].port_mode);
 *   }
 */

    rc = sx_api_port_device_set(__handle, SX_ACCESS_CMD_ADD,
                                __device_db_p->device_info.dev_id,
                                &(__device_db_p->base_mac_addr),
                                port_attributes_p,
                                port_attr_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("sx_api_port_device_set has failed for device %u (%s)\n",
                   __device_db_p->device_info.dev_id, sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }

    for (i = 0; i < port_cnt; i++) {
        if (port_info_p[i].port_mapping.local_port != port_attributes_p[i].port_mapping.local_port) {
            printf("ERROR: local ports not aligned: %d, %d, index:%d\n",
                   port_info_p[i].port_mapping.local_port,
                   port_attributes_p[i].port_mapping.local_port,
                   i);
            continue;
        }

        __device_db_p->log_ports_arr[i] = port_attributes_p[i].log_port;
/*        printf("logport:%#x local port %d\n",__device_db_p->log_ports_arr[i],port_info_p[i].port_mapping.local_port);*/
    }

out:
    if (port_attributes_p) {
        rollback_evb_rc = EVB_PORT_UTILS_MEM_PUT(port_attributes_p);
        if (EVB_STATUS_SUCCESS != rollback_evb_rc) {
            SX_LOG_ERR("Failed to free port attributes. Err = %d\n", rollback_evb_rc);
        }
    }
    if (port_locals_p) {
        rollback_evb_rc = EVB_PORT_UTILS_MEM_PUT(port_locals_p);
        if (EVB_STATUS_SUCCESS != rollback_evb_rc) {
            SX_LOG_ERR("Failed to free port locals. Err = %d\n", rollback_evb_rc);
        }
    }

    return evb_rc;
}


evb_status_t __evb_sdk_self_init(char     *platform_xml,
                                 int       profile,
                                 boolean_t issu_start,
                                 boolean_t pdb_lag_init,
                                 boolean_t pdb_port_map_init,
                                 uint8_t   fw_fatal_event_mode,
                                 boolean_t port_state_down_mode,
                                 uint8_t   port_speed_rate_mode,
                                 boolean_t disable_health_check,
                                 boolean_t use_2nd_bonus_port)
{
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;
    char        *basedir = NULL;
    char         filepath[PATH_MAX];
    char        *slash = "/";
    size_t       path_length = 0;


    SX_LOG_ENTER();

    memset(filepath, 0, sizeof(filepath));
    basedir = dirname(platform_xml);

    path_length = strlen(basedir) + strlen(slash) + strlen(EVB_DEFAULT_BASE_XML_FILE) + 1;
    if (path_length > PATH_MAX) {
        SX_LOG_ERR("Failed opening the default device base xml configuration file, the path is too long: %lu > %u \n",
                   path_length, PATH_MAX);
        return EVB_STATUS_ERROR;
    }

    strcat(filepath, basedir);
    strcat(filepath, slash);
    strcat(filepath, EVB_DEFAULT_BASE_XML_FILE);

    printf("Platform xml not present, sdk self initializing using defaults %s\n", filepath);
    /* Open the base XML file */
    evb_rc = __open_configuration_file(filepath);
    if (EVB_CHECK_FAIL(evb_rc)) {
        goto out;
    }


    /* allocate memory for device DB */
    evb_rc = __evb_sdk_self_init_device_defaults();
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("sdk self init Failed to set the  device defaults , error: %s\n",  evb_utils_get_err_str(evb_rc));
        goto out;
    }

    switch (profile) {
    case PROFILE_ETH:
        /* sdk self initialize swid and ports*/
        evb_rc = __evb_sdk_self_init_handle_eth(issu_start,
                                                pdb_lag_init,
                                                pdb_port_map_init,
                                                fw_fatal_event_mode,
                                                port_state_down_mode,
                                                port_speed_rate_mode,
                                                disable_health_check,
                                                use_2nd_bonus_port);
        break;

    case PROFILE_IB:
        /* sdk self initialize swid and ports*/
        evb_rc = __evb_sdk_self_init_handle_ib(use_2nd_bonus_port,
                                               issu_start,
                                               pdb_port_map_init);
        break;
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}


int main(int argc, char **argv)
{
    int                  profile = PROFILE_ETH;
    void                *log_lib = NULL;
    int                  use_log_file = 0, use_log_lib = 0;
    int                  c = 0;
    char                *errmsg = NULL;
    sx_user_channel_t    user_channel;
    sxd_status_t         sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t          rc = SX_STATUS_SUCCESS;
    evb_status_t         evb_rc = EVB_STATUS_SUCCESS;
    sx_boot_mode_e       boot_mode = SX_BOOT_MODE_DISABLED_E;
    boolean_t            pdb_lag_init = FALSE;
    boolean_t            port_state_down_mode = FALSE;
    uint8_t              port_speed_rate_mode = SX_PORT_SPEED_RATE_MODE_DEFAULT_E;
    boolean_t            pdb_port_map_init = FALSE;
    uint8_t              fw_fatal_event_mode = SXD_MFGD_FW_FATAL_EVENT_MODE_DONT_CHECK_FW_FATAL_E;
    sx_verbosity_level_t verbosity_level = SX_VERBOSITY_LEVEL_NOTICE;
    boolean_t            set_verbosity = TRUE;
    boolean_t            disable_health_check = FALSE;
    boolean_t            use_2nd_bonus_port = FALSE;

    memset(&user_channel, 0, sizeof(user_channel));
    user_channel.channel.fd.fd = -1;

    /* read user inputs */
    while (1) {
        int option_index = 0;

        c = getopt_long(argc, argv, "eh", __evb_manager_long_options_arr, &option_index);
        /* Detect the end of the options. */
        if (c == -1) {
            break;
        }

        switch (c) {
        case 'e':
            wait_events = 1;
            break;

        case ARG_VERBOSITY_LEVEL:
            sscanf(optarg, "%u", &(verbosity_level));
            break;

        case ARG_NO_VERBOSITY:
            if (set_verbosity) {
                SX_LOG_INF("Skipping verbosity set\n");
                set_verbosity = FALSE;
            }
            break;

        case EVB_ARG_LOG_FILE:
            log_file = fopen(optarg, "a");
            if (log_file == NULL) {
                fprintf(stderr, "Could not open log file: %s\n", optarg);
                exit(1);
            }

            use_log_file = 1;
            break;

        case EVB_ARG_MODE:
            if (!strcmp(optarg, "802.1Q")) {
                sdk_bridge_mode = SX_MODE_802_1Q;
            }
            if (!strcmp(optarg, "802.1D")) {
                sdk_bridge_mode = SX_MODE_802_1D;
            }
            if (!strcmp(optarg, "HYBRID")) {
                sdk_bridge_mode = SX_MODE_HYBRID;
            }
            break;

        case EVB_ARG_LOG_LIB:
            log_lib = dlopen(optarg, RTLD_LAZY);
            errmsg = dlerror();
            if (errmsg) {
                fprintf(stderr, "Could not load log library: %s\n", errmsg);
                exit(1);
            }

            *(void**)(&log_lib_cb) = dlsym(log_lib, "log_cb");
            errmsg = dlerror();
            if (errmsg) {
                fprintf(stderr, "Could not find symbol log_cb: %s\n", errmsg);
                exit(1);
            }

            use_log_lib = 1;
            break;

        case EVB_ARG_MAX_VLAN:
            sscanf(optarg, "%u", &num_of_active_vlans);
            break;

        case EVB_ARG_BOOT_MODE:
            if (!strcmp(optarg, "NORMAL")) {
                boot_mode = SX_BOOT_MODE_NORMAL_E;
            } else if (!strcmp(optarg, "FAST")) {
                boot_mode = SX_BOOT_MODE_FAST_E;
            } else if (!strcmp(optarg, "ISSU_NORMAL")) {
                boot_mode = SX_BOOT_MODE_ISSU_NORMAL_E;
            } else if (!strcmp(optarg, "ISSU_FAST")) {
                boot_mode = SX_BOOT_MODE_ISSU_FAST_E;
            } else if (!strcmp(optarg, "ISSU_STARTED")) {
                boot_mode = SX_BOOT_MODE_ISSU_STARTED_E;
            } else if (!strcmp(optarg, "DISABLED")) {
                boot_mode = SX_BOOT_MODE_DISABLED_E;
            } else {
                SX_LOG_ERR("Unsupported boot_mode parameter : %s \n", optarg);
                goto out;
            }
            break;

        case EVB_ARG_PDB_LAG_INIT:
            pdb_lag_init = TRUE;
            break;

        case EVB_ARG_PORT_STATE_DOWN_MODE:
            port_state_down_mode = TRUE;
            break;

        case EVB_ARG_PDB_PORT_MAP_INIT:
            pdb_port_map_init = TRUE;
            break;

        case EVB_ARG_FW_FATAL_EVENT_MODE:
            if (!strcmp(optarg, "FW_NO_CHECK")) {
                fw_fatal_event_mode = SXD_MFGD_FW_FATAL_EVENT_MODE_DONT_CHECK_FW_FATAL_E;
            } else if (!strcmp(optarg, "FW_CONTINUE")) {
                fw_fatal_event_mode = SXD_MFGD_FW_FATAL_EVENT_MODE_CHECK_FW_FATAL_E;
            } else if (!strcmp(optarg, "FW_HALT")) {
                fw_fatal_event_mode = SXD_MFGD_FW_FATAL_EVENT_MODE_CHECK_FW_FATAL_STOP_FW_E;
            } else {
                SX_LOG_ERR("Unsupported fw_fatal_event_mode parameter : %s \n", optarg);
                goto out;
            }
            break;

        case EVB_ARG_PORT_SPEED_RATE_MODE:
            if (!strcmp(optarg, "DEFAULT")) {
                port_speed_rate_mode = SX_PORT_SPEED_RATE_MODE_DEFAULT_E;
            } else if (!strcmp(optarg, "SPEED")) {
                port_speed_rate_mode = SX_PORT_SPEED_RATE_MODE_SPEED_E;
            } else if (!strcmp(optarg, "RATE")) {
                port_speed_rate_mode = SX_PORT_SPEED_RATE_MODE_RATE_E;
            } else {
                SX_LOG_ERR("Unsupported port_speed_rate_mode parameter : %s \n", optarg);
                goto out;
            }
            break;

        case EVB_ARG_DISABLE_HEALTH_CHECK:
            disable_health_check = TRUE;
            break;

        case EVB_ARG_USE_2ND_BONUS_PORT:
            use_2nd_bonus_port = TRUE;
            break;

        case EVB_ARG_DO_NOT_INIT_WITH_PORT_PROFILE:
            do_not_init_with_port_profile = TRUE;
            break;

        case '?':
        case 'h':
            __show_help();

        /* fall through */
        default:
            /* getopt_long already printed an error message. */
            __show_error();
        }
    }

    printf("*** EVB Manager: boot_mode (%d) ***\n", boot_mode);

    /* Check mutual exclusive command line options. */
    if (use_log_file && use_log_lib) {
        __show_error();
    }

    /* Check remaining command line arguments (not options). */
    if (optind + 2 != argc) {
        __show_error();
    }

    if (!strcmp(argv[optind], "eth-single") || !strcmp(argv[optind], "ETH-SINGLE")) {
        profile = PROFILE_ETH;
    } else if (!strcmp(argv[optind], "eth-multi") || !strcmp(argv[optind], "ETH-MULTI")) {
        profile = PROFILE_ETH;
    } else if (!strcmp(argv[optind], "ib-single") || !strcmp(argv[optind], "IB-SINGLE") ||
               !strcmp(argv[optind], "switchib-single") || !strcmp(argv[optind], "SWITCHIB-SINGLE") ||
               !strcmp(argv[optind], "switchib2-single") || !strcmp(argv[optind], "SWITCHIB2-SINGLE") ||
               !strcmp(argv[optind], "quantum-single") || !strcmp(argv[optind], "QUANTUM-SINGLE") ||
               !strcmp(argv[optind], "quantum2-single") || !strcmp(argv[optind], "QUANTUM2-SINGLE") ||
               !strcmp(argv[optind], "quantum3-single") || !strcmp(argv[optind], "QUANTUM3-SINGLE")) {
        profile = PROFILE_IB;
    } else if (!strcmp(argv[optind], "ib-multi") || !strcmp(argv[optind], "IB-MULTI")) {
        profile = PROFILE_IB;
    } else {
        __show_error();
    }


    if (set_verbosity) {
        LOG_VAR_NAME(__MODULE__) = verbosity_level;
    }

    /* open sx-api handle */
    rc = sx_api_open(__evb_log_cb, &__handle);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to open SX-API , error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out_manager_close;
    }

    if ((boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) && (do_not_init_with_port_profile == FALSE)) {
        /*If issu_start, some api need run in readonly mode, port profile can't support that*/
        SX_LOG_NTC("In issu started mode, we will init without port profile\n");
        do_not_init_with_port_profile = TRUE;
    }

    /* init register access - for port mapping only */
    sxd_status = sxd_access_reg_init(evb_manager_app_id, __evb_log_cb, LOG_VAR_NAME(__MODULE__));
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to init register access , error: %s\n", SXD_STATUS_MSG(sxd_status));
        evb_rc = EVB_STATUS_ERROR;
        goto out_manager_close;
    }

    /* open configuration file */
    evb_rc = __open_configuration_file(argv[optind + 1]);
    if (EVB_CHECK_FAIL(evb_rc)) {
        evb_rc = __evb_sdk_self_init(argv[optind + 1],
                                     profile,
                                     (boot_mode == SX_BOOT_MODE_ISSU_STARTED_E),
                                     pdb_lag_init,
                                     pdb_port_map_init,
                                     fw_fatal_event_mode,
                                     port_state_down_mode,
                                     port_speed_rate_mode,
                                     disable_health_check,
                                     use_2nd_bonus_port);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed in __evb_sdk_self_init , error: %s\n", evb_utils_get_err_str(evb_rc));
            goto out_manager_close;
        }
    } else {
        if (profile == PROFILE_ETH) {
            evb_rc = __eth_evb_sdk_xml_init((boot_mode == SX_BOOT_MODE_ISSU_STARTED_E),
                                            pdb_lag_init,
                                            pdb_port_map_init,
                                            fw_fatal_event_mode,
                                            port_state_down_mode,
                                            port_speed_rate_mode,
                                            disable_health_check,
                                            use_2nd_bonus_port);
        } else {
            evb_rc = __ib_evb_sdk_xml_init();
        }
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed in __evb_sdk_xml_init , error: %s\n", evb_utils_get_err_str(evb_rc));
            goto out_manager_close;
        }
    }

    /* Set Async mode to DISABLE, unless boot_mode is ISSU_FAST or FAST and user requested Transaction Mode ENABLE (using XML 'transaction-mode-en' field). */
    if ((__device_db_p[0].transaction_mode_en == FALSE) ||
        ((boot_mode != SX_BOOT_MODE_ISSU_FAST_E) && (boot_mode != SX_BOOT_MODE_FAST_E))) {
        rc = sx_api_transaction_mode_set(__handle, SX_ACCESS_CMD_DISABLE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to sx_api_transaction_mode_set(DISABLE) (%s)\n", sx_status_str(rc));
            goto out_manager_close;
        }
        printf("*** EVB Manager - Transaction mode = DISABLE ***\n");
    } else {
        printf(
            "*** EVB Manager - Transaction mode = ENABLE.\n    Required from user to DISABLE Transaction mode by calling sx_api_transaction_mode_set(DISABLE) ***\n");
    }

    if (wait_events) {
        uint8_t           packet[EVB_MAX_PACKET_SIZE] = {0};
        uint32_t          packet_size = EVB_MAX_PACKET_SIZE;
        sx_receive_info_t receive_info;
        uint16_t          label_port = 0;

        rc = sx_api_host_ifc_open(__handle, &user_channel.channel.fd);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to open host ifc %s\n", sx_status_str(rc));
            evb_rc = EVB_STATUS_ERROR;
            goto out_manager_close;
        }

        /* Register for port UP/DOWN event */
        user_channel.type = SX_USER_CHANNEL_TYPE_FD;
        rc = sx_api_host_ifc_trap_id_register_set(__handle, SX_ACCESS_CMD_REGISTER,
                                                  0, SX_TRAP_ID_PUDE, &user_channel);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to register for PUDE event, error: %s\n", sx_status_str(rc));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }

        while (TRUE) {
            packet_size = EVB_MAX_PACKET_SIZE;
            memset(packet, 0, sizeof(packet));

            /* blocking on packet receive */
            SX_LOG_DBG("Waiting on host ifc packet receive.\n");
            rc = sx_lib_host_ifc_recv(&user_channel.channel.fd, packet,
                                      &packet_size, &receive_info);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed in sx_api_host_ifc_recv, error: %s.\n",
                           sx_status_str(rc));
                evb_rc = EVB_STATUS_ERROR;
                goto out;
            }

            /* TODO: Parse events info at IB profiles. */
            if (profile == PROFILE_ETH) {
                evb_rc = __eth_logical_to_label_port(receive_info.event_info.pude.log_port,
                                                     &label_port);
                if (EVB_CHECK_FAIL(evb_rc)) {
                    SX_LOG_ERR("Failed to find label port, error: %s.\n",
                               evb_utils_get_err_str(evb_rc));
                    goto out;
                }
            } else {
                label_port = (receive_info.event_info.pude.log_port & 0xFFFF) >> 8;
            }

            switch (receive_info.trap_id) {
            case SX_TRAP_ID_PUDE:
                SX_LOG_NTC("PORT [%u] state has changed to [%s].\n", label_port,
                           sx_port_oper_state_str(receive_info.event_info.pude.oper_state));
                break;

            default:
                SX_LOG_WRN("Unsolicited event received with trap id [%u].\n",
                           receive_info.trap_id);
                break;
            }
        }
    }

out:
    /* close all open handles and free memory */
    if (user_channel.channel.fd.fd != -1) {
        rc = sx_api_host_ifc_close(__handle, &user_channel.channel.fd);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to open host ifc %s\n", sx_status_str(rc));
            evb_rc = EVB_STATUS_ERROR;
        }
    }

    if ((evb_rc | sxd_status | rc) != 0) {
        evb_rc = EVB_STATUS_ERROR;
    }
out_manager_close:
    if (evb_rc == EVB_STATUS_SUCCESS) {
        SX_LOG_NTC("*** DVS Manager successfully configured the requested setup ***\n");
        printf("*** DVS Manager successfully configured the requested setup ***\n");
    } else {
        SX_LOG_NTC("*** DVS Manager failed to configure the requested setup ***\n");
        printf("*** DVS Manager failed to configure the requested setup ***\n");
    }

    if (evb_rc == EVB_STATUS_SUCCESS) {
        evb_rc = __manager_close(__device_count);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed in __manager_close , [error: %s] , exit...\n", evb_utils_get_err_str(evb_rc));
        }
    } else {
        __manager_close(__device_count);
    }

    if (use_log_lib) {
        dlclose(log_lib);
    }

    if (use_log_file) {
        fclose(log_file);
    }

    return (evb_rc);
}

evb_status_t __manager_close(IN int device_count)
{
    int          device_index = 0;
    sx_status_t  rc = SX_STATUS_SUCCESS;
    sxd_status_t sxd_status = SXD_STATUS_SUCCESS;
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    /* close configuration file */
    if (__reader_p) {
        sx_xml_reader_free(__reader_p);
    }
    if (__parser_p) {
        sx_xml_parser_free(__parser_p);
    }
    if (__tree_p) {
        sx_xml_tree_free(__tree_p);
    }

    /* free memory for each device */
    for (; device_index < device_count; device_index++) {
        if (__device_db_p[device_index].uc_mac_arr) {
            evb_rc
                = EVB_PORT_UTILS_MEM_PUT(__device_db_p[device_index].uc_mac_arr);
            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("failed to free uc_mac_arr\n");
                evb_rc = EVB_STATUS_ERROR;
            }
        }

        if (__device_db_p[device_index].port_info_arr_eth) {
            evb_rc
                = EVB_PORT_UTILS_MEM_PUT(__device_db_p[device_index].port_info_arr_eth);
            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("failed to free port_info_arr\n");
                evb_rc = EVB_STATUS_ERROR;
            }
        }
        if (__device_db_p[device_index].port_info_arr_ib) {
            evb_rc
                = EVB_PORT_UTILS_MEM_PUT(__device_db_p[device_index].port_info_arr_ib);
            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("failed to free port_info_arr\n");
                evb_rc = EVB_STATUS_ERROR;
            }
        }
        if (__device_db_p[device_index].port_info_arr) {
            evb_rc
                = EVB_PORT_UTILS_MEM_PUT(__device_db_p[device_index].port_info_arr);
            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("failed to free port_info_arr\n");
                evb_rc = EVB_STATUS_ERROR;
            }
        }
    }

    /* free devices array */
    if (__device_db_p) {
        evb_rc = EVB_PORT_UTILS_MEM_PUT(__device_db_p);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed to free devices array\n");
            evb_rc = EVB_STATUS_ERROR;
        }
    }

    /*ee topology device array */
    __topo_eth_device_db_free();

    /* close sx-api */
    rc = sx_api_close(&__handle);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to close SX-API , error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
    }

    if (__swids_db_p_ib) {
        evb_rc = EVB_PORT_UTILS_MEM_PUT(__swids_db_p_ib);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed to free swids array\n");
            evb_rc = EVB_STATUS_ERROR;
        }
    }
    if (__swids_db_p_eth) {
        evb_rc = EVB_PORT_UTILS_MEM_PUT(__swids_db_p_eth);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed to free swids array\n");
            evb_rc = EVB_STATUS_ERROR;
        }
    }

    /* close access register */
    sxd_status = sxd_access_reg_deinit();
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("failed to close register access, error: %s\n", SXD_STATUS_MSG(sxd_status));
        evb_rc = EVB_STATUS_ERROR;
    }

    /* print memory status */
    evb_utils_memory_print_summary(UTILS_MEM_TYPE_ID_EVB_MANAGER);

    SX_LOG_EXIT();
    return evb_rc;
}

static int __count_chars(IN char *str, IN char ch)
{
    int count = 0;
    int i = 0;
    int str_len = 0;

    assert(str != NULL);

    str_len = strlen(str);
    for (; i < str_len; i++) {
        if (str[i] == ch) {
            count++;
        }
    }

    return count;
}


void __evb_log_cb(sx_log_severity_t severity, const char *module_name, char *msg)
{
    sx_verbosity_level_t verbosity = 0;

    SEVERITY_LEVEL_TO_VERBOSITY_LEVEL(severity, verbosity);

    if (log_file) {
        fprintf(log_file, "[%-20s][%s] : %s", module_name, SX_VERBOSITY_LEVEL_STR(verbosity), msg);
    } else if (log_lib_cb) {
        log_lib_cb(severity, module_name, msg);
    } else {
        syslog((int)VERBOSITY_LEVEL_TO_SYSLOG_LEVEL(verbosity), "[%-20s][%s] : %s",
               module_name, SX_VERBOSITY_LEVEL_STR(verbosity), msg);
    }

    return;
}


evb_status_t __open_configuration_file(IN char * const path_p)
{
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (path_p == NULL) {
        SX_LOG_WRN("Can't open EVB manager configuration file , empty file name\n");
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

    sx_xml_log_function_set(__evb_log_cb);
    sx_xml_log_verbosity_level_set(LOG_VAR_NAME(__MODULE__));

    /* Creates an XML parser. This is the first function to call. */
    __parser_p = sx_xml_parser_create();
    if (__parser_p == NULL) {
        SX_LOG_WRN("Unable to create an XML parser\n");
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }
    sx_xml_parser_ignore_whitespaces(__parser_p);

    /* Loads an XML file. */
    __reader_p = sx_xml_reader_create(path_p);
    if (__reader_p == NULL) {
        SX_LOG_WRN("Unable to load the XML file %s\n", path_p);
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

    __tree_p = sx_xml_tree_create(__parser_p, __reader_p);
    if (__tree_p == NULL) {
        SX_LOG_WRN("Unable to parse an XML file\n");
        evb_rc = EVB_STATUS_ERROR;
    }

out:
    if (EVB_CHECK_FAIL(evb_rc)) {
        if (__tree_p != NULL) {
            sx_xml_tree_free(__tree_p);
            __tree_p = NULL;
        }
        if (__reader_p != NULL) {
            sx_xml_reader_free(__reader_p);
            __reader_p = NULL;
        }
        if (__parser_p != NULL) {
            sx_xml_parser_free(__parser_p);
            __parser_p = NULL;
        }
    }

    SX_LOG_EXIT();
    return evb_rc;
}


/*****************************************************************************/
/*		       XML PARSING FUNCTIONS IMPL			     */
/*****************************************************************************/

evb_status_t __parse_device_count_section(OUT int *device_count_p)
{
    evb_status_t      evb_rc = EVB_STATUS_SUCCESS;
    sx_xml_element_t *child_number_of_devices = sx_xml_element_by_name_get(
        sx_xml_tree_root_element_get(__tree_p), "number-of-devices");

    SX_LOG_ENTER();

    if (device_count_p == NULL) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    if (child_number_of_devices != NULL) {
        device_count_p[0] = atoi(sx_xml_element_content_get(
                                     child_number_of_devices));
    } else {
        SX_LOG_ERR("Error parsing number of devices\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __parse_swid_section(OUT int *swid_count_p, OUT sx_swid_t **swid_arr_p, IN char *swid_key)
{
    char             *search = " , ";
    char             *token;
    int               i = 0;
    sx_swid_t         temp_swid = 0;
    evb_status_t      evb_rc = EVB_STATUS_SUCCESS;
    sx_xml_element_t *child_swids = sx_xml_element_by_name_get(
        sx_xml_tree_root_element_get(__tree_p), swid_key);

    SX_LOG_ENTER();

    if ((swid_count_p == NULL) || (swid_arr_p == NULL)) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    if (child_swids) {
        char *swids_str = (char*)sx_xml_element_content_get(child_swids);

        if (swids_str == NULL) {
            SX_LOG_WRN("Empty string in swids element\n");
            evb_rc = EVB_STATUS_SUCCESS;
            goto out;
        }

        swid_count_p[0] = __count_chars(swids_str, ',') + 1;

        /* allocate memory */
        evb_rc = EVB_UTILS_CLR_MEM_GET(swid_arr_p, swid_count_p[0], sizeof(sx_swid_t));
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed to allocate memory for swids_arr_p , error: %s\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }

        /* move again and fill array */
        token = strtok(swids_str, search);
        while (token) {
            temp_swid = (sx_swid_t)atoi(token);

            printf("added swid to swids array: %d\n", temp_swid);
            swid_arr_p[0][i] = temp_swid;
            token = strtok(NULL, search);
            i++;
        }
    } else {
        SX_LOG_ERR("Error parsing swids section\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }
out:
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __parse_device_ports_list_section(IN profile_t         profile,
                                               IN sx_xml_element_t *child_p,
                                               OUT port_info_t    **port_info_arr,
                                               OUT int             *port_info_arr_len_p)
{
    evb_status_t   evb_rc = EVB_STATUS_SUCCESS;
    sx_xml_list_t *list = NULL;
    sx_xml_list_t *list_head = NULL;

    if (child_p == NULL) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    sx_xml_element_t *ports_list = sx_xml_element_by_name_get(
        child_p, "ports-list");
    sx_xml_element_t *number_of_physical_ports_element = sx_xml_element_by_name_get(
        child_p, "number-of-physical-ports");
    int number_of_physical_ports = 0;
    int port_info_index = 0;

    SX_LOG_ENTER();

    /* get number-of-physical-ports */
    if (number_of_physical_ports_element != NULL) {
        number_of_physical_ports = atoi(sx_xml_element_content_get(
                                            number_of_physical_ports_element));
    } else {
        SX_LOG_ERR("Error parsing number of physical ports value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
        goto out;
    }

    port_info_arr_len_p[0] = number_of_physical_ports;
    if (ports_list) {
        /* allocate memory for port_info_arr */
        evb_rc = EVB_UTILS_CLR_MEM_GET(port_info_arr, number_of_physical_ports, sizeof(port_info_t));
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed to allocate memory for port_info_arr , error: %s\n", evb_utils_get_err_str(evb_rc));
            goto out;
        }

        /* iterate port info objects */
        port_info_index = 0;
        list_head = sx_xml_element_shallow_list_by_name_get(ports_list, "port-info");
        list = list_head;
        while (list != NULL && port_info_index < number_of_physical_ports) {
            sx_xml_element_t *child = sx_xml_element_list_data(list);

            /* parse port info */
            if (profile == PROFILE_ETH) {
                evb_rc = __eth_parse_port_info_section(child, &(port_info_arr[0][port_info_index]));
            } else {
                evb_rc = __ib_parse_port_info_section(child, &(port_info_arr[0][port_info_index]));
            }
            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("Failed to parse port info section [section #: %d], error: %s\n",
                           port_info_index,
                           evb_utils_get_err_str(evb_rc));
                goto out;
            }

            port_info_index++;
            list = sx_xml_element_list_next(list);
        }
    } else {
        SX_LOG_ERR("Error parsing ports list section\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }
out:
    sx_xml_element_shallow_list_free(list_head); /* free list */
    SX_LOG_EXIT();
    return evb_rc;
}


/*****************************************************************************/
/*		       ETH RELATED FUNCTIONS IMPL		             */
/*****************************************************************************/


/*****************************************************************************/
/*		       IB RELATED FUNCTIONS IMPL		             */
/*****************************************************************************/


evb_status_t __set_port_mapping_per_port(sxd_dev_id_t       dev_id,
                                         port_info_t       *port_info_p,
                                         port_system_mode_t port_system_mode)
{
    int                j = 0;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_pmlp_reg pmlp_reg;
    evb_status_t       evb_rc = EVB_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_port_log_id_t   log_port_eth;
    uint8_t            lane_index;

    SX_LOG_ENTER();

    if (port_info_p == NULL) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    memset(&pmlp_reg, 0, sizeof(struct ku_pmlp_reg));

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pmlp_reg.local_port, pmlp_reg.lp_msb, port_info_p->port_mapping.local_port);
    pmlp_reg.width = port_info_p->port_mapping.width;

    reg_meta.swid = 0;
    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    SX_LOG_DBG("Port : [%d]\n", port_info_p->port_mapping.local_port);
    pmlp_reg.use_different_rx_tx =
        port_info_p->module_lane_map.use_different_rx_tx;

    for (j = 0; j < pmlp_reg.width; ++j) {
        pmlp_reg.module[j]
            = port_info_p->module_lane_map.module[j];
        pmlp_reg.slot[j]
            = port_info_p->module_lane_map.slot[j];
        pmlp_reg.lane[j]
            = port_info_p->module_lane_map.lane[j];
        pmlp_reg.rx_lane[j]
            = port_info_p->module_lane_map.rx_lane[j];
        SX_LOG_DBG("Slot: [%u] , Module : [%u] , Lane : [%u]\n", pmlp_reg.slot[j], pmlp_reg.module[j],
                   pmlp_reg.lane[j]);
    }

    switch (port_system_mode) {
    case PORT_SYSTEM_IB:
        sxd_status = sxd_access_reg_pmlp(&pmlp_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_status)) {
            SX_LOG_ERR("Failed to set port [%d] mapping [PMLP], error: %s\n",
                       port_info_p->port_mapping.local_port,
                       SXD_STATUS_MSG(sxd_status));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }
        break;

    case PORT_SYSTEM_ETH:

        port_info_p->port_mapping.lane_bmap = 0;
        /* Parse lane bitmap*/
        for (lane_index = 0; lane_index < port_info_p->port_mapping.width; lane_index++) {
            port_info_p->port_mapping.lane_bmap |= 0x01 << port_info_p->module_lane_map.lane[lane_index];
        }
        log_port_eth = 0;
        SX_PORT_DEV_ID_SET(log_port_eth, __device_db_p->device_info.dev_id);
        SX_PORT_TYPE_ID_SET(log_port_eth, SX_PORT_TYPE_NETWORK);
        SX_PORT_PHY_ID_SET(log_port_eth, port_info_p->port_mapping.local_port);

        sx_status = sx_api_port_mapping_set(__handle, &log_port_eth, &(port_info_p->port_mapping), 1);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to set log_port 0x%x , error: %s\n",
                       log_port_eth,
                       sx_status_str(sx_status));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }
        break;

    default:
        evb_rc = EVB_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported port_system mode\n");
        goto out;
        break;
    }

    SX_LOG_DBG("Successfully set port mapping\n");

out:
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __set_port_unmapping_per_port(sxd_dev_id_t       dev_id,
                                           port_info_t       *port_info_p,
                                           port_system_mode_t port_system_mode)
{
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_pmlp_reg pmlp_reg;
    evb_status_t       evb_rc = EVB_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_port_log_id_t   log_port_eth;
    sx_port_mapping_t  port_mapping;

    SX_LOG_ENTER();

    if (port_info_p == NULL) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    memset(&pmlp_reg, 0, sizeof(struct ku_pmlp_reg));

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pmlp_reg.local_port, pmlp_reg.lp_msb, port_info_p->port_mapping.local_port);
    pmlp_reg.width = 0;

    reg_meta.swid = 0;
    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;


    SX_LOG_DBG("Port : [%d], Width : [%d]\n", port_info_p->port_mapping.local_port, pmlp_reg.width);


    switch (port_system_mode) {
    case PORT_SYSTEM_IB:
        sxd_status = sxd_access_reg_pmlp(&pmlp_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_status)) {
            SX_LOG_ERR("Unable to set SXD EMAD PMLP: [%s]\n", SXD_STATUS_MSG(sxd_status));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }
        break;

    case PORT_SYSTEM_ETH:
        log_port_eth = 0;
        SX_PORT_DEV_ID_SET(log_port_eth, __device_db_p->device_info.dev_id);
        SX_PORT_TYPE_ID_SET(log_port_eth, SX_PORT_TYPE_NETWORK);
        SX_PORT_PHY_ID_SET(log_port_eth, port_info_p->port_mapping.local_port);

        /* memcpy(&port_mapping, &(port_info_p->port_mapping), sizeof(sx_port_mapping_t)); */
        memset(&port_mapping, 0, sizeof(port_mapping));
        port_mapping.local_port = port_info_p->port_mapping.local_port;
        sx_status = sx_api_port_mapping_set(__handle, &log_port_eth, &(port_mapping), 1);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Unable to set SX API PORT MAPPING: [%s]\n", sx_status_str(sx_status));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }
        /* port_info_p->port_mapping.mapping_mode = SX_PORT_MAPPING_MODE_ENABLE; */
        break;

    default:
        evb_rc = EVB_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported port_system mode\n");
        goto out;
        break;
    }

    SX_LOG_DBG("Successfully set port UN-mapping\n");

out:
    SX_LOG_EXIT();
    return evb_rc;
}

/*****************************************************************************/
/*	             HELPER FUNCTIONS IMPL				     */
/*****************************************************************************/


evb_status_t __port_rate_dump(sx_port_rate_bitmask_t *rate_p)
{
    SX_LOG_ENTER();

    /* Let's use buffer of 256 bytes to collect all enabled rate values */
    char buf[256] = {0};

    if (NULL == rate_p) {
        SX_LOG_ERR("NULL pointer for rate_p\n");
        return EVB_STATUS_PARAM_NULL;
    }

    if (rate_p->rate_100M == TRUE) {
        strcat(buf, "100M, ");
    }

    if (rate_p->rate_1G == TRUE) {
        strcat(buf, "1G, ");
    }

    if (rate_p->rate_10G == TRUE) {
        strcat(buf, "10G, ");
    }

    if (rate_p->rate_25G == TRUE) {
        strcat(buf, "25G, ");
    }

    if (rate_p->rate_40G == TRUE) {
        strcat(buf, "40G, ");
    }

    if (rate_p->rate_50G == TRUE) {
        strcat(buf, "50G, ");
    }

    if (rate_p->rate_100G == TRUE) {
        strcat(buf, "100G, ");
    }

    if (rate_p->rate_200G == TRUE) {
        strcat(buf, "200G, ");
    }

    if (rate_p->rate_400G == TRUE) {
        strcat(buf, "400G, ");
    }

    if (rate_p->rate_800G == TRUE) {
        strcat(buf, "800G, ");
    }

    if (rate_p->rate_auto == TRUE) {
        strcat(buf, "auto, ");
    }

    SX_LOG_DBG("%s\n", buf);

    SX_LOG_EXIT();
    return EVB_STATUS_SUCCESS;
}

evb_status_t __port_pmd_type_dump(sx_port_phy_module_type_bitmask_t *type_p)
{
    SX_LOG_ENTER();

    /* Let's use buffer of 256 bytes to collect all enabled type values
     *  please note that all types occupy 177 bytes only */
    char buf[256] = {0};

    if (NULL == type_p) {
        SX_LOG_ERR("NULL pointer for type_p\n");
        return EVB_STATUS_PARAM_NULL;
    }

    if (type_p->module_smf_up_500m == TRUE) {
        strcat(buf, "SMF up to 500m, ");
    }

    if (type_p->module_smf_up_2km == TRUE) {
        strcat(buf, "SMF in range 500-2000m, ");
    }

    if (type_p->module_smf_above_2km == TRUE) {
        strcat(buf, "SMF above 2000m, ");
    }

    if (type_p->module_mmf_up_100m == TRUE) {
        strcat(buf, "MMF up to 100m, ");
    }

    if (type_p->module_mmf_above_100m == TRUE) {
        strcat(buf, "MMF above 100m, ");
    }

    if (type_p->module_aoc_acc_up_30m == TRUE) {
        strcat(buf, "active optical/cr up to 30m, ");
    }

    if (type_p->module_aoc_acc_above_30m == TRUE) {
        strcat(buf, "active optical/cr above 30m, ");
    }

    if (type_p->module_base_cr == TRUE) {
        strcat(buf, "passive copper, ");
    }

    if (type_p->module_base_tp == TRUE) {
        strcat(buf, "twisted pair, ");
    }

    SX_LOG_DBG("%s\n", buf);

    SX_LOG_EXIT();
    return EVB_STATUS_SUCCESS;
}
