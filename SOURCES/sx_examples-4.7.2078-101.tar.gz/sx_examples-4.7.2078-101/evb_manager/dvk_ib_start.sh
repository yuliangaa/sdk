#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


profile="ib-single"
target="dvk"
sdk_applibs_modules="all"
sdk_mode=${1:-"802.1Q"}
max_vlan=${2:-"0"}
dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

$dir/evb_start.sh ${profile} ${target} ${sdk_applibs_modules} ${sdk_mode} ${max_vlan}