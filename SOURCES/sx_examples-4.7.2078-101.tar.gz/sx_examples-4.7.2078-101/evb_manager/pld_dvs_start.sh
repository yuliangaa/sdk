#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

me=$(basename "$0")

# Log executed command with all flags, for debuggability, to a file. Used by dvs_stop + VER.
full_cmd_log=/tmp/dvs.start.cmd.log
echo ${me} ${*} > ${full_cmd_log} 2>&1
syslog=1

usage()
{
    echo "The script enables EVB software"
    echo "Usage $0 [--pld_system] [--mode] [--sdk_bridge_mode] [--max_vlan] [--rpc_sniffer] [--rpc_sniffer_file_path]  [--sxd_sniffer] [--sxd_sniffer_file_path] \
	  [--kvd_linear_size] [--kvd_single_size] [--kvd_double_size] [--prm_sniffer] [--prm_sniffer_file_path]  \
          [--fast_boot] [--boot_mode] [--lazy_delete_mode] [--fdb_async_mode] [--sdk_async_mode] [--use_sgmii] [--pipeline_latency_size] \
          [--enable_chassis_manager_debugger] [--enable_debugger] [--enable_dvs_manager_debugger] [--enable_evb_debugger] [--enable_rsc_manager_debugger] \
          [--verbosity <v>] [--syslog] [--acl_search_type] [--emad_dump] [--restore] [--fatal_error_mode] [--fw_fatal_event_mode] [--sys_acl_drop_trap_en] \
          [--hide_deprecation_err] [--pdb_lag_init] [--pdb_port_map_init] [--port_speed_rate_mode] [--port_state_down_mode] [--custom_config_file] [--acl_manual_bind] [--urmcv6_enable] \
          [--roaming_mac_notif_en] [--cos_max_buff_mode] [--emad_timeout] [--disable_modular_chassis_init] [--port_profiles_num] [--use_xm] \
          [--accuflow_max_number] [--max_bridge] [--max_port_router] [--module_support_disable] [--asan] [--asan_options] [--lsan_options] [--load_spice] [--bist] [--enable_ib_split_profile] [--disable_health_check] [--do_not_init_with_port_profile]"
    echo ""
    echo "mode options: eth|vpi|ib (for vpi systems), eth (for eth systems)"
    echo "sdk_bridge_mode options: 802.1Q|802.1D|HYBRID"
    echo "port_profiles_num options: 0-4"
    echo ""
    echo "--pld_system                    This flag defines PLD system type (raven|phoenix|blackbird|sunbird|albatross|flamingo). This flag is mandatory."
    echo "--mode                          When mode flag is not given the mode of the sdk package installed on switch is used."
    echo "--sdk_bridge_mode               When sdk_bridge_mode flag is not given the bridge mode of the sdk is 802.1Q."
    echo "--max_vlan                      When max_vlan flag is not given or it equals to 0, the max_vlans mode of the sdk is 4096."
    echo "--rpc_sniffer                   When rpc_sniffer flag is not given. sniffer won't be loaded."
    echo "--rpc_sniffer_file_path         When rpc_sniffer_file_path is not given, a path will be given by the system."
    echo "--sxd_sniffer                   When sxd_sniffer flag is not given, sxd_sniffer will not record."
    echo "--sxd_sniffer_file_path         When sxd_sniffer_file_path is not given, default path(/tmp/sxd_recording.bin) will be used."
    echo "--kvd_linear_size               When kvd_linear_size is not given default size will be used"
    echo "--kvd_single_size               When kvd_single_size is not given default size will be used"
    echo "--kvd_double_size               When kvd_double_size is not given default size will be used"
    echo "--prm_sniffer                   When prm_sniffer flag is not given, prm_sniffer will not record."
    echo "--prm_sniffer_file_path         When prm_sniffer_file_path is not given, default path(/tmp/prm_recording.log) will be used."
    echo "--fast_boot                     When fast_boot is not given, default mode = disable."
    echo "--boot_mode                     When boot_mode is not given, the SDK will start regularly. options: NORMAL, FAST, ISSU_NORMAL, ISSU_FAST, ISSU_STARTED"
    echo "--lazy_delete_mode              When lazy_delete_mode equals 0 SDK will not use it, otherwise lazy delete is in use."
    echo "--fdb_async_mode                When fdb_async_mode is not given, default mode = synced."
    echo "--sdk_async_mode                When sdk_async_mode is not given, the SDK will work in sync mode. Options: SYNC,ASYNC_RETURN_STATUS_SUCCESS,ASYNC_RETURN_STATUS_ACCEPTED"
    echo "--use_sgmii                     When use_sgmii is not given, default mode = disable."
    echo "--pipeline_latency_size         When mirror_buffer_size is not given, default size = 217 (in cell units)."
    echo "--verbosity=<v>                 When not specified, chassis manager sets SDK verbosity to NOTICE(3) as a default"
    echo "                                <v> may be 0=NONE,1=ERROR,2=WARNING,3=NOTICE,4=INFO,5=DEBUG,6=FUNCS,7=FRAMES,8=ALL,no=Do not set"
    echo "--syslog                        When not specified, disabled as a default. If enabled, logging to syslog."
    echo "--acl_search_type <type>        When not specified acl type is serial.{ SERIAL, PARALLEL }"
    echo "--emad_dump <direction> <pcap>  Start emad_dump in the given direction with the given .pcap file. To stop, run emad_dump_stop.sh."
    echo "--restore                       When restore flag is given, sdk will be restored and the other options will be ignored."
    echo "--fatal_error_mode              When not specified, mode is disabled. If enabled it logs a backtrace to stderr and kills the SDK process"
    echo "--fw_fatal_event_mode           When not specified, mode is FW_NO_CHECK. defines the fw behavior in case of a fatal event. options:FW_NO_CHECK, FW_CONTINUE, FW_HALT"
    echo "--sys_acl_drop_trap_en          When not specified, mode is disabled. If enabled SDK starts trapping packets dropped by System ACLs to WJH Q"
    echo "--hide_deprecation_err          When not specified, mode is disabled. If enabled it hides deprecation errors for deprecated APIs"
    echo "--pdb_lag_init                  When pdb_lag_init is not given, default is false."
    echo "--pdb_port_map_init             When pdb_port_map_init is not given, default is false."
    echo "--port_state_down_mode          When port_state_down_mode is not given, default is false. if given all the ports state will be down"
    echo "--port_speed_rate_mode          When port_speed_rate_mode is not given, default is DEFAULT. DEFAULT=port_admin_speed on Spectrum and port_rate on Spectrum-2 and above, SPEED=port_admin_speed, RATE=port_rate"
    echo "--custom_config_file            When not specified, default config file will be determined according to PSID"
    echo "--acl_manual_unbind             When not given, default value is false, bound ACLs are automatically removed when removing binding point"
    echo "--urmcv6_enable                 When not given, default value is false, URMCV6 vector is BC"
    echo "--roaming_mac_notif_en          When roaming_mac_notif_en equals 0 SDK will not report roaming flag in FDB notification, otherwise roaming flag will be reported."
    echo "--cos_max_buff_mode <mode>      Mode can be {\"GUARANTEED\",\"TOTAL\"}. When not given, default value is GUARANTEED"
    echo "--emad_timeout <usec>           Set custom EMAD Timeout, In micro-seconds (1 Sec = 1000000 uSec). Valid range is [1-4294967295]. When not given, will use SDK Default value of 20 Seconds"
    echo "--disable_modular_chassis_init  For Modular systems only, when not specified, modular chassis init happens automatically in modular systems."
    echo "--port_profiles_num             When not specified, 2 port profiles are used."
    echo "--use_xm                        When not specified, default is false"
    echo "--accuflow_max_number           Maximum number of accumulated counter-sets. Range: 1..400 (in K (1024) units). The default values is 400."
    echo "--max_bridge                    When max_bridge flag is not given, it is 512 by default."
    echo "--max_port_router               When max_port_router flag is not given or it equals to 0, it is 1000(SPC), 4000(SPC2/3), 8000(SPC4)."
    echo "--module_support_disable        When not specified, module support is enabled in SDK. If disabled user can use kernel interfaces instead to configure module."
    echo "--asan                          When asan flag is provided, SDK will start with address sanitizer support."
    echo "--asan_options='<options>'      Address sanitizer options to use when --asan provided. Default are: ${DEFAULT_ASAN_OPTIONS}"
    echo "--lsan_options='<options>'      Leak sanitizer options to use when --asan provided. Default are: ${DEFAULT_LSAN_OPTIONS}"
    echo "--load_spice                    When not specified, default is false"
    echo "--bist                          Trigger Built-In-Self-Testing - Simple sanity test for the SDK + Driver, that will execute after SDK Was loaded"
    echo "--enable_ib_split_profile         Configure switch profile with split enable."
    echo "--disable_health_check            Disable SDK health check mechanism. Default: False (ignored when --fatal_error_mode is enabled)"
    echo "--do_not_init_with_port_profile   When specified, dvs will init all ports without using port profile"
    echo "--enable_chassis_manager_debugger Enable debugger to start chassis manager."
    echo "--enable_debugger                 Enable debugger to start sx_sdk."
    echo "--enable_dvs_manager_debugger     Enable debugger to start dvs manager."
    echo "--enable_evb_debugger             Enable debugger to start all resource, chassis and dvs managers."
    echo "--enable_rsc_manager_debugger     Enable debugger to start resource manager."
}

# VARIABLES DEFINITION
SDK_DATA_PATH="$(cd -- "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P)/../share"
DEFAULT_ASAN_OPTIONS="log_path=/tmp/asan.log:log_exe_name=1:halt_on_error=0:verify_asan_link_order=0:disable_coredump=0"
DEFAULT_LSAN_OPTIONS="suppressions=${SDK_DATA_PATH}/sx_sdk_lsan_ignore.txt:print_suppressions=0"
#sdk_async_mode="ASYNC_RETURN_STATUS_ACCEPTED"
accuflow_max_number="400"
acl_manual_unbind=""
acl_search_type="SERIAL"
asan_options=${DEFAULT_ASAN_OPTIONS}
asan="0"
bist="0"
boot_mode="DISABLED"
bridge_mode=""
cos_max_buff_mode_param="GUARANTEED"
custom_config_file=""
dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
disable_modular_chassis_init=""
emad_dump_dir=""
emad_dump_pcap=""
emad_dump=""
emad_timeout=""
fast_boot="0"
fatal_error_mode="0"
fdb_async_mode=""
fw_fatal_event_mode=""
hide_deprecation_err="0"
kvd_double_size=""
kvd_linear_size=""
kvd_single_size=""
lazy_delete="1"
load_spice=""
lsan_options=${DEFAULT_LSAN_OPTIONS}
max_bridge=""
max_port_router=""
max_vlan="0"
module_support_disable=""
pdb_lag_init=""
pdb_port_map_init=""
pipeline_latency_size=""
pld_system=""
port_profiles_num="2"
port_speed_rate_mode="DEFAULT"
port_state_down_mode=""
prm_sniffer_file_path=""
prm_sniffer=""
restore="0"
roaming_mac_notif_en="1"
rpc_sniffer_file_path=""
rpc_sniffer=""
sdk_async_mode="" # changing to default sync mode.
start_mode=""
sxd_sniffer_file_path=""
sxd_sniffer=""
sys_acl_drop_trap_en="0"
urmcv6_enable=""
use_xm=""
verbosity=""
enable_ib_split_profile="0"
disable_health_check="0"
do_not_init_with_port_profile="0"

# GET INPUT PARAMETERS

while [ "`echo $1 | cut -c1`" = "-" ]
do
    flag=${1%=*}
    param=${1#*=}

    # --help
    case "$flag" in
        -h | --help)
            usage
            exit 0
            ;;
    esac

    # --pld_system
    case "$flag" in
        --pld_system)
            param=${1#*=}
            pld_system=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --mode
    case "$flag" in
        --mode)
            param=${1#*=}
            start_mode=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --sdk_bridge_mode
    case "$flag" in
        --sdk_bridge_mode)
            param=${1#*=}
            bridge_mode=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --max_vlan
    case "$flag" in
        --max_vlan)
            param=${1#*=}
            max_vlan=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --kvd_linear_size
    case "$flag" in
        --kvd_linear_size)
            param=${1#*=}
            kvd_linear_size=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --kvd_single_size
    case "$flag" in
        --kvd_single_size)
            param=${1#*=}
            kvd_single_size=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --kvd_double_size
    case "$flag" in
        --kvd_double_size)
            param=${1#*=}
            kvd_double_size=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --prm_sniffer
    case "$flag" in
        --prm_sniffer)
            prm_sniffer=1
            shift 1
            continue # skip to next param
            ;;
    esac

    # --prm_sniffer_file_path
    case "$flag" in
        --prm_sniffer_file_path)
            param=${1#*=}
            prm_sniffer_file_path=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --rpc_sniffer
    case "$flag" in
        --rpc_sniffer)
            rpc_sniffer=1
            shift 1
            continue # skip to next param
            ;;
    esac

    # --rpc_sniffer_file_path
    case "$flag" in
        --rpc_sniffer_file_path)
            param=${1#*=}
            rpc_sniffer_file_path=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --sxd_sniffer
    case "$flag" in
        --sxd_sniffer)
            sxd_sniffer=1
            shift 1
            continue # skip to next param
            ;;
    esac

    # --sxd_sniffer_file_path
    case "$flag" in
        --sxd_sniffer_file_path)
            param=${1#*=}
            sxd_sniffer_file_path=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --fast_boot
    case "$flag" in
        --fast_boot)
            fast_boot=1
            shift 1
            continue # skip to next param
            ;;
    esac

    # --boot_mode
    case "$flag" in
        --boot_mode)
            param=${1#*=}
            boot_mode=$param
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --lazy_delete_mode
    case "$flag" in
        --lazy_delete_mode)
            lazy_delete=$param
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --fdb_async_mode
    case "$flag" in
        --fdb_async_mode)
            param=${1#*=}
            fdb_async_mode=$param
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --sdk_async_mode
    case "$flag" in
        --sdk_async_mode)
            param=${1#*=}
            sdk_async_mode=$param
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --use_sgmii
    case "$flag" in
        --use_sgmii)
            echo "DVS-OS is unable to work with SGMII"
            exit 1
            ;;
    esac

    # --pipeline_latency_size
    case "$flag" in
        --pipeline_latency_size)
            shift 1
            param=${1#*=}
            pipeline_latency_size=$param
            continue # skip to next param.
            ;;
    esac

    # --verbosity
    case "$flag" in
        --verbosity)
            param=${1#*=}
            verbosity=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    #--syslog
    case "$flag" in
        --syslog)
            syslog="${1#*=}"
            if [[ "${syslog}" != "0" ]]; then    # User didn't assign a value, or given any value which is not 0 -> Treat as 1
                syslog=1
            fi
            shift 1
            continue # Skip to next param.
            ;;
    esac

    # --acl_search_type
    case "$flag" in
         --acl_search_type)
            param=${1#*=}
            acl_search_type=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --emad_dump
    case "$flag" in
        --emad_dump)
            emad_dump="1"
            param=${1#*=}
            emad_dump_dir=$param
            shift 1
            param=${1#*=}
            emad_dump_pcap=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --restore
    case "$flag" in
        --restore)
            restore="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --fatal_error_mode
    case "$flag" in
        --fatal_error_mode)
            fatal_error_mode="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --fw_fatal_event_mode
    case "$flag" in
        --fw_fatal_event_mode)
            param=${1#*=}
            fw_fatal_event_mode=$param
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --sys_acl_drop_trap_en
    case "$flag" in
        --sys_acl_drop_trap_en)
            sys_acl_drop_trap_en="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --hide_deprecation_err
    case "$flag" in
        --hide_deprecation_err)
            hide_deprecation_err="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --pdb_lag_init
    case "$flag" in
        --pdb_lag_init)
            pdb_lag_init="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --pdb_port_map_init
    case "$flag" in
        --pdb_port_map_init)
            pdb_port_map_init="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --custom_config_file
    case "$flag" in
        --custom_config_file)
            custom_config_file="1"
            shift 1
            continue # skip to next param.
            ;;

    esac

    case "$flag" in
        --enable_debugger)
            enable_debugger=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_rsc_manager_debugger)
            enable_rsc_manager_debugger=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_chassis_manager_debugger)
            enable_chassis_manager_debugger=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_dvs_manager_debugger)
            enable_dvs_manager_debugger=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_evb_debugger)
            enable_rsc_manager_debugger=1
            enable_chassis_manager_debugger=1
            enable_dvs_manager_debugger=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    # --acl_manual_unbind
    case "$flag" in
        --acl_manual_unbind)
            acl_manual_unbind="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --urmcv6_enable
    case "$flag" in
        --urmcv6_enable)
            urmcv6_enable="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --roaming_mac_notif_en
    case "$flag" in
        --roaming_mac_notif_en)
            roaming_mac_notif_en=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    # --cos_max_buff_mode
    case "$flag" in
        --cos_max_buff_mode)
            param=${1#*=}
            cos_max_buff_mode_param=$param
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --emad_timeout
    case "$flag" in
        --emad_timeout)
            param=${1#*=}
            emad_timeout=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    # --disable_modular_chassis_init
    case "$flag" in
        --disable_modular_chassis_init)
            disable_modular_chassis_init="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --port_profiles_num
    case "$flag" in
        --port_profiles_num)
            port_profiles_num="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --use_xm
    case "$flag" in
        --use_xm)
            use_xm="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --accuflow_max_number
    case "$flag" in
        --accuflow_max_number)
            param=${1#*=}
            accuflow_max_number=$param
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --max_bridge
    case "$flag" in
        --max_bridge)
            param=${1#*=}
            max_bridge=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --max_port_router
    case "$flag" in
        --max_port_router)
            param=${1#*=}
            max_port_router=$param
            shift 1
            continue # skip to next param
            ;;
    esac

    # --module_support_disable
    case "$flag" in
        --module_support_disable)
            module_support_disable="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --asan
    case "$flag" in
        --asan)
            asan="1"
            shift 1
            continue # skip to next param.
            ;;
    esac

    # --asan_options
    case "$flag" in
        --asan_options)
            param=${1#*=}
            asan_options=$param
            shift 1
            continue # skip to next param.
            ;;
    esac

    #--lsan_options
    case "$flag" in
        --lsan_options)
            param=${1#*=}
            lsan_options=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac
    #--bist
    case "$flag" in
        --bist)
            bist="1"
            shift 1
            continue # skip to next param
            ;;
    esac

    #--port_speed_rate_mode
    case "$flag" in
        --port_speed_rate_mode)
            param=${1#*=}
            port_speed_rate_mode=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    #--port_state_down_mode
    case "$flag" in
        --port_state_down_mode)
            echo "port_state_down_mode=1"
            port_state_down_mode="1"
            shift 1
            continue # skip to next param
            ;;
    esac

    #--load_spice
    case "$flag" in
        --load_spice)
            echo "load_spice=1"
            load_spice="1"
            shift 1
            continue # skip to next param
            ;;
    esac

    case "$flag" in
        --enable_ib_split_profile)
            enable_split=1
            shift 1
            continue # skip to next param.
            ;;
    esac

    case "$flag" in
       --disable_health_check)
           disable_health_check="1"
           shift 1
           continue # Skip to next param.
           ;;
    esac
    
    case "$flag" in
        --do_not_init_with_port_profile)
            do_not_init_with_port_profile=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    # wrong parameter
    case "$flag" in
        *)
            usage
            echo "Wrong flag $flag"
            exit 1
            ;;
    esac
done


if [[ "${syslog}" != "0" ]]; then
    exec 1> >(logger --stderr --tag ${me}) 2>&1   # Log script execution to syslog and stderr
fi

echo "*** PLD DVS Start started ***"

cat ${full_cmd_log} 2> /dev/null      # Log the dvs_start command to shell/syslog

# CHECK THE DRIVER

# check if driver is not already up
lsmod | grep "sx_core" > /dev/null
if [ $? == "0" ]; then
    echo "Error: sx_core driver is running !"
    exit 1
fi


# PARAMETERS PROCESSING

# pld_system
if [ "$pld_system" == "" ]
then
    usage
    echo ""
    echo "Please specify PLD system type"
    exit 1
fi

if [[ "$enable_split" == "1" ]]
then
    echo "Enable split in IB switch profile"
    export ENABLE_IB_SPLIT=1
fi

# start_mode
if [ "$start_mode" != "eth" ] && [ "$start_mode" != "vpi" ] && [ "$start_mode" != "ib" ] && [ "$start_mode" != "" ]
then
    usage
    exit 1
fi

# bridge_mode
if [ "$bridge_mode" != "802.1D" ] && [ "$bridge_mode" != "802.1Q" ] && [ "$bridge_mode" != "HYBRID" ] && [ "$bridge_mode" != "" ]
then
    usage
    exit 1
fi

if [ "$bridge_mode" == "" ]
then
    bridge_mode="802.1Q"
fi

# kvd_linear_size
if [[ "$kvd_linear_size" != "" ]]
then
    export KVD_LINEAR_SIZE=$kvd_linear_size
    echo "The KVD linear size is set to $kvd_linear_size"
fi

# kvd_single_size
if [[ "$kvd_single_size" != "" ]]
then
    export KVD_SINGLE_SIZE=$kvd_single_size
    echo "The KVD single size is set to $kvd_single_size"
fi

# kvd_double_size
if [[ "$kvd_double_size" != "" ]]
then
    export KVD_DOUBLE_SIZE=$kvd_double_size
    echo "The KVD double  size is set to $kvd_double_size"
fi

# prm_sniffer
if [[ "$prm_sniffer" == "1" ]]
then
    export PRM_SNIFFER="1"
    export PRM_SNIFFER_FILE_PATH="$prm_sniffer_file_path"
    echo "prm_sniffer_activated"
fi

# rpc_sniffer
if [[ "$rpc_sniffer" != "" ]] && [[ "$rpc_sniffer" != "1" ]]
then
    usage
    exit 1
fi

if [[ "$rpc_sniffer" == "1" ]]
then
    export evb_sx_sdk_prefix="$evb_sx_sdk_prefix LD_PRELOAD=\"\$LD_PRELOAD libsxsniffer.so\""
    if [[ "x$rpc_sniffer_file_path" != "x" ]]
    then
        export evb_sx_sdk_prefix="$evb_sx_sdk_prefix SX_SNIFFER_TARGET=\"$rpc_sniffer_file_path\""
    fi
fi

# sxd_sniffer
if [[ "$sxd_sniffer" == "1" ]]
then
    export SXD_SNIFFER="1"
    export SXD_SNIFFER_FILE_PATH="$sxd_sniffer_file_path"
    echo "sxd_sniffer_activated"
fi

# fast_boot
if [[ "$fast_boot" == "1" ]]
then
    export FAST_BOOT=1
else
    export FAST_BOOT=0
fi

# boot_mode
if [ "$boot_mode" != "NORMAL" ] && [ "$boot_mode" != "FAST" ] && [ "$boot_mode" != "ISSU_NORMAL" ] && [ "$boot_mode" != "ISSU_FAST" ] && [ "$boot_mode" != "ISSU_STARTED" ] && [ "$boot_mode" != "DISABLED" ]
then
    echo "boot_mode is not valid"
    usage
    exit 1
fi

if [[ "$boot_mode" == "NORMAL" || "$boot_mode" == "FAST" || "$boot_mode" == "ISSU_NORMAL" || "$boot_mode" == "ISSU_FAST" || "$boot_mode" == "ISSU_STARTED" ]]
then
    echo "boot_mode = $boot_mode"
    export BOOT_MODE="$boot_mode"
    if [[ "$boot_mode" == "FAST" || "$boot_mode" == "ISSU_FAST" || "$boot_mode" == "ISSU_STARTED" ]]
    then
        export FAST_BOOT=1
    else
        export FAST_BOOT=0
    fi
else
    echo "missing boot_mode, setting boot_mode = DISABLED"
fi

# lazy_delete
if [[ "$lazy_delete" == "1" ]]
then
    echo "lazy_delete = TRUE"
    export LAZY_DELETE=1
else
    echo "lazy_delete = FALSE"
    export LAZY_DELETE=0
fi

# fdb_async_mode
if [[ "$fdb_async_mode" != "" ]]
then
    export FDB_ASYNC_MODE=$fdb_async_mode
    echo "The FDB async mode is set to $fdb_async_mode"
fi

# sdk_async_mode
if [[ "$sdk_async_mode" != "" ]]
then
    export SDK_ASYNC_MODE=$sdk_async_mode
    echo "The SDK async mode is set to $sdk_async_mode"
fi

# pipeline_latency_size
if [[ "$pipeline_latency_size" != "" ]]
then
    export PIPELINE_LATENCY_SIZE=$pipeline_latency_size
    echo "The pipeline latency size is set to $pipeline_latency_size"
fi

# verbosity
if [[ "$verbosity" != "" ]]
then
    export SDK_VERBOSITY=$verbosity
    echo "SDK log verbosity set to $verbosity"
fi

# acl_search_type
if [ "$acl_search_type" != "PARALLEL" ] && [ "$acl_search_type" != "SERIAL" ]
then
    usage
    exit 1
fi

# emad_dump
if [[ "$emad_dump" == "1" ]]
then
    export RESET_TRIGGER=0
    export EMAD_DUMP_DIR="$emad_dump_dir"
    export EMAD_DUMP_PCAP_FILE="$emad_dump_pcap"
    echo "EMAD dump is enabled"
else
    export RESET_TRIGGER=1
fi

# restore
if [[ "$restore" == "1" ]]
then
    export RESUME_SDK=1
    sdk_criu_dir=/root/.sdk_criu

    `pidof sx_sdk > /dev/null`;
    if [ $? == "0" ]; then
        echo "Error: could not restore sdk : sx_sdk process is running !"
        exit 1
    fi

    cp -rf $sdk_criu_dir/shm/* /var/run/shm/
    if [ $? != "0" ]; then
        exit 1
    fi

    # The restore may fail due to the PID/TID of the checkpointed process (sx_sdk) has been used by other process/thread.
    # The wiki page https://criu.org/When_C/R_fails describes the details of such failure.
    # Below is a simple WA which retries the restore upon such failure, if the retry still fails, then the script exits.
    criu_log=$(criu restore -d -D $sdk_criu_dir/sdk --shell-job 2>&1)
    if [ $? != 0 ]; then
        echo $criu_log | grep -E "Pid\s+[0-9]+\s+do not match expected|Thread pid mismatch"
        if [ $? != 0 ]; then
            echo "Error: CRIU restore failed"
            exit 1
        fi
        echo "The CRIU restore may fail due to the PID/TID of the checkpointed process (sx_sdk) has been used by other process/thread."
        echo "The wiki page https://criu.org/When_C/R_fails describes the details of such failure."
        echo "We are now retrying the restore."
        sleep 2
        criu restore -d -D $sdk_criu_dir/sdk --shell-job
        if [ $? != 0 ]; then
            echo "The retry of CRIU restore still fails, please kexec the kernel and try the restore again."
            exit 1
        fi
    fi

    ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel start
    if [ $? != "0" ]; then
        echo "Error: could not load drivers"
        exit 1
    fi

    $dir/sdk_pause_resume --resume
    if [ $? != "0" ]; then
        exit 1
    fi

    echo -e "\nSDK has been successfully restored.\n"

    exit 0
else
    export RESUME_SDK=0
fi

# fatal_error_mode
if [[ "$fatal_error_mode" == "1" ]]
then
    echo "===Starting in fatal_error_mode==="
    export FATAL_ERROR_MODE=1
else
    export FATAL_ERROR_MODE=0
fi

# fw_fatal_event_mode
if [ "$fw_fatal_event_mode" != "FW_NO_CHECK" ] && [ "$fw_fatal_event_mode" != "FW_CONTINUE" ] && [ "$fw_fatal_event_mode" != "FW_HALT" ] && [ "$fw_fatal_event_mode" != "" ]
then
    echo "Error: invalid fw_fatal_event_mode: ${fw_fatal_event_mode} "
    exit 1
fi

if [[ "$fw_fatal_event_mode" == "" ]]
then
    if [[ "$fatal_error_mode" == "1" ]]
    then
        export FW_FATAL_EVENT_MODE="FW_HALT"
        echo "===Configure fw_fatal_event_mode to FW_HALT==="
    else
        export FW_FATAL_EVENT_MODE="FW_NO_CHECK"
    fi
else
    export FW_FATAL_EVENT_MODE=$fw_fatal_event_mode
    echo "===Starting in fw_fatal_event_mode $FW_FATAL_EVENT_MODE==="
fi

# sys_acl_drop_trap_en
if [[ "$sys_acl_drop_trap_en" == "1" ]]
then
    echo "===Trapping Pkts Dropped by System ACL is ON==="
    export SYS_ACL_DROP_TRAP_EN=1
else
    export SYS_ACL_DROP_TRAP_EN=0
fi

# hide_deprecation_err
if [[ "$hide_deprecation_err" == "1" ]]
then
    echo "===Hiding deprecation err==="
    export evb_sx_sdk_suffix="$evb_sx_sdk_suffix --hide_deprecation_err"
fi

# pdb_lag_init
if [[ "$pdb_lag_init" == "1" ]]
then
    echo "===Starting with pdb_lag_init TRUE==="
    export PDB_LAG_INIT=1
fi

# pdb_port_map_init
if [[ "$pdb_port_map_init" == "1" ]]
then
    echo "===Starting with pdb_port_map_init TRUE==="
    export PDB_PORT_MAP_INIT=1
fi

# custom_config_file
if [ -n "${custom_config_file}" ] && [ ! -f "${custom_config_file}" ]
then
    echo "Error: custom_config_file ${custom_config_file} does not exist"
    exit 1
fi

if [ -n "${custom_config_file}" ]
then
    export SDK_CONFIG_FILE=${custom_config_file}
fi

if [[ "$enable_debugger" == "1" ]]
then
    echo "===Enable GDB to start sx_sdk==="
    export START_SX_SDK_WITH_GDB=1
fi

if [[ "$enable_rsc_manager_debugger" == "1" ]]
then
    echo "===Enable GDB to start resource manager==="
    export START_RSC_MANAGER_WITH_GDB=1
fi

if [[ "$enable_chassis_manager_debugger" == "1" ]]
then
    echo "===Enable GDB to start chassis manager==="
    export START_CHASSIS_MANAGER_WITH_GDB=1
fi

if [[ "$enable_dvs_manager_debugger" == "1" ]]
then
    echo "===Enable GDB to start dvs manager==="
    export START_DVS_MANAGER_WITH_GDB=1
fi

# acl_manual_unbind
if [[ "${acl_manual_unbind}" == "1" ]]
then
    export ACL_MANUAL_UNBIND=1
    echo "ACL manual unbind is enabled"
fi

# urmcv6_enable
if [[ "${urmcv6_enable}" == "1" ]]
then
    export URMCV6_ENABLE=1
    echo "URMCV6 is enabled"
fi

# roaming_mac_notif_en
if [[ "${roaming_mac_notif_en}" == "1" ]]
then
    export ROAMING_MAC_NOTIF_EN=1
    echo "Roaming mac notification is enabled"
fi

# cos_max_buff_mode_param
if [[ "$cos_max_buff_mode_param" == "GUARANTEED"  ||  "$cos_max_buff_mode_param" == "TOTAL" ]]
then
    if [[ "$cos_max_buff_mode_param" == "GUARANTEED" ]]
    then
        export COS_BUFF_MAX_MODE=0
    else
        export COS_BUFF_MAX_MODE=1
    fi
else
    if [[ "$cos_max_buff_mode_param" == "" ]]
    then
        echo "Missing mode argument for --cos_max_buff_mode"
    else
        echo "Invalid mode argument for --cos_max_buff_mode"
    fi
    usage
    exit 1
fi

# emad_timeout
if [[ "${emad_timeout}" != "" ]]
then
    int(){ expr 0 + ${1:-} 2>/dev/null||:; }
    emad_timeout=$(int $emad_timeout)
    if [[ "${emad_timeout}" == "" ]]
    then
        echo "Invalid EMAD Timeout given (Non-int)"
        exit 1
    fi

    ((emad_timeout<1 || emad_timeout>4294967295)) && echo "EMAD Timeout invalid ($emad_timeout). valid range is [1-4294967295]" && exit 1

    export EMAD_TIMEOUT="$emad_timeout"
    echo "EMAD Custom timeout given: '$emad_timeout' usec"
fi

# disable_modular_chassis_init
if [[ "$disable_modular_chassis_init" == "1" ]]
then
    echo "===Starting with disable_modular_chassis_init TRUE==="
    export DISABLE_MODULAR_CHASSIS_INIT=1
fi

# port_profiles_num
if [ "$port_profiles_num" == "" ]
then
    port_profiles_num="2"
fi
export PORT_PROFILES_NUM=$port_profiles_num

# use_xm
if [[ "$use_xm" == "1" ]]
then
    echo "===Starting with use_xm TRUE==="
    export USE_XM=1
fi

# accuflow_max_number
if [[ "$accuflow_max_number" != "" ]]
then
    export ACCUFLOW_MAX_NUMBER="$accuflow_max_number"
    echo "Maximum number of accumulated counter-sets is set to $accuflow_max_number"
fi

# max_bridge
if [[ "$max_bridge" != "" ]]
then
    echo "max_bridge = $max_bridge"
    export MAX_BRIDGE_NUM=$max_bridge
fi

# max_port_router
if [[ "$max_port_router" != "" ]]
then
    echo "max_port_router = $max_port_router"
    export MAX_PORT_ROUTER_INTERFACE_NUM=$max_port_router
fi

# module_support_disable
if [[ "${module_support_disable}" == "1" ]]
then
    export MODULE_SUPPORT_DISABLE=1
    echo "Module support in SDK is disabled"
fi

# asan
if [[ "$asan" == "1" ]]
then
    echo "===Starting SDK under address sanitizer==="
    echo "Using ASAN options: $asan_options"
    echo "Using LSAN options: $lsan_options"
    echo "For any application using SDK, please export ASAN_OPTIONS and LSAN_OPTIONS environment variables with above options"
    export ASAN_OPTIONS=$asan_options LSAN_OPTIONS=$lsan_options
fi

if [[ "$disable_health_check" == "1" ]]
then
    export DISABLE_HEALTH_CHECK=1
fi

if [[ "$do_not_init_with_port_profile" == "1" ]]
then
    export DO_NOT_INIT_WITH_PORT_PROFILE=1
fi

# GET SYSTEM TYPE AND INIT RESOURCES

system_type=$($dir/pld_get_system_type.sh --mode=$start_mode --pld_system=$pld_system)
system_type_script_return=$?

if [ "$system_type_script_return" != 0 ]
then
    echo "$system_type"
    exit $system_type_script_return
fi

if [[ "$bist" == "1" ]]
then
    echo "=== SDK Loaded - Starting Built-In-Self-Test ==="
    if ! sx_sdk_built_in_self_test; then               # Should be in usr PATH as installed binary
        echo "SDK Built-In-Self-Test FAILED"
        exit 1
    fi
    echo "=== SDK Built-In-Self-Test PASSED ==="
fi

if [[ "$syslog" != "" ]]
then
    export SDK_SYSLOG=$syslog
    echo "SDK syslog is enabled"
fi

if [[ "$load_spice" == "1" ]]
then
    export SPICE=1
    echo "SPICE is enabled"
else
    export SPICE=0
fi

if [[ "$port_state_down_mode" == "1" ]]
then
    echo "===Starting with port_state_down_mode TRUE==="
    export PORT_STATE_DOWN_MODE=1
fi

if [[ "$port_speed_rate_mode" == "DEFAULT" || "$port_speed_rate_mode" == "SPEED"  || "$port_speed_rate_mode" == "RATE" ]]
then
    echo "===Starting with port_speed_rate_mode ${port_speed_rate_mode}==="
    export PORT_SPEED_RATE_MODE=${port_speed_rate_mode}
else
    echo "Error: invalid port_speed_rate_mode: ${port_speed_rate_mode}. Valid modes are DEFAULT, SPEED and RATE "
    exit 1
fi

# RUN START SCRIPT

echo "$system_type"| while read data; do
    echo $data
    if [[ $data = *start.sh ]]; then
        start_script=${data#*:}
        sleep 4
        eval $start_script $bridge_mode $max_vlan $acl_search_type
        exit $?
    fi
done

if [[ "$asan" == "1" ]]
then
    echo "=== SDK Started under address sanitizer ==="
    echo "For any application using SDK, please export ASAN_OPTIONS=$asan_options"
fi
# Increase timeout to 10 minutes in order not to fail on long config profile
echo 600 > /proc/sys/kernel/hung_task_timeout_secs

rc=$?
echo "*** PLD DVS Start finished with rc ${rc} ***"
exit $rc
