#!/bin/bash
#
 # Copyright (C) 2008-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


usage()
{
	echo "Script prints the following data:"
	echo "1) system type"
	echo "2) fw version"
	echo "3) OPN number"
	echo "4) which start script to use"
	echo "5) which xml configuration file will be used when running the start script"

    echo "Usage: $0 --mode=<start mode> "
    echo "<start mode> options are: "
    echo "1) for vpi system - eth|vpi|ib "
    echo "2) for eth system - eth"

	echo "When mode flag is not given the mode of the sdk package installed on switch is used"
}

start_mode=""

while [ "`echo $1 | cut -c1`" = "-" ]
do
    flag=${1%=*}
    param=${1#*=}
    case "$flag" in
        -h | --help)
           usage
           exit 0
            ;;
        --mode)
            start_mode=$param
            shift 1
            ;;
        *)
            usage
            exit 1
            ;;
esac
done


mst restart

is_sdk_up=`pidof sx_sdk`
if [ "$is_sdk_up" == "" ]; then
	${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel start; sleep 2
	if [ "$start_mode" != "eth" ] && [ -f /etc/init.d/openibd ]; then
		/etc/init.d/openibd start; sleep 2
		run_resources.sh vpi-single dvk
	else
		run_resources.sh eth-single dvk	
	fi
fi 

system_type="panther"
system_mode="eth"
system_id="spectrum2_sim"
part_number="spectrum2_sim"

if [ "$start_mode" ==  "" ]
then
	start_mode=$(sx_sdk --version | cut -d ' ' -f 2 | tr '[:upper:]' '[:lower:]')
fi	

if [ "$system_mode" == "eth" ] && [ "$start_mode" != "eth" ]
then
	echo "-E- System mode is ETH, can't use "$start_mode" mode"
	exit 1
fi

if [ "$system_mode" == "ib" ] && [ "$start_mode" == "eth" ]
then
       echo "-E- System mode is IB, can't use "$start_mode" mode"
       exit 1
fi
	

if [ "evb" == "$system_id" ]
then
	system="Development kit"
else
	system="Development system"
fi

echo "-I- system type is: "$system $system_type $system_mode

fw_version=`flint -d mlnxsw-255 -qq q | grep -i fw`

echo "-I- OPN is: "$part_number

echo "-I- "$fw_version

if [ "$start_mode" == "eth" ] && [ "$system_mode" != "eth" ]
then
	use_system_id=$eth_system_id
else
	use_system_id=$system_id
fi

echo "-I- xml configuration file is: dvs_manager_"$start_mode"_"$use_system_id".xml"

echo "-I- start script is: "$use_system_id"_"$start_mode"_start.sh"

if [ "$is_sdk_up" == "" ]; then
	if [ "$start_mode" != "eth" ] && [ -f /etc/init.d/openibd ]; then
		/etc/init.d/openibd stop;
	fi
	${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel stop;
fi


exit 0