#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

# Redirect stderr to stdout for all the commands following
exec > /proc/$$/fd/1
exec 2>&1

me=$(basename "$0")
dump_dir="sdkdump_$(date +"%Y%m%d%_H%M%S")"
dump_dir="${dump_dir// /_}"
dump_file=/tmp/${dump_dir}.tar.gz
current_dir="$(pwd)"
mkdir -p /tmp/${dump_dir} || exit 1
cd /tmp/${dump_dir}
mkdir -p ./var/log ./proc/dbg_dump ./proc/sys/vm ./etc

syslog_msg() {
    logger -it "${me}" "${1}"
}

info() {
    echo "`date` ${1}"
}

info_and_syslog() {
    info "${1}"
    syslog_msg "${1}"
}

TIMEOUT="timeout -s SIGKILL"

info_and_syslog "Creating SDK system dump. This may take some time"

if test -z "${SIMX}" && lspci -vv 2> /dev/null | grep -qi simx; then
    SIMX=1
fi

info "Collecting SDK Info"
${TIMEOUT} 5s sx_sdk --info > sx_sdk_info.log 2> /dev/null || info_and_syslog "Querying sx_sdk --info failed"

if test -z "${PLD}" && cat sx_sdk_info.log | grep -i palladium | grep -iq yes; then
    PLD=1
fi

# IRISC Dump will stop IRISCs/IRONs - Set WITH_IRISC Env only if you plan to reset the system following dumps
if test -z "${WITH_IRISC}"; then
    irisc_dump=0
elif test -z "${SIMX}" && test -z "${PLD}"; then  # Even if user asked: Should be only if we're not over SimX/PLD (irrelevant there)
    irisc_dump=1
else
    irisc_dump=0
fi

if grep -qis _debug_ /etc/nvidia-release || test -e /sys/kernel/debug/kmemleak ; then
    DEBUG_KERNEL=1
fi

info_and_syslog "SIMX=${SIMX}, PLD=${PLD}, DEBUG_KERNEL=${DEBUG_KERNEL}, Take IRISC Dump = ${irisc_dump}"

if test -z "${WITH_IRISC}"; then
    info "IRISC Dump will be skipped. To enable - Set env WITH_IRISC (WITH_IRISC=1 prepare_sdk_system_dump.sh)"
fi

if test -z "${PLD}"; then
    info "Collecting sensors (Temperatures, FANs, etc. information)"
    ${TIMEOUT} 30s sensors > sensors.log
fi

info_and_syslog "Collecting /proc/dbg_dump/*"
${TIMEOUT} 60s cp -rf /proc/dbg_dump/* ./proc/dbg_dump/ 2> /dev/null

if test -f /etc/nvidia-release && test -d /var/log/sdk_dbg; then
    info_and_syslog "Collecting sdk_sys_info folder /var/log/sdk_dbg"
    # Exclude fuse related folders:
    # If SDK Is entirely stuck, fuse FS Copy, which is un-interruptible, may get kernel stuck and result in kernel panic
    mkdir -p ./var/log/sdk_dbg && ${TIMEOUT} 60s cp -rf `find /var/log/sdk_dbg/ -maxdepth 1 -mindepth 1 | grep -v fuse` ./var/log/sdk_dbg/
fi

info_and_syslog "Collecting various needed env logs"
info "Collecting system environment variables"
printenv > printenv.log
info "Collection lsmod"
lsmod > lsmod.log
info "Collecting lspci"
lspci > lspci.log
info "Collecting lsof"
${TIMEOUT} 60s lsof -VnPX > lsof.log
info "Collecting ifconfig -a"
ifconfig -a > ifconfig.log
ibidagnet_path=$(which ibdiagnet)
if [ -x "$ibdiagnet_path" ]; then
    info "Collecting ibdiagnet version"
    ibdiagnet --version > ibdiagnet_version.log
fi
opensm_path=$(which opensm)
if [ -x "$opensm_path" ]; then
    info "Collecting opensm version"
    opensm --version > opensm_version.log
fi
info "Collecting MST version"
mst --version > mst_version.log
info "Collecting mlxi2c version"
mlxi2c -v > mlxi2c_version.log
info "Collecting OS Related info from /etc"
\cp -f /etc/issue /etc/os-release /etc/nvidia-release ./etc/
info "Collecting /proc needed files"
\cp -f /proc/meminfo /proc/zoneinfo /proc/slabinfo /proc/vmallocinfo /proc/stat /proc/pagetypeinfo /proc/interrupts ./proc/
\cp -f /proc/sys/vm/overcommit_memory ./proc/sys/vm/
info "Collecting uname -a"
uname -a > uname.log
info "Collecting DVS Start log"
\cp -f /tmp/dvs_start.log dvs_start.log 2> /dev/null
info "Collecting Address Sanitizer Logs"
\cp -f /tmp/asan.log.sx_sdk* . 2> /dev/null
info "Collecting ip rule"
ip rule show > ip_rule.log
info "Collecting ip route"
ip route > ip_route.log
info "Collecting ip route show table all"
ip route show table all > ip_route_table.log
info "Collecting ip address list"
ip address list > ip_adress.log
info "Collecting ip neigh"
ip neigh > ip_neigh.log
info "Collecting free -m"
free -m > free.log
info "Collecting PacketX Failure logs"
mv -fv `find /tmp -maxdepth 1 -iname 'packetx*log'` . 2> /dev/null
info "Collecting process list"
ps -ef > process.log
info "Collecting vmstat"
vmstat > vmstat.log

# get the device, find the longest device that matches /dev/mst/mt*pci_cr0
device=`ls /dev/mst/mt*pci_cr0 | perl -e 'print sort { length($b) <=> length($a) } <>' | head -1`
info_and_syslog "Collecting FW Info from device: ${device})"

if test -z "${PLD}"; then
    ${TIMEOUT} 60s flint -d $device -qq q > fw_info.log && ${TIMEOUT} 60s flint -d $device -qq dc > fw_ini.log    # If quick query fails, so will the the DC
fi

if test -z "${SIMX}" && test -z "${PLD}"; then
    info "Collecting chip revision"
    ${TIMEOUT} 10s mcra $device 0xf0014.16:4 > chip_revision.log

    info "Collecting global system image status"
    ${TIMEOUT} 10s mcra $device 0xa1844 > mcra_0x1844_global_image_status.log
fi

dump_timeout=60
if test -n "${DEBUG_KERNEL}"; then
    dump_timeout=120
elif test -n "${PLD}"; then
    dump_timeout=180
fi

dumps_dir=`pwd`/sdk_debug_dumps
dumps_dir_ext=${dumps_dir}_ext
mkdir -p ${dumps_dir} ${dumps_dir_ext}
if pgrep sx_sdk &> /dev/null; then
    info_and_syslog "Generating SDK debug dump"
    if test -n "${PLD}"; then   # SW Data Only, Plain text only - To reduce time over PLD. No dev/null redirection - for debug purposes
        ${TIMEOUT} ${dump_timeout}s python3 $(which sx_api_dbg_dump.py) --hw_dump_method none --dump_format plain_text --plain_text_path ${dumps_dir}/sdkdump.txt
    else
        ${TIMEOUT} ${dump_timeout}s python3 $(which sx_api_dbg_dump.py) --json_path ${dumps_dir}/sdkdump.json --plain_text_path ${dumps_dir}/sdkdump.txt > /dev/null
    fi
else
    info "Collecting possible SDK Dumps that were generated to /tmp/"
    \cp -f `find /tmp -maxdepth 1 -iname '*sdkdump*' -not -name "*.*gz" -not -type d` ${dumps_dir} 2> /dev/null
fi

legacy_mstdumps() {
    if test -z "${SIMX}" && test -z "${PLD}"; then
        info_and_syslog "Collecting CR Space dumps using legacy mode (mstdump)"
        # 3 Dumps needed for FW To compare states between dumps
        mkdir -p ./mst_dumps_legacy
        for i in {1..3}; do ${TIMEOUT} ${dump_timeout}s mstdump ${device} > ./mst_dumps_legacy/mstdump${i} || break; done
    fi
}

# Should occur last - Might stop IRISCs / IRONs
dump_script="$(which sx_api_dbg_generate_dump_ext.py)"
if test -n "${PLD}"; then
    info "Palladium: Skip SDK Debug dump ext. execution"
elif which ${dump_script} > /dev/null; then
    info_and_syslog "Generating SDK Debug Dump Ext. (Driver/DPT/Cr-Space/etc.)"
    if ! lsmod | grep -qs sx_core; then
        info_and_syslog "Loading SDK Driver since its down before taking dumps"
        SX_SKIP_RESET=1 /etc/init.d/sxdkernel start
    fi

    if [ "x${irisc_dump}" == "x1" ]; then
        echo "Will collect IR Core dump per user request"
        dump_script="${dump_script} --ircore"
    fi

    if test -z "${SIMX}"; then
        dump_script="${dump_script} --fw_trace --amber"            # FWTrace/AMBER Irrelevant on SimX
    fi

    ext_dump_log="sx_api_dbg_generate_dump_ext.log"
    ${TIMEOUT} 180s python3 ${dump_script} --path $(realpath ${dumps_dir_ext}) --sdk_threads_backtrace 2>&1 | tee ${dumps_dir_ext}/${ext_dump_log}
    ext_dump_rc="${?}"
    if test "${ext_dump_rc}" -ne "0"; then
        info_and_syslog "SDK Debug Dump Ext. failed with RC=${ext_dump_rc} | Check ${ext_dump_log}"
        legacy_mstdumps
    fi
else
    info "Python SDK API Examples is missing (${dump_script} not found)"
    legacy_mstdumps
fi

info_and_syslog "Collecting special debug files (Core dumps, PCAPs, SimX Logs, etc.)"

core_pattern="/tmp/core"
if test -f /proc/sys/kernel/core_pattern; then
    core_pattern=$(head -1 /proc/sys/kernel/core_pattern)
fi

if ls ${core_pattern}* > /dev/null 2>&1; then
    core_file=$(ls -t ${core_pattern}* | head -1)    # Get last dump in case there are few
    info "Collecting SDK Core dump file ${core_file}"
    gzip --keep -c ${core_file} > ./sdk-core-dump.gz
fi

# Add sniffer log to full dump
if test -z "${SX_SNIFFER_TARGET}"; then
    sniffer_log_pattern="/var/log/sdk_dbg/sx_sdk"
else
    sniffer_log_pattern="${SX_SNIFFER_TARGET/".pcap"/""}"   # Remove .pcap in the log file name
fi

if ls ${sniffer_log_pattern}*pcap* > /dev/null 2>&1; then
    info "Collecting SDK sniffer log file ${sniffer_log_pattern}"
    mkdir -p ./api_sniffer_pcaps; \cp -f ${sniffer_log_pattern}*.pcap* ./api_sniffer_pcaps/
fi

# Collect those last, so it'll include relevant debug syslog prints from "logger" execution in this script
if test -n "${SIMX}"; then
    info "Collecting SimX VM Logs"
    mkdir -p ./var/log/libvirt/qemu/ && \cp -f /var/log/libvirt/qemu/*.log ./var/log/libvirt/qemu/ 2> /dev/null
fi

info_and_syslog "Collecting needed dmesg and system logs from /var/log"
dmesg -T > ./var/log/dmesg
\cp -f /var/log/messages /var/log/syslog* /var/log/*.log /var/log/tc_log ./var/log/ 2> /dev/null

cd ..
info "Compressing the dump..."
tar --remove-files -czf ${dump_dir}.tar.gz $dump_dir
cd ${current_dir} > /dev/null
info_and_syslog "SDK system dump file is ready at: ${dump_file}"
