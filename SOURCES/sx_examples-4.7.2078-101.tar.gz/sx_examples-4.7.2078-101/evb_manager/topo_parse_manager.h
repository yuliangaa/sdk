/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef TOPO_MANAGER_H_
#define TOPO_MANAGER_H_

#include <complib/sx_log.h>
#include <sx/sxd/sxd_command_ifc.h>
#include "../utils/utils.h"
#include <complib/sx_xml.h>

#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>

#include <sx/sdk/sx_types.h>

#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_fdb.h>
#include <sx/sdk/sx_api_mstp.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sdk/sx_api_host_ifc.h>

#include <sx/sdk/sx_api_topo.h>
#include <sx/sdk/sx_api_vlan.h>
#include <sx/sdk/sx_api_acl.h>

#include <string.h>
#include <netinet/ether.h>
#include <arpa/inet.h>

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * evb_status_t
 * Enumerated type - Used to provide function return values.
 */
typedef enum topo_status {
    TOPO_STATUS_SUCCESS = 0,
    TOPO_STATUS_ERROR,
    TOPO_STATUS_NO_RESOURCES,
    TOPO_STATUS_NO_MEMORY,
    TOPO_STATUS_MEMORY_ERROR,
    TOPO_STATUS_PARAM_ERROR,
    TOPO_STATUS_PARAM_NULL,
    TOPO_STATUS_PARSE_ERROR,
    TOPO_STATUS_SDK_ERROR,
    TOPO_STATUS_PARAM_EXCEED_RANGE,
    TOPO_STATUS_MIN = TOPO_STATUS_SUCCESS,
    TOPO_STATUS_MAX = TOPO_STATUS_PARAM_EXCEED_RANGE
} topo_status_t;


#define TOPO_STATUS_CHECK_RANGE(STATUS) (TOPO_STATUS_MIN <= (int)STATUS && TOPO_STATUS_MAX >= STATUS)
/**
 * Macro is used to test if status isn't success.
 */
#ifndef TOP_CHECK_FAIL
#define TOPO_CHECK_FAIL(STATUS) (TOPO_STATUS_SUCCESS != (STATUS))
#endif  /*	TOPO_CHECK_FAIL	*/

#define MAX_NUM_OF_DEVICES 54

/************************************************
 *  FUNC definitions
 ***********************************************/
topo_status_t topo_xml_params_initialize();
topo_status_t topo_sdk_self_init_initialize();
topo_status_t topo_xml_params_get();
topo_status_t topo_device_params_get_from_parse_db(sx_topolib_dev_info_t* dev_info);
topo_status_t topo_tree_params_get_from_parse_db(char              * device_arr,
                                                 char                device_cnt,
                                                 sx_topo_lib_tree_t* tree_info,
                                                 char              * tree_cnt,
                                                 unsigned int        dev_id);
void topo_print_device_info(sx_topolib_dev_info_t* dev_info, int num_dev);
void topo_print_tree_info(sx_topo_lib_tree_t* tree_info, int num_tree);
void topo_tree_free_mem(sx_topo_lib_tree_t* tree_info, char tree_num);

topo_status_t __topo_eth_device_params_get();
topo_status_t __parse_tree_count_section(int *device_count_p);
topo_status_t __parse_eth_tree_params_section(sx_topo_lib_tree_t *tree_p, sx_xml_element_t *child_p);
topo_status_t __parse_eth_tree_neigh_params_section(sx_tree_neigh_t *tree_neigh_p, sx_xml_element_t *child_p);
topo_status_t __parse_eth_tree_node_params_section(sx_tree_node_t *tree_node_p, sx_xml_element_t *child_p);
topo_status_t __eth_tree_params_get();
topo_status_t __eth_device_params_get();
topo_status_t __topo_eth_device_db_free();

#endif /* EVB_MANAGER_H_ */
