#!/bin/bash
#
# Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
# (the "Company") and all right, title, and interest in and to the software product,
# including all associated intellectual property rights, are and shall
# remain exclusively with the Company.
#
# This software product is governed by the End User License Agreement
# provided with the software product.
#

# Default parameter string
dvs_start_param_str=""

# Default values for flags
pcap_source_dvs_os_default_params=" "
pcap_source_nos_default_params=" --use_legacy_init_flow --syslog=0 --boot_mode=DISABLED "

# Help message
function show_help {
    echo ""
    echo "Usage: sx_player_start.sh [[Common options] [DVS options]] 'sx_player options'"
    echo ""
    echo "Note:"
	echo "1. This script starts the SDK process only if it is not running already."
    echo "2.'sx_player options' are mandatory, please use the flag '--player_help' to learn more."
    echo "2. Common and DVS options are optional, but if given, they should come before the 'sx_player options'."
    echo "3. If no DVS option is given, the script will behave like it was given --pcap_source=DVS_OS."
    echo ""
    echo ""
    echo "Common options:"
    echo "  --print_args [options]      Show the options received by the script"
    echo "  --help                      Show the help message of this script"
    echo ""
    echo "DVS options:"
    echo "  --pcap_source=VALUE         Set the source of the pcap file."
    echo "                              The VALUE can be either 'DVS_OS','CL','SONIC' or 'Unknown'."
    echo "                              This option will modify the dvs_start.sh defaults accordingly to"
    echo "                              make possible re-playing the given pcap file."
    echo "                              Note:"
    echo "                              This option is mutually exlusive with the rest of the options."
    echo "                              The user should use either this option or any combination of"
    echo "                              the options below."
    echo "  --use_legacy_init_flow      Pass the "--use_legacy_init_flow" flag to the dvs_start.sh"
    echo "  --syslog=VALUE              Pass the "--syslog=VALUE" flag to the dvs_start.sh"
    echo "  --boot_mode=VALUE           Pass the "--boot_mode=VALUE" flag to the dvs_start.sh"
    echo ""
    echo "sx_player options:"
    echo "  --player_help               Show the help message of the sx player - the options that can be"
    echo "                              passed to the sx player through this script as 'sx_player options'"
    echo ""
}

# Parse DVS options
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --help)
            show_help
            exit 0
            ;;
        --print_args)
            echo "Received parameters: $@"
            show_help
            exit 0
            ;;
        --pcap_source=*)
            pcap_source_value="${1#*=}"
            if [[ "$pcap_source_value" == "DVS_OS" ]]; then
                dvs_start_param_str="$pcap_source_dvs_os_default_params"
            elif [[ "$pcap_source_value" == "CL" || "$pcap_source_value" == "SONIC" || "$pcap_source_value" == "Unknown" ]]; then
                dvs_start_param_str="$pcap_source_nos_default_params"
            else
                echo "Invalid value for --pcap_source. Use either 'DVS_OS','CL','SONIC' or 'Unknown'."
                show_help
                exit 1
            fi

            echo "Note: --pcap_source is set. Other flags will be ignored."
            # shift is included on purpose
            shift
            break
            ;;
        --use_legacy_init_flow)
            dvs_start_param_str+=" --use_legacy_init_flow "
            ;;
        --syslog=*)
            syslog_value="${1#*=}"
            dvs_start_param_str+=" --syslog=$syslog_value "
            ;;
        --boot_mode=*)
            boot_mode_value="${1#*=}"
            dvs_start_param_str+=" --boot_mode=$boot_mode_value "
            ;;
        *)
            # Do not fail the rest of the options will be passed to the sx_player at the end
            echo "sx_player options: $@"
            # shift is omitted on purpose
            break
            ;;
    esac
    shift
done


# Check sx_player options
if [[ "$@" == *"--player_help"* ]] || [[ "x$@" == "x" ]]; then
    echo ""
    echo "sx_player_start.sh runs:"
    echo "    sx_player --help"
    echo ""
    sx_player --help
    exit;
fi

# Start SDK process only of not already running.
pidof sx_sdk > /dev/null
if [ "$?" == "1" ]; then
    # Print the constructed parameter string
    echo ""
    echo "sx_player_start.sh runs:"
    echo "    evb_skip_init=1 dvs_start.sh $dvs_start_param_str"
    echo ""
    evb_skip_init=1 dvs_start.sh $dvs_start_param_str
fi

# Run the player with the provided params.
echo ""
echo "sx_player_start.sh runs:"
echo "    sx_player $@"
echo ""
sx_player $@