/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "topo_parse_manager.h"
#include "evb_manager.h"

#undef  __MODULE__
#define __MODULE__ TOPO_MANAGER_EXAMPLE


/*****************************************************************************/
/*			       LOCAL VARIABLES                               */
/*****************************************************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE; /* TOPO MANAGER log verbosity level */
static sx_topolib_dev_info_t *__topo_device_db_p = NULL;      /* Devices Database  */
static sx_topo_lib_tree_t    *__tree_db_p = NULL;         /* trees Database  */
int                           __tree_count = 0; /* Number of Trees in __topo_device_db_p */
char                          topo_xml_db_fl = 0;
char                          device_cnt;
char                          device_arr[MAX_NUM_OF_DEVICES + 1];
short                         tree_arr[MAX_NUM_OF_DEVICES];


/*****************************************************************************/
/*		       LOCAL GENERIC FUNCTIONS IMPLEMENTATION		     */
/*****************************************************************************/
topo_status_t topo_sdk_self_init_initialize()
{
    sx_xml_list_t    *list_head = NULL;  /* XML list object - used to iterate device nodes */
    int               device_index = 0; /* Device index */
    sx_xml_element_t *child_dev_mac_address_p = NULL;
    sx_xml_element_t *child_p = NULL;
    sx_mac_addr_t    *base_mac_addr_p = NULL;
    topo_status_t     topo_rc = TOPO_STATUS_SUCCESS;


    SX_LOG_ENTER();
    if (!topo_xml_db_fl) {
        topo_xml_db_fl = 1;
        __topo_device_db_p = malloc(__device_count * sizeof(sx_topolib_dev_info_t));
        if (!__topo_device_db_p) {
            SX_LOG_ERR("Failed to allocate memory for devices array\n");
            topo_rc = TOPO_STATUS_NO_MEMORY;
            goto out;
        }


        __topo_device_db_p[device_index].node_type = EVB_DEFAULT_NODE_TYPE;
        __topo_device_db_p[device_index].unicast_arr_len = EVB_DEFAULT_XML_TREE_HDL;
        __topo_device_db_p[device_index].dev_id = EVB_DEFAULT_DEVICE_NUMBER;

        list_head = sx_xml_element_shallow_list_by_name_get(sx_xml_tree_root_element_get(__tree_p), "device");
        child_p = sx_xml_element_list_data(list_head);
        child_dev_mac_address_p = sx_xml_element_by_name_get(child_p, "device-mac-address");
        if (child_dev_mac_address_p) {
            base_mac_addr_p = ether_aton(sx_xml_element_content_get(child_dev_mac_address_p));
            if (base_mac_addr_p == NULL) {
                SX_LOG_ERR("Error parsing device mac address, conversion failed\n");
            } else {
                memcpy(&__topo_device_db_p[device_index].switch_mac_addr, base_mac_addr_p, sizeof(sx_mac_addr_t));
            }
        } else {
            memset(&__topo_device_db_p[device_index].switch_mac_addr, 0, sizeof(sx_mac_addr_t));
            SX_LOG_ERR("Error parsing device MAC address\n");
        }
        memset(device_arr, 0, sizeof(device_arr[0]) * (MAX_NUM_OF_DEVICES + 1));
        memset(tree_arr, 0, sizeof(tree_arr[0]) * (MAX_NUM_OF_DEVICES));
    }
out:
    sx_xml_element_shallow_list_free(list_head);
    SX_LOG_EXIT();
    return topo_rc;
}

topo_status_t topo_xml_params_initialize()
{
    topo_status_t topo_rc = TOPO_STATUS_SUCCESS;

    if (!topo_xml_db_fl) {
        topo_xml_db_fl = 1;
        topo_rc = topo_xml_params_get();
        if (TOPO_CHECK_FAIL(topo_rc)) {
            SX_LOG_ERR("Failed in  topo_xml_params_get, error: %d\n", topo_rc);
            return (topo_rc);
        }
        SX_LOG_DBG("#####################\n");
        SX_LOG_DBG("## XML DEVICE INFO ##\n");
        SX_LOG_DBG("#####################\n");
        topo_print_device_info(__topo_device_db_p, __device_count);
        SX_LOG_DBG("#####################\n");
        SX_LOG_DBG("### XML TREE INFO ###\n");
        SX_LOG_DBG("#####################\n");
        topo_print_tree_info(__tree_db_p, __tree_count);

        memset(device_arr, 0, sizeof(device_arr[0]) * (MAX_NUM_OF_DEVICES + 1));
        memset(tree_arr, 0, sizeof(tree_arr[0]) * (MAX_NUM_OF_DEVICES));
    }

    return (topo_rc);
}


topo_status_t topo_xml_params_get()
{
    topo_status_t topo_rc = TOPO_STATUS_SUCCESS;

    /*****************************************************************************/
    /*		               PARSING SECTION				                         */
    /*****************************************************************************/
    SX_LOG_DBG("####### GET TREE ########\n");
    /* Parse Tree configuration */
    topo_rc = __eth_tree_params_get();
    if (TOPO_CHECK_FAIL(topo_rc)) {
        SX_LOG_ERR("Failed in  __eth_tree_params_get, error: %d\n", topo_rc);
        goto out;
    }

    SX_LOG_DBG("####### GET DEVICE ########\n");
    /* Parse Device configuration */
    topo_rc = __topo_eth_device_params_get();
    if (TOPO_CHECK_FAIL(topo_rc)) {
        SX_LOG_ERR("Failed in  __eth_device_params_get, error: %d\n", topo_rc);
        goto out;
    }

out:
    return (topo_rc);
}


/*****************************************************************************/
/*		       XML PARSING FUNCTIONS IMPL			     */
/*****************************************************************************/

topo_status_t __parse_tree_count_section(int *device_count_p)
{
    topo_status_t     topo_rc = TOPO_STATUS_SUCCESS;
    sx_xml_element_t *child_number_of_trees = sx_xml_element_by_name_get(
        sx_xml_tree_root_element_get(__tree_p), "number-of-trees");

    SX_LOG_ENTER();

    if (device_count_p == NULL) {
        topo_rc = TOPO_STATUS_PARAM_NULL;
        goto out;
    }

    if (child_number_of_trees != NULL) {
        device_count_p[0] = atoi(sx_xml_element_content_get(
                                     child_number_of_trees));
    } else {
        SX_LOG_ERR("Error parsing number of trees\n");
        topo_rc = TOPO_STATUS_PARSE_ERROR;
    }

out:
    SX_LOG_EXIT();
    return topo_rc;
}


topo_status_t __parse_eth_tree_params_section(sx_topo_lib_tree_t *tree_p, sx_xml_element_t *child_p)
{
    topo_status_t     topo_rc = TOPO_STATUS_SUCCESS;
    sx_xml_element_t *xml_tree_qos = NULL;
    sx_xml_element_t *xml_mc_root_device = NULL;
    sx_xml_element_t *xml_tree_len = NULL;
    sx_xml_element_t *tree_neigh_list = NULL;
    int               tree_qos = 0, mc_root_device = 0, tree_len = 0;
    sx_tree_neigh_t * tree_neigh_p;
    int               tree_neigh_index = 0;
    sx_xml_list_t    *list = NULL, *list_head = NULL;    /* XML list object - used to iterate device nodes */

    SX_LOG_ENTER();

    if ((tree_p == NULL) || (child_p == NULL)) {
        topo_rc = TOPO_STATUS_PARAM_NULL;
        goto out;
    }

    /*****************************************************************************/
    /*		               PARSING SECTION				     */
    /*****************************************************************************/
    tree_neigh_list = sx_xml_element_by_name_get(child_p, "tree-neigh-list");
    xml_tree_qos = sx_xml_element_by_name_get(child_p, "tree-qos");
    xml_mc_root_device = sx_xml_element_by_name_get(child_p, "mc-root-device");
    xml_tree_len = sx_xml_element_by_name_get(child_p, "tree-len");

    if (xml_tree_len) {
        tree_len = atoi(sx_xml_element_content_get(xml_tree_len));
    }
    if (xml_mc_root_device) {
        mc_root_device = atoi(sx_xml_element_content_get(xml_mc_root_device));
    }
    if (xml_tree_qos) {
        tree_qos = atoi(sx_xml_element_content_get(xml_tree_qos));
    }

    /* allocate memory for tree DB */
    tree_neigh_p = malloc(tree_len * sizeof(sx_tree_neigh_t));
    if (!__tree_db_p) {
        SX_LOG_ERR("Failed to allocate memory for tree neigh array\n");
        goto out;
    }

    tree_p->tree_dev = tree_neigh_p;
    tree_p->mc_root_device = mc_root_device;
    tree_p->tree_len = tree_len;
    tree_p->tree_qos = tree_qos;

    if (tree_neigh_list) {
        /* get the list of Trees from the XML file */
        list_head = sx_xml_element_shallow_list_by_name_get(tree_neigh_list, "tree-neigh");
        list = list_head;
        /* handle each tree */
        while (list != NULL && tree_neigh_index < tree_len) {
            sx_xml_element_t *child_tree_neigh_list = sx_xml_element_list_data(list);

            /*  get tree data - tree parameters */
            topo_rc = __parse_eth_tree_neigh_params_section(&tree_neigh_p[tree_neigh_index], child_tree_neigh_list);
            if (TOPO_CHECK_FAIL(topo_rc)) {
                SX_LOG_ERR("failed to parse tree neigh params , [error: %d] , exit...\n", topo_rc);
                goto out;
            }
            tree_neigh_index++;
            list = sx_xml_element_list_next(list);
        }
    } else {
        SX_LOG_ERR("Error parsing tree neigh list section\n");
        topo_rc = TOPO_STATUS_PARSE_ERROR;
    }

    goto out;

out:
    sx_xml_element_shallow_list_free(list_head);
    SX_LOG_EXIT();
    return topo_rc;
}

topo_status_t __topo_parse_eth_device_params_section(sx_topolib_dev_info_t *device_p,
                                                     sx_xml_element_t      *child_p,
                                                     int                   *dev_state)
{
    topo_status_t     topo_rc = TOPO_STATUS_SUCCESS;
    sx_xml_element_t *xml_dev_id = NULL;
    sx_xml_element_t *xml_dev_state = NULL;
    sx_xml_element_t *xml_node_type = NULL;
    sx_xml_element_t *xml_arr_len = NULL;
    sx_xml_element_t *xml_switch_mac = NULL;
    sx_mac_addr_t    *mac_addr = NULL;
    int               dev_id = 0, node_type = 0, arr_len = 0;

    SX_LOG_ENTER();

    if ((device_p == NULL) || (child_p == NULL)) {
        topo_rc = TOPO_STATUS_PARAM_NULL;
        goto out;
    }

    /*****************************************************************************/
    /*		               PARSING SECTION				     */
    /*****************************************************************************/
    xml_dev_id = sx_xml_element_by_name_get(child_p, "device-number");
    xml_dev_state = sx_xml_element_by_name_get(child_p, "device-state");
    xml_node_type = sx_xml_element_by_name_get(child_p, "node-type");
    xml_arr_len = sx_xml_element_by_name_get(child_p, "tree-handle-num");
    xml_switch_mac = sx_xml_element_by_name_get(child_p, "device-mac-address");

    if (xml_dev_id) {
        dev_id = atoi(sx_xml_element_content_get(xml_dev_id));
    }

    if (xml_dev_state) {
        *dev_state = atoi(sx_xml_element_content_get(xml_dev_state));
    }

    if (xml_node_type) {
        node_type = atoi(sx_xml_element_content_get(xml_node_type));
    }

    if (xml_arr_len) {
        arr_len = atoi(sx_xml_element_content_get(xml_arr_len));
    }

    if (xml_switch_mac) {
        mac_addr = ether_aton(sx_xml_element_content_get(xml_switch_mac));
        if (mac_addr == NULL) {
            SX_LOG_ERR("Error parsing device mac address\n");
        }
    }

    device_p->dev_id = dev_id;
    device_p->node_type = node_type;
    device_p->unicast_arr_len = arr_len;
    if (mac_addr != NULL) {
        memcpy(&(device_p->switch_mac_addr), mac_addr, sizeof(sx_mac_addr_t));
    } else {
        memset(&(device_p->switch_mac_addr), 0, sizeof(sx_mac_addr_t));
    }

out:
    SX_LOG_EXIT();
    return topo_rc;
}


topo_status_t __parse_eth_tree_neigh_params_section(sx_tree_neigh_t *tree_neigh_p, sx_xml_element_t *child_p)
{
    topo_status_t     topo_rc = TOPO_STATUS_SUCCESS;
    sx_xml_element_t *xml_sx_dev_id = NULL;
    sx_xml_element_t *xml_dirty = NULL;
    sx_xml_element_t *xml_len = NULL;
    sx_xml_element_t *tree_node_list = NULL;
    int               sx_dev_id = 0, dirty = 0, len = 0;
    sx_tree_node_t  * tree_node_p;
    int               tree_node_index = 0;
    sx_xml_list_t    *list = NULL, *list_head = NULL;   /* XML list object - used to iterate device nodes */

    SX_LOG_ENTER();

    if ((tree_neigh_p == NULL) || (child_p == NULL)) {
        topo_rc = TOPO_STATUS_PARAM_NULL;
        goto out;
    }

    /*****************************************************************************/
    /*		               PARSING SECTION				     */
    /*****************************************************************************/
    tree_node_list = sx_xml_element_by_name_get(child_p, "tree-node-list");
    xml_sx_dev_id = sx_xml_element_by_name_get(child_p, "device-id");
    xml_dirty = sx_xml_element_by_name_get(child_p, "dirty");
    xml_len = sx_xml_element_by_name_get(child_p, "node-len");

    if (xml_sx_dev_id) {
        sx_dev_id = atoi(sx_xml_element_content_get(xml_sx_dev_id));
    }
    if (xml_dirty) {
        dirty = atoi(sx_xml_element_content_get(xml_dirty));
    }
    if (xml_len) {
        len = atoi(sx_xml_element_content_get(xml_len));
    }

    /* allocate memory for tree DB */
    tree_node_p = malloc(len * sizeof(sx_tree_node_t));
    if (!tree_node_p) {
        SX_LOG_ERR("Failed to allocate memory for tree node array\n");
        goto out;
    }

    tree_neigh_p->neigh = tree_node_p;
    tree_neigh_p->dev_id = sx_dev_id;
    tree_neigh_p->dirty = dirty;
    tree_neigh_p->len = len;

    if (tree_node_list) {
        /* get the list of Trees from the XML file */
        list_head = sx_xml_element_shallow_list_by_name_get(tree_node_list, "tree-node");
        list = list_head;
        /* handle each tree */
        while (list != NULL && tree_node_index < len) {
            sx_xml_element_t *child_tree_node_list = sx_xml_element_list_data(list);

            /*  get tree data - tree parameters */
            topo_rc = __parse_eth_tree_node_params_section(&tree_node_p[tree_node_index], child_tree_node_list);
            if (TOPO_CHECK_FAIL(topo_rc)) {
                SX_LOG_ERR("failed to parse tree node params , [error: %d] , exit...\n", topo_rc);
                goto out;
            }
            tree_node_index++;
            list = sx_xml_element_list_next(list);
        }
    }
    goto out;

out:
    sx_xml_element_shallow_list_free(list_head);
    SX_LOG_EXIT();
    return topo_rc;
}

topo_status_t __parse_eth_tree_node_params_section(sx_tree_node_t *tree_node_p, sx_xml_element_t *child_p)
{
    topo_status_t      topo_rc = TOPO_STATUS_SUCCESS;
    sx_xml_element_t  *xml_peer_dev_id = NULL;
    sx_xml_element_t  *xml_node_len = NULL;
    sx_xml_element_t * local_port_list;
    sx_xml_element_t  *xml_local_port = NULL;
    sx_xml_element_t  *xml_peer_local_port = NULL;
    int                peer_dev_id = 0, node_len = 0;
    sx_xml_list_t     *list = NULL, *list_head = NULL;    /* XML list object - used to iterate device nodes */
    sx_port_phy_id_t * peer_local_port_p;
    sx_port_phy_id_t * local_port_p;
    int                local_ports_index;

    SX_LOG_ENTER();

    if ((tree_node_p == NULL) || (child_p == NULL)) {
        topo_rc = TOPO_STATUS_PARAM_NULL;
        goto out;
    }

    /*****************************************************************************/
    /*		               PARSING SECTION				     */
    /*****************************************************************************/
    local_port_list = sx_xml_element_by_name_get(child_p, "local-ports-list");
    xml_peer_dev_id = sx_xml_element_by_name_get(child_p, "peer-dev-id");
    xml_node_len = sx_xml_element_by_name_get(child_p, "local-port-len");

    if (xml_peer_dev_id) {
        peer_dev_id = atoi(sx_xml_element_content_get(xml_peer_dev_id));
    }
    if (xml_node_len) {
        node_len = atoi(sx_xml_element_content_get(xml_node_len));
    }

    /* allocate memory for tree DB */
    peer_local_port_p = malloc(node_len * sizeof(sx_port_phy_id_t));
    if (!peer_local_port_p) {
        SX_LOG_ERR("Failed to allocate memory for peer local port array\n");
        topo_rc = TOPO_STATUS_PARAM_NULL;
        goto out;
    }
    /* allocate memory for tree DB */
    local_port_p = malloc(node_len * sizeof(sx_port_phy_id_t));
    if (!local_port_p) {
        SX_LOG_ERR("Failed to allocate memory for local port array\n");
        topo_rc = TOPO_STATUS_PARAM_NULL;
        goto out;
    }

    tree_node_p->peer_dev_id = peer_dev_id;
    tree_node_p->len = node_len;
    tree_node_p->peer_local_port = peer_local_port_p;
    tree_node_p->local_port = local_port_p;


    if (local_port_list) {
        /* get the list of nodes ports from the XML file */
        list_head = sx_xml_element_shallow_list_by_name_get(local_port_list, "local-ports");
        list = list_head;
        local_ports_index = 0;
        /* handle each tree */
        while (list != NULL && local_ports_index < node_len) {
            sx_xml_element_t *child_local_ports_list = sx_xml_element_list_data(list);
            xml_peer_local_port = sx_xml_element_by_name_get(child_local_ports_list, "peer-local-port");
            xml_local_port = sx_xml_element_by_name_get(child_local_ports_list, "local-port");

            if (xml_peer_local_port) {
                tree_node_p->peer_local_port[local_ports_index] =
                    atoi(sx_xml_element_content_get(xml_peer_local_port));
            }

            if (xml_local_port) {
                tree_node_p->local_port[local_ports_index] = atoi(sx_xml_element_content_get(xml_local_port));
            }

            local_ports_index++;
            list = sx_xml_element_list_next(list);
        }
    }
    goto out;

out:
    sx_xml_element_shallow_list_free(list_head);
    SX_LOG_EXIT();
    return topo_rc;
}

/*****************************************************************************/
/*		       ETH RELATED FUNCTIONS IMPL		             */
/*****************************************************************************/

topo_status_t __eth_tree_params_get()
{
    topo_status_t  topo_rc = TOPO_STATUS_SUCCESS; /* return value for EVB manager APIs*/
    sx_xml_list_t *list = NULL, *list_head = NULL;    /* XML list object - used to iterate device nodes */
    int            tree_index = 0; /* Tree index */

    /* parse tree count section in the XML file */
    topo_rc = __parse_tree_count_section(&__tree_count);
    if (TOPO_CHECK_FAIL(topo_rc)) {
        SX_LOG_ERR("Failed to fetch number of trees in file , error: %d\n", topo_rc);
        goto out;
    }


    /* allocate memory for tree DB */
    __tree_db_p = malloc(__tree_count * sizeof(sx_topo_lib_tree_t));
    if (!__tree_db_p) {
        SX_LOG_ERR("Failed to allocate memory for tree db struct array\n");
        goto out;
    }

    /* get the list of Trees from the XML file */
    list_head = sx_xml_element_shallow_list_by_name_get(sx_xml_tree_root_element_get(__tree_p), "tree");
    list = list_head;
    /* handle each tree */
    while (list != NULL && tree_index < __tree_count) {
        sx_xml_element_t *child = sx_xml_element_list_data(list);

        /* get tree data - tree parameters */
        topo_rc = __parse_eth_tree_params_section(&__tree_db_p[tree_index], child);
        if (TOPO_CHECK_FAIL(topo_rc)) {
            SX_LOG_ERR("failed to parse tree params , [error: %d] , exit...\n", topo_rc);
            goto out;
        }

        tree_index++;
        list = sx_xml_element_list_next(list);
    }

out:
    sx_xml_element_shallow_list_free(list_head);
    SX_LOG_EXIT();
    return topo_rc;
}

topo_status_t __topo_eth_device_params_get()
{
    topo_status_t  topo_rc = TOPO_STATUS_SUCCESS; /* return value for EVB manager APIs*/
    sx_xml_list_t *list = NULL, *list_head = NULL;    /* XML list object - used to iterate device nodes */
    int            device_index = 0;  /* Device index */

    /* parse device count section in the XML file */
    topo_rc = (topo_status_t)(__parse_device_count_section(&__device_count));
    if (TOPO_CHECK_FAIL(topo_rc)) {
        SX_LOG_ERR("Failed to fetch number of devices in file , error: %d\n", topo_rc);
        goto out;
    }

    SX_LOG_NTC("The XML contains %d devices\n", __device_count);

    /* allocate memory for tree DB */
    __topo_device_db_p = malloc(__device_count * sizeof(sx_topolib_dev_info_t));
    if (!__topo_device_db_p) {
        SX_LOG_ERR("Failed to allocate memory for devices array\n");
        goto out;
    }

    /* get the list of Devices from the XML file */
    list_head = sx_xml_element_shallow_list_by_name_get(sx_xml_tree_root_element_get(__tree_p), "device");
    list = list_head;

    /* handle each tree */
    while (list != NULL && device_index < __device_count) {
        sx_xml_element_t *child = sx_xml_element_list_data(list);
        int               dev_state = 0;

        /* get tree data - device parameters */
        topo_rc = __topo_parse_eth_device_params_section(&__topo_device_db_p[device_index], child, &dev_state);
        if (TOPO_CHECK_FAIL(topo_rc)) {
            SX_LOG_ERR("failed to parse device params , [error: %d] , exit...\n", topo_rc);
            goto out;
        }

        if (dev_state) {
            device_index++;
        }

        list = sx_xml_element_list_next(list);
    }

out:
    sx_xml_element_shallow_list_free(list_head);
    SX_LOG_EXIT();
    return topo_rc;
}


topo_status_t topo_device_params_get_from_parse_db(sx_topolib_dev_info_t* dev_info)
{
    int           i;
    topo_status_t topo_rc = TOPO_STATUS_SUCCESS;

    SX_LOG_ENTER();

    for (i = 0; i < __device_count; i++) {
        if (__topo_device_db_p[i].dev_id == dev_info->dev_id) {
            dev_info->node_type = __topo_device_db_p[i].node_type;
            dev_info->unicast_arr_len = __topo_device_db_p[i].unicast_arr_len;
            memcpy(&dev_info->switch_mac_addr,
                   &__topo_device_db_p[i].switch_mac_addr,
                   sizeof(dev_info->switch_mac_addr));
            SX_LOG_NTC("Found device %u of type %s (%u), switch MAC %#" PRIx64 " in the XML\n",
                       __topo_device_db_p[i].dev_id,
                       sx_dev_node_type_str(dev_info->node_type),
                       dev_info->node_type,
                       SX_MAC_TO_U64(dev_info->switch_mac_addr));
            goto out;
        }
    }

    topo_rc = TOPO_STATUS_ERROR;

out:
    SX_LOG_EXIT();
    return topo_rc;
}


topo_status_t topo_tree_params_get_from_parse_db(char              * device_arr,
                                                 char                device_cnt,
                                                 sx_topo_lib_tree_t* tree_info,
                                                 char              * tree_cnt,
                                                 unsigned int        dev_id)
{
    topo_status_t     topo_rc = TOPO_STATUS_SUCCESS;
    sx_tree_neigh_t * filtered_tree_neigh_p;
    sx_tree_node_t  * filtered_tree_node_p;
    sx_port_phy_id_t* filtered_node_peer_local_port_p;
    sx_port_phy_id_t* filtered_node_local_port_p;
    int               tree_index, neigh_index, node_index, num_dev, peer_num_dev, filter_neigh_index,
                      filter_node_index, i, node_local_port_index, valid_parsed_tree;
    int  local_tree_cnt = 0;
    char part_of_tree_fl;

    UNUSED_PARAM(device_cnt);


    SX_LOG_ENTER();

    SX_LOG_DBG("^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");
    for (i = 0; i < MAX_NUM_OF_DEVICES; i++) {
        if (device_arr[i] == 1) {
            SX_LOG_DBG("device_arr[%d] = %d--> EXIST\n", i, device_arr[i]);
        }
    }
    SX_LOG_DBG("^^^^^^^^^^^^^^^^^^^^^^^^^^^\n");

    /* Get number of matched devices*/
    for (tree_index = 0; tree_index < __tree_count; tree_index++) {
        valid_parsed_tree = 0;
        num_dev = 0;
        for (neigh_index = 0; neigh_index < __tree_db_p[tree_index].tree_len; neigh_index++) {
            /* Check & count if tree device id was added*/
            if (device_arr[__tree_db_p[tree_index].tree_dev[neigh_index].dev_id]) {
                num_dev++;
            }
        }
        /* allocate memory for tree DB */
        filtered_tree_neigh_p = malloc(num_dev * sizeof(sx_tree_neigh_t));
        if (!filtered_tree_neigh_p) {
            SX_LOG_ERR("Failed to allocate memory for tree neigh array\n");
            topo_rc = TOPO_STATUS_MEMORY_ERROR;
            goto out;
        }
        tree_info[local_tree_cnt].tree_dev = filtered_tree_neigh_p;
        tree_info[local_tree_cnt].mc_root_device = __tree_db_p[tree_index].mc_root_device;
        tree_info[local_tree_cnt].tree_qos = __tree_db_p[tree_index].tree_qos;

        filter_neigh_index = 0;
        part_of_tree_fl = 0;
        for (neigh_index = 0; neigh_index < __tree_db_p[tree_index].tree_len; neigh_index++) {
            /* Copy the tree part that contains the added devices */
            if (device_arr[__tree_db_p[tree_index].tree_dev[neigh_index].dev_id]) {
                /* Check if the new added device_id is a part of the current tree */
                if (dev_id == __tree_db_p[tree_index].tree_dev[neigh_index].dev_id) {
                    part_of_tree_fl = 1;
                }

                tree_info[local_tree_cnt].tree_dev[filter_neigh_index].dev_id =
                    __tree_db_p[tree_index].tree_dev[neigh_index].dev_id;
                tree_info[local_tree_cnt].tree_dev[filter_neigh_index].dirty =
                    __tree_db_p[tree_index].tree_dev[neigh_index].dirty;

                peer_num_dev = 0;
                for (node_index = 0; node_index < __tree_db_p[tree_index].tree_dev[neigh_index].len; node_index++) {
                    /* count relevant tree nodes */
                    if (device_arr[__tree_db_p[tree_index].tree_dev[neigh_index].neigh[node_index].peer_dev_id]) {
                        peer_num_dev++;
                    }
                }
                /* Check for at least 2 existed devices*/
                if (peer_num_dev == 0) {
                    continue;
                }
                valid_parsed_tree = 1;

                /* allocate memory for node DB */
                filtered_tree_node_p = malloc(peer_num_dev * sizeof(sx_tree_node_t));
                if (!filtered_tree_node_p) {
                    SX_LOG_ERR("Failed to allocate memory for tree node array\n");
                    topo_rc = TOPO_STATUS_MEMORY_ERROR;
                    goto out;
                }

                tree_info[local_tree_cnt].tree_dev[filter_neigh_index].len = peer_num_dev;
                tree_info[local_tree_cnt].tree_dev[filter_neigh_index].neigh = filtered_tree_node_p;
                filter_node_index = 0;
                for (node_index = 0; node_index < __tree_db_p[tree_index].tree_dev[neigh_index].len; node_index++) {
                    /* count relevant tree nodes */
                    if (device_arr[__tree_db_p[tree_index].tree_dev[neigh_index].neigh[node_index].peer_dev_id]) {
                        tree_info[local_tree_cnt].tree_dev[filter_neigh_index].neigh[filter_node_index].peer_dev_id =
                            __tree_db_p[tree_index].tree_dev[neigh_index].neigh[node_index].peer_dev_id;
                        tree_info[local_tree_cnt].tree_dev[filter_neigh_index].neigh[filter_node_index].len =
                            __tree_db_p[tree_index].tree_dev[neigh_index].neigh[node_index].len;

                        /* allocate memory for filtered node local port DB */
                        filtered_node_peer_local_port_p =
                            malloc(tree_info[local_tree_cnt].tree_dev[filter_neigh_index].neigh[filter_node_index].len *
                                   sizeof(sx_port_phy_id_t));
                        if (!filtered_node_peer_local_port_p) {
                            SX_LOG_ERR("Failed to allocate memory for node peer local portarray\n");
                            topo_rc = TOPO_STATUS_MEMORY_ERROR;
                            goto out;
                        }
                        /* allocate memory for filtered node local port DB */
                        filtered_node_local_port_p =
                            malloc(tree_info[local_tree_cnt].tree_dev[filter_neigh_index].neigh[filter_node_index].len *
                                   sizeof(sx_port_phy_id_t));
                        if (!filtered_node_local_port_p) {
                            /*release filtered_node_peer_local_port_p allocated memory*/
                            free(filtered_node_peer_local_port_p);
                            SX_LOG_ERR("Failed to allocate memory for node local portarray\n");
                            topo_rc = TOPO_STATUS_MEMORY_ERROR;
                            goto out;
                        }

                        tree_info[local_tree_cnt].tree_dev[filter_neigh_index].neigh[filter_node_index].peer_local_port
                            = filtered_node_peer_local_port_p;
                        tree_info[local_tree_cnt].tree_dev[filter_neigh_index].neigh[filter_node_index].local_port =
                            filtered_node_local_port_p;

                        for (node_local_port_index = 0;
                             node_local_port_index <
                             tree_info[local_tree_cnt].tree_dev[filter_neigh_index].neigh[filter_node_index].len;
                             node_local_port_index++) {
                            tree_info[local_tree_cnt].tree_dev[filter_neigh_index].neigh[filter_node_index].local_port[
                                node_local_port_index] =
                                __tree_db_p[tree_index].tree_dev[neigh_index].neigh[filter_node_index].local_port[
                                    node_local_port_index];
                            tree_info[local_tree_cnt].tree_dev[filter_neigh_index].neigh[filter_node_index].
                            peer_local_port[node_local_port_index] =
                                __tree_db_p[tree_index].tree_dev[neigh_index].neigh[filter_node_index].peer_local_port[
                                    node_local_port_index];
                        }
                        filter_node_index++;
                    }
                }
                filter_neigh_index++;
            } /* if(device_arr[__tree_db_p[tree_index].tree[neigh_index].dev_id]) */
        } /* for(neigh_index = 0; neigh_index < __tree_db_p[tree_index].tree_len; neigh_index++)*/

        tree_info[local_tree_cnt].tree_len = filter_neigh_index;
        tree_info[local_tree_cnt].tree_hndl = tree_index + 1;

        /* Count the number of valid parsed trees & Check if the device is a part of the tree*/
        if ((valid_parsed_tree == 1) && (part_of_tree_fl == 1)) {
            local_tree_cnt++;
        }
    } /* for(tree_index = 0; tree_index < __tree_count; tree_index++)*/
    *tree_cnt = local_tree_cnt;
out:

    SX_LOG_EXIT();
    return topo_rc;
}


void topo_print_tree_info(sx_topo_lib_tree_t* tree_info, int num_tree)
{
    int tree_index, neigh_index, node_index, local_ports_index;

    return;

    /* Get number of matched devices*/
    SX_LOG_DBG("*****************\n");
    /* coverity[unreachable] */
    for (tree_index = 0; tree_index < num_tree; tree_index++) {
        SX_LOG_DBG("#########################\n");
        SX_LOG_DBG("tree index = %d\n", tree_index);
        SX_LOG_DBG("mc_root_device = %d\n", tree_info[tree_index].mc_root_device);
        SX_LOG_DBG("tree_hndl = %d\n", tree_info[tree_index].tree_hndl);
        SX_LOG_DBG("tree_len = %d\n", tree_info[tree_index].tree_len);
        SX_LOG_DBG("tree_qos = %d\n", tree_info[tree_index].tree_qos);

        for (neigh_index = 0; neigh_index < tree_info[tree_index].tree_len; neigh_index++) {
            SX_LOG_DBG("+++++++++++++++++++++++++++++++\n");
            SX_LOG_DBG("+++++++++++++++++++++++++++++++\n");
            SX_LOG_DBG("neigh index = %d\n", neigh_index);
            SX_LOG_DBG("dev_id = %d\n", tree_info[tree_index].tree_dev[neigh_index].dev_id);
            SX_LOG_DBG("dirty = %d\n", tree_info[tree_index].tree_dev[neigh_index].dirty);
            SX_LOG_DBG("len = %d\n", tree_info[tree_index].tree_dev[neigh_index].len);
            for (node_index = 0; node_index < tree_info[tree_index].tree_dev[neigh_index].len; node_index++) {
                SX_LOG_DBG("______________________________\n");
                SX_LOG_DBG("node index = %d\n", node_index);
                SX_LOG_DBG("peer_dev_id = %d\n",
                           tree_info[tree_index].tree_dev[neigh_index].neigh[node_index].peer_dev_id);
                SX_LOG_DBG("local port list len = %d\n",
                           tree_info[tree_index].tree_dev[neigh_index].neigh[node_index].len);

                for (local_ports_index = 0;
                     local_ports_index < tree_info[tree_index].tree_dev[neigh_index].neigh[node_index].len;
                     local_ports_index++) {
                    SX_LOG_DBG("..........\n");
                    SX_LOG_DBG("peer_local_port[%d] = %d\n",
                               local_ports_index,
                               tree_info[tree_index].tree_dev[neigh_index].neigh[node_index].peer_local_port[
                                   local_ports_index]);
                    SX_LOG_DBG("local_port[%d] = %d\n",
                               local_ports_index,
                               tree_info[tree_index].tree_dev[neigh_index].neigh[node_index].local_port[
                                   local_ports_index]);
                    SX_LOG_DBG("..........\n");
                }
            }
            SX_LOG_DBG("+++++++++++++++++++++++++++++++\n");
            SX_LOG_DBG("+++++++++++++++++++++++++++++++\n");
        }
    }
}


void topo_print_device_info(sx_topolib_dev_info_t* dev_info, int num_dev)
{
    int i, len_index;

    UNUSED_PARAM(dev_info);
    UNUSED_PARAM(num_dev);
    UNUSED_PARAM(i);
    UNUSED_PARAM(len_index);

    return;
}


void topo_tree_free_mem(sx_topo_lib_tree_t* tree_info, char tree_num)
{
    int tree_index, neigh_index, node_index;

    /* Get number of matched devices*/
    for (tree_index = 0; tree_index < tree_num; tree_index++) {
        for (neigh_index = 0; neigh_index < tree_info[tree_index].tree_len; neigh_index++) {
            for (node_index = 0; node_index < tree_info[tree_index].tree_dev[neigh_index].len; node_index++) {
                /*Free node structs memory*/
                free(tree_info[tree_index].tree_dev[neigh_index].neigh[node_index].peer_local_port);
                free(tree_info[tree_index].tree_dev[neigh_index].neigh[node_index].local_port);
            }
            /*Free node structs memory*/
            free(tree_info[tree_index].tree_dev[neigh_index].neigh);
        }
        /*Free neigh structs memory*/
        free(tree_info[tree_index].tree_dev);
    }
}


topo_status_t __topo_eth_device_db_free()
{
    /* free memory for each device */
    if (__topo_device_db_p) {
        free(__topo_device_db_p);
        __topo_device_db_p = NULL;
    }
    return TOPO_STATUS_SUCCESS;
}
