#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#


usage()
{
    echo "Script prints the following data:"
    echo "  1) system type"
    echo "  2) fw version"
    echo "  3) OPN number"
    echo "  4) which start script to use"
    echo "  5) which xml configuration file will be used when running the start script"
    echo ""
    echo "Usage: $0 --mode=<start mode> --pld_system=<pld_system>"
    echo "<start mode> options are: "
    echo "  1) for vpi system - eth|vpi|ib "
    echo "  2) for eth system - eth"
    echo "When mode flag is not given the mode of the sdk package installed on switch is used"
}

error() {
    echo -e "-E- ${1}"; exit 1
}

# VARIABLES DEFINITION

openibd_started="False"
start_mode=""
system_id=""

dir=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd)

# GET INPUT PARAMETERS

while [ "`echo $1 | cut -c1`" = "-" ]
do
    flag=${1%=*}
    param=${1#*=}

    case "$flag" in
        -h | --help)
            usage
            exit 0
            ;;
        --mode)
            start_mode=$param
            shift 1
            ;;
        --pld_system)
            pld_system=$param
            shift 1
            ;;
        *)
            usage
            exit 1
            ;;
    esac
done

if [ "${start_mode}" == "" ]; then
    lspci_entry=$(lspci | grep Mellanox) || error "Failed to get system type - No PCI Device found"
    if echo "$lspci_entry" | grep -q "Infiniband"; then
        echo "Infiniband controller found"
        start_mode="ib"
    else
        echo "Ethernet controller found"
        start_mode="eth"
    fi
fi


# MST RESTART
mst restart || error "Failed to start MST"


# LOAD DRIVER

# the sx_sdk binary can be ran by another process, i.e. valgrind, therefore `pidof sx_sdk` does not work
is_sdk_up=$(ps -efww | grep bin/sx_sdk | grep -v grep || true)

sdk_driver_load()
{
    if [ "${is_sdk_up}" == "" ]; then
        if [ "${start_mode}" != "eth" ] && [ -f /etc/init.d/openibd ]; then
            /etc/init.d/openibd force-start
            FAST_BOOT=1 ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel start || error "Failed to load driver"
            "${dir}"/run_resources.sh ib-single dvk
            openibd_started="True"
        else
            FAST_BOOT=1 ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel start || error "Failed to load driver"
            "${dir}"/run_resources.sh eth-single dvk
        fi
    else
      echo "SDK Is running - Skip driver load"
    fi
}

sdk_driver_unload()
{
    if [ "${is_sdk_up}" == "" ]; then
        ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel stop || error "Failed to unload driver"
        if [[ ( ${start_mode} != "eth"  && -f /etc/init.d/openibd ) || ${openibd_started} == "True" ]]; then
            /etc/init.d/openibd stop;
        fi
    fi
}

# Must load driver in case it is down - due to run_resources.sh usage. without it, ISSU_FAST Boot mode for example will fail
sdk_driver_load

# GET PLD SYSTEM PARAMETERS

if [ "$pld_system" == "raven" ]
then
    system_type="raven_palladium"
    system_mode="ib"
    system_id="pld"
    start_mode="quantum"
    profile="quantum-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "phoenix" ]
then
    system_type="phoenix_palladium"
    system_mode="eth"
    system_id="spectrum2_pld"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "firebird" ]
then
    system_type="firebird_palladium"
    system_mode="eth"
    system_id="spectrum3_pld"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "firebird_main_tile" ]
then
    system_type="firebird_palladium"
    system_mode="eth"
    system_id="spectrum3_pld_main_tile"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "firebird_main_4ports" ]
then
    system_type="firebird_palladium"
    system_mode="eth"
    system_id="spectrum3_pld_main_4ports"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "blackbird" ]
then
    system_type="blackbird_palladium"
    system_mode="ib"
    system_id="pld"
    start_mode="quantum2"
    profile="quantum2-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "albatross_main_4ports" ]
then
    system_type="albatross_palladium"
    system_mode="eth"
    system_id="spectrum4_pld_main_4ports"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "albatross_moose_low_4x" ]
then
    system_type="albatross_palladium"
    system_mode="eth"
    system_id="spectrum4_pld_moose_low_4x"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "albatross_moose_low_8x" ]
then
    system_type="albatross_palladium"
    system_mode="eth"
    system_id="spectrum4_pld_moose_low_8x"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "albatross_moose_low_4x_bonus" ]
then
    system_type="albatross_palladium"
    system_mode="eth"
    system_id="spectrum4_pld_moose_low_4x_bonus"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "albatross_moose_low_4x_2bonus" ]
then
    system_type="albatross_palladium"
    system_mode="eth"
    system_id="spectrum4_pld_moose_low_4x_2bonus"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "albatross_moose_high_4x" ]
then
    system_type="albatross_palladium"
    system_mode="eth"
    system_id="spectrum4_pld_moose_high_4x"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "albatross_moose_high_8x" ]
then
    system_type="albatross_palladium"
    system_mode="eth"
    system_id="spectrum4_pld_moose_high_8x"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "albatross_moose_cport_red_4x" ]
then
    system_type="albatross_palladium"
    system_mode="eth"
    system_id="spectrum4_pld_moose_cport_red_4x"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "sunbird" ]
then
    system_type="sunbird_palladium"
    system_mode="ib"
    system_id="quantum3_pld"
    start_mode="ib"
    profile="ib-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "flamingo_main_4ports" ]
then
    system_type="flamingo_palladium"
    system_mode="eth"
    system_id="spectrum5_pld_main_4ports"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
elif [ "$pld_system" == "flamingo_main_4ports_2bonus" ]
then
    system_type="flamingo_palladium"
    system_mode="eth"
    system_id="spectrum5_pld_main_4ports_2bonus"
    start_mode="eth"
    profile="eth-single"
    platform_support_fast_boot="0"
else
    echo "-E- failed to get system type"
    echo "-E- unknown system type: $psid"
    exit 1
fi


# PARAMETERS PROCESSING

# start_mode & system_mode
if [ "$start_mode" ==  "" ]
then
    start_mode=$(sx_sdk --version | cut -d ' ' -f 2 | tr '[:upper:]' '[:lower:]')
fi

if [ "$system_mode" == "eth" ] && [ "$start_mode" != "eth" ]
then
    echo "-E- System mode is ETH, can't use "$start_mode" mode"
    exit 1
fi

if [ "$system_mode" == "ib" ] && [ "$start_mode" == "eth" ]
then
    echo "-E- System mode is IB, can't use "$start_mode" mode"
    exit 1
fi

# system_id
if [ "evb" == "$system_id" ]
then
    system="Development kit"
else
    system="Development system"
fi

# use_system_id
if [ "$start_mode" == "eth" ] && [ "$system_mode" != "eth" ]
then
    use_system_id=$eth_system_id
else
    use_system_id=$system_id
fi


# PRINT PLD SYSTEM INFO

echo "-I- system type is: "$system $system_type $system_mode
echo "-I- xml configuration file is: dvs_manager_"$start_mode"_"$use_system_id".xml"
echo "-I- start script is: "$use_system_id"_"$start_mode"_start.sh"

# UNLOAD DRIVER
sdk_driver_unload

exit 0
