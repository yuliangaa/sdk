#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


usage()
{
    echo "The script enables EVB software"

    echo "Usage $0 [--mode] [--sdk_bridge_mode] [--max_vlan] [--rpc_sniffer] [--prm_sniffer] [--sxd_sniffer] [--fast_boot_mode] [--pipeline_latency_size] [--verbosity <v>]"
    echo ""
    echo "mode options: eth|vpi|ib (for vpi systems), eth (for eth systems)"
    echo "sdk_bridge_mode options: 802.1Q|802.1D|HYBRID"
    echo ""
    echo "--mode                          When mode flag is not given the mode of the sdk package installed on switch is used."
    echo "--sdk_bridge_mode               When sdk_bridge_mode flag is not given the bridge mode of the sdk is 802.1Q."
    echo "--max_vlan                      When max_vlan flag is not given or it equals to 0, the max_vlans mode of the sdk is 4096."
    echo "--rpc_sniffer                   When rpc_sniffer flag is not given. sniffer won't be loaded."
    echo "--rpc_sniffer_file_path         When rpc_sniffer_file_path is not given, a path will be given by the system."
    echo "--sxd_sniffer                   When sxd_sniffer flag is not given, sxd_sniffer will not record."
    echo "--sxd_sniffer_file_path         When sxd_sniffer_file_path is not given, default path(/tmp/sxd_recording.bin) will be used."
    echo "--kvd_linear_size               When kvd_linear_size is not given default size will be used"
    echo "--kvd_single_size               When kvd_single_size is not given default size will be used"
    echo "--kvd_double_size               When kvd_double_size is not given default size will be used"
    echo "--prm_sniffer                   When prm_sniffer flag is not given, prm_sniffer will not record."
    echo "--prm_sniffer_file_path         When prm_sniffer_file_path is not given, default path(/tmp/prm_recording.log) will be used."
    echo "--fast_boot                     When fast_boot_mode is not given, default mode = disable."
    echo "--pipeline_latency_size         When mirror_buffer_size is not given, default size = 217 (in cell units)."           
    echo "--verbosity <v>                 When not specified, chassis manager sets SDK verbosity to NOTICE as a default"
    echo "--acl_search_type <type>		  When not specified acl type is serial.{ SERIAL, PARALLEL }"
    echo "--emad_dump <direction> <pcap>  Start emad_dump in the given direction with the given .pcap file. To stop, run emad_dump_stop.sh."
    echo "                                Override SDK log verbosity set by chassis manager:"
    echo "                                  <v> may be 0=NONE,1=ERROR,2=WARNING,3=NOTICE,4=INFO,5=DEBUG,6=FUNCS,7=FRAMES,8=ALL,no=Do not set"
}

start_mode=""
bridge_mode=""
max_vlan="0"
rpc_sniffer=""
sxd_sniffer=""
emad_dump=""
emad_dump_dir=""
emad_dump_pcap=""
sxd_sniffer_file_path=""
rpc_sniffer_file_path=""
acl_search_type="SERIAL"
kvd_linear_size=""
kvd_single_size=""
kvd_double_size=""
pipeline_latency_size=""

while [ "`echo $1 | cut -c1`" = "-" ]
do                 
                                                             
    # Params with no arguments       
    case "$1" in                     
        --rpc_sniffer)               
            rpc_sniffer=1
            shift 1                  
            continue # Skip to next param.
            ;;                            
    esac                                  
                                                                                                            
    # Params with arguments          
    flag=${1%=*}
    param=${1#*=}   
                                      
    case "$flag" in                       
        --sxd_sniffer)
            sxd_sniffer=1
            shift 1
            continue # Skip to next param.
            ;;
    esac
    
    case "$flag" in
        --sxd_sniffer_file_path)
            param=${1#*=}
            sxd_sniffer_file_path=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac
    
    case "$flag" in                       
        --prm_sniffer)
            prm_sniffer=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --emad_dump)
            emad_dump="1"
            shift 1
            param=${1#*=}
            emad_dump_dir=$param
            shift 1
            param=${1#*=}
            emad_dump_pcap=$param
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --fast_boot)
            fast_boot="1"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --prm_sniffer_file_path)
            param=${1#*=}
            prm_sniffer_file_path=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --rpc_sniffer_file_path)
            param=${1#*=}
            rpc_sniffer_file_path=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac
    
    case "$flag" in
        --verbosity)
            shift 1
            param=${1#*=}
            verbosity=$param
            continue # Skip to next param.
            ;;
    esac
   
    case "$flag" in
        --kvd_linear_size)
            param=${1#*=}
            kvd_linear_size=$param
	    shift 1
            continue # Skip to next param.
	    ;;
        --kvd_single_size)
            param=${1#*=}
	    kvd_single_size=$param
            shift 1
            continue # Skip to next param.
	    ;;
        --kvd_double_size)
            param=${1#*=}
	    kvd_double_size=$param
            shift 1
            continue # Skip to next param.
	    ;;
    esac

    case "$flag" in
        --pipeline_latency_size)
            shift 1
            param=${1#*=}
            pipeline_latency_size=$param
            continue # Skip to next param.
            ;;
    esac
     
    case "$flag" in
        -h | --help)
           usage
           exit 0
            ;;
        --mode)
            start_mode=$param
            shift 1
            ;;
        --sdk_bridge_mode)
            bridge_mode=$param
            shift 1
            ;;            
        --max_vlan)
            max_vlan=$param
            shift 1
            ;;
         --acl_search_type)
            acl_search_type=$param
            shift 1
            ;;   
        *)
            usage
            exit 1
            ;;
    esac
done



if [ "$start_mode" != "eth" ] && [ "$start_mode" != "vpi" ] && [ "$start_mode" != "ib" ] && [ "$start_mode" != "" ]
then
    usage
    exit 1
fi    

if [ "$bridge_mode" != "802.1D" ] && [ "$bridge_mode" != "802.1Q" ] && [ "$bridge_mode" != "HYBRID" ] && [ "$bridge_mode" != "" ]
then
    usage
    exit 1
fi  

if [ "$acl_search_type" != "PARALLEL" ] && [ "$acl_search_type" != "SERIAL" ]
then
    usage
    exit 1
fi    
  

if [[ "$rpc_sniffer" != "" ]] && [[ "$rpc_sniffer" != "1" ]]
then
    usage
    exit 1
fi

if [ "$bridge_mode" == "" ]
then
    bridge_mode="802.1Q"
fi

if [[ "$rpc_sniffer" == "1" ]]
then
    export evb_sx_sdk_prefix="$evb_sx_sdk_prefix LD_PRELOAD=\"\$LD_PRELOAD libsxsniffer.so\""
    if [[ "x$rpc_sniffer_file_path" != "x" ]]
    then
        export evb_sx_sdk_prefix="$evb_sx_sdk_prefix SX_SNIFFER_TARGET=\"$rpc_sniffer_file_path\""
    fi
fi

if [[ "$verbosity" != "" ]]
then
    export SDK_VERBOSITY=$verbosity
    echo "SDK log verbosity set to $verbosity"
fi

if [[ "$kvd_linear_size" != "" ]]
then
    export KVD_LINEAR_SIZE=$kvd_linear_size
    echo "The KVD linear size is set to $kvd_linear_size"
fi

if [[ "$kvd_single_size" != "" ]]
then
    export KVD_SINGLE_SIZE=$kvd_single_size
    echo "The KVD single size is set to $kvd_single_size"
fi

if [[ "$kvd_double_size" != "" ]]
then
    export KVD_DOUBLE_SIZE=$kvd_double_size
    echo "The KVD double  size is set to $kvd_double_size"
fi

if [[ "$pipeline_latency_size" != "" ]]
then
    export PIPELINE_LATENCY_SIZE=$pipeline_latency_size
    echo "The pipeline latency size is set to $pipeline_latency_size"
fi

# check if driver is not already up 
lsmod | grep "sx_core" > /dev/null
if [ $? == "0" ]; then
        echo "Error: sx_core driver is running !"
        exit 1
fi

if [[ "$fast_boot" == "1" ]]
then
    export FAST_BOOT=1
else
    export FAST_BOOT=0
fi

system_type=$(spectrum2_sim_get_system_type.sh --mode=$start_mode)
system_type_script_return=$?

if [ "$system_type_script_return" != 0 ]
then
    echo "$system_type"
    exit $system_type_script_return
fi

if [[ "$sxd_sniffer" == "1" ]]
then
    export SXD_SNIFFER="1"
    export SXD_SNIFFER_FILE_PATH="$sxd_sniffer_file_path"
    echo "sxd_sniffer_activated"
fi

if [[ "$prm_sniffer" == "1" ]]
then
    export PRM_SNIFFER="1"
    export PRM_SNIFFER_FILE_PATH="$prm_sniffer_file_path"
    echo "prm_sniffer_activated"
fi

if [[ "$emad_dump" == "1" ]]
then
    export RESET_TRIGGER=0
    export EMAD_DUMP_DIR="$emad_dump_dir"
    export EMAD_DUMP_PCAP_FILE="$emad_dump_pcap"
    echo "EMAD dump is enabled"
else
    export RESET_TRIGGER=1
fi

echo "$system_type"| while read data; do
    echo $data
    if [[ $data = *start.sh ]]; then
        start_script=${data#*:}
        sleep 4
        eval $start_script $bridge_mode $max_vlan $acl_search_type
        exit $?
    fi    
done

exit $?