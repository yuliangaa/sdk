#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

me=$(basename "$0")

# Log executed command with all flags, for debuggability, to a file. Used by dvs_stop + VER.
full_cmd_log=/tmp/multi.asic.dvs.start.cmd.log
echo ${me} ${*} > ${full_cmd_log} 2>&1

error() {
    echo -e "-E- ${1}"; exit 1
}

usage()
{
    echo "The script enables EVB software for multi asic systems - initialize the drivers and sets a docker container per asic with SDK running inside"
    echo "Usage $0 [--is_nvlink] [--additional_mounts=PATH1,PATH2..]"
    echo "--is_nvlink            Configure NVLink switch."
    echo "--additional_mounts    Mount paths inside the containers."
    echo "--boot_mode            When boot_mode is not given, the SDK will start in NORMAL. options: NORMAL, ISSU_NORMAL, ISSU_STARTED"
    echo "--fatal_error_mode     When not specified, mode is disabled. If enabled it logs a backtrace to stderr and kills the SDK process"
    echo "--pdb_port_map_init    When pdb_port_map_init is not given, default is false."
    echo "--log_file             Log each ASIC Docker container dvs_start.sh and SDK Logs to given log file"
    echo "--asan                 When asan flag is provided, SDK will start with address sanitizer support."
}

nvlink="0"
fatal_error_mode=""
additional_mounts_param=""
boot_mode=""
pdb_port_map_init=""
log_file=""
asan=""

while [ "`echo $1 | cut -c1`" = "-" ]
do
    flag="${1%=*}"
    param="${1#*=}"

    case "${flag}" in
        --is_nvlink)
            nvlink="1"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "${flag}" in
        --additional_mounts)
            additional_mounts_param="${param}"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "${flag}" in
        --boot_mode)
            param=${1#*=}
            boot_mode=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "${flag}" in
        --fatal_error_mode)
            fatal_error_mode="--fatal_error_mode"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "${flag}" in
        --pdb_port_map_init)
            pdb_port_map_init="--pdb_port_map_init"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "${flag}" in
        --log_file)
            log_file="${param}"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "${flag}" in
        --asan)
            asan="--asan"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "${flag}" in
        -h | --help)
            usage
            exit 0
            ;;
        *)
            usage
            echo -e "-E- Unrecognized argument: '${flag}'. Check usage info above."
            exit 1
            ;;
    esac

done

if [ "$boot_mode" != "" ] && [ "$boot_mode" != "NORMAL" ] && [ "$boot_mode" != "ISSU_NORMAL" ] && [ "$boot_mode" != "ISSU_STARTED" ]
then
    error "Invalid --boot_mode value '${boot_mode}'. Options: NORMAL/ISSU_NORMAL/ISSU_STARTED"
fi

# User not provided explicit boot mode -> use NORMAL
if test -z "${boot_mode}"; then
    boot_mode="NORMAL"
fi

if [[ "$boot_mode" == "ISSU_STARTED" ]]
then
    export FAST_BOOT=1
else
    export FAST_BOOT=0
fi

echo "boot_mode = $boot_mode"
cat ${full_cmd_log} 2> /dev/null      # Log the multi_asic_dvs_start command to shell/syslog

containers="$(docker ps -a | grep asicd | awk '{print $1;}')"
if test -n "${containers}"; then
    error "Multi ASIC Docker containers '${containers}' already running"
fi

lspci_entry=$(lspci | grep Mellanox) || error "Failed to set device to PCI mapping - No PCI Device found"
dev_id=1
MAPPING=""
while IFS= read -r line; do
    bus=$(echo "${line}" | head -n1 | awk '{print $1;}')
    MAPPING+="${dev_id}@$bus,"
    dev_id=$((dev_id + 1))
done <<< "$lspci_entry"

MAPPING=${MAPPING::-1}
echo "Found $((dev_id - 1)) devices!"
echo "Setting PREDEFINED_DEV_PCI_BUS to be: $MAPPING"
export PREDEFINED_DEV_PCI_BUS=$MAPPING
${SX_SDK_CUSTOM_PREFIX}/etc/init.d/openibd force-start
${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel start

if [ -z "$(docker images -q debian:bookworm-slim 2> /dev/null)" ]; then
    echo "Pulling docker image"
    docker pull debian:bookworm-slim
fi

MST_DEV_PCICONF=$(mst status -v | grep pciconf0 | grep -Ei 'quantum' | head -n1 | awk '{print $2}') || error "Failed to determine chip MST Device"
MST_DEV_PCICONF=${MST_DEV_PCICONF::-1}

for ((i=1;i<$dev_id;i++)); do
    echo "Creating container asicd_$i"

    additional_mounts=""
    IFS=',' read -ra ADDR <<< "$additional_mounts_param"
    for path in "${ADDR[@]}"; do
        additional_mounts+=" -v $path:$path:rw"
    done

    docker_create_command=" docker create -it --name asicd_$i \
                        -v /usr/:/usr/:rw \
                        -v /dev/sxdevs/:/dev/sxdevs/:rw \
                        -v /etc/:/etc/:rw \
                        -v /sbin:/sbin:rw \
                        -v /bin:/bin:rw \
                        -v /opt:/opt:rw \
                        -v /dev/mst:/dev/mst:rw \
                        -v /etc/mft:/etc/mft:ro \
                        -v /dev/infiniband:/dev/infiniband:rw \
                        -v /dev/sxdevs/sxcdev$i:/dev/sxdevs/sxcdev:rw \
                        --ipc=private \
                        -e PREDEFINED_DEV=$i \
                        -v /root/sys_sdk/:/root/sys_sdk/:rw \
                        -v /var/:/var/:rw \
                        -v /lib/modules:/lib/modules:rw \
                        -v /dev/log:/dev/log:rw \
                        -v /auto:/auto:shared \
                        -v ${MST_DEV_PCICONF}$((i - 1)):${MST_DEV_PCICONF}0:rw \
                        ${additional_mounts} \
                        --net=host \
                        --privileged debian:bookworm-slim"

    eval ${docker_create_command}
    echo "Starting container asicd_$i"
    docker start asicd_$i
done

dvs_start_rc=0

for ((i=1;i<$dev_id;i++)); do
    echo "Starting SDK in container asicd_${i}"
    start_cmd="dvs_start.sh ${fatal_error_mode} --boot_mode=${boot_mode} ${pdb_port_map_init} ${asan}"
    if [[ "${nvlink}" == "0" ]]; then
        start_cmd+=" --enable_ib_split_profile"
    fi

    if test -n "${log_file}"; then
        start_cmd+=" >> ${log_file} 2>&1"   # Use append mode in case log exists
    fi

    docker exec asicd_${i} bash -c "${start_cmd}"
    dvs_start_rc=$((dvs_start_rc | $?))
done

exit $dvs_start_rc
