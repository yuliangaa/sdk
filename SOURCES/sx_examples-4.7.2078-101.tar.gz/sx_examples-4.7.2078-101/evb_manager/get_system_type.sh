#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

set -eE

usage()
{
	echo "Script prints the following data:"
	echo "1) system type"
	echo "2) fw version"
	echo "3) OPN number"
	echo "4) PSID"
	echo "5) which start script to use"
	echo "6) which xml configuration file will be used when running the start script"

	echo "Usage: $0 --mode=<start mode> [--xml_init]"
	echo "<start mode> options are: "
	echo "1) for vpi system - eth|vpi|ib "
	echo "2) for eth system - eth"
	echo "--xml_init: Use pre-defined XML Configuration file based init, rather than self init using FW"

	echo "When mode flag is not given the mode of the sdk package installed on switch is used"
}

error() {
    echo -e "-E- ${1}"; exit 1
}

self_init_mode="True"
openibd_started="False"
start_mode=""
system_id=""
modular="False"

dir=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd)

while [ "$(echo "$1" | cut -c1)" = "-" ]
do
	flag=${1%=*}
	param=${1#*=}
	case "$flag" in
		h | --help)
			usage
			exit 0
			;;
		--mode)
			start_mode=$param
			shift 1
			;;
		--skip_flint)
			skip_flint=$param
			shift 1
			;;
		--xml_init)
			self_init_mode="False"
			shift 1
			;;
		*)
			usage
			exit 1
	 		;;
	esac
done

if [ "${start_mode}" == "" ]; then
	lspci_entry=$(lspci | grep Mellanox) || error "Failed to get system type - No PCI Device found"
	if echo "$lspci_entry" | grep -q "Infiniband"; then
	    echo "Infiniband controller found"
			start_mode="ib"
	else
			echo "Ethernet controller found"
			start_mode="eth"
	fi
fi

mst start || error "Failed to start MST"

# the sx_sdk binary can be ran by another process, i.e. valgrind, therefore `pidof sx_sdk` does not work
is_sdk_up=$(ps -efww | grep bin/sx_sdk | grep -v grep || true)

sdk_driver_load()
{
	if [ "${is_sdk_up}" == "" ]; then
		SX_SKIP_RESET=1 ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel start || error "Failed to load driver"
	else
		echo "SDK Is running - Skip driver load"
	fi
}

sdk_driver_unload()
{
	if [ "${is_sdk_up}" == "" ]; then
		${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel stop || error "Failed to unload driver"
	fi
}

# Must load driver in case it is down - due to run_resources.sh usage. without it, ISSU_FAST Boot mode for example will fail
sdk_driver_load

echo "Determining Chip MST Device to use"
device_name=$(mst status -v | grep pciconf0 | grep -Ei 'spectrum|quantum|switchib' | head -n1 | awk '{print $2}') || error "Failed to determine chip MST Device"

echo "Chip MST Device detected: '${device_name}'"


if [[ ! -z "${IB_CHIPSIM_SYSTEM}" ]]; then
    CHIPSIM_SYSTEM="${IB_CHIPSIM_SYSTEM}"
    echo "Running on ChipSim $CHIPSIM_SYSTEM, skipping flint calls!"
    skip_flint="True"
fi

ib_system=""

if [[ "$skip_flint" == "False" ]]; then
    set +eE
    query_dc_passed="True"
    query_device=$(flint -d ${device_name} -qq dc)
    query_device_return=$?
    if [[ "${query_device_return}" -ne 0 ]]; then
        query_dc_passed="False"
        query_device=$(flint -d ${device_name} q full)
        query_device_return=$?
        if [[ "${query_device_return}" -ne 0 ]]; then
            echo -e "-E- failed to get system type, 'flint -d ${device_name} q full' failed:\n${query_device}"
            sdk_driver_unload  # Unload driver in case it was down to begin with prior running this script.
            exit ${query_device_return}
        fi
    fi
    set -eE

    if [[ "${query_dc_passed}" == "True" ]]; then
        psid=$(echo "${query_device}" | grep -i PSID | cut -d ' ' -f 3 | sed -r "s/[^_a-zA-Z0-9]//g") || true
    else
        psid=$(echo "${query_device}" | grep PSID | grep -vi orig | cut -d ':' -f 2 | head -n1 | sed -r "s/[^_a-zA-Z0-9]//g") || true
    fi

    # QTM3 systems have many different PSIDs. Instead of having to update this script
    # every time a new PSID is created, we can just look at the description output of flint for
    # known tokens.
    if [[ ${query_device} == *"NVLink Tray"* ]]; then
        ib_system="Juliet"
    else
        if [[ ${query_device} == *"XDR InfiniBand"* ]]; then
            ib_system="Crocodile"
        fi
    fi
fi

if [ "${psid}" == "MT_2630110033" ] || [ "${psid}" == "MT_2620110033" ] || [ "${psid}" == "MT_2750110033" ] || [ "${psid}" == "MT_2750111033" ] || [ "${psid}" == "MT_2750113033" ] || [ "${psid}" == "MT_0000000032" ] || [ "${psid}" == "MT_0000000127" ] || [ "${psid}" == "MT_0000000033" ]
then
	system_type="panther"
	system_mode="eth"
	system_id="2700"
	part_number="MSN2700-CS2FE"
	start_mode="eth"
elif [ "${psid}" == "MT_0000000214" ] || [ "${psid}" == "MT_0000000198" ] || [ "${psid}" == "MT_0000000199" ] || [ "${psid}" == "MT_0000000201" ] || [ "${psid}" == "CP_0000000005" ]
then
	system_type="anaconda"
	system_mode="eth"
	system_id="3700" # At first phase for Anaconda we will use device XML file
                         # At second phase we will use generic 'device_base' instead of '3700'
	part_number="MSN-3700"
	start_mode="eth"
elif [ "${psid}" == "MT_0000000215" ] || [ "${psid}" == "MT_0000000216" ] || [ "${psid}" == "MT_0000000217" ]
then
	system_type="tigris"
	system_mode="eth"
	system_id="3800" # At first phase for Tigris we will use device XML file
                         # At second phase we will use generic 'device_base' instead of '3800'
	part_number="MSN-3800"
	start_mode="eth"
elif [ "${psid}" == "MT_0000000301" ] || [ "${psid}" == "MT_0000000302" ] || [ "${psid}" == "MT_0000000303" ] || [ "${psid}" == "CP_0000000015" ]
then
	system_type="lionfish"
	system_mode="eth"
	system_id="3420"
	part_number="MSN-3420"
	start_mode="eth"
elif [ "${psid}" == "MT_0000000350" ] || [ "${psid}" == "MT_0000000514" ]
then
	system_type="leopard"
	system_mode="eth"
	system_id="4700" # At first phase for Leopard we will use device XML file
                         # At second phase we will use generic 'device_base' instead of '4700'
	part_number="MSN-4700"
	start_mode="eth"
elif [ "${psid}" == "MT_0000000352" ] || [ "${psid}" == "MT_0000000351" ]
then
	system_type="leopard"
	start_mode="eth"
elif [ "${psid}" == "MT_0000000508" ] || [ "${psid}" == "MT_0000000510" ] || [ "${psid}" == "MT_0000000511" ]
then
	system_type="octopus"
	start_mode="eth"
elif [ "${psid}" == "MT_0000000470" ] || [ "${psid}" == "MT_0000000467" ] || [ "${psid}" == "MT_0000000469" ]
then
	system_type="tigon"
	start_mode="eth"
elif [ "${psid}" == "MT_0000000464" ] || [ "${psid}" == "MT_0000000466" ] || [ "${psid}" == "MT_0000000465" ]
then
	system_type="liger"
	start_mode="eth"
elif [ "${psid}" == "MT_0000000569" ] || [ "${psid}" == "MT_0000000669" ] 
then
	system_type="buffalo"
	system_mode="eth"
	system_id="4800" 
	part_number="MSN-4800"
	start_mode="eth"
	modular="True"
elif [ "${psid}" == "MT_1870110032" ] || [ "${psid}" == "MT_2360110032" ]
then
	system_type="scorpion"
	system_mode="ib"
	system_id="7700"
	start_mode="ib"
	part_number=""
elif [ "${psid}" == "MT_2630110032" ] 
then
	system_type="scorpion2"
	system_mode="ib"
	system_id="7800"
	start_mode="ib"
	part_number=""
elif [ "${psid}" == "MT_2640110032" ]
then
    system_type="scorpion2"
    system_mode="ib"
    system_id="7890"
    start_mode="ib"
    part_number=""
elif [ "${psid}" == "MT_1940110032" ]
then
	system_type="eagle_pld"
	system_mode="ib"
	system_id="eagle_pld"
	start_mode="ib"
	part_number=""
elif [ "${psid}" == "MT_0000000231" ] || [ "${psid}" == "MT_0000000062" ] ||  [ "${psid}" == "MT_0000000243" ] || [ "${psid}" == "MT_0000000063" ]
then
	system_type="jaguar"
	system_mode="ib"
	system_id="8700"
	start_mode="ib"
	part_number=""
elif [ "${psid}" == "MT_0000000848" ] || [ "${psid}" == "MT_0000000577" ] || [ "${psid}" == "MT_0000000836" ] || [ "${psid}" == "MT_0000000865" ] || [ "${CHIPSIM_SYSTEM}" == "blackbird" ] || [ "${psid}" == "MT_0000000579" ]
then
	system_type="gorilla"
	system_mode="ib"
	self_init_mode="True"
elif [ "${psid}" == "MT_0000001072" ]
then
	system_type="surrogate"
	system_mode="ib"
elif [ "${psid}" == "MT_0000001068" ] || [ "${psid}" == "MT_0000001191" ] || [ "${psid}" == "MT_0000001197" ] || [ "${psid}" == "MT_0000001164" ] || [ "${CHIPSIM_SYSTEM}" == "sunbird" ] || [ "${psid}" == "MT_0000001163" ] || [ "${psid}" == "MT_0000001026" ] || [ "${psid}" == "MT_0000001198" ] || [ "${psid}" == "MT_0000001216" ] || [ "${ib_system}" == "Crocodile" ]
then
	system_type="crocodile"
	system_mode="ib"
	start_mode="ib"
elif [ "${psid}" == "MT_0000001185" ] || [ "${psid}" == "MT_0000001184" ] || [ "${psid}" == "MT_0000001142" ] || [ "${psid}" == "MT_0000001141" ] || [ "${psid}" == "MT_0000001160" ] || [ "${psid}" == "MT_0000001161" ] || [ "${ib_system}" == "Juliet" ]
then
	system_type="juliet"
	system_mode="ib"
	start_mode="ib"
elif [ "${psid}" == "MT_0000001218" ] || [ "${psid}" == "MT_0000001073" ] || [ "${psid}" == "MT_0000001071" ] || [ "${psid}" == "MT_0000001027" ] || [ "${psid}" == "MT_0000001053" ] || [ "${psid}" == "MT_0000001219" ]
then
	system_type="black_mamba"
	system_mode="ib"
	start_mode="ib"
elif [ "${psid}" == "MT_0000000816" ] || [ "${psid}" == "MT_0000000817" ]
then
	system_type="marlin"
	system_mode="ib"
	system_id="9510"
	start_mode="ib"
	part_number=""
elif [ "${psid}" == "MT_2860112033" ] || [ "${psid}" == "MT_2860110033" ] || [ "${psid}" == "MT_2860111033" ] || [ "${psid}" == "MT_0000000047" ] || [ "${psid}" == "MT_0000000042" ] || [ "${psid}" == "CP_0000000002" ] || [ "${psid}" ==  "MT_2860116033" ]
then
	system_type="spider"
	system_mode="eth"
	system_id="2410"
	start_mode="eth"
	part_number="MSN2410"
elif [ "${psid}" == "MT_3000110033" ] || [ "${psid}" == "MT_3000112033" ] || [ "${psid}" == "MT_3000111033" ] || [ "${psid}" == "MT_3000113033" ] || [ "${psid}" == "MT_3000114033" ] || [ "${psid}" == "MT_3000115033" ] || [ "${psid}" == "MT_0000000054" ]
then
	system_type="bulldog"
	system_mode="eth"
	system_id="2100"
	start_mode="eth"
	part_number="MSN2100-CB2FE"
elif [ "${psid}" == "MT_3010110033" ]
then
	system_type="altoline"
	system_mode="eth"
	system_id="7400"
	start_mode="eth"
	part_number="MSN-AS7400-32X"
elif [ "${psid}" == "BAI2830110033" ]
then
	system_type="Aurora"
	system_mode="eth"
	system_id="2420"
	start_mode="eth"
	part_number="MSN2420-CB2RB"
elif [ "${psid}" == "MT_2900110033" ] || [ "${psid}" == "MT_2890111033" ] || [ "${psid}" == "MT_0000000066" ] || [ "${psid}" == "MT_2890110033" ] || [ "${psid}" == "MT_0000000116" ] || [ "${psid}" == "CP_0000000003" ]
then
	system_type="panther_sf"
	system_mode="eth"
	system_id="2740"
	start_mode="eth"
	part_number="MSN2740"
elif [ "${psid}" == "MT_0000000143" ] || [ "${psid}" == "MT_0000000144" ] || [ "${psid}" == "MT_0000000108" ]
then
	system_type="boxer"
	system_mode="eth"
	system_id="2010"
	start_mode="eth"
	part_number="MSN2010"
elif [ "${self_init_mode}" == "False" ]
then
  error "System PSID ${psid} does not have predefined XML Configuration, cannot use XML Based init"
else
	# PSID not found, trying to boot the system in self-init mode
	start_mode="eth"
fi

if [ "${start_mode}" ==  "" ]
then
	start_mode=$(sx_sdk --version | grep "SX-SDK" | cut -d ' ' -f 2 | tr '[:upper:]' '[:lower:]')
fi

if [ "${self_init_mode}" ==  "True" ]
then
	system_id="device_base"
	system_mode=${start_mode}
	system_type=$(echo "${query_device}" | grep board_name | tr -d ' ' | cut -d '=' -f 2 | tr '[:upper:]' '[:lower:]')
	if [[ "${query_dc_passed}" == "True" ]]; then
	    part_number=$(echo "${query_device}" | grep -i -A1 ps_info | grep -i name | tr -d ' ' | cut -d '=' -f2)
	else
	    part_number=$(echo "${query_device}" | grep -i "Part number" | tr -d ' ' | cut -d ':' -f2)
	fi
fi

if [ "${system_mode}" == "eth" ] && [ "${start_mode}" != "eth" ]; then
	error "System mode is ETH, can't use ${start_mode} mode"
fi

if [ "${system_mode}" == "ib" ] && [ "${start_mode}" == "eth" ]; then
	error "System mode is IB, can't use ${start_mode} mode"
fi

system="Development system"

if [ "${start_mode}" == "eth" ] && [ "${system_mode}" != "eth" ]; then
	use_system_id=${eth_system_id}
else
	use_system_id=${system_id}
fi

if [[ "$skip_flint" == "False" ]]; then
     set +eE
     quick_query_device=$(flint -d ${device_name} -qq q)
     quick_query_device_return=$?
     if [[ "${quick_query_device_return}" -ne 0 ]]; then
     	echo -e "-E- failed to get system type, 'flint -d ${device_name} -qq q' failed:\n${quick_query_device}"
     	sdk_driver_unload  # Unload driver in case it was down to begin with prior running this script.
     	exit ${quick_query_device_return}
     fi
     set -eE

     fw_version=$(echo "${quick_query_device}" | grep -i 'fw version' | tr -s ' ') || true
     fw_release_date=$(echo "${quick_query_device}" | grep -i 'fw release date' | tr -s ' ') || true
fi

echo "-I- system type is: ${system} ${system_type} ${system_mode}"
echo "-I- OPN is: ${part_number}"
if ! [ -z "${fw_version}" ]; then
    echo "-I- ${fw_version}"
fi
if ! [ -z "${fw_release_date}" ]; then
    echo "-I- ${fw_release_date}"
fi
if ! [ -z "${psid}" ]; then
	echo "-I- PSID: ${psid}"
fi

if [ "${modular}" ==  "True" ]
then
    echo "-I- xml configuration file is: dvs_manager_${start_mode}_device_base.xml"
else
    echo "-I- xml configuration file is: dvs_manager_${start_mode}_${use_system_id}.xml"
fi

if [ "${self_init_mode}" ==  "True" ]
then
    echo "-I- Init method is: self init using FW Capabilities"
else
    echo "-I- Init method is: pre-defined XML Configuration"
fi

echo "-I- start script is: ${dir}/${use_system_id}_${start_mode}_start.sh"

if [[ -z "${PREDEFINED_DEV}" ]]; then
    sdk_driver_unload  # Unload driver in case it was down to begin with prior running this script.
fi

exit 0
