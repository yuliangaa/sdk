/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef EVB_MANAGER_IB_H_
#define EVB_MANAGER_IB_H_

evb_status_t __evb_ib_port_update_reg_info(port_info_t       *port_info_p,
                                           int                local_port,
                                           struct ku_ptys_reg ptys_reg,
                                           sxd_reg_meta_t     reg_meta);


/**
 * handle IB configuration : open handle to command interface and configure the
 * SDK as per the default values in firmware
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
evb_status_t __evb_sdk_self_init_handle_ib();

/**
 * Parse device properties from the configuration file (IB device section)
 *
 * @param[out]  device_p - fill device with device parameters
 * @param[in]   child_p  - device xml section
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __parse_ib_device_params_section(OUT device_t        *device_p,
                                              IN sx_xml_element_t *child_p);

/**
 * This function creates IB SWIDs in the SDK
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __ib_set_swids(void);


/**
 * handle IB configuration : open handle to command interface and configure the
 * Necessary registers according to the parsed data from the XML file
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
evb_status_t __ib_handle_profile();

/**
 * This function prepare node description string
 *
 * @param[in]   host_name      - host name
 * @param[in]   slot_num      - slot number
 * @param[out]  desc          - description
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __ib_prepare_node_desc(IN const char* host_name,
                                    IN const int   slot_num,
                                    OUT char     * desc);

/**
 * This function sets port state (UP / DOWN)
 *
 * @param[in]   log_port     - logical port number
 * @param[in]   admin_state - port state (UP / DOWN)
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __ib_set_port_state(IN sx_port_log_id_t      log_port,
                                 IN sx_port_admin_state_t admin_state);

/**
 * This function sets port admin capabilities
 *
 * @param[in]   dev_id        - device id
 * @param[in]   port_info_p   - port info object
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __ib_set_port_admin_cap(IN sxd_dev_id_t dev_id,
                                     IN port_info_t *port_info_p);

/**
 * This function sets system GUID for IB system
 *
 * @param[in]   dev_id    - device id
 * @param[in]   sysguid   - system GUID
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __ib_set_node_sysguid(IN sxd_dev_id_t dev_id,
                                   IN uint64_t     sysguid);

/**
 * This function sets node description for IB system
 *
 * @param[in]   dev_id    - device id
 * @param[in]   host_name - host name
 * @param[in]   slot_num  - slot number
 * @param[in]   slot_type - slot type
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
evb_status_t __ib_set_node_ndesc(IN sxd_dev_id_t dev_id,
                                 IN const char * host_name,
                                 IN const int    slot_num,
                                 IN const int    slot_type);


/**
 * This function set the following port mapping (iterate on port list of device_p):
 * 1. Lanes
 * 2. Lane to module
 * to all local ports of device_p
 * @param[in]   device - device object
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __ib_set_port_mapping(IN device_t *device_p);

evb_status_t __ib_evb_sdk_self_init_swids(uint8_t swid_bmap);
evb_status_t __ib_evb_sdk_self_init_swid_ports(OUT device_t *device_p, boolean_t use_2nd_bonus_port);
evb_status_t __ib_evb_sdk_self_init_port(port_info_t *port_info_p, int local_port, sx_swid_t swid);
evb_status_t __ib_evb_sdk_xml_init(void);
evb_status_t __ib_parse_port_info_section(IN sx_xml_element_t *child_p,
                                          OUT port_info_t     *port_info_p);
#endif /* EVB_MANAGER_IB_H_ */
