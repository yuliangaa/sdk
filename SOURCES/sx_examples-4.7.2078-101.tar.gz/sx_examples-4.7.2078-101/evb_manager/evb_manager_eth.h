/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef EVB_MANAGER_ETH_H_
#define EVB_MANAGER_ETH_H_

/**
 * handle ETH configuration : open handle to the SDK and configure it according
 * to the default values configured in the chip registers.
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
evb_status_t __evb_sdk_self_init_handle_eth(boolean_t issu_start,
                                            boolean_t pdb_lag_init,
                                            boolean_t pdb_port_map_init,
                                            uint8_t   fw_fatal_event_mode,
                                            boolean_t port_state_down_mode,
                                            uint8_t   port_speed_rate_mode,
                                            boolean_t disable_health_check,
                                            boolean_t use_2nd_bonus_port);

/*
 * The following function check whether specified speed_bitmap belongs to extended port
 * speed array (which may contains 200Gbps and 400Gbps) and if yes - convert specified
 * speed value into relevant admin_rate set of bits.
 */
evb_status_t __port_rate_convert_bitmap(const sx_port_speed_t   speed_bitmap,
                                        boolean_t              *is_ext_port_speed_p,
                                        sx_port_rate_bitmask_t *admin_rate_p);

evb_status_t __port_speed_convert_bitmap_to_capability(const sx_port_speed_t       speed_bitmap,
                                                       sx_port_speed_capability_t* speed_capability);

/**
 * Parse device properties from the configuration file (ETH device section)
 * @param[out]  device_p - fill device with device parameters
 * @param[in]   child_p  - device xml section
 * @param[in]   static_mac_entries_count_p  - number of mac entries
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __parse_eth_device_params_section(OUT device_t        *device_p,
                                               IN sx_xml_element_t *child_p,
                                               IN int              *static_mac_entries_count_p,
                                               IN boolean_t         issu_start,
                                               IN boolean_t         pdb_port_map_init,
                                               IN boolean_t         use_2nd_bonus_port);


/*****************************************************************************/
/*		       ETH RELATED FUNCTIONS DECLARATIONS	             */
/*****************************************************************************/

/**
 * handle ETH configuration : open handle to the SDK and configure it according
 * to the parsed data from the XML file
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
evb_status_t __eth_handle_profile(boolean_t issu_start,
                                  boolean_t pdb_lag_init,
                                  boolean_t pdb_port_map_init,
                                  uint8_t   fw_fatal_event_mode,
                                  boolean_t port_state_down_mode,
                                  uint8_t   port_speed_rate_mode,
                                  boolean_t disable_health_check,
                                  boolean_t use_2nd_bonus_port);

/**
 * This function creates ETH SWIDs in the SDK
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __eth_set_swids(void);

/**
 * This function set the following port properties (Using the SDK) :
 *
 * 1. port RSTP state
 * 2. port speed
 * 3. port state
 * 4. port default VLAN
 * according to the parsed port info section
 *
 * @param[in]   device - device object
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __eth_set_port_properties(device_t *device_p,
                                       boolean_t issu_start,
                                       boolean_t pdb_lag_init,
                                       boolean_t port_state_down_mode,
                                       uint8_t   port_speed_rate_mode);

/**
 * This function set UC routes to the SDK according to the
 * UC ports section in each device section
 * @param[in]   device - device object
 * @param[in]   static_entries_count - number of MAC entries
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __eth_set_static_mac_entries(IN device_t *device_p,
                                          IN int       static_entries_count);

/**
 * This function sends an ioctl command to driver in order to notify
 * that a new device was added
 * @param[in]   device - device object
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __eth_signal_management_software_new_device(IN const device_t *device_p);

/**
 * This function set the following port mapping (iterate on port list of device_p):
 * 1. Lanes
 * 2. Lane to module
 * to all local ports of device_p
 * @param[in]   device - device object
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __eth_set_port_mapping(IN device_t *device_p, boolean_t issu_start);

/**
 * This function creates .1Q vlans according to the num_of _vlans provided in the cmd_line.
 * @param[in] num_of_active_vlans
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
evb_status_t __eth_set_vlans(IN uint32_t num_of_active_vlans);

evb_status_t __eth_set_fw_fatal_event_mode(sx_dev_id_t dev_id, uint8_t fw_fatal_event_mode);


/**
 * This function translate the logical port into label port
 * @param[in]   log_port   - Logical Port ID
 * @param[out]  label_port - Label Port
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __eth_logical_to_label_port(sx_port_log_id_t log_port,
                                         uint16_t        *label_port);


evb_status_t __parse_eth_device_state_section(IN sx_xml_element_t *child_p);


/**
 * Parse UC routes number field value from the configuration file
 *
 * @param[in]   child_p                - device xml section
 * @param[out]  static_entries_count_p - number of mac entries configured in the a device section
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __parse_fdb_static_mac_count_section(IN sx_xml_element_t *child_p,
                                                  OUT int             *static_entries_count_p);

/**
 * This function parse mac-address-to-log-port
 * @param[in , out]   static_entries_count_p - in : expected entries count (see number-of-static-entries in configuration file)
 *                                             out: actual entries in fdb entries routes section
 * @param[in,out]     static_entries_count_p  -
 * @param[in]         child_p                 - device xml section
 * @param[out]        static_entries_arr      - array of uc mac entries
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __parse_static_fdb_entry_section(INOUT int                        *static_entries_count_p,
                                              IN sx_xml_element_t              *child_p,
                                              OUT sx_fdb_uc_mac_addr_params_t **static_entries_arr);


evb_status_t __eth_evb_sdk_self_init_swids(uint8_t swid_bmap);
evb_status_t __eth_evb_sdk_self_init_swid_ports(OUT device_t *device_p, boolean_t use_2nd_bonus_port);
evb_status_t __eth_evb_sdk_self_init_port(port_info_t *port_info_p, int local_port, sx_swid_t swid);

evb_status_t __eth_evb_sdk_xml_init(boolean_t issu_start,
                                    boolean_t pdb_lag_init,
                                    boolean_t pdb_port_map_init,
                                    uint8_t   fw_fatal_event_mode,
                                    boolean_t port_state_down_mode,
                                    uint8_t   port_speed_rate_mode,
                                    boolean_t disable_health_check,
                                    boolean_t use_2nd_bonus_port);

evb_status_t __eth_parse_port_info_section(IN sx_xml_element_t *child_p,
                                           OUT port_info_t     *port_info_p);
#endif /* EVB_MANAGER_ETH_H_ */
