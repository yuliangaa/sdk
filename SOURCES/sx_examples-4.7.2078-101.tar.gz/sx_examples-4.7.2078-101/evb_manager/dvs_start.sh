#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

me=$(basename "$0")

# Log executed command with all flags, for debuggability, to a file. Used by dvs_stop + VER.
full_cmd_log=/tmp/dvs.start.cmd.log
echo ${me} ${*} > ${full_cmd_log} 2>&1
syslog=1

set -eE

error() {
    echo -e "-E- ${1}"; exit 1
}

usage()
{
    echo "The script enables EVB software"
    echo "Usage $0 [--accuflow_max_number] [--acl_manual_bind] [--acl_search_type] [--asan] [--asan_options] [--bist] [--boot_mode] [--cos_max_buff_mode] \
            [--custom_config_file] [--disable_health_check] [--disable_modular_chassis_init] [--do_not_init_with_port_profile] [--emad_dump] \
            [--emad_timeout] [--enable_chassis_manager_debugger] [--enable_debugger] [--enable_dvs_manager_debugger] [--enable_evb_debugger] \
            [--enable_health_check_log] [--enable_ib_router_profile] [--enable_ib_split_profile] [--enable_rsc_manager_debugger] [--fast_boot] \
            [--fatal_error_mode] [--fdb_async_mode] [--fuse_enable] [--fw_fatal_event_mode] [--hide_deprecation_err] [--i2c_mode] [--ib_chipsim] [--issu_bank] \
            [--kvd_double_size] [--kvd_linear_size] [--kvd_single_size] [--lazy_delete_mode] [--load_spice] [--lsan_options] [--max_bridge] [--max_port_router] \
            [--max_vlan] [--mode] [--module_support_type] [--mst_mode] [--override_default_flood_mode] [--override_default_lag_mode] [--pdb_lag_init] \
            [--pdb_port_map_init] [--pipeline_latency_size] [--port_profiles_num] [--port_profiles_total_memory] [--port_speed_rate_mode] [--port_state_down_mode] \
            [--prm_sniffer] [--restore] [--roaming_mac_notif_en] [--rpc_sniffer] [--sdk_async_mode] [--sdk_bridge_mode] [--sdk_sys_info_path] \
            [--skip_minimal_driver_check] [--skip_reset] [--sxd_sniffer] [--sys_acl_drop_trap_en] [--syslog=<0/1>] [--urmcv6_enable] [--use_2nd_bonus_port] \
            [--use_legacy_init_flow] [--use_sgmii] [--use_xm] [--verbosity=<v>] [--transaction_mode_disable]"
    echo ""
    echo "mode options: eth|vpi|ib (for vpi systems), eth (for eth systems)"
    echo "sdk_bridge_mode options: 802.1Q|802.1D|HYBRID"
    echo "port_profiles_num options: 0-4"
    echo ""
    echo "--accuflow_max_number             Maximum number of accumulated counter-sets. Range: 1..400 (in K (1024) units). The default values is 400."
    echo "--acl_manual_unbind               When not given, default value is false, bound ACLs are automatically removed when removing binding point"
    echo "--acl_search_type <type>          When not specified acl type is serial.{ SERIAL, PARALLEL }"
    echo "--asan                            When asan flag is provided, SDK will start with address sanitizer support."
    echo "--asan_options='<options>'        Address sanitizer options to use when --asan provided. Default are: ${DEFAULT_ASAN_OPTIONS}"
    echo "--bist                            Trigger Built-In-Self-Testing - Simple sanity test for the SDK + Driver, that will execute after SDK Was loaded"
    echo "--boot_mode                       When boot_mode is not given, the SDK will start in FAST Boot (ETH), or regularly (IB). options: NORMAL, FAST, ISSU_NORMAL, ISSU_FAST, ISSU_STARTED"
    echo "--cos_max_buff_mode <mode>        Mode can be {\"GUARANTEED\",\"TOTAL\"}. When not given, default value is GUARANTEED"
    echo "--custom_config_file              When not specified, default config file will be determined according to PSID"
    echo "--disable_health_check            Disable SDK health check mechanism. Default: False (ignored when --fatal_error_mode is enabled)"
    echo "--disable_modular_chassis_init    For Modular systems only, when not specified, modular chassis init happens automatically in modular systems."
    echo "--do_not_init_with_port_profile   When specified, dvs will init all ports without using port profile"
    echo "--emad_dump <direction> <pcap>    Start emad_dump in the given direction with the given .pcap file. To stop, run emad_dump_stop.sh."
    echo "--emad_timeout <usec>             Set custom EMAD Timeout, In micro-seconds (1 Sec = 1000000 uSec). Valid range is [1-4294967295]. When not given, will use SDK Default value of 20 Seconds"
    echo "--enable_chassis_manager_debugger Enable debugger to start chassis manager."
    echo "--enable_debugger                 Enable debugger to start sx_sdk."
    echo "--enable_dvs_manager_debugger     Enable debugger to start dvs manager."
    echo "--enable_evb_debugger             Enable debugger to start all resource, chassis and dvs managers."
    echo "--enable_health_check_log         Enable SDK host interface logs for health check events. Default: disable"
    echo "--enable_ib_router_profile        Configure switch profile with router enable."
    echo "--enable_ib_split_profile         Configure switch profile with split enable."
    echo "--enable_rsc_manager_debugger     Enable debugger to start resource manager."
    echo "--fast_boot                       When fast_boot is not given, default mode = disable."
    echo "--fatal_error_mode                When not specified, mode is disabled. If enabled it logs a backtrace to stderr and kills the SDK process"
    echo "--fdb_async_mode                  When fdb_async_mode is not given, default mode = synced."
    echo "--fuse_enable                     When not specified, mode is disabled. If enabled it runs fuse debug dump."
    echo "--fw_fatal_event_mode             When not specified, mode is FW_NO_CHECK. defines the fw behavior in case of a fatal event. options:FW_NO_CHECK, FW_CONTINUE, FW_HALT"
    echo "--hide_deprecation_err            When not specified, mode is disabled. If enabled it hides deprecation errors for deprecated APIs"
    echo "--i2c_mode                        Enable SDK in I2C mode"
    echo "--ib_chipsim                      IB Chipsim chip name. options: blackbird/sunbird"
    echo "--issu_bank                       When issu_bank is not given, we don't chane the issu_bank. This flag is for debugging purpose, valid values are 0/1"
    echo "--kvd_double_size                 When kvd_double_size is not given default size will be used"
    echo "--kvd_linear_size                 When kvd_linear_size is not given default size will be used"
    echo "--kvd_single_size                 When kvd_single_size is not given default size will be used"
    echo "--lazy_delete_mode                When lazy_delete_mode equals 0 SDK will not use it, otherwise lazy delete is in use."
    echo "--load_spice                      When not specified, default is false"
    echo "--lsan_options='<options>'        Leak sanitizer options to use when --asan provided. Default are: ${DEFAULT_LSAN_OPTIONS}"
    echo "--max_bridge                      When max_bridge flag is not given, it is 512 by default."
    echo "--max_port_router                 When max_port_router flag is not given or it equals to 0, it is 1000(SPC), 4000(SPC2/3), 8000(SPC4), 3000(SPC5)."
    echo "--max_vlan                        When max_vlan flag is not given or it equals to 0, the max_vlans mode of the sdk is 4096."
    echo "--mode                            When mode flag is not given the mode of the sdk package installed on switch is used."
    echo "--module_support_type <type>      When not specified, default is DEPENDENT. Options: DEPENDENT/ENABLED - modules are controlled by FW, INDEPENDENT - modules are controlled by SW, STANDALONE - modules are controlled by SW (with no I2C connectivity)."
    echo "--mst_mode                        Driver is using MST protocol over remote device"
    echo "--override_default_flood_mode     For debug purposes only. When not specified, default flood mode is used."
    echo "--override_default_lag_mode       For debug purposes only. When not specified, default lag mode is used."
    echo "--pdb_lag_init                    When pdb_lag_init is not given, default is false."
    echo "--pdb_port_map_init               When pdb_port_map_init is not given, default is false."
    echo "--pipeline_latency_size           When mirror_buffer_size is not given, default size = 217 (in cell units)."
    echo "--port_profiles_num               When not specified, 2 port profiles are used."
    echo "--port_profiles_total_memory      Size of memory allocated for port profile in 4KB pages. Chosen size should be a power of 2, maximum size is 512. The default values is 64."
    echo "--port_speed_rate_mode            When port_speed_rate_mode is not given, default is DEFAULT. DEFAULT=port_admin_speed on Spectrum and port_rate on Spectrum-2 and above, SPEED=port_admin_speed, RATE=port_rate"
    echo "--port_state_down_mode            When port_state_down_mode is not given, default is false. if given all the ports state will be down"
    echo "--prm_sniffer                     When prm_sniffer flag is not given, prm_sniffer will not record."
    echo "--restore                         When restore flag is given, sdk will be restored and the other options will be ignored."
    echo "--roaming_mac_notif_en            When roaming_mac_notif_en equals 0 SDK will not report roaming flag in FDB notification, otherwise roaming flag will be reported."
    echo "--rpc_sniffer                     When rpc_sniffer flag is not given. sniffer won't be loaded."
    echo "                                  Empty value (--rpc_sniffer): Will use SDK Default sniffer log mode (linear)."
    echo "                                  Optionally, user can provide custom sniffer log mode (--rpc_sniffer=cyclic)"
    echo "--sdk_async_mode                  When sdk_async_mode is not given, the SDK will work in sync mode. Options: SYNC,ASYNC_RETURN_STATUS_SUCCESS,ASYNC_RETURN_STATUS_ACCEPTED"
    echo "--sdk_bridge_mode                 When sdk_bridge_mode flag is not given the bridge mode of the sdk is 802.1Q."
    echo "--sdk_sys_info_path               SDK system debug path for storing system information. Default: ${sdk_sys_info_path}"
    echo "--skip_minimal_driver_check       Skip the sanity check for HW-MGMT Minimal driver loading"
    echo "--skip_reset                      Driver will not reset the ASIC when loaded."
    echo "--sxd_sniffer                     When sxd_sniffer flag is not given, sxd_sniffer will not record."
    echo "--sys_acl_drop_trap_en            When not specified, mode is disabled. If enabled SDK starts trapping packets dropped by System ACLs to WJH Q"
    echo "--syslog                          When not specified, enabled by default. If enabled, SDK Process will log messages to syslog instead of stdout, dvs_start/stop will log to syslog and stderr."
    echo "                                  To disable, set '--syslog=0' - SDK Process will log messages to stdout."
    echo "--urmcv6_enable                   When not given, default value is false, URMCV6 vector is BC"
    echo "--use_2nd_bonus_port              On SPC4, use port 258 (2nd bonus port). Default: No"
    echo "--use_legacy_init_flow            When use_legacy_init_flow is not given, default is 0."
    echo "--use_sgmii                       When use_sgmii is not given, default mode = disable."
    echo "--use_xm                          When not specified, default is false"
    echo "--verbosity=<v>                   When not specified, chassis manager sets SDK verbosity to NOTICE(3) as a default"
    echo "                                  <v> may be 0=NONE,1=ERROR,2=WARNING,3=NOTICE,4=INFO,5=DEBUG,6=FUNCS,7=FRAMES,8=ALL,no=Do not set"
    echo "--skip_flint                      skip flint query - temporary workaround for flamingo(spc5) bring up over simx"
    echo "--xml_init                        Use pre-defined XML Configuration file based init, rather than self init using FW"
    echo "--transaction_mode_disable        When not specified, default is transaction mode enable"
}

# VARIABLES DEFINITION
SDK_DATA_PATH="$(cd -- "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P)/../share"
DEFAULT_ASAN_OPTIONS="log_path=/tmp/asan.log:log_exe_name=1:halt_on_error=0:verify_asan_link_order=0:suppressions=${SDK_DATA_PATH}/sx_sdk_asan_ignore.txt:disable_coredump=0"
DEFAULT_LSAN_OPTIONS="suppressions=${SDK_DATA_PATH}/sx_sdk_lsan_ignore.txt:print_suppressions=0"
#sdk_async_mode="ASYNC_RETURN_STATUS_ACCEPTED"
accuflow_max_number="400"
acl_manual_unbind=""
acl_search_type="SERIAL"
asan_options=${DEFAULT_ASAN_OPTIONS}
asan="0"
bist="0"
use_internal_init_flow="1"
boot_mode=""
bridge_mode=""
cos_max_buff_mode_param="GUARANTEED"
custom_config_file=""
disable_modular_chassis_init=""
emad_dump_dir=""
emad_dump_pcap=""
emad_dump=""
emad_timeout=""
fast_boot="0"
fatal_error_mode="0"
fdb_async_mode=""
fw_fatal_event_mode=""
override_default_flood_mode=""
override_default_lag_mode=""
hide_deprecation_err="0"
kvd_double_size=""
kvd_linear_size=""
kvd_single_size=""
lazy_delete="1"
load_spice=""
lsan_options=${DEFAULT_LSAN_OPTIONS}
max_bridge=""
max_port_router=""
max_vlan="0"
module_support_type="dependent"
pdb_lag_init=""
pdb_port_map_init=""
pipeline_latency_size=""
port_profiles_num="2"
port_profiles_total_memory="0"
port_speed_rate_mode="DEFAULT"
port_state_down_mode=""
prm_sniffer=""
restore="0"
roaming_mac_notif_en="1"
rpc_sniffer=""
sdk_async_mode="" # changing to default sync mode.
start_mode=""
sxd_sniffer=""
sys_acl_drop_trap_en="0"
urmcv6_enable=""
use_xm=""
fuse_enable="0"
verbosity=""
issu_bank=""
skip_minimal_driver_check=0
enable_ib_split_profile="0"
enable_ib_router_profile="0"
skip_reset=0
sdk_sys_info_path="/var/log/sdk_dbg"   # Default val. override using --sdk_sys_info_path=/other/path
disable_health_check="0"
enable_health_check_log="0"
use_2nd_bonus_port=0
do_not_init_with_port_profile=0
ib_chipsim=0
skip_flint="False"
transaction_mode_disable=0

while [ "`echo $1 | cut -c1`" = "-" ]
do

    # Params with arguments
    flag=${1%%=*}
    param=${1#*=}

    case "$flag" in
        --rpc_sniffer)
            if [[ "${flag}" == "${param}" ]]; then    # User didn't assign a value: Treat as legacy behavior: Enable RPC Sniffer with SDK Defaults sniffer mode
                rpc_sniffer=1
            else
                rpc_sniffer="${1#*=}"
                rpc_sniffer="$(echo "${rpc_sniffer}" | tr '[:upper:]' '[:lower:]')"   # Convert to lowercase
            fi
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --sxd_sniffer)
            sxd_sniffer=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --prm_sniffer)
            prm_sniffer=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --emad_dump)
            emad_dump="1"
            shift 1
            param=${1#*=}
            emad_dump_dir=$param
            shift 1
            param=${1#*=}
            emad_dump_pcap=$param
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --fuse_enable)
            fuse_enable="1"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --sdk_sys_info_path)
            param=${1#*=}
            sdk_sys_info_path=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
       --disable_health_check)
           disable_health_check="1"
           shift 1
           continue # Skip to next param.
           ;;
    esac
    
    case "$flag" in
       --enable_health_check_log)
           enable_health_check_log="1"
           shift 1
           continue # Skip to next param.
           ;;
    esac
    
    case "$flag" in
        --fast_boot)
            fast_boot="1"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --boot_mode)
            param=${1#*=}
            boot_mode=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --use_legacy_init_flow) # resources-manager
            use_internal_init_flow="0"
            shift 1
            continue # Skip to next param.
            ;;
    esac

        case "$flag" in
        --port_speed_rate_mode)
            param=${1#*=}
            port_speed_rate_mode=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --use_sgmii)
            echo "DVS-OS is unable to work with SGMII"
            exit 1
            ;;
    esac

    case "$flag" in
        --verbosity)
            param=${1#*=}
            verbosity=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --syslog)
            syslog="${1#*=}"
            if [[ "${syslog}" != "0" ]]; then    # User didn't assign a value, or given any value which is not 0 -> Treat as 1
                syslog=1
            fi
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --fw_fatal_event_mode)
            param=${1#*=}
            fw_fatal_event_mode=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --skip_flint)
            skip_flint="True"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --xml_init)
            xml_init="--xml_init"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --kvd_linear_size)
            param=${1#*=}
            kvd_linear_size=$param
	    shift 1
            continue # Skip to next param.
	    ;;
        --kvd_single_size)
            param=${1#*=}
	    kvd_single_size=$param
            shift 1
            continue # Skip to next param.
	    ;;
        --kvd_double_size)
            param=${1#*=}
	    kvd_double_size=$param
            shift 1
            continue # Skip to next param.
	    ;;
    esac

    case "$flag" in
        --fdb_async_mode)
            param=${1#*=}
            fdb_async_mode=$param
	    shift 1
            continue # Skip to next param.
	    ;;
    esac
        case "$flag" in
        --sdk_async_mode)
            param=${1#*=}
            sdk_async_mode=$param
	    shift 1
            continue # Skip to next param.
	    ;;
    esac
    case "$flag" in
        --pipeline_latency_size)
            shift 1
            param=${1#*=}
            pipeline_latency_size=$param
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --restore)
            restore="1"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --acl_manual_unbind)
            acl_manual_unbind="1"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --urmcv6_enable)
            urmcv6_enable="1"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --module_support_type)
            param=${1#*=}
            module_support_type=${param,,}
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --roaming_mac_notif_en)
            roaming_mac_notif_en=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --cos_max_buff_mode)
            param=${1#*=}
            cos_max_buff_mode_param=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --emad_timeout)
            param=${1#*=}
            emad_timeout=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --accuflow_max_number)
            param=${1#*=}
            accuflow_max_number=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --asan)
            asan="1"
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --asan_options)
            param=${1#*=}
            asan_options=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --lsan_options)
            param=${1#*=}
            lsan_options=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_debugger)
            enable_debugger=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --skip_minimal_driver_check)
            skip_minimal_driver_check=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --i2c_mode)
            i2c_mode=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --mst_mode)
            mst_mode=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_ib_split_profile)
            enable_split=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_ib_router_profile)
            enable_router=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --skip_reset)
            skip_reset=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --use_2nd_bonus_port)
            use_2nd_bonus_port=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --do_not_init_with_port_profile)
            do_not_init_with_port_profile=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_rsc_manager_debugger)
            enable_rsc_manager_debugger=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_chassis_manager_debugger)
            enable_chassis_manager_debugger=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_dvs_manager_debugger)
            enable_dvs_manager_debugger=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        --enable_evb_debugger)
            enable_rsc_manager_debugger=1
            enable_chassis_manager_debugger=1
            enable_dvs_manager_debugger=1
            shift 1
            continue # Skip to next param.
            ;;
    esac
    
    case "$flag" in
        --transaction_mode_disable)
            transaction_mode_disable=1
            shift 1
            continue # Skip to next param.
            ;;
    esac
    
    case "$flag" in
        -h | --help)
           usage
           exit 0
            ;;
        --mode)
            start_mode=$param
            shift 1
            ;;
        --sdk_bridge_mode)
            bridge_mode=$param
            shift 1
            ;;
        --max_vlan)
            max_vlan=$param
            shift 1
            ;;
         --lazy_delete_mode)
            lazy_delete=$param
            shift 1
            ;;
         --acl_search_type)
            acl_search_type=$param
            shift 1
            ;;
         --fatal_error_mode)
            fatal_error_mode="1"
            shift 1
            ;;
         --bist)
            bist="1"
            shift 1
            ;;
         --pdb_lag_init)
            echo "pdb_lag_init=1"
            pdb_lag_init="1"
            shift 1
            ;;
         --port_state_down_mode)
            echo "port_state_down_mode=1"
            port_state_down_mode="1"
            shift 1
            ;;
         --pdb_port_map_init)
            echo "pdb_port_map_init=1"
            pdb_port_map_init="1"
            shift 1
            ;;
         --use_xm)
            echo "use_xm=1"
            use_xm="1"
            shift 1
            ;;
         --hide_deprecation_err)
            hide_deprecation_err="1"
            shift 1
            ;;
         --sys_acl_drop_trap_en)
            sys_acl_drop_trap_en="1"
            shift 1
            ;;
         --custom_config_file)
            param=${1#*=}
            custom_config_file=$param
            shift 1
            ;;
         --disable_modular_chassis_init)
            echo "disable_modular_chassis_init=1"
            disable_modular_chassis_init="1"
            shift 1
            ;;
	     --port_profiles_num)
	        port_profiles_num=$param
            shift 1
            ;;
	     --port_profiles_total_memory)
	        port_profiles_total_memory=$param
            shift 1
            ;;
         --override_default_flood_mode)
            override_default_flood_mode="1"
            shift 1
            ;;
         --override_default_lag_mode)
            override_default_lag_mode="1"
            shift 1
            ;;
          --max_bridge)
            max_bridge=$param
            shift 1
            ;;
        --max_port_router)
            max_port_router=$param
            shift 1
            ;;
        --issu_bank)
            issu_bank=$param
            shift 1
            ;;
        --max_lags)
            max_lags=$param
            shift 1
            ;;
        --load_spice)
            echo "load_spice=1"
            load_spice="1"
            shift 1
            ;;
        --ib_chipsim)
            ib_chipsim_system=$param
            shift 1
            ;;
        *)
            usage
            error "Unrecognized argument: '${flag}'. Check usage info above."
            ;;
    esac

done

if [[ "${syslog}" != "0" ]]; then
    exec 1> >(logger --stderr --tag ${me}) 2>&1   # Log script execution to syslog and stderr
fi

echo "*** DVS Start started ***"

cat ${full_cmd_log} 2> /dev/null      # Log the dvs_start command to shell/syslog

echo "Clearing RAM Caches"
sync && timeout 1m echo 3 > /proc/sys/vm/drop_caches || echo "-W- Clearing RAM Caches failed or timed-out after 1m"

if test -z "${start_mode}"; then
    if lspci | grep -s Mellanox | grep -qs "Infiniband"; then
        echo "Infiniband controller found"
        start_mode="ib"
    else
        echo "Ethernet controller found"
        start_mode="eth"
    fi
fi

echo "Start Mode: ${start_mode}"

if [ "$start_mode" != "eth" ] && [ "$start_mode" != "vpi" ] && [ "$start_mode" != "ib" ]
then
    usage
    exit 1
fi

if [ "$bridge_mode" != "802.1D" ] && [ "$bridge_mode" != "802.1Q" ] && [ "$bridge_mode" != "HYBRID" ] && [ "$bridge_mode" != "" ]
then
    usage
    exit 1
fi

if [ "$acl_search_type" != "PARALLEL" ] && [ "$acl_search_type" != "SERIAL" ]
then
    usage
    exit 1
fi

if [[ "$rpc_sniffer" != "" ]] && [[ "$rpc_sniffer" != "1" ]] && [[ "$rpc_sniffer" != "linear" ]] && [[ "$rpc_sniffer" != "cyclic" ]]
then
    error "Invalid --rpc_sniffer value '${rpc_sniffer}'. Options: linear/cyclic"
    exit 1
fi

if [ "$boot_mode" != "" ] && [ "$boot_mode" != "NORMAL" ] && [ "$boot_mode" != "FAST" ] && [ "$boot_mode" != "ISSU_NORMAL" ] && [ "$boot_mode" != "ISSU_FAST" ] && [ "$boot_mode" != "ISSU_STARTED" ] && [ "$boot_mode" != "DISABLED" ]
then
    error "Invalid --boot_mode value '${boot_mode}'. Options: NORMAL/FAST/ISSU_FAST/ISSU_NORMAL/ISSU_STARTED/DISABLED"
fi

if [ "$issu_bank" != "0" ] && [ "$issu_bank" != "1" ] && [ "$issu_bank" != "" ]
then
    error "Invalid --issu_bank value '${issu_bank}'. Options: 0/1"
fi

if [[ "$issu_bank" != "" ]]
then
    echo "Setting ISSU Bank to be ${issu_bank}"
    cat << EOF > /var/issu_bank_v2.json
{
	"bank": $issu_bank
}
EOF

fi


if [ "$fw_fatal_event_mode" != "FW_NO_CHECK" ] && [ "$fw_fatal_event_mode" != "FW_CONTINUE" ] && [ "$fw_fatal_event_mode" != "FW_HALT" ] && [ "$fw_fatal_event_mode" != "" ]
then
    echo "Error: invalid fw_fatal_event_mode: ${fw_fatal_event_mode} "
    exit 1
fi

if [ -n "${custom_config_file}" ] && [ ! -f "${custom_config_file}" ]
then
    echo "Error: custom_config_file ${custom_config_file} does not exist"
    exit 1
fi

if [ "$bridge_mode" == "" ]
then
    bridge_mode="802.1Q"
fi

if [ "$port_profiles_num" == "" ]
then
    port_profiles_num="2"
fi

if [ "$port_profiles_total_memory" == "" ]
then
    port_profiles_total_memory ="0"
fi

if test -n "${rpc_sniffer}"
then
    msg="SDK RPC Sniffer enabled"
    export evb_sx_sdk_prefix="$evb_sx_sdk_prefix LD_PRELOAD=\"\$LD_PRELOAD libsxsniffer.so\""
    if [[ "${rpc_sniffer}" != "1" ]]; then    # Custom sniffer log mode given
        msg+=" with SX_SNIFFER_LOG_MODE=${rpc_sniffer}"
        export SX_SNIFFER_LOG_MODE=${rpc_sniffer}
    fi
    echo "${msg}"
fi

if [[ "$verbosity" != "" ]]
then
    export SDK_VERBOSITY=$verbosity
    echo "SDK log verbosity set to $verbosity"
fi

if [[ "${syslog}" != "0" ]]
then
    export SDK_SYSLOG=1
    echo "SDK syslog is enabled"
fi

if [[ "$kvd_linear_size" != "" ]]
then
    export KVD_LINEAR_SIZE=$kvd_linear_size
    echo "The KVD linear size is set to $kvd_linear_size"
fi

if [[ "$kvd_single_size" != "" ]]
then
    export KVD_SINGLE_SIZE=$kvd_single_size
    echo "The KVD single size is set to $kvd_single_size"
fi

if [[ "$kvd_double_size" != "" ]]
then
    export KVD_DOUBLE_SIZE=$kvd_double_size
    echo "The KVD double  size is set to $kvd_double_size"
fi

if [[ "$fdb_async_mode" != "" ]]
then
    export FDB_ASYNC_MODE=$fdb_async_mode
    echo "The FDB async mode is set to $fdb_async_mode"
fi

if [[ "$sdk_async_mode" != "" ]]
then
    export SDK_ASYNC_MODE=$sdk_async_mode
    echo "The SDK async mode is set to $sdk_async_mode"
fi

if [[ "$pipeline_latency_size" != "" ]]
then
    export PIPELINE_LATENCY_SIZE=$pipeline_latency_size
    echo "The pipeline latency size is set to $pipeline_latency_size"
fi

if [[ "$accuflow_max_number" != "" ]]
then
    export ACCUFLOW_MAX_NUMBER="$accuflow_max_number"
    echo "Maximum number of accumulated counter-sets is set to $accuflow_max_number"
fi

# check if driver is not already up
if [[ -z "${PREDEFINED_DEV}" ]]; then
    if lsmod | grep "sx_core" > /dev/null; then
        error "sx_core driver is running !"
    fi
fi

# User not provided explicit boot mode -> ETH: FAST Boot mode. IB: DISABLED Boot mode
# ETH: Default will be FAST
# IB: Default will be DISABLED
if test -z "${boot_mode}"; then
    if [[ "${start_mode}" == "ib" ]]; then
        boot_mode="DISABLED"
    else                   # Means explicit start_mode != ib given, or no no start_mode given and we detected IB Switch
        boot_mode="FAST"
    fi
fi

echo "boot_mode = $boot_mode"
export BOOT_MODE="$boot_mode"
if [[ "$boot_mode" == "FAST" || "$boot_mode" == "ISSU_FAST" || "$boot_mode" == "ISSU_STARTED" ]] || [[ "$fast_boot" == "1" ]]
then
    export FAST_BOOT=1
else
    export FAST_BOOT=0
fi

modprobe_conf=${SX_SDK_CUSTOM_PREFIX}/etc/modprobe.d/sx.modprobe.conf
carrier_options="options sx_netdev carrier_set_on_pude_disable"
if test -f ${modprobe_conf} && ! grep -qs "${carrier_options}=0" ${modprobe_conf}; then
    echo "=== Setting sx_netdev carrier_set_on_pude_disable=0 ==="
    if grep -qs "${carrier_options}" ${modprobe_conf}; then
        sed -i "s/.*${carrier_options}.*/${carrier_options}=0/g" ${modprobe_conf}
    else
        echo "${carrier_options}=0" >> ${modprobe_conf}
    fi
fi


if [[ "$use_internal_init_flow" == "1" ]]
then
    export USE_INTERNAL_INIT_FLOW=1
else
    export USE_INTERNAL_INIT_FLOW=0
fi

if [[ "$lazy_delete" == "1" ]]
then
    echo "lazy_delete = TRUE"
    export LAZY_DELETE=1
else
    echo "lazy_delete = FALSE"
    export LAZY_DELETE=0
fi

if [[ "$fatal_error_mode" == "1" ]]
then
    echo "===Starting in fatal_error_mode==="
    export FATAL_ERROR_MODE=1
else
    export FATAL_ERROR_MODE=0
fi

if [[ "$override_default_flood_mode" == "1" ]]
then
    echo "===Override default flood_mode==="
    export OVERRIDE_DEFAULT_FLOOD_MODE=1
fi

if [[ "$override_default_lag_mode" == "1" ]]
then
    echo "===Override default lag_mode==="
    export OVERRIDE_DEFAULT_LAG_MODE=1
fi

if [[ "$fw_fatal_event_mode" == "" ]]
then
    if [[ "$fatal_error_mode" == "1" ]]
    then
        export FW_FATAL_EVENT_MODE="FW_HALT"
        echo "===Configure fw_fatal_event_mode to FW_HALT==="
    else
        export FW_FATAL_EVENT_MODE="FW_NO_CHECK"
    fi
else
    export FW_FATAL_EVENT_MODE=$fw_fatal_event_mode
    echo "===Starting in fw_fatal_event_mode $FW_FATAL_EVENT_MODE==="
fi


if [[ "$sys_acl_drop_trap_en" == "1" ]]
then
    echo "===Trapping Pkts Dropped by System ACL is ON==="
    export SYS_ACL_DROP_TRAP_EN=1
else
    export SYS_ACL_DROP_TRAP_EN=0
fi

if [[ "$pdb_lag_init" == "1" ]]
then
    echo "===Starting with pdb_lag_init TRUE==="
    export PDB_LAG_INIT=1
fi

if [[ "$port_state_down_mode" == "1" ]]
then
    echo "===Starting with port_state_down_mode TRUE==="
    export PORT_STATE_DOWN_MODE=1
fi

if [[ "$port_speed_rate_mode" == "DEFAULT" || "$port_speed_rate_mode" == "SPEED"  || "$port_speed_rate_mode" == "RATE" ]]
then
    echo "===Starting with port_speed_rate_mode ${port_speed_rate_mode}==="
    export PORT_SPEED_RATE_MODE=${port_speed_rate_mode}
else
    echo "Error: invalid port_speed_rate_mode: ${port_speed_rate_mode}. Valid modes are DEFAULT, SPEED and RATE "
    exit 1
fi

if [[ "$pdb_port_map_init" == "1" ]]
then
    echo "===Starting with pdb_port_map_init TRUE==="
    export PDB_PORT_MAP_INIT=1
fi

if [[ "$use_xm" == "1" ]]
then
    echo "===Starting with use_xm TRUE==="
    export USE_XM=1
fi

if [[ "$hide_deprecation_err" == "1" ]]
then
    echo "===Hiding deprecation err==="
    export evb_sx_sdk_suffix="$evb_sx_sdk_suffix --hide_deprecation_err"
fi

if [[ "$enable_debugger" == "1" ]]
then
    echo "===Enable GDB to start sx_sdk==="
    export START_SX_SDK_WITH_GDB=1
fi

if [[ "$i2c_mode" == "1" ]]
then
    echo "===Starting SDK in I2C mode==="
    export SX_I2C_MODE=1
fi

if [[ "$mst_mode" == "1" ]]
then
    echo "===Starting SDK in MST mode==="
    export SX_MST_MODE=1
fi

if [[ "$skip_reset" == "1" ]]
then
    echo "===Skip ASIC reset==="
    export SX_SKIP_RESET=1
fi

if [[ "$skip_flint" == "True" ]]
then
    echo "===Skipping flint query on get_system_type.sh==="
fi

if test -n "${xml_init}"; then
    echo "=== Pre-Defined XML Initialization mode will be used in get_system_type.sh==="
fi

if [[ "$use_2nd_bonus_port" == "1" ]]
then
    export SX_USE_2ND_BONUS_PORT=1
fi

if [[ "$transaction_mode_disable" == "1" ]]
then
    export TRANSACTION_MODE_DISABLE=1
fi

if [[ "$do_not_init_with_port_profile" == "1" ]]
then
    export DO_NOT_INIT_WITH_PORT_PROFILE=1
fi

if [[ "$enable_rsc_manager_debugger" == "1" ]]
then
    echo "===Enable GDB to start resource manager==="
    export START_RSC_MANAGER_WITH_GDB=1
fi

if [[ "$enable_chassis_manager_debugger" == "1" ]]
then
    echo "===Enable GDB to start chassis manager==="
    export START_CHASSIS_MANAGER_WITH_GDB=1
fi

if [[ "$enable_dvs_manager_debugger" == "1" ]]
then
    echo "===Enable GDB to start dvs manager==="
    export START_DVS_MANAGER_WITH_GDB=1
fi

if [[ "$cos_max_buff_mode_param" == "GUARANTEED"  ||  "$cos_max_buff_mode_param" == "TOTAL" ]]
then
    if [[ "$cos_max_buff_mode_param" == "GUARANTEED" ]]
    then
        export COS_BUFF_MAX_MODE=0
    else
        export COS_BUFF_MAX_MODE=1
    fi
else
    if [[ "$cos_max_buff_mode_param" == "" ]]
    then
        echo "Missing mode argument for --cos_max_buff_mode"
    else
        echo "Invalid mode argument for --cos_max_buff_mode"
    fi
    exit 1
fi

if [[ "$disable_modular_chassis_init" == "1" ]]
then
    echo "===Starting with disable_modular_chassis_init TRUE==="
    export DISABLE_MODULAR_CHASSIS_INIT=1
fi

export PORT_PROFILES_NUM=$port_profiles_num
export PORT_PROFILES_TOTAL_MEMORY=$port_profiles_total_memory

if [[ "$max_bridge" != "" ]]
then
    echo "max_bridge = $max_bridge"
    export MAX_BRIDGE_NUM=$max_bridge
fi

if [[ "$max_port_router" != "" ]]
then
    echo "max_port_router = $max_port_router"
    export MAX_PORT_ROUTER_INTERFACE_NUM=$max_port_router
fi

if [[ "$asan" == "1" ]]
then
    echo "===Starting SDK under address sanitizer==="
    if ! strings $(which sx_sdk) | grep -qis "libasan"; then
        error "SDK Was not compiled with address sanitizer support, cannot use --asan"
    fi
    echo "Using ASAN options: $asan_options"
    echo "Using LSAN options: $lsan_options"
    echo "For any application using SDK, please export ASAN_OPTIONS and LSAN_OPTIONS environment variables with above options"
    export ASAN_OPTIONS=$asan_options LSAN_OPTIONS=$lsan_options
fi

dir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

if [[ "$restore" == "1" ]]
then
    export RESUME_SDK=1
    sdk_criu_dir=/root/.sdk_criu

    if pidof sx_sdk > /dev/null; then
        error "Could not restore sdk : sx_sdk process is running !"
    fi

    cp -rf $sdk_criu_dir/shm/* /var/run/shm/

    # The restore may fail due to the PID/TID of the checkpointed process (sx_sdk) has been used by other process/thread.
    # The wiki page https://criu.org/When_C/R_fails describes the details of such failure.
    # Below is a simple WA which retries the restore upon such failure, if the retry still fails, then the script exits.
    set +eE     # Disable bash exit on error
    criu_log=$(criu restore -d -D $sdk_criu_dir/sdk --shell-job 2>&1)
    if [ $? != 0 ]; then
        echo $criu_log | grep -E "Pid\s+[0-9]+\s+do not match expected|Thread pid mismatch"
        if [ $? != 0 ]; then
            error "CRIU restore failed"
        fi
        echo "The CRIU restore may fail due to the PID/TID of the checkpointed process (sx_sdk) has been used by other process/thread."
        echo "The wiki page https://criu.org/When_C/R_fails describes the details of such failure."
        echo "We are now retrying the restore."
        sleep 2
        criu restore -d -D $sdk_criu_dir/sdk --shell-job
        if [ $? != 0 ]; then
            error "The retry of CRIU restore still fails, please kexec the kernel and try the restore again."
        fi
    fi
    set -eE     # Restore bash exit on error

    ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel start || error "Could not load drivers"
    $dir/sdk_pause_resume --resume || error "SDK Resume failed"

    echo -e "\nSDK has been successfully restored.\n"
    exit 0
else
    export RESUME_SDK=0
fi

if [[ "$ib_chipsim_system" != "" ]]
then
    if [[ "$ib_chipsim_system" != "blackbird" ]] && [[ "$ib_chipsim_system" != "sunbird" ]]
    then
        echo "IB ChipSim system must be (blackbird/sunbird)"
        exit 1
    fi
    export IB_CHIPSIM_SYSTEM=$ib_chipsim_system
    echo "IB ChipSim system is $ib_chipsim_system"
fi

system_type=$($dir/get_system_type.sh --mode=$start_mode --skip_flint=$skip_flint ${xml_init}) || error "${system_type}"

# Hippo indication: Non-Secured FW Will show the board name. Secured-FW: Will show only PSID/Part-Number
if [[ "$system_type" == *"system hippo"* ]] || [[ "$system_type" == *"MT_0000000962"* ]] || [[ "$system_type" == *"MT_0000000961"* ]]; then
    export SX_USE_2ND_BONUS_PORT=1
fi

if test -n "${SX_USE_2ND_BONUS_PORT}"; then
    echo "=== Starting with 2nd bonus port enabled ==="
fi

if [[ "$sxd_sniffer" == "1" ]]
then
    export SXD_SNIFFER="1"
    echo "sxd_sniffer_activated"
fi

export SDK_SYS_INFO_PATH="$sdk_sys_info_path"
mkdir -p $sdk_sys_info_path

if [[ "$fuse_enable" == "1" ]]
then
    export FUSE_ENABLE="1"
    fuse_running_path=${sdk_sys_info_path}/dump_fuse
    export FUSE_DIR_PATH="$fuse_running_path"
    modprobe fuse
    if mount | grep -q $fuse_running_path; then umount $fuse_running_path; fi
    mkdir -p $fuse_running_path
    echo "fuse dump enabled, fuse dump directory: '$fuse_running_path'"
fi

if [[ "$disable_health_check" == "1" ]]
then
    export DISABLE_HEALTH_CHECK=1
fi

if [[ "$enable_health_check_log" == "1" ]]
then
    export ENABLE_HEALTH_CHECK_LOG=1
fi

if [[ "$enable_split" == "1" ]]
then
    echo "Enable split in IB switch profile"
    export ENABLE_IB_SPLIT=1
fi

if [[ "$enable_router" == "1" ]]
then
    echo "Enable routert in IB switch profile"
    export ENABLE_IB_ROUTER=1
fi

if [[ "$prm_sniffer" == "1" ]]
then
    export PRM_SNIFFER="1"
    echo "prm_sniffer_activated"
fi

if [[ "$emad_dump" == "1" ]]
then
    export RESET_TRIGGER=0
    export EMAD_DUMP_DIR="$emad_dump_dir"
    export EMAD_DUMP_PCAP_FILE="$emad_dump_pcap"
    echo "EMAD dump is enabled"
else
    export RESET_TRIGGER=1
fi

if [[ "$load_spice" == "1" ]]
then
    export SPICE=1
    echo "SPICE is enabled"
else
    export SPICE=0
fi

if [ -n "${custom_config_file}" ]
then
    export SDK_CONFIG_FILE=${custom_config_file}
fi

if [[ "${acl_manual_unbind}" == "1" ]]
then
    export ACL_MANUAL_UNBIND=1
    echo "ACL manual unbind is enabled"
fi

if [[ "${urmcv6_enable}" == "1" ]]
then
    export URMCV6_ENABLE=1
    echo "URMCV6 is enabled"
fi

if [ "$module_support_type" != "dependent" ] && [ "$module_support_type" != "enabled" ] && [ "$module_support_type" != "independent" ] && [ "$module_support_type" != "standalone" ]
then
    echo "Invalid module_support_type $module_support_type: Supported are dependent,enabled,independent,standalone"
    usage
    exit 1
else
    export MODULE_SUPPORT_TYPE=$module_support_type
    echo "Module support type is set to $module_support_type"
fi

if [[ "${roaming_mac_notif_en}" == "1" ]]
then
    export ROAMING_MAC_NOTIF_EN=1
    echo "Roaming mac notification is enabled"
fi

if [[ "${emad_timeout}" != "" ]]
then
    int(){ expr 0 + ${1:-} 2>/dev/null||:; }
    emad_timeout=$(int $emad_timeout)
    if [[ "${emad_timeout}" == "" ]]
    then
        echo "Invalid EMAD Timeout given (Non-int)"
        exit 1
    fi

    ((emad_timeout<1 || emad_timeout>4294967295)) && echo "EMAD Timeout invalid ($emad_timeout). valid range is [1-4294967295]" && exit 1

    export EMAD_TIMEOUT="$emad_timeout"
    echo "EMAD Custom timeout given: '$emad_timeout' usec"
fi

echo "$system_type"| while read data; do
    echo $data
    if [[ $data = *start.sh ]]; then
	 start_script=${data#*:}
        eval $start_script $bridge_mode $max_vlan $acl_search_type
        exit $?
    fi
done

# Folder patterns for backup defined in dvs_stop & dvs_start scripts
issu_first_life_backup_path="${sdk_sys_info_path}_first_life"
if test "${boot_mode}" == "ISSU_STARTED" && ls ${issu_first_life_backup_path}/sx_sdk_*.pcap* > /dev/null 2>&1; then
    echo "Restoring ISSU 1st life PCAP Recordings from ${issu_first_life_backup_path} to ${sdk_sys_info_path}"
    cp -f ${issu_first_life_backup_path}/sx_sdk_*.pcap* ${sdk_sys_info_path}/ && rm -rf ${issu_first_life_backup_path}
fi

# HW-MGMT / Minimal driver related conditions

if [[ -z "${PREDEFINED_DEV}" ]]; then
    mod_support_use=`grep 'mod_support_use' /proc/dbg_dump/fw_and_board_info_dump | awk '{print $3}'`
    mod_support_cap=`grep 'mod_support_cap' /proc/dbg_dump/fw_and_board_info_dump | awk '{print $3}'`
    hw_mgmt_svc_state="$(systemctl is-active hw-management || true)"
else
    DEV_ID="${PREDEFINED_DEV}"
    mod_support_use=`grep 'mod_support_use' /proc/dbg_dump/dev_$DEV_ID/fw_and_board_info_dump | awk '{print $3}'`
    mod_support_cap=`grep 'mod_support_cap' /proc/dbg_dump/dev_$DEV_ID/fw_and_board_info_dump | awk '{print $3}'`
    echo "Skipping minimal driver validation due to PREDEFINED_DEV Run mode"
    skip_minimal_driver_check=1
fi

if test -z "${mod_support_use}"; then
    echo "Failed to determine module management support usage"
    exit 1
fi

hw_mgmt_run_path="/var/run/hw-management"
if ! test -e "${hw_mgmt_run_path}"; then
    echo "Skipping minimal driver validation since '${hw_mgmt_run_path}' doesn't exist. Assuming underlying platform not supported"
    skip_minimal_driver_check=1
elif test "${mod_support_use}" != "dependent"; then
    echo "Skipping minimal driver validation due to '${mod_support_use}' module management mode"
    skip_minimal_driver_check=1
    if systemctl is-enabled --quiet hw-management-tc && systemctl is-active --quiet hw-management-tc; then
        echo "Stopping hw-management-tc service: No thermal report daemon over DVS, We need FANs to operate at max speed"
        systemctl stop hw-management-tc &
    fi
elif test -n "${evb_skip_init}" && test "${mod_support_cap}" != "dependent"; then
    # On switch supporting independent/standalone-module-management CAPABILITY ->
    # Device-Add-Udev event for minimal-driver, will be sent only after set-profile
    # (and only if user choose to work dependent mode).
    # In evb_skip_init mode - No set-profile occurs at all -> So we should skip minimal validation here
    echo "Skipping minimal driver validation since env evb_skip_init=${evb_skip_init} && Switch is '${mod_support_cap}' module management capable"
    skip_minimal_driver_check=1
elif test "${skip_minimal_driver_check}" -eq "1"; then
    echo "Skipping minimal driver validation due to explicit user choice"
elif ! test -x ${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel; then
    echo "Skipping minimal driver validation since SDK Kernel driver not installed"
    skip_minimal_driver_check=1
elif test "${hw_mgmt_svc_state}" != "active"; then
    echo -e "\nhw-management service is in '${hw_mgmt_svc_state}' state, service status for debug:"
    systemctl status hw-management --no-pager -l || true
    echo -e "Skipping minimal driver validation since hw-management service is in '${hw_mgmt_svc_state}' state\n"
    skip_minimal_driver_check=1
fi

if test "${skip_minimal_driver_check}" -eq "0"; then
    interval=0.05
    wait_cnt=0
    max_wait_cnt=600    # 30 Seconds, 0.05 Interval
    timeout=$(echo "$max_wait_cnt $interval" | awk '{print $1 * $2}')

    echo "*** Waiting minimal driver to finish initialization, up to ${timeout} sec ***"

    asics_init_done="${hw_mgmt_run_path}/config/asics_init_done"
    if test "$(uname -r)" == "4.19.81-OpenNetworkLinux"; then     # Old DVS - Use module counter instead
        asics_init_done="${hw_mgmt_run_path}/config/module_counter"
    fi

    while ( ! test -f ${asics_init_done} || test "$(cat ${asics_init_done})" -eq "0" ) && (( wait_cnt < max_wait_cnt )); do
        printf "." && sleep ${interval} && ((wait_cnt=wait_cnt+1))
    done
    (( wait_cnt > 0 )) && echo || true      # Add empty line in case '.' was printed
    (( wait_cnt < max_wait_cnt )) && echo "*** Minimal driver finished initialization ***" \
        || echo "-W- Minimal driver did not finish init (${asics_init_done} = 0) after ${timeout} sec"
fi

if [[ "$bist" == "1" ]]
then
    echo "=== SDK Loaded - Starting Built-In-Self-Test ==="
    if ! sx_sdk_built_in_self_test; then               # Should be in usr PATH as installed binary
        echo "SDK Built-In-Self-Test FAILED"
        exit 1
    fi
    echo "=== SDK Built-In-Self-Test PASSED ==="
fi

if [[ "$asan" == "1" ]]
then
    echo "=== SDK Started under address sanitizer ==="
    echo "For any application using SDK, please export ASAN_OPTIONS=$asan_options LSAN_OPTIONS=$lsan_options"
fi

rc=$?
echo "*** DVS Start finished with rc ${rc} ***"
exit $rc
