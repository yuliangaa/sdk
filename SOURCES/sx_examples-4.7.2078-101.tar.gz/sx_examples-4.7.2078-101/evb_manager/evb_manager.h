/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef EVB_MANAGER_H_
#define EVB_MANAGER_H_

#include <complib/sx_log.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_dpt.h>

#include <sx/sdk/sx_types.h>

#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_fdb.h>
#include <sx/sdk/sx_api_mstp.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_lib_host_ifc.h>
#include <sx/sdk/sx_api_policer.h>
#include <sx/sdk/sx_api_topo.h>
#include <sx/sdk/sx_api_vlan.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_strings.h>
#include <sx/sdk/sx_api_lag.h>
#include <sx/sdk/sx_api_dbg.h>
#include <sx/sdk/sx_api_span.h>

#ifdef IB_PRESENT_FLAG
#include <sx/ib/sx_ib_router.h>
#include <sx/ib/sx_api_ib_router.h>
#include <sx/ib/sx_api_ib_port.h>
#endif

#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <libgen.h>
#include <complib/sx_xml.h>
#include <netinet/ether.h>
#include <arpa/inet.h>

#include "../include/evb_status.h"
#include "../utils/utils.h"


/************************************************
 *  MACROS
 ***********************************************/

#define EVB_XML_PARSE_UINT(sx_xml_element_t, uint_var, var_name, rc)                   \
    do {                                                                               \
        if (sx_xml_element_t != NULL) {                                                \
            uint_var = strtoul(sx_xml_element_content_get(sx_xml_element_t), NULL, 0); \
        } else {                                                                       \
            SX_LOG_ERR("Error parsing %s\n", var_name);                                \
            rc = EVB_STATUS_PARSE_ERROR;                                               \
        }                                                                              \
    } while (0)

#define EVB_XML_PARSE_MAC_ADDR(mac_element, mac_var, var_name, rc)                   \
    do {                                                                             \
        if (mac_element != NULL) {                                                   \
            memcpy(mac_var, ether_aton(sx_xml_element_content_get(mac_element)), 6); \
            if (mac_var == NULL) {                                                   \
                SX_LOG_ERR("Error parsing MAC address %s\n", var_name);              \
                rc = EVB_STATUS_PARSE_ERROR;                                         \
            }                                                                        \
        }                                                                            \
    } while (0)


#define EVB_XML_PARSE_IP_ADDR(ip_element, ip_var, var_name, rc)                 \
    do {                                                                        \
        struct in_addr network;                                                 \
        if (inet_aton(sx_xml_element_content_get(ip_element), &network) == 0) { \
            SX_LOG_ERR("Error parsing network IP\n");                           \
            rc = EVB_STATUS_PARSE_ERROR;                                        \
        }                                                                       \
        ip_var = ntohl(network.s_addr);                                         \
    } while (0);                                                                \


#define EVB_UTILS_CLR_MEM_GET(ptr, num, size) \
    evb_utils_clr_memory_get((void**)(ptr), (uint32_t)(num), (uint32_t)(size), UTILS_MEM_TYPE_ID_EVB_MANAGER)

#define EVB_PORT_UTILS_MEM_PUT(ptr) \
    evb_utils_memory_put((void*)(ptr), UTILS_MEM_TYPE_ID_EVB_MANAGER)

enum {
    EVB_ARG_LOG_FILE                      = 1000,
    EVB_ARG_LOG_LIB                       = 1001,
    EVB_ARG_MODE                          = 1002,
    EVB_ARG_MAX_VLAN                      = 1003,
    EVB_ARG_BOOT_MODE                     = 1004,
    EVB_ARG_PDB_LAG_INIT                  = 1005,
    EVB_ARG_PDB_PORT_MAP_INIT             = 1006,
    ARG_VERBOSITY_LEVEL                   = 1007,
    ARG_NO_VERBOSITY                      = 1008,
    EVB_ARG_FW_FATAL_EVENT_MODE           = 1009,
    EVB_ARG_PORT_STATE_DOWN_MODE          = 1010,
    EVB_ARG_PORT_SPEED_RATE_MODE          = 1011,
    EVB_ARG_DISABLE_HEALTH_CHECK          = 1012,
    EVB_ARG_USE_2ND_BONUS_PORT            = 1013,
    EVB_ARG_DO_NOT_INIT_WITH_PORT_PROFILE = 1014,
};

#define EVB_MAX_PORTS     200
#define EVB_MAX_UC_ROUTES 200

#define EVB_DEFAULT_BASE_XML_FILE       "device_base.xml"
#define EVB_DEFAULT_XML_TREES_COUNT     0
#define EVB_DEFAULT_DEVICE_COUNT        1
#define EVB_DEFAULT_DEVICE_STATE        1
#define EVB_DEFAULT_DEVICE_NUMBER       1
#define EVB_DEFAULT_XML_TREE_HDL        0
#define EVB_DEFAULT_NODE_TYPE           1
#define EVB_DEFAULT_RSTP_STATE          3 /* Forwarding */
#define EVB_DEFAULT_PORT_STATE          1
#define EVB_DEFAULT_PORT_VID            1
#define EVB_DEFAULT_LOOPBACK_MODE       0
#define EVB_DEFAULT_MAPPING_MODE        1
#define EVB_PORT_TYPE_PROTOCOL_MASK_ETH (1 << 2)
#define EVB_PORT_TYPE_PROTOCOL_MASK_IB  (1 << 0)

#define EVB_MAX_PACKET_SIZE    (4 * 1024)
#define LCL_PORT_LANE_NUM      (NUMBER_OF_SERDESES)
#define LOCAL_PORTS_ARR_LEN    (64)
#define DEFAULT_NVE_PORT_COUNT 3  /* NVE + 2 FLEX TUNNELS */

#define EVB_ETH_L3_MC_TRAP_GROUP 3
#define EVB_ARP_TRAP_GROUP       2
#define EVB_IP2ME_TRAP_GROUP     1

/* The following define is used to indicate that we will use new API
 *  'sx_api_port_rate_set' for port speed configuration. Please note
 *  that this API allows to configure 200Gbps and 400Gbps port speed.
 */
#define EVB_PORT_SPEED_API_TYPE_RATE (1 << 31)

/* The following macro is used to determine whether specified 'speed' is enabled
 *  in the 'speed_bitmap' for the new type of port configuration API 'sx_api_port_rate_set'
 *
 *  In case if speed is enabled macro will return TRUE
 */
#define EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, speed) \
    (((speed_bitmap & speed) != 0) &&                   \
     ((speed_bitmap & EVB_PORT_SPEED_API_TYPE_RATE) != 0))

#define SET_DPT_STATE_IF_ISSU_STARTED(dev_id, issu_started, dpt_state, ret_type)          \
    do {                                                                                  \
        sxd_status_t sxd_rc = SXD_STATUS_SUCCESS;                                         \
        if (issu_started) {                                                               \
            sxd_rc = sxd_dpt_set_access_control(dev_id, dpt_state);                       \
            if (SXD_CHECK_FAIL(sxd_rc)) {                                                 \
                SX_LOG_ERR("failed to set access control in user space DPT, "             \
                           "for device %d. error: %s\n", dev_id, SXD_STATUS_MSG(sxd_rc)); \
                return (ret_type)(sxd_status_to_sx_status(sxd_rc));                       \
            }                                                                             \
        }                                                                                 \
    } while (0)


typedef enum profile {
    PROFILE_ETH = 0,
    PROFILE_IB  = 1,
} profile_t;

typedef enum port_state {
    PORT_UP   = 1,
    PORT_DOWN = 2
} port_state_t;

typedef enum  port_system_mode {
    PORT_SYSTEM_ETH = 0,
    PORT_SYSTEM_IB  = 1
} port_system_mode_t;

/**
 * module_lane_map_t structure is used to store
 * info regarding the map between lane and it's module
 */
typedef struct module_lane_map {
    uint8_t use_different_rx_tx;
    uint8_t module[LCL_PORT_LANE_NUM]; /*!< module number (0..63) */
    uint8_t slot[LCL_PORT_LANE_NUM];  /*!< slot number (0..8), 1U system - slot value = 0, buffalo slot value = 1..8 */
    uint8_t lane[LCL_PORT_LANE_NUM]; /*!< lane number ( 0..7) */
    uint8_t rx_lane[LCL_PORT_LANE_NUM]; /*!< RX lane number ( 0..7) */
} module_lane_map_t;

/**
 * port_info_t structure is used to store port info
 */
typedef struct port_info {
    sx_port_mode_t            port_mode;   /*!< physical ports stacking mode info */
    sx_port_mapping_t         port_mapping;    /*!< physical ports mapping info */
    sx_mstp_inst_port_state_t mstp_port_state; /*!< mstp port's state */
    sx_port_speed_t           port_speed;      /*!< port's speed */
    sx_port_admin_state_t     port_state;       /*!< port's state */
    boolean_t                 port_ext_api_type; /*!< indicates whether user uses new 'sx_api_port_rate_set' API for port speed configuration */
    sx_swid_t                 swid;            /*!< port's swid */
    sx_vid_t                  vid;             /*!< port's vid */
    module_lane_map_t         module_lane_map; /*!< port's module & lanes map */
    uint16_t                  mtu_cap; /*!< port's mtu capability */
    uint8_t                   vl_cap; /*!< port's vl capability */
    uint8_t                   link_width_supported; /*!< port's link width supported */
    uint16_t                  label_port;      /*!< label port number (==ib port) */
    sx_port_phys_loopback_t   phys_loopback; /**< port physical loopback */
} port_info_t;


/**
 * device_t structure is used to store
 * info regarding the device section in the configuration file
 */
typedef struct device {
    sx_dev_info_t                device_info; /*!< general device information */
    sx_fdb_uc_mac_addr_params_t *uc_mac_arr; /*!< array which maps destination log port to egress local port  */
    uint32_t                     uc_mac_arr_len; /*!< # of members in uc_mac_arr */
    sx_port_log_id_t             log_ports_arr[RM_API_HOST_IFC_NUM_MAX + 3]; /*!< array of logical ports created for this device  */
    uint32_t                     log_ports_arr_len; /*!< # of members in log_ports_arr */
    sx_mac_addr_t                base_mac_addr; /*!< device mac address */
    port_info_t                 *port_info_arr_eth; /*!< array of eth port info structs */
    int                          port_info_arr_len_eth; /*!< # of members in eth port_info_arr */
    port_info_t                 *port_info_arr_ib; /*!< array of ib port info structs */
    int                          port_info_arr_len_ib; /*!< # of members in ib port_info_arr */
    port_info_t                 *port_info_arr;
    int                          port_info_arr_len;
    char                       * host_name; /*!< host name (IB) */
    uint64_t                     sys_guid; /*!< system GUID (IB) */
    boolean_t                    transaction_mode_en; /*<! # Transaction mode after the SDK initialization. If the transaction mode is ENABLE, the user must disable it.
                                                       *      Relevant when boot_mode is ISSU_FAST or FAST. */
} device_t;

/**
 * device_t structure is used to store
 * info regarding the device section in the configuration file
 */
typedef struct {
    cl_map_item_t    map_item;
    sx_port_log_id_t port_log_id;
} port_map_item_t;

/**
 * Get device count field value from the configuration file
 *
 * @param[out]  device_count_p - number of devices configured in the file
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __parse_device_count_section(OUT int *device_count_p);


/**
 * Parse the SWIDs section in the XML file
 *
 * @param[out]  swid_count_p - swids count
 * @param[out]  swid_arr_p  - swids array
 * @param[IN]   swid_key - XML swids section key.
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __parse_swid_section(OUT int        *swid_count_p,
                                  OUT sx_swid_t **swid_arr_p,
                                  IN char        *swid_key);


/**
 * This function parse a physical port section
 *
 * @param[in]   profile             - port list xml section type : ETH , IB
 * @param[in]   child_p             - port info xml section
 * @param[out]  port_info_p         - port info struct
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __parse_port_info_section(IN profile_t         profile,
                                       IN sx_xml_element_t *child_p,
                                       OUT port_info_t     *port_info_p);

/*
 * The following function check whether specified speed_bitmap belongs to extended port
 * speed array (which may contains 200Gbps and 400Gbps) and if yes - convert specified
 * speed value into relevant admin_rate set of bits.
 */
evb_status_t __port_rate_convert_bitmap(const sx_port_speed_t   speed_bitmap,
                                        boolean_t              *is_ext_port_speed_p,
                                        sx_port_rate_bitmask_t *admin_rate_p);

sx_status_t __get_chip_type(const sx_api_handle_t handle, sx_chip_types_t* chip_type);
evb_status_t __port_device_set(device_t *__device_db_p, port_info_t *port_info_p, uint32_t port_cnt);

/**
 * This function parse the physical ports list section
 *
 * @param[in]   profile             - port list xml section type : ETH , IB
 * @param[in]   child_p             - port list xml section
 * @param[out]  port_info_arr       - port info array
 * @param[out]  port_info_arr_len_p - port info array length
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __parse_device_ports_list_section(IN profile_t         profile,
                                               IN sx_xml_element_t *child_p,
                                               OUT port_info_t    **port_info_arr,
                                               OUT int             *port_info_arr_len_p);


/**
 * This function set the following port mapping (per port):
 * 1. Lanes
 * 2. Lane to module
 * according to the parsed port info section
 * @param[in]   dev_id - device ID
 * @param[in]   port_info_p- port info
 * @param[in]   port_system_mode_t - port system mode ETH or IB
 *
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 */
evb_status_t __set_port_mapping_per_port(IN sxd_dev_id_t    dev_id,
                                         IN port_info_t    *port_info_p,
                                         port_system_mode_t port_system_mode);

/**
 * This function set the following port UN-mapping (per port):
 * 1. Lanes
 * 2. Lane to module
 * according to the parsed port info section
 * @param[in]   dev_id - device ID
 * @param[in]   port_info_p- port info
 * @param[in]   port_system_mode - port system mode ETH or IB
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __set_port_unmapping_per_port(IN sxd_dev_id_t       dev_id,
                                           IN port_info_t       *port_info_p,
                                           IN port_system_mode_t port_system_mode);


evb_status_t __evb_sdk_self_init_port_defaults(port_info_t *port_info_p);

extern sx_xml_reader_t *__reader_p;             /* XML file reader */
extern sx_xml_parser_t *__parser_p;             /* XML file parser */
extern sx_xml_tree_t   *__tree_p;             /* XML tree        */
extern sx_api_handle_t  __handle;
extern device_t        *__device_db_p; /* Devices Database  */
extern int              __device_count;         /* Number of devices in __device_db_p */
extern sx_swid_t       *__swids_db_p_ib;       /* SWIDs Database */
extern int              __swids_count_ib;          /* Number of SWIDs in __swids_db_p */
extern sx_swid_t       *__swids_db_p_eth;       /* SWIDs Database */
extern int              __swids_count_eth;         /* Number of SWIDs in __swids_db_p */
extern char             device_cnt;
extern char             device_arr[];
extern short            tree_arr[];
extern int              __tree_count;     /* Number of Trees in __topo_device_db_p */
extern uint32_t         num_of_active_vlans;
extern boolean_t        do_not_init_with_port_profile;
extern boolean_t        is_eth_from_xml_init;

#endif /* EVB_MANAGER_H_ */
