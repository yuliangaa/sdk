/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "evb_manager.h"
#include "topo_parse_manager.h"
#include "evb_manager_ib.h"

#undef  __MODULE__
#define __MODULE__ EVB_MANAGER_IB

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

evb_status_t __parse_ib_device_params_section(OUT device_t *device_p, IN sx_xml_element_t *child_p)
{
    evb_status_t      evb_rc = EVB_STATUS_SUCCESS;
    sx_xml_element_t *child_dev_number = NULL;
    sx_xml_element_t *child_host_name = NULL;
    sx_xml_element_t *child_sys_guid = NULL;

    SX_LOG_ENTER();

    if ((device_p == NULL) || (child_p == NULL)) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    /*****************************************************************************/
    /*		               PARSING SECTION				     */
    /*****************************************************************************/


    child_dev_number = sx_xml_element_by_name_get(child_p, "device-number");
    child_host_name = sx_xml_element_by_name_get(child_p, "host-name");
    child_sys_guid = sx_xml_element_by_name_get(child_p, "sys_guid");

    if (child_dev_number) {
        device_p->device_info.dev_id = atoi(sx_xml_element_content_get(
                                                child_dev_number));
    } else {
        SX_LOG_ERR("Error parsing dev_number\n");
    }

    if (child_host_name) {
        device_p->host_name = (char*)(sx_xml_element_content_get(child_host_name));
    } else {
        SX_LOG_ERR("Error parsing host name\n");
    }

    if (child_sys_guid) {
        device_p->sys_guid = strtoull(sx_xml_element_content_get(
                                          child_sys_guid), NULL, 16);
    } else {
        SX_LOG_ERR("Error parsing system GUID\n");
    }

    /*****************************************************************************/
    /*		               PARSE PORT INFO LIST			     */
    /*****************************************************************************/
    evb_rc = __parse_device_ports_list_section(
        PROFILE_IB,
        child_p,
        &(device_p->port_info_arr_ib),
        &(device_p->port_info_arr_len_ib));
    if (EVB_CHECK_FAIL(evb_rc)) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}

/*
 * Register based ib port vl_cap and mtu configuration
 */
evb_status_t __evb_ib_port_update_reg_info(port_info_t       *port_info_p,
                                           int                local_port,
                                           struct ku_ptys_reg ptys_reg,
                                           sxd_reg_meta_t     reg_meta)
{
    struct ku_pvlc_reg pvlc_reg;
    struct ku_pmtu_reg pmtu_reg;
    struct ku_pllp_reg pllp_reg;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;
    evb_status_t       evb_rc = EVB_STATUS_SUCCESS;

    memset(&pmtu_reg, 0, sizeof(struct ku_pmtu_reg));
    memset(&pvlc_reg, 0, sizeof(struct ku_pvlc_reg));
    memset(&pllp_reg, 0, sizeof(struct ku_pllp_reg));


    port_info_p->port_speed = ptys_reg.ib_proto_capability;
    port_info_p->link_width_supported = ptys_reg.ib_link_width_admin;

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pvlc_reg.local_port, pvlc_reg.lp_msb, local_port);
    sxd_err = sxd_access_reg_pvlc(&pvlc_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed in PVLC get (VL CAP) local_port %u, error: %s\n",
                   pvlc_reg.local_port, SXD_STATUS_MSG(sxd_err));
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }
    port_info_p->vl_cap = pvlc_reg.vl_cap; /*PVLC Reg */

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pllp_reg.local_port, pllp_reg.lp_msb, local_port);
    /* get protocol using PLLP */
    sxd_err = sxd_access_reg_pllp(&pllp_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed in PLLP get (getting protocol), error: %s, local_port = %u\n",
                   SXD_STATUS_MSG(sxd_err), local_port);
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

    if (pllp_reg.protocol == 3) { /* NVLink */
        pmtu_reg.protocol = 2;
    } else if (pllp_reg.protocol == 2) { /* IBg1 */
        pmtu_reg.protocol = 1;
    }

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pmtu_reg.local_port, pmtu_reg.lp_msb, local_port);
    sxd_err = sxd_access_reg_pmtu(&pmtu_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed in PMTU get (MTU CAP), error: %s\n",
                   SXD_STATUS_MSG(sxd_err));
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }
    port_info_p->mtu_cap = pmtu_reg.admin_mtu;
out:
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __evb_common_ib_profile_init(int device_index, boolean_t issu_start, boolean_t pdb_port_map_init)
{
    evb_status_t          evb_rc = EVB_STATUS_SUCCESS;
    sx_status_t           rc = SX_STATUS_SUCCESS;
    sxd_status_t          sxd_rc = SXD_STATUS_SUCCESS;
    int                   log_port_index = 0;
    sx_topolib_dev_info_t dev_info;
    dpt_path_params_t     path_params;

    memset(&dev_info, 0, sizeof(dev_info));

    SX_LOG_ENTER();
    evb_rc = __port_device_set(
        &(__device_db_p[device_index]),
        __device_db_p[device_index].port_info_arr_ib,
        (uint32_t)__device_db_p[device_index].port_info_arr_len_ib);

    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("__port_device_set failed, error: %s\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }

    dev_info.dev_id = __device_db_p[device_index].device_info.dev_id;
    dev_info.node_type = SX_DEV_NODE_TYPE_LEAF_LOCAL;
    dev_info.unicast_arr_len = 0;

    SET_DPT_STATE_IF_ISSU_STARTED(dev_info.dev_id, issu_start, READ_WRITE, evb_status_t);

    rc = sx_api_topo_device_set(__handle, SX_ACCESS_CMD_ADD, &dev_info);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to add device %u to the SDK (sx_api_topo_device_set)\n",
                   __device_db_p[device_index].device_info.dev_id);
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

    if (issu_start) {
        SET_DPT_STATE_IF_ISSU_STARTED(dev_info.dev_id, issu_start, READ_ONLY, evb_status_t);
    }

    if ((pdb_port_map_init == FALSE) || (issu_start == FALSE)) {
        /* set port mapping */
        evb_rc = __ib_set_port_mapping((&__device_db_p[device_index]));
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed in __set_port_mapping , [error: %s] , exit...\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }
    }


    /* Set node description string */
    evb_rc = __ib_set_node_ndesc(__device_db_p[device_index].device_info.dev_id,
                                 __device_db_p[device_index].host_name,
                                 0 /* slot number is 0 - EVB is not part of a chassis */,
                                 0 /* slot type is 0 - only 1 chip type */);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("failed in __set_node_ndesc , [error: %s] , exit...\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* Set system GUID */
    evb_rc = __ib_set_node_sysguid(__device_db_p[device_index].device_info.dev_id,
                                   __device_db_p[device_index].sys_guid);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("failed in __ib_set_node_sysguid , [error: %s] , exit...\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }


    while (log_port_index < __device_db_p[device_index].port_info_arr_len_ib) {
        if (__device_db_p[device_index].port_info_arr_ib[log_port_index].port_mapping.mapping_mode ==
            SX_PORT_MAPPING_MODE_DISABLE) {
            log_port_index++;
            continue;
        }
        /* set port -> SWID only if SWID is not default SWID */
        if ((__device_db_p[device_index].port_info_arr_ib[log_port_index].swid != SX_SWID_ID_DEFAULT) &&
            (__device_db_p[device_index].port_info_arr_ib[log_port_index].swid != SX_SWID_ID_STACKING) &&
            (__device_db_p[device_index].port_info_arr_ib[log_port_index].port_mode != SX_PORT_MODE_NVE)) {
            printf("%s:%d  %s(): dev %d , bind port  0x%x to swid %d \n", __FILE__, __LINE__, __func__,
                   __device_db_p[device_index].device_info.dev_id,
                   __device_db_p[device_index].log_ports_arr[log_port_index],
                   __device_db_p[device_index].port_info_arr_ib[log_port_index].swid);

            if ((pdb_port_map_init == FALSE) || (issu_start == FALSE)) {
                SET_DPT_STATE_IF_ISSU_STARTED(__device_db_p[device_index].device_info.dev_id,
                                              issu_start,
                                              READ_ONLY,
                                              evb_status_t);

                rc = sx_api_port_swid_bind_set(__handle,
                                               __device_db_p[device_index].log_ports_arr[log_port_index],
                                               __device_db_p[device_index].port_info_arr_ib[log_port_index].swid);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed in sx_api_port_swid_alloc_set , error: %s\n", sx_status_str(rc));
                    evb_rc = EVB_STATUS_SDK_ERROR;
                    goto out;
                }

                SET_DPT_STATE_IF_ISSU_STARTED(__device_db_p[device_index].device_info.dev_id,
                                              issu_start,
                                              READ_WRITE,
                                              evb_status_t);
            }
        }

        /* Set port state to DOWN before we configure port attributes */
        evb_rc = __ib_set_port_state(__device_db_p[device_index].log_ports_arr[log_port_index],
                                     SX_PORT_ADMIN_STATUS_DOWN);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed in __ib_set_port_state, [error: %s] , exit...\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }

        /* Set port properties : supported speed , mtu , VLs */
        evb_rc = __ib_set_port_admin_cap(__device_db_p[device_index].device_info.dev_id,
                                         &(__device_db_p[device_index].port_info_arr_ib[log_port_index]));
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed in __ib_set_port_admin_cap , [error: %s] , exit...\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }

        /* Set port state : UP / DOWN */
        evb_rc = __ib_set_port_state(__device_db_p[device_index].log_ports_arr[log_port_index],
                                     __device_db_p[device_index].port_info_arr_ib[log_port_index].port_state
                                     );
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed in __ib_set_port_state, [error: %s] , exit...\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }

        log_port_index++;
    }

    memset(&path_params, 0, sizeof(path_params));

    /* Set DPT to EMADs */
    sxd_rc = sxd_dpt_path_add(__device_db_p[device_index].device_info.dev_id, 0, OOB_PATH, path_params);
    if (SXD_CHECK_FAIL(sxd_rc)) {
        SX_LOG_ERR("Failed: sxd_dpt_path_add for device: [%u]. Return value: [%d, %s]",
                   __device_db_p[device_index].device_info.dev_id, sxd_rc, SXD_STATUS_MSG(sxd_rc));
        SX_LOG_ERR("Failed changing dpt path to EMAD: %s", SXD_STATUS_MSG(sxd_rc));
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __evb_sdk_self_init_handle_ib(boolean_t use_2nd_bonus_port,
                                           boolean_t issu_start,
                                           boolean_t pdb_port_map_init)
{
    int               device_index = 0; /* Device index */
    evb_status_t      evb_rc = EVB_STATUS_SUCCESS;
    sx_xml_list_t    *list_head = NULL;
    sx_xml_element_t *child_p = NULL;
    sx_xml_element_t *child_host_name = NULL;
    sx_xml_element_t *child_sys_guid = NULL;


    SX_LOG_ENTER();


    /* Initialize ib ports */
    evb_rc = __ib_evb_sdk_self_init_swid_ports(&__device_db_p[device_index], use_2nd_bonus_port);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("sdk self init Failed to initialize ib ports , error: %s\n",  evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* create SWIDs in SDK */
    evb_rc = __ib_set_swids();
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in __set_swids , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    printf("%s:%d  %s(): dev_cnt: %d \n", __FILE__, __LINE__, __func__,  __device_count);

    /* Retrieve the MAC address */
    list_head = sx_xml_element_shallow_list_by_name_get(sx_xml_tree_root_element_get(__tree_p), "device");
    child_p = sx_xml_element_list_data(list_head);
    child_host_name = sx_xml_element_by_name_get(child_p, "host-name");
    child_sys_guid = sx_xml_element_by_name_get(child_p, "sys_guid");

    if (child_host_name) {
        __device_db_p[device_index].host_name = (char*)(sx_xml_element_content_get(child_host_name));
    } else {
        SX_LOG_ERR("Error parsing host name\n");
    }

    if (child_sys_guid) {
        __device_db_p[device_index].sys_guid = strtoull(sx_xml_element_content_get(
                                                            child_sys_guid), NULL, 16);
    } else {
        SX_LOG_ERR("Error parsing system GUID\n");
    }

    /* logical ports array length should be the same as the physical ports array length */
    __device_db_p[device_index].log_ports_arr_len = __device_db_p[device_index].port_info_arr_len_ib;
    __device_db_p[device_index].device_info.num_ports = __device_db_p[device_index].port_info_arr_len_ib;

    evb_rc = __evb_common_ib_profile_init(device_index, issu_start, pdb_port_map_init);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("__evb common ib profile init  failed, error: %s\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }

out:
    sx_xml_element_shallow_list_free(list_head);
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __ib_set_swids(void)
{
    int          i = 0;
    sx_status_t  rc = SX_STATUS_SUCCESS;
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();

    for (i = 0; i < __swids_count_ib; i++) {
        if (__swids_db_p_ib[i] == SX_SWID_ID_DEFAULT) {
            continue;
        }

        rc = sx_api_port_swid_set(__handle,
                                  SX_ACCESS_CMD_ADD,
                                  __swids_db_p_ib[i]);
        if (SX_CHECK_FAIL(rc) && (rc != SX_STATUS_ENTRY_ALREADY_EXISTS)) {
            SX_LOG_ERR("Failed in sx_api_port_swid_set , error: %s\n", sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __ib_handle_profile()
{
    evb_status_t          evb_rc = EVB_STATUS_SUCCESS; /* return value for EVB manager APIs */
    sx_xml_list_t        *list = NULL, *list_head = NULL;     /* XML list object - used to iterate device nodes */
    int                   device_index = 0; /* Device index */
    sx_topolib_dev_info_t dev_info;

    memset(&dev_info, 0, sizeof(dev_info));

    list_head = sx_xml_element_shallow_list_by_name_get(sx_xml_tree_root_element_get(__tree_p), "device");
    list = list_head;

    evb_rc = __ib_set_swids();
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in __ib_set_swids , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* handle each device */
    while (list != NULL && device_index < __device_count) {
        sx_xml_element_t *child = sx_xml_element_list_data(list);

        /* get device data - device parameters should fit IB profile */
        evb_rc = __parse_ib_device_params_section(&__device_db_p[device_index], child);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed to parse device params , [error: %s] , exit...\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }

        evb_rc = __evb_common_ib_profile_init(device_index, FALSE, FALSE);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("__evb common ethernet profile init  failed, error: %s\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }

        device_index++;
        list = sx_xml_element_list_next(list);
    }

out:
    sx_xml_element_shallow_list_free(list_head);
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __ib_set_node_ndesc(IN sxd_dev_id_t dev_id,
                                 IN const char * host_name,
                                 IN const int    slot_num,
                                 IN const int    slot_type)
{
    evb_status_t       evb_rc = EVB_STATUS_SUCCESS;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;
    struct ku_spzr_reg spzr_reg;
    sxd_reg_meta_t     spzr_reg_meta;
    int                i = 0;

    SX_LOG_ENTER();

    memset(&spzr_reg_meta, 0, sizeof(sxd_reg_meta_t));

    for (i = 0; i < __swids_count_ib; i++) {
        SX_LOG_DBG("set node description, "
                   "SWID: [%d], device id: [%u], host name: [%s], slot num: [%d], "
                   "slot type: [%d]\n", __swids_db_p_ib[i], dev_id, host_name, slot_num, slot_type);

        memset(&spzr_reg, 0, sizeof(struct ku_spzr_reg));

        /* SWitch partition ID */
        spzr_reg_meta.dev_id = dev_id;
        spzr_reg.swid = __swids_db_p_ib[i];
        spzr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

        /* Node description mask. Set to 1 to write the NodeDescription field */
        spzr_reg.ndm = 1;

        /* Text string that describes the node */
        evb_rc = __ib_prepare_node_desc(host_name, slot_num, (char*)(spzr_reg.node_description));
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed in __build_node_desc, error: %s\n", evb_utils_get_err_str(evb_rc));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }

        sxd_err = sxd_access_reg_spzr(&spzr_reg, &spzr_reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in SPZR set (NODE DESCRIPTION), error: %s\n", SXD_STATUS_MSG(sxd_err));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __ib_set_node_sysguid(IN sxd_dev_id_t dev_id, IN uint64_t sysguid)
{
    evb_status_t       evb_rc = EVB_STATUS_SUCCESS;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;
    struct ku_spzr_reg spzr_reg;
    sxd_reg_meta_t     spzr_reg_meta;
    int                i = 0;

    SX_LOG_ENTER();

    memset(&spzr_reg_meta, 0, sizeof(sxd_reg_meta_t));

    for (i = 0; i < __swids_count_ib; i++) {
        memset(&spzr_reg, 0, sizeof(struct ku_spzr_reg));

        /* SWitch partition ID */
        spzr_reg_meta.dev_id = dev_id;
        spzr_reg.swid = __swids_db_p_ib[i];
        spzr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

        /* Node description mask. Set to 1 to write the NodeDescription field */
        /* Set System Image GUID to system_image_guid specified.
         *  System_image_guid and sig must be the same for all ports.*/
        spzr_reg.sig = 1;
        /* System Image GUID, takes effect only if the sig bit is set.
         *  Must be the same for both ports.*/
        spzr_reg.system_image_guid_h = (sysguid >> 32);
        spzr_reg.system_image_guid_l = (sysguid & 0xFFFFFFFF);

        sxd_err = sxd_access_reg_spzr(&spzr_reg, &spzr_reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in SPZR set (SYSTEM GUID), error: %s\n", SXD_STATUS_MSG(sxd_err));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __ib_set_port_admin_cap(IN sxd_dev_id_t dev_id, IN port_info_t     *port_info_p)
{
    evb_status_t       evb_rc = EVB_STATUS_SUCCESS;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;
    struct ku_ptys_reg ptys_reg;
    struct ku_pmtu_reg pmtu_reg;
    struct ku_pvlc_reg pvlc_reg;
    struct ku_pllp_reg pllp_reg;
    sxd_reg_meta_t     reg_meta;
    int                speed_mask = 0x1ff; /* up to XDR */

    SX_LOG_ENTER();

    SX_LOG_DBG("Device id: [%u], local port: [%d], "
               "port capability: link_width_supported: [%u],    "
               "link_speed_supported: [%u], "
               "mtu_cap: [%u], "
               "vl_cap: [%u], \n"
               , dev_id, port_info_p->port_mapping.local_port,
               port_info_p->link_width_supported,
               port_info_p->port_speed,
               port_info_p->mtu_cap,
               port_info_p->vl_cap
               );

    memset(&ptys_reg, 0, sizeof(struct ku_ptys_reg));
    memset(&pmtu_reg, 0, sizeof(struct ku_pmtu_reg));
    memset(&pvlc_reg, 0, sizeof(struct ku_pvlc_reg));
    memset(&pllp_reg, 0, sizeof(struct ku_pllp_reg));
    memset(&reg_meta, 0, sizeof(sxd_reg_meta_t));

    reg_meta.dev_id = dev_id;

    {
        /* read before write */
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pvlc_reg.local_port, pvlc_reg.lp_msb,
                                            port_info_p->port_mapping.local_port);
        reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        sxd_err = sxd_access_reg_pvlc(&pvlc_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in PVLC get (VL CAP) local_port %u, error: %s\n",
                       pvlc_reg.local_port, SXD_STATUS_MSG(sxd_err));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }

        pvlc_reg.vl_admin = port_info_p->vl_cap;
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

        sxd_err = sxd_access_reg_pvlc(&pvlc_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in PVLC set (VL CAP) local_port %u, vl_admin %u, error: %s\n",
                       pvlc_reg.local_port, pvlc_reg.vl_admin, SXD_STATUS_MSG(sxd_err));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }
    }

    {
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pllp_reg.local_port, pllp_reg.lp_msb,
                                            port_info_p->port_mapping.local_port);
        /* get protocol PLLP */
        reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        sxd_err = sxd_access_reg_pllp(&pllp_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in PLLP get (getting protocol), error: %s, local_port = %u\n",
                       SXD_STATUS_MSG(sxd_err), port_info_p->port_mapping.local_port);
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }

        if (pllp_reg.protocol == 3) { /* NVLink */
            pmtu_reg.protocol = 2;
        } else if (pllp_reg.protocol == 2) { /* IBg1 */
            pmtu_reg.protocol = 1;
        }
    }

    {
        /* read before write */
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pmtu_reg.local_port, pmtu_reg.lp_msb,
                                            port_info_p->port_mapping.local_port);
        reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        sxd_err = sxd_access_reg_pmtu(&pmtu_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in PMTU get (MTU CAP), error: %s\n", SXD_STATUS_MSG(sxd_err));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }

        pmtu_reg.admin_mtu = port_info_p->mtu_cap;
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        sxd_err = sxd_access_reg_pmtu(&pmtu_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in PMTU set (MTU CAP), local port %u, admin MTU %u. "
                       "error: %s\n", port_info_p->port_mapping.local_port, pmtu_reg.admin_mtu,
                       SXD_STATUS_MSG(sxd_err));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }
    }

    {
        uint32_t width;
        uint32_t speed;

        /* read before write */
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(ptys_reg.local_port, ptys_reg.lp_msb,
                                            port_info_p->port_mapping.local_port);
        ptys_reg.proto_mask = 1;
        reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        sxd_err = sxd_access_reg_ptys(&ptys_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in PTYS get (PORT WIDTH & SPEED), error: %s, local_port = %u\n",
                       SXD_STATUS_MSG(sxd_err), port_info_p->port_mapping.local_port);
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }

#if defined(PD_BU) && defined(PD_BU_PTYS_STUB)
        /* Stub for PTYS - FW stub will return 0 for proto capabilities, setting expected number here */
        sxd_access_sdk_ptys_eth_proto_cap_for_pd_set(&ptys_reg);
#endif

        if (ptys_reg.local_port >= 145) {
            /* FNM ports return NDR capability but do not support it
             * Remove NDR capability from this port */
            speed_mask = 0x7f;
        }

        width = ((ptys_reg.ib_link_width_capability & speed_mask)) & port_info_p->link_width_supported;
        speed = (ptys_reg.ib_proto_capability & speed_mask) & port_info_p->port_speed;
        ptys_reg.ib_link_width_admin = width;
        ptys_reg.ib_proto_admin = speed;
        ptys_reg.an_disable_admin = 0; /* an_disable_admin=0 allows to configure more than one speed */
        ptys_reg.ext_ib_proto_admin.ptys_ext_proto_ib.ext_proto_ib = 0; /* ext_ib_proto_admin and ib_proto_admin are mutual exclusive */
        reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        sxd_err = sxd_access_reg_ptys(&ptys_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in PTYS set (PORT TYPE & SPEED), error: %s, local_port = %u\n",
                       SXD_STATUS_MSG(sxd_err), port_info_p->port_mapping.local_port);
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __ib_set_port_state(IN sx_port_log_id_t log_port, IN sx_port_admin_state_t admin_state)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG_INF("Set port state, logical port: [%x], state: [%d]\n",
               log_port, admin_state);

    /* PORT STATE */
    rc = sx_api_port_state_set(__handle,
                               log_port,
                               admin_state);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set port [%x] state : [%s], error: %s\n", log_port,
                   sx_port_admin_state_str(admin_state),
                   sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}


/*****************************************************************************/
/*		                IB HELP FUNCTIONS	                                             */
/*****************************************************************************/

evb_status_t __ib_prepare_node_desc(IN const char* host_name, IN const int slot_num, OUT char*       desc)
{
    int         rc;
    char        slot_name[64];
    char        board_type[64];
    char        host_name_buff[64];
    const char* sys_type_str;
    char      * p;

    #define NODE_DESC_VERSION 0

    if (desc == NULL) {
        return EVB_STATUS_PARAM_NULL;
    }

    board_type[0] = '\0';

    if (host_name) {
        snprintf(host_name_buff, sizeof(host_name_buff), "%s", host_name);
    } else {
        SX_LOG_DBG("Host name is empty, Node desc will not include system name\n");
        snprintf(host_name_buff, sizeof(host_name_buff), "%s", "NA");
    }

    /* Clear bad chars from sys name */
    while ((p = strpbrk(host_name_buff, "/:"))) {
        *p = '_';
    }

    p = desc;

    sys_type_str = "NA";

    /* Format: "MF<version>;sys_name:sys_type/slot_name:board_type" */
    rc = snprintf(p, sizeof(host_name_buff) - 1, "MF%d;%s:%s",
                  NODE_DESC_VERSION,
                  host_name_buff,
                  sys_type_str);

    p += rc;

    snprintf(slot_name, sizeof(slot_num), "L%02d", slot_num);

    if (slot_name[0] != '\0') {
        rc = snprintf(p, sizeof(slot_name), "/%s", slot_name);
        p += rc;

        if (board_type[0] != '\0') {
            rc = snprintf(p, sizeof(board_type), ":%s", board_type);
            p += rc;
        }
    }

    rc = snprintf(p, 4, "/U1");

    return EVB_STATUS_SUCCESS;
}

evb_status_t __ib_set_port_mapping(IN device_t *device_p)
{
    int          i = 0;
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (device_p == NULL) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    /* iterate the array of local ports */
    for (i = 0; i < device_p->port_info_arr_len_ib; i++) {
        if (device_p->port_info_arr_ib[i].port_mapping.mapping_mode == SX_PORT_MAPPING_MODE_DISABLE) {
            continue;
        }
        evb_rc = __set_port_unmapping_per_port(device_p->device_info.dev_id,
                                               &(device_p->port_info_arr_ib[i]),
                                               PORT_SYSTEM_IB);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed in  __set_port_unmapping_per_port, error: %s\n", evb_utils_get_err_str(evb_rc));
            goto out;
        }
    }

    /* iterate the array of local ports */
    for (i = 0; i < device_p->port_info_arr_len_ib; i++) {
        if (device_p->port_info_arr_ib[i].port_mapping.mapping_mode == SX_PORT_MAPPING_MODE_DISABLE) {
            continue;
        }
        evb_rc = __set_port_mapping_per_port(device_p->device_info.dev_id,
                                             &(device_p->port_info_arr_ib[i]),
                                             PORT_SYSTEM_IB);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed in  __set_port_mapping_per_port, error: %s\n", evb_utils_get_err_str(evb_rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}


/*
 * Register based swid initialization
 */
evb_status_t __ib_evb_sdk_self_init_swids(uint8_t swid_bmap)
{
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;
    uint8_t      swid_val = 0;
    sx_swid_t    swids_eth[SXD_SWID_ID_COUNT];
    sx_swid_t    swids_ib[SXD_SWID_ID_COUNT];

    SX_LOG_ENTER();

    memset((swids_eth), 0, sizeof(swids_eth));
    memset((swids_ib), 0, sizeof(swids_ib));

    /* when there is no SWID, add default SWID(0) */
    if (swid_bmap == 0) {
        swids_ib[__swids_count_ib] = SXD_SWID_MIN;
        __swids_count_ib++;
    }

    while (swid_bmap != 0) {
        if (swid_bmap & 0x01) {
            swids_ib[__swids_count_ib] = swid_val;
            __swids_count_ib++;
        }
        swid_bmap = swid_bmap >> 1;
        swid_val++;
    }

    /* allocate memory */
    evb_rc = EVB_UTILS_CLR_MEM_GET(&__swids_db_p_ib, __swids_count_ib, sizeof(sx_swid_t));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to allocate memory for swids_arr_p , error: %s\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }
    memcpy(__swids_db_p_ib, swids_ib, (__swids_count_ib * sizeof(sx_swid_t)));
out:
    SX_LOG_EXIT();
    return evb_rc;
}


/*
 * Register based local port and swid initialization
 */
evb_status_t __ib_evb_sdk_self_init_swid_ports(OUT device_t *device_p, boolean_t use_2nd_bonus_port)
{
    uint8_t              swid_bmap = 0x00;
    struct ku_ptys_reg   ptys_reg;
    struct ku_pspa_reg   pspa_reg;
    uint32_t             index = 0;
    sxd_reg_meta_t       reg_meta;
    sxd_status_t         sxd_err = SXD_STATUS_SUCCESS;
    evb_status_t         evb_rc = EVB_STATUS_SUCCESS;
    evb_status_t         rc = EVB_STATUS_SUCCESS;
    sx_status_t          sx_err = SX_STATUS_SUCCESS;
    port_info_t         *port_info_arr_ib = NULL;
    int                  port_info_arr_ib_len = 0;
    sx_chip_types_t      chip_type = SX_CHIP_TYPE_UNKNOWN;
    struct ku_query_rsrc rsrc_info;
    uint32_t             max_ports;

    SX_LOG_ENTER();
    memset(&(reg_meta), 0, sizeof(reg_meta));
    reg_meta.dev_id = EVB_DEFAULT_DEVICE_NUMBER;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    memset(&rsrc_info, 0, sizeof(rsrc_info));
    rsrc_info.rsrc_id = KU_RES_ID_CAP_MAX_SWITCH_PORTS;

    sxd_err = sxd_access_reg_query_rsrc_info(&rsrc_info);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed in FW command Query_RSRC error: %s\n", SXD_STATUS_MSG(sxd_err));
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    } else {
        max_ports = rsrc_info.rsrc_val;

        sx_err = __get_chip_type(__handle, &chip_type);
        if (SX_CHECK_FAIL(sx_err)) {
            printf("__get_chip_type failed (%s)\n", sx_status_str(sx_err));
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }

        if (!use_2nd_bonus_port && (max_ports == 258)) {
            max_ports = 257;
        }
    }

    evb_rc = EVB_UTILS_CLR_MEM_GET(&port_info_arr_ib, max_ports, sizeof(port_info_t));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to allocate memory for devices ib port array , error: %s\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }

    for (index = 1; index <= max_ports; index++) {
        memset(&pspa_reg, 0, sizeof(pspa_reg));
        reg_meta.swid = 0;
        pspa_reg.swid = 0;
        pspa_reg.sub_port = 0;
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pspa_reg.local_port, pspa_reg.lp_msb, index);

        /* Find the port/ swid mapping */
        sxd_err = sxd_access_reg_pspa(&pspa_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in PSPA get (PORT Switch Partition Allocation), error: %s, local_port = %u\n",
                       SXD_STATUS_MSG(sxd_err), index);
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }

        if (pspa_reg.swid != 0xFF) { /* swid (0xFF) is disabled port */
            if (pspa_reg.swid <= SXD_SWID_MAX) {
                swid_bmap |= 1 << pspa_reg.swid;
            }
            reg_meta.swid = pspa_reg.swid;
            memset(&ptys_reg, 0, sizeof(ptys_reg));
            SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(ptys_reg.local_port, ptys_reg.lp_msb, index);

            ptys_reg.proto_mask = EVB_PORT_TYPE_PROTOCOL_MASK_IB;

            sxd_err = sxd_access_reg_ptys(&ptys_reg, &reg_meta, 1, NULL, NULL);
            if (SXD_CHECK_FAIL(sxd_err)) {
                SX_LOG_ERR("Failed in PTYS get (PORT SPEED and CAPABILITY), error: %s, local_port = %u\n",
                           SXD_STATUS_MSG(sxd_err), index);
                evb_rc = EVB_STATUS_ERROR;
                goto out;
            }

#if defined(PD_BU) && defined(PD_BU_PTYS_STUB)
            /* Stub for PTYS - FW stub will return 0 for proto capabilities, setting expected number here */
            sxd_access_sdk_ptys_eth_proto_cap_for_pd_set(&ptys_reg);
#endif
            evb_rc = __evb_ib_port_update_reg_info(&port_info_arr_ib[port_info_arr_ib_len],
                                                   index,
                                                   ptys_reg,
                                                   reg_meta);
            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("Failed to initialize ib ports from pvlc, pmtu reg , error: %s\n",
                           evb_utils_get_err_str(evb_rc));
                goto out;
            }

            evb_rc = __ib_evb_sdk_self_init_port(&port_info_arr_ib[port_info_arr_ib_len],
                                                 index,
                                                 pspa_reg.swid);
            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("Failed to self initialize ports, error: %s\n",  evb_utils_get_err_str(evb_rc));
                goto out;
            }
            port_info_arr_ib_len++;
        }
    }

    device_p->port_info_arr_len_ib = port_info_arr_ib_len;
    /* allocate memory for port_info_arr in device db*/
    if (port_info_arr_ib_len != 0) {
        evb_rc = EVB_UTILS_CLR_MEM_GET(&device_p->port_info_arr_ib, port_info_arr_ib_len, sizeof(port_info_t));
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed to allocate memory for device port info , error: %s\n", evb_utils_get_err_str(
                           evb_rc));
            goto out;
        }
        memcpy(device_p->port_info_arr_ib, port_info_arr_ib, (port_info_arr_ib_len * sizeof(port_info_t)));
    }

    evb_rc = __ib_evb_sdk_self_init_swids(swid_bmap);

out:
    if (port_info_arr_ib) {
        rc = EVB_PORT_UTILS_MEM_PUT(port_info_arr_ib);
        if (EVB_STATUS_SUCCESS != rc) {
            evb_rc = rc;
            SX_LOG_ERR("Failed to free port attributes. Err = %d\n", evb_rc);
        }
    }
    SX_LOG_EXIT();
    return evb_rc;
}


/*
 * Register based local port initialization
 */
evb_status_t __ib_evb_sdk_self_init_port(port_info_t *port_info_p, int local_port, sx_swid_t swid)
{
    struct ku_pmlp_reg pmlp_reg;
    struct ku_pllp_reg pllp_reg;
    sxd_reg_meta_t     reg_meta;
    int                lane;
    evb_status_t       evb_rc = EVB_STATUS_SUCCESS;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (port_info_p == NULL) {
        SX_LOG_ERR("__evb_sdk_self_init_port null parameter\n");
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    memset(&(reg_meta), 0, sizeof(reg_meta));
    reg_meta.dev_id = EVB_DEFAULT_DEVICE_NUMBER;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.swid = swid;
    memset(&pmlp_reg, 0, sizeof(pmlp_reg));
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pmlp_reg.local_port, pmlp_reg.lp_msb, local_port);

    sxd_err = sxd_access_reg_pmlp(&pmlp_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed in PMLP get (PORT Switch Partition Allocation), error: %s, local_port = %u\n",
                   SXD_STATUS_MSG(sxd_err), local_port);
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

    port_info_p->port_mapping.local_port = local_port;
    evb_rc = __evb_sdk_self_init_port_defaults(port_info_p);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to initialize port defaults, error: %s\n",  evb_utils_get_err_str(evb_rc));
        goto out;
    }

    port_info_p->swid = swid;

    if (swid == SX_SWID_ID_STACKING) {
        port_info_p->port_mode = SX_PORT_MODE_STACKING;
    } else {
        port_info_p->port_mode = SX_PORT_MODE_EXTERNAL;
    }

    port_info_p->port_mapping.module_port = pmlp_reg.module[0];
    port_info_p->port_mapping.slot = pmlp_reg.slot[0];
    port_info_p->port_mapping.width = pmlp_reg.width;
    port_info_p->module_lane_map.use_different_rx_tx = pmlp_reg.use_different_rx_tx;
    for (lane = 0; lane < pmlp_reg.width; lane++) {
        port_info_p->port_mapping.lane_bmap |= (1 << pmlp_reg.lane[lane]);
        port_info_p->module_lane_map.module[lane] = pmlp_reg.module[lane];
        port_info_p->module_lane_map.slot[lane] = pmlp_reg.slot[lane];
        port_info_p->module_lane_map.lane[lane] = pmlp_reg.lane[lane];
        if (pmlp_reg.use_different_rx_tx) {
            port_info_p->module_lane_map.rx_lane[lane] = pmlp_reg.rx_lane[lane];
        } else {
            port_info_p->module_lane_map.rx_lane[lane] = 0;
        }
    }

    memset(&pllp_reg, 0, sizeof(pllp_reg));
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pllp_reg.local_port, pllp_reg.lp_msb, local_port);
    /* get label port using PLLP */
    sxd_err = sxd_access_reg_pllp(&pllp_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed in PLLP get (getting label port), error: %s, local_port = %u\n",
                   SXD_STATUS_MSG(sxd_err), local_port);
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }
    port_info_p->label_port = pllp_reg.label_port;


out:
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __ib_evb_sdk_xml_init(void)
{
    evb_status_t evb_rc;

    /*****************************************************************************/
    /*		               PARSING SECTION				                         */
    /*****************************************************************************/

    /* parse device count section in the XML file */
    evb_rc = __parse_device_count_section(&__device_count);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to fetch number of devices in file , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* allocate memory for device DB */
    evb_rc = EVB_UTILS_CLR_MEM_GET(&__device_db_p, __device_count, sizeof(device_t));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to allocate memory for devices array , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* parse swids section in the XML file */
    evb_rc = __parse_swid_section(&(__swids_count_ib), &(__swids_db_p_ib), "swids");
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in __parse_swid_section , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    evb_rc = __ib_handle_profile();
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in  __handle_ib_profile, error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

out:

    return evb_rc;
}


evb_status_t __ib_parse_port_info_section(IN sx_xml_element_t *child_p, OUT port_info_t     *port_info_p)
{
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;
    int          ret_value = 0;
    int          ignore_info = 0;
    int          i = 0;

    SX_LOG_ENTER();

    if (port_info_p == NULL) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    sx_xml_element_t *local_port_element = sx_xml_element_by_name_get(
        child_p, "local-port");
    sx_xml_element_t *port_label_element = sx_xml_element_by_name_get(
        child_p, "port-label");
    sx_xml_element_t *width_element = sx_xml_element_by_name_get(
        child_p, "width");
    sx_xml_element_t *lanes_element = sx_xml_element_by_name_get(
        child_p, "lanes");
    sx_xml_element_t *lane_to_module_element = sx_xml_element_by_name_get(
        child_p, "lane-to-module");
    sx_xml_element_t *lane_to_slot_element = sx_xml_element_by_name_get(
        child_p, "lane-to-slot");
    sx_xml_element_t *port_speed_element = sx_xml_element_by_name_get(
        child_p, "port-speed");
    sx_xml_element_t *port_state_element = sx_xml_element_by_name_get(
        child_p, "port-state");
    sx_xml_element_t *swid_element = sx_xml_element_by_name_get(
        child_p, "swid");
    sx_xml_element_t *mtu_element = sx_xml_element_by_name_get(
        child_p, "mtu_cap");
    sx_xml_element_t *vl_cap_element = sx_xml_element_by_name_get(
        child_p, "vl_cap");
    sx_xml_element_t *link_width_element = sx_xml_element_by_name_get(
        child_p, "link_width");
    sx_xml_element_t *port_mode_element = sx_xml_element_by_name_get(
        child_p, "port-mode");
    sx_xml_element_t *mapping_mode_element = sx_xml_element_by_name_get(
        child_p, "mapping-mode");

    if (local_port_element != NULL) {
        port_info_p->port_mapping.local_port = atoi(sx_xml_element_content_get(
                                                        local_port_element));
    } else {
        SX_LOG_ERR("Error parsing local port number\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (port_mode_element != NULL) {
        port_info_p->port_mode = atoi(sx_xml_element_content_get(
                                          port_mode_element));
    } else {
        SX_LOG_ERR("Error parsing link width value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (port_info_p->port_mode == SX_PORT_MODE_TCA_CONNECTOR) {
        ignore_info = 1;
    }

    if (port_label_element != NULL) {
        port_info_p->label_port = atoi(sx_xml_element_content_get(
                                           port_label_element));
    } else {
        SX_LOG_ERR("Error parsing label port number\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (mapping_mode_element != NULL) {
        port_info_p->port_mapping.mapping_mode = atoi(sx_xml_element_content_get(
                                                          mapping_mode_element));
    } else { /* Make default mapping mode for IB enabled */
        port_info_p->port_mapping.mapping_mode = SX_PORT_MAPPING_MODE_ENABLE;
    }

    if (!ignore_info) {
        if (width_element != NULL) {
            port_info_p->port_mapping.width = atoi(sx_xml_element_content_get(
                                                       width_element));
        } else {
            SX_LOG_ERR("Error parsing width value\n");
            evb_rc = EVB_STATUS_PARSE_ERROR;
        }

        if (lanes_element != NULL) {
            char *lanes_str = (char*)sx_xml_element_content_get(lanes_element);
            int   lane_bmap = 0;

            if (lanes_str != NULL) {
                ret_value = sscanf(lanes_str, "%hhd , %hhd , %hhd , %hhd",
                                   &(port_info_p->module_lane_map.lane[0]),
                                   &(port_info_p->module_lane_map.lane[1]),
                                   &(port_info_p->module_lane_map.lane[2]),
                                   &(port_info_p->module_lane_map.lane[3]));

                if (ret_value == EOF) {
                    SX_LOG_ERR("Error parsing lanes value , local port: [%d]\n",
                               port_info_p->port_mapping.local_port);
                    evb_rc = EVB_STATUS_PARSE_ERROR;
                }
                for (i = 0; i < port_info_p->port_mapping.width; i++) {
                    lane_bmap += 1 << port_info_p->module_lane_map.lane[i];
                }
                port_info_p->port_mapping.lane_bmap = lane_bmap;
            }
        } else {
            SX_LOG_ERR("Error parsing lanes value , local port: [%d]\n", port_info_p->port_mapping.local_port);
            evb_rc = EVB_STATUS_PARSE_ERROR;
        }

        if (lane_to_module_element != NULL) {
            char *lane_to_module_str = (char*)sx_xml_element_content_get(lane_to_module_element);

            if (lane_to_module_str != NULL) {
                ret_value = sscanf(lane_to_module_str, "%hhd , %hhd , %hhd , %hhd",
                                   &(port_info_p->module_lane_map.module[0]),
                                   &(port_info_p->module_lane_map.module[1]),
                                   &(port_info_p->module_lane_map.module[2]),
                                   &(port_info_p->module_lane_map.module[3]));
                port_info_p->port_mapping.module_port = port_info_p->module_lane_map.module[0];
                if (ret_value == EOF) {
                    SX_LOG_ERR("Error parsing lane to module value , local port: [%d]\n",
                               port_info_p->port_mapping.local_port);
                    evb_rc = EVB_STATUS_PARSE_ERROR;
                }
            }
        } else {
            SX_LOG_ERR("Error parsing lane to module value , local port: [%d]\n",
                       port_info_p->port_mapping.local_port);
            evb_rc = EVB_STATUS_PARSE_ERROR;
        }

        if (lane_to_slot_element != NULL) {
            char *lane_to_slot_str = (char*)sx_xml_element_content_get(lane_to_slot_element);
            if (lane_to_slot_str != NULL) {
                ret_value = sscanf(lane_to_slot_str, "%hhd , %hhd , %hhd , %hhd",
                                   &(port_info_p->module_lane_map.slot[0]),
                                   &(port_info_p->module_lane_map.slot[1]),
                                   &(port_info_p->module_lane_map.slot[2]),
                                   &(port_info_p->module_lane_map.slot[3]));

                port_info_p->port_mapping.slot = port_info_p->module_lane_map.slot[0];
                if (ret_value == EOF) {
                    SX_LOG_ERR("Error parsing lane to slot value , local port: [%d]\n",
                               port_info_p->port_mapping.local_port);
                    evb_rc = EVB_STATUS_PARSE_ERROR;
                }
            }
        } else {
            port_info_p->port_mapping.slot = 0;
            SX_LOG_DBG("Default Lane to slot value(0) assigned to  local port: [%d]\n",
                       port_info_p->port_mapping.local_port);
        }

        if (port_speed_element != NULL) {
            port_info_p->port_speed = atoi(sx_xml_element_content_get(
                                               port_speed_element));
        } else {
            SX_LOG_ERR("Error parsing port speed value\n");
            evb_rc = EVB_STATUS_PARSE_ERROR;
        }
    }

    if (port_state_element != NULL) {
        port_info_p->port_state = atoi(sx_xml_element_content_get(
                                           port_state_element));
    } else {
        SX_LOG_ERR("Error parsing port state value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (swid_element != NULL) {
        port_info_p->swid = atoi(sx_xml_element_content_get(
                                     swid_element));
    } else {
        SX_LOG_ERR("Error parsing swid value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (!ignore_info) {
        if (mtu_element != NULL) {
            port_info_p->mtu_cap = atoi(sx_xml_element_content_get(
                                            mtu_element));
        } else {
            SX_LOG_ERR("Error parsing mtu_cap value\n");
            evb_rc = EVB_STATUS_PARSE_ERROR;
        }

        if (vl_cap_element != NULL) {
            port_info_p->vl_cap = atoi(sx_xml_element_content_get(
                                           vl_cap_element));
        } else {
            SX_LOG_ERR("Error parsing vl_cap value\n");
            evb_rc = EVB_STATUS_PARSE_ERROR;
        }

        if (link_width_element != NULL) {
            port_info_p->link_width_supported = atoi(sx_xml_element_content_get(
                                                         link_width_element));
        } else {
            SX_LOG_ERR("Error parsing link width value\n");
            evb_rc = EVB_STATUS_PARSE_ERROR;
        }
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}
