#!/bin/bash
#
# Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #

me=$(basename "$0")

log_msg() {
    local msg="${1}"
    echo "${msg}"
    logger -it "${me}" "${msg}" 2> /dev/null
}

log_msg "*** DVS Kexec started ***"
log_msg "${me} ${*}"

usage()
{
    echo "The script kexecs the current running kernel."
    echo "Usage $0 [--force]"
    echo "--force         When force flag is given, the script will do the kexec directly without a prompt."
}

basedir=`readlink -f $0`
basedir=${basedir%/*}

grub_dirs="/boot/grub /mnt/onl/boot/grub /host/grub"
boot_dirs="/boot /mnt/onl/boot"
kernel_image_name=""
initrd_name=""
boot_dir=""
force=0

while [ "`echo $1 | cut -c1`" = "-" ]
do
    flag=${1%=*}
    param=${1#*=}

    case "$flag" in
        --force)
            force=1
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        -h | --help)
            usage
            exit 0
            ;;
        *)
            usage
            exit 1
            ;;
    esac
done

if [ $force == 0 ]; then
    while true; do
        read -p "This script is about to kexec the current running kernel, do you wish to continue? " yn
        case $yn in
            [Yy]* ) break;;
            [Nn]* ) exit 0;;
            * ) echo "Please answer yes or no.";;
        esac
    done
fi

# SPC4 setups uses UEFI, kernel_image and initrd names contains linuxefi and initrdefi, so needs to be covered by the regex used in grep.
efi_suffix=""
if test -d /sys/firmware/efi/efivars; then
    efi_suffix="efi"
fi

for dir in $grub_dirs; do
    if [ -e $dir/grub.cfg ]; then
        kernel_image_name=$(grep -E "\s*linux${efi_suffix}\s+/" $dir/grub.cfg | head -n1 | awk '{print $2}' | rev | cut -d'/' -f 1 | rev)
        initrd_name=$(grep -E "\s*initrd${efi_suffix}\s+/" $dir/grub.cfg | head -n1 | awk '{print $2}' | rev | cut -d'/' -f 1 | rev)
        break
    fi
done

if [[ $kernel_image_name =~ ^[[:space:]]+$ ]] || [ -z $kernel_image_name ] || [[ $initrd_name =~ ^[[:space:]]+$ ]] || [ -z $initrd_name ]; then
    log_msg "ERROR: Could not determine the kernel image name or initrd image name"
    exit 1
fi

boot_dir=""
for dir in $boot_dirs; do
    if [ -e $dir/$kernel_image_name ] && [ -e $dir/$initrd_name ]; then
        boot_dir=$dir
        break
    fi
done

if [ "$boot_dir" == "" ]; then
    log_msg "ERROR: Failed to find boot dir containing the kernel image and/or the initrd image"
    exit 1
fi

kexec_cmd="kexec -l ${boot_dir}/${kernel_image_name} --initrd=${boot_dir}/${initrd_name} --reuse-cmdline"
log_msg "Running '${kexec_cmd}'"
${kexec_cmd}
log_msg "Running 'kexec -e' | CPU Will Reboot!"
kexec -e
