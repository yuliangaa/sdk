#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


usage()
{
    echo ""
    echo "The script enables Spectrum PLD software"

    echo "Usage: $0 --prm_sniffer"

    echo "When prm_sniffer flag is not given, prm_sniffer will not record."
    echo "When prm_sniffer_file_path is not given, default path(/tmp/prm_recording.log) will be used."
    echo ""
}

profile="eth-single"
target="rpp_4_ports"
sdk_applibs_modules="all"

while [ "`echo $1 | cut -c1`" = "-" ]
do                 
                                                             
    # Params with arguments          
    flag=${1%=*}                     
    param=${1#*=}   
                    
    case "$flag" in                       
        --sxd_sniffer)
            sxd_sniffer=1
            shift 1
            continue # Skip to next param.
            ;;
    esac
    
    case "$flag" in
        --sxd_sniffer_file_path)
            param=${1#*=}
            sxd_sniffer_file_path=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac
                      
    case "$flag" in                       
        --prm_sniffer)
            prm_sniffer=1
            shift 1
            continue # Skip to next param.
            ;;
    esac
    
    case "$flag" in
        --prm_sniffer_file_path)
            param=${1#*=}
            prm_sniffer_file_path=$param
            shift 1
            continue # Skip to next param.
            ;;
    esac

    case "$flag" in
        -h | --help)
           usage
           exit 0
            ;;
        *)
            usage
            exit 1
            ;;
    esac
done

if [[ "$sxd_sniffer" == "1" ]]
then
    export SXD_SNIFFER="1"
    export SXD_SNIFFER_FILE_PATH="$sxd_sniffer_file_path"
    echo "sxd_sniffer_activated"
fi

if [[ "$prm_sniffer" == "1" ]]
then
    export PRM_SNIFFER="1"
    export PRM_SNIFFER_FILE_PATH="$prm_sniffer_file_path"
    echo "prm_sniffer_activated"
fi


evb_start.sh ${profile} ${target} ${sdk_applibs_modules}