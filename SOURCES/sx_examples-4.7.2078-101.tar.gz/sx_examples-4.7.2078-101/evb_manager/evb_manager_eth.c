/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "evb_manager.h"
#include "topo_parse_manager.h"
#include "evb_manager_eth.h"

#undef  __MODULE__
#define __MODULE__ EVB_MANAGER_ETH

extern sx_bridge_mode_t sdk_bridge_mode;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

evb_status_t __parse_eth_device_params_section(OUT device_t        *device_p,
                                               IN sx_xml_element_t *child_p,
                                               IN int              *static_mac_entries_count_p,
                                               IN boolean_t         issu_start,
                                               IN boolean_t         pdb_port_map_init,
                                               IN boolean_t         use_2nd_bonus_port)
{
    evb_status_t      evb_rc = EVB_STATUS_SUCCESS; /* return value for EVB manager APIs */
    sx_xml_element_t *child_dev_number = NULL;
    sx_xml_element_t *child_dev_mac_address = NULL;
    sx_xml_element_t *child_dev_transaction_mode = NULL;
    int               actual_static_mac_entries = 0, tmp = 0;
    sx_mac_addr_t    *base_mac_addr;

    SX_LOG_ENTER();

    if ((device_p == NULL) || (child_p == NULL)) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    /*****************************************************************************/
    /*		               PARSING SECTION				     */
    /*****************************************************************************/
    child_dev_number = sx_xml_element_by_name_get(child_p, "device-number");
    child_dev_mac_address = sx_xml_element_by_name_get(child_p, "device-mac-address");

    if (child_dev_number) {
        device_p->device_info.dev_id = atoi(sx_xml_element_content_get(
                                                child_dev_number));
    } else {
        SX_LOG_ERR("Error parsing dev_number\n");
    }

    if (child_dev_mac_address) {
        base_mac_addr = ether_aton(sx_xml_element_content_get(child_dev_mac_address));
        if (base_mac_addr == NULL) {
            SX_LOG_ERR("Error parsing device mac address\n");
            evb_rc = EVB_STATUS_PARSE_ERROR;
            goto out;
        }

        memcpy(&(device_p->base_mac_addr), base_mac_addr, sizeof(sx_mac_addr_t));
    } else {
        SX_LOG_ERR("Error parsing device MAC address\n");
    }

    /* set node type as leaf */
    device_p->device_info.node_type = SX_DEV_NODE_TYPE_LEAF;

    device_p->transaction_mode_en = FALSE;
    child_dev_transaction_mode = sx_xml_element_by_name_get(child_p, "transaction-mode-en");
    if (child_dev_transaction_mode) {
        tmp = atoi(sx_xml_element_content_get(child_dev_transaction_mode));
        if (tmp == 1) {
            device_p->transaction_mode_en = TRUE;
        }
    }

    /*****************************************************************************/
    /*		               PARSE PORT INFO LIST			     */
    /*****************************************************************************/
    if ((issu_start == FALSE) || (pdb_port_map_init == FALSE)) {
        evb_rc = __parse_device_ports_list_section(
            PROFILE_ETH,
            child_p,
            &(device_p->port_info_arr_eth),
            &(device_p->port_info_arr_len_eth));
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Error parsing device ports list\n");
            goto out;
        }
    } else {
        /* Initialize ethernet ports */
        evb_rc = __eth_evb_sdk_self_init_swid_ports(device_p, use_2nd_bonus_port);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("sdk self init Failed to initialize eth ports , error: %s\n",  evb_utils_get_err_str(evb_rc));
            goto out;
        }
    }

    /* logical ports array length should be the same as the physical ports array length */
    device_p->log_ports_arr_len = device_p->port_info_arr_len_eth;
    device_p->device_info.num_ports = device_p->port_info_arr_len_eth;

    /*****************************************************************************/
    /*		               PARSE STATIC MAC ENTRIES section			     */
    /*****************************************************************************/

    evb_rc = __parse_fdb_static_mac_count_section(child_p, static_mac_entries_count_p);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Error parsing FDB static MAC count\n");
        goto out;
    }

    actual_static_mac_entries = static_mac_entries_count_p[0];

    evb_rc = __parse_static_fdb_entry_section(&actual_static_mac_entries, child_p,
                                              &(device_p->uc_mac_arr));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Error parsing static FDB entry\n");
        goto out;
    }

    device_p->uc_mac_arr_len = actual_static_mac_entries;


out:
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __parse_fdb_static_mac_count_section(IN sx_xml_element_t *child_p, OUT int *static_entries_count_p)
{
    evb_status_t      evb_rc = EVB_STATUS_SUCCESS;
    sx_xml_element_t *child_number_of_routes = sx_xml_element_by_name_get(
        child_p, "number-of-static-entries");

    SX_LOG_ENTER();

    if (static_entries_count_p == NULL) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    if (child_number_of_routes != NULL) {
        static_entries_count_p[0] = atoi(sx_xml_element_content_get(
                                             child_number_of_routes));
    } else {
        SX_LOG_ERR("Error parsing number of static mac entries\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __parse_eth_device_state_section(IN sx_xml_element_t *child_p)
{
    evb_status_t      evb_rc = EVB_STATUS_ERROR; /* return value for EVB manager APIs */
    sx_xml_element_t *child_dev_state = NULL;

    child_dev_state = sx_xml_element_by_name_get(child_p, "device-state");
    if (child_dev_state) {
        if (atoi(sx_xml_element_content_get(child_dev_state))) {
            evb_rc = EVB_STATUS_SUCCESS;
        }
    }

    return evb_rc;
}

/**
 * This function set the following port properties on the port profile according to the parsed port info section:
 * 1. port RSTP state
 * 2. port speed
 * 3. port state
 * 4. port default VLAN
 * 5. phys loopback
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */

evb_status_t __evb_add_function_to_profile(device_t        *device_p,
                                           sx_port_log_id_t port_profile_id,
                                           int              base_port,
                                           boolean_t        port_state_down_mode,
                                           uint8_t          port_speed_rate_mode)
{
    evb_status_t               evb_rc = EVB_STATUS_SUCCESS;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_port_speed_capability_t admin_speed;
    sx_port_rate_bitmask_t     admin_rate;

    rc = sx_api_port_swid_bind_set(__handle,
                                   port_profile_id,
                                   device_p->port_info_arr_eth[base_port].swid);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in sx_api_port_swid_bind_set , error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }

    rc = sx_api_port_init_set(__handle, port_profile_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in sx_api_port_init_set , error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }

    /* RSTP STATE */
    if (device_p->port_info_arr_eth[base_port].port_mode == SX_PORT_MODE_EXTERNAL) {
        rc = sx_api_rstp_port_state_set(__handle,
                                        port_profile_id,
                                        device_p->port_info_arr_eth[base_port].mstp_port_state
                                        );
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set port [%x] rstp state , error: %s\n",
                       port_profile_id,
                       sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }
    }

    /* Check whether we must invoke Legacy API for port speed configuration,
     *  or new API which allows to configure 200Gbps, and 400Gbps  */
    evb_rc =
        __port_rate_convert_bitmap(device_p->port_info_arr_eth[base_port].port_speed,
                                   &(device_p->port_info_arr_eth[base_port].port_ext_api_type), &admin_rate);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to convert port [%x] speed value, error: %s\n",
                   device_p->log_ports_arr[base_port],
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* Check whether we need to use new port speed configuration API */
    if (((port_speed_rate_mode == SX_PORT_SPEED_RATE_MODE_DEFAULT_E) &&
         (device_p->port_info_arr_eth[base_port].port_ext_api_type == TRUE)) ||
        (port_speed_rate_mode == SX_PORT_SPEED_RATE_MODE_RATE_E)) {
        rc = sx_api_port_rate_set(__handle, port_profile_id, &admin_rate);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set port [%x] speed , error: %s\n", port_profile_id,
                       sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }
    } else {
        /* PORT SPEED */
        evb_rc = __port_speed_convert_bitmap_to_capability(device_p->port_info_arr_eth[base_port].port_speed,
                                                           &admin_speed);

        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed to set port [%x] speed , error: %s\n", port_profile_id,
                       sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }


        rc = sx_api_port_speed_admin_set(__handle,
                                         port_profile_id,
                                         &admin_speed
                                         );

        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set port [%x] speed , error: %s\n", port_profile_id,
                       sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }
    }

    /* PORT PHYS LOOPBACK */
    rc = sx_api_port_state_set(__handle,
                               port_profile_id,
                               SX_PORT_ADMIN_STATUS_DOWN);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set port [%x] state DOWN, error: %s\n", port_profile_id,
                   sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }

    rc = sx_api_port_phys_loopback_set(__handle,
                                       port_profile_id,
                                       device_p->port_info_arr_eth[base_port].phys_loopback);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set port [%x] phys loopback [%u]. error: %s\n",
                   port_profile_id,
                   device_p->port_info_arr_eth[base_port].phys_loopback,
                   sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }

    /* PORT STATE */
    if (port_state_down_mode == FALSE) {
        rc = sx_api_port_state_set(__handle,
                                   port_profile_id,
                                   device_p->port_info_arr_eth[base_port].port_state
                                   );
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set port [%x] state : [%s], error: %s\n", port_profile_id,
                       sx_port_admin_state_str(device_p->port_info_arr_eth[base_port].port_state),
                       sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }
    }

    /* PORT default VLAN */
    if (device_p->port_info_arr_eth[base_port].port_mode == SX_PORT_MODE_EXTERNAL) {
        rc = sx_api_vlan_port_pvid_set(__handle,
                                       SX_ACCESS_CMD_ADD,
                                       port_profile_id,
                                       device_p->port_info_arr_eth[base_port].vid
                                       );
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set port [%x] default vid [%u], error: %s\n", port_profile_id,
                       device_p->port_info_arr_eth[base_port].vid,
                       sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }

        if ((sdk_bridge_mode == SX_MODE_802_1Q) || (sdk_bridge_mode == SX_MODE_HYBRID)) {
            rc = sx_api_vlan_port_ingr_filter_set(__handle,
                                                  port_profile_id, SX_INGR_FILTER_ENABLE);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set port [%x] vlan_ingress_filter enable, error: %s\n",
                           port_profile_id, sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }
        }
    }
out:
    return evb_rc;
}

evb_status_t __issu_get_all_lag_members_ports(cl_qmap_t *port_in_lag_map, uint32_t port_list_cnt)
{
    sx_status_t      rc = SX_STATUS_SUCCESS;
    evb_status_t     evb_rc = EVB_STATUS_SUCCESS;
    uint             j = 0, k = 0;
    uint32_t         port_in_lag_cnt = port_list_cnt;
    sx_port_log_id_t log_port_list[port_list_cnt], port_in_lag_list[port_in_lag_cnt];
    sx_port_type_t   port_type;
    port_map_item_t *port_map_item_p;

    rc = sx_api_port_swid_port_list_get(__handle, 0, log_port_list, &port_list_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get LAG list, error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }

    for (j = 0; j < port_list_cnt; j++) {
        port_type = SX_PORT_TYPE_ID_GET(log_port_list[j]);
        if ((SX_PORT_TYPE_LAG == port_type)) {
            port_in_lag_cnt = port_list_cnt;
            rc = sx_api_lag_port_group_get(__handle, 0, log_port_list[j], port_in_lag_list, &port_in_lag_cnt);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get LAG ports list, error: %s\n", sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }
            for (k = 0; k < port_in_lag_cnt; k++) {
                port_map_item_p = (port_map_item_t*)malloc(sizeof(port_map_item_t));
                if (!port_map_item_p) {
                    SX_LOG_ERR("Failed to allocate memory for tree port_list_item_p, error: %d\n", rc);
                    return EVB_STATUS_NO_MEMORY;
                }
                port_map_item_p->port_log_id = port_in_lag_list[k];
                cl_qmap_insert(port_in_lag_map,
                               port_in_lag_list[k],
                               &(port_map_item_p->map_item));
            }
        }
    }
out:
    return evb_rc;
}

evb_status_t __get_device_mac_address_str(IN sx_xml_element_t *child_p, char *dev_mac_str)
{
    evb_status_t      evb_rc = EVB_STATUS_SUCCESS; /* return value for EVB manager APIs */
    sx_xml_element_t *child_dev_mac_address = NULL;
    char             *tmp_str;

    child_dev_mac_address = sx_xml_element_by_name_get(child_p, "device-mac-address");
    if (child_dev_mac_address) {
        tmp_str = (char*)sx_xml_element_content_get(child_dev_mac_address);
        if (tmp_str == NULL) {
            SX_LOG_ERR("Error parsing device mac address\n");
            evb_rc = EVB_STATUS_PARSE_ERROR;
            goto out;
        }

        memcpy(dev_mac_str, tmp_str, 17);
        dev_mac_str[17] = '\0';
    } else {
        SX_LOG_ERR("Error parsing device MAC address\n");
        evb_rc = EVB_STATUS_ERROR;
    }

out:
    return evb_rc;
}

evb_status_t __set_mac_addresses(IN sx_xml_element_t *child_p)
{
    int          i;
    char         cmd[200];
    char         dev_mac[18];
    char        *dev_mac_zero = "00:00:00:00:00:00";
    int          system_err;
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;  /* return value for EVB manager APIs */

    evb_rc = __get_device_mac_address_str(child_p, dev_mac);
    if (evb_rc != EVB_STATUS_SUCCESS) {
        return evb_rc;
    }

    if (0 == strcmp(dev_mac, dev_mac_zero)) {
        SX_LOG_ERR("Error mac cannot be 00:00:00:00:00:00\n");
        evb_rc = EVB_STATUS_PARAM_ERROR;
        goto out;
    }

    for (i = 0; i < __swids_count_eth; i++) {
        sprintf(cmd, "ifconfig swid%u_eth hw ether %s > /dev/null 2>&1", __swids_db_p_eth[i], dev_mac);
        system_err = system(cmd);
        if (0 != system_err) {
            SX_LOG_ERR("Failed running \"%s\".\n", cmd);
            goto out;
        }
        sprintf(cmd, "ifconfig swid%u_eth up", __swids_db_p_eth[i]);
        system_err = system(cmd);
        if (0 != system_err) {
            SX_LOG_ERR("Failed running \"%s\".\n", cmd);
            goto out;
        }
    }

out:
    return evb_rc;
}

evb_status_t __evb_parse_device_mac_address(sx_xml_list_t *list, device_t *device_p)
{
    sx_xml_element_t *child_dev_mac_address_p = NULL;
    sx_xml_element_t *child_p = NULL;
    sx_mac_addr_t    *base_mac_addr_p;
    evb_status_t      evb_rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((device_p == NULL) || (list == NULL)) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    child_p = sx_xml_element_list_data(list);
    child_dev_mac_address_p = sx_xml_element_by_name_get(child_p, "device-mac-address");
    if (child_dev_mac_address_p) {
        base_mac_addr_p = ether_aton(sx_xml_element_content_get(child_dev_mac_address_p));
        if (base_mac_addr_p == NULL) {
            SX_LOG_ERR("Error parsing device mac address\n");
            evb_rc = EVB_STATUS_PARSE_ERROR;
            goto out;
        }

        memcpy(&device_p->base_mac_addr, base_mac_addr_p, sizeof(sx_mac_addr_t));
    } else {
        SX_LOG_ERR("Error parsing device MAC address\n");
    }
out:
    SX_LOG_EXIT();
    return evb_rc;
}

sx_status_t __activate_health_check(void)
{
    sx_dbg_health_sample_params_t health_params;
    sx_status_t                   rc = SX_STATUS_SUCCESS;

    memset(&health_params, 0, sizeof(health_params));
    health_params.failures_num = SX_DBG_HEALTH_NUM_OF_FAILURES_DEFAULT;
    health_params.periodic_time = SX_DBG_HEALTH_PERIODIC_TIME_DEFAULT;
    health_params.min_severity = SX_HEALTH_SEVERITY_FATAL_E;
    rc = sx_api_dbg_fatal_failure_detection_set(__handle, SX_ACCESS_CMD_ENABLE, &health_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to start health check mechanism (err=%s)\n", sx_status_str(rc));
    }

    return rc;
}

sx_status_t evb_sdk_self_init_mng_topo_device_add(sx_dev_id_t dev_id,
                                                  boolean_t   issu_start,
                                                  boolean_t   disable_health_check)
{
    sx_topolib_dev_info_t dev_info;
    sx_status_t           rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    memset(&dev_info, 0, sizeof(dev_info));
    dev_info.dev_id = dev_id;

    rc = (sx_status_t)(topo_sdk_self_init_initialize());
    if (rc) {
        SX_LOG_ERR("ERROR: Fail to extract data from XML file\n");
        return rc;
    }

    rc = (sx_status_t)(topo_device_params_get_from_parse_db(&dev_info));
    if (rc) {
        SX_LOG_ERR("Device ID %u NOT found in the XML file\n", dev_id);
        return rc;
    }
    /* Set dev id to local db */
    device_arr[dev_id] = EVB_DEFAULT_DEVICE_NUMBER;
    device_cnt++;

    SET_DPT_STATE_IF_ISSU_STARTED(dev_id, issu_start, READ_WRITE, sx_status_t);

    rc = sx_api_topo_device_set(__handle, SX_ACCESS_CMD_ADD, &dev_info);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to add device %u to the SDK (sx_api_topo_device_set)\n", dev_id);
        return rc;
    }

    if (issu_start) {
        SET_DPT_STATE_IF_ISSU_STARTED(dev_id, issu_start, READ_ONLY, sx_status_t);
    }

    /* Device READY - configure the SSPR register */
    rc = sx_api_topo_device_set(__handle, SX_ACCESS_CMD_READY, &dev_info);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set device ready in the SDK for device %u (sx_api_topo_device_set)\n", dev_id);
        return rc;
    }

    if (!disable_health_check) {
#if !defined(PD_BU)
        __activate_health_check();
#endif
    }

    SX_LOG_EXIT();
    return rc;
}


boolean_t is_port_same_configuration(port_info_t * base_port, port_info_t * new_port)
{
    if ((base_port->port_mode == new_port->port_mode) &&
        (base_port->mstp_port_state == new_port->mstp_port_state) &&
        (base_port->port_speed == new_port->port_speed) &&
        (base_port->port_state == new_port->port_state) &&
        (base_port->port_ext_api_type == new_port->port_ext_api_type) &&
        (base_port->swid == new_port->swid) &&
        (base_port->vid == new_port->vid) &&
        (base_port->port_mapping.width == new_port->port_mapping.width) &&
        (base_port->phys_loopback == new_port->phys_loopback)) {
        return TRUE;
    }
    return FALSE;
}

/**
 * This function wait up to 30S for given apply done statuses.
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __evb_eth_port_profile_wait(sx_port_profile_apply_done_status_e status1,
                                         sx_port_profile_apply_done_status_e status2,
                                         sx_fd_t                             sx_fd)
{
    sx_status_t       rc;
    fd_set            r_fds;
    struct timeval    tv;
    uint8_t           buff[1024] = { 0 };
    uint32_t          buff_size = sizeof(buff);
    sx_receive_info_t receive_info;
    evb_status_t      evb_rc = EVB_STATUS_SUCCESS;
    int               err;


    FD_ZERO(&r_fds);
    FD_SET(sx_fd.fd, &r_fds);
    long int poll_time = 30;

#if defined(PD_BU)
    poll_time = 600;
#endif

    tv.tv_sec = poll_time;
    tv.tv_usec = 0;
    err = select(sx_fd.fd + 1, &r_fds, NULL, NULL, &tv);
    if (err <= 0) {
        if (err == 0) {
            SX_LOG_ERR("port_profile_apply_done failed: %ld sec timeout reached waiting for done event\n", poll_time);
        } else {    /* err = -1 */
            SX_LOG_ERR("port_profile_apply_done failed: Error on select(), errno = [%s]\n", strerror(errno));
        }
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }
    SX_LOG_INF("port_profile_apply_done took %ld seconds\n", poll_time - tv.tv_sec);
    memset(&receive_info, 0, sizeof(receive_info));
    rc = sx_lib_host_ifc_recv(&sx_fd, buff, &buff_size, &receive_info);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to sx_lib_host_ifc_recv, error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }

    if ((receive_info.event_info.port_profile_apply_done_info.status != status1) &&
        (receive_info.event_info.port_profile_apply_done_info.status != status2)) {
        SX_LOG_ERR("port_profile_apply_done failed: expected apply done status %d or %d, but got %d\n",
                   status1,
                   status2,
                   receive_info.event_info.port_profile_apply_done_info.status);
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }

out:
    return evb_rc;
}


/**
 * This function search all the ports with same configuration
 * create a port profile
 * add api to the profile
 * apply the profile
 * destroy the profile
 * repeat until all ports are inited.
 *
 * @return: EVB_STATUS_SUCCESS - on success , otherwise all other values
 *
 */
evb_status_t __evb_eth_port_profile_apply(int       device_index,
                                          boolean_t port_state_down_mode,
                                          uint8_t   port_speed_rate_mode)
{
    evb_status_t                   evb_rc = EVB_STATUS_SUCCESS;
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    device_t                      *device_p = &__device_db_p[device_index];
    boolean_t                      is_port_inited[device_p->port_info_arr_len_eth];
    boolean_t                      is_port_selected[device_p->port_info_arr_len_eth];
    int                            port_inited_ct = 0;
    int                            i = 0, base_port = -1;
    sx_port_log_id_t               port_profile_id = 0;
    sx_port_profile_params_t       sx_port_profile_params = {0};
    sx_port_profile_apply_params_t apply_param;
    uint32_t                       vlan_list_size = 1;
    sx_vlan_ports_t                vlan_port;
    sx_user_channel_t              uc;
    sx_fd_t                        sx_fd;
    sx_span_port_attr_t            span_port_attr;

    SX_LOG_ENTER();

    span_port_attr.type = SX_SPAN_PORT_ATTR_LABEL_INFO_E;
    span_port_attr.attr.label_info.port_label = 0; /* will get label from FW */

    memset(is_port_inited, 0, sizeof(is_port_inited));
    memset(&apply_param, 0, sizeof(apply_param));

    rc = sx_api_host_ifc_open(__handle, &sx_fd);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to sx_api_host_ifc_open, error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out2;
    }

    memset(&uc, 0, sizeof(uc));
    uc.type = SX_USER_CHANNEL_TYPE_FD;
    memcpy(&uc.channel.fd, &sx_fd, sizeof(uc.channel.fd));
    rc = sx_api_host_ifc_trap_id_register_set(__handle,
                                              SX_ACCESS_CMD_REGISTER,
                                              0,
                                              SX_TRAP_ID_PORT_PROFILE_APPLY_DONE,
                                              &uc);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to register trap SX_TRAP_ID_PORT_PROFILE_APPLY_DONE, error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out1;
    }

    while (port_inited_ct < device_p->port_info_arr_len_eth) {
        memset(&(is_port_selected), 0, sizeof(is_port_selected));
        base_port = -1;
        for (i = 0; i < device_p->port_info_arr_len_eth; i++) {
            if (device_p->port_info_arr_eth[i].port_mode == SX_PORT_MODE_NVE) {
                if (!is_port_inited[i]) {
                    port_inited_ct++;
                    is_port_inited[i] = TRUE;
                }
                continue;
            }

            if (!is_port_inited[i]) {
                /*select ports with same configuration*/
                if (base_port == -1) {
                    base_port = i;
                    port_inited_ct++;
                    is_port_selected[i] = TRUE;
                    is_port_inited[i] = TRUE;
                } else if (is_port_same_configuration(&device_p->port_info_arr_eth[base_port],
                                                      &device_p->port_info_arr_eth[i])) {
                    port_inited_ct++;
                    is_port_selected[i] = TRUE;
                    is_port_inited[i] = TRUE;
                }
            }
        }

        if (base_port == -1) {
            goto out;
        }
        sx_port_profile_params.width = device_p->port_info_arr_eth[base_port].port_mapping.width;
        rc = sx_api_port_profile_set(__handle, SX_ACCESS_CMD_CREATE, &sx_port_profile_params, &port_profile_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to create port profile, error: %s\n", sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }
        printf("port profile id  =  0x%x with width %d created\n", port_profile_id, sx_port_profile_params.width);
        evb_rc = __evb_add_function_to_profile(device_p,
                                               port_profile_id,
                                               base_port,
                                               port_state_down_mode,
                                               port_speed_rate_mode);
        if (evb_rc != EVB_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to add function to port profile 0x%x error: %s\n",
                       port_profile_id, evb_utils_get_err_str(evb_rc));
            goto out;
        }

        apply_param.port_list_cnt = 0;
        for (i = base_port; i < device_p->port_info_arr_len_eth; i++) {
            if (is_port_selected[i]) {
                apply_param.port_list[apply_param.port_list_cnt] = __device_db_p[device_index].log_ports_arr[i];
                apply_param.port_list_cnt++;
                /*only base port port_ext_api_type is calculated above, here copy to other ports*/
                device_p->port_info_arr_eth[i].port_ext_api_type =
                    device_p->port_info_arr_eth[base_port].port_ext_api_type;
                /*printf(" port 0x%x added to port profile\n",  __device_db_p[device_index].log_ports_arr[i]); */
            }
        }


        rc = sx_api_port_profile_apply_set(__handle, port_profile_id, &apply_param);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to apply port profile 0x%x error: %s\n",
                       port_profile_id, sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }

        /*we only wait SX_PORT_PROFILE_APPLY_DONE_STATUS_OK_E here*/
        evb_rc = __evb_eth_port_profile_wait(SX_PORT_PROFILE_APPLY_DONE_STATUS_OK_E,
                                             SX_PORT_PROFILE_APPLY_DONE_STATUS_OK_E,
                                             sx_fd);
        if (evb_rc != EVB_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to wait for apply done after profile 0x%x applied, error: %s\n",
                       port_profile_id, evb_utils_get_err_str(evb_rc));
            goto out;
        }

        rc = sx_api_port_profile_set(__handle, SX_ACCESS_CMD_DESTROY, &sx_port_profile_params, &port_profile_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to destroy port profile 0x%x, error: %s\n",
                       port_profile_id, sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }

        evb_rc = __evb_eth_port_profile_wait(SX_PORT_PROFILE_APPLY_DONE_STATUS_OK_E,
                                             SX_PORT_PROFILE_APPLY_DONE_STATUS_CLEAR_E,
                                             sx_fd);
        if (evb_rc != EVB_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to wait for apply done after profile 0x%x destroyed, error %s\n",
                       port_profile_id, evb_utils_get_err_str(evb_rc));
            goto out;
        }

        for (i = base_port; i < device_p->port_info_arr_len_eth; i++) {
            if (is_port_selected[i]) {
                /*We need this because port profile doesn't support sx_api_vlan_ports_set */
                vlan_port.log_port = __device_db_p[device_index].log_ports_arr[i];
                vlan_port.is_untagged = 1;
                vlan_port.pass_state = 0;
                rc = sx_api_vlan_ports_set(__handle,
                                           SX_ACCESS_CMD_ADD,
                                           device_p->port_info_arr_eth[base_port].swid,
                                           device_p->port_info_arr_eth[base_port].vid,
                                           &vlan_port,
                                           1);

                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to set port [%x] to vid [%u], error: %s\n", port_profile_id,
                               device_p->port_info_arr_eth[base_port].vid,
                               sx_status_str(rc));
                    evb_rc = EVB_STATUS_SDK_ERROR;
                    goto out;
                }
            }
        }
    }

    for (i = 0; i < device_p->port_info_arr_len_eth; i++) {
        if (device_p->port_info_arr_eth[i].port_mode == SX_PORT_MODE_NVE) {
            continue;
        }

        /* Skip ports that are connected to XM, mapping */
        if (device_p->port_info_arr_eth[i].swid == SX_SWID_ID_DEFAULT) {
            continue;
        }
        if (device_p->port_info_arr_eth[i].port_mode == SX_PORT_MODE_EXTERNAL) {
            rc = sx_api_span_port_attr_set(__handle, device_p->log_ports_arr[i], &span_port_attr, 1);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set span port attr: %s\n", sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }

            if ((sdk_bridge_mode == SX_MODE_802_1Q) || (sdk_bridge_mode == SX_MODE_HYBRID)) {
                /* Make sure default vlan is initialized */
                rc = sx_api_vlan_get(__handle, device_p->port_info_arr_eth[i].swid, NULL, &vlan_list_size);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to retrieve vlans error: %s\n", sx_status_str(rc));
                    evb_rc = EVB_STATUS_SDK_ERROR;
                    goto out;
                }

                if (0 == vlan_list_size) {
                    vlan_list_size = 1;
                    rc = sx_api_vlan_set(__handle,
                                         SX_ACCESS_CMD_ADD,
                                         device_p->port_info_arr_eth[i].swid,
                                         &device_p->port_info_arr_eth[i].vid,
                                         &vlan_list_size);
                    if (SX_CHECK_FAIL(rc)) {
                        SX_LOG_ERR("Failed to add vlan [%u], error: %s\n",
                                   device_p->port_info_arr_eth[i].vid,
                                   sx_status_str(rc));
                        evb_rc = EVB_STATUS_SDK_ERROR;
                        goto out;
                    }
                }

                vlan_port.log_port = device_p->log_ports_arr[i];
                vlan_port.is_untagged = 1;
                vlan_port.pass_state = 0;
                rc = sx_api_vlan_ports_set(__handle,
                                           SX_ACCESS_CMD_ADD,
                                           device_p->port_info_arr_eth[i].swid,
                                           device_p->port_info_arr_eth[i].vid,
                                           &vlan_port,
                                           1);

                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to set port [%x] to vid [%u], error: %s\n", device_p->log_ports_arr[i],
                               device_p->port_info_arr_eth[i].vid,
                               sx_status_str(rc));
                    evb_rc = EVB_STATUS_SDK_ERROR;
                    goto out;
                }
            }
        }
    }

out:
    rc = sx_api_host_ifc_trap_id_register_set(__handle,
                                              SX_ACCESS_CMD_DEREGISTER,
                                              0,
                                              SX_TRAP_ID_PORT_PROFILE_APPLY_DONE,
                                              &uc);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deregister SX_TRAP_ID_PORT_PROFILE_APPLY_DONE, error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
    }
out1:
    rc = sx_api_host_ifc_close(__handle, &sx_fd);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to sx_api_host_ifc_close, error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
    }
out2:
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __evb_common_eth_profile_init(int       device_index,
                                           boolean_t issu_start,
                                           boolean_t pdb_lag_init,
                                           boolean_t pdb_port_map_init,
                                           uint8_t   fw_fatal_event_mode,
                                           boolean_t port_state_down_mode,
                                           uint8_t   port_speed_rate_mode)
{
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;
    sx_status_t  rc = SX_STATUS_SUCCESS;
    uint32_t     log_port_index = 0;

    SX_LOG_ENTER();

    /* set port mapping */
    if ((pdb_port_map_init == FALSE) || (issu_start == FALSE)) {
        evb_rc = __eth_set_port_mapping((&__device_db_p[device_index]), issu_start);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed in __set_port_mapping , [error: %s] , exit...\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }
    }

    /*Configure fw fatal_event_mode [mfgd reg] in case its not the default on init [NO_CHECK]*/
    if (SXD_MFGD_FW_FATAL_EVENT_MODE_DONT_CHECK_FW_FATAL_E != fw_fatal_event_mode) {
        evb_rc = __eth_set_fw_fatal_event_mode(__device_db_p[device_index].device_info.dev_id, fw_fatal_event_mode);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("sdk self init Failed to configure fw fatal event mode: %c : %s\n",
                       fw_fatal_event_mode,
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }
    }

    printf("%s:%d  %s(): dev_id: %d port_num:%d\n", __FILE__, __LINE__, __func__,
           __device_db_p[device_index].device_info.dev_id, __device_db_p[device_index].log_ports_arr_len);

    if (do_not_init_with_port_profile == TRUE) {
        /* Set port's SWID && Init logical ports */
        log_port_index = 0;
        while (log_port_index < __device_db_p[device_index].log_ports_arr_len) {
            if (__device_db_p[device_index].port_info_arr_eth[log_port_index].port_mode == SX_PORT_MODE_NVE) {
                log_port_index++;
                continue;
            }
            /* set port -> SWID only if SWID is not default SWID */
            if ((__device_db_p[device_index].port_info_arr_eth[log_port_index].swid != SX_SWID_ID_DEFAULT) &&
                (__device_db_p[device_index].port_info_arr_eth[log_port_index].swid != SX_SWID_ID_STACKING)) {
                printf("%s:%d  %s(): dev %d , bind port  0x%x to swid %d map_mode %d\n", __FILE__, __LINE__, __func__,
                       __device_db_p[device_index].device_info.dev_id,
                       __device_db_p[device_index].log_ports_arr[log_port_index],
                       __device_db_p[device_index].port_info_arr_eth[log_port_index].swid,
                       __device_db_p[device_index].port_info_arr_eth[log_port_index].port_mapping.mapping_mode);

                SET_DPT_STATE_IF_ISSU_STARTED(__device_db_p[device_index].device_info.dev_id,
                                              issu_start,
                                              READ_ONLY,
                                              evb_status_t);

                if ((pdb_port_map_init == FALSE) || (issu_start == FALSE)) {
                    rc = sx_api_port_swid_bind_set(__handle,
                                                   __device_db_p[device_index].log_ports_arr[log_port_index],
                                                   __device_db_p[device_index].port_info_arr_eth[log_port_index].swid);

                    if (SX_CHECK_FAIL(rc)) {
                        SX_LOG_ERR("Failed in sx_api_port_swid_alloc_set , error: %s\n", sx_status_str(rc));
                        evb_rc = EVB_STATUS_SDK_ERROR;
                        goto out;
                    }
                }

                SET_DPT_STATE_IF_ISSU_STARTED(__device_db_p[device_index].device_info.dev_id,
                                              issu_start,
                                              READ_WRITE,
                                              evb_status_t);
            } else if (__device_db_p[device_index].port_info_arr_eth[log_port_index].swid == SX_SWID_ID_STACKING) {
                printf("%s:%d  %s(): dev %d , bind port  0x%x to swid %d by sx_api_port_stacking_mode_set()\n",
                       __FILE__, __LINE__, __func__, __device_db_p[device_index].device_info.dev_id,
                       __device_db_p[device_index].log_ports_arr[log_port_index],
                       __device_db_p[device_index].port_info_arr_eth[log_port_index].swid);
                rc = sx_api_port_mode_set(__handle,
                                          __device_db_p[device_index].log_ports_arr[log_port_index],
                                          SX_PORT_MODE_STACKING);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed in sx_api_port_stacking_mode_set , error: %s\n", sx_status_str(rc));
                    evb_rc = EVB_STATUS_SDK_ERROR;
                    goto out;
                }
            }

            SET_DPT_STATE_IF_ISSU_STARTED(__device_db_p[device_index].device_info.dev_id,
                                          issu_start,
                                          READ_ONLY,
                                          evb_status_t);

            /* No port init for XM ports */
            if ((do_not_init_with_port_profile == TRUE) &&
                (__device_db_p[device_index].port_info_arr_eth[log_port_index].swid != SX_SWID_ID_DEFAULT)) {
                rc = sx_api_port_init_set(__handle, __device_db_p[device_index].log_ports_arr[log_port_index]);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed in sx_api_port_init_set , error: %s\n", sx_status_str(rc));
                    evb_rc = EVB_STATUS_SDK_ERROR;
                    goto out;
                }
            }

            SET_DPT_STATE_IF_ISSU_STARTED(__device_db_p[device_index].device_info.dev_id,
                                          issu_start,
                                          READ_WRITE,
                                          evb_status_t);

            log_port_index++;
        }

        /* set port properties */
        printf("%s:%d  %s(): dev_id: %d set port properties\n", __FILE__, __LINE__, __func__,
               __device_db_p[device_index].device_info.dev_id);
        evb_rc = __eth_set_port_properties((&__device_db_p[device_index]),
                                           issu_start,
                                           pdb_lag_init,
                                           port_state_down_mode,
                                           port_speed_rate_mode);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed in __eth_set_port_properties , [error: %s] , exit...\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }
    } else {
        evb_rc = __evb_eth_port_profile_apply(device_index, port_state_down_mode, port_speed_rate_mode);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed in __evb_eth_port_profile_apply , [error: %s] , exit...\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }
    }

    printf("%s:%d  %s(): dev_id: %d set vlan properties\n", __FILE__, __LINE__, __func__,
           __device_db_p[device_index].device_info.dev_id);
    SET_DPT_STATE_IF_ISSU_STARTED(__device_db_p[device_index].device_info.dev_id,
                                  issu_start,
                                  READ_ONLY,
                                  evb_status_t);
    /*Create vlan's only if required*/
    if (num_of_active_vlans > 0) {
        evb_rc = __eth_set_vlans(num_of_active_vlans);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed in __eth_set_vlans , [error: %s] , exit...\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }
    }

    SET_DPT_STATE_IF_ISSU_STARTED(__device_db_p[device_index].device_info.dev_id, issu_start, READ_WRITE,
                                  evb_status_t);

    evb_rc = __eth_signal_management_software_new_device(&__device_db_p[device_index]);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("failed in __signal_management_software_new_device , [error: %s] , exit...\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __evb_sdk_self_init_handle_eth(boolean_t issu_start,
                                            boolean_t pdb_lag_init,
                                            boolean_t pdb_port_map_init,
                                            uint8_t   fw_fatal_event_mode,
                                            boolean_t port_state_down_mode,
                                            uint8_t   port_speed_rate_mode,
                                            boolean_t disable_health_check,
                                            boolean_t use_2nd_bonus_port)
{
    int            device_index = 0;    /* Device index */
    evb_status_t   evb_rc = EVB_STATUS_SUCCESS;
    sx_xml_list_t *list_head = NULL;         /* XML list object - used to iterate device nodes */
    sx_status_t    rc = SX_STATUS_SUCCESS;    /* return value for SDK APIs */

    SX_LOG_ENTER();

    /* Initialize ethernet ports */
    evb_rc = __eth_evb_sdk_self_init_swid_ports(&__device_db_p[device_index], use_2nd_bonus_port);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("sdk self init Failed to initialize eth ports , error: %s\n",  evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* create SWIDs in SDK */
    evb_rc = __eth_set_swids();
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in __set_swids , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }


    printf("%s:%d  %s(): dev_cnt: %d swid_cnt: %d\n", __FILE__, __LINE__, __func__,  __device_count,
           __swids_count_eth);
    /* logical ports array length should be the same as the physical ports array length */
    __device_db_p[device_index].log_ports_arr_len = __device_db_p[device_index].port_info_arr_len_eth;
    __device_db_p[device_index].device_info.num_ports = __device_db_p[device_index].port_info_arr_len_eth;

    /* Retrieve the MAC address */
    list_head = sx_xml_element_shallow_list_by_name_get(sx_xml_tree_root_element_get(__tree_p), "device");

    evb_rc = __set_mac_addresses(sx_xml_element_list_data(list_head));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in __set_mac_addresses , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    evb_rc = __evb_parse_device_mac_address(list_head, &__device_db_p[device_index]);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in parsing device mac address , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    evb_rc = __port_device_set(
        &(__device_db_p[device_index]),
        __device_db_p[device_index].port_info_arr_eth,
        (uint32_t)__device_db_p[device_index].port_info_arr_len_eth);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("__port_device_set failed, error: %s\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }

    rc = evb_sdk_self_init_mng_topo_device_add(__device_db_p[device_index].device_info.dev_id,
                                               issu_start,
                                               disable_health_check);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("evb_mng_topo_xml_device_add failed for device %u (%s)\n",
                   __device_db_p[device_index].device_info.dev_id,
                   sx_status_str(rc));
        /* free port_mode_arr & port_mapping_arr arrays */
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

    evb_rc = __evb_common_eth_profile_init(device_index,
                                           issu_start,
                                           pdb_lag_init,
                                           pdb_port_map_init,
                                           fw_fatal_event_mode,
                                           port_state_down_mode,
                                           port_speed_rate_mode);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("__evb common ethernet profile init  failed, error: %s\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }
out:
    if (list_head != NULL) {
        sx_xml_element_shallow_list_free(list_head);
    }
    SX_LOG_EXIT();
    return evb_rc;
}

sx_status_t evb_mng_topo_xml_device_add(sx_dev_id_t dev_id, boolean_t issu_start, boolean_t disable_health_check)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    int                   tree_index;
    char                  parse_tree_cnt = 0;
    sx_topolib_dev_info_t dev_info;
    sx_topo_lib_tree_t  * tree_info = NULL;
    sx_access_cmd_t       cmd;
    sx_tree_hndl_t        tree_id;
    sx_swid_t             swid = 0;

    SX_LOG_ENTER();

    memset(&dev_info, 0, sizeof(dev_info));

    /* Get XML file DB */
    rc = (sx_status_t)(topo_xml_params_initialize());
    if (rc) {
        SX_LOG_ERR("ERROR: Fail to extract data from XML file\n");
        return rc;
    }

    SX_LOG_DBG("####################################################\n");
    SX_LOG_DBG("#######  FILTERED - Based on added devices   #######\n");
    SX_LOG_DBG("####################################################\n");
    if (device_arr[dev_id]) {
        SX_LOG_ERR("Device ID already added\n");
        return SX_STATUS_ERROR;
    }

    /* Add new TOPO device - without tree */
    dev_info.dev_id = dev_id;
    rc = (sx_status_t)(topo_device_params_get_from_parse_db(&dev_info));
    if (rc) {
        SX_LOG_ERR("Device ID %u NOT found in the XML file\n", dev_id);
        return rc;
    }

    /* Set dev id to local db */
    device_arr[dev_id] = 1;
    device_cnt++;

    SET_DPT_STATE_IF_ISSU_STARTED(dev_id, issu_start, READ_WRITE, sx_status_t);

    rc = sx_api_topo_device_set(__handle, SX_ACCESS_CMD_ADD, &dev_info);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to add device %u to the SDK (sx_api_topo_device_set)\n", dev_id);
        return rc;
    }

    if (issu_start) {
        /* Flush FDB */
        rc = sx_api_fdb_uc_flush_all_set(__handle, swid);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to flush all UC for swid %d\n", swid);
            return rc;
        }

        SET_DPT_STATE_IF_ISSU_STARTED(dev_id, issu_start, READ_ONLY, sx_status_t);
    }

    if (device_cnt > 1) {
        /* Allocate memory for tree info */
        tree_info = malloc(__tree_count * sizeof(sx_topo_lib_tree_t));
        if (!tree_info) {
            SX_LOG_ERR("Failed to allocate memory for tree tree_info array , error: %d\n", rc);
            return SX_STATUS_NO_MEMORY;
        }

        /* Filter relevant tree nodes from DB */
        rc =
            (sx_status_t)topo_tree_params_get_from_parse_db(device_arr, device_cnt, tree_info, &parse_tree_cnt,
                                                            dev_id);
        topo_print_tree_info(tree_info, parse_tree_cnt);
        for (tree_index = 0; tree_index < parse_tree_cnt; tree_index++) {
            /* ID of the tree parsed from XML file */
            tree_id = tree_info[tree_index].tree_hndl;
            /* Check if the tree is new or it should be edit */
            if (tree_arr[tree_id]) {
                /* The tree was added - will be EDIT */
                cmd = SX_ACCESS_CMD_EDIT;
                tree_info[tree_index].tree_hndl = tree_arr[tree_id];
            } else {
                /* The tree was not added - will be ADD */
                cmd = SX_ACCESS_CMD_ADD;
            }

            /* Add new TOPO tree */
            rc = sx_api_topo_tree_set(__handle, cmd, &tree_info[tree_index]);
            if (rc) {
                SX_LOG_ERR("ERROR: Fail to add topo tree\n");
                free(tree_info);
                return rc;
            }

            /* Set the ADD/EDIT tree flag */
            tree_arr[tree_id] = tree_info[tree_index].tree_hndl;
            /* Attached tree handle to device */
            dev_info.unicast_tree_hndl_arr[tree_index] = tree_info[tree_index].tree_hndl;
        }

        dev_info.unicast_arr_len = parse_tree_cnt;
        rc = sx_api_topo_device_set(__handle, SX_ACCESS_CMD_EDIT, &dev_info);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to edit device topology in SDK for device %u (sx_api_topo_device_set)\n", dev_id);
            free(tree_info);
            return rc;
        }
        topo_tree_free_mem(tree_info, parse_tree_cnt);
        if (tree_info != NULL) {
            free(tree_info);
        }
    }

    /* Device READY - configure the SSPR register */
    rc = sx_api_topo_device_set(__handle, SX_ACCESS_CMD_READY, &dev_info);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set device ready in the SDK for device %u (sx_api_topo_device_set)\n", dev_id);
        return rc;
    }

    if (!disable_health_check) {
        __activate_health_check();
    }

    SX_LOG_EXIT();

    return rc;
}

evb_status_t __parse_static_fdb_entry_section(INOUT int                        *static_entries_count_p,
                                              IN sx_xml_element_t              *child_p,
                                              OUT sx_fdb_uc_mac_addr_params_t **static_entries_arr)
{
    int          i = 0;
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    if ((static_entries_arr == NULL) || (child_p == NULL) || (static_entries_count_p == NULL)) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    sx_xml_element_t *child_dev_static_mac = sx_xml_element_by_name_get(child_p,
                                                                        "mac-address-to-log-port");
    sx_xml_list_t *route_list = NULL;
    sx_xml_list_t *route_list_head = NULL;
    char           mac_address[100] = "";
    sx_mac_addr_t *mac_addr = NULL;
    char         * pch;

    SX_LOG_ENTER();

    if ((child_dev_static_mac == NULL) || (static_entries_count_p[0] == 0)) {
        SX_LOG_INF("No static MAC entries to parse\n");
        goto out;
    }

    route_list_head = sx_xml_element_list_get(child_dev_static_mac);
    route_list = route_list_head;

    /* allocate memory */
    evb_rc
        = EVB_UTILS_CLR_MEM_GET(static_entries_arr, static_entries_count_p[0], sizeof(sx_fdb_uc_mac_addr_params_t));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to allocate memory for static_entries_arr , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    while (route_list != NULL && i < static_entries_count_p[0]) {
        sx_xml_element_t *route_child = sx_xml_element_list_data(route_list);
        char             *route_str = (char*)sx_xml_element_content_get(route_child);

        if (route_str == NULL) {
            continue;
        }

        pch = strtok(route_str, ",");
        if (pch != NULL) {
            if (1 != sscanf(pch, "%s", mac_address)) {
                SX_LOG_ERR("Error parsing device mac address\n");
                goto out;
            }

            pch = strtok(NULL, ",");
            if ((pch == NULL) || (1 != sscanf(pch, "%d", &(static_entries_arr[0][i].log_port)))) {
                SX_LOG_ERR("Error parsing log port for device mac address\n");
                goto out;
            }
        } else {
            SX_LOG_ERR("Error parsing device mac address\n");
            goto out;
        }

        SX_LOG_ERR("MAC : %s , LOG PORT: %d , count : %d\n",
                   mac_address,
                   static_entries_arr[0][i].log_port,
                   static_entries_count_p[0]);
        mac_addr = ether_aton(mac_address);
        if (mac_addr == NULL) {
            SX_LOG_ERR("Error parsing device mac address\n");
            goto out;
        }

        memcpy(&(static_entries_arr[0][i].mac_addr), mac_addr, sizeof(sx_mac_addr_t));

        i++;

        route_list = sx_xml_element_list_next(route_list);
    }

    if (i != static_entries_count_p[0]) {
        SX_LOG_WRN("Number of parsed static mac entries (%d) is different then expected (%d)\n",
                   i, static_entries_count_p[0]);
    }

    /* set out parameter */
    static_entries_count_p[0] = i;

out:
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __eth_handle_profile(boolean_t issu_start,
                                  boolean_t pdb_lag_init,
                                  boolean_t pdb_port_map_init,
                                  uint8_t   fw_fatal_event_mode,
                                  boolean_t port_state_down_mode,
                                  uint8_t   port_speed_rate_mode,
                                  boolean_t disable_health_check,
                                  boolean_t use_2nd_bonus_port)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;    /* return value for SDK APIs */
    evb_status_t   evb_rc = EVB_STATUS_SUCCESS; /* return value for EVB manager APIs */
    int            static_mac_entries_count = 0; /* STATIC MAC entries counter */
    sx_xml_list_t *list = NULL, *list_head = NULL;   /* XML list object - used to iterate device nodes */
    int            device_index = 0;  /* Device index */

    /* create SWIDs in SDK */
    evb_rc = __eth_set_swids();
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in __set_swids , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }


    list_head = sx_xml_element_shallow_list_by_name_get(sx_xml_tree_root_element_get(__tree_p), "device");  /* get the list of devices from the XML file */
    list = list_head;
    printf("%s:%d  %s(): dev_cnt: %d \n", __FILE__, __LINE__, __func__,  __device_count);

    evb_rc = __set_mac_addresses(sx_xml_element_list_data(list));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in __set_mac_addresses , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* handle each device */
    while (list != NULL && device_index < __device_count) {
        sx_xml_element_t *child = sx_xml_element_list_data(list);

        /* Check the device state - do not handle disabled devices */
        evb_rc = __parse_eth_device_state_section(child);
        if (EVB_CHECK_FAIL(evb_rc)) {
            list = sx_xml_element_list_next(list);
            continue;
        }

        /* get device data - device parameters should fit ETH profile */
        evb_rc = __parse_eth_device_params_section(&__device_db_p[device_index], child,
                                                   &(static_mac_entries_count),
                                                   issu_start,
                                                   pdb_port_map_init,
                                                   use_2nd_bonus_port);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("failed to parse device params , [error: %s] , exit...\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }

        evb_rc = __port_device_set(
            &(__device_db_p[device_index]),
            __device_db_p[device_index].port_info_arr_eth,
            (uint32_t)__device_db_p[device_index].port_info_arr_len_eth);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("__port_device_set failed, error: %s\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }


        rc = evb_mng_topo_xml_device_add(__device_db_p[device_index].device_info.dev_id,
                                         issu_start,
                                         disable_health_check);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("evb_mng_topo_xml_device_add failed for device %u (%s)\n",
                       __device_db_p[device_index].device_info.dev_id,
                       sx_status_str(rc));
            /* free port_mode_arr & port_mapping_arr arrays */
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }

        evb_rc = __evb_common_eth_profile_init(device_index,
                                               issu_start,
                                               pdb_lag_init,
                                               pdb_port_map_init,
                                               fw_fatal_event_mode,
                                               port_state_down_mode,
                                               port_speed_rate_mode);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("__evb common ethernet profile init  failed, error: %s\n",
                       evb_utils_get_err_str(evb_rc));
            goto out;
        }


        if (sdk_bridge_mode == SX_MODE_802_1Q) {
            evb_rc = __eth_set_static_mac_entries(&__device_db_p[device_index],
                                                  static_mac_entries_count);
            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("failed in __eth_set_static_mac_entries , [error: %s] , exit...\n",
                           evb_utils_get_err_str(evb_rc));
                goto out;
            }
        }

        device_index++;
        list = sx_xml_element_list_next(list);
    }

out:
    sx_xml_element_shallow_list_free(list_head);
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __eth_set_swids(void)
{
    int          i = 0;
    sx_status_t  rc = SX_STATUS_SUCCESS;
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();

    for (i = 0; i < __swids_count_eth; i++) {
        if (__swids_db_p_eth[i] == SX_SWID_ID_DEFAULT) {
            continue;
        }

        rc = sx_api_port_swid_set(__handle,
                                  SX_ACCESS_CMD_ADD,
                                  __swids_db_p_eth[i]);
        if (SX_CHECK_FAIL(rc) && (rc != SX_STATUS_ENTRY_ALREADY_EXISTS)) {
            SX_LOG_ERR("Failed in sx_api_port_swid_set , error: %s\n", sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __eth_set_port_properties(device_t *device_p,
                                       boolean_t issu_start,
                                       boolean_t pdb_lag_init,
                                       boolean_t port_state_down_mode,
                                       uint8_t   port_speed_rate_mode)
{
    int                        i = 0;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    evb_status_t               evb_rc = EVB_STATUS_SUCCESS; /* return value for EVB manager APIs */
    sx_vlan_ports_t            vlan_port;
    sx_port_speed_capability_t admin_speed;
    uint32_t                   vlan_list_size = 1;
    sx_port_rate_bitmask_t     admin_rate;
    uint32_t                   port_list_cnt = 0;
    cl_qmap_t                  port_in_lag_map;
    cl_map_item_t             *map_item = NULL;
    port_map_item_t           *port_map_item_p = NULL;

    SX_LOG_ENTER();

    cl_qmap_init(&port_in_lag_map);

    if (device_p == NULL) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    /* Get LAGs ports list: */
    rc = sx_api_port_swid_port_list_get(__handle, 0, NULL, &port_list_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to port list count, error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_SDK_ERROR;
        goto out;
    }

    if ((issu_start) && (pdb_lag_init)) {
        evb_rc = __issu_get_all_lag_members_ports(&port_in_lag_map, port_list_cnt);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed to initialize ports in lags list, error: %s\n",  evb_utils_get_err_str(evb_rc));
            goto out;
        }
    }

    /* build an array of local ports */
    for (i = 0; i < device_p->port_info_arr_len_eth; i++) {
        if (device_p->port_info_arr_eth[i].port_mode == SX_PORT_MODE_NVE) {
            continue;
        }

        /* Skip ports that are connected to XM, mapping */
        if (device_p->port_info_arr_eth[i].swid == SX_SWID_ID_DEFAULT) {
            continue;
        }

        /* Check whether we must invoke Legacy API for port speed configuration,
         *  or new API which allows to configure 200Gbps, and 400Gbps  */
        evb_rc =
            __port_rate_convert_bitmap(device_p->port_info_arr_eth[i].port_speed,
                                       &(device_p->port_info_arr_eth[i].port_ext_api_type), &admin_rate);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed to convert port [%x] speed value, error: %s\n",
                       device_p->log_ports_arr[i],
                       sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }

        /* If ISSU_STARTED and restoring LAGs from pdb, skip properties config: */
        map_item = cl_qmap_get(&port_in_lag_map, device_p->log_ports_arr[i]);
        if (map_item != cl_qmap_end(&port_in_lag_map)) {
            port_map_item_p = PARENT_STRUCT(map_item, port_map_item_t, map_item);
            cl_qmap_remove_item(&port_in_lag_map, &port_map_item_p->map_item);
            free(port_map_item_p);
            continue;
        }

        /* RSTP STATE */
        if (device_p->port_info_arr_eth[i].port_mode == SX_PORT_MODE_EXTERNAL) {
            rc = sx_api_rstp_port_state_set(__handle,
                                            device_p->log_ports_arr[i],
                                            device_p->port_info_arr_eth[i].mstp_port_state
                                            );
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set port [%x] rstp state , error: %s\n",
                           device_p->log_ports_arr[i],
                           sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }
        }


        /* Check whether we need to use new port speed configuration API */
        if (((port_speed_rate_mode == SX_PORT_SPEED_RATE_MODE_DEFAULT_E) &&
             (device_p->port_info_arr_eth[i].port_ext_api_type == TRUE)) ||
            (port_speed_rate_mode == SX_PORT_SPEED_RATE_MODE_RATE_E)) {
            rc = sx_api_port_rate_set(__handle, device_p->log_ports_arr[i], &admin_rate);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set port [%x] speed , error: %s\n", device_p->log_ports_arr[i],
                           sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }
        } else {
            /* PORT SPEED */
            evb_rc = __port_speed_convert_bitmap_to_capability(device_p->port_info_arr_eth[i].port_speed,
                                                               &admin_speed);

            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("Failed to set port [%x] speed , error: %s\n", device_p->log_ports_arr[i],
                           sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }


            rc = sx_api_port_speed_admin_set(__handle,
                                             device_p->log_ports_arr[i],
                                             &admin_speed
                                             );

            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set port [%x] speed , error: %s\n", device_p->log_ports_arr[i],
                           sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }
        }

        if (issu_start == FALSE) {
            /* PORT PHYS LOOPBACK */
            rc = sx_api_port_state_set(__handle,
                                       device_p->log_ports_arr[i],
                                       SX_PORT_ADMIN_STATUS_DOWN);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set port [%x] state DOWN, error: %s\n", device_p->log_ports_arr[i],
                           sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }

            rc = sx_api_port_phys_loopback_set(__handle,
                                               device_p->log_ports_arr[i],
                                               device_p->port_info_arr_eth[i].phys_loopback);

            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set port [%x] phys loopback [%u]. error: %s\n",
                           device_p->log_ports_arr[i],
                           device_p->port_info_arr_eth[i].phys_loopback,
                           sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }
        }

        /* PORT STATE */

        if (port_state_down_mode == FALSE) {
            rc = sx_api_port_state_set(__handle,
                                       device_p->log_ports_arr[i],
                                       device_p->port_info_arr_eth[i].port_state
                                       );
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set port [%x] state : [%s], error: %s\n", device_p->log_ports_arr[i],
                           sx_port_admin_state_str(device_p->port_info_arr_eth[i].port_state),
                           sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }
        }

        /* PORT default VLAN */
        if (device_p->port_info_arr_eth[i].port_mode == SX_PORT_MODE_EXTERNAL) {
            SET_DPT_STATE_IF_ISSU_STARTED(device_p->device_info.dev_id, issu_start, READ_ONLY, evb_status_t);
            rc = sx_api_vlan_port_pvid_set(__handle,
                                           SX_ACCESS_CMD_ADD,
                                           device_p->log_ports_arr[i],
                                           device_p->port_info_arr_eth[i].vid
                                           );
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set port [%x] default vid [%u], error: %s\n", device_p->log_ports_arr[i],
                           device_p->port_info_arr_eth[i].vid,
                           sx_status_str(rc));
                evb_rc = EVB_STATUS_SDK_ERROR;
                goto out;
            }
            SET_DPT_STATE_IF_ISSU_STARTED(device_p->device_info.dev_id, issu_start, READ_WRITE, evb_status_t);

            if ((sdk_bridge_mode == SX_MODE_802_1Q) || (sdk_bridge_mode == SX_MODE_HYBRID)) {
                /* Make sure default vlan is initialized */
                rc = sx_api_vlan_get(__handle, device_p->port_info_arr_eth[i].swid, NULL, &vlan_list_size);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to retrieve vlans error: %s\n", sx_status_str(rc));
                    evb_rc = EVB_STATUS_SDK_ERROR;
                    goto out;
                }

                if (0 == vlan_list_size) {
                    vlan_list_size = 1;
                    SET_DPT_STATE_IF_ISSU_STARTED(device_p->device_info.dev_id, issu_start, READ_ONLY, evb_status_t);
                    rc = sx_api_vlan_set(__handle,
                                         SX_ACCESS_CMD_ADD,
                                         device_p->port_info_arr_eth[i].swid,
                                         &device_p->port_info_arr_eth[i].vid,
                                         &vlan_list_size);
                    if (SX_CHECK_FAIL(rc)) {
                        SX_LOG_ERR("Failed to add vlan [%u], error: %s\n",
                                   device_p->port_info_arr_eth[i].vid,
                                   sx_status_str(rc));
                        evb_rc = EVB_STATUS_SDK_ERROR;
                        goto out;
                    }
                    SET_DPT_STATE_IF_ISSU_STARTED(device_p->device_info.dev_id, issu_start, READ_WRITE, evb_status_t);
                }

                vlan_port.log_port = device_p->log_ports_arr[i];
                vlan_port.is_untagged = 1;
                vlan_port.pass_state = 0;
                rc = sx_api_vlan_ports_set(__handle,
                                           SX_ACCESS_CMD_ADD,
                                           device_p->port_info_arr_eth[i].swid,
                                           device_p->port_info_arr_eth[i].vid,
                                           &vlan_port,
                                           1);

                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to set port [%x] to vid [%u], error: %s\n", device_p->log_ports_arr[i],
                               device_p->port_info_arr_eth[i].vid,
                               sx_status_str(rc));
                    evb_rc = EVB_STATUS_SDK_ERROR;
                    goto out;
                }

                /* In ISSU, if vlan membership is not standard, setting filter could affect traffic.
                 * This API can be used AFTER VLAN membership is reconfigured (to the values pre-issu) */

                SET_DPT_STATE_IF_ISSU_STARTED(device_p->device_info.dev_id, issu_start, READ_ONLY, evb_status_t);
                rc = sx_api_vlan_port_ingr_filter_set(__handle,
                                                      device_p->log_ports_arr[i], SX_INGR_FILTER_ENABLE);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to set port [%x] vlan_ingress_filter enable, error: %s\n",
                               device_p->log_ports_arr[i], sx_status_str(rc));
                    evb_rc = EVB_STATUS_SDK_ERROR;
                    goto out;
                }
                SET_DPT_STATE_IF_ISSU_STARTED(device_p->device_info.dev_id, issu_start, READ_WRITE, evb_status_t);
            }
        }
    }

    SX_LOG_DBG("Successfully set port properties\n");

out:
    if (!cl_is_qmap_empty(&port_in_lag_map)) {
        SX_LOG_ERR("port_in_lag_map NOT empty!!!\n");
        map_item = cl_qmap_head(&port_in_lag_map);
        while (map_item != cl_qmap_end(&port_in_lag_map)) {
            port_map_item_p = PARENT_STRUCT(map_item, port_map_item_t, map_item);
            map_item = cl_qmap_next(map_item);
            cl_qmap_remove_item(&port_in_lag_map, &port_map_item_p->map_item);
            free(port_map_item_p);
        }
    }
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __eth_set_static_mac_entries(IN device_t *device_p, IN int static_entries_count)
{
    uint32_t                     i = 0;
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    evb_status_t                 evb_rc = EVB_STATUS_SUCCESS;
    sx_port_phy_id_t             phy_id = 0;
    sx_fdb_uc_mac_addr_params_t *mac_list = NULL;
    uint32_t                     list_len = 0;

    SX_LOG_ENTER();

    /* check that static_entries_count == device_p->uc_mac_arr_len */
    if (static_entries_count != (int)device_p->uc_mac_arr_len) {
        evb_rc = EVB_STATUS_PARAM_ERROR;
        goto out;
    }

    while (i < device_p->log_ports_arr_len && i
           < device_p->uc_mac_arr_len) {
        if (device_p->port_info_arr_eth[i].port_mode == SX_PORT_MODE_NVE) {
            i++;
            continue;
        }
        SX_LOG_DBG("Adding static mac entry (current device: %d) , destination log port details:\n",
                   device_p->device_info.dev_id);
        M_PRINT_PORT_LOG_ID_MEMBERS(device_p->uc_mac_arr[i].log_port);

        phy_id = SX_PORT_PHY_ID_GET(device_p->uc_mac_arr[i].log_port);

        device_p->uc_mac_arr[i].entry_type = SX_FDB_UC_STATIC;
        device_p->uc_mac_arr[i].fid_vid = device_p->port_info_arr_eth[phy_id].vid;

        i++;
    }

    list_len = i;
    i = 0;

    while (i < device_p->log_ports_arr_len && i
           < device_p->uc_mac_arr_len) {
        if (device_p->port_info_arr_eth[i].port_mode == SX_PORT_MODE_NVE) {
            list_len--;
        }
    }


    if (list_len > 0) {
        mac_list = (sx_fdb_uc_mac_addr_params_t*)malloc(list_len * sizeof(sx_fdb_uc_mac_addr_params_t));
        if (mac_list == NULL) {
            SX_LOG_ERR("Failed to allocate memory\n");
            goto out;
        }

        rc = sx_api_fdb_uc_mac_addr_set(
            __handle,
            SX_ACCESS_CMD_ADD,
            device_p->port_info_arr_eth[phy_id].swid,
            mac_list,
            &list_len);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in sx_api_fdb_uc_mac_addr_set , error: %s\n", sx_status_str(rc));
            evb_rc = EVB_STATUS_SDK_ERROR;
            goto out;
        }
    }

out:
    if (mac_list != NULL) {
        free(mac_list);
    }
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __eth_signal_management_software_new_device(IN const device_t *device_p)
{
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();
#if 0
    rxDeviceEvent_t dev_info;
    sx_status_t     rc = SX_STATUS_SUCCESS;


    dev_info.DeviceId = device_p->device_info.dev_id;

    rc = rxtx_send_event(__hw_handle_p, SX_EVENT_NEW_DEVICE_ADD, &(dev_info), sizeof(rxDeviceEvent_t));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to send event through API , error: %s\n", sx_status_str(rc));
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

    SX_LOG_DBG("Sent device notification to software management , device id: [%d]\n",
               device_p->device_info.dev_id);
out:
#else
    UNUSED_PARAM(device_p);
#endif
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __eth_set_vlans(IN uint32_t num_of_active_vlans)
{
    int           i = 0;
    uint32_t      index = 0;
    evb_status_t  evb_rc = EVB_STATUS_SUCCESS;
    sx_vlan_id_t *vlan_list_p = NULL;
    sx_status_t   status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    for (i = 0; i < __swids_count_eth; i++) {
        if (__swids_db_p_eth[i] != SX_SWID_ID_DEFAULT) {
            break;
        }
    }

    if (i == __swids_count_eth) {
        SX_LOG_ERR("Valid swid not found.\n");
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }
    vlan_list_p = (sx_vlan_id_t*)malloc(num_of_active_vlans * sizeof(sx_vlan_id_t));
    if (vlan_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory\n");
        evb_rc = EVB_STATUS_MEMORY_ERROR;
        goto out;
    }

    /*Creating all Vlans except PVID 1 (already configured)*/
    memset(vlan_list_p, 0, num_of_active_vlans * sizeof(sx_vlan_id_t));

    for (index = 1; index < num_of_active_vlans; index++) {
        vlan_list_p[index - 1] = (index + 1);
    }

    num_of_active_vlans--;
    if (num_of_active_vlans == 0) {
        SX_LOG_NTC("input num_of_active_vlans is 1, no need to set vlan!!");
        goto out;
    }
    status = sx_api_vlan_set(__handle, SX_ACCESS_CMD_ADD, __swids_db_p_eth[i],
                             vlan_list_p, &num_of_active_vlans);
    if (status != SX_STATUS_SUCCESS) {
        evb_rc = EVB_STATUS_SDK_ERROR;
        SX_LOG_ERR("sx_api_vlan_set Failed status = %s.\n", sx_status_str(status));
    }

out:
    if (vlan_list_p) {
        free(vlan_list_p);
    }
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __eth_set_port_mapping(IN device_t *device_p, boolean_t issu_start)
{
    int          i = 0;
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (device_p == NULL) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    /* iterate the array of local ports */
    if (!issu_start) {
        for (i = 0; i < device_p->port_info_arr_len_eth; i++) {
            if (device_p->port_info_arr_eth[i].port_mode == SX_PORT_MODE_NVE) {
                continue;
            }

            /* Skip ports that are connected to XM, mapping */
            if (device_p->port_info_arr_eth[i].swid == SX_SWID_ID_DEFAULT) {
                continue;
            }

            evb_rc = __set_port_unmapping_per_port(device_p->device_info.dev_id,
                                                   &(device_p->port_info_arr_eth[i]),
                                                   PORT_SYSTEM_ETH);
            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("Failed in  __set_port_unmapping_per_port, error: %s\n", evb_utils_get_err_str(evb_rc));
            }
        }
    }
    /* iterate the array of local ports */
    for (i = 0; i < device_p->port_info_arr_len_eth; i++) {
        if (device_p->port_info_arr_eth[i].port_mode == SX_PORT_MODE_NVE) {
            continue;
        }
        /* This port is connected to XM, mapping */
        if (device_p->port_info_arr_eth[i].swid == SX_SWID_ID_DEFAULT) {
            continue;
        }

        evb_rc = __set_port_mapping_per_port(device_p->device_info.dev_id,
                                             &(device_p->port_info_arr_eth[i]),
                                             PORT_SYSTEM_ETH);
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed in  __set_port_mapping_per_port, error: %s\n", evb_utils_get_err_str(evb_rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __eth_set_fw_fatal_event_mode(sx_dev_id_t dev_id, uint8_t fw_fatal_event_mode)
{
    evb_status_t       evb_rc = EVB_STATUS_SUCCESS;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;
    struct ku_mfgd_reg mfgd_reg_data;
    sxd_reg_meta_t     mfgd_reg_meta;

    SX_LOG_ENTER();

    memset(&mfgd_reg_data, 0, sizeof(struct ku_mfgd_reg));
    memset(&mfgd_reg_meta, 0, sizeof(sxd_reg_meta_t));


    /* Get the MFGD 1st to make sure all default values are correct */
    mfgd_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    mfgd_reg_meta.dev_id = dev_id;
    mfgd_reg_meta.swid = 0;

    sxd_err = sxd_access_reg_mfgd(&mfgd_reg_data, &mfgd_reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed to read MFGD, return value:[%s]\n", SXD_STATUS_MSG(sxd_err));
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }


    mfgd_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    mfgd_reg_data.fw_fatal_event_mode = fw_fatal_event_mode;
    mfgd_reg_data.en_debug_assert =
        (fw_fatal_event_mode == SXD_MFGD_FW_FATAL_EVENT_MODE_CHECK_FW_FATAL_STOP_FW_E) ? TRUE : FALSE;

    sxd_err = sxd_access_reg_mfgd(&mfgd_reg_data, &mfgd_reg_meta, 1, NULL, NULL);

    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed to set MFGD to re-arm FW trap, return value:[%s]\n",
                   SXD_STATUS_MSG(sxd_err));
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}

evb_status_t __eth_logical_to_label_port(sx_port_log_id_t log_port, uint16_t          *label_port)
{
    device_t    *device_p = NULL;
    int          dev = 0, port = 0;
    evb_status_t rc = EVB_STATUS_SUCCESS;

    SX_LOG_ENTER();

    for (dev = 0; dev < __device_count; ++dev) {
        device_p = &(__device_db_p[dev]);
        for (port = 0; port < device_p->port_info_arr_len_eth; ++port) {
            if (log_port != device_p->log_ports_arr[port]) {
                continue;
            }
            *label_port = device_p->port_info_arr_eth[port].label_port;
            goto out;
        }
    }

    rc = EVB_STATUS_ERROR;

out:
    SX_LOG_EXIT();
    return rc;
}

evb_status_t __port_rate_convert_bitmap(const sx_port_speed_t   speed_bitmap,
                                        boolean_t              *is_ext_port_speed_p,
                                        sx_port_rate_bitmask_t *admin_rate_p)
{
    if (NULL == is_ext_port_speed_p) {
        SX_LOG_ERR("NULL pointer for is_ext_port_speed\n");
        return EVB_STATUS_PARAM_NULL;
    }

    if (NULL == admin_rate_p) {
        SX_LOG_ERR("NULL pointer for admin_rate\n");
        return EVB_STATUS_PARAM_NULL;
    }

    /* Set all speed values to False */
    memset(admin_rate_p, 0x00, sizeof(sx_port_rate_bitmask_t));

    *is_ext_port_speed_p = FALSE;

    if (speed_bitmap == 0xFFFFFFFF) {
        SX_LOG_DBG("0xFFFFFFFF speed value is used in legacy flow to specify auto-mode.\n");
        admin_rate_p->rate_auto = TRUE;
        return EVB_STATUS_SUCCESS;
    }

    /* The following validation is to check that we are not going to use 0 speed value for
     *  the following SDK initialization. For example if speed_bitmap == (0 | (1 << 31)), we
     *  should ignore this value. */
    if ((speed_bitmap ^ EVB_PORT_SPEED_API_TYPE_RATE) == 0) {
        SX_LOG_DBG("We wont use 0 speed value for port speed configuration.\n");
        return EVB_STATUS_SUCCESS;
    }


    /* Go over every bit in the 'speed_bitmap' and check whether it is set to 1 */

    /* 100M */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 0)) == TRUE) {
        admin_rate_p->rate_100M = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 1G */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 1)) == TRUE) {
        admin_rate_p->rate_1G = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 10G */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 4)) == TRUE) {
        admin_rate_p->rate_10G = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 40G */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 5)) == TRUE) {
        admin_rate_p->rate_40G = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 25G */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 6)) == TRUE) {
        admin_rate_p->rate_25G = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 50G - 2x */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 7)) == TRUE) {
        admin_rate_p->rate_50Gx2 = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 50G - 1x */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 8)) == TRUE) {
        admin_rate_p->rate_50Gx1 = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 100G - 4x */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 9)) == TRUE) {
        admin_rate_p->rate_100Gx4 = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 100G - 2x */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 10)) == TRUE) {
        admin_rate_p->rate_100Gx2 = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 100G - 1x */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 11)) == TRUE) {
        admin_rate_p->rate_100Gx1 = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 200G - 4x */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 12)) == TRUE) {
        admin_rate_p->rate_200Gx4 = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 200G - 2x */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 13)) == TRUE) {
        admin_rate_p->rate_200Gx2 = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 400G - 8x */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 15)) == TRUE) {
        admin_rate_p->rate_400Gx8 = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 400G - 4x */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 16)) == TRUE) {
        admin_rate_p->rate_400Gx4 = TRUE;
        *is_ext_port_speed_p = TRUE;
    }

    /* 800G */
    if (EVB_PORT_SPEED_ENABLED_GET(speed_bitmap, (1 << 19)) == TRUE) {
        admin_rate_p->rate_800G = TRUE;
        *is_ext_port_speed_p = TRUE;
    }
    return EVB_STATUS_SUCCESS;
}

evb_status_t __port_speed_capability_disable_all(sx_port_speed_capability_t* speed_capability)
{
    if (NULL == speed_capability) {
        SX_LOG_ERR("NULL pointer: Port Speed Capability\n");
        return EVB_STATUS_PARAM_NULL;
    }

    speed_capability->mode_1GB_CX_SGMII = FALSE;
    speed_capability->mode_1GB_KX = FALSE;
    speed_capability->mode_10GB_CX4_XAUI = FALSE;
    speed_capability->mode_10GB_KR = FALSE;
    speed_capability->mode_10GB_KX4 = FALSE;
    speed_capability->mode_20GB_KR2 = FALSE;
    speed_capability->mode_40GB_CR4 = FALSE;
    speed_capability->mode_40GB_KR4 = FALSE;
    speed_capability->mode_56GB_KR4 = FALSE;
    speed_capability->mode_56GB_KX4 = FALSE;
    speed_capability->mode_10GB_CR = FALSE;
    speed_capability->mode_10GB_SR = FALSE;
    speed_capability->mode_10GB_ER_LR = FALSE;
    speed_capability->mode_40GB_SR4 = FALSE;
    speed_capability->mode_40GB_LR4_ER4 = FALSE;
    speed_capability->mode_100GB_CR4 = FALSE;
    speed_capability->mode_100GB_SR4 = FALSE;
    speed_capability->mode_100GB_KR4 = FALSE;
    speed_capability->mode_100GB_LR4_ER4 = FALSE;
    speed_capability->mode_25GB_CR = FALSE;
    speed_capability->mode_25GB_KR = FALSE;
    speed_capability->mode_25GB_SR = FALSE;
    speed_capability->mode_50GB_CR2 = FALSE;
    speed_capability->mode_50GB_KR2 = FALSE;
    speed_capability->mode_50GB_SR2 = FALSE;
    speed_capability->mode_auto = FALSE;
    speed_capability->force = FALSE;
    speed_capability->mode_10MB_T = FALSE;
    speed_capability->mode_100MB_TX = FALSE;
    speed_capability->mode_1000MB_T = FALSE;

    return EVB_STATUS_SUCCESS;
}

evb_status_t __port_speed_convert_bitmap_to_capability(const sx_port_speed_t       speed_bitmap,
                                                       sx_port_speed_capability_t* speed_capability)
{
    evb_status_t rc = EVB_STATUS_SUCCESS;

    if (NULL == speed_capability) {
        SX_LOG_ERR("NULL pointer: Port Speed Capability\n");
        return EVB_STATUS_PARAM_NULL;
    }

    rc = __port_speed_capability_disable_all(speed_capability);
    if (EVB_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed in  port_speed_convert_bitmap_to_capability, error: %s\n", evb_utils_get_err_str(rc));
        return rc;
    }

    if (speed_bitmap & 1) {
        speed_capability->mode_1GB_CX_SGMII = TRUE;
    }
    if (speed_bitmap & 1 << 1) {
        speed_capability->mode_1GB_KX = TRUE;
    }
    if (speed_bitmap & 1 << 2) {
        speed_capability->mode_10GB_CX4_XAUI = TRUE;
    }
    if (speed_bitmap & 1 << 3) {
        speed_capability->mode_10GB_KX4 = TRUE;
    }
    if (speed_bitmap & 1 << 4) {
        speed_capability->mode_10GB_KR = TRUE;
    }
    if (speed_bitmap & 1 << 5) {
        speed_capability->mode_20GB_KR2 = TRUE;
    }
    if (speed_bitmap & 1 << 6) {
        speed_capability->mode_40GB_CR4 = TRUE;
    }
    if (speed_bitmap & 1 << 7) {
        speed_capability->mode_40GB_KR4 = TRUE;
    }
    if (speed_bitmap & 1 << 8) {
        speed_capability->mode_56GB_KR4 = TRUE;
    }
    if (speed_bitmap & 1 << 9) {
        speed_capability->mode_56GB_KX4 = TRUE;
    }
    if (speed_bitmap & 1 << 10) {
        speed_capability->mode_10MB_T = TRUE;
    }
    if (speed_bitmap & 1 << 12) {
        speed_capability->mode_10GB_CR = TRUE;
    }
    if (speed_bitmap & 1 << 13) {
        speed_capability->mode_10GB_SR = TRUE;
    }
    if (speed_bitmap & 1 << 14) {
        speed_capability->mode_10GB_ER_LR = TRUE;
    }
    if (speed_bitmap & 1 << 15) {
        speed_capability->mode_40GB_SR4 = TRUE;
    }
    if (speed_bitmap & 1 << 16) {
        speed_capability->mode_40GB_LR4_ER4 = TRUE;
    }
    if (speed_bitmap & 1 << 18) {
        speed_capability->mode_50GB_SR2 = TRUE;
    }
    if (speed_bitmap & 1 << 20) {
        speed_capability->mode_100GB_CR4 = TRUE;
    }
    if (speed_bitmap & 1 << 21) {
        speed_capability->mode_100GB_SR4 = TRUE;
    }
    if (speed_bitmap & 1 << 22) {
        speed_capability->mode_100GB_KR4 = TRUE;
    }
    if (speed_bitmap & 1 << 23) {
        speed_capability->mode_100GB_LR4_ER4 = TRUE;
    }
    if (speed_bitmap & 1 << 24) {
        speed_capability->mode_100MB_TX = TRUE;
    }
    if (speed_bitmap & 1 << 25) {
        speed_capability->mode_1000MB_T = TRUE;
    }
    if (speed_bitmap & 1 << 27) {
        speed_capability->mode_25GB_CR = TRUE;
    }
    if (speed_bitmap & 1 << 28) {
        speed_capability->mode_25GB_KR = TRUE;
    }
    if (speed_bitmap & 1 << 29) {
        speed_capability->mode_25GB_SR = TRUE;
    }
    if (speed_bitmap & 1 << 30) {
        speed_capability->mode_50GB_CR2 = TRUE;
    }
    if (speed_bitmap & 1 << 31) {
        speed_capability->mode_50GB_KR2 = TRUE;
    }
    if (speed_bitmap == 0xFFFFFFFF) {
        speed_capability->mode_auto = TRUE;
    }


    return EVB_STATUS_SUCCESS;
}

/*
 * Register based swid initialization
 */
evb_status_t __eth_evb_sdk_self_init_swids(uint8_t swid_bmap)
{
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;
    uint8_t      swid_val = 0;
    sx_swid_t    swids_eth[SXD_SWID_ID_COUNT];
    sx_swid_t    swids_ib[SXD_SWID_ID_COUNT];

    SX_LOG_ENTER();

    memset((swids_eth), 0, sizeof(swids_eth));
    memset((swids_ib), 0, sizeof(swids_ib));

    /* when there is no SWID, add default SWID(0) */
    if (swid_bmap == 0) {
        swids_eth[__swids_count_eth] = SXD_SWID_MIN;
        __swids_count_eth++;
    }

    while (swid_bmap != 0) {
        if (swid_bmap & 0x01) {
            swids_eth[__swids_count_eth] = swid_val;
            __swids_count_eth++;
        }
        swid_bmap = swid_bmap >> 1;
        swid_val++;
    }

    /* allocate memory */
    evb_rc = EVB_UTILS_CLR_MEM_GET(&__swids_db_p_eth, __swids_count_eth, sizeof(sx_swid_t));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to allocate memory for swids_arr_p , error: %s\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }
    memcpy(__swids_db_p_eth, swids_eth, (__swids_count_eth * sizeof(sx_swid_t)));
out:
    SX_LOG_EXIT();
    return evb_rc;
}


/*
 * Register based local port and swid initialization
 */
evb_status_t __eth_evb_sdk_self_init_swid_ports(OUT device_t *device_p, boolean_t use_2nd_bonus_port)
{
    uint8_t                 swid_bmap = 0x00;
    struct ku_ptys_reg      ptys_reg;
    struct ku_pspa_reg      pspa_reg;
    uint32_t                index = 0;
    sxd_reg_meta_t          reg_meta;
    sxd_status_t            sxd_err = SXD_STATUS_SUCCESS;
    evb_status_t            evb_rc = EVB_STATUS_SUCCESS;
    evb_status_t            rc = EVB_STATUS_SUCCESS;
    sx_status_t             sx_err = SX_STATUS_SUCCESS;
    port_info_t            *port_info_arr_eth = NULL;
    int                     port_info_arr_eth_len = 0;
    sx_chip_types_t         chip_type = SX_CHIP_TYPE_UNKNOWN;
    struct ku_query_rsrc    rsrc_info;
    uint32_t                max_ports;
    uint32_t                tunnel_port_count = DEFAULT_NVE_PORT_COUNT;
    sx_port_tunnel_phy_id_t tunnel_local_port[DEFAULT_NVE_PORT_COUNT] =
    {SX_PORT_TUNNEL_NVE,
     SX_PORT_TUNNEL_FLEX0,
     SX_PORT_TUNNEL_FLEX1};

    SX_LOG_ENTER();
    memset(&(reg_meta), 0, sizeof(reg_meta));
    reg_meta.dev_id = EVB_DEFAULT_DEVICE_NUMBER;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    memset(&rsrc_info, 0, sizeof(rsrc_info));
    rsrc_info.rsrc_id = KU_RES_ID_CAP_MAX_SWITCH_PORTS;

    sxd_err = sxd_access_reg_query_rsrc_info(&rsrc_info);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed in FW command Query_RSRC error: %s\n", SXD_STATUS_MSG(sxd_err));
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    } else {
        max_ports = rsrc_info.rsrc_val;

        if (!use_2nd_bonus_port && (max_ports == 258)) {
            max_ports = 257;
        }
    }

    /* total number of ports is max port + nve port + 2 flex tunnels in SDK */
    evb_rc = EVB_UTILS_CLR_MEM_GET(&port_info_arr_eth, max_ports + DEFAULT_NVE_PORT_COUNT, sizeof(port_info_t));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to allocate memory for devices eth port array , error: %s\n",
                   evb_utils_get_err_str(evb_rc));
        goto out;
    }

    for (index = 1; index <= max_ports; index++) {
        memset(&pspa_reg, 0, sizeof(pspa_reg));
        reg_meta.swid = 0;
        pspa_reg.swid = 0;
        pspa_reg.sub_port = 0;
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pspa_reg.local_port, pspa_reg.lp_msb, index);

        /* Find the port/ swid mapping */
        sxd_err = sxd_access_reg_pspa(&pspa_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in PSPA get (PORT Switch Partition Allocation), error: %s, local_port = %u\n",
                       SXD_STATUS_MSG(sxd_err), index);
            evb_rc = EVB_STATUS_ERROR;
            goto out;
        }

        if (pspa_reg.swid != 0xFF) { /* swid (0xFF) is disabled port */
            if (pspa_reg.swid <= SXD_SWID_MAX) {
                swid_bmap |= 1 << pspa_reg.swid;
            }
            reg_meta.swid = pspa_reg.swid;
            memset(&ptys_reg, 0, sizeof(ptys_reg));
            SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(ptys_reg.local_port, ptys_reg.lp_msb, index);

            ptys_reg.proto_mask = EVB_PORT_TYPE_PROTOCOL_MASK_ETH;
            sxd_err = sxd_access_reg_ptys(&ptys_reg, &reg_meta, 1, NULL, NULL);
            if (SXD_CHECK_FAIL(sxd_err)) {
                SX_LOG_ERR("Failed in PTYS get (PORT SPEED and CAPABILITY), error: %s, local_port = %u\n",
                           SXD_STATUS_MSG(sxd_err), index);
                evb_rc = EVB_STATUS_ERROR;
                goto out;
            }

#if defined(PD_BU) && defined(PD_BU_PTYS_STUB)
            /* Stub for PTYS - FW stub will return 0 for proto capabilities, setting expected number here */
            sxd_access_sdk_ptys_eth_proto_cap_for_pd_set(&ptys_reg);
#endif
            /* Check whether ext_eth_proto_capability has any value.
             *  If yes - that means that we (and FW) are going to use ext_eth_proto fields which allow to have 400Gbps. */
            if (ptys_reg.ext_eth_proto_capability != 0) {
                port_info_arr_eth[port_info_arr_eth_len].port_speed = ptys_reg.ext_eth_proto_capability |
                                                                      EVB_PORT_SPEED_API_TYPE_RATE;
            } else {
                port_info_arr_eth[port_info_arr_eth_len].port_speed = ptys_reg.eth_proto_capability;
            }

            evb_rc = __eth_evb_sdk_self_init_port(&port_info_arr_eth[port_info_arr_eth_len],
                                                  index,
                                                  pspa_reg.swid);
            if (EVB_CHECK_FAIL(evb_rc)) {
                SX_LOG_ERR("Failed to itself initialize ports, error: %s\n",  evb_utils_get_err_str(evb_rc));
                goto out;
            }
            port_info_arr_eth_len++;
        }
    }

    sx_err = __get_chip_type(__handle, &chip_type);
    if (SX_CHECK_FAIL(sx_err)) {
        printf("__get_chip_type failed (%s)\n", sx_status_str(sx_err));
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }
    switch (chip_type) {
    case SX_CHIP_TYPE_SWITCH_IB:
    case SX_CHIP_TYPE_SPECTRUM:
    case SX_CHIP_TYPE_SWITCH_IB2:
    case SX_CHIP_TYPE_SPECTRUM_A1:
        tunnel_port_count = 1;
        break;

    default:
        tunnel_port_count = DEFAULT_NVE_PORT_COUNT;
        break;
    }

    /* Initialize the s/w only NVE/Tunnel ports for Ethernet profiles */
    for (index = 0; index < tunnel_port_count; index++) {
        port_info_arr_eth[port_info_arr_eth_len].port_mode = SX_PORT_MODE_TUNNEL;
        port_info_arr_eth[port_info_arr_eth_len].port_mapping.local_port = tunnel_local_port[index];
        port_info_arr_eth_len++;
    }
    device_p->port_info_arr_len_eth = port_info_arr_eth_len;
    if (port_info_arr_eth_len != 0) {
        /* allocate memory for port_info_arr in device db*/
        evb_rc = EVB_UTILS_CLR_MEM_GET(&device_p->port_info_arr_eth, port_info_arr_eth_len, sizeof(port_info_t));
        if (EVB_CHECK_FAIL(evb_rc)) {
            SX_LOG_ERR("Failed to allocate memory for device port info , error: %s\n", evb_utils_get_err_str(
                           evb_rc));
            goto out;
        }
        memcpy(device_p->port_info_arr_eth, port_info_arr_eth, (port_info_arr_eth_len * sizeof(port_info_t)));
    }

    evb_rc = __eth_evb_sdk_self_init_swids(swid_bmap);

out:
    if (port_info_arr_eth) {
        rc = EVB_PORT_UTILS_MEM_PUT(port_info_arr_eth);
        if (EVB_STATUS_SUCCESS != rc) {
            evb_rc = rc;
            SX_LOG_ERR("Failed to free port attributes. Err = %d\n", evb_rc);
        }
    }
    SX_LOG_EXIT();
    return evb_rc;
}


/*
 * Register based local port initialization
 */
evb_status_t __eth_evb_sdk_self_init_port(port_info_t *port_info_p, int local_port, sx_swid_t swid)
{
    struct ku_pmlp_reg pmlp_reg;
    sxd_reg_meta_t     reg_meta;
    int                lane;
    evb_status_t       evb_rc = EVB_STATUS_SUCCESS;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();


    if (port_info_p == NULL) {
        SX_LOG_ERR("__evb_sdk_self_init_port null parameter\n");
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    memset(&(reg_meta), 0, sizeof(reg_meta));
    reg_meta.dev_id = EVB_DEFAULT_DEVICE_NUMBER;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.swid = swid;
    memset(&pmlp_reg, 0, sizeof(pmlp_reg));
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pmlp_reg.local_port, pmlp_reg.lp_msb, local_port);

    sxd_err = sxd_access_reg_pmlp(&pmlp_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed in PMLP get (PORT Switch Partition Allocation), error: %s, local_port = %u\n",
                   SXD_STATUS_MSG(sxd_err), local_port);
        evb_rc = EVB_STATUS_ERROR;
        goto out;
    }

    port_info_p->port_mapping.local_port = local_port;
    evb_rc = __evb_sdk_self_init_port_defaults(port_info_p);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to initialize port defaults, error: %s\n",  evb_utils_get_err_str(evb_rc));
        goto out;
    }

    port_info_p->swid = swid;

    if (swid == SX_SWID_ID_STACKING) {
        port_info_p->port_mode = SX_PORT_MODE_STACKING;
    } else {
        port_info_p->port_mode = SX_PORT_MODE_EXTERNAL;
    }

    port_info_p->port_mapping.module_port = pmlp_reg.module[0];
    port_info_p->port_mapping.slot = pmlp_reg.slot[0];
    port_info_p->port_mapping.width = pmlp_reg.width;
    port_info_p->module_lane_map.use_different_rx_tx = pmlp_reg.use_different_rx_tx;
    for (lane = 0; lane < pmlp_reg.width; lane++) {
        port_info_p->port_mapping.lane_bmap |= (1 << pmlp_reg.lane[lane]);
        port_info_p->module_lane_map.module[lane] = pmlp_reg.module[lane];
        port_info_p->module_lane_map.slot[lane] = pmlp_reg.slot[lane];
        port_info_p->module_lane_map.lane[lane] = pmlp_reg.lane[lane];
        if (pmlp_reg.use_different_rx_tx) {
            port_info_p->module_lane_map.rx_lane[lane] = pmlp_reg.rx_lane[lane];
        } else {
            port_info_p->module_lane_map.rx_lane[lane] = 0;
        }
    }

    port_info_p->label_port = pmlp_reg.module[0] + 1;

out:
    SX_LOG_EXIT();
    return evb_rc;
}


evb_status_t __eth_evb_sdk_xml_init(boolean_t issu_start,
                                    boolean_t pdb_lag_init,
                                    boolean_t pdb_port_map_init,
                                    uint8_t   fw_fatal_event_mode,
                                    boolean_t port_state_down_mode,
                                    uint8_t   port_speed_rate_mode,
                                    boolean_t disable_health_check,
                                    boolean_t use_2nd_bonus_port)
{
    evb_status_t evb_rc;

    /*****************************************************************************/
    /*		               PARSING SECTION				                         */
    /*****************************************************************************/
    /* parse device count section in the XML file */
    evb_rc = __parse_device_count_section(&__device_count);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to fetch number of devices in file , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* allocate memory for device DB */
    evb_rc = EVB_UTILS_CLR_MEM_GET(&__device_db_p, __device_count, sizeof(device_t));
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed to allocate memory for devices array , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    /* parse swids section in the XML file */
    evb_rc = __parse_swid_section(&(__swids_count_eth), &(__swids_db_p_eth), "swids");
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in __parse_swid_section , error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

    is_eth_from_xml_init = TRUE;
    evb_rc = __eth_handle_profile(issu_start,
                                  pdb_lag_init,
                                  pdb_port_map_init,
                                  fw_fatal_event_mode,
                                  port_state_down_mode,
                                  port_speed_rate_mode,
                                  disable_health_check,
                                  use_2nd_bonus_port);
    if (EVB_CHECK_FAIL(evb_rc)) {
        SX_LOG_ERR("Failed in  __handle_eth_profile, error: %s\n", evb_utils_get_err_str(evb_rc));
        goto out;
    }

out:

    return evb_rc;
}

evb_status_t __eth_parse_port_info_section(IN sx_xml_element_t *child_p, OUT port_info_t     *port_info_p)
{
    evb_status_t evb_rc = EVB_STATUS_SUCCESS;
    int          ret_value = 0;
    uint32_t     lane_index = 0;

    SX_LOG_ENTER();

    if (port_info_p == NULL) {
        evb_rc = EVB_STATUS_PARAM_NULL;
        goto out;
    }

    sx_xml_element_t *local_port_element = sx_xml_element_by_name_get(
        child_p, "local-port");
    sx_xml_element_t *mapping_mode_element = sx_xml_element_by_name_get(
        child_p, "mapping-mode");
    sx_xml_element_t *port_label_element = sx_xml_element_by_name_get(
        child_p, "port-label");
    sx_xml_element_t *width_element = sx_xml_element_by_name_get(
        child_p, "width");
    sx_xml_element_t *use_rx_lanes_element = sx_xml_element_by_name_get(
        child_p, "use-rx-lanes");
    sx_xml_element_t *rx_lanes_element = sx_xml_element_by_name_get(
        child_p, "rx-lanes");
    sx_xml_element_t *lanes_element = sx_xml_element_by_name_get(
        child_p, "lanes");
    sx_xml_element_t *lane_to_module_element = sx_xml_element_by_name_get(
        child_p, "lane-to-module");
    sx_xml_element_t *lane_to_slot_element = sx_xml_element_by_name_get(
        child_p, "lane-to-slot");
    sx_xml_element_t *port_mode_element = sx_xml_element_by_name_get(
        child_p, "port-mode");
    sx_xml_element_t *rstp_port_state_element = sx_xml_element_by_name_get(
        child_p, "rstp-port-state");
    sx_xml_element_t *port_speed_element = sx_xml_element_by_name_get(
        child_p, "port-speed");
    sx_xml_element_t *port_state_element = sx_xml_element_by_name_get(
        child_p, "port-state");
    sx_xml_element_t *swid_element = sx_xml_element_by_name_get(
        child_p, "swid");
    sx_xml_element_t *vid_element = sx_xml_element_by_name_get(
        child_p, "vid");
    sx_xml_element_t *phys_loopback_element = sx_xml_element_by_name_get(
        child_p, "phys-loopback");

    if (local_port_element != NULL) {
        port_info_p->port_mapping.local_port = atoi(sx_xml_element_content_get(
                                                        local_port_element));
    } else {
        SX_LOG_ERR("Error parsing local port number\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (mapping_mode_element != NULL) {
        port_info_p->port_mapping.mapping_mode = atoi(sx_xml_element_content_get(
                                                          mapping_mode_element));
    } else {
        SX_LOG_ERR("Error parsing mapping mode\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (port_label_element != NULL) {
        port_info_p->label_port = atoi(sx_xml_element_content_get(
                                           port_label_element));
    } else {
        SX_LOG_ERR("Error parsing label port\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (width_element != NULL) {
        port_info_p->port_mapping.width = atoi(sx_xml_element_content_get(
                                                   width_element));
    } else {
        SX_LOG_ERR("Error parsing width value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (use_rx_lanes_element != NULL) {
        port_info_p->module_lane_map.use_different_rx_tx =
            atoi(sx_xml_element_content_get(use_rx_lanes_element));
    } else {
        /* default value */
        port_info_p->module_lane_map.use_different_rx_tx = 0;
    }

    if ((rx_lanes_element != NULL) &&
        port_info_p->module_lane_map.use_different_rx_tx) {
        char *rx_lanes_str = (char*)sx_xml_element_content_get(rx_lanes_element);

        if (rx_lanes_str != NULL) {
            ret_value = sscanf(rx_lanes_str, "%hhd , %hhd , %hhd , %hhd , %hhd , %hhd , %hhd , %hhd",
                               &(port_info_p->module_lane_map.rx_lane[0]),
                               &(port_info_p->module_lane_map.rx_lane[1]),
                               &(port_info_p->module_lane_map.rx_lane[2]),
                               &(port_info_p->module_lane_map.rx_lane[3]),
                               &(port_info_p->module_lane_map.rx_lane[4]),
                               &(port_info_p->module_lane_map.rx_lane[5]),
                               &(port_info_p->module_lane_map.rx_lane[6]),
                               &(port_info_p->module_lane_map.rx_lane[7]));
            /* coverity[example_checked] */
            if (ret_value == EOF) {
                SX_LOG_ERR("Error parsing RX lanes value , local port: [%d]\n",
                           port_info_p->port_mapping.local_port);
                evb_rc = EVB_STATUS_PARSE_ERROR;
            }
        }
    } else {
        /* Make sure that all rx_lanes are set to 0 */
        memset(port_info_p->module_lane_map.rx_lane,
               0,
               sizeof(port_info_p->module_lane_map.rx_lane[0]) * LCL_PORT_LANE_NUM);
    }

    if (lanes_element != NULL) {
        char *lanes_str = (char*)sx_xml_element_content_get(lanes_element);

        if (lanes_str != NULL) {
            ret_value = sscanf(lanes_str, "%hhd , %hhd , %hhd , %hhd , %hhd , %hhd , %hhd , %hhd",
                               &(port_info_p->module_lane_map.lane[0]),
                               &(port_info_p->module_lane_map.lane[1]),
                               &(port_info_p->module_lane_map.lane[2]),
                               &(port_info_p->module_lane_map.lane[3]),
                               &(port_info_p->module_lane_map.lane[4]),
                               &(port_info_p->module_lane_map.lane[5]),
                               &(port_info_p->module_lane_map.lane[6]),
                               &(port_info_p->module_lane_map.lane[7]));

            if (ret_value == EOF) {
                SX_LOG_ERR("Error parsing lanes value , local port: [%d]\n", port_info_p->port_mapping.local_port);
                evb_rc = EVB_STATUS_PARSE_ERROR;
            }

            port_info_p->port_mapping.lane_bmap = 0;
            for (lane_index = 0; lane_index < port_info_p->port_mapping.width; lane_index++) {
                port_info_p->port_mapping.lane_bmap |= 0x01 << port_info_p->module_lane_map.lane[lane_index];
            }
        }
    } else {
        SX_LOG_ERR("Error parsing lanes value , local port: [%d]\n", port_info_p->port_mapping.local_port);
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (lane_to_module_element != NULL) {
        char *lane_to_module_str = (char*)sx_xml_element_content_get(lane_to_module_element);

        if (lane_to_module_str != NULL) {
            ret_value = sscanf(lane_to_module_str, "%hhd , %hhd , %hhd , %hhd , %hhd , %hhd , %hhd , %hhd",
                               &(port_info_p->module_lane_map.module[0]),
                               &(port_info_p->module_lane_map.module[1]),
                               &(port_info_p->module_lane_map.module[2]),
                               &(port_info_p->module_lane_map.module[3]),
                               &(port_info_p->module_lane_map.module[4]),
                               &(port_info_p->module_lane_map.module[5]),
                               &(port_info_p->module_lane_map.module[6]),
                               &(port_info_p->module_lane_map.module[7]));
            /***** THIS IS A TEMP CODE - should check which lanes are mapped to module and take the right bit *****/
            port_info_p->port_mapping.module_port = port_info_p->module_lane_map.module[0];

            if (ret_value == EOF) {
                SX_LOG_ERR("Error parsing lane to module value , local port: [%d]\n",
                           port_info_p->port_mapping.local_port);
                evb_rc = EVB_STATUS_PARSE_ERROR;
            }
        }
    } else {
        SX_LOG_ERR("Error parsing lane to module value , local port: [%d]\n",
                   port_info_p->port_mapping.local_port);
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (lane_to_slot_element != NULL) {
        char *lane_to_slot_str = (char*)sx_xml_element_content_get(lane_to_slot_element);
        if (lane_to_slot_str != NULL) {
            ret_value = sscanf(lane_to_slot_str, "%hhd , %hhd , %hhd , %hhd , %hhd , %hhd , %hhd , %hhd",
                               &(port_info_p->module_lane_map.slot[0]),
                               &(port_info_p->module_lane_map.slot[1]),
                               &(port_info_p->module_lane_map.slot[2]),
                               &(port_info_p->module_lane_map.slot[3]),
                               &(port_info_p->module_lane_map.slot[4]),
                               &(port_info_p->module_lane_map.slot[5]),
                               &(port_info_p->module_lane_map.slot[6]),
                               &(port_info_p->module_lane_map.slot[7]));

            port_info_p->port_mapping.slot = port_info_p->module_lane_map.slot[0];
            if (ret_value == EOF) {
                SX_LOG_ERR("Error parsing lane to slot value , local port: [%d]\n",
                           port_info_p->port_mapping.local_port);
                evb_rc = EVB_STATUS_PARSE_ERROR;
            }
        }
    } else {
        port_info_p->port_mapping.slot = 0;
        SX_LOG_DBG("Default Lane to slot value(0) assigned to  local port: [%d]\n",
                   port_info_p->port_mapping.local_port);
    }
    if (port_mode_element != NULL) {
        port_info_p->port_mode = atoi(sx_xml_element_content_get(
                                          port_mode_element));
    } else {
        SX_LOG_ERR("Error parsing port mode value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (rstp_port_state_element != NULL) {
        port_info_p->mstp_port_state = atoi(sx_xml_element_content_get(
                                                rstp_port_state_element));
    } else {
        SX_LOG_ERR("Error parsing rstp state value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (port_speed_element != NULL) {
        port_info_p->port_speed = atoi(sx_xml_element_content_get(
                                           port_speed_element));
    } else {
        SX_LOG_ERR("Error parsing port speed value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (port_state_element != NULL) {
        port_info_p->port_state = atoi(sx_xml_element_content_get(
                                           port_state_element));
    } else {
        SX_LOG_ERR("Error parsing port state value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (swid_element != NULL) {
        port_info_p->swid = atoi(sx_xml_element_content_get(
                                     swid_element));
    } else {
        SX_LOG_ERR("Error parsing swid value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (vid_element != NULL) {
        port_info_p->vid = atoi(sx_xml_element_content_get(
                                    vid_element));
    } else {
        SX_LOG_ERR("Error parsing vid value\n");
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

    if (phys_loopback_element != NULL) {
        port_info_p->phys_loopback = atoi(sx_xml_element_content_get(
                                              phys_loopback_element));
    } else {
        SX_LOG_ERR("Error parsing physical loopback values , local port: [%d]\n",
                   port_info_p->port_mapping.local_port);
        evb_rc = EVB_STATUS_PARSE_ERROR;
    }

out:
    SX_LOG_EXIT();
    return evb_rc;
}
