#!/bin/bash
#
# Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# This software product is a proprietary product of Nvidia Corporation and its affiliates
# (the "Company") and all right, title, and interest in and to the software
# product, including all associated intellectual property rights, are and
# shall remain exclusively with the Company.
#
# This software product is governed by the End User License Agreement
# provided with the software product.
#

basedir=`readlink -f $0`
basedir=${basedir%/*}

profile=${1:-"eth-single"}
target=${2:-"dvk"}
sdk_mode=${3:-"802.1Q"}
max_vlan=${4:-"0"}
boot_mode="${BOOT_MODE:-DISABLED}"
pdb_lag_init="${PDB_LAG_INIT}"
port_state_down_mode="${PORT_STATE_DOWN_MODE}"
port_speed_rate_mode="${PORT_SPEED_RATE_MODE:-DEFAULT}"
fw_fatal_event_mode="${FW_FATAL_EVENT_MODE:-FW_NO_CHECK}"
disable_health_check=""
do_not_init_with_port_profile=""

if [ -z "${SDK_CONFIG_FILE}" ]; then
    config_file=${basedir}/../share/dvs_manager_${profile%-*}_${target}.xml
else
    config_file=${SDK_CONFIG_FILE}
fi

if [ "$SDK_VERBOSITY" == "no" ]; then
    verbosity_flags="--no_verbosity"
else
    if [ "$SDK_VERBOSITY" != "" ]; then
        verbosity_flags="--verbosity=$SDK_VERBOSITY"
    fi
fi

if [[ "$BOOT_MODE" != "NORMAL" && "$BOOT_MODE" != "FAST" && "$BOOT_MODE" != "ISSU_NORMAL" && "$BOOT_MODE" != "ISSU_FAST" && "$BOOT_MODE" != "ISSU_STARTED" ]]
then
    echo "invalid or missing boot_mode, setting boot_mode = DISABLED"
fi

if [[ "$FW_FATAL_EVENT_MODE" != "FW_NO_CHECK" && "$FW_FATAL_EVENT_MODE" != "FW_CONTINUE" && "$FW_FATAL_EVENT_MODE" != "FW_HALT" ]]
then
    echo "invalid or missing fw_fatal_event_mode, setting fw_fatal_event_mode = FW_NO_CHECK"
fi

if [[ "$PORT_SPEED_RATE_MODE" != "DEFAULT" && "$PORT_SPEED_RATE_MODE" != "SPEED" && "$PORT_SPEED_RATE_MODE" != "RATE" ]]
then
    echo "invalid or missing port_speed_rate_mode, setting port_speed_rate_mode = DEFAULT"
fi

if [ "$PDB_LAG_INIT" != "" ]; then
    pdb_lag_init="--pdb_lag_init "
fi

if [ "$DO_NOT_INIT_WITH_PORT_PROFILE" != "" ]; then
    do_not_init_with_port_profile="--do_not_init_with_port_profile "
fi

if [ "$PORT_STATE_DOWN_MODE" != "" ]; then
    port_state_down_mode="--port_state_down_mode "
fi

if [ "$PDB_PORT_MAP_INIT" != "" ]; then
    pdb_port_map_init="--pdb_port_map_init "
fi

if [ "${DISABLE_HEALTH_CHECK}" != "" ]; then
    disable_health_check="--disable_health_check"
    echo "Disabling health check"
fi

if [ "$SX_USE_2ND_BONUS_PORT" != "" ]; then
    use_2nd_bonus_port="--use_2nd_bonus_port"
fi

wait_dvs_manager_ready() {
   while screen -ls | grep -q dvs_manager_gdb; do
        sleep 0.001
   done
}

dvs_manager_cmd="${basedir}/dvs_manager ${evb_evb_manager_suffix} --sdk_mode ${sdk_mode} --max_vlan ${max_vlan} ${profile} ${config_file} --boot_mode ${boot_mode} --port_speed_rate_mode ${port_speed_rate_mode} ${pdb_lag_init} ${port_state_down_mode} ${pdb_port_map_init} --fw_fatal_event_mode ${fw_fatal_event_mode} ${disable_health_check} ${verbosity_flags} ${do_not_init_with_port_profile} ${use_2nd_bonus_port}"
if [ "${START_DVS_MANAGER_WITH_GDB}" != "" ]; then
echo "========================================================================================================"
screen -dmS "dvs_manager_gdb" bash -c "${evb_evb_manager_prefix} gdb -ex 'set pagination off' -ex=start -q -tui --args ${dvs_manager_cmd} || exit 1"
echo "Please attach GDB screen with following command below to continue"
echo "screen -r dvs_manager_gdb"
echo "========================================================================================================"
wait_dvs_manager_ready
else
${evb_evb_manager_prefix} ${dvs_manager_cmd} || exit 1
fi