/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <unistd.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <time.h>


#include "flex_acl_gen_def.h"
#include "flex_acl_keys_scp.h"


#define NUM_ROUNDS 250

static const char * const sx_acl_key_str_s[] = {
    [FLEX_ACL_KEY_SWITCH_PRIO] = "SWITCH_PRIO",                                                 \
    [FLEX_ACL_KEY_INNER_DSCP] = "INNER_DSCP",                                                   \
    [FLEX_ACL_KEY_TX_PORT_LIST] = "TX_PORT_LIST",                                               \
    [FLEX_ACL_KEY_TUNNEL_TYPE] = "TUNNEL_TYPE",                                                 \
    [FLEX_ACL_KEY_GP_REGISTER_5_VALID] = "GP_REGISTER_5_VALID",                                 \
    [FLEX_ACL_KEY_DISCARD_STATE] = "DISCARD_STATE",                                             \
    [FLEX_ACL_KEY_GP_REGISTER_6] = "GP_REGISTER_6",                                             \
    [FLEX_ACL_KEY_CUSTOM_BYTE_22] = "CUSTOM_BYTES_22",                                          \
    [FLEX_ACL_KEY_CUSTOM_BYTE_21] = "CUSTOM_BYTES_21",                                          \
    [FLEX_ACL_KEY_CUSTOM_BYTE_20] = "CUSTOM_BYTES_20",                                          \
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_2] = "INNER_MPLS_LABEL_ID_2",                             \
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_3] = "INNER_MPLS_LABEL_ID_3",                             \
    [FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_1] = "INNER_MPLS_LABEL_ID_1",                             \
    [FLEX_ACL_KEY_DEFAULT_ROUTE_HIT] = "DEFAULT_ROUTE",                                         \
    [FLEX_ACL_KEY_ERIF] = "ERIF",                                                               \
    [FLEX_ACL_KEY_SIPV6] = "SIPV6",                                                             \
    [FLEX_ACL_KEY_INNER_FPP_4_TOUCHED] = "INNER_FPP_4_TOUCHED",                                 \
    [FLEX_ACL_KEY_GP_REGISTER_10] = "GP_REGISTER_10",                                           \
    [FLEX_ACL_KEY_FPP_7_TOUCHED] = "FPP_7_TOUCHED",                                             \
    [FLEX_ACL_KEY_L4_TYPE] = "L4_TYPE",                                                         \
    [FLEX_ACL_KEY_DWORD_1_VALID] = "DWORD_1_VALID",                                             \
    [FLEX_ACL_KEY_SRC_PORT] = "SRC_PORT",                                                       \
    [FLEX_ACL_KEY_DWORD_2_VALID] = "DWORD_2_VALID",                                             \
    [FLEX_ACL_KEY_INNER_DEI] = "INNER_DEI",                                                     \
    [FLEX_ACL_KEY_MACSEC_VNI_ID] = "VNI_ID",                                                    \
    [FLEX_ACL_KEY_GP_REGISTER_8] = "GP_REGISTER_8",                                             \
    [FLEX_ACL_KEY_GP_REGISTER_8_VALID] = "GP_REGISTER_8_VALID",                                 \
    [FLEX_ACL_KEY_RX_LIST] = "RX_LIST",                                                         \
    [FLEX_ACL_KEY_INNER_IP_PACKET_LENGTH] = "INNER_IP_PACKET_LENGTH",                           \
    [FLEX_ACL_KEY_INNER_FPP_3_TOUCHED] = "INNER_FPP_3_TOUCHED",                                 \
    [FLEX_ACL_KEY_L3_TYPE] = "L3_TYPE",                                                         \
    [FLEX_ACL_KEY_DWORD_3_VALID] = "DWORD_3_VALID",                                             \
    [FLEX_ACL_KEY_FREE_RUNNING_CLOCK_MSB] = "FREE_RUNNING_CLOCK_MSB",                           \
    [FLEX_ACL_KEY_INNER_IP_PROTO] = "INNER_IP_PROTO",                                           \
    [FLEX_ACL_KEY_INNER_VLAN_TAG_VALID] = "INNER_VLAN_TAG_VALID",                               \
    [FLEX_ACL_KEY_SMAC] = "SMAC",                                                               \
    [FLEX_ACL_KEY_INNER_MPLS_TTL] = "INNER_MPLS_TTL",                                           \
    [FLEX_ACL_KEY_L4_TYPE_EXTENDED] = "L4_TYPE_EXTENDED",                                       \
    [FLEX_ACL_KEY_INNER_IS_TCP_OPTION] = "INNER_IS_TCP_OPTION",                                 \
    [FLEX_ACL_KEY_GP_REGISTER_3_VALID] = "GP_REGISTER_3_VALID",                                 \
    [FLEX_ACL_KEY_IP_DONT_FRAGMENT] = "IP_DONT_FRAGMENT",                                       \
    [FLEX_ACL_KEY_GP_REGISTER_11] = "GP_REGISTER_11",                                           \
    [FLEX_ACL_KEY_MACSEC_VLAN_ID] = "VLAN_ID",                                                  \
    [FLEX_ACL_KEY_INNER_SMAC] = "INNER_SMAC",                                                   \
    [FLEX_ACL_KEY_LLC_VALID] = "LLC_VALID",                                                     \
    [FLEX_ACL_KEY_BOS] = "BoS",                                                                 \
    [FLEX_ACL_KEY_CUSTOM_BYTE_23] = "CUSTOM_BYTES_23",                                          \
    [FLEX_ACL_KEY_GP_REGISTER_7_VALID] = "GP_REGISTER_7_VALID",                                 \
    [FLEX_ACL_KEY_GP_REGISTER_OFFSET_START] = "GP_REGISTER_0_OFFSET",                           \
    [FLEX_ACL_KEY_ALU_CARRY_FLAG] = "ALU_CARRY_FLAG",                                           \
    [FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID] = "TUNNEL_VLAN_TAG_VALID",                             \
    [FLEX_ACL_KEY_INNER_EXP] = "EXP",                                                           \
    [FLEX_ACL_KEY_INNER_IS_MPLS] = "INNER_IS_MPLS",                                             \
    [FLEX_ACL_KEY_INNER_VLAN_VALID] = "INNER_VLAN_VALID",                                       \
    [FLEX_ACL_KEY_IP_FRAGMENTED] = "IP_FRAGMENTED",                                             \
    [FLEX_ACL_KEY_INVALID] = "INVALID",                                                         \
    [FLEX_ACL_KEY_FPP_5_TOUCHED] = "FPP_5_TOUCHED",                                             \
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID] = "MPLS_CONTROL_WORD_VALID",                         \
    [FLEX_ACL_KEY_MC_TYPE] = "MC_TYPE",                                                         \
    [FLEX_ACL_KEY_IP_PROTO] = "IP_PROTO",                                                       \
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID] = "INNER_MPLS_CONTROL_WORD_VALID",             \
    [FLEX_ACL_KEY_INNER_BOS] = "INNER_BOS",                                                     \
    [FLEX_ACL_KEY_ECN] = "ECN",                                                                 \
    [FLEX_ACL_KEY_IP_MORE_FRAGMENTS] = "IP_MORE_FRAGMENTS",                                     \
    [FLEX_ACL_KEY_INNER_DMAC] = "INNER_DMAC",                                                   \
    [FLEX_ACL_KEY_ETHERTYPE] = "ETHERTYPE",                                                     \
    [FLEX_ACL_KEY_DWORD_5_VALID] = "DWORD_5_VALID",                                             \
    [FLEX_ACL_KEY_FPP_6_TOUCHED] = "FPP_6_TOUCHED",                                             \
    [FLEX_ACL_KEY_ROCE_PKEY] = "ROCE_PKEY",                                                     \
    [FLEX_ACL_KEY_IP_OPT] = "IP_OPT",                                                           \
    [FLEX_ACL_KEY_INNER_DMAC_VALID] = "INNER_DMAC_VALID",                                       \
    [FLEX_ACL_KEY_INNER_PCP] = "INNER_PCP",                                                     \
    [FLEX_ACL_KEY_TRAP_ID] = "TRAP_ID",                                                         \
    [FLEX_ACL_KEY_CUSTOM_BYTES_START] = "CUSTOM_BYTES_0",                                       \
    [FLEX_ACL_KEY_RX_PORT_LIST] = "RX_PORT_LIST",                                               \
    [FLEX_ACL_KEY_DMAC_IS_UC] = "DMAC_IS_UC",                                                   \
    [FLEX_ACL_KEY_INNER_SIPV6] = "INNER_SIPV6",                                                 \
    [FLEX_ACL_KEY_FPP_1_TOUCHED] = "FPP_1_TOUCHED",                                             \
    [FLEX_ACL_KEY_INNER_DIPV6] = "INNER_DIPV6",                                                 \
    [FLEX_ACL_KEY_INNER_FPP_TOUCHED_START] = "INNER_FPP_0_TOUCHED",                             \
    [FLEX_ACL_KEY_DIP] = "DIP",                                                                 \
    [FLEX_ACL_KEY_RW_DSCP] = "RW_DSCP",                                                         \
    [FLEX_ACL_KEY_CUSTOM_BYTE_3] = "CUSTOM_BYTES_3",                                            \
    [FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID] = "ND_SLL_OR_TLL_VALID",                                 \
    [FLEX_ACL_KEY_VLAN_TAGGED] = "VLAN_TAGGED",                                                 \
    [FLEX_ACL_KEY_INNER_SIP] = "INNER_SIP",                                                     \
    [FLEX_ACL_KEY_CUSTOM_BYTE_5] = "CUSTOM_BYTES_5",                                            \
    [FLEX_ACL_KEY_GRE_PROTOCOL] = "GRE_PROTOCOL",                                               \
    [FLEX_ACL_KEY_MPLS_ECN] = "MPLS_ECN",                                                       \
    [FLEX_ACL_KEY_MACSEC_ETHERTYPE] = "ETHERTYPE",                                              \
    [FLEX_ACL_KEY_DWORD_0_VALID] = "DWORD_0_VALID",                                             \
    [FLEX_ACL_KEY_MACSEC_SCI] = "MACSEC_SCI",                                                   \
    [FLEX_ACL_KEY_IS_TCP_OPTION] = "IS_TCP_OPTION",                                             \
    [FLEX_ACL_KEY_GRE_KEY_EXISTS] = "GRE_KEY_EXISTS",                                           \
    [FLEX_ACL_KEY_LAST] = "LAST",                                                               \
    [FLEX_ACL_KEY_GP_REGISTER_9_VALID] = "GP_REGISTER_9_VALID",                                 \
    [FLEX_ACL_KEY_IP_PACKET_LENGTH] = "IP_PACKET_LENGTH",                                       \
    [FLEX_ACL_KEY_CUSTOM_BYTE_9] = "CUSTOM_BYTES_9",                                            \
    [FLEX_ACL_KEY_GP_REGISTER_1_OFFSET] = "GP_REGISTER_1_OFFSET",                               \
    [FLEX_ACL_KEY_RX_TUNNEL_LIST] = "RX_TUNNEL_LIST",                                           \
    [FLEX_ACL_KEY_DIPV6] = "DIPV6",                                                             \
    [FLEX_ACL_KEY_MPLS_CONTROL_WORD] = "MPLS_CONTROL_WORD",                                     \
    [FLEX_ACL_KEY_INNER_IP_MORE_FRAGMENTS] = "INNER_IP_MORE_FRAGMENTS",                         \
    [FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT] = "INNER_IP_DONT_FRAGMENT",                           \
    [FLEX_ACL_KEY_GP_REGISTER_2_VALID] = "GP_REGISTER_2_VALID",                                 \
    [FLEX_ACL_KEY_PACKET_IS_ELEPHANT] = "PACKET_IS_ELEPHANT",                                   \
    [FLEX_ACL_KEY_INNER_IP_FRAGMENTED] = "INNER_IP_FRAGMENTED",                                 \
    [FLEX_ACL_KEY_MACSEC_SCI_VALID] = "MACSEC_SCI_VALID",                                       \
    [FLEX_ACL_KEY_GP_REGISTER_11_VALID] = "GP_REGISTER_11_VALID",                               \
    [FLEX_ACL_KEY_INNER_FPP_5_TOUCHED] = "INNER_FPP_5_TOUCHED",                                 \
    [FLEX_ACL_KEY_FPP_2_TOUCHED] = "FPP_2_TOUCHED",                                             \
    [FLEX_ACL_KEY_ROCE_DEST_QP] = "ROCE_DEST_QP",                                               \
    [FLEX_ACL_KEY_FPP_TOUCHED_START] = "FPP_0_TOUCHED",                                         \
    [FLEX_ACL_KEY_TUNNEL_VLAN_ID] = "TUNNEL_VLAN_ID",                                           \
    [FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT] = "INNER_L4_DEST_PORT",                            \
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS] = "INNER_IPV6_HBH_EXTENSION_HEADERS",           \
    [FLEX_ACL_KEY_INNER_TTL] = "INNER_TTL",                                                     \
    [FLEX_ACL_KEY_FDB_MISS] = "FDB_MISS",                                                       \
    [FLEX_ACL_KEY_INNER_IP_OK] = "INNER_IP_OK",                                                 \
    [FLEX_ACL_KEY_CUSTOM_BYTE_14] = "CUSTOM_BYTES_14",                                          \
    [FLEX_ACL_KEY_INNER_FPP_6_TOUCHED] = "INNER_FPP_6_TOUCHED",                                 \
    [FLEX_ACL_KEY_CUSTOM_BYTE_13] = "CUSTOM_BYTES_13",                                          \
    [FLEX_ACL_KEY_MPLS_LABEL_ID_1] = "MPLS_LABEL_ID_1",                                         \
    [FLEX_ACL_KEY_CUSTOM_BYTE_15] = "CUSTOM_BYTES_15",                                          \
    [FLEX_ACL_KEY_VLAN_VALID] = "VLAN_VALID",                                                   \
    [FLEX_ACL_KEY_CUSTOM_BYTE_18] = "CUSTOM_BYTES_18",                                          \
    [FLEX_ACL_KEY_CUSTOM_BYTE_19] = "CUSTOM_BYTES_19",                                          \
    [FLEX_ACL_KEY_INNER_ECN] = "INNER_ECN",                                                     \
    [FLEX_ACL_KEY_SRC_PHY_PORT] = "SRC_PHY_PORT",                                               \
    [FLEX_ACL_KEY_CUSTOM_BYTE_12] = "CUSTOM_BYTES_12",                                          \
    [FLEX_ACL_KEY_INNER_TCP_CONTROL] = "INNER_TCP_CONTROL",                                     \
    [FLEX_ACL_KEY_CUSTOM_BYTE_10] = "CUSTOM_BYTES_10",                                          \
    [FLEX_ACL_KEY_CUSTOM_BYTE_11] = "CUSTOM_BYTES_11",                                          \
    [FLEX_ACL_KEY_CUSTOM_BYTE_16] = "CUSTOM_BYTES_16",                                          \
    [FLEX_ACL_KEY_CUSTOM_BYTE_17] = "CUSTOM_BYTES_17",                                          \
    [FLEX_ACL_KEY_GP_REGISTER_4] = "GP_REGISTER_4",                                             \
    [FLEX_ACL_KEY_INNER_FPP_1_TOUCHED] = "INNER_FPP_1_TOUCHED",                                 \
    [FLEX_ACL_KEY_AR_PACKET_CLASS] = "AR_PACKET_CLASS",                                         \
    [FLEX_ACL_KEY_BUFF] = "BUFF",                                                               \
    [FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID_VALID] = "MACSEC_FLOW_SECY_ID_VALID",                     \
    [FLEX_ACL_KEY_DST_PORT] = "DST_PORT",                                                       \
    [FLEX_ACL_KEY_VLAN_ID] = "VLAN_ID",                                                         \
    [FLEX_ACL_KEY_IRIF] = "IRIF",                                                               \
    [FLEX_ACL_KEY_L4_PORT_RANGE] = "L4_PORT_RANGE",                                             \
    [FLEX_ACL_KEY_INNER_IP_OPT] = "INNER_IP_OPT",                                               \
    [FLEX_ACL_KEY_GP_REGISTER_1_VALID] = "GP_REGISTER_1_VALID",                                 \
    [FLEX_ACL_KEY_TCP_ECN] = "TCP_ECN",                                                         \
    [FLEX_ACL_KEY_MACSEC_DMAC] = "DMAC",                                                        \
    [FLEX_ACL_KEY_IS_MPLS] = "IS_MPLS",                                                         \
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID] = "TUNNEL_INNER_VLAN_TAG_VALID",                 \
    [FLEX_ACL_KEY_GP_REGISTER_5] = "GP_REGISTER_5",                                             \
    [FLEX_ACL_KEY_SIP] = "SIP",                                                                 \
    [FLEX_ACL_KEY_GP_REGISTER_7] = "GP_REGISTER_7",                                             \
    [FLEX_ACL_KEY_INNER_L4_SOURCE_PORT] = "INNER_L4_SRC_PORT",                                  \
    [FLEX_ACL_KEY_GP_REGISTER_1] = "GP_REGISTER_1",                                             \
    [FLEX_ACL_KEY_RW_EXP] = "RW_EXP",                                                           \
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS] = "IPV6_EXT_HDRS",                                    \
    [FLEX_ACL_KEY_GP_REGISTER_2] = "GP_REGISTER_2",                                             \
    [FLEX_ACL_KEY_GP_REGISTER_9] = "GP_REGISTER_9",                                             \
    [FLEX_ACL_KEY_INNER_L4_OK] = "INNER_L4_OK",                                                 \
    [FLEX_ACL_KEY_INNER_ETHERTYPE] = "INNER_ETHERTYPE",                                         \
    [FLEX_ACL_KEY_TUNNEL_INNER_VLAN_ID] = "TUNNEL_INNER_VLAN_ID",                               \
    [FLEX_ACL_KEY_MPLS_LABELS_VALID] = "MPLS_LABELS_VALID",                                     \
    [FLEX_ACL_KEY_LAG_HASH] = "LAG_HASH",                                                       \
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0] = "ETHERNET_PAYLOAD_DWORD_0",                       \
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_1] = "ETHERNET_PAYLOAD_DWORD_1",                       \
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_2] = "ETHERNET_PAYLOAD_DWORD_2",                       \
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_3] = "ETHERNET_PAYLOAD_DWORD_3",                       \
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_4] = "ETHERNET_PAYLOAD_DWORD_4",                       \
    [FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_5] = "ETHERNET_PAYLOAD_DWORD_5",                       \
    [FLEX_ACL_KEY_IS_ARP] = "IS_ARP",                                                           \
    [FLEX_ACL_KEY_IP_COMPARE] = "IP_COMPARE",                                                   \
    [FLEX_ACL_KEY_CUSTOM_BYTE_1] = "CUSTOM_BYTES_1",                                            \
    [FLEX_ACL_KEY_CUSTOM_BYTE_2] = "CUSTOM_BYTES_2",                                            \
    [FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST] = "INNER_IP_FRAGMENT_NOT_FIRST",                 \
    [FLEX_ACL_KEY_CUSTOM_BYTE_4] = "CUSTOM_BYTES_4",                                            \
    [FLEX_ACL_KEY_RW_PCP] = "RW_PCP",                                                           \
    [FLEX_ACL_KEY_CUSTOM_BYTE_6] = "CUSTOM_BYTES_6",                                            \
    [FLEX_ACL_KEY_CUSTOM_BYTE_7] = "CUSTOM_BYTES_7",                                            \
    [FLEX_ACL_KEY_CUSTOM_BYTE_8] = "CUSTOM_BYTES_8",                                            \
    [FLEX_ACL_KEY_ECMP_HASH] = "ECMP_HASH",                                                     \
    [FLEX_ACL_KEY_IP_OK] = "IP_OK",                                                             \
    [FLEX_ACL_KEY_VNI_KEY] = "VNI",                                                             \
    [FLEX_ACL_KEY_URPF_FAIL] = "URPF_FAIL",                                                     \
    [FLEX_ACL_KEY_MPLS_LABEL_ID_5] = "MPLS_LABEL_ID_5",                                         \
    [FLEX_ACL_KEY_MPLS_LABEL_ID_4] = "MPLS_LABEL_ID_4",                                         \
    [FLEX_ACL_KEY_MPLS_LABEL_ID_6] = "MPLS_LABEL_ID_6",                                         \
    [FLEX_ACL_KEY_FID] = "FID",                                                                 \
    [FLEX_ACL_KEY_MPLS_LABEL_ID_3] = "MPLS_LABEL_ID_3",                                         \
    [FLEX_ACL_KEY_MPLS_LABEL_ID_2] = "MPLS_LABEL_ID_2",                                         \
    [FLEX_ACL_KEY_GP_REGISTER_START] = "GP_REGISTER_0",                                         \
    [FLEX_ACL_KEY_INNER_VLAN_ID] = "INNER_VLAN_ID",                                             \
    [FLEX_ACL_KEY_VLAN_TAG_VALID] = "VLAN_TAG_VALID",                                           \
    [FLEX_ACL_KEY_IS_IP_V4] = "IS_IP_V4",                                                       \
    [FLEX_ACL_KEY_IS_TRAPPED] = "IS_TRAPPED",                                                   \
    [FLEX_ACL_KEY_GP_REGISTER_4_VALID] = "GP_REGISTER_4_VALID",                                 \
    [FLEX_ACL_KEY_TTL] = "TTL",                                                                 \
    [FLEX_ACL_KEY_INNER_FPP_2_TOUCHED] = "INNER_FPP_2_TOUCHED",                                 \
    [FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD] = "INNER_MPLS_CONTROL_WORD",                         \
    [FLEX_ACL_KEY_IS_BUM] = "SMPE_VALID",                                                       \
    [FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS] = "IPV6_EXT_HDR_EXISTS",                        \
    [FLEX_ACL_KEY_L4_OK] = "L4_OK",                                                             \
    [FLEX_ACL_KEY_DMAC] = "DMAC",                                                               \
    [FLEX_ACL_KEY_PCP] = "PCP",                                                                 \
    [FLEX_ACL_KEY_IS_ROUTED] = "IS_ROUTED",                                                     \
    [FLEX_ACL_KEY_PORT_USER_MEMORY] = "PORT_USER_MEMORY",                                       \
    [FLEX_ACL_KEY_DSCP] = "DSCP",                                                               \
    [FLEX_ACL_KEY_TCP_CONTROL] = "TCP_CONTROL",                                                 \
    [FLEX_ACL_KEY_FPP_3_TOUCHED] = "FPP_3_TOUCHED",                                             \
    [FLEX_ACL_KEY_MACSEC_AN] = "MACSEC_AN",                                                     \
    [FLEX_ACL_KEY_DWORD_4_VALID] = "DWORD_4_VALID",                                             \
    [FLEX_ACL_KEY_VIRTUAL_ROUTER] = "VIRTUAL_ROUTER",                                           \
    [FLEX_ACL_KEY_FPP_4_TOUCHED] = "FPP_4_TOUCHED",                                             \
    [FLEX_ACL_KEY_L4_PORT_COMPARE] = "L4_PORT_COMPARE",                                         \
    [FLEX_ACL_KEY_EXP] = "EXP",                                                                 \
    [FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED] = "INNER_L4_TYPE_EXTENDED",                           \
    [FLEX_ACL_KEY_DEI] = "DEI",                                                                 \
    [FLEX_ACL_KEY_INNER_TCP_ECN] = "INNER_TCP_ECN",                                             \
    [FLEX_ACL_KEY_ROCE_BTH_OPCODE] = "ROCE_BTH_OPCODE",                                         \
    [FLEX_ACL_KEY_TUNNEL_NVE_TYPE] = "NVE_TUNNEL_VECTOR",                                       \
    [FLEX_ACL_KEY_INNER_FPP_7_TOUCHED] = "INNER_FPP_7_TOUCHED",                                 \
    [FLEX_ACL_KEY_INNER_MPLS_ECN] = "INNER_MPLS_ECN",                                           \
    [FLEX_ACL_KEY_MACSEC_FLOW_SECY_ID] = "MACSEC_FLOW_SECY_ID",                                 \
    [FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST] = "IP_FRAGMENT_NOT_FIRST",                             \
    [FLEX_ACL_KEY_INNER_DIP] = "INNER_DIP",                                                     \
    [FLEX_ACL_KEY_GP_REGISTER_3] = "GP_REGISTER_3",                                             \
    [FLEX_ACL_KEY_USER_TOKEN] = "USER_TOKEN",                                                   \
    [FLEX_ACL_KEY_MAC_COMPARE] = "MAC_COMPARE",                                                 \
    [FLEX_ACL_KEY_L2_DMAC_TYPE] = "L2_DMAC_TYPE",                                               \
    [FLEX_ACL_KEY_L4_SOURCE_PORT] = "L4_SRC_PORT",                                              \
    [FLEX_ACL_KEY_INNER_TTL_OK] = "INNER_TTL_OK",                                               \
    [FLEX_ACL_KEY_GP_REGISTER_VALID_START] = "GP_REGISTER_0_VALID",                             \
    [FLEX_ACL_KEY_GP_REGISTER_6_VALID] = "GP_REGISTER_6_VALID",                                 \
    [FLEX_ACL_KEY_GRE_KEY] = "GRE_KEY",                                                         \
    [FLEX_ACL_KEY_INNER_MPLS_LABELS_VALID] = "INNER_MPLS_LABELS_VALID",                         \
    [FLEX_ACL_KEY_TTL_OK] = "TTL_OK",                                                           \
    [FLEX_ACL_KEY_L4_DESTINATION_PORT] = "L4_DEST_PORT",                                        \
    [FLEX_ACL_KEY_BUM_BRIDGE_ID] = "SMPE",                                                      \
    [FLEX_ACL_KEY_GP_REGISTER_10_VALID] = "GP_REGISTER_10_VALID",                               \
    [FLEX_ACL_KEY_INNER_IS_IP_V4] = "INNER_IS_IP_V4",                                           \
    [FLEX_ACL_KEY_INNER_L3_TYPE] = "INNER_L3_TYPE",                                             \
    [FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS] = "INNER_IPV6_EXTENSION_HEADERS_EXISTS", \
    [FLEX_ACL_KEY_L2_VALID] = "L2_VALID",                                                       \
    [FLEX_ACL_KEY_COLOR] = "COLOR",                                                             \
    [FLEX_ACL_KEY_MPLS_TTL] = "MPLS_TTL",
};


#define SX_ACL_KEY_STR_LEN \
    (sizeof(sx_acl_key_str_s) / sizeof(sx_acl_key_str_s[0]))

const char * sx_acl_key_str(sx_acl_key_t idx)
{
    if (SX_CHECK_MAX(idx, SX_ACL_KEY_STR_LEN - 1) && sx_acl_key_str_s[idx]) {
        return sx_acl_key_str_s[idx];
    }
    printf("Unknown [%u]: idx", idx);
    return "Unknown";
}


static int __key_cmp(const void *p1, const void *p2)
{
    uint32_t ui1, ui2;

    ui1 = *(uint32_t*)p1;
    ui2 = *(uint32_t*)p2;

    if (ui1 == ui2) {
        return 0;
    } else if (ui1 < ui2) {
        return -1;
    } else {
        return 1;
    }
}

extern flex_acl_key_map_data_t flex3_acl_key_map[FLEX_ACL_KEY_LAST];


static void generate_rand_acl_keys(sx_acl_key_t acl_keys[], uint32_t* key_count_p, uint32_t round)
{
    srand(round ^ time(NULL));
    uint32_t     key_count = 1 + (rand() % 15);
    uint32_t     i = 0;
    sx_acl_key_t acl_keys_gen[40] = {FLEX_ACL_KEY_INVALID};
    int          idx;

    printf("Trying %u keys\n", key_count);

    do {
        /* coverity[dont_call] */
        idx = 1 + rand() % (FLEX_ACL_KEY_LAST - 1);
        if (flex3_acl_key_map[idx].hw_keys_cnt != 0) {
            acl_keys_gen[i] = idx;
            i++;
        }
    }while(i < key_count);


    qsort(acl_keys_gen, key_count, sizeof(sx_acl_key_t), __key_cmp);

    uint32_t j = 0, k = 0;

    for (k = 0; k < key_count - 1; k++) {
        if (acl_keys_gen[k] != acl_keys_gen[k + 1]) {
            acl_keys[j++] = acl_keys_gen[k];
        }
    }

    /* Store the last element as whether it is unique or */
    /* repeated, it hasn't stored previously */
    acl_keys[j++] = acl_keys_gen[key_count - 1];

    *key_count_p = j;
}

#if 0
static void generate_acl_keys(sx_acl_key_t acl_keys[], uint32_t* key_count_p)
{
    uint32_t     key_count = 0;
    uint32_t     i = 0;
    sx_acl_key_t acl_keys_gen[] =
    {FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS, FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID, FLEX_ACL_KEY_ALU_CARRY_FLAG,
     FLEX_ACL_KEY_GP_REGISTER_3, FLEX_ACL_KEY_GP_REGISTER_2_VALID, FLEX_ACL_KEY_GP_REGISTER_OFFSET_START,
     FLEX_ACL_KEY_FPP_6_TOUCHED, FLEX_ACL_KEY_CUSTOM_BYTE_6, FLEX_ACL_KEY_CUSTOM_BYTE_11};

    key_count = sizeof(acl_keys_gen) / sizeof(sx_acl_key_t);
    for (i = 0; i < key_count; i++) {
        acl_keys[i] = acl_keys_gen[i];
    }

    *key_count_p = key_count;
}
#endif

int main(int argc, char *argv[])
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_acl_key_t       acl_keys[48] = {FLEX_ACL_KEY_INVALID};
    uint32_t           keys_count = 0;
    uint32_t           hw_key_cnt = 256;
    sx_acl_hw_key_e    hw_keys[256];
    uint32_t           greedy_key_blocks_count = 12;
    sx_acl_key_block_e greedy_key_blocks[256];
    uint32_t           static_key_blocks_count = 12;
    sx_acl_key_block_e static_key_blocks[256];
    uint32_t           key_blocks_count = 12;
    sx_acl_key_block_e key_blocks[256];
    uint64_t           add_time = 0;
    struct timespec    tms_start;
    struct timespec    tms_end;

    memset(&tms_start, 0, sizeof(tms_start));
    memset(&tms_end, 0, sizeof(tms_end));

    sx_status_t greedy_status = SX_STATUS_SUCCESS;
    sx_status_t optimal_status = SX_STATUS_SUCCESS;
    sx_status_t static_optimal_status = SX_STATUS_SUCCESS;
    int         num_rounds = 0;
    int         num_mismatch = 0;
    uint32_t    max_mismatch = 0;


    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);


    /* Initialize the SCP to work with the keys of this acl stage */
    sx_status = flex_acl_scp_init(ACL_STAGE_FLEX3);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("Failed to init SCP; acl_stage %u\n", ACL_STAGE_FLEX3);
        exit(1);
    }


    for (num_rounds = 0; num_rounds < NUM_ROUNDS; num_rounds++) {
        printf("\n*********ROUND %u of %u***********\n", num_rounds, NUM_ROUNDS);
        memset(&tms_start, 0, sizeof(tms_start));
        memset(&tms_end, 0, sizeof(tms_end));

        generate_rand_acl_keys(acl_keys, &keys_count, num_rounds);

        printf("\nGenerated [%u] random ACL keys]\t", keys_count);
        for (uint32_t l = 0; l < keys_count; l++) {
            printf("%s \t", sx_acl_key_str(acl_keys[l]));
        }


        /* Generate the HW keys corresponding with the SW keys */
        sx_status = flex_acl_get_hw_keys(ACL_STAGE_FLEX3, acl_keys, keys_count, hw_keys, &hw_key_cnt);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("Failed to get HW keys; acl_stage %u\n", ACL_STAGE_FLEX3);
            exit(1);
        }

        printf("\nGenerated %u HW keys; acl_stage %u\n", hw_key_cnt, ACL_STAGE_FLEX3);


        /* First test optimal solution*/
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        optimal_status = flex_acl_scp_calc(ACL_STAGE_FLEX3,
                                           hw_keys,
                                           hw_key_cnt,
                                           key_blocks,
                                           &key_blocks_count,
                                           FALSE,
                                           FALSE);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);
        add_time = (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                   (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);

        printf("Optimal: Generated %u key blocks; total time %" PRIu64 " us \n", key_blocks_count, add_time);

        memset(&tms_start, 0, sizeof(tms_start));
        memset(&tms_end, 0, sizeof(tms_end));


        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        static_optimal_status = flex_acl_scp_calc(ACL_STAGE_FLEX3,
                                                  hw_keys,
                                                  hw_key_cnt,
                                                  static_key_blocks,
                                                  &static_key_blocks_count,
                                                  FALSE,
                                                  TRUE);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);
        add_time = (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                   (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);

        printf("Optimal with Static: Generated %u key blocks; total time %" PRIu64 " us \n",
               static_key_blocks_count,
               add_time);

        assert(optimal_status == static_optimal_status);
        if (optimal_status == SX_STATUS_SUCCESS) {
            if (key_blocks_count != static_key_blocks_count) {
                printf("\nOptimal KB\n");
                for (uint32_t i = 0; i < key_blocks_count; i++) {
                    printf("[%u]\t", key_blocks[i]);
                }
                printf("\nStatic KB\n");
                for (uint32_t i = 0; i < static_key_blocks_count; i++) {
                    printf("[%u]\t", static_key_blocks[i]);
                }

                assert(key_blocks_count == static_key_blocks_count);
            }

            qsort(key_blocks, key_blocks_count, sizeof(sx_acl_key_block_e), __key_cmp);
            qsort(static_key_blocks, static_key_blocks_count, sizeof(sx_acl_key_block_e), __key_cmp);

            for (uint32_t i = 0; i < key_blocks_count; i++) {
                assert(key_blocks[i] == static_key_blocks[i]);
            }
        }

        /* Test greedy approx */
        memset(&tms_start, 0, sizeof(tms_start));
        memset(&tms_end, 0, sizeof(tms_end));

        /* Generate the key blocks that can contain all the above keys */
        (void)clock_gettime(CLOCK_REALTIME, &tms_start);
        greedy_status = flex_acl_scp_calc_greedy(ACL_STAGE_FLEX3,
                                                 hw_keys,
                                                 hw_key_cnt,
                                                 greedy_key_blocks,
                                                 &greedy_key_blocks_count,
                                                 FALSE);
        (void)clock_gettime(CLOCK_REALTIME, &tms_end);


        add_time = (tms_end.tv_sec * 1000000 + tms_end.tv_nsec / 1000) -
                   (tms_start.tv_sec * 1000000 + tms_start.tv_nsec / 1000);

        printf("\nGreedy: Generated %u key blocks; total time %" PRIu64 " us \n", greedy_key_blocks_count, add_time);

        if (static_key_blocks_count != 12) {
            assert(greedy_status == static_optimal_status);
        }
        if (static_optimal_status == SX_STATUS_SUCCESS) {
            assert(greedy_key_blocks_count >= static_key_blocks_count);
        }

        if ((static_optimal_status == SX_STATUS_SUCCESS) && (greedy_key_blocks_count != static_key_blocks_count)) {
            num_mismatch++;
            if ((greedy_key_blocks_count - static_key_blocks_count) > max_mismatch) {
                max_mismatch = (greedy_key_blocks_count - static_key_blocks_count);
            }
        }

        static_optimal_status = SX_STATUS_SUCCESS;
        optimal_status = SX_STATUS_SUCCESS;
        greedy_status = SX_STATUS_SUCCESS;
        printf("********************\n");
    }

    printf("Successfully finished, Total Mismatch [%d] Max Mismatch [%d]\n", num_mismatch, max_mismatch);

    return 0;
}
