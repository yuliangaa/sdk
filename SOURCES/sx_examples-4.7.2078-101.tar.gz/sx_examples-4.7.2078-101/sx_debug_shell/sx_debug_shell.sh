#
# Copyright (c) 2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
#
# This software product is a proprietary product of Nvidia Corporation and its affiliates
# (the "Company") and all right, title, and interest in and to the software
# product, including all associated intellectual property rights, are and
# shall remain exclusively with the Company.
#
# This software product is governed by the End User License Agreement
# provided with the software product.
#

#/bin/bash

function set_bold()          { printf "\e[1m";      }
function set_italic()        { printf "\e[2m";      }
function reset_style()       { printf "\e[0m";      }
function set_blue()          { printf "\033[1;34m"; }
function set_red()           { printf "\033[1;31m"; }
function reset_color()       { printf "\033[0m";    }

function restore_old_config()
{
    echo ${rollback_rx_dump} > /sys/module/sx_core/parameters/rx_dump
    echo ${rollback_rx_debug_emad_type} > /sys/module/sx_core/parameters/rx_debug_emad_type
    echo ${rollback_rx_debug} > /sys/module/sx_core/parameters/rx_debug
    echo ${rollback_rx_debug_metadata} > /sys/module/sx_core/parameters/rx_debug_metadata
    echo ${rollback_rx_cqev2_dbg} > /sys/module/sx_core/parameters/rx_cqev2_dbg
    echo ${rollback_tx_dump} > /sys/module/sx_core/parameters/tx_dump
    echo ${rollback_tx_debug_emad_type} > /sys/module/sx_core/parameters/tx_debug_emad_type
    echo ${rollback_tx_debug} > /sys/module/sx_core/parameters/tx_debug
    echo ${rollback_tx_debug_metadata} > /sys/module/sx_core/parameters/tx_debug_metadata
    echo ${rollback_rx_netdev_debug} > /sys/module/sx_netdev/parameters/sx_netdev_rx_debug
    echo ${rollback_tx_netdev_debug} > /sys/module/sx_netdev/parameters/sx_netdev_tx_debug

    if [[ "${rollback_dynamic_debug}" != "" ]]; then
        echo "${rollback_dynamic_debug}" > /sys/kernel/debug/dynamic_debug/control
    fi

    # rollback printk configuration
    echo "$rollback_printk" > /proc/sys/kernel/printk
}

function ctrl_c_handler()
{
    echo

    set_red
    echo "handling a request to terminate"
    reset_color

    restore_old_config
}

function usage()
{
    set_bold
    echo "USAGE: sx_debug_shell.sh <option> [params]"
    reset_style
    echo
    set_blue
    echo "    printk_open <module_name [,module_name] [,module_name] ...> [duration]"
    reset_color
    echo "        Description: open dynamic debug for several modules"
    echo "        Params:"
    echo "            module_name: SDK kernel module name (sx_core, sx_netdev, etc.)"
    echo "            duration:    Duration in seconds to open dynamic debug for the kernel modules (default: infinite)"
    echo "        Example:"
    set_italic
    echo "            # printk_open sx_core,sx_netdev 10"
    reset_style
    echo "    -------------------------------------------------------------------------------------"
    set_blue
    echo "    packet_debug <option [,option] [,option] ...> [duration]"
    reset_color
    echo "        Description: open packet debug in dmesg"
    echo "        Params:"
    echo "            option:   rx_meta"
    echo "                      rx_cqe"
    echo "                      rx_dump"
    echo "                      rx_trap=<trap_id>"
    echo "                      rx_reg=<reg_id>"
    echo "                      rx_netdev"
    echo "                      rx_all"
    echo "                      tx_meta"
    echo "                      tx_dump"
    echo "                      tx_reg=<reg_id>"
    echo "                      tx_netdev"
    echo "                      tx_all"
    echo "                      all"
    echo "            duration: Duration in seconds to open packet debug (default: infinite)"
    echo "        Example:"
    set_italic
    echo "            # packet_debug rx_meta,rx_dump,rx_reg=0x5008,tx_meta 5"
    reset_style
    echo "    -------------------------------------------------------------------------------------"

    exit 0
}

printk_open()
{
    module_names=$1

    if [[ "${module_names}" == "" ]]; then
        usage
    fi
 
    echo 9 > /proc/sys/kernel/printk

    IFS=',' # an environment variable that is used in for-loop implicitly
    for module in ${module_names}; do
        rollback_dynamic_debug+="module ${module} -p; "
        echo "module ${module} +p" > /sys/kernel/debug/dynamic_debug/control
    done
    IFS= # reset IFS

    duration=$2
    if [[ "${duration}" == "" ]]; then
        duration=${infinite_duration}
    fi

    echo "Press Ctrl-C to stop ..."
    sleep ${duration}
}

packet_debug()
{
    sx_core_rx=0
    sx_core_tx=0
    sx_core=0
    sx_netdev=0
    modules=""

    options=$1
    if [[ "${options}" == "" ]]; then
        usage
    fi

    if [[ "${options}" == "all" ]]; then
        options="rx_meta,rx_cqe,rx_dump,rx_trap=0xffff,rx_reg=0xffff,rx_netdev,tx_meta,tx_dump,tx_reg=0xffff,tx_netdev"
    elif [[ "${options}" == "rx_all" ]]; then
        options="rx_meta,rx_cqe,rx_dump,rx_trap=0xffff,rx_reg=0xffff,rx_netdev"
    elif [[ "${options}" == "tx_all" ]]; then
        options="tx_meta,tx_dump,tx_reg=0xffff,tx_netdev"
    fi

    IFS=',' # an environment variable that is used in for-loop implicitly
    for option in ${options}; do
        case ${option} in
        rx_meta)
            echo 1 > /sys/module/sx_core/parameters/rx_debug_metadata
            sx_core_rx=1
            ;;
        rx_cqe)
            echo 1 > /sys/module/sx_core/parameters/rx_cqev2_dbg
            sx_core_rx=1
            ;;
        rx_dump)
            echo 1 > /sys/module/sx_core/parameters/rx_dump
            sx_core_rx=1
            ;;
        rx_netdev)
            echo 1 > /sys/module/sx_netdev/parameters/sx_netdev_rx_debug
            sx_netdev=1
            ;;
        tx_meta)
            echo 1 > /sys/module/sx_core/parameters/tx_debug_metadata
            sx_core_tx=1
            ;;
        tx_dump)
            echo 1 > /sys/module/sx_core/parameters/tx_dump
            sx_core_tx=1
            ;;
        tx_netdev)
            echo 1 > /sys/module/sx_netdev/parameters/sx_netdev_tx_debug
            sx_netdev=1
            ;;
        *)
            if [[ "${option:0:8}" == "rx_trap=" ]]; then
                trap_id=$(echo ${option} | cut -f2 -d=)
                echo "${trap_id}" > /sys/module/sx_core/parameters/rx_debug_pkt_type
                sx_core_rx=1
            elif [[ "${option:0:7}" == "rx_reg=" ]]; then
                reg_id=$(echo ${option} | cut -f2 -d=)
                echo "${reg_id}" > /sys/module/sx_core/parameters/rx_debug_emad_type
                sx_core_rx=1
            elif [[ "${option:0:7}" == "tx_reg=" ]]; then
                reg_id=$(echo ${option} | cut -f2 -d=)
                echo "${reg_id}" > /sys/module/sx_core/parameters/tx_debug_emad_type
                sx_core_tx=1
            else
                usage
            fi
            ;;
        esac
    done
    IFS= # reset IFS

    duration=$2
    if [[ "${duration}" == "" ]]; then
        duration=${infinite_duration}
    fi

    if [[ ${sx_core_rx} == 1 ]]; then
        echo 1 > /sys/module/sx_core/parameters/rx_debug
        sx_core=1
    fi

    if [[ ${sx_core_tx} == 1 ]]; then
        echo 1 > /sys/module/sx_core/parameters/tx_debug
        sx_core=1
    fi

    if [[ ${sx_core} == 1 ]]; then
        modules="sx_core"
        if [[ ${sx_netdev} == 1 ]]; then
            modules+=",sx_netdev"
        fi
    elif [[ ${sx_netdev} == 1 ]]; then
        modules="sx_netdev"
    fi

    printk_open "${modules}" ${duration}
}

#############################################
# Script starts here

trap ctrl_c_handler INT
trap ctrl_c_handler TERM

if [ $# -eq 0 ]; then
    usage
fi

if [ ${EUID} -ne 0 ] ; then
    echo "Must be root user to run this script!"
    exit 0
fi

lsmod | grep sx_core > /dev/null
if [ $? -ne 0 ]; then
    echo "sx_core driver is not loaded"
    exit 0
fi

lsmod | grep sx_netdev > /dev/null
if [ $? -ne 0 ]; then
    echo "sx_netdev driver is not loaded"
    exit 0
fi

infinite_duration=1000000
rollback_printk="$(cat /proc/sys/kernel/printk)"
rollback_dynamic_debug=""
rollback_rx_dump="$(cat /sys/module/sx_core/parameters/rx_dump)"
rollback_rx_debug_emad_type="$(cat /sys/module/sx_core/parameters/rx_debug_emad_type)"
rollback_rx_debug="$(cat /sys/module/sx_core/parameters/rx_debug)"
rollback_rx_debug_metadata="$(cat /sys/module/sx_core/parameters/rx_debug_metadata)"
rollback_rx_cqev2_dbg="$(cat /sys/module/sx_core/parameters/rx_cqev2_dbg)"
rollback_tx_dump="$(cat /sys/module/sx_core/parameters/tx_dump)"
rollback_tx_debug_emad_type="$(cat /sys/module/sx_core/parameters/tx_debug_emad_type)"
rollback_tx_debug="$(cat /sys/module/sx_core/parameters/tx_debug)"
rollback_tx_debug_metadata="$(cat /sys/module/sx_core/parameters/tx_debug_metadata)"
rollback_rx_netdev_debug="$(cat /sys/module/sx_netdev/parameters/sx_netdev_rx_debug)"
rollback_tx_netdev_debug="$(cat /sys/module/sx_netdev/parameters/sx_netdev_tx_debug)"

case $1 in
printk_open)
    printk_open $2 $3
    ;;
packet_debug)
    packet_debug $2 $3
    ;;
--help)
    usage
    ;;
*)
    usage
    ;;
esac

restore_old_config
exit 0
