/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sdk/sx_api_flex_parser.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_dbg.h>
#include <complib/sx_log.h>

sx_acl_key_t            key_id_set_example[] = {
    FLEX_ACL_KEY_FPP_0_TOUCHED,
    FLEX_ACL_KEY_FPP_1_TOUCHED,
    FLEX_ACL_KEY_FPP_2_TOUCHED,
    FLEX_ACL_KEY_FPP_3_TOUCHED,
    FLEX_ACL_KEY_FPP_4_TOUCHED,
    FLEX_ACL_KEY_FPP_5_TOUCHED,
    FLEX_ACL_KEY_FPP_6_TOUCHED,
    FLEX_ACL_KEY_FPP_7_TOUCHED,
    FLEX_ACL_KEY_INNER_FPP_0_TOUCHED,
    FLEX_ACL_KEY_INNER_FPP_1_TOUCHED,
    FLEX_ACL_KEY_INNER_FPP_2_TOUCHED,
    FLEX_ACL_KEY_INNER_FPP_3_TOUCHED,
    FLEX_ACL_KEY_INNER_FPP_4_TOUCHED,
    FLEX_ACL_KEY_INNER_FPP_5_TOUCHED,
    FLEX_ACL_KEY_INNER_FPP_6_TOUCHED,
    FLEX_ACL_KEY_INNER_FPP_7_TOUCHED,
};
sx_acl_key_type_t       key_handle;
sx_acl_region_id_t      region_id;
sx_acl_region_group_t   acl_region_group;
sx_acl_id_t             acl_id;
sx_acl_direction_t      acl_direction = SX_ACL_DIRECTION_INGRESS;
sx_acl_id_t             acl_group_id;
sx_acl_id_t             acl_id_list[1];
sx_flex_acl_flex_rule_t rules_example[16];


sx_status_t create_fpp_rule(sx_api_handle_t api_handle, sx_flex_parser_header_fpp_e fpp)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_acl_rule_offset_t offset = 0;


    /* Create key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_set_example,
                                        sizeof(key_id_set_example) / sizeof(key_id_set_example[0]),
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_CREATE,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      16,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_CREATE,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_CREATE,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    acl_id_list[0] = acl_id;
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_SET,
                                     acl_direction,
                                     acl_id_list,
                                     1,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create a simple rule using the FPP touch key */
    sx_status = sx_lib_flex_acl_rule_init(key_handle, 1, &rules_example[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_lib_flex_acl_rule_init failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }
    rules_example[0].valid = 1;
    rules_example[0].key_desc_count = 1;
    rules_example[0].action_count = 1;

    rules_example[0].key_desc_list_p[0].key_id = FLEX_ACL_KEY_FPP_TOUCHED_START + fpp;
    rules_example[0].key_desc_list_p[0].key.fpp_touched = TRUE;
    rules_example[0].key_desc_list_p[0].mask.fpp_touched = TRUE;
    rules_example[0].action_list_p[0].type = SX_FLEX_ACL_ACTION_SET_TTL;
    rules_example[0].action_list_p[0].fields.action_set_ttl.ttl_val = 77;

    sx_status = sx_api_acl_flex_rules_set(api_handle,
                                          SX_ACCESS_CMD_SET,
                                          region_id,
                                          &offset,
                                          &rules_example[0],
                                          1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_rules_set failed [%s]\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules_example[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_lib_flex_acl_rule_deinit failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }


out:
    return sx_status;
}

sx_status_t delete_fpp_rule(sx_api_handle_t api_handle, sx_flex_parser_header_fpp_e fpp)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(fpp);

    /* Delete ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      16,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Delete key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_DELETE,
                                        key_id_set_example,
                                        sizeof(key_id_set_example) / sizeof(key_id_set_example[0]),
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}


int main(int argc, char *argv[])
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_api_handle_t               api_handle;
    sx_flex_parser_param_t        flex_parser_param;
    sx_flex_parser_fpp_id_t       fpp_id;
    sx_flex_parser_fpp_t          fpp_cfg;
    sx_flex_parser_transition_t   transition_cfg;
    sx_flex_parser_header_t       parser_header;
    sx_flex_parser_root_sop_cfg_t root_cfg;
    sx_flex_parser_header_fpp_e   fpp = SX_FLEX_PARSER_HEADER_FPP3;

    memset(&flex_parser_param, 0, sizeof(flex_parser_param));
    memset(&fpp_id, 0, sizeof(fpp_id));
    memset(&fpp_cfg, 0, sizeof(fpp_cfg));
    memset(&transition_cfg, 0, sizeof(transition_cfg));
    memset(&parser_header, 0, sizeof(parser_header));
    memset(&root_cfg, 0, sizeof(root_cfg));

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    /* Open SDK API */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_parser_init_set(api_handle, &flex_parser_param);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_init_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Create a regular FPH */
    fpp_id.fpp_id = fpp;
    fpp_cfg.type = SX_FLEX_PARSER_FPP_TYPE_FPH;
    sx_status = sx_api_flex_parser_fpp_set(api_handle, SX_ACCESS_CMD_CREATE, &fpp_id, &fpp_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_fpp_set failed on create. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Set a regular FPH */
    fpp_cfg.hdr_len_field.constant = 8;
    fpp_cfg.protocol_field.offset = 2;
    fpp_cfg.protocol_field.size = 2;
    fpp_cfg.protocol_field.mask = 0xffff;
    sx_status = sx_api_flex_parser_fpp_set(api_handle, SX_ACCESS_CMD_SET, &fpp_id, &fpp_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_fpp_set failed on set. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Remove the fixed transition between the IPv4 to UDP */
    parser_header.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
    parser_header.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV4_E;
    transition_cfg.transition_value = 17;
    transition_cfg.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
    transition_cfg.next_parser_hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_UDP_E;
    sx_status = sx_api_flex_parser_transition_set(api_handle, SX_ACCESS_CMD_UNSET, parser_header, transition_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_transition_set failed on set. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Remove the fixed transition between the IPv6 to UDP */
    parser_header.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
    parser_header.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV6_E;
    transition_cfg.transition_value = 17;
    transition_cfg.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
    transition_cfg.next_parser_hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_UDP_E;
    sx_status = sx_api_flex_parser_transition_set(api_handle, SX_ACCESS_CMD_UNSET, parser_header, transition_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_transition_set failed on set. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }


    /* Set the transition from IPv4 to our FPH instead of the UDP */
    parser_header.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
    parser_header.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV4_E;
    transition_cfg.transition_value = 17;
    transition_cfg.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E;
    transition_cfg.next_parser_hdr.hdr_data.parser_hdr_fpp = fpp;
    sx_status = sx_api_flex_parser_transition_set(api_handle, SX_ACCESS_CMD_SET, parser_header, transition_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_transition_set failed on set. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Set the transition from IPv6 to our FPH instead of the UDP */
    parser_header.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
    parser_header.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV6_E;
    transition_cfg.transition_value = 17;
    transition_cfg.next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E;
    transition_cfg.next_parser_hdr.hdr_data.parser_hdr_fpp = 3;
    sx_status = sx_api_flex_parser_transition_set(api_handle, SX_ACCESS_CMD_SET, parser_header, transition_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_transition_set failed on set. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* Set a specific port to to go directly to our FPH */
    root_cfg.fpp_id.fpp_id = fpp;
    root_cfg.log_port = 0x10005;
    sx_status = sx_api_flex_parser_root_set(api_handle, SX_ACCESS_CMD_SET, &root_cfg, 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_root_set failed on set. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }


    /* Set ACL rule to match the FPP */
    sx_status = create_fpp_rule(api_handle, fpp);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed to create FPP rule. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    /* From here we REMOVE the configurations we've done so far */

    /* Remove the ACL rule */
    sx_status = delete_fpp_rule(api_handle, fpp);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: Failed to delete FPP rule. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }


    root_cfg.fpp_id.fpp_id = fpp;
    root_cfg.log_port = 0x10005;
    sx_status = sx_api_flex_parser_root_set(api_handle, SX_ACCESS_CMD_UNSET, &root_cfg, 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_root_set failed on unset. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    parser_header.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
    parser_header.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV6_E;
    transition_cfg.transition_value = 17;
    sx_status = sx_api_flex_parser_transition_set(api_handle, SX_ACCESS_CMD_UNSET, parser_header, transition_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_transition_set failed on unset. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    parser_header.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
    parser_header.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV4_E;
    transition_cfg.transition_value = 17;
    sx_status = sx_api_flex_parser_transition_set(api_handle, SX_ACCESS_CMD_UNSET, parser_header, transition_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_transition_set failed on unset. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    sx_status = sx_api_flex_parser_fpp_set(api_handle, SX_ACCESS_CMD_DESTROY, &fpp_id, &fpp_cfg);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_fpp_set failed on destroy. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }


    sx_status = sx_api_flex_parser_deinit_set(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_flex_parser_deinit_set failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }


    /* Close SDK API */
    sx_status = sx_api_close(&api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        exit(1);
    }

    printf("Successfully finished\n");
    return 0;
}
