/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/utils/sim.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <inttypes.h>
#include <complib/cl_types.h>
#include <complib/sx_log.h>
#include <utils/gen_utils.h>
#include <pthread.h>
#include <complib/cl_mem.h>

#undef  __MODULE__
#define __MODULE__ SIM

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/
sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

sim_init_params_t        sim_init_params;
uint32_t                 bg_full_reorder_stats_len = 0;
uint16_t                 cur_delta = 0;
uint16_t                 min_delta = 0;
uint16_t                 max_delta = 0;
uint32_t                 timer = 0;
bool                     is_steady = FALSE;
bool                     program_ended = FALSE;
uint32_t                 new_num_shifts = 0;
uint32_t                 old_num_shifts = 0;
float                    factor = 1.5;
uint32_t                 shifts = 0;
FILE                    *command_log = NULL;
uint32_t                 background_worker_count = 0;
bool                     already_read_delta = FALSE;
bool                     already_read_timer_thread = FALSE;
bool                     is_initialized = FALSE;
bool                     during_add_operation = FALSE;
bool                     during_resize_operation = FALSE;
bool                     g_is_first_shift = TRUE;
sx_run_mode_e            run_mode = PSORT_SIM_RUN_MODE_CONFORMANCE_E;
int                      bg_tcam_ratio = 0;
uint32_t                 tcam_foreground_count = 0;
psort_handle_t           handle = 0;
psort_init_param_t       param;
uint32_t                 seed = 0;
uint32_t                 delay_insert_remove = 0;
uint32_t                 num_of_seeds = 1;
uint32_t                 cur_table_size = SIM_TABLE_SIZE;
uint32_t                 total_num = 0;
sim_entry_t             *sim_db = NULL;
pthread_t                timer_thread;
bool                     is_timer_thread_started = FALSE;
bool                     already_executed = FALSE;
bg_full_reorder_stats_t *bg_full_reorder_stats_arr = NULL;
statistics_t            *statistic_per_delta = NULL;
uint8_t                  iteration_counter = 0;
uint8_t                  seed_counter = 0;
sim_run_seed_info      * p_sim_run_seed_info = NULL;
uint32_t                *prios_arr = NULL;
static pthread_mutex_t   psort_mutex;

/************************************************
 *  Local function declarations
 ***********************************************/
static int __time_sub(struct timeval *end, struct timeval *begin, struct timeval *result);
static int __time_sum(struct timeval *val, struct timeval *result);
static int __time_update_min_max(struct timeval *time, bg_full_reorder_stats_t *stats);
static int __time_avg(struct timeval *time, uint16_t num, struct timeval *result);
int __time_min_max(struct timeval *in_time, struct timeval *inout_max, struct timeval *inout_min);

/* handlers */
static sx_utils_status_t __handle_line(char *line);
static sx_utils_status_t __handle_rand_operation(char *line);
static sx_utils_status_t __handle_psort_params_set(char *line);
static sx_utils_status_t __handle_insertion_delay(char *line);
static sx_utils_status_t __handle_num_of_seeds(char *line);
static sx_utils_status_t __handle_num_of_prios(char *line);
static sx_utils_status_t __handle_add(char *line);
static sx_utils_status_t __handle_rem(char *line);
static sx_utils_status_t __handle_reorder(char *line);
static sx_utils_status_t __handle_init(char *line);
static sx_utils_status_t __handle_resize(char *line);
static sx_utils_status_t __handle_seed(char *line);
static sx_utils_status_t __handle_timer_thread(char* line);
static sx_utils_status_t __handle_delta(char *line);
static void __print_help(void);
static void __clear_counters(void);
static sx_utils_status_t __sim_notf_cb(psort_notification_type_e notif_type, void* data, void* cookie);
static void * set_timer_thread(void);
static sx_utils_status_t __call_bg_and_update_status(bool is_reordering_full);

/* add */
static sx_utils_status_t __add_entry(uint32_t key, int prio);
static sx_utils_status_t __add_random_n(uint16_t amount);
static sx_utils_status_t __add_random_n_prio(uint16_t amount, int prio);
static sx_utils_status_t __add_block(uint16_t num_prio, uint16_t num_per_prio);

/* remove */
static sx_utils_status_t __rem_specific_entry(uint32_t key, int prio);
static sx_utils_status_t __rem_random_n_prio(uint16_t amount, bool specific_prio, int prio);
static sx_utils_status_t __reorder_n(bool do_reorder_full, uint16_t num, bool do_check_each_reorder, char* tag);
static sx_utils_status_t __check_constrains(bool should_lock);
static sx_utils_status_t __sim_init_db(uint32_t table_size);
static sx_utils_status_t __is_mirror_db_equals_psort_table(uint32_t table_size);
static sx_utils_status_t __wait_for_steady_state(void);
static float __percentage_full(void);
static void __print_stats(bool is_end);
static void __deinit(void);

/* validations */
static sx_utils_status_t __validate_init_constrains(const psort_init_param_t *params);
static sx_utils_status_t __validate_add_constrains(psort_entry_t *entry_p, uint16_t num_of_entries);
static sx_utils_status_t __validate_rem_constrains(psort_entry_t *entries_p, uint16_t num_to_del);

/* wrappers */
static sx_utils_status_t __psort_init_wrapper(psort_handle_t *handle, const psort_init_param_t *params);
static sx_utils_status_t __get_entry_by_key_prio(psort_entry_info_t *entry_info,
                                                 psort_entry_info_t *entries_p,
                                                 uint32_t            num_entries);
static sx_utils_status_t __validate_reorder_constrains(psort_entry_info_t *entries_before_p,
                                                       uint32_t            num_entries_before,
                                                       psort_entry_info_t *entries_after_p);
static sx_utils_status_t __print_table(void);
static sx_utils_status_t __generate_rand_prio_arr(uint32_t min_prio, uint32_t max_prio);
static void __dbg_print();
static void __collect_stats_from_seeds(uint32_t curr_seed);
static long long __get_time_stamp(struct timespec* ts);


/************************************************
 *  Function implementations
 ***********************************************/

void sim_log_cb(sx_log_severity_t severity, const char *module_name, char *msg)
{
    UNUSED_PARAM(module_name);
    sx_verbosity_level_t verbosity = 0;

    SEVERITY_LEVEL_TO_VERBOSITY_LEVEL(severity, verbosity);
    SIM_PRINT("[PSORT_SIM][%s] : %s", SX_VERBOSITY_LEVEL_STR(verbosity), msg);

    return;
}

void __print_all_tables()
{
    uint32_t j = 0;

    psort_debug_dump(handle, stdout);
    psort_debug_dump(handle, logfile);
    SIM_PRINT("##############\n");
    __print_table();
    SIM_PRINT("##############\n");
    for (j = 0; j < cur_table_size; j++) {
        SIM_PRINT("%d) v %d, prio %" PRIu32 ", key %" PRIu64 "\n", j, sim_db[j].valid,
                  sim_db[j].priority, sim_db[j].key);
    }
}

void __dbg_print()
{
    psort_debug_dump(handle, stdout);
    psort_debug_dump(handle, logfile);
}

int main(int argc, char *argv[])
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    int               size = 1024, pos;
    int               parse_character;
    char             *buffer = NULL;
    boolean_t         use_specifc_seed = FALSE;
    bool              is_not_eof = FALSE;

    logfile = fopen(LOG_FILE_PATH, "w");
    command_log = fopen(COMMAND_LOG_PATH, "w");
    if (!command_log) {
        SIM_PRINT("failed to open command log file\n");
        return SX_UTILS_STATUS_ERROR;
    }

    int i = 0;

    if (argc < 2) {
        __print_help();
        return status;
    }

    pthread_mutex_init(&psort_mutex, NULL);

    seed = time(NULL); /* first, take seed from time */

    for (i = 1; i < argc; i++) {
        if (IS_STR_BEGINS_WITH(argv[i], "help") ||
            IS_STR_BEGINS_WITH(argv[i], "-h") ||
            IS_STR_BEGINS_WITH(argv[i], "--h")) {
            __print_help();
            return status;
        } else if (IS_STR_BEGINS_WITH(argv[i], "-s")) {
            if (i < argc - 1) {
                seed = atoi(argv[i + 1]);
                use_specifc_seed = TRUE;
                SIM_PRINT("seed from command line: %d\n", seed);
            }
        } else if (IS_STR_BEGINS_WITH(argv[i], "-n")) {
            if (i < argc - 1) {
                num_of_seeds = atoi(argv[i + 1]);
                SIM_PRINT("num of seeds from command line: %d\n", seed);
            }
        } else if (IS_STR_BEGINS_WITH(argv[i], "-r")) {
            if (i < argc - 1) {
                run_mode = atoi(argv[i + 1]);
                SIM_PRINT("run mode from command line: %d\n", run_mode);
            }
        } else if (IS_STR_BEGINS_WITH(argv[i], "-b")) {
            if (i < argc - 1) {
                bg_tcam_ratio = atoi(argv[i + 1]);
                SIM_PRINT("background reorder will run once every [%d] tcam writes\n", bg_tcam_ratio);
            }
        }
    }

    SIM_CLR_MEMORY_GET(buffer, size, char);
    memset(&sim_init_params, 0, sizeof(sim_init_params_t));
    sim_init_params.psort_set_param.hole_min_size_factor = 3;

    status = sx_log_init(TRUE, NULL, sim_log_cb);
    if (status != 0) {
        fprintf(stderr, "ERROR: Initializing log utility failed.\n");
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    memset(&param, 0, sizeof(psort_init_param_t));

    SIM_PRINT("input file path: %s\n", argv[1]);
    SIM_PRINT("log file path: %s\n", LOG_FILE_PATH);

    /* Measure time */
    struct timespec ts;
    long long       start_nsec = 0;
    long long       end_nsec = 0;

    start_nsec = __get_time_stamp(&ts);

    do { /* repeat for increment delta */
        SIM_CLR_MEMORY_GET(p_sim_run_seed_info, num_of_seeds, sim_run_seed_info);

        for (seed_counter = 0; seed_counter < num_of_seeds; seed_counter++) {
            SIM_PRINT("seed run #: %d/%d\n", seed_counter + 1, num_of_seeds);
            if (use_specifc_seed == FALSE) {
                if (seed == 0) {
                    /* is first time (seed == 0) ? */
                    seed = time(NULL); /* Take seed from time */
                } else {
                    seed++;
                }
            }

            FILE *f = fopen(argv[1], "r");
            if (f) {
                do { /* read all lines in file */
                    pos = 0;
                    is_not_eof = FALSE;
                    do { /* read one line */
                        parse_character = fgetc(f);
                        if (parse_character != EOF) {
                            buffer[pos++] = (char)parse_character;
                            is_not_eof = TRUE;
                        }
                        if (pos >= size - 1) { /* increase buffer length - leave room for 0 */
                            status = SX_UTILS_STATUS_ERROR;
                            SIM_LOG_ERR("line too long (%s)\n", SX_UTILS_STATUS_MSG(status));
                            goto out;
                        }
                    } while (parse_character != EOF && parse_character != '\n'); /* end read line */
                    if (is_not_eof == TRUE) {
                        buffer[pos] = '\0';
                        /* line is now in buffer */
                        if (SX_UTILS_CHECK_FAIL(status = __handle_line(buffer))) {
                            SIM_LOG_ERR("Operation failed (%s)\n", SX_UTILS_STATUS_MSG(status));
                            goto out;
                        }
                    }
                } while (parse_character != EOF); /* end file read */
                SIM_PRINT("\n#####################\n");
                SIM_PRINT("reached end of file\n");
                SIM_PRINT("#####################\n");
                fclose(f);
            } else {
                SIM_LOG_ERR("failed to open input file\n");
                status = SX_UTILS_STATUS_ERROR;
                goto out;
            }
            __collect_stats_from_seeds(seed_counter);
            __print_stats(FALSE);
            __clear_counters();
        } /* end seed iteration */
        SIM_MEMORY_PUT(p_sim_run_seed_info);
        iteration_counter++;
    } while (cur_delta++ < max_delta); /* end incremental delta iteration */

    end_nsec = __get_time_stamp(&ts);

    long long diff_nano = end_nsec - start_nsec;
    long long microsec_diff = diff_nano / 1000;
    long long millisec_diff = microsec_diff / 1000;
    long long second_diff = millisec_diff / 1000;

    SIM_PRINT("##############\nduration: %" PRIu64 " seconds\n##############\n\n", (uint64_t)second_diff);
out:
    __print_stats(TRUE);
    SIM_PRINT("\n\n");
    SIM_PRINT("##############\nstatus: %d\n##############\n\n", status);
    if (SX_UTILS_CHECK_FAIL(status)) {
        __print_all_tables();
        SIM_PRINT("Simulator FAILED :( %s\n", SX_UTILS_STATUS_MSG(status));
        SIM_PRINT("seed = %u\n", seed);
    } else {
        SIM_PRINT("Simulator finished SUCCESSFULLY :)\n");
    }

    SIM_PRINT("\n\n\n");
    __deinit();
    SIM_MEMORY_PUT(buffer);
    return status;
}

void __deinit()
{
    SIM_MEMORY_PUT(sim_db);
    SIM_MEMORY_PUT(bg_full_reorder_stats_arr);
    SIM_MEMORY_PUT(statistic_per_delta);

    fclose(logfile);
    fclose(command_log);
    program_ended = TRUE;
    if (timer > 0) {
        pthread_join(timer_thread, NULL);
    }
}

sx_utils_status_t reorder_according_to_background_tcam_ratio(uint32_t tcam_foreground_count_before)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    if (tcam_foreground_count_before / bg_tcam_ratio < tcam_foreground_count / bg_tcam_ratio) {
        if (SX_UTILS_CHECK_FAIL(status = __reorder_n(TRUE, 1, FALSE, "reorder_according_to_bg_tcam_ratio"))) {
            SIM_LOG_ERR("failed to reorder after %" PRIu32 " tcam foreground writes %s\n",
                        tcam_foreground_count,
                        SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    }

out:
    return status;
}

void __print_stats(bool is_end)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_info_t *entries_p = NULL;
    psort_info_stats_t  info;
    uint32_t            num_entries = cur_table_size;
    uint32_t            i = 0, valids = 0;
    struct timeval      avg_duration;
    uint32_t            num_of_shifts_sum = 0;
    uint32_t            foreground_shifts_sum = 0;
    uint32_t            background_shifts_sum = 0;
    uint32_t            add_tv_sec_sum = 0, add_tv_usec_sum = 0;
    uint32_t            bg_tv_sec_sum = 0, bg_tv_usec_sum = 0;
    uint32_t            seed_idx = 0;

    if (FALSE == is_end) {
        if (SX_UTILS_CHECK_FAIL(status = psort_info_stats_get(handle, &info))) {
            SIM_LOG_ERR("Failed to get info stats %s\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }

        SIM_CLR_MEMORY_GET(entries_p, num_entries, psort_entry_info_t);

        /* dump db */
        if (SX_UTILS_CHECK_FAIL(status = psort_dump_table(handle, entries_p, &num_entries))) {
            SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }

        uint32_t       l_min_total_shift = 99999;
        uint32_t       l_max_total_shift = 0;
        uint32_t       l_min_foreground_shift = 99999;
        uint32_t       l_max_foreground_shift = 0;
        uint32_t       l_min_background_shift = 99999;
        uint32_t       l_max_background_shift = 0;
        struct timeval min_add_time, max_add_time;
        struct timeval min_bg_time, max_bg_time;
        struct timeval min_fg_bg_time, max_fg_bg_time;
        memset(&min_add_time, 0, sizeof(struct timeval));
        min_add_time.tv_sec = 0xFFFF;
        memset(&max_add_time, 0, sizeof(struct timeval));
        memset(&min_bg_time, 0, sizeof(struct timeval));
        min_bg_time.tv_sec = 0xFFFF;
        memset(&max_bg_time, 0, sizeof(struct timeval));
        memset(&min_fg_bg_time, 0, sizeof(struct timeval));
        min_fg_bg_time.tv_sec = 0xFFFF;
        memset(&max_fg_bg_time, 0, sizeof(struct timeval));

        for (seed_idx = 0; seed_idx < num_of_seeds; seed_idx++) {
            if (l_min_total_shift > p_sim_run_seed_info[seed_idx].total_shifts) {
                l_min_total_shift = p_sim_run_seed_info[seed_idx].total_shifts;
            }
            if (l_max_total_shift < p_sim_run_seed_info[seed_idx].total_shifts) {
                l_max_total_shift = p_sim_run_seed_info[seed_idx].total_shifts;
            }
            if (l_min_foreground_shift > p_sim_run_seed_info[seed_idx].foreground_shifts) {
                l_min_foreground_shift = p_sim_run_seed_info[seed_idx].foreground_shifts;
            }
            if (l_max_foreground_shift < p_sim_run_seed_info[seed_idx].foreground_shifts) {
                l_max_foreground_shift = p_sim_run_seed_info[seed_idx].foreground_shifts;
            }
            if (l_min_background_shift > p_sim_run_seed_info[seed_idx].background_shifts) {
                l_min_background_shift = p_sim_run_seed_info[seed_idx].background_shifts;
            }
            if (l_max_background_shift < p_sim_run_seed_info[seed_idx].background_shifts) {
                l_max_background_shift = p_sim_run_seed_info[seed_idx].background_shifts;
            }
            __time_min_max(&p_sim_run_seed_info[seed_idx].total_add_time, &max_add_time, &min_add_time);
            __time_min_max(&p_sim_run_seed_info[seed_idx].total_bg_time, &max_bg_time, &min_bg_time);
            struct timeval fg_bg_time;
            memset(&fg_bg_time, 0, sizeof(struct timeval));
            __time_sum(&statistic_per_delta[i].total_add_time, &fg_bg_time);
            __time_sum(&statistic_per_delta[i].total_bg_time,  &fg_bg_time);
            __time_min_max(&fg_bg_time, &max_fg_bg_time, &min_fg_bg_time);

            num_of_shifts_sum += p_sim_run_seed_info[seed_idx].total_shifts;
            foreground_shifts_sum += p_sim_run_seed_info[seed_idx].foreground_shifts;
            background_shifts_sum += p_sim_run_seed_info[seed_idx].background_shifts;
            add_tv_sec_sum += p_sim_run_seed_info[seed_idx].total_add_time.tv_sec;
            add_tv_usec_sum += p_sim_run_seed_info[seed_idx].total_add_time.tv_usec;
            bg_tv_sec_sum += p_sim_run_seed_info[seed_idx].total_bg_time.tv_sec;
            bg_tv_usec_sum += p_sim_run_seed_info[seed_idx].total_bg_time.tv_usec;
        }

        statistic_per_delta[iteration_counter].total_shifts = num_of_shifts_sum / num_of_seeds;
        statistic_per_delta[iteration_counter].total_add_shifts = foreground_shifts_sum / num_of_seeds;
        statistic_per_delta[iteration_counter].total_background_shifts = background_shifts_sum / num_of_seeds;
        statistic_per_delta[iteration_counter].total_add_time.tv_sec = add_tv_sec_sum / num_of_seeds;
        statistic_per_delta[iteration_counter].total_add_time.tv_usec = add_tv_usec_sum / num_of_seeds;
        statistic_per_delta[iteration_counter].total_bg_time.tv_sec = bg_tv_sec_sum / num_of_seeds;
        statistic_per_delta[iteration_counter].total_bg_time.tv_usec = bg_tv_usec_sum / num_of_seeds;
        statistic_per_delta[iteration_counter].min_total_shift = l_min_total_shift;
        statistic_per_delta[iteration_counter].max_total_shift = l_max_total_shift;
        statistic_per_delta[iteration_counter].min_foreground_shift = l_min_foreground_shift;
        statistic_per_delta[iteration_counter].max_foreground_shift = l_max_foreground_shift;
        statistic_per_delta[iteration_counter].min_background_shift = l_min_background_shift;
        statistic_per_delta[iteration_counter].max_background_shift = l_max_background_shift;
        statistic_per_delta[iteration_counter].max_add_time = max_add_time;
        statistic_per_delta[iteration_counter].min_add_time = min_add_time;
        statistic_per_delta[iteration_counter].max_bg_time = max_bg_time;
        statistic_per_delta[iteration_counter].min_bg_time = min_bg_time;
        statistic_per_delta[iteration_counter].max_fg_plus_bg_time = max_fg_bg_time;
        statistic_per_delta[iteration_counter].min_fg_plus_bg_time = min_fg_bg_time;

        for (i = 0; i < num_entries; i++) {
            valids += (entries_p[i].valid) ? 1 : 0;
        }

        if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
            SIM_PRINT("\n#####################\n");
            SIM_PRINT("psort table dump:\n");
            SIM_PRINT("#####################\n\n");
            for (i = 0; i < num_entries; i++) {
                SIM_PRINT("[%-3d]  p=%-3" PRIu32 " valid=%-2d k=%-12" PRIu64 " i=%-5" PRIu32 "\n",
                          i, entries_p[i].entry.priority, entries_p[i].valid,
                          entries_p[i].entry.key, entries_p[i].entry.index);
            }
        }

        SIM_PRINT("\n");
        SIM_PRINT(
            "################################################################################################\n\n");
        SIM_PRINT("statistics: (delta = %d):\n", cur_delta);
        SIM_PRINT("=========================\n");
        SIM_PRINT("\n");
        SIM_PRINT("   table size: %" PRIu32 "\n", cur_table_size);
        SIM_PRINT("   total valid entries: %" PRIu32 "\n", valids);
        SIM_PRINT("   num of regions: %" PRIu32 "\n", info.num_of_regions);
        SIM_PRINT("   total num of shifts: %" PRIu32 "\n", info.num_of_shifts);
        SIM_PRINT("   total region hole num: %" PRIu32 "\n", info.total_region_hole_num);
        SIM_PRINT("   total regions size: %" PRIu32 "\n", info.total_regions_size);
        SIM_PRINT("   total background worker call %" PRIu32 " \n", background_worker_count);
        SIM_PRINT("\n\n");

        valids = 0;
        for (i = 0; i < cur_table_size; i++) {
            if (bg_full_reorder_stats_arr[i].valid) {
                valids++;
            }
        }

        if (valids) {
            SIM_PRINT("   BACKGROUND REORDER results (delta = %d):\n", cur_delta);
            SIM_PRINT("   ----------------------------------------\n");
            SIM_PRINT("     num    | background shifts num | time to steady state (sec) |\n");
            SIM_PRINT("    entries |  max  |  min  |  avg  |   max  |   min   |   avg   |\n");
            for (i = 0; i < bg_full_reorder_stats_len; i++) {
                if (bg_full_reorder_stats_arr[i].valid && (bg_full_reorder_stats_arr[i].total_shifts_count > 0)) {
                    SIM_PRINT("   ---------|-------|-------|-------|--------|---------|---------|\n");
                    SIM_PRINT("      %-6" PRIu32 "|", i + 1);
                    SIM_PRINT("%-7" PRIu32 "|", bg_full_reorder_stats_arr[i].max_shift_count);
                    SIM_PRINT("%-7" PRIu32 "|", bg_full_reorder_stats_arr[i].min_shift_count);
                    SIM_PRINT("%-7d|",
                              bg_full_reorder_stats_arr[i].total_shifts_count /
                              bg_full_reorder_stats_arr[i].num_shifts);
                    SIM_PRINT("%2ld.%-5ld|",
                              bg_full_reorder_stats_arr[i].max_shift_time.tv_sec,
                              bg_full_reorder_stats_arr[i].max_shift_time.tv_usec);
                    SIM_PRINT("%2ld.%-6ld|",
                              bg_full_reorder_stats_arr[i].min_shift_time.tv_sec,
                              bg_full_reorder_stats_arr[i].min_shift_time.tv_usec);
                    __time_avg(&bg_full_reorder_stats_arr[i].total_shift_time,
                               bg_full_reorder_stats_arr[i].num_shifts,
                               &avg_duration);
                    SIM_PRINT("%2ld.%-6ld|", avg_duration.tv_sec, avg_duration.tv_usec);
                    SIM_PRINT("\n");
                }
            }
        }
        SIM_PRINT("\n");
        SIM_PRINT(
            "################################################################################################\n\n");
    } else {
        SIM_PRINT("\n\n\n\n\n          ALL ITERATIONS ENDED!");
        SIM_PRINT("\n\n\n\n\n");
        SIM_PRINT(
            "################################################################################################\n\n");
        SIM_PRINT("ADD operation final results:\n");
        SIM_PRINT("============================\n");
        SIM_PRINT("\n");
        SIM_PRINT("   Total duration & shifts spent:\n");
        SIM_PRINT("   ===============================================\n");
        SIM_PRINT(
            "   delta size |      fg dur. (sec)     |        bg dur. (sec)     |          fg+bg dur.       |      fg shifts num    |     bg shifts  num   |    total shifts num  |\n");
        SIM_PRINT(
            "              |  avg  |   min  |  max  |  avg   |  min   |  max   |  avg   |  min   |   max   |  avg  |  min  |  max  |  avg |  min  |  max  |  avg |  min  |  max  |\n");
        for (i = 0; i < iteration_counter; i++) {
            SIM_PRINT(
                "   -----------|-------|--------|-------|--------|--------|--------|--------|--------|---------|-------|-------|-------|------|-------|-------|------|-------|-------|\n");
            SIM_PRINT("        %-6u|", min_delta + i);
            struct timeval fg_bg_time;
            memset(&fg_bg_time, 0, sizeof(struct timeval));
            __time_sum(&statistic_per_delta[i].total_add_time, &fg_bg_time);
            __time_sum(&statistic_per_delta[i].total_bg_time,  &fg_bg_time);
            SIM_PRINT("%3ld.%-3ld|%3ld.%-4ld|%3ld.%-3ld|",
                      statistic_per_delta[i].total_add_time.tv_sec, statistic_per_delta[i].total_add_time.tv_usec,
                      statistic_per_delta[i].min_add_time.tv_sec, statistic_per_delta[i].min_add_time.tv_usec,
                      statistic_per_delta[i].max_add_time.tv_sec, statistic_per_delta[i].max_add_time.tv_usec);
            SIM_PRINT("%3ld.%-4ld|%3ld.%-4ld|%3ld.%-.4ld|",
                      statistic_per_delta[i].total_bg_time.tv_sec, statistic_per_delta[i].total_bg_time.tv_usec,
                      statistic_per_delta[i].min_bg_time.tv_sec, statistic_per_delta[i].min_bg_time.tv_usec,
                      statistic_per_delta[i].max_bg_time.tv_sec, statistic_per_delta[i].max_bg_time.tv_usec);
            SIM_PRINT("%3ld.%-4ld|%3ld.%-4ld|%3ld.%-.5ld|",
                      fg_bg_time.tv_sec,
                      fg_bg_time.tv_usec,
                      statistic_per_delta[i].min_fg_plus_bg_time.tv_sec,
                      statistic_per_delta[i].min_fg_plus_bg_time.tv_usec,
                      statistic_per_delta[i].max_fg_plus_bg_time.tv_sec,
                      statistic_per_delta[i].max_fg_plus_bg_time.tv_usec);
            char line[50];
            snprintf(line, 50, "%-7" PRIu32 "|%-7" PRIu32 "|%-7" PRIu32 "",
                     statistic_per_delta[i].total_add_shifts,
                     statistic_per_delta[i].min_foreground_shift,
                     statistic_per_delta[i].max_foreground_shift);
            SIM_PRINT("%-3s|", line);
            snprintf(line, 50, "%-6" PRIu32 "|%-7" PRIu32 "|%-7" PRIu32 "",
                     statistic_per_delta[i].total_background_shifts,
                     statistic_per_delta[i].min_background_shift,
                     statistic_per_delta[i].max_background_shift);
            SIM_PRINT("%-3s|", line);
            snprintf(line, 50, "%-6" PRIu32 "|%-7" PRIu32 "|%-7" PRIu32 "",
                     statistic_per_delta[i].total_shifts,
                     statistic_per_delta[i].min_total_shift,
                     statistic_per_delta[i].max_total_shift);
            SIM_PRINT("%-3s|", line);
        }
        SIM_PRINT("\n");
        SIM_PRINT(
            "################################################################################################\n\n");
    }

out:
    SIM_MEMORY_PUT(entries_p);

    return;
}


void __collect_stats_from_seeds(uint32_t cur_seed)
{
    sx_utils_status_t  status = SX_UTILS_STATUS_SUCCESS;
    psort_info_stats_t info;

    if (SX_UTILS_CHECK_FAIL(status = psort_info_stats_get(handle, &info))) {
        SIM_LOG_ERR("Failed to get info stats %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    p_sim_run_seed_info[cur_seed].total_shifts = info.num_of_shifts;
    /*p_sim_run_seed_info[cur_seed].foreground_shifts =  total_add_shifts[i];*/
    p_sim_run_seed_info[cur_seed].background_shifts = p_sim_run_seed_info[cur_seed].total_shifts -
                                                      p_sim_run_seed_info[cur_seed].foreground_shifts;


out:
    return;
}

sx_utils_status_t execute_once_after_init()
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    if (already_executed == FALSE) {
        if (sim_init_params.num_of_prios > 0) {
            /* validation for num_of_prios */
            if (sim_init_params.num_of_prios > (uint32_t)param.max_priority - (uint32_t)param.min_priority + 1) {
                status = SX_UTILS_STATUS_ERROR;
                SIM_PRINT("num of prios is (%d) but prio range is (%d,%d) (%s)\n", sim_init_params.num_of_prios,
                          param.min_priority,
                          param.min_priority,
                          SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        }

        /* generate random priority array */
        status = __generate_rand_prio_arr(param.min_priority, param.max_priority);
        if (SX_UTILS_CHECK_FAIL(status)) {
            SIM_PRINT("generate_rand_prio_arr failed (%s)\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    }
    already_executed = TRUE;
out:
    return status;
}

/**
 *
 * LINE HANDLERS
 *
 */

sx_utils_status_t __handle_line(char *line)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    /* ignore new lines or comments */
    if (IS_STR_EQUAL(line, "\n") ||
        IS_STR_BEGINS_WITH(line, "#")) {
        goto out;
    }

    if (NULL == line) {
        status = SX_UTILS_STATUS_PARAM_NULL;
        SIM_PRINT("null pointer (%s)\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    if (IS_STR_BEGINS_WITH(line, SIM_STR_TIMER_THREAD)) {
        return __handle_timer_thread(line);
    } else if (IS_STR_BEGINS_WITH(line, SIM_STR_DELTA)) {
        return __handle_delta(line);
    } else if (IS_STR_BEGINS_WITH(line, SIM_STR_INIT)) {
        return __handle_init(line);
    } else if (IS_STR_BEGINS_WITH(line, SIM_STR_FIXED_SEED)) {
        return __handle_seed(line);
    } else if (IS_STR_BEGINS_WITH(line, SIM_STR_INSERTION_DELAY)) {
        return __handle_insertion_delay(line);
    } else if (IS_STR_BEGINS_WITH(line, SIM_STR_NUM_OF_SEEDS)) {
        return __handle_num_of_seeds(line);
    } else if (IS_STR_BEGINS_WITH(line, SIM_STR_NUM_OF_PRIOS)) {
        return __handle_num_of_prios(line);
    } else if (IS_STR_BEGINS_WITH(line, SIM_STR_PSORT_PARAMS_SET)) {
        return __handle_psort_params_set(line);
    } else {
        /* check psort lib was initialized */
        if (!is_initialized) {
            status = SX_UTILS_STATUS_NOT_INITIALIZED;
            SIM_PRINT("error: need to call init. run help for more details (%s)\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
        if (SX_UTILS_CHECK_FAIL(status = execute_once_after_init())) {
            SIM_PRINT("error: execute_once_after_init failed (%s)\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }

        if (IS_STR_BEGINS_WITH(line, SIM_STR_ADD)) {
            return __handle_add(line);
        } else if (IS_STR_BEGINS_WITH(line, SIM_STR_REM)) {
            return __handle_rem(line);
        } else if (IS_STR_BEGINS_WITH(line, SIM_STR_REORDER)) {
            return __handle_reorder(line);
        } else if (IS_STR_BEGINS_WITH(line, PRINT)) {
            __print_all_tables();
            goto out;
        } else if (IS_STR_BEGINS_WITH(line, SIM_STR_CHECK)) {
            return __check_constrains(TRUE);
        } else if (IS_STR_BEGINS_WITH(line, SIM_STR_RESIZE_TABLE)) {
            return __handle_resize(line);
        } else if (IS_STR_BEGINS_WITH(line, SIM_STR_WAIT_FOR_STEADY_STATE)) {
            return __wait_for_steady_state();
        } else if (IS_STR_BEGINS_WITH(line, SIM_STR_RAND_OPERATION)) {
            return __handle_rand_operation(line);
        } else {
            status = SX_UTILS_STATUS_CMD_UNSUPPORTED;
            SIM_PRINT("error: invalid command in: %s (%s) \n", line, SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    }

out:
    return status;
}

sx_utils_status_t __handle_delta(char *line)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    char            * ptr = NULL;
    char            * cmd = NULL;
    int               min = 0, max = 0;

    if (TRUE == already_read_delta) {
        SIM_PRINT("\n\n\n\n\n\n");
        SIM_PRINT("#########################\n");
        SIM_PRINT("#########################\n");
        SIM_PRINT("\nDELTA: %d seed run # %d\n", cur_delta, seed_counter + 1);
        SIM_PRINT("#########################\n");
        SIM_PRINT("#########################\n\n\n\n\n\n");
        goto out;
    }

    ptr = strchr(line, ' ');
    if (ptr == NULL) {
        SIM_LOG_ERR("invalid value in delta: %s\n", line);
        status = SX_UTILS_STATUS_ERROR;
        goto out;
    }
    ptr++;

    already_read_delta = TRUE;

    SIM_PRINT("delta: ");

    cmd = strtok(ptr, " \n");
    if (cmd != NULL) {
        ptr = strtok(NULL, " \n");
        if (ptr != NULL) {
            min = atoi(ptr);
        }

        if (IS_STR_EQUAL(cmd, SIM_STR_FIXED)) {
            SIM_PRINT("%s value: %d\n", cmd, min);

            min_delta = min;
            cur_delta = min;

            SIM_CLR_MEMORY_GET(statistic_per_delta, 1, statistics_t);

            goto out;
        } else if (IS_STR_EQUAL(cmd, SIM_STR_INCREMENTAL)) {
            ptr = strtok(NULL, " \n");
            if (ptr != NULL) {
                max = atoi(ptr);
            }

            if (min >= max) {
                status = SX_UTILS_STATUS_PARAM_ERROR;
                SIM_LOG_ERR("invalid value in delta, min: %d, max=%d (%s)\n", min, max, SX_UTILS_STATUS_MSG(status));
                goto out;
            }

            max_delta = max;
            min_delta = min;
            cur_delta = min_delta;

            SIM_CLR_MEMORY_GET(statistic_per_delta, max - min + 1, statistics_t);

            SIM_PRINT("%s min: %d, max: %d\n", cmd, min, max);

            goto out;
        } else {
            SIM_LOG_ERR("invalid value in delta: %s\n", line);
            status = SX_UTILS_STATUS_ERROR;
            goto out;
        }
    }

out:
    return status;
}

sx_utils_status_t __handle_init(char *line)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    char            * ptr = NULL;
    int               max_prio = 0, min_prio = 0, full_thr = 0, empty_thr = 0;

    SIM_PRINT("seed: %u\n", seed);
    srand(seed);
    SIM_PRINT("--------------------------\n")
    SIM_PRINT("calling init: \n");
    SIM_PRINT("--------------------------\n")

    if (param.delta_size != 0) {
        param.delta_size = cur_delta;
        cur_table_size = sim_init_params.table_size;
        if (SX_UTILS_CHECK_FAIL(status = __psort_init_wrapper(&handle, &param))) {
            SIM_LOG_ERR("Init Failed (%s)\n", SX_UTILS_STATUS_MSG(status));
        }
        goto out;
    }

    ptr = strchr(line, ' ');
    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in init: %s\n", line);
        goto out;
    }

    ptr++;
    ptr = strtok(ptr, " \n");
    if (ptr != NULL) {
        sim_init_params.table_size = atoi(ptr);
        cur_table_size = sim_init_params.table_size;

        ptr = strtok(NULL, " \n");
        if (ptr != NULL) {
            max_prio = atoi(ptr);

            ptr = strtok(NULL, " \n");
            if (ptr != NULL) {
                min_prio = atoi(ptr);

                ptr = strtok(NULL, " \n");
                if (ptr != NULL) {
                    full_thr = atoi(ptr);

                    ptr = strtok(NULL, " \n");
                    if (ptr != NULL) {
                        empty_thr = atoi(ptr);

                        SIM_PRINT("table size: %" PRIu32 "\n", cur_table_size);
                        SIM_PRINT("cur delta: %" PRIu16 "\n", cur_delta);
                        SIM_PRINT("max priority: %" PRIu32 "\n", max_prio);
                        SIM_PRINT("min priority: %" PRIu32 "\n", min_prio);
                        SIM_PRINT("full thr: %d\n", full_thr);
                        SIM_PRINT("empty thr: %d\n", empty_thr);

                        cur_delta = (cur_delta == 0) ? SIM_DELTA_DEFAULT : cur_delta;

                        param.delta_size = cur_delta;
                        param.max_priority = max_prio;
                        param.min_priority = min_prio;
                        param.notif_callback = (psort_notification_func_ptr_t)__sim_notf_cb;
                        param.table_almost_empty_precentage_threshold = empty_thr;
                        param.table_almost_full_precentage_threshold = full_thr;
                        param.table_size = cur_table_size;

                        status = __psort_init_wrapper(&handle, &param);

                        goto out;
                    }
                }
            }
        }
    }

    status = SX_UTILS_STATUS_ERROR;
    SIM_LOG_ERR("invalid value in init: %s\n", line);
    goto out;

out:
    return status;
}

sx_utils_status_t __handle_psort_params_set(char *line)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    char            * ptr = NULL;

    SIM_PRINT("--------------------------\n")
    SIM_PRINT("calling psort param set: \n");
    SIM_PRINT("--------------------------\n")

    if (is_initialized == FALSE) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("must initialize psort before psort params set %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    ptr = strchr(line, ' ');
    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in init: %s\n", line);
        goto out;
    }

    ptr++;
    ptr = strtok(ptr, " \n");
    if (ptr != NULL) {
        sim_init_params.psort_set_param.background_move_block_size = atoi(ptr);

        ptr = strtok(NULL, " \n");
        if (ptr != NULL) {
            sim_init_params.psort_set_param.foreground_move_block_size = atoi(ptr);

            ptr = strtok(NULL, " \n");
            if (ptr != NULL) {
                sim_init_params.psort_set_param.decrease_size_threshold = atoi(ptr);

                ptr = strtok(NULL, " \n");
                if (ptr != NULL) {
                    sim_init_params.psort_set_param.expand_at_empty_space_size = atoi(ptr);

                    ptr = strtok(NULL, " \n");
                    if (ptr != NULL) {
                        sim_init_params.psort_set_param.hole_min_size_factor = atoi(ptr);

                        SIM_PRINT("background_move_block_size: %" PRIu32 "\n",
                                  sim_init_params.psort_set_param.background_move_block_size);
                        SIM_PRINT("foreground_move_block_size: %" PRIu32 "\n",
                                  sim_init_params.psort_set_param.foreground_move_block_size);
                        SIM_PRINT("decrease_size_threshold: %" PRIu32 "\n",
                                  sim_init_params.psort_set_param.decrease_size_threshold);
                        SIM_PRINT("expand_at_empty_space_size: %" PRIu32 "\n",
                                  sim_init_params.psort_set_param.expand_at_empty_space_size);
                        SIM_PRINT("hole_min_size_factor: %" PRIu32 "\n",
                                  sim_init_params.psort_set_param.hole_min_size_factor);

                        /*status = psort_params_set(&handle, &sim_init_params);*/

                        goto out;
                    }
                }
            }
        }
    }

    status = SX_UTILS_STATUS_ERROR;
    SIM_LOG_ERR("invalid value in init: %s\n", line);
    goto out;

out:
    return status;
}

sx_utils_status_t resize_table_enlarge(uint32_t new_size)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    /* execute resize */
    if (SX_UTILS_CHECK_FAIL(status = psort_table_resize(handle, new_size, FALSE, NULL))) {
        SIM_LOG_ERR("failed to resize table: (%s)\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    /* validate that all data still there */
    if (SX_UTILS_CHECK_FAIL(status = __is_mirror_db_equals_psort_table(new_size))) {
        SIM_LOG_ERR("failed to resize table: (%s)\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    /* resize all buffers */
    SIM_ENLARGE_BUF_KEEP_DATA(bg_full_reorder_stats_arr, bg_full_reorder_stats_len, new_size, bg_full_reorder_stats_t);
    bg_full_reorder_stats_len = new_size;

    /* update mirror db */
    if (SX_UTILS_CHECK_FAIL(status = __sim_init_db(new_size))) {
        SIM_LOG_ERR("failed to resize table: (%s)\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    cur_table_size = new_size;
    is_steady = FALSE;

out:
    return status;
}

sx_utils_status_t resize_table_shrink(uint32_t new_size)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i = 0, valids = 0;
    boolean_t         ok_to_shrink = TRUE;

    for (i = 0; i < cur_table_size; i++) {
        if (sim_db[i].valid) {
            valids++;
        }
    }

    if (new_size < valids) {
        ok_to_shrink = FALSE;
    }

    /* execute resize */
    if (SX_UTILS_CHECK_FAIL(status = psort_table_resize(handle, new_size, FALSE, NULL))) {
        if ((SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE == status) && (FALSE == ok_to_shrink)) {
            /* That's OK */
            SIM_PRINT("failed to resize table as expected, new size too small: (%s)\n", SX_UTILS_STATUS_MSG(status));
            status = SX_UTILS_STATUS_SUCCESS;
        } else {
            SIM_LOG_ERR("failed to resize table: (%s)\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    }

    if (TRUE == ok_to_shrink) {
        cur_table_size = new_size;
    }

    /* validate that all data still there */
    if (SX_UTILS_CHECK_FAIL(status = __is_mirror_db_equals_psort_table(cur_table_size))) {
        SIM_LOG_ERR("failed to resize table: (%s)\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    if (TRUE == ok_to_shrink) {
        /* update mirror db */
        if (SX_UTILS_CHECK_FAIL(status = __sim_init_db(new_size))) {
            SIM_LOG_ERR("failed to resize table: (%s)\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
        is_steady = FALSE;
    }

out:
    return status;
}

sx_utils_status_t __handle_resize(char *line)
{
    char            * ptr = strchr(line, ' ');
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    uint32_t          new_size = 0;

    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in resize: %s\n", line);
        return status;
    }
    ptr++;

    SIM_PRINT("\n------------------------------------\n");
    SIM_PRINT("table resize: ");

    ptr = strtok(ptr, " \n");
    if (ptr != NULL) {
        new_size = atoi(ptr);
    } else {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in resize: %s\n", line);
        goto out;
    }

    SIM_PRINT("old size: %d new size: %d\n", cur_table_size, new_size);
    SIM_PRINT("------------------------------------\n\n");

    during_resize_operation = TRUE;

    if (new_size > cur_table_size) {
        /* Larger */
        if (SX_UTILS_CHECK_FAIL(status = resize_table_enlarge(new_size))) {
            SIM_LOG_ERR("failed to enlarge table: (%s)\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    } else {
        if (new_size < cur_table_size) {
            /* Smaller */
            if (SX_UTILS_CHECK_FAIL(status = resize_table_shrink(new_size))) {
                SIM_LOG_ERR("failed to shrink table: (%s)\n", SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        } else {
            /* Equal */
            /* execute resize */
            if (SX_UTILS_CHECK_FAIL(status = psort_table_resize(handle, new_size, FALSE, NULL))) {
                SIM_LOG_ERR("failed to resize table: (%s)\n", SX_UTILS_STATUS_MSG(status));
                goto out;
            }

            /* validate that all data still there */
            if (SX_UTILS_CHECK_FAIL(status = __is_mirror_db_equals_psort_table(new_size))) {
                SIM_LOG_ERR("failed to resize table: (%s)\n", SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        }
    }

    if (SX_UTILS_CHECK_FAIL(status = __check_constrains(TRUE))) {
        SIM_LOG_ERR("failed to check constrains: (%s)\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

out:
    during_resize_operation = FALSE;
    return status;
}

sx_utils_status_t __handle_rand_operation(char *line)
{
    char            * ptr = strchr(line, ' ');
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i = 0, num = 0;

    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in resize: %s\n", line);
        return status;
    }
    ptr++;


    ptr = strtok(ptr, " \n");
    if (ptr != NULL) {
        num = atoi(ptr);
    } else {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in num of entries: %s\n", line);
        return status;
    }

    SIM_PRINT("\n---------------------------------\n");
    SIM_PRINT("calling random operation (%d) times\n", num);
    SIM_PRINT("---------------------------------\n");
    for (i = 0; i < num; i++) {
        uint8_t operation = SIM_RAND(0, 1);
        if (operation == 0) {
            /* REMOVE */
            if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
                SIM_PRINT("rand operation: Removing 1 entry\n");
            }

            if (SX_UTILS_CHECK_FAIL(status = __rem_random_n_prio(1, FALSE, 0))) {
                SIM_LOG_ERR("failed to remove: (%s)\n", SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        } else {
            /* ADD */
            if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
                SIM_PRINT("rand operation: Adding 1 entry\n");
            }

            if (SX_UTILS_CHECK_FAIL(status = __add_random_n(1))) {
                SIM_LOG_ERR("failed to add: (%s)\n", SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        }
    }

out:
    return status;
}

sx_utils_status_t __handle_seed(char *line)
{
    char            * ptr = strchr(line, ' ');
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in seed: %s\n", line);
        return status;
    }
    ptr++;

    SIM_PRINT("set seed: ");

    ptr = strtok(ptr, " \n");
    if (ptr != NULL) {
        seed = atoi(ptr);
        srand(seed);
        SIM_PRINT("%d\n", seed);
        return status;
    }

    status = SX_UTILS_STATUS_ERROR;
    SIM_LOG_ERR("invalid value in seed: %s\n", line);
    return status;
}

sx_utils_status_t __handle_num_of_seeds(char *line)
{
    char            * ptr = strchr(line, ' ');
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in num of seeds: %s\n", line);
        return status;
    }
    ptr++;

    SIM_PRINT("num of seeds: ");

    ptr = strtok(ptr, " \n");
    if (ptr != NULL) {
        num_of_seeds = atoi(ptr);
        SIM_PRINT("%d\n", num_of_seeds);
        return status;
    }

    status = SX_UTILS_STATUS_ERROR;
    SIM_LOG_ERR("invalid value in num of seeds: %s\n", line);
    return status;
}

sx_utils_status_t __handle_num_of_prios(char *line)
{
    char            * ptr = strchr(line, ' ');
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in num of seeds: %s\n", line);
        return status;
    }
    ptr++;

    SIM_PRINT("num of seeds: ");

    ptr = strtok(ptr, " \n");
    if (ptr != NULL) {
        sim_init_params.num_of_prios = atoi(ptr);
        SIM_PRINT("%d\n", sim_init_params.num_of_prios);
        return status;
    } else {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in num of prios: %s\n", line);
        return status;
    }
}

sx_utils_status_t __handle_insertion_delay(char *line)
{
    char            * ptr = strchr(line, ' ');
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in insertion/removal delay: %s\n", line);
        return status;
    }
    ptr++;

    SIM_PRINT("set insertion/removal delay: ");

    ptr = strtok(ptr, " \n");
    if (ptr != NULL) {
        delay_insert_remove = atoi(ptr);
        SIM_PRINT("%d\n", delay_insert_remove);
        return status;
    }

    status = SX_UTILS_STATUS_ERROR;
    SIM_LOG_ERR("invalid value in insertion/removal delay: %s\n", line);
    return status;
}

sx_utils_status_t __handle_add(char *line)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    char            * ptr = strchr(line, ' ');
    char            * cmd;
    int               num1 = 0, num2 = 0;

    is_steady = FALSE;

    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in add: %s\n", line);
        return status;
    }
    ptr++;

    cmd = strtok(ptr, " \n");

    if (cmd != NULL) {
        ptr = strtok(NULL, " \n");
        if (ptr != NULL) {
            num1 = atoi(ptr);

            ptr = strtok(NULL, " \n");
            if (ptr != NULL) {
                num2 = atoi(ptr);
            }
        }

        SIM_PRINT("--------------------------\n");
        SIM_PRINT("calling add (%s):\n", cmd);
        SIM_PRINT("--------------------------\n");

        if (IS_STR_EQUAL(cmd, SIM_STR_FIXED)) {
            SIM_PRINT("%s value: %d, prio: %d\n\n", cmd, num1, num2);

            return __add_entry(num1, num2);
        } else if (IS_STR_EQUAL(cmd, SIM_STR_RAND)) {
            SIM_PRINT("%s amount: %d\n\n", cmd, num1);

            return __add_random_n(num1);
        } else if (IS_STR_EQUAL(cmd, SIM_STR_RAND_VAL_FIXED_PRIO)) {
            SIM_PRINT("%s amount: %d, prio: %d\n\n", cmd, num1, num2);

            return __add_random_n_prio(num1, num2);
        } else if (IS_STR_EQUAL(cmd, SIM_STR_RAND_BLOCK)) {
            SIM_PRINT("%s num_prio: %d, num_per_prio: %d\n\n", cmd, num1, num2);

            return __add_block(num1, num2);
        } else {
            status = SX_UTILS_STATUS_ERROR;
            SIM_LOG_ERR("invalid value in add: %s\n", line);
            return status;
        }
    }
    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t __handle_rem(char *line)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    char            * ptr = strchr(line, ' ');
    char            * cmd;
    int               num = 0, prio = 0;

    is_steady = FALSE;

    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in remove: %s\n", line);
        return status;
    }
    ptr++;

    cmd = strtok(ptr, " \n");

    SIM_PRINT("--------------------------\n");
    SIM_PRINT("calling remove: \n");
    SIM_PRINT("--------------------------\n");

    if (cmd != NULL) {
        ptr = strtok(NULL, " \n");
        if (ptr != NULL) {
            num = atoi(ptr);

            ptr = strtok(NULL, " \n");
            if (ptr != NULL) {
                prio = atoi(ptr);
            }
        }

        if (IS_STR_EQUAL(cmd, SIM_STR_FIXED)) {
            SIM_PRINT("%s value: %d, prio: %d\n", cmd, num, prio);

            return __rem_specific_entry(num, prio);
        } else if (IS_STR_EQUAL(cmd, SIM_STR_RAND)) {
            SIM_PRINT("%s amount: %d\n", cmd, num);

            return __rem_random_n_prio(num, FALSE, 0);
        } else if (IS_STR_EQUAL(cmd, SIM_STR_RAND_VAL_FIXED_PRIO)) {
            SIM_PRINT("%s amount: %d, prio: %d\n", cmd, num, prio);

            return __rem_random_n_prio(num, TRUE, prio);
        } else {
            status = SX_UTILS_STATUS_ERROR;
            SIM_LOG_ERR("invalid value in remove: %s\n", line);
            return status;
        }
    }
    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t __wait_for_steady_state(void)
{
    sx_utils_status_t  status = SX_UTILS_STATUS_SUCCESS;
    psort_info_stats_t info;

    memset(&info, 0, sizeof(psort_info_stats_t));

    if (timer == 0) {
        status = SX_UTILS_STATUS_PARAM_ERROR;
        SIM_LOG_ERR("error: cannot wait for steady state (timer thread not activated) (%s)\n",
                    SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    while (FALSE == is_steady) {
        SIM_PRINT(
            "\n\n##################################\nwaiting for steady state\n##################################\n\n");
        usleep(1000000);
    }

out:
    SIM_PRINT("** in steady state **\n");
    return status;
}

sx_utils_status_t __handle_reorder(char *line)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    char            * ptr = strchr(line, ' ');
    char            * cmd;
    int               num = 0;

    if (ptr == NULL) {
        status = SX_UTILS_STATUS_CMD_UNSUPPORTED;
        SIM_LOG_ERR("invalid value in reorder: %s (%s)\n", line, SX_UTILS_STATUS_MSG(status));
        goto out;
    }
    ptr++;
    cmd = strtok(ptr, " \n");

    if (timer > 0) {
        status = SX_UTILS_STATUS_PARAM_ERROR;
        SIM_LOG_ERR("cannot manually reorder (timer thread activated) %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    } else {
        SIM_PRINT("--------------------------\n");
        SIM_PRINT("calling reorder: \n");
        SIM_PRINT("--------------------------\n");

        if (cmd != NULL) {
            ptr = strtok(NULL, " \n");

            if (IS_STR_EQUAL(cmd, SIM_STR_N_CYCLES)) {
                if (ptr != NULL) {
                    num = atoi(ptr);
                }

                SIM_PRINT("%s num: %d\n", cmd, num);

                status = __reorder_n(FALSE, num, FALSE, NULL);
                goto out;
            } else if (IS_STR_EQUAL(cmd, SIM_STR_FULL)) {
                SIM_PRINT("%s (tag: %s)\n", cmd, ptr);

                status = __reorder_n(TRUE, 0, FALSE, ptr);
                goto out;
            } else if (IS_STR_EQUAL(cmd, SIM_STR_WITH_CHECK)) {
                SIM_PRINT("%s (tag: %s)\n", cmd, ptr);

                status = __reorder_n(TRUE, 0, TRUE, ptr);
                goto out;
            } else {
                status = SX_UTILS_STATUS_CMD_UNSUPPORTED;
                SIM_LOG_ERR("invalid value in reorder: %s (%s)\n", line, SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        }
    }
out:
    return status;
}

sx_utils_status_t __check_constrains(bool should_lock)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    psort_info_stats_t  info;
    psort_entry_info_t *entries_p = NULL;
    uint32_t            num_entries = cur_table_size;
    uint32_t            i = 0, res_i = 0, db_i = 0;
    uint32_t            region_size = 0, valid_cnt = 0;
    uint32_t            total_regions = 0;
    uint16_t            cur_hole_size = 0;
    uint16_t            num_holes = 0;
    uint16_t            min_hole_size = 0xFFFF;
    uint16_t            total_holes_size = 0;

    /*float hole_optimal_size = 0;*/

    if (should_lock) {
        pthread_mutex_lock(&psort_mutex);
    }

    SIM_PRINT("\n\n--------------------------\n");
    SIM_PRINT("checking constrains\n");
    SIM_PRINT("--------------------------\n\n");

    /* allocate memory for dump */
    SIM_CLR_MEMORY_GET(entries_p, num_entries, psort_entry_info_t);

    /* dump db */
    status = psort_dump_table(handle, entries_p, &num_entries);
    if (SX_UTILS_CHECK_FAIL(status)) {
        SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    /* count num of regions */
    total_regions = 1; /*for the first region*/
    for (i = 1; i < num_entries; i++) {
        if (entries_p[i].entry.priority < entries_p[i - 1].entry.priority) {
            total_regions++;
        }
    }

    if (SX_UTILS_CHECK_FAIL(status = psort_info_stats_get(handle, &info))) {
        SIM_LOG_ERR("Failed to get info stats %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    if (total_regions != info.num_of_regions) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("info.num_of_regions=%d, but actual num of regions is %d (%s)\n",
                    info.num_of_regions, total_regions, SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    /* dump should be equal to sim db */
    if ((entries_p[0].valid != sim_db[0].valid) &&
        (entries_p[0].entry.key != sim_db[0].key) &&
        (entries_p[0].entry.index != 0) &&
        (entries_p[0].entry.priority != sim_db[0].priority)) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("check constrains failed %s\n", SX_UTILS_STATUS_MSG(status));
        __print_all_tables();
        goto out;
    }

    db_i = 1;
    valid_cnt = (entries_p[0].valid) ? 1 : 0;
    region_size = 1;
    for (i = 1; i < num_entries; i++) {
        res_i = entries_p[i].entry.index;

        if (entries_p[i].entry.priority < entries_p[i - 1].entry.priority) {
            /* it's a new region */
            /* update hole counters */
            cur_hole_size = entries_p[i].entry.index - entries_p[i - 1].entry.index - 1;
            total_holes_size = total_holes_size + cur_hole_size;
            min_hole_size = MIN(min_hole_size, cur_hole_size);
            num_holes++;

            while (db_i < res_i) {
                /* it's a hole (?) make sure no valid entries in it */
                if (1 == sim_db[db_i].valid) {
                    __print_all_tables();
                    status = SX_UTILS_STATUS_ERROR;
                    SIM_LOG_ERR("check constrains failed - showed hole in %d, but actually has value (%s)\n",
                                db_i, SX_UTILS_STATUS_MSG(status));
                    goto out;
                }
                db_i++;
            }

            if (TRUE == is_steady) {
                /* no empty regions (except for first and last */
                if ((0 == valid_cnt) && (entries_p[i - 1].entry.priority != param.max_priority)) {
                    status = SX_UTILS_STATUS_ERROR;
                    SIM_LOG_ERR("check constrains failed (prio %d is empty) (%s)\n",
                                entries_p[i - 1].entry.priority, SX_UTILS_STATUS_MSG(status));
                    goto out;
                }

                /* should not have empty size larger than factor*delta */
                if ((region_size - valid_cnt) > factor * cur_delta) {
                    status = SX_UTILS_STATUS_ERROR;
                    SIM_LOG_ERR(
                        "check constrains failed (should not have region empty space larger than factor*delta) index %d %s\n",
                        entries_p[i].entry.index,
                        SX_UTILS_STATUS_MSG(status));
                    goto out;
                }
            }

            /* reset counters */
            region_size = 0;
            valid_cnt = 0;
        }

        region_size++;
        valid_cnt += (entries_p[i].valid) ? 1 : 0;

        /* validate increasing indexes */
        if (entries_p[i].entry.index <= entries_p[i - 1].entry.index) {
            status = SX_UTILS_STATUS_ERROR;
            SIM_LOG_ERR("check constrains failed - index %d is not increasing (%s)\n",
                        i, SX_UTILS_STATUS_MSG(status));
            goto out;
        }

        /* validate priorities are decreasing */
        if (entries_p[i].entry.priority > entries_p[i - 1].entry.priority) {
            status = SX_UTILS_STATUS_ERROR;
            SIM_LOG_ERR("check constrains failed - index %d priority is not decreasing (%s)\n",
                        i, SX_UTILS_STATUS_MSG(status));
            goto out;
        }

        /* compare db's */
        if (sim_db[res_i].valid || entries_p[i].valid) {
            if ((sim_db[res_i].priority != entries_p[i].entry.priority) ||
                (sim_db[res_i].key != entries_p[i].entry.key) ||
                (sim_db[res_i].valid != entries_p[i].valid)) {
                status = SX_UTILS_STATUS_ERROR;
                __dbg_print();
                SIM_LOG_ERR("error sim_db: p=%" PRIu32 " k=%" PRIu64 " v=%d index=%d\n"
                            "   entries_p: p=%" PRIu32 " k=%" PRIu64 " v=%d index=%" PRIu32 " %s\n",
                            sim_db[res_i].priority,
                            sim_db[res_i].key,
                            sim_db[res_i].valid,
                            res_i,
                            entries_p[i].entry.priority,
                            entries_p[i].entry.key,
                            entries_p[i].valid,
                            entries_p[i].entry.index,
                            SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        }

        db_i++;
    }

    /* validations for steady state */
    if (TRUE == is_steady) {
        if (sim_init_params.psort_set_param.hole_min_size_factor * cur_delta * num_holes <= total_holes_size) {
            if (min_hole_size < sim_init_params.psort_set_param.hole_min_size_factor * cur_delta) {
                status = SX_UTILS_STATUS_ERROR;
                SIM_LOG_ERR(
                    "check constrains failed - there's enough free space, but there is a hole smaller than factor*delta (%s)\n",
                    SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        }

        /* check for the last region */
        /* should not have empty size larger than factor*delta */
        if ((region_size - valid_cnt) > factor * cur_delta) {
            status = SX_UTILS_STATUS_ERROR;
            SIM_LOG_ERR("check constrains failed (should not have region empty space larger than factor*delta) %s\n",
                        SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    }

out:
    SIM_MEMORY_PUT(entries_p);

    if (should_lock) {
        pthread_mutex_unlock(&psort_mutex);
    }
    return status;
}

sx_utils_status_t __handle_timer_thread(char* line)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    char            * ptr = NULL;
    int               num = 0;

    if (bg_tcam_ratio > 0) {
        SIM_PRINT("timer is ignored because background worker to tcam writes ratio was configured\n");
        return status;
    }

    if (TRUE == already_read_timer_thread) {
        SIM_PRINT("timer: %d us\n", timer);
        return SX_UTILS_STATUS_SUCCESS;
    }

    ptr = strchr(line, ' ');
    if (ptr == NULL) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in timer: %s\n", line);
        return status;
    }
    ptr++;

    already_read_timer_thread = TRUE;

    SIM_PRINT("timer: ");

    ptr = strtok(ptr, " \n");

    if (ptr != NULL) {
        num = atoi(ptr);

        timer = num;
    } else {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("invalid value in timer: %s\n", line);
        return status;
    }

    return status;
}

/**
 *
 * PSORT LIB WRAPPERS
 *
 */

sx_utils_status_t psort_entry_set_wrapper(const psort_handle_t handle, psort_entry_t     *entry_p)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i = 0, tcam_foreground_count_before = tcam_foreground_count;
    struct timeval    time1, time2, res_time;

    pthread_mutex_lock(&psort_mutex);

    if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
        SIM_PRINT("psort entryset %" PRIu64 " %d %" PRIu32 " %" PRIu64 " 0\n",
                  handle,
                  SX_UTILS_CMD_ADD,
                  entry_p->priority,
                  entry_p->key);
    }

    fprintf(command_log,
            "psort entryset %" PRIu64 " %d %" PRIu32 " %" PRIu64 " 0\n",
            handle,
            SX_UTILS_CMD_ADD,
            entry_p->priority,
            entry_p->key);

    during_add_operation = TRUE;

    gettimeofday(&time1, NULL);

    status = psort_entry_set(handle, SX_UTILS_CMD_ADD, entry_p);
    gettimeofday(&time2, NULL);

    tcam_foreground_count++;

    during_add_operation = FALSE;

    if (SX_UTILS_CHECK_FAIL(status)) {
        SIM_LOG_ERR("failed to add key: %" PRIu64 ", prio: %" PRIu32 " %s\n",
                    entry_p->key,
                    entry_p->priority,
                    SX_UTILS_STATUS_MSG(status));
        if (SX_UTILS_STATUS_NO_RESOURCES == status) {
            for (i = 0; i < cur_table_size; i++) {
                if (FALSE == sim_db[i].valid) {
                    status = SX_UTILS_STATUS_ERROR;
                    SIM_LOG_ERR("got NO_RESOURCES but there's free spot in %" PRIu32 "! %s\n", i,
                                SX_UTILS_STATUS_MSG(status));
                    goto out;
                }
            }
            status = SX_UTILS_STATUS_SUCCESS;
            SIM_PRINT("validated table is really full, continuing...\n");
            goto out;
        }
        goto out;
    }
    __time_sub(&time2, &time1, &res_time);
    __time_sum(&res_time, &p_sim_run_seed_info[seed_counter].total_add_time);
    status = __validate_add_constrains(entry_p, 1);
    if (SX_UTILS_CHECK_FAIL(status)) {
        SIM_LOG_ERR("failed validating init constrains %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

out:
    pthread_mutex_unlock(&psort_mutex);

    /* must be after releasing the mutex */
    if (status == SX_UTILS_STATUS_SUCCESS) {
        if (bg_tcam_ratio > 0) {
            if (SX_UTILS_CHECK_FAIL(status =
                                        reorder_according_to_background_tcam_ratio(tcam_foreground_count_before))) {
                return status;
            }
        }
    }

    if (delay_insert_remove != 0) {
        usleep(delay_insert_remove);
    }
    return status;
}

sx_utils_status_t __psort_init_wrapper(psort_handle_t *handle_p, const psort_init_param_t *params_p)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    SIM_PRINT("\npsort init %d %d %d %d %d %d\n",
              params_p->table_size, params_p->delta_size, params_p->max_priority, params_p->min_priority,
              params_p->table_almost_full_precentage_threshold,
              params_p->table_almost_empty_precentage_threshold);

    status = psort_init(handle_p, params_p);
    if (SX_UTILS_CHECK_FAIL(status)) {
        SIM_LOG_ERR("failed to init %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    is_initialized = TRUE;
    SIM_PRINT("\nPSORT TABLE INITIALIZE - SUCCESS\n");

    if (bg_full_reorder_stats_arr == NULL) {
        /* bg_full_reorder_stats_arr wasn't initialized yet */
        bg_full_reorder_stats_len = sim_init_params.table_size;
        SIM_CLR_MEMORY_GET(bg_full_reorder_stats_arr, bg_full_reorder_stats_len, bg_full_reorder_stats_t);
    }
    memset(bg_full_reorder_stats_arr, 0, sizeof(bg_full_reorder_stats_t) * bg_full_reorder_stats_len);

    if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
        status = __validate_init_constrains(params_p);
        if (SX_UTILS_CHECK_FAIL(status)) {
            SIM_LOG_ERR("failed validating init constrains %s\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    }

    total_num = 0;

    if (SX_UTILS_CHECK_FAIL(status = __sim_init_db(sim_init_params.table_size))) {
        SIM_LOG_ERR("failed db init %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    if ((timer > 0) && (is_timer_thread_started == FALSE)) {
        pthread_create(&timer_thread, NULL, (void*)set_timer_thread, NULL);
    }

out:
    return status;
}

sx_utils_status_t __sim_init_db(uint32_t table_size)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_info_t *entries_p = NULL;
    uint32_t            num_entries = table_size;
    uint32_t            i = 0;


    SIM_CLR_MEMORY_GET(entries_p, num_entries, psort_entry_info_t);

    /* dump db */
    if (SX_UTILS_CHECK_FAIL(status = psort_dump_table(handle, entries_p, &num_entries))) {
        SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    SIM_RESIZE_BUF(sim_db, table_size, sim_entry_t);


    for (i = 0; i < num_entries; i++) {
        sim_db[entries_p[i].entry.index].priority = entries_p[i].entry.priority;
        sim_db[entries_p[i].entry.index].key = entries_p[i].entry.key;
        sim_db[entries_p[i].entry.index].valid = entries_p[i].valid;
    }

out:
    SIM_MEMORY_PUT(entries_p);
    return status;
}

sx_utils_status_t __is_mirror_db_equals_psort_table(uint32_t table_size)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_info_t *entries_p = NULL;
    uint32_t            num_entries = table_size;
    uint32_t            i = 0, j = 0;
    uint8_t             cont = 0;
    uint32_t            sim_db_valids = 0, psort_db_valids = 0;


    SIM_CLR_MEMORY_GET(entries_p, num_entries, psort_entry_info_t);

    /* dump db */
    if (SX_UTILS_CHECK_FAIL(status = psort_dump_table(handle, entries_p, &num_entries))) {
        SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    i = 0;
    j = 0;
    while (1) {
        cont = 0;

        if ((i == cur_table_size) && (j != num_entries)) {
            for (; j < num_entries; j++) {
                if (entries_p[j].valid) {
                    status = SX_UTILS_STATUS_ERROR;
                    SIM_LOG_ERR("*****\ntables not equal sizes i=%u j=%u %s\n*****\n", i, j, SX_UTILS_STATUS_MSG(
                                    status));
                    goto out;
                }
            }
            SIM_PRINT("*****\nequal tables i=%u j=%u %s\n*****\n", i, j, SX_UTILS_STATUS_MSG(status));
            goto out;
        } else if ((i != cur_table_size) && (j == num_entries)) {
            for (; i < cur_table_size; i++) {
                if (sim_db[i].valid) {
                    status = SX_UTILS_STATUS_ERROR;
                    SIM_LOG_ERR("tables not equal sizes i=%u j=%u %s\n", i, j, SX_UTILS_STATUS_MSG(status));
                    goto out;
                }
            }
            SIM_PRINT("*****\nequal tables i=%u j=%u %s\n*****\n", i, j, SX_UTILS_STATUS_MSG(status));
            break;
        } else if ((i == cur_table_size) && (j == num_entries)) {
            SIM_PRINT("*****\nequal tables i=%u j=%u %s\n*****\n", i, j, SX_UTILS_STATUS_MSG(status));
            goto out;
        }
        if (!sim_db[i].valid) {
            i++;
            cont = 1;
        }
        if (!entries_p[j].valid) {
            j++;
            cont = 1;
        }
        if (cont) {
            continue;
        } else {
            if ((sim_db[i].priority != entries_p[j].entry.priority) ||
                (sim_db[i].key != entries_p[j].entry.key)) {
                status = SX_UTILS_STATUS_ERROR;
                SIM_LOG_ERR("tables not equal i=%u j=%u %s\n", i, j, SX_UTILS_STATUS_MSG(status));
                goto out;
            }
            i++;
            j++;
        }
    }

    /* check that amount of valid entries is equal */
    for (i = 0; i < cur_table_size; i++) {
        if (sim_db[i].valid) {
            sim_db_valids++;
        }
    }

    for (j = 0; j < num_entries; j++) {
        if (entries_p[j].valid) {
            psort_db_valids++;
        }
    }

    if (sim_db_valids != psort_db_valids) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("in sim db (%u) valid entries, but in psort table (%u) valid entries %s\n",
                    sim_db_valids,
                    psort_db_valids,
                    SX_UTILS_STATUS_MSG(status));
        goto out;
    }

out:
    SIM_MEMORY_PUT(entries_p);
    return status;
}

/**
 *
 *
 * FUNCTIONS
 *
 *
 */

sx_utils_status_t set_delta(uint16_t val)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    cur_delta = val;

    return status;
}

void * set_timer_thread(void)
{
    is_timer_thread_started = TRUE;

    while (!program_ended) {
        usleep(timer);
        if (is_initialized) {
            SIM_PRINT("\n--------------------------\ncalling reorder: \n--------------------------\n\n");
            __reorder_n(FALSE, 1, FALSE, NULL);
        }
    }
    pthread_exit((void*)&timer);

    return SX_UTILS_STATUS_SUCCESS;
}

void update_stats_array(struct timeval *duration_p)
{
    int index = total_num - 1;

    if (index && (FALSE == bg_full_reorder_stats_arr[index].valid)) {
        bg_full_reorder_stats_arr[index].valid = 1;
        bg_full_reorder_stats_arr[index].min_shift_count = 0xFFFF;
        bg_full_reorder_stats_arr[index].min_shift_time.tv_sec = 0xFFFF;
    }

    __time_sum(duration_p, &(bg_full_reorder_stats_arr[index].total_shift_time));
}

sx_utils_status_t __call_bg_and_update_status(bool is_reordering_full)
{
    sx_utils_status_t  status = SX_UTILS_STATUS_SUCCESS;
    psort_info_stats_t info;
    struct timeval     duration, time1, time2;
    boolean_t          is_complete = FALSE;

    memset(&info, 0, sizeof(psort_info_stats_t));
    memset(&duration, 0, sizeof(struct timeval));

    if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
        SIM_PRINT("psort backgroundworker\n");
    }

    gettimeofday(&time1, NULL);
    status = psort_background_worker(handle, &is_complete);
    gettimeofday(&time2, NULL);

    background_worker_count++;

    fprintf(command_log, "psort backgroundworker %" PRIu64 "\n", handle);


    if (SX_UTILS_CHECK_FAIL(status)) {
        SIM_LOG_ERR("failed to run psort backgroud worker %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    if (SX_UTILS_CHECK_FAIL(status = psort_info_stats_get(handle, &info))) {
        SIM_LOG_ERR("failed to get psort info stats %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    new_num_shifts = info.num_of_shifts;
    /* steady state taken from psort_background_worker function */
    is_steady = is_complete;

    /* steady state taken by checking if no shifts has occured */
    /*is_steady = (new_num_shifts == old_num_shifts) ? TRUE : FALSE;*/

    __time_sub(&time2, &time1, &duration);
    __time_sum(&duration, &p_sim_run_seed_info[seed_counter].total_bg_time);

    if (is_reordering_full) {
        update_stats_array(&duration);
    }

    old_num_shifts = new_num_shifts;

out:
    return status;
}

sx_utils_status_t __add_entry(uint32_t key, int prio)
{
    psort_entry_t     entry;
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    memset(&entry, 0, sizeof(psort_entry_t));

    entry.key = key;
    entry.priority = prio;

    status = psort_entry_set_wrapper(handle, &entry);
    if (SX_UTILS_CHECK_FAIL(status)) {
        SIM_LOG_ERR("failed to add key: %d, prio: %d %s\n", key, prio, SX_UTILS_STATUS_MSG(status));
        goto out;
    }

out:
    return status;
}

sx_utils_status_t __sim_notf_cb(psort_notification_type_e notif_type, void* data, void* cookie)
{
    psort_shift_param_t *shift;
    sx_utils_status_t    status = SX_UTILS_STATUS_SUCCESS;
    float                capacity = 0;
    sim_entry_t         *tmp_buff = NULL;

    UNUSED_PARAM(cookie);

    switch (notif_type) {
    case PSORT_TABLE_ALMOST_FULL_E:
        SIM_PRINT("*************************************\n")
        SIM_PRINT("got event! (PSORT_TABLE_ALMOST_FULL_E)\n");
        SIM_PRINT("*************************************\n")

        /* check table almost full */
        capacity = __percentage_full();

        if (capacity < param.table_almost_full_precentage_threshold) {
            status = SX_UTILS_STATUS_ERROR;
            SIM_LOG_ERR("event error: got false ALMOST_FULL event. %%capacity: %f, %%threshold: %d\n",
                        capacity, param.table_almost_full_precentage_threshold);
        }

        break;

    case PSORT_TABLE_ALMOST_EMPTY_E:
        SIM_PRINT("*************************************\n")
        SIM_PRINT("got event! (PSORT_TABLE_ALMOST_EMPTY_E)\n");
        SIM_PRINT("*************************************\n")

        /* check table almost empty */
        capacity = __percentage_full();
        if (capacity > param.table_almost_empty_precentage_threshold) {
            status = SX_UTILS_STATUS_ERROR;
            SIM_LOG_ERR("event error: got false ALMOST_EMPTY event. %%capacity: %f, %%threshold: %d\n",
                        capacity, param.table_almost_empty_precentage_threshold);
        }

        break;

    case PSORT_TABLE_SHIFT_E:
        shift = (psort_shift_param_t*)data;

        if (TRUE == during_resize_operation) {
            SIM_PRINT("*************************************\n")
            SIM_PRINT("got event! (PSORT_TABLE_SHIFT_E during resize, new index: %u, old index: %u, size: %u)\n",
                      shift->new_index, shift->old_index, shift->size);
            SIM_PRINT("*************************************\n");
            p_sim_run_seed_info[seed_counter].foreground_shifts++;
            tcam_foreground_count = tcam_foreground_count + shift->size;
        } else if (TRUE == during_add_operation) {
            p_sim_run_seed_info[seed_counter].foreground_shifts++;
            tcam_foreground_count = tcam_foreground_count + shift->size;

            if (g_is_first_shift == TRUE) {
                SIM_PRINT("*************************************\n")
                SIM_PRINT("got event! (PSORT_TABLE_SHIFT_E during ADD, new index: %u, old index: %u, size: %u)\n",
                          shift->new_index, shift->old_index, shift->size);
                SIM_PRINT("*************************************\n");
                /* print table before shift */
                __dbg_print();
                g_is_first_shift = FALSE;
            }
            if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
                SIM_PRINT("*************************************\n")
                SIM_PRINT("got event! (PSORT_TABLE_SHIFT_E during ADD, new index: %u, old index: %u, size: %u)\n",
                          shift->new_index, shift->old_index, shift->size);
                SIM_PRINT("*************************************\n");
            }
        } else {
            if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
                SIM_PRINT("*************************************\n")
                SIM_PRINT("got event! (PSORT_TABLE_SHIFT_E from background, new index: %u, old index: %u, size: %u)\n",
                          shift->new_index, shift->old_index, shift->size);
                SIM_PRINT("*************************************\n");
            }
        }

        SIM_CLR_MEMORY_GET(tmp_buff, shift->size, sim_entry_t);
        memcpy(tmp_buff, &sim_db[shift->old_index], shift->size * sizeof(sim_entry_t));
        memset(&sim_db[shift->old_index], 0, shift->size * sizeof(sim_entry_t));
        memcpy(&sim_db[shift->new_index], tmp_buff, shift->size * sizeof(sim_entry_t));

        break;

    default:
        status = SX_UTILS_STATUS_CMD_UNSUPPORTED;
        SIM_PRINT("unsupported notification type: %d\n", notif_type);
        goto out;
    }

out:
    SIM_MEMORY_PUT(tmp_buff);
    return status;
}

sx_utils_status_t __add_random_n(uint16_t amount)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_t     entry;
    uint16_t          i = 0;

    memset(&entry, 0, sizeof(psort_entry_t));

    for (i = 0; i < amount; i++) {
        /* generate random keys, */
        entry.key = rand() % SIM_MAX_VAL;

        /* set random priorities */
        if (sim_init_params.num_of_prios > 0) {
            /* we have array of random prios to use */
            entry.priority = SIM_GET_RAND_PRIO_FROM_PRIO_ARR;
        } else {
            /* we don't have array of random prios, simply randomize priorities */
            entry.priority = SIM_RAND(param.min_priority, param.max_priority);
        }
        if (SX_UTILS_CHECK_FAIL(status = psort_entry_set_wrapper(handle, &entry))) {
            SIM_LOG_ERR("Failed to add (%s)\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    }

out:
    return status;
}

sx_utils_status_t __add_random_n_prio(uint16_t amount, int prio)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_t     entry;
    uint16_t          i = 0;

    memset(&entry, 0, sizeof(psort_entry_t));

    /* generate random entries */
    for (i = 0; i < amount; i++) {
        entry.key = rand() % SIM_MAX_VAL;
        entry.priority = prio;

        if (SX_UTILS_CHECK_FAIL(status = psort_entry_set_wrapper(handle, &entry))) {
            SIM_LOG_ERR("Failed to add (%s)\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    }

out:
    return status;
}

sx_utils_status_t __generate_rand_prio_arr(uint32_t min_prio, uint32_t max_prio)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i = 0, j = 0;
    uint32_t          length = max_prio - min_prio + 1;
    uint32_t         *all_prios_arr = NULL;

    SIM_CLR_MEMORY_GET(prios_arr, length, uint32_t);
    SIM_CLR_MEMORY_GET(all_prios_arr, length, uint32_t);

    for (i = 0; i < length; i++) {
        all_prios_arr[i] = min_prio + i;
    }

    prios_arr[0] = all_prios_arr[0];
    for (i = 0; i < length; i++) {
        j = SIM_RAND(0, i);
        if (j != i) {
            prios_arr[i] = prios_arr[j];
        }
        prios_arr[j] = all_prios_arr[i];
    }

    SIM_PRINT("generated following prios: {");
    for (i = 0; i < sim_init_params.num_of_prios; i++) {
        SIM_PRINT(" %d", prios_arr[i]);
    }
    SIM_PRINT(" }\n");

out:
    SIM_MEMORY_PUT(all_prios_arr);
    return status;
}

sx_utils_status_t __add_block(uint16_t num_prio, uint16_t num_per_prio)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    uint32_t         *is_prios_full = NULL;
    uint32_t         *count = NULL;
    uint32_t          val = 0, i = 0, j = 0, total_entries = num_prio * num_per_prio;
    bool              found_vacant_prio = FALSE;

    SIM_CLR_MEMORY_GET(count, num_prio, uint32_t);
    SIM_CLR_MEMORY_GET(is_prios_full, num_prio, uint32_t);

    /* add random values */
    for (i = 0; i < total_entries; i++) {
        found_vacant_prio = FALSE;
        do {
            j = rand() % num_prio; /* generate random index of priority */
            if (count[j] < num_per_prio) { /* make sure generated index prio is not full*/
                found_vacant_prio = TRUE;
            } else {
                /* prio j is full */
                if (is_prios_full[j] == 0) {
                    SIM_PRINT("*************************************\n")

                    SIM_PRINT("prio [%d] is full\n", prios_arr[j]);

                    __dbg_print();
                    SIM_PRINT("*************************************\n");
                    is_prios_full[j] = 1;
                }
            }
        } while (!found_vacant_prio);

        val = rand() % SIM_MAX_VAL; /* generate random value */

        if (SX_UTILS_CHECK_FAIL(status = __add_entry(val, prios_arr[j]))) {
            SIM_LOG_ERR("Failed to add %s\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }

        count[j]++;
    }

out:
    SIM_MEMORY_PUT(count);
    SIM_MEMORY_PUT(is_prios_full);

    return status;
}

sx_utils_status_t __rem_specific_entry(uint32_t key, int prio)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_info_t  entry_info;
    uint32_t            tcam_foreground_count_before = tcam_foreground_count;
    psort_entry_info_t *entries_p = NULL;
    uint32_t            num_entries = cur_table_size;

    pthread_mutex_lock(&psort_mutex);

    SIM_CLR_MEMORY_GET(entries_p, num_entries, psort_entry_info_t);

    /* dump db */
    if (SX_UTILS_CHECK_FAIL(status = psort_dump_table(handle, entries_p, &num_entries))) {
        SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    /* find the entry */
    entry_info.entry.key = key;
    entry_info.entry.priority = prio;
    if (SX_UTILS_CHECK_FAIL(status = __get_entry_by_key_prio(&entry_info, entries_p, num_entries))) {
        SIM_LOG_ERR("Failed to find entry index %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    if (FALSE == entry_info.valid) {
        status = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SIM_LOG_ERR("Entry was already deleted before %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
        SIM_PRINT("psort entryset %" PRIu64 " %d %" PRIu32 " %" PRIu64 " %" PRIu32 "\n", handle, SX_UTILS_CMD_DELETE,
                  entry_info.entry.priority, entry_info.entry.key, entry_info.entry.index);
    }

    fprintf(command_log,
            "psort entryset %" PRIu64 " %d %" PRIu32 " %" PRIu64 " %" PRIu32 "\n",
            handle,
            SX_UTILS_CMD_DELETE,
            entry_info.entry.priority,
            entry_info.entry.key,
            entry_info.entry.index);

    if (SX_UTILS_CHECK_FAIL(status = psort_entry_set(handle, SX_UTILS_CMD_DELETE, &(entry_info.entry)))) {
        SIM_LOG_ERR("Failed to remove entry %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }
    tcam_foreground_count++;

    if (delay_insert_remove != 0) {
        usleep(delay_insert_remove);
    }

    if (SX_UTILS_CHECK_FAIL(status = __validate_rem_constrains(&(entry_info.entry), 1))) {
        SX_LOG_ERR("Failed to validate after remvoe %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

out:
    SIM_MEMORY_PUT(entries_p);

    pthread_mutex_unlock(&psort_mutex);

    /* must be after releasing the mutex */
    if (status == SX_UTILS_STATUS_SUCCESS) {
        if (bg_tcam_ratio > 0) {
            if (SX_UTILS_CHECK_FAIL(status =
                                        reorder_according_to_background_tcam_ratio(tcam_foreground_count_before))) {
                return status;
            }
        }
    }

    return status;
}


sx_utils_status_t __validate_rem_constrains(psort_entry_t *entries_p, uint16_t num_to_del)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_info_t  entry_info;
    uint32_t            i = 0;
    psort_entry_info_t *dump_entries_p = NULL;
    uint32_t            num_entries = cur_table_size;

    SIM_CLR_MEMORY_GET(dump_entries_p, num_entries, psort_entry_info_t);

    /* dump db */
    if (SX_UTILS_CHECK_FAIL(status = psort_dump_table(handle, dump_entries_p, &num_entries))) {
        SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    for (i = 0; i < num_to_del; i++) {
        /* update db */
        sim_db[entries_p[i].index].valid = FALSE;
        sim_db[entries_p[i].index].key = 0;
        total_num--;

        if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
            /* validate - valid bit is turned off */
            entry_info.entry.priority = entries_p[i].priority;
            entry_info.entry.key = entries_p[i].key;

            if (SX_UTILS_CHECK_FAIL(status = __get_entry_by_key_prio(&entry_info, dump_entries_p, num_entries))) {
                SIM_LOG_ERR("Failed to find entry index (key: %" PRIu64 " prio: %" PRIu32 ") %s\n",
                            entries_p[i].key, entries_p[i].priority, SX_UTILS_STATUS_MSG(status));
                goto out;
            }

            if (entry_info.valid == 1) {
                status = SX_UTILS_STATUS_ERROR;
                SIM_LOG_ERR("REMOVE error: valid bit is incorrect %s\n", SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        }
    }

out:
    SIM_MEMORY_PUT(dump_entries_p);
    return status;
}

sx_utils_status_t __print_table(void)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_info_t *entries_p = NULL;
    uint32_t            num_entries = cur_table_size;
    uint32_t            i = 0, valids = 0;

    SIM_CLR_MEMORY_GET(entries_p, num_entries, psort_entry_info_t);

    /* dump db */
    if (SX_UTILS_CHECK_FAIL(status = psort_dump_table(handle, entries_p, &num_entries))) {
        SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    for (i = 0; i < num_entries; i++) {
        valids += (entries_p[i].valid) ? 1 : 0;
        SIM_PRINT("e[%d] {p=%" PRIu32 " ; v=%d ; k=%" PRIu64 " i=%" PRIu32 "  }\n",
                  i, entries_p[i].entry.priority, entries_p[i].valid,
                  entries_p[i].entry.key, entries_p[i].entry.index);
    }
    SIM_PRINT("valids: %u\n", valids);
out:
    SIM_MEMORY_PUT(entries_p);
    return status;
}

sx_utils_status_t __rem_random_n_prio(uint16_t amount, bool specific_prio, int prio)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_t      *valid_entries = NULL, temp_entry;
    psort_entry_info_t *entries_p = NULL;
    uint32_t            num_entries = cur_table_size;
    uint32_t            i = 0, j = 0, k = 0, m = 0, num_to_del = 0, valid_cnt = 0;
    uint32_t            tcam_foreground_count_before = tcam_foreground_count;

    SIM_CLR_MEMORY_GET(entries_p, num_entries, psort_entry_info_t);

    /* dump db */
    if (SX_UTILS_CHECK_FAIL(status = psort_dump_table(handle, entries_p, &num_entries))) {
        SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    SIM_CLR_MEMORY_GET(valid_entries, num_entries, psort_entry_t);

    for (i = 0; i < num_entries; i++) {
        if (1 == entries_p[i].valid) {
            if (specific_prio && (entries_p[i].entry.priority != prio)) {
                continue;
            }
            memcpy(&(valid_entries[j++]), &(entries_p[i].entry), sizeof(psort_entry_t));
        }
    }

    valid_cnt = j;
    k = valid_cnt;
    num_to_del = MIN(valid_cnt, amount);
    m = num_to_del;

    j = 0;
    while (m > 0) {
        i = rand() % (k--) + j;
        if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
            SIM_PRINT("removing key: %" PRIu64 " prio: %" PRIu32 "\n", valid_entries[i].key,
                      valid_entries[i].priority);
        }

        if (i != j) {
            memcpy(&temp_entry, &(valid_entries[j]), sizeof(psort_entry_t));
            memcpy(&(valid_entries[j]), &(valid_entries[i]), sizeof(psort_entry_t));
            memcpy(&(valid_entries[i]), &temp_entry, sizeof(psort_entry_t));
        }

        m--;
        j++;
    }

    /* call delete for each random entry */
    for (i = 0; i < num_to_del; i++) {
        tcam_foreground_count_before = tcam_foreground_count;

        if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
            SIM_PRINT("psort entryset %" PRIu64 " %d %" PRIu32 " %" PRIu64 " %" PRIu32 "\n",
                      handle,
                      SX_UTILS_CMD_DELETE,
                      valid_entries[i].priority,
                      valid_entries[i].key,
                      valid_entries[i].index);
        }

        fprintf(command_log,
                "psort entryset %" PRIu64 " %d %" PRIu32 " %" PRIu64 " %" PRIu32 "\n",
                handle,
                SX_UTILS_CMD_DELETE,
                valid_entries[i].priority,
                valid_entries[i].key,
                valid_entries[i].index);

        pthread_mutex_lock(&psort_mutex);
        if (SX_UTILS_CHECK_FAIL(status = psort_entry_set(handle, SX_UTILS_CMD_DELETE, &(valid_entries[i])))) {
            SIM_LOG_ERR("Failed to remove entries %s\n", SX_UTILS_STATUS_MSG(status));
            pthread_mutex_unlock(&psort_mutex);
            goto out;
        }
        tcam_foreground_count++;

        pthread_mutex_unlock(&psort_mutex);
        if (delay_insert_remove != 0) {
            usleep(delay_insert_remove);
        }

        pthread_mutex_lock(&psort_mutex);
        if (SX_UTILS_CHECK_FAIL(status = __validate_rem_constrains(&(valid_entries[i]), 1))) {
            SIM_LOG_ERR("Failed to validate after remove %s\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }

        pthread_mutex_unlock(&psort_mutex);


        if (bg_tcam_ratio > 0) {
            if (SX_UTILS_CHECK_FAIL(status =
                                        reorder_according_to_background_tcam_ratio(tcam_foreground_count_before))) {
                goto out;
            }
        }
    }

out:
    SIM_MEMORY_PUT(valid_entries);
    SIM_MEMORY_PUT(entries_p);

    return status;
}

sx_utils_status_t __reorder_n(bool do_reorder_full, uint16_t num, bool do_check_each_reorder, char *tag)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    uint16_t            count = 0;
    uint32_t            num_entries_before = cur_table_size;
    struct timeval      time_begin, time_end, order_time;
    psort_info_stats_t  info;
    psort_entry_info_t *entries_before_p = NULL, *entries_after_p = NULL;
    int                 index = total_num - 1;

    if (index < 0) {
        /* Table empty */
        goto out;
    }
    pthread_mutex_lock(&psort_mutex);

    memset(&order_time, 0, sizeof(struct timeval));
    memset(&time_end, 0, sizeof(struct timeval));
    memset(&order_time, 0, sizeof(struct timeval));
    memset(&time_begin, 0, sizeof(struct timeval));

    SIM_CLR_MEMORY_GET(entries_before_p, cur_table_size, psort_entry_info_t);
    SIM_CLR_MEMORY_GET(entries_after_p, cur_table_size, psort_entry_info_t);

    if (index) {
        memcpy(&time_begin, &(bg_full_reorder_stats_arr[index].total_shift_time), sizeof(struct timeval));
    }

    do {
        if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
            /* dump db */
            num_entries_before = cur_table_size;
            if (SX_UTILS_CHECK_FAIL(status = psort_dump_table(handle, entries_before_p, &num_entries_before))) {
                SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        }

        /* call reorder */
        if (SX_UTILS_CHECK_FAIL(status = __call_bg_and_update_status(do_reorder_full))) {
            SIM_LOG_ERR("failed to reorder table %s\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }

        if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
            if (SX_UTILS_CHECK_FAIL(status =
                                        __validate_reorder_constrains(entries_before_p, num_entries_before,
                                                                      entries_after_p))) {
                SIM_LOG_ERR("failed to validate after reorder %s\n", SX_UTILS_STATUS_MSG(status));
                goto out;
            }
            if (do_check_each_reorder) {
                if (SX_UTILS_CHECK_FAIL(status = __check_constrains(FALSE))) {
                    SIM_LOG_ERR("failed to check constrains after reorder %s\n", SX_UTILS_STATUS_MSG(status));
                    goto out;
                }
            }
        }

        count++;

        if (count > 32 * cur_table_size) {
            status = SX_UTILS_STATUS_ERROR;
            SIM_LOG_ERR("reorder failed - infinite loop %s\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    } while (is_steady == FALSE &&
             ((do_reorder_full == FALSE && count < num) || do_reorder_full == TRUE));


    if (is_steady && (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E)) {
        if (SX_UTILS_CHECK_FAIL(status = __check_constrains(FALSE))) {
            SIM_LOG_ERR("failed to check constrains after reorder %s\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    }


    if (SX_UTILS_CHECK_FAIL(status = psort_info_stats_get(handle, &info))) {
        SIM_LOG_ERR("Failed to get psort info stats %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    if ((count > 0) && (TRUE == is_steady)) {
        if (index) {
            memcpy(&time_end, &(bg_full_reorder_stats_arr[index].total_shift_time), sizeof(struct timeval));
            __time_sub(&time_end, &time_begin, &order_time);
            __time_update_min_max(&order_time, &(bg_full_reorder_stats_arr[index]));
            bg_full_reorder_stats_arr[index].max_shift_count = MAX(count,
                                                                   bg_full_reorder_stats_arr[index].max_shift_count);
            bg_full_reorder_stats_arr[index].min_shift_count = MIN(count,
                                                                   bg_full_reorder_stats_arr[index].min_shift_count);
            bg_full_reorder_stats_arr[index].num_shifts++;
            bg_full_reorder_stats_arr[index].total_shifts_count += count;
        }


        SIM_PRINT("######################\n");
        SIM_PRINT("Achieved steady state!!\n")
        if (NULL != tag) {
            SIM_PRINT("tag: %s\n", tag);
        }
        SIM_PRINT("total entries in table:%" PRIu16 "\n", total_num);
        SIM_PRINT("num of cycles: %" PRIu16 "\n", count);
        SIM_PRINT("duration: %ld.%ld (sec)\n", order_time.tv_sec, order_time.tv_usec);
        SIM_PRINT("######################\n\n");
    }

out:
    SIM_MEMORY_PUT(entries_before_p);
    SIM_MEMORY_PUT(entries_after_p);

    pthread_mutex_unlock(&psort_mutex);
    return status;
}

sx_utils_status_t __validate_reorder_constrains(psort_entry_info_t *entries_before_p,
                                                uint32_t            num_entries_before,
                                                psort_entry_info_t *entries_after_p)
{
    sx_utils_status_t  status = SX_UTILS_STATUS_SUCCESS;
    uint32_t           num_entries_after = cur_table_size, i = 0, j = 0, diff_count = 0;
    psort_entry_info_t entry_info;


    /* TODO Currently reorder constains doesn't work well , need to fix*/
    goto out;

    memset(&entry_info, 0, sizeof(psort_entry_info_t));

    if (SX_UTILS_CHECK_FAIL(status = psort_dump_table(handle, entries_after_p, &num_entries_after))) {
        SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    while (i < num_entries_before && j < num_entries_after) {
        if ((entries_after_p[j].valid == entries_before_p[i].valid) &&
            (0 == memcmp(&(entries_after_p[j].entry), &(entries_before_p[i].entry), sizeof(psort_entry_t)))) {
            /* entries are equal */
            i++;
            j++;
            continue;
        } else {
            if (entries_before_p[i].entry.index != entries_after_p[j].entry.index) {
                diff_count++;

                i++;
                j++;
                while (entries_before_p[i].entry.priority == entries_before_p[i - 1].entry.priority) {
                    i++;
                }
                while (entries_after_p[j].entry.priority == entries_after_p[j - 1].entry.priority) {
                    j++;
                }
                if (diff_count > 2) {
                    status = SX_UTILS_STATUS_ERROR;
                    SIM_LOG_ERR("reorder error: more than two changes were detected.. (%s)\n",
                                SX_UTILS_STATUS_MSG(status));
/*					for(k=0;k<num_entries_before;k++){
 *                       printf("i %2d v %d p %2d k %10"PRIu64" index %2d\n",k,entries_before_p[k].valid,
 *                               entries_before_p[k].entry.priority, entries_before_p[k].entry.key, entries_before_p[k].entry.index);
 *                   }
 *                   printf("\n\n");
 *                   for(k=0;k<num_entries_before;k++){
 *                       printf("i %2d v %d p %2d k %10"PRIu64" index %2d\n",k,entries_after_p[k].valid,
 *                               entries_after_p[k].entry.priority, entries_after_p[k].entry.key, entries_after_p[k].entry.index);
 *                   }*/
                    goto out;
                }

                continue;
            } else {
                /* indices are equal */

                if ((FALSE == entries_before_p[i].valid) && (FALSE == entries_after_p[j].valid)) {
                    /* we don't care about invalids */
                    i++;
                    j++;
                    continue;
                } else if (((1 == entries_before_p[i].valid) && (FALSE == entries_after_p[j].valid)) ||
                           ((FALSE == entries_before_p[i].valid) && (1 == entries_after_p[j].valid))) {
                    /* one is valid, the other is not, meaning that entry was moved */
                    diff_count++;
                    if (diff_count > 2) {
                        status = SX_UTILS_STATUS_ERROR;
                        SIM_LOG_ERR("reorder error: more than two changes were detected (%s)\n",
                                    SX_UTILS_STATUS_MSG(status));
                        goto out;
                    }

                    i++;
                    j++;
                    continue;
                } else {
                    /* indices are equal and valid, but different key/prio -impossible */
                    status = SX_UTILS_STATUS_ERROR;
                    SIM_LOG_ERR(
                        "reorder error: after reorder, indices are identical and valid, but prio/key changed (%s)\n",
                        SX_UTILS_STATUS_MSG(status));
                    goto out;
                }
            }
        }
    }

out:
    return status;
}

/**
 *
 * OTHER FUNCIONS
 *
 */

void is_unique(const uint32_t *output_prio_arr, const uint32_t size, const uint32_t val, bool *is_unique)
{
    /* TODO make it more efficient (sorted...) */
    uint32_t i = 0;

    for (i = 0; i <= size; i++) {
        if (output_prio_arr[i] == val) {
            *is_unique = FALSE;
            return;
        }
    }

    *is_unique = TRUE;
    return;
}

void __print_help(void)
{
    printf("PSORT SIMULATOR\n\n");
    printf(
        "run this simulator with ./psort_sim <input_file> [-h] [-s seed] [-r run_mode] -n [num_of_seeds] -b [ratio]\n");
    printf("-b      tcam writes to background worker ratio (e.g, 50)\n");
    printf("-h      print this help\n");
    printf("-s      use specific seed\n");
    printf(
        "-r      0 - (default) conformance mode, execute commands and perform validations (this run might take longer time)\n");
    printf("        1 - performance mode, execute commands, skip validations\n");
    printf("\ncreate the input file with the following commands-\n\n");
    printf("in the header:\n");
    printf(
        "[%s] <us> - optional, use timer thread to periodically handle reorders (if not used, default is to order manually) \n",
        SIM_STR_TIMER_THREAD);
    printf("[%s] (optional)\n", SIM_STR_DELTA);
    printf("\t[%s] - use a custom delta value\n", SIM_STR_FIXED);
    printf("\t[%s] <min> <max> - increment delta and repeat test from scratch from <min> to <max>\n",
           SIM_STR_INCREMENTAL);
    printf("[%s] <seed> - optional, use a custom seed for random numbers\n", SIM_STR_FIXED_SEED);
    printf("[%s] <num> - optional, use a test several seeds\n", SIM_STR_NUM_OF_SEEDS);
    printf("[%s] <us> - delay in micro sec between insertion/removing items\n", SIM_STR_INSERTION_DELAY);
    printf("[%s] <num> - define how many random priorities to use\n", SIM_STR_NUM_OF_PRIOS);
    printf(
        "[%s] <table_size> <max_prio> <min_prio> <full_thr> <empty_thr> - init psort (full_thr/empty_thr - threshold for full/empty notifications)\n",
        SIM_STR_INIT);

    printf("\n");
    printf("available commands:\n");
    printf("[%s] <num> - randomly choose operation (add/delete), to apply on random <num> entries\n",
           SIM_STR_RAND_OPERATION);
    printf("[%s]\n", SIM_STR_ADD);
    printf("\t[%s] <entry> - add a specific entry\n", SIM_STR_FIXED);
    printf("\t[%s] <num> - add <num> random entries\n", SIM_STR_RAND);
    printf("\t[%s] <num> <prio> - add <num> random entries to specific priority\n", SIM_STR_RAND_VAL_FIXED_PRIO);
    printf("\t[%s] <num_prios> <num_entries_per_prio> - add <num_entries_per_prio> "
           "random entries to <num_prios> random priorities\n", SIM_STR_RAND_BLOCK);
    printf("[%s]\n", SIM_STR_REM);
    printf("\t[%s] - remove a specific entry\n", SIM_STR_FIXED);
    printf("\t[%s] <num> - remove <num> random entries (or maximum possible)\n", SIM_STR_RAND);
    printf("\t[%s] <num> <prio> - remove <num> entries from specific priority\n", SIM_STR_RAND_VAL_FIXED_PRIO);

    printf("[%s] - use when timer thread is not activated in order to trigger db reorganization\n", SIM_STR_REORDER);
    printf("\t[%s] <num> - performs <num> cycles of reordering (or less, if reached steady-state)\n",
           SIM_STR_N_CYCLES);
    printf(
        "\t[%s] <tag> - performs reordering until db reached steady-state. <tag> is used to identify statistics in log\n",
        SIM_STR_FULL);
    printf("\t[%s] <tag> - performs full reorder with checks between each cycle", SIM_STR_WITH_CHECK);

    printf("[%s] - call the constrains validation procedure\n", SIM_STR_CHECK);

    printf("[%s] <new_size> - set new size for the table\n", SIM_STR_RESIZE_TABLE);

    printf("[%s] used when timer thread is activated; will hold executing next line until steady-state is reached\n",
           SIM_STR_WAIT_FOR_STEADY_STATE);

    printf("[%s] - print psort table\n", PRINT);

    printf("\n");
    printf("to comment out a line put '#' at the beginning\n");
}

void __clear_counters(void)
{
    total_num = 0;
    tcam_foreground_count = 0;
    background_worker_count = 0;
    already_executed = FALSE;

    memset(bg_full_reorder_stats_arr, 0, bg_full_reorder_stats_len * (sizeof(bg_full_reorder_stats_t)));
    if (is_initialized) {
        pthread_mutex_lock(&psort_mutex);
        is_initialized = FALSE;
        psort_clear_table(handle);
        pthread_mutex_unlock(&psort_mutex);
    }
    SIM_MEMORY_PUT(prios_arr);
}

float __percentage_full(void)
{
    float    res = 0;
    uint16_t valids = 0;
    uint16_t i = 0;

    for (i = 0; i < cur_table_size; i++) {
        valids += (sim_db[i].valid) ? 1 : 0;
    }

    res = valids;
    res = res * 100 / cur_table_size;

    return res;
}

/**
 *
 * VALIDATING CONSTRAINS
 *
 */

sx_utils_status_t __validate_init_constrains(const psort_init_param_t *params)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_info_t *entries_p = NULL;
    uint32_t            num_entries = cur_table_size;
    uint32_t            i = 0;
    uint32_t            prev_index = 0;
    int                 prev_prio = 0;

    SIM_CLR_MEMORY_GET(entries_p, num_entries, psort_entry_info_t);

    /* dump db */
    status = psort_dump_table(handle, entries_p, &num_entries);
    if (SX_UTILS_CHECK_FAIL(status)) {
        SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
        goto out;
    }

    if (params->table_size - 1 != entries_p[num_entries - 1].entry.index) {
        status = SX_UTILS_STATUS_ERROR;
        SIM_LOG_ERR("init problem, last entry index (%" PRIu32 ") should be table_size - 1 (%" PRIu32 ")!\n",
                    entries_p[num_entries - 1].entry.index,
                    params->table_size - 1);
        goto out;
    }

    prev_prio = entries_p[0].entry.priority;
    prev_index = entries_p[0].entry.index;
    /* check db: [max prio region, hole, min prio region] */
    if ((entries_p[0].entry.priority != param.max_priority) ||
        (entries_p[num_entries - 1].entry.priority != param.min_priority)) {
        SIM_LOG_ERR("init problem\n");
        status = SX_UTILS_STATUS_ERROR;
        goto out;
    }
    for (i = 0; i < num_entries; i++) {
        if (entries_p[i].valid) {
            SIM_LOG_ERR("init valid problem!\n");
            status = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        if (i > 0) {
            if (prev_index >= entries_p[i].entry.index) {
                SIM_LOG_ERR("init index problem!\n");
                status = SX_UTILS_STATUS_ERROR;
                goto out;
            }

            if ((i == params->delta_size) || (i == num_entries - params->delta_size)) {
                if (entries_p[i].entry.priority == entries_p[i - 1].entry.priority) {
                    SIM_LOG_ERR("init problem, first/last region is not delta sized!\n");
                    status = SX_UTILS_STATUS_ERROR;
                    goto out;
                }
            }
        }

        if (prev_prio != entries_p[i].entry.priority) {
            if ((prev_prio != param.max_priority) ||
                (entries_p[i].entry.priority != param.min_priority)) {
                SIM_LOG_ERR("init problem!\n");
                status = SX_UTILS_STATUS_ERROR;
                goto out;
            } else {
                /* hole found */
            }
        }

        prev_prio = entries_p[i].entry.priority;
        prev_index = entries_p[i].entry.index;
    }

out:
    SX_LOG_INF("%s() finished with status: %s\n", __FUNCTION__, SX_UTILS_STATUS_MSG(status));
    SIM_MEMORY_PUT(entries_p);
    return status;
}

sx_utils_status_t __validate_add_constrains(psort_entry_t *entry_p, uint16_t num_of_entries)
{
    sx_utils_status_t   status = SX_UTILS_STATUS_SUCCESS;
    uint16_t            i = 0, res_i = 0, j = 0;
    psort_entry_info_t  entry_test;
    int                 prev_prio = param.max_priority;
    psort_entry_info_t *entries_p = NULL;
    uint32_t            num_entries = cur_table_size;

    if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
        SIM_CLR_MEMORY_GET(entries_p, num_entries, psort_entry_info_t);

        /* dump db */
        if (SX_UTILS_CHECK_FAIL(status = psort_dump_table(handle, entries_p, &num_entries))) {
            SIM_LOG_ERR("failed to get psort table %s\n", SX_UTILS_STATUS_MSG(status));
            goto out;
        }
    }

    /* validate correct index */
    for (i = 0; i < num_of_entries; i++) {
        res_i = entry_p[i].index;

        sim_db[res_i].key = entry_p[i].key;
        sim_db[res_i].priority = entry_p[i].priority;
        sim_db[res_i].valid = 1;
        total_num++;

        if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
            for (j = 0; j < cur_table_size; j++) {
                if (1 == sim_db[j].valid) {
                    if (sim_db[j].priority > prev_prio) {
                        status = SX_UTILS_STATUS_ERROR;
                        SIM_LOG_ERR("add error - priorities should decrease (i=%d prio=%d, prev prio=%d)\n", j,
                                    sim_db[j].priority, prev_prio);
                        goto out;
                    }
                    prev_prio = sim_db[j].priority;
                }
            }

            entry_test.entry.key = entry_p[i].key;
            entry_test.entry.priority = entry_p[i].priority;
            if (SX_UTILS_CHECK_FAIL(status = __get_entry_by_key_prio(&entry_test, entries_p, num_entries))) {
                SIM_LOG_ERR("add error - new entry wasn't found in the table (%s)\n", SX_UTILS_STATUS_MSG(status));
                goto out;
            }

            if (entry_test.valid != 1) {
                status = SX_UTILS_STATUS_ERROR;
                SIM_LOG_ERR("add error - new entry's valid bit is FALSE (%s)\n", SX_UTILS_STATUS_MSG(status));
                goto out;
            }

            if (entry_test.entry.index != entry_p[i].index) {
                status = SX_UTILS_STATUS_ERROR;
                SIM_LOG_ERR(
                    "add error - new entry's index (%" PRIu16 ") is different than actually (%" PRIu16 ") (key %" PRIu64 ")  (%s)\n",
                    entry_p[i].index,
                    entry_test.entry.index,
                    entry_p[i].key,
                    SX_UTILS_STATUS_MSG(status));
                goto out;
            }
        }
    }

    if (run_mode == PSORT_SIM_RUN_MODE_CONFORMANCE_E) {
        /* validate all valids are still inside */

        for (i = 0; i < cur_table_size; i++) {
            if (1 == sim_db[i].valid) {
                entry_test.entry.key = sim_db[i].key;
                entry_test.entry.priority = sim_db[i].priority;
                if (SX_UTILS_CHECK_FAIL(status = __get_entry_by_key_prio(&entry_test, entries_p, num_entries))) {
                    SIM_LOG_ERR("add error - entry wasn't found in the table (%s)\n", SX_UTILS_STATUS_MSG(status));
                    goto out;
                }

                if (entry_test.valid != 1) {
                    status = SX_UTILS_STATUS_ERROR;
                    SIM_LOG_ERR("add error - new entry's valid bit is FALSE (%s) entry_test.entry.key %" PRIu64 " \n",
                                SX_UTILS_STATUS_MSG(status),
                                entry_test.entry.key);
                    goto out;
                }
            }
        }
    }

    goto out;
out:
    SIM_MEMORY_PUT(entries_p);
    return status;
}


/* Return 1 if the difference is negative, otherwise 0.  */
int __time_sub(struct timeval *end, struct timeval *begin, struct timeval *result)
{
    long int diff = (end->tv_usec + 1000000 * end->tv_sec) - (begin->tv_usec + 1000000 * begin->tv_sec);

    result->tv_sec = diff / 1000000;
    result->tv_usec = diff % 1000000;

    return (diff < 0);
}

int __time_sum(struct timeval *val, struct timeval *result)
{
    long int sum = (result->tv_usec + 1000000 * result->tv_sec) + (val->tv_usec + 1000000 * val->tv_sec);

    result->tv_sec = sum / 1000000;
    result->tv_usec = sum % 1000000;

    return 0;
}

int __time_min_max(struct timeval *in_time, struct timeval *inout_max, struct timeval *inout_min)
{
    if (in_time->tv_usec + 1000000 * in_time->tv_sec > inout_max->tv_usec + 1000000 * inout_max->tv_sec) {
        inout_max->tv_sec = in_time->tv_sec;
        inout_max->tv_usec = in_time->tv_usec;
    }
    if (in_time->tv_usec + 1000000 * in_time->tv_sec < inout_min->tv_usec + 1000000 * inout_min->tv_sec) {
        inout_min->tv_sec = in_time->tv_sec;
        inout_min->tv_usec = in_time->tv_usec;
    }

    return 0;
}

int __time_update_min_max(struct timeval *time,  bg_full_reorder_stats_t *bg_full_reorder_stats_arr)
{
    if (time->tv_usec + 1000000 * time->tv_sec > bg_full_reorder_stats_arr->max_shift_time.tv_usec + 1000000 *
        bg_full_reorder_stats_arr->max_shift_time.tv_sec) {
        bg_full_reorder_stats_arr->max_shift_time.tv_sec = time->tv_sec;
        bg_full_reorder_stats_arr->max_shift_time.tv_usec = time->tv_usec;
    }
    if (time->tv_usec + 1000000 * time->tv_sec < bg_full_reorder_stats_arr->min_shift_time.tv_usec + 1000000 *
        bg_full_reorder_stats_arr->min_shift_time.tv_sec) {
        bg_full_reorder_stats_arr->min_shift_time.tv_sec = time->tv_sec;
        bg_full_reorder_stats_arr->min_shift_time.tv_usec = time->tv_usec;
    }

    return 0;
}

int __time_avg(struct timeval *time, uint16_t num, struct timeval *result)
{
    uint32_t avg = (time->tv_usec + 1000000 * time->tv_sec) / num;

    result->tv_sec = avg / 1000000;
    result->tv_usec = avg % 1000000;

    return 0;
}

sx_utils_status_t __get_entry_by_key_prio(psort_entry_info_t *entry_info,
                                          psort_entry_info_t *entries_p,
                                          uint32_t            num_entries)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i = 0;
    bool              found = FALSE;

    for (i = 0; i < num_entries; i++) {
        if ((entries_p[i].entry.priority == entry_info->entry.priority) &&
            (entries_p[i].entry.key == entry_info->entry.key)) {
            found = TRUE;
            entry_info->valid = entries_p[i].valid;
            entry_info->entry.index = entries_p[i].entry.index;
            break;
        }
    }

    if (FALSE == found) {
        status = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
out:
    return status;
}


long long __get_time_stamp(struct timespec* ts)
{
    long long nsec = 0;

    if (clock_gettime(CLOCK_REALTIME, ts) == -1) {
        return 0;
    }

    nsec = (((long long)ts->tv_sec) * (long long)1000000000ll) + ts->tv_nsec;

    return nsec;
}
