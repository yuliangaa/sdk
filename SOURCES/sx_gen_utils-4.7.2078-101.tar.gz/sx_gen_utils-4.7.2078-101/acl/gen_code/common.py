import sys
import getopt


def is_key_exposed(key, keys_blocks, blocks):
    for kb in keys_blocks:
        block_info = blocks[kb]
        if not block_info['opened']:
            continue
        items = keys_blocks[kb]
        for i in items:
            if (i['key_name'] == key) and (i['is_exposed']):
                return True
    return False


def get_data_dictinary_files(argv):
    keys_file = None
    blocks_file = None
    keys_blocks_file = None
    output_file = None

    try:
        opts, args = getopt.getopt(argv, 'k:b:r:o:')
    except getopt.GetoptError:
        print('uasge : create_gen_deg.py  -k <keyfile> -b <blocksfile> r <keysinblocksfile>')
        sys.exit(2)

    for opt, arg in opts:
        if opt == '-k':
            keys_file = arg
        elif opt == '-b':
            blocks_file = arg
        elif opt == '-r':
            keys_blocks_file = arg
        elif opt == '-o':
            output_file = arg

    if (keys_file is None) or (blocks_file is None) or (keys_blocks_file is None):
        print('uasge : create_gen_deg.py  -k <keyfile> -b <blocksfile> r <keysinblocksfile> [-o <outputfile>]')
        sys.exit(2)

    return (keys_file, blocks_file, keys_blocks_file, output_file)


class CONSTANTS():
    INGRESS = 'INGRESS'
    EGRESS = 'EGRESS'
    RIF_INGRESS = 'RIF_INGRESS'
    RIF_EGRESS = 'RIF_EGRESS'
    TPORT_INGRESS = 'TPORT_INGRESS'
    TPORT_EGRESS = 'TPORT_EGRESS'
    CPU_INGRESS = 'CPU_INGRESS'
    CPU_EGRESS = 'CPU_EGRESS'
    BLOCK_PREFIX = 'FLEX_ACL_KEY_BLOCK_'
    SXD_BLOCK_PREFIX = 'SXD_ACL_KEY_BLOCK_'
    DIR_PREFIX = 'SX_ACL_DIRECTION_'
    KEY_PREFIX = 'FLEX_ACL_HW_KEY_'
    SUFFIX = '_E'
    TAB = '    '
    EQUAL = ' = '
