Code Generator
--------------

Input CSV files For ACL Data dictionary: 
The CSV files are : basic_keys.txt, blocks.txt and keys_blocks.txt
The above CSV files are the ACL data dictionary that is used to create ACL code : flex_acl_gen_def.h and flex_acl_gen_init.c.
Important note!!! Please don't leave empty line in end of file. This will break the generation.

basic_keys.txt - key fields
-------------
fields: 
------
name,
type: u - uint, a- uint8 arr, mac, fc, bit array  
bytes size,
bits size,
is ingrees,
is egrees,
is rif ingress,
is rif egress,
is tport ingress,
is tport egress,
is cpu ingress,
is cpu egress,
is_exposed,
description.

blocks.txt - blocks
fields:
------
name, 
enable/disable: 0 - disabled, 1 - enabled.
Flex version bitmask: 0x1 - FLEX1, 0x2 - FLEX2, 0x4 - FLEX3, 0x8 - FLEX4, 0x10 - MACSEC
Symmetric key support (bitmask): 0x1 -  non symmetric, 0x2 - symmetric, 0x3 - both.
description

keys_block.txt - Describes the fields in each key block.
fields:
-------
block name, 
key name, 
offset in block,
bits length in this instance,
offset in key,
is keys exposed in block

After any changes to one of the above files the following shuld be done:

make
make install
