from db import *


class BLOCKS(DB):
    def update(self, line):
        tokens = line.split('#')
        name = tokens[0]
        is_enabled = bool(int(tokens[1]))
        hw_key_stages = '0x0'
        symmetric = '0x0'
        if name in self.db:
            del self.db[name]
        if True == is_enabled:
            hw_key_stages = tokens[2]
            symmetric = tokens[3]
        self.db[name] = {'opened': is_enabled, 'hw_key_stages': hw_key_stages, 'symmetric': symmetric}
