from db import *
from common import *


class KEYS(DB):
    def update(self, line):
        tokens = line.split('#')
        name = tokens[0]
        key_type = tokens[1]
        key_type_len = int(tokens[2])
        bits_len = int(tokens[3])

        ingress = bool(int(tokens[4]))
        egress = bool(int(tokens[5]))
        rif_ingress = bool(int(tokens[6]))
        rif_egress = bool(int(tokens[7]))
        tport_ingress = bool(int(tokens[8]))
        tport_egress = bool(int(tokens[9]))
        cpu_ingress = bool(int(tokens[10]))
        cpu_egress = bool(int(tokens[11]))
        is_exposed = bool(int(tokens[12]))
        desc = tokens[13]
        if name in self.db:
            del self.db[name]
        self.db[name] = {'key_type': key_type, 'key_type_len': key_type_len, 'key_bits_len': bits_len, CONSTANTS.INGRESS: ingress,
                         CONSTANTS.EGRESS: egress, CONSTANTS.RIF_INGRESS:
                         rif_ingress, CONSTANTS.RIF_EGRESS: rif_egress, CONSTANTS.TPORT_INGRESS: tport_ingress,
                         CONSTANTS.TPORT_EGRESS: tport_egress, CONSTANTS.CPU_INGRESS: cpu_ingress, CONSTANTS.CPU_EGRESS: cpu_egress,
                         'is_exposed': is_exposed, 'desc': desc}
