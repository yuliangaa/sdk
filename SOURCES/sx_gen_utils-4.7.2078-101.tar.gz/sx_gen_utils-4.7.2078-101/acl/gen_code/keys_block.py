from db import *


class KEYS_BLOCK(DB):
    def load(self, file_name):
        old_block_name = None
        block_name = None
        block_keys_list = []
        file = open(file_name, 'r')
        for line in file:
            line = line[:-1]
            tokens = line.split('#')
            block_name = tokens[0]
            if old_block_name != block_name:
                if old_block_name is not None:
                    self.db[old_block_name] = block_keys_list
                    block_keys_list = []
                old_block_name = block_name
            key_name = tokens[1]
            block_offset = tokens[2]
            bit_length = tokens[3]
            key_offset = tokens[4]
            if tokens[5] == '0':
                is_exposed = False
            else:
                is_exposed = True
            block_keys_list.append({'key_name': key_name, 'block_offset': block_offset.strip(), 'bit_length': bit_length.strip(),
                                    'key_offset': key_offset.strip(), 'is_exposed': is_exposed})
        if block_name is not None:
            self.db[block_name] = block_keys_list
        file.close()
