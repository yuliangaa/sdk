from collections import OrderedDict


class DB:
    def __init__(self):
        self.db = OrderedDict()

    def update(self, line):
        pass

    def item_exists(self, id):
        return id in self.db

    def get_all(self):
        return self.db

    def get_data(self, id):
        if id in self.db:
            return self.db[id]
        return None

    def load(self, file_name):
        with open(file_name, 'r') as file:
            for line in file:
                self.update(line.strip())
