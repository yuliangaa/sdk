#!/usr/bin/env python3

import sys
from blocks import *
from keys import *
from keys_block import *
from common import *


def get_byte_size(type_name, type_size):
    if type_name == 'u':
        return (type_size // 8)
    if (type_name == 'a') or (type_name == 'b'):
        return type_size
    if type_name == 'm':
        return 6
    if type_name == 'f':
        return 3

    return 0


def is_endienism(type_name, type_size):
    if type_name == 'u':
        return (type_size > 1)
    if type_name == 'm':
        return False
    if type_name == 'f':
        return True
    if (type_name == 'a'):
        return False
    if (type_name == 'b'):
        return True

    return False


def main(argv):
    keys_file, blocks_file, keys_blocks_file, output_file = get_data_dictinary_files(argv)

    if output_file:
        fout = open(output_file, 'w')
    else:
        fout = sys.stdout

    blocks_db = BLOCKS()
    blocks_db.load(blocks_file)
    keys_db = KEYS()
    keys_db.load(keys_file)
    keys_block_db = KEYS_BLOCK()
    keys_block_db.load(keys_blocks_file)

    fout.write('/*\n')
    fout.write(' * Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.\n')
    fout.write(' *\n')
    fout.write(' * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.\n')
    fout.write(' * (the "Company") and all right, title, and interest in and to the software product,\n')
    fout.write(' * including all associated intellectual property rights, are and shall\n')
    fout.write(' * remain exclusively with the Company.\n')
    fout.write(' *\n')
    fout.write(' * This software product is governed by the End User License Agreement\n')
    fout.write(' * provided with the software product.\n')
    fout.write(' *\n')
    fout.write(' */\n')
    fout.write('/* flex_acl_db_gen_init.c\n')
    fout.write(' *   GENERATED CODE created by machine. Do not change.\n')
    fout.write(' */\n')

    fout.write('#define __FLEX_ACL_GEN_INIT__\n')
    fout.write('#include "flex_acl_gen_def.h"\n')
    fout.write('#undef __FLEX_ACL_GEN_INIT__\n')
    fout.write('/***********************************************\n')
    fout.write('*  Local variables\n')
    fout.write('***********************************************/\n')
    fout.write('/************************************************\n')
    fout.write(' *  Global variables\n')
    fout.write(' ***********************************************/\n\n')

    fout.write('flex_acl_key_data_t       flex_acl_keys_data[FLEX_ACL_HW_KEY_LAST_E] = {\n')
    blocks = blocks_db.get_all()
    keys = keys_db.get_all()
    keys_blocks = keys_block_db.get_all()
    for k in keys:
        if not is_key_exposed(k, keys_blocks, blocks):
            continue
        keys_info = keys[k]
        byte_size = get_byte_size(keys_info['key_type'], keys_info['key_type_len'])
        line = [CONSTANTS.TAB, '[', CONSTANTS.KEY_PREFIX, k, CONSTANTS.SUFFIX, ']', ' = {', str(byte_size), ', ', str(keys_info['key_bits_len']), ',', '\n']
        pline = "".join(line)
        fout.write(pline)
        line_prefix = (pline.index('{') + 1) * ' '

        is_end = str(is_endienism(keys_info['key_type'], byte_size))
        flags = '0 '
        for b in [CONSTANTS.INGRESS, CONSTANTS.EGRESS, CONSTANTS.RIF_INGRESS, CONSTANTS.RIF_EGRESS, CONSTANTS.TPORT_INGRESS, CONSTANTS.TPORT_EGRESS, CONSTANTS.CPU_INGRESS, CONSTANTS.CPU_EGRESS]:
            if keys_info[b]:
                flags = flags + '| (1 << ' + CONSTANTS.DIR_PREFIX + b + ')\n' + line_prefix
        line = [line_prefix, flags, ', ', is_end.upper(), '},', '\n']
        fout.write("".join(line))
    fout.write('};\n')

    fout.write('flex_acl_key_block_data_t key_block_data_dictionary[] = {\n')

    for b in blocks:
        block_info = blocks[b]
        if not block_info['opened']:
            continue
        keys_block_info = keys_blocks[b]
        num_of_keys = 0
        for k in keys_block_info:
            if k['is_exposed']:
                num_of_keys += 1
        if num_of_keys == 0:
            continue
        line = [CONSTANTS.TAB, '[', CONSTANTS.BLOCK_PREFIX, b, CONSTANTS.SUFFIX, '] =', '\n']
        fout.write("".join(line))
        line = [CONSTANTS.TAB, '{', CONSTANTS.SXD_BLOCK_PREFIX, b, ', 1, ', block_info['hw_key_stages'], ', ', block_info['symmetric'], ', ', str(num_of_keys),
                ', (flex_acl_key_block_item_t[', str(num_of_keys), ']) {', '\n']
        fout.write("".join(line))
        for k in keys_block_info:
            if not k['is_exposed']:
                continue
            line = [CONSTANTS.TAB, CONSTANTS.TAB, ' {', CONSTANTS.KEY_PREFIX, k['key_name'], CONSTANTS.SUFFIX, ', ', k['block_offset'], ', ', k['bit_length'], ', ',
                    k['key_offset'], '},', '\n', ]
            fout.write("".join(line))
        line = [CONSTANTS.TAB, ' },', ' },', '\n']
        fout.write("".join(line))
    fout.write('};\n')

    fout.write('/************************************************\n')
    fout.write(' *  Local function declarations\n')
    fout.write(' ***********************************************/\n')
    fout.write('/************************************************\n')
    fout.write(' *  Function implementations\n')
    fout.write(' ***********************************************/\n')

    if fout is not sys.stdout:
        fout.close()


if __name__ == "__main__":
    main(sys.argv[1:])
