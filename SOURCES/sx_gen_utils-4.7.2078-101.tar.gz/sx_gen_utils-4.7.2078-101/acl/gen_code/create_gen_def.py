#!/usr/bin/env python3

import sys
from blocks import *
from keys import *
from keys_block import *
from common import *


def main(argv):
    keys_file, blocks_file, keys_blocks_file, output_file = get_data_dictinary_files(argv)

    if output_file:
        fout = open(output_file, 'w')
    else:
        fout = sys.stdout

    fout.write('/*\n')
    fout.write(' * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.\n')
    fout.write(' *\n')
    fout.write(' * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.\n')
    fout.write(' * (the "Company") and all right, title, and interest in and to the software product,\n')
    fout.write(' * including all associated intellectual property rights, are and shall\n')
    fout.write(' * remain exclusively with the Company.\n')
    fout.write(' *\n')
    fout.write(' * This software product is governed by the End User License Agreement\n')
    fout.write(' * provided with the software product.\n')
    fout.write(' *\n')
    fout.write(' */\n')
    fout.write('/* flex_acl_db_gen_def.h\n')
    fout.write(' *    GENEREATED CODE created by machine. Do not change.\n')
    fout.write(' */\n')
    fout.write('#ifndef FLEX_ACL_GEN_DEF_H_\n')
    fout.write('#define FLEX_ACL_GEN_DEF_H_\n\n')

    fout.write('#include <sx/sdk/sx_flex_acl.h>\n')
    fout.write('#ifdef GEN_DF_C_\n\n')

    fout.write('/************************************************\n')
    fout.write(' *  Local Defines\n')
    fout.write(' ***********************************************/\n\n')

    fout.write('/************************************************\n')
    fout.write(' *  Local Macros\n')
    fout.write(' ***********************************************/\n\n')

    fout.write('/************************************************\n')
    fout.write(' *  Local Type definitions\n')
    fout.write(' ***********************************************/\n')
    fout.write('#endif\n\n')

    fout.write('/************************************************\n')
    fout.write(' *  Defines\n')
    fout.write(' ***********************************************/\n\n')

    fout.write('/************************************************\n')
    fout.write(' *  Macros\n')
    fout.write(' ***********************************************/\n\n')

    fout.write('/************************************************\n')
    fout.write(' *  Type definitions\n')
    fout.write(' ***********************************************/\n')

    blocks_db = BLOCKS()
    blocks_db.load(blocks_file)
    keys_db = KEYS()
    keys_db.load(keys_file)
    keys_block_db = KEYS_BLOCK()
    keys_block_db.load(keys_blocks_file)

    fout.write('typedef enum sx_acl_key_block {\n')
    blocks = blocks_db.get_all()
    ind = 0
    for b in blocks:
        block_info = blocks[b]
        if block_info['opened']:
            line = [CONSTANTS.TAB, CONSTANTS.BLOCK_PREFIX, b, CONSTANTS.SUFFIX, CONSTANTS.EQUAL, str(ind), ',', ' /**<  */', '\n']
            fout.write("".join(line))
            ind += 1
    line = [CONSTANTS.TAB, CONSTANTS.BLOCK_PREFIX, 'LAST', CONSTANTS.SUFFIX, CONSTANTS.EQUAL, str(ind), ',', '\n']
    fout.write("".join(line))
    fout.write('} sx_acl_key_block_e;\n\n')

    fout.write('typedef enum {\n')
    keys = keys_db.get_all()
    line = [CONSTANTS.TAB, CONSTANTS.KEY_PREFIX, 'INVALID', CONSTANTS.SUFFIX, CONSTANTS.EQUAL, '0', ',', '\n']
    fout.write("".join(line))
    ind = 1
    for k in keys:
        if is_key_exposed(k, keys_block_db.get_all(), blocks):
            key_info = keys[k]
            line = [CONSTANTS.TAB, CONSTANTS.KEY_PREFIX, k, CONSTANTS.SUFFIX, CONSTANTS.EQUAL, str(ind), ',', ' /**< size:', str(key_info['key_bits_len']), ', ', key_info['desc'], ' */', '\n']
            fout.write("".join(line))
            ind += 1
    line = [CONSTANTS.TAB, CONSTANTS.KEY_PREFIX, 'LAST', CONSTANTS.SUFFIX, CONSTANTS.EQUAL, str(ind), ',', '\n']
    fout.write("".join(line))
    fout.write('} sx_acl_hw_key_e;\n\n')

    fout.write('typedef struct {\n')
    fout.write('    uint8_t   size;\n')
    fout.write('    uint8_t   bit_size;\n')
    fout.write('    uint8_t   flags;\n')
    fout.write('    boolean_t is_endianism;\n')
    fout.write('} flex_acl_key_data_t;\n\n')

    fout.write('typedef struct {\n')
    fout.write('    sx_acl_hw_key_e key_id;\n')
    fout.write('    uint32_t        block_offset;\n')
    fout.write('    uint32_t        len;\n')
    fout.write('    uint32_t        basic_key_offset;\n')
    fout.write('} flex_acl_key_block_item_t;\n\n')

    fout.write('typedef struct {\n')
    fout.write('    uint8_t                    key_block_code;\n')
    fout.write('    boolean_t                  is_enabled;\n')
    fout.write('    uint32_t                   hw_key_stages;\n')
    fout.write('    uint32_t                   symmetric_bitmask;\n')
    fout.write('    uint32_t                   key_block_items_count;\n')
    fout.write('    flex_acl_key_block_item_t *key_block_items;\n')
    fout.write('} flex_acl_key_block_data_t;\n\n')

    fout.write('#ifndef __FLEX_ACL_GEN_INIT__\n')
    fout.write('extern flex_acl_key_data_t       flex_acl_keys_data[];\n')
    fout.write('extern flex_acl_key_block_data_t key_block_data_dictionary[];\n')
    fout.write('#endif\n\n')

    fout.write('/************************************************\n')
    fout.write(' *  Global variables\n')
    fout.write(' ***********************************************/\n\n')

    fout.write('/************************************************\n')
    fout.write(' *  Function declarations\n')
    fout.write(' ***********************************************/\n\n')

    fout.write('#endif /* FLEX_ACL_DB_GEN_DEF_H_ */\n')

    if fout is not sys.stdout:
        fout.close()


if __name__ == "__main__":
    main(sys.argv[1:])
