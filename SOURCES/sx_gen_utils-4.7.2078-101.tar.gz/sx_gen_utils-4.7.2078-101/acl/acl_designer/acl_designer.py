#!/usr/bin/env python3
# -*- python -*-

import sys
import json
import itertools
from PyQt4 import QtCore, QtGui, uic

CHIP_TYPE = 'spectrum'

JSON_PATH_PREFIX = './'
SW_KEYS = 'sw_keys.json'
SW_HW_KEYS = 'sw_hw_keys_spectrum.json'
HW_KEY_BLOCKS = 'hw_key_blocks_spectrum.json'

JSON_FILES_SPC = [
    'sw_keys.json',
    'sw_hw_keys_spectrum.json',
    'hw_key_blocks_spectrum.json']

JSON_FILES_SPC2 = [
    'sw_keys.json',
    'sw_hw_keys_spectrum2.json',
    'hw_key_blocks_spectrum2.json']

JSON_FILES_SPC3 = [
    'sw_keys.json',
    'sw_hw_keys_spectrum3.json',
    'hw_key_blocks_spectrum3.json']

MAX_KEY_BLOCKS = 6
KEY_BLOCK_WIDTH = 9


class ScpCalculatorError(Exception):
    pass


def keys_db_update(keys_db_new):
    keys_db._db = keys_db_new._db


def _get_next_comb(indices, n):
    # We are not using itertools.combinations
    # because we want to generate combinations in the same order as SDK does.
    indices[-1] += 1
    if indices[-1] < n:
        return True
    for cur in reversed(list(range(len(indices) - 1))):
        indices[cur] += 1
        if indices[cur] < n - 1:
            for i in range(cur + 1, len(indices)):
                indices[i] = indices[i - 1] + 1
            if indices[-1] < n:
                return True
    return False


def _comb_generator(blocks, k):
    indices = list(range(k))
    yield [blocks[i] for i in indices]
    while _get_next_comb(indices, len(blocks)):
        yield [blocks[i] for i in indices]


def _get_scp(hw_keys, relevant_blocks, k):
    for comb in _comb_generator(relevant_blocks, k):
        if keys_db.are_blocks_enough(hw_keys, comb):
            return keys_db.get_blocks_names(comb)


def _scp_calc(hw_keys, relevant_blocks, start, end):
    if start > end:
        raise ScpCalculatorError("Too many SW keys selected")

    mid = (start + end) / 2
    key_blocks = _get_scp(hw_keys, relevant_blocks, mid)
    if key_blocks is None:
        return _scp_calc(hw_keys, relevant_blocks, mid + 1, end)
    else:
        try:
            return _scp_calc(hw_keys, relevant_blocks, start, mid - 1)
        except ScpCalculatorError:
            return key_blocks


def _calc_width(key_blocks):
    if CHIP_TYPE == 'spectrum':
        if len(key_blocks) % 2 == 0:
            return len(key_blocks) * KEY_BLOCK_WIDTH
        else:
            return (len(key_blocks) + 1) * KEY_BLOCK_WIDTH
    else:
        if len(key_blocks) <= 2:
            return 2 * KEY_BLOCK_WIDTH
        elif len(key_blocks) <= 4:
            return 4 * KEY_BLOCK_WIDTH
        elif len(key_blocks) <= 8:
            return 8 * KEY_BLOCK_WIDTH
        elif len(key_blocks) <= 12:
            return 12 * KEY_BLOCK_WIDTH
        else:
            return len(key_blocks) * KEY_BLOCK_WIDTH


def _subsets(l):
    for i in range(len(l)):
        for subset in itertools.combinations(l, i):
            yield list(subset)


def scp_calc(sw_keys):
    hw_keys = keys_db.sw_to_hw_keys(sw_keys)
    relevant_blocks = keys_db.get_relevant_blocks(hw_keys)
    key_blocks = _scp_calc(hw_keys, relevant_blocks, 1, min(len(relevant_blocks), MAX_KEY_BLOCKS))
    width = _calc_width(key_blocks)
    return hw_keys, width, key_blocks


def scp_calc_match_width(sw_keys, width_to_match):
    reserved_keys = list(set(keys_db.get_sw_keys()) - set(sw_keys))
    error_message = 'Cannot find key handle for selected width'
    for optional_keys in _subsets(reserved_keys):
        keys_to_check = sw_keys + optional_keys
        try:
            hw_keys, width, key_blocks = scp_calc(keys_to_check)
            if not optional_keys and width > width_to_match:
                error_message = 'Minimum width for selected keys is %d' % width
                break
            if width == width_to_match:
                return keys_to_check, hw_keys, width, key_blocks

        except ScpCalculatorError:
            pass
    raise ScpCalculatorError(error_message)


class KeysDBError(Exception):
    pass


class KeysDB(object):
    def __init__(self, json_files):
        self._db = {}
        with open(JSON_PATH_PREFIX + json_files[0], 'r') as f:
            self._db[SW_KEYS] = json.load(f)
            print((json_files[0] + ": opened succesfully"))
        with open(JSON_PATH_PREFIX + json_files[1], 'r') as f:
            self._db[SW_HW_KEYS] = json.load(f)
            print((json_files[1] + ": opened succesfully"))
        with open(JSON_PATH_PREFIX + json_files[2], 'r') as f:
            self._db[HW_KEY_BLOCKS] = json.load(f)
            print((json_files[2] + ": opened succesfully"))

    def are_blocks_enough(self, hw_keys, blocks):
        for hw_key in hw_keys:
            key_found = False
            for block in blocks:
                if hw_key in self._db[HW_KEY_BLOCKS][block]['hw_keys']:
                    key_found = True
                    break
            if not key_found:
                return False
        return True

    def sw_to_hw_keys(self, sw_keys):
        res = []
        for sw_key in sw_keys:
            res += self._db[SW_HW_KEYS][sw_key]
        return list(set(res))

    def get_relevant_blocks(self, hw_keys):
        relevant_blocks = []
        for i, block_dict in enumerate(self._db[HW_KEY_BLOCKS]):
            if set(hw_keys) & set(block_dict['hw_keys']):
                relevant_blocks.append(i)
        return relevant_blocks

    def get_sw_keys(self):
        return list(self._db[SW_KEYS].keys())

    def get_sw_key_desc(self, sw_key):
        return self._db[SW_KEYS][sw_key]['Description']

    def get_blocks_names(self, blocks):
        return [self._db[HW_KEY_BLOCKS][i]['Name'] for i in blocks]

    def get_block_hw_keys(self, block_name):
        for block in self._db[HW_KEY_BLOCKS]:
            if block['Name'] == block_name:
                return block['hw_keys']
        raise KeysDBError()


class ImageDialog(QtGui.QDialog):
    def __init__(self):

        QtGui.QDialog.__init__(self)

        # Set up the user interface from Designer.
        self.ui = uic.loadUi(JSON_PATH_PREFIX + "../acl_designer/acl5.ui")

        self.connect(self.ui.delete_selected, QtCore.SIGNAL("clicked()"), self.remove_selected)

        self.ui.sw_keys.addItems(keys_db.get_sw_keys())

        self.ui.sw_keys.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.ui.sw_keys.customContextMenuRequested.connect(self.right_button_sw_keys)

        self.ui.hw_key_blocks.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.ui.hw_key_blocks.customContextMenuRequested.connect(self.right_button_hw_key_blocks)
        self.ui.clear.clicked.connect(lambda: self.clear())

        self.ui.build.clicked.connect(lambda: self.build())
        self.ui.update.clicked.connect(lambda: self.update())

        self.ui.show()

    def remove_selected(self):
        for item in self.ui.selected_sw_keys.selectedItems():
            self.ui.selected_sw_keys.takeItem(self.ui.selected_sw_keys.row(item))

    def right_button_sw_keys(self, pos):
        menu = QtGui.QMenu()
        menu.addAction('Get Description', lambda: self.get_description())
        menu.exec_(QtGui.QCursor.pos())

    def right_button_hw_key_blocks(self, pos):
        menu = QtGui.QMenu()
        menu.addAction('Get all HW keys in block', lambda: self.get_hw_keys())
        menu.exec_(QtGui.QCursor.pos())

    def get_description(self):
        key = self.ui.sw_keys.currentItem().text()
        QtGui.QMessageBox.information(self, 'SW Key Description',
                                      keys_db.get_sw_key_desc(str(key)),
                                      QtGui.QMessageBox.Ok)

    def get_hw_keys(self):
        block = self.ui.hw_key_blocks.currentItem().text()
        hw_keys = keys_db.get_block_hw_keys(str(block))
        QtGui.QMessageBox.information(self, 'HW Keys',
                                      "\n".join(hw_keys),
                                      QtGui.QMessageBox.Ok)

    def clear(self, clear_selected_width=True):
        self.ui.hw_key_blocks.clear()
        self.ui.hw_keys.clear()
        self.ui.key_handle.clear()
        self.ui.width.setText('Calculated width:')
        if clear_selected_width:
            index = self.ui.selected_width.findText('min', QtCore.Qt.MatchFixedString)
            self.ui.selected_width.setCurrentIndex(index)

    def update(self):
        global CHIP_TYPE
        global MAX_KEY_BLOCKS
        global KEY_BLOCK_WIDTH

        selected_chip = str(self.ui.selected_chip.currentText())

        if selected_chip == 'Spectrum':
            CHIP_TYPE = 'spectrum'
            MAX_KEY_BLOCKS = 6
            KEY_BLOCK_WIDTH = 9
            keys_db = KeysDB(JSON_FILES_SPC)

        elif selected_chip == 'Spectrum2':
            CHIP_TYPE = 'spectrum2'
            MAX_KEY_BLOCKS = 12
            KEY_BLOCK_WIDTH = 4.5
            keys_db = KeysDB(JSON_FILES_SPC2)
            keys_db_update(keys_db)

        elif selected_chip == 'Spectrum3':
            CHIP_TYPE = 'spectrum3'
            MAX_KEY_BLOCKS = 12
            KEY_BLOCK_WIDTH = 4.5
            keys_db = KeysDB(JSON_FILES_SPC3)
            keys_db_update(keys_db)

        self.ui.selected_sw_keys.clear()
        self.ui.sw_keys.clear()
        self.ui.hw_key_blocks.clear()
        self.ui.hw_keys.clear()
        self.ui.key_handle.clear()
        self.ui.sw_keys.addItems(keys_db.get_sw_keys())

    def build(self):
        self.clear(False)
        selected_sw_keys = [str(self.ui.selected_sw_keys.item(i).text()) for i in range(self.ui.selected_sw_keys.count())]
        selected_width = str(self.ui.selected_width.currentText())

        try:
            if selected_width == 'min':    # if MIN
                key_handle = selected_sw_keys
                hw_keys, width, key_blocks = scp_calc(selected_sw_keys)
            else:
                key_handle, hw_keys, width, key_blocks = scp_calc_match_width(selected_sw_keys, int(selected_width))

            for key in key_handle:
                item = QtGui.QListWidgetItem(key)
                if key not in selected_sw_keys:
                    item.setBackground(QtGui.QColor('#7fc97f'))
                self.ui.key_handle.addItem(item)
            self.ui.hw_key_blocks.addItems(key_blocks)
            self.ui.width.setText('Calculated width: %d' % width)
            self.ui.hw_keys.addItems(hw_keys)
        except ScpCalculatorError as e:
            QtGui.QMessageBox.warning(self, 'ACL Designer', e.message, QtGui.QMessageBox.Ok)
        except Exception as e:
            QtGui.QMessageBox.critical(window, 'ACL Designer',
                                       "Exception raised during build:\n%s" % e.message,
                                       QtGui.QMessageBox.Ok)
            raise


if __name__ == "__main__":
    keys_db = KeysDB(JSON_FILES_SPC)
    app = QtGui.QApplication(sys.argv)
    window = ImageDialog()
    sys.exit(app.exec_())
