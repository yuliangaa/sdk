/*
 * Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include "flex_acl_hw.h"
#include "cJSON.h"

#undef  __MODULE__
#define __MODULE__ DBG_UTILS

/************************************************
 *  Local variables
 ***********************************************/

extern char                    * hw_key_dictionary[];
extern char                    * key_dictionary[];
extern flex_acl_key_map_data_t   flex1_acl_key_map[];
extern flex_acl_key_map_data_t   flex2_acl_key_map[];
extern flex_acl_key_block_data_t key_block_data_dictionary[];
extern char                    * key_block_dictionary[];

int generate_sw_keys(void)
{
    int    iii;
    cJSON *root = cJSON_CreateObject();
    FILE  *fp;

    for (iii = 0; iii < FLEX_ACL_KEY_LAST; iii++) {
        if (key_dictionary[iii] != NULL) {
            cJSON *key_data = cJSON_CreateObject();
            int    key_id = iii;
            int    size = 32;
            cJSON_AddNumberToObject(key_data, "Id", key_id);
            cJSON_AddStringToObject(key_data, "Description", "Description");
            cJSON_AddNumberToObject(key_data, "Size", size);


            cJSON_AddItemToObject(root, key_dictionary[iii], key_data);
        }
    }


    fp = fopen("sw_keys.json", "w");
    fprintf(fp, "%s", cJSON_Print(root));
    fclose(fp);

    cJSON_Delete(root);

    printf("sw_keys.json done\n");
    return 0;
}

int generate_sw_hw_keys(flex_acl_key_map_data_t* key_map, int chip)
{
    if ((chip < 1) || (chip > 3)) {
        printf("generate_sw_hw_keys failed - wrong chip type\n");
        return 1;
    }

    int    iii, jjj;
    cJSON *root = cJSON_CreateObject();
    FILE  *fp;

    for (iii = 0; iii < FLEX_ACL_KEY_LAST; iii++) {
        if (key_dictionary[iii] != NULL) {
            cJSON *hw_key_list = cJSON_CreateArray();

            for (jjj = 0; jjj < key_map[iii].hw_keys_cnt; jjj++) {
                char * hw_key_name = hw_key_dictionary[key_map[iii].hw_keys[jjj]];

                cJSON_AddItemToArray(hw_key_list, cJSON_CreateString(hw_key_name));
            }

            cJSON_AddItemToObject(root, key_dictionary[iii], hw_key_list);
        }
    }


    if (chip == 1) {
        fp = fopen("sw_hw_keys_spectrum.json", "w");
    } else if (chip == 2) {
        fp = fopen("sw_hw_keys_spectrum2.json", "w");
    } else { /* chip == 3 */
        fp = fopen("sw_hw_keys_spectrum3.json", "w");
    }

    fprintf(fp, "%s", cJSON_Print(root));
    fclose(fp);

    cJSON_Delete(root);
    if (chip == 1) {
        printf("sw_hw_keys_spectrum.json done\n");
    } else if (chip == 2) {
        printf("sw_hw_keys_spectrum2.json done\n");
    } else { /* chip == 3 */
        printf("sw_hw_keys_spectrum3.json done\n");
    }

    return 0;
}

int generate_hw_key_blocks(int chip)
{
    if ((chip < 1) || (chip > 3)) {
        printf("generate_hw_key_blocks failed - wrong chip type\n");
        return 1;
    }
    int    iii, jjj;
    cJSON *root = cJSON_CreateArray();
    FILE  *fp;
    int    hw_key_stages = chip;

    if (chip == 3) {
        hw_key_stages = 2;
    }

    for (iii = 0; iii < FLEX_ACL_KEY_BLOCK_LAST_E; iii++) {
        if ((key_block_dictionary[iii] != NULL) &&
            (key_block_data_dictionary[iii].hw_key_stages == hw_key_stages)) {
            /* printf("%d: \t %s\n",iii,key_block_dictionary[iii]); */
            cJSON *hw_block_data = cJSON_CreateObject();
            char  *key_block_name = key_block_dictionary[iii];
            cJSON_AddStringToObject(hw_block_data, "Name", key_block_name);

            cJSON *hw_key_list = cJSON_CreateArray();

            for (jjj = 0; jjj < key_block_data_dictionary[iii].key_block_items_count; jjj++) {
                int    hw_key_id = key_block_data_dictionary[iii].key_block_items[jjj].key_id;
                char * hw_key_name = hw_key_dictionary[hw_key_id];

                cJSON_AddItemToArray(hw_key_list, cJSON_CreateString(hw_key_name));
            }

            cJSON_AddItemToObject(hw_block_data, "hw_keys", hw_key_list);

            cJSON_AddItemToArray(root, hw_block_data);
        }
    }

    if (chip == 1) {
        fp = fopen("hw_key_blocks_spectrum.json", "w");
    } else if (chip == 2) {
        fp = fopen("hw_key_blocks_spectrum2.json", "w");
    } else { /* chip 3 */
        fp = fopen("hw_key_blocks_spectrum3.json", "w");
    }

    fprintf(fp, "%s", cJSON_Print(root));
    fclose(fp);

    cJSON_Delete(root);

    if (chip == 1) {
        printf("hw_key_blocks_spectrum.json done\n");
    } else if (chip == 2) {
        printf("hw_key_blocks_spectrum2.json done\n");
    } else { /* chip 3 */
        printf("hw_key_blocks_spectrum3.json done\n");
    }

    return 0;
}

int main(int argc, char *argv[])
{
    generate_sw_keys();
    generate_sw_hw_keys(flex1_acl_key_map, 1);
    generate_sw_hw_keys(flex2_acl_key_map, 2);
    generate_sw_hw_keys(flex2_acl_key_map, 3);
    generate_hw_key_blocks(1);
    generate_hw_key_blocks(2);
    generate_hw_key_blocks(3);
    return 0;
}
