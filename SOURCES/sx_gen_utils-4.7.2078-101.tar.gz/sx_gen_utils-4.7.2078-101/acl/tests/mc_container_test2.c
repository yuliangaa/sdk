/*
 * Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api_init.h>
#include <arpa/inet.h>
#include <sx/sdk/sx_api_flow_counter.h>
#include <sx/sdk/sx_api_lag.h>
#include <sx/sdk/sx_api_mc_container.h>
#include <sx/sdk/sx_api_vlan.h>
#include "sx/sdk/sx_strings.h"

#define LOG(format, ...) printf("%s[%d]:" format, __func__, __LINE__, ## __VA_ARGS__)

int main(int argc, char *argv[])
{
    sx_api_handle_t              api_handle;
    sx_status_t                  sx_status;
    sx_port_log_id_t             port_list[] = {0x10001, 0x10009, 0x10005};
    sx_mc_container_id_t         container_id;
    sx_mc_next_hop_t             next_hop_list[1];
    sx_mc_container_attributes_t container_attr;

    UNUSED_PARAM(port_list);

    /* Open SDK */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    LOG("SDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);

    /* Create MC container with 1 port */
    next_hop_list[0].type = SX_MC_NEXT_HOP_TYPE_LOG_PORT;
    next_hop_list[0].data.log_port = port_list[0];
    container_attr.type = SX_MC_CONTAINER_TYPE_BRIDGE_MC;
    container_attr.fid = 1;
    sx_status = sx_api_mc_container_set(api_handle, SX_ACCESS_CMD_CREATE, &container_id, next_hop_list, 1,
                                        &container_attr);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_mc_container_set CREATE failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    LOG("SDK API: MC container %#x created with port %#x. \n", container_id, port_list[0]);

    /* Add 2nd port to MC container */
    next_hop_list[0].type = SX_MC_NEXT_HOP_TYPE_LOG_PORT;
    next_hop_list[0].data.log_port = port_list[1];
    container_attr.type = SX_MC_CONTAINER_TYPE_BRIDGE_MC;
    container_attr.fid = 1;
    sx_status = sx_api_mc_container_set(api_handle, SX_ACCESS_CMD_ADD, &container_id, next_hop_list, 1,
                                        &container_attr);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_mc_container_set CREATE failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    LOG("SDK API: MC container %#x created with port %#x. \n", container_id, port_list[0]);


    /* Destroy MC container */
    sx_status = sx_api_mc_container_set(api_handle, SX_ACCESS_CMD_DESTROY, &container_id, NULL, 0,
                                        &container_attr);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_mc_container_set DESTROY failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    LOG("SDK API: MC container %#x destroyed. \n", container_id);

    sx_status = sx_api_close(&api_handle);

    return 0;
}
