/*
 * Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <complib/sx_log.h>
#include <sx/sdk/sx_api_init.h>
#include <arpa/inet.h>
#include <sx/sdk/sx_api_flow_counter.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include "sx/sdk/sx_strings.h"

#define LOG(format, ...) printf("%s[%d]:" format, __func__, __LINE__, ## __VA_ARGS__)

int main(int argc, char *argv[])
{
    sx_api_handle_t                      api_handle;
    sx_status_t                          sx_status;
    sx_acl_custom_bytes_set_attributes_t custom_bytes_set_attributes;
    sx_acl_key_t                         custom_bytes_set_key_id[16];
    uint32_t                             custom_bytes_set_key_id_cnt = sizeof(custom_bytes_set_key_id) /
                                                                       sizeof(custom_bytes_set_key_id[0]);
    int                                iii;
    sx_router_general_param_t          general_params;
    sx_router_resources_param_t        router_resource;
    sx_port_log_id_t                   log_port = 0x10001;
    sx_router_ecmp_port_hash_params_t  ecmp_hash_params;
    sx_router_ecmp_hash_field_enable_t hash_field_enable_list[1];

    memset(&general_params, 0, sizeof(general_params));
    memset(&router_resource, 0, sizeof(router_resource));

    /* Open SDK */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_open failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    LOG("SDK API: opened API handle: 0x%" PRIx64 "\n", api_handle);

    LOG("Allocating Custom bytes set for [L2_START_OF_HEADER]. Allocated size:%d\n", custom_bytes_set_key_id_cnt);
    custom_bytes_set_attributes.extraction_point.extraction_group_type = SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_L2;
    custom_bytes_set_attributes.extraction_point.params.extraction_l2_group.extraction_l2.extraction_point_type =
        SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_L2_ETHER_TYPE;
    custom_bytes_set_attributes.extraction_point.params.extraction_l2_group.extraction_l2.offset = 12;

    sx_status = sx_api_acl_custom_bytes_set(api_handle, SX_ACCESS_CMD_CREATE, &custom_bytes_set_attributes,
                                            custom_bytes_set_key_id, &custom_bytes_set_key_id_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_acl_custom_bytes_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    LOG("SDK API: sx_api_acl_custom_bytes_set done. Allocated custom bytes set size:%d \n",
        custom_bytes_set_key_id_cnt);

    for (iii = 0; iii < custom_bytes_set_key_id_cnt; iii++) {
        LOG("\tCustom byte key ID[%d]: %d(%#x) \n", iii, custom_bytes_set_key_id[iii], custom_bytes_set_key_id[iii]);
    }

    /* Router Init */
    general_params.ipv4_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.ipv4_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.ipv6_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.ipv6_mc_enable = SX_ROUTER_ENABLE_STATE_ENABLE;
    general_params.rpf_enable = FALSE;

    router_resource.max_virtual_routers_num = 12;
    router_resource.max_router_interfaces = 16;
    router_resource.min_ipv4_neighbor_entries = 10;
    router_resource.min_ipv6_neighbor_entries = 10;
    router_resource.min_ipv4_uc_route_entries = 10;
    router_resource.min_ipv6_uc_route_entries = 10;
    router_resource.min_ipv4_mc_route_entries = 0;
    router_resource.min_ipv6_mc_route_entries = 0;
    router_resource.max_ipv4_neighbor_entries = 1000;
    router_resource.max_ipv6_neighbor_entries = 1000;
    router_resource.max_ipv4_uc_route_entries = 1000;
    router_resource.max_ipv6_uc_route_entries = 1000;
    router_resource.max_ipv4_mc_route_entries = 0;
    router_resource.max_ipv6_mc_route_entries = 0;

    sx_status = sx_api_router_init_set(api_handle, &general_params, &router_resource);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_router_init_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    LOG("SDK API: sx_api_router_init_set done. \n");

    ecmp_hash_params.ecmp_hash_type = SX_ROUTER_ECMP_HASH_TYPE_CRC;
    ecmp_hash_params.symmetric_hash = TRUE;
    ecmp_hash_params.seed = 0;

    /* custom_bytes_set_key_id[1]=FLEX_ACL_KEY_CUSTOM_BYTE_15; */

    sx_status = sx_api_router_ecmp_port_hash_params_set(api_handle, SX_ACCESS_CMD_ADD, log_port,
                                                        &ecmp_hash_params,
                                                        hash_field_enable_list,
                                                        0,
                                                        custom_bytes_set_key_id,
                                                        custom_bytes_set_key_id_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_router_ecmp_port_hash_params_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    LOG("SDK API: sx_api_router_ecmp_port_hash_params_set done. \n");

#if 0
    sx_status = sx_api_router_deinit_set(api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_router_deinit_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    LOG("SDK API: sx_api_router_deinit_set done. \n");
#endif

    return 0;
}
