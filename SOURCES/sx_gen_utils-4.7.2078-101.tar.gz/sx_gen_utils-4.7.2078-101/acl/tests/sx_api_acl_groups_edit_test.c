/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <getopt.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_dbg.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_trap_id.h>
#include <complib/sx_log.h>
#include <arpa/inet.h>
#include "sx/sdk/sx_strings.h"

/*
 * Example of FLEX ACL rules creation/deletion
 */

/*
 * Local test definitions
 */


static struct option long_options[] = {
    {"verbosity_level",         required_argument,  NULL,   'v'                       },
    {"help",                    no_argument,        NULL,   'h'                       },
    {0,                         0,                  0,      0                         },
};
static void __show_help()
{
    printf("\tOptions:\n"
           "\t--verbosity_level <NONE=0,ERROR=1,WARNING=2,NOTICE=3,INFO=4,  - ACL verbosity level\n"
           "\t                   DEBUG=5,FUNCS=6,FRAMES=7,ALL=8>\n"
           "\t(-h|--help)                                                   - show this help message and exit.\n");
    exit(0);
}

sx_verbosity_level_t verbosity_level = SX_VERBOSITY_LEVEL_NOTICE;


#define LOG(format, ...) printf("%s[%d]:" format, __func__, __LINE__, ## __VA_ARGS__)

#define NUM_RULES 15
#define NUM_ACLS  2

sx_acl_key_t key_id_set_example[] = {
    FLEX_ACL_KEY_DMAC,
    FLEX_ACL_KEY_SMAC,
    FLEX_ACL_KEY_ETHERTYPE,
    FLEX_ACL_KEY_VLAN_ID,
    FLEX_ACL_KEY_DIP,
    FLEX_ACL_KEY_SIP,
    FLEX_ACL_KEY_IP_PROTO,
    FLEX_ACL_KEY_TTL,
    FLEX_ACL_KEY_L4_DESTINATION_PORT,
    FLEX_ACL_KEY_L4_SOURCE_PORT
};
int          num_keys_ex = sizeof(key_id_set_example) / sizeof(key_id_set_example[0]);

int get_options(int argc, char **argv)
{
    int rc = 0;
    int c;

    while (1) {
        int option_index = 0;

        c = getopt_long(argc, argv, "h", long_options, &option_index);

        /* Detect the end of the options. */
        if (c == -1) {
            break;
        }

        switch (c) {
        case 'v':
            rc = sscanf(optarg, "%u", &verbosity_level);
            LOG("\t\t Verbosity level: %s(%u)\n\n", SX_VERBOSITY_LEVEL_STR(verbosity_level), verbosity_level);
            break;

        case 'h':
        case '?':
        default:
            /* getopt_long already printed an error message. */
            __show_help();
            return 1;
        }

        if (rc != 1) {
            LOG("COMMAND LINE PARAMETERS ERROR\n");
            __show_help();
            return 1;
        }
    }

    return 0;
}

static sx_status_t __create_user_key_region_acl_group(sx_api_handle_t     api_handle,
                                                      sx_acl_key_type_t  *key_handle_p,
                                                      sx_acl_region_id_t *region_id_p,
                                                      sx_acl_id_t        *acl_id_p,
                                                      sx_acl_id_t        *acl_group_id_p)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    sx_acl_region_group_t acl_region_group;
    sx_acl_id_t           acl_id_list[1];

    LOG("CREATING user key, region, ACL and ACL group \n");

    if (key_handle_p) {
        /* Create key handle */
        sx_status = sx_api_acl_flex_key_set(api_handle,
                                            SX_ACCESS_CMD_CREATE,
                                            key_id_set_example,
                                            num_keys_ex,
                                            key_handle_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
            return sx_status;
        }
    }

    if (region_id_p) {
        /* Create region */
        sx_status = sx_api_acl_region_set(api_handle,
                                          SX_ACCESS_CMD_CREATE,
                                          *key_handle_p,
                                          SX_ACL_ACTION_TYPE_EXTENDED,
                                          NUM_RULES,
                                          region_id_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
            return sx_status;
        }
    }

    if (acl_id_p) {
        /* Create ACL */
        acl_region_group.regions.acl_packet_agnostic.region = *region_id_p;
        sx_status = sx_api_acl_set(api_handle,
                                   SX_ACCESS_CMD_CREATE,
                                   SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                   SX_ACL_DIRECTION_INGRESS,
                                   &acl_region_group,
                                   acl_id_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
            return sx_status;
        }
    }

    if (acl_group_id_p) {
        /* Create ACL group */
        sx_status = sx_api_acl_group_set(api_handle,
                                         SX_ACCESS_CMD_CREATE,
                                         SX_ACL_DIRECTION_INGRESS,
                                         acl_id_list,
                                         0,
                                         acl_group_id_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            return sx_status;
        }

        acl_id_list[0] = *acl_id_p;
        sx_status = sx_api_acl_group_set(api_handle,
                                         SX_ACCESS_CMD_SET,
                                         SX_ACL_DIRECTION_INGRESS,
                                         acl_id_list,
                                         1,
                                         acl_group_id_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            return sx_status;
        }
    }

    LOG("CREATED user key:%d, region:%#x, ACL:%#x and ACL group:%#x \n",
        (key_handle_p != NULL) ? *key_handle_p : 0,
        (region_id_p != NULL) ? *region_id_p : 0,
        (acl_id_p != NULL) ? *acl_id_p : 0,
        (acl_group_id_p != NULL) ? *acl_group_id_p : 0);

    return SX_STATUS_SUCCESS;
}

static sx_status_t __delete_user_key_region_acl_group(sx_api_handle_t     api_handle,
                                                      sx_acl_key_type_t  *key_handle_p,
                                                      sx_acl_region_id_t *region_id_p,
                                                      sx_acl_id_t        *acl_id_p,
                                                      sx_acl_id_t        *acl_group_id_p)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    sx_acl_region_group_t acl_region_group;
    sx_acl_id_t           acl_id_list[1];

    LOG("DELETING user key:%d, region:%#x, ACL:%#x and ACL group:%#x \n",
        (key_handle_p != NULL) ? *key_handle_p : 0,
        (region_id_p != NULL) ? *region_id_p : 0,
        (acl_id_p != NULL) ? *acl_id_p : 0,
        (acl_group_id_p != NULL) ? *acl_group_id_p : 0);

    if (acl_group_id_p) {
        /* ACL group */
        sx_status = sx_api_acl_group_set(api_handle,
                                         SX_ACCESS_CMD_DESTROY,
                                         SX_ACL_DIRECTION_INGRESS,
                                         acl_id_list,
                                         0,
                                         acl_group_id_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            return sx_status;
        }
    }

    if (acl_id_p) {
        /* ACL */
        acl_region_group.regions.acl_packet_agnostic.region = *region_id_p;
        sx_status = sx_api_acl_set(api_handle,
                                   SX_ACCESS_CMD_DESTROY,
                                   SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                   SX_ACL_DIRECTION_INGRESS,
                                   &acl_region_group,
                                   acl_id_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
            return sx_status;
        }
    }

    if (region_id_p) {
        /* Region */
        sx_status = sx_api_acl_region_set(api_handle,
                                          SX_ACCESS_CMD_DESTROY,
                                          *key_handle_p,
                                          SX_ACL_ACTION_TYPE_EXTENDED,
                                          NUM_RULES,
                                          region_id_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
            return sx_status;
        }
    }

    if (key_handle_p) {
        /* Key handle */
        sx_status = sx_api_acl_flex_key_set(api_handle,
                                            SX_ACCESS_CMD_DELETE,
                                            key_id_set_example,
                                            num_keys_ex,
                                            key_handle_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
            return sx_status;
        }
    }

    LOG("DELETED user key:%d, region:%#x, ACL:%#x and ACL group:%#x \n",
        (key_handle_p != NULL) ? *key_handle_p : 0,
        (region_id_p != NULL) ? *region_id_p : 0,
        (acl_id_p != NULL) ? *acl_id_p : 0,
        (acl_group_id_p != NULL) ? *acl_group_id_p : 0);

    return SX_STATUS_SUCCESS;
}

int main(int argc, char **argv)
{
    sx_status_t        sx_status;
    char             * sdkdump_fname = "/tmp/test_sdk.dump";
    sx_api_handle_t    api_handle;
    sx_acl_key_type_t  key_handle[NUM_ACLS];
    sx_acl_region_id_t region_id[NUM_ACLS];
    sx_acl_id_t        acl_id[NUM_ACLS];
    sx_acl_id_t        acl_group_id[NUM_ACLS];
    int                iii;
    sx_port_log_id_t   log_port[] = {0x10001, 0x10003};

    if (get_options(argc, argv)) {
        goto out;
    }

    /* Open SDK API */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status =
        sx_api_acl_log_verbosity_level_set(api_handle, SX_LOG_VERBOSITY_BOTH, verbosity_level, verbosity_level);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: sx_api_acl_log_verbosity_level_set failed. [%s]\n", sx_status_str(sx_status));
        goto out;
    }

    for (iii = 0; iii < NUM_ACLS; iii++) {
        LOG("i=%d\n", iii);
        sx_status = __create_user_key_region_acl_group(api_handle, &key_handle[iii], &region_id[iii],
                                                       &acl_id[iii], iii == 0 ? &acl_group_id[iii] : NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: __create_user_key_region_acl_group failed. iii=%d. [%s]\n", iii, sx_status_str(sx_status));
            goto out;
        }
    }

    /* Bind group [0] to port[0] */
    sx_status = sx_api_acl_port_bind_set(api_handle,
                                         SX_ACCESS_CMD_BIND,
                                         log_port[0],
                                         acl_group_id[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_acl_port_bind_set failed. [%s] ACL group:%#x port:%#x\n"
            , sx_status_str(sx_status), acl_group_id[0], log_port[0]);
        goto out;
    }
    LOG("ACL group %#x bound to port %#x\n", acl_group_id[0], log_port[0]);

    /* Edit - add ACL[1] to ACL group[0] */
    {
        sx_acl_id_t acl_id_list[2] = {acl_id[0], acl_id[1]};

        LOG("Adding ACL IDs %#x and %#x to ACL group %#x \n", acl_id_list[0], acl_id_list[1], acl_group_id[0]);

        sx_status = sx_api_acl_group_set(api_handle,
                                         SX_ACCESS_CMD_SET,
                                         SX_ACL_DIRECTION_INGRESS,
                                         acl_id_list,
                                         2,
                                         &acl_group_id[0]);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            return sx_status;
        }
    }

    /* CREATE DEBUG DUMP *****/
    sx_status = sx_api_dbg_generate_dump(api_handle, sdkdump_fname);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_dbg_generate_dump [%s] failed [%s]\n", sdkdump_fname, sx_status_str(sx_status));
        goto out;
    }
    LOG("SDK DEBUG DUMP CREATED AT: %s\n\n", sdkdump_fname);

    /* START CLEANUP */

    /* UNBind group [0] to port[0] */
    sx_status = sx_api_acl_port_bind_set(api_handle,
                                         SX_ACCESS_CMD_UNBIND,
                                         log_port[0],
                                         acl_group_id[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_acl_port_unbind_set failed. [%s] ACL group:%#x port:%#x\n"
            , sx_status_str(sx_status), acl_group_id[0], log_port[0]);
        goto out;
    }
    LOG("ACL group %#x unbound from port %#x\n", acl_group_id[0], log_port[0]);

    for (iii = 0; iii < NUM_ACLS; iii++) {
        sx_status = __delete_user_key_region_acl_group(api_handle, &key_handle[iii], &region_id[iii],
                                                       &acl_id[iii], iii == 0 ? &acl_group_id[iii] : NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            LOG("ERROR: __delete_user_key_region_acl_group failed. iii=%d [%s]\n", iii, sx_status_str(sx_status));
            goto out;
        }
    }

out:
    /* Close SDK API */
    sx_status = sx_api_close(&api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        LOG("ERROR: SDK API sx_api_open failed. [%s]\n", sx_status_str(sx_status));
    }

    LOG("Finished with status: %s\n", sx_status_str(sx_status));
    return sx_status;
}
