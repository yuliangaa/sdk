/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flow_counter.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_dbg.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_trap_id.h>
#include <complib/sx_log.h>
#include <arpa/inet.h>
#include "sx/sdk/sx_strings.h"

/*
 * Example of FLEX ACL rules creation/deletion
 */

/*
 * Local test definitions
 */
#define NUM_RULES 1
#define SWID      0

static char * api_action_short[SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST + 1] = {
    [SX_FLEX_ACL_ACTION_FORWARD] = "FWD",
    [SX_FLEX_ACL_ACTION_TRAP] = "TRAP",
    [SX_FLEX_ACL_ACTION_COUNTER] = "CNTR",
    [SX_FLEX_ACL_ACTION_MIRROR] = "MIRR",
    [SX_FLEX_ACL_ACTION_EGRESS_MIRROR] = "EGMIRR",
    [SX_FLEX_ACL_ACTION_POLICER] = "POLCR",
    [SX_FLEX_ACL_ACTION_SET_PRIO] = "PRIO",
    [SX_FLEX_ACL_ACTION_SET_VLAN] = "VLAN",
    [SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI] = "INVPRI",
    [SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI] = "OUVPRI",
    [SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID] = "INVID",
    [SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID] = "OUVID",
    [SX_FLEX_ACL_ACTION_SET_SRC_MAC] = "SMAC",
    [SX_FLEX_ACL_ACTION_SET_DST_MAC] = "DMAC",
    [SX_FLEX_ACL_ACTION_SET_DSCP] = "DSCP",
    [SX_FLEX_ACL_ACTION_SET_BRIDGE] = "BRDG",
    [SX_FLEX_ACL_ACTION_PBS] = "PBS",
    [SX_FLEX_ACL_ACTION_SET_TC] = "TC",
    [SX_FLEX_ACL_ACTION_DEC_TTL] = "DECTTL",
    [SX_FLEX_ACL_ACTION_SET_TTL] = "TTL",
    [SX_FLEX_ACL_ACTION_SET_COLOR] = "CLR",
    [SX_FLEX_ACL_ACTION_SET_ECN] = "ECN",
    [SX_FLEX_ACL_ACTION_SET_USER_TOKEN] = "USRTKN",
    [SX_FLEX_ACL_ACTION_DONT_LEARN] = "DNTLRN",
    [SX_FLEX_ACL_ACTION_TUNNEL_DECAP] = "TUNDCP",
    [SX_FLEX_ACL_ACTION_GOTO] = "GOTO",
    [SX_FLEX_ACL_ACTION_RPF] = "RPF",
    [SX_FLEX_ACL_ACTION_MC_ROUTE] = "MCROUT",
    [SX_FLEX_ACL_ACTION_SET_ROUTER] = "ROUTER",
    [SX_FLEX_ACL_ACTION_MC] = "MCPBS",
    [SX_FLEX_ACL_ACTION_UC_ROUTE] = "UCROUT",
    [SX_FLEX_ACL_ACTION_SET_DSCP_REWRITE] = "DSCPRW",
    [SX_FLEX_ACL_ACTION_SET_PCP_REWRITE] = "PCPRW",
    [SX_FLEX_ACL_ACTION_IGNORE_EGRESS_VLAN_FILTER] = "IGEVFL",
    [SX_FLEX_ACL_ACTION_IGNORE_EGRESS_STP_FILTER] = "IGESTP",
    [SX_FLEX_ACL_ACTION_DISABLE_OVERLAY_LEARNING] = "DISOVLN",
    [SX_FLEX_ACL_ACTION_PORT_FILTER] = "PRTFLT",
    [SX_FLEX_ACL_ACTION_PORT_FILTER] = "TRUNC",
    [SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST] = "LAST",
};
#define API_ACT_2SHORT(act_type)                                \
    (((act_type) > SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST) ? "***" : \
     (api_action_short[act_type] ? : "###"))


void set_rules_example(sx_flex_acl_flex_rule_t *rules);

sx_acl_key_t         key_id_set_example[] = {
    FLEX_ACL_KEY_DIP,
    FLEX_ACL_KEY_SIP,
};
sx_acl_key_fields_t  key_value_set_example[] = {
    {.dip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xC0A8FA02}
             }
     }
    },
    {.sip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xC0A8FA01}
             }
     }
    },
};
sx_acl_mask_fields_t key_mask_set_example[] = {
    {.dip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xFFFFFFFF}
             }
     }
    },
    {.sip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xFFFFFFFF}
             }
     }
    },
};

enum {
    PBS_OUT_UC_1,
    PBS_OUT_UC_2,
    PBS_OUT_UC_3,
    PBS_UC_1,
    PBS_NUM,
};

enum {
    COUNTER_1,
    COUNTER_NUM,
};

typedef struct pbs_entry {
    sx_acl_pbs_id_t         pbs_id;
    sx_port_log_id_t        pbs_port;
    sx_acl_pbs_entry_type_t entry_type;
} pbs_entry_t;

pbs_entry_t               pbs_entry_db_g[PBS_NUM];
int                       num_pbs_db = PBS_NUM;
sx_acl_pbs_id_t           counters_g[COUNTER_NUM];
int                       num_counters = COUNTER_NUM;
sx_flex_acl_flex_action_t action_set_example[] = {
/*    {.type = SX_FLEX_ACL_ACTION_TRAP, .fields = */
/*        {.action_trap = {.action = SX_ACL_TRAP_ACTION_TYPE_TRAP, .trap_id = SX_TRAP_ID_ACL_MIN} */
/*        } */
/*    }, // TRAP */
    {.type = SX_FLEX_ACL_ACTION_COUNTER, .fields =
     {.action_counter = {.counter_id = COUNTER_1}
     }
    }, /* COUNTER */
    {.type = SX_FLEX_ACL_ACTION_SET_VLAN, .fields =
     {.action_set_vlan = {.cmd = SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH, .vlan_id = 1103}
     }
    }, /* VLAN */
/*    {.type = SX_FLEX_ACL_ACTION_FORWARD, .fields = */
/*        {.action_forward = {.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD} */
/*        } */
/*    }, // FORWARD */
    {.type = SX_FLEX_ACL_ACTION_PBS, .fields =
     {.action_pbs = {.pbs_id = PBS_OUT_UC_1}
     }
    }, /* OUTPUT */
    {.type = SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID, .fields =
     {.action_set_outer_vlan_id = {.vlan_id = 1121}
     }
    }, /* VLAN */
    {.type = SX_FLEX_ACL_ACTION_PBS, .fields =
     {.action_pbs = {.pbs_id = PBS_OUT_UC_2}
     }
    }, /* OUTPUT */
    {.type = SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID, .fields =
     {.action_set_outer_vlan_id = {.vlan_id = 1123}
     }
    }, /* VLAN */
    {.type = SX_FLEX_ACL_ACTION_PBS, .fields =
     {.action_pbs = {.pbs_id = PBS_OUT_UC_3}
     }
    }, /* OUTPUT */
    {.type = SX_FLEX_ACL_ACTION_PBS, .fields =
     {.action_pbs = {.pbs_id = PBS_UC_1}
     }
    }, /* PBS */
    {.type = SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID, .fields =
     {.action_set_outer_vlan_id = {.vlan_id = 1199}
     }
    }, /* VLAN */
};
int                       num_keys_ex = sizeof(key_id_set_example) / sizeof(key_id_set_example[0]);
int                       num_actions_ex = sizeof(action_set_example) / sizeof(action_set_example[0]);
sx_flex_acl_flex_rule_t   rules_example[NUM_RULES];
sx_acl_rule_offset_t      offset_list_example[NUM_RULES];

sx_status_t create_counters(sx_api_handle_t api_handle)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    int                  iii, jjj;
    sx_flow_counter_id_t counter_id;

    for (iii = 0; iii < num_counters; iii++) {
        sx_status = sx_api_flow_counter_set(api_handle, SX_ACCESS_CMD_CREATE, SX_FLOW_COUNTER_TYPE_PACKETS,
                                            &counter_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_flow_counter_set failed: [%s]\n",
                   __func__, __LINE__, sx_status_str(sx_status));
            exit(1);
        }
        printf("SDK API: created counter id: %#x \n", counter_id);
        counters_g[iii] = counter_id;

        for (jjj = 0; jjj < num_actions_ex; jjj++) {
            if (action_set_example[jjj].type == SX_FLEX_ACL_ACTION_COUNTER) {
                if (action_set_example[jjj].fields.action_counter.counter_id == iii) {
                    action_set_example[jjj].fields.action_counter.counter_id = counter_id;
                }
            }
        }
    }
    return sx_status;
}
sx_status_t delete_counters(sx_api_handle_t api_handle)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    int                  iii;
    sx_flow_counter_id_t counter_id;

    for (iii = 0; iii < num_counters; iii++) {
        counter_id = counters_g[iii];
        printf("SDK API: deleting counter id: %#x \n", counter_id);
        sx_status = sx_api_flow_counter_set(api_handle, SX_ACCESS_CMD_DESTROY, SX_FLOW_COUNTER_TYPE_PACKETS,
                                            &counter_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_flow_counter_set failed: [%s]\n",
                   __func__, __LINE__, sx_status_str(sx_status));
            exit(1);
        }
    }

    return sx_status;
}

sx_status_t create_pbs_entries(sx_api_handle_t api_handle)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_acl_pbs_entry_t pbs_entry;
    sx_port_log_id_t   pbs_ports[4];
    sx_acl_pbs_id_t    pbs_id;
    int                iii;

    /* Create PBS entry: UC */
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_UNICAST;
    pbs_entry.port_num = 1;
    pbs_entry.log_ports = pbs_ports;
    pbs_ports[0] = 0x10029;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__, __LINE__, sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created UC PBS entry id: %#x \n", pbs_id);
    pbs_entry_db_g[PBS_UC_1].pbs_id = pbs_id;
    pbs_entry_db_g[PBS_UC_1].pbs_port = pbs_ports[0];
    pbs_entry_db_g[PBS_UC_1].entry_type = pbs_entry.entry_type;

    /* Create OUTPUT entry: UC */
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST;
    pbs_entry.port_num = 1;
    pbs_entry.log_ports = pbs_ports;
    pbs_ports[0] = 0x10009;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__,
               __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created UC PBS entry id: %#x \n", pbs_id);
    pbs_entry_db_g[PBS_OUT_UC_1].pbs_id = pbs_id;
    pbs_entry_db_g[PBS_OUT_UC_1].pbs_port = pbs_ports[0];
    pbs_entry_db_g[PBS_OUT_UC_1].entry_type = pbs_entry.entry_type;

    /* Create OUTPUT entry: UC */
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST;
    pbs_entry.port_num = 1;
    pbs_entry.log_ports = pbs_ports;
    pbs_ports[0] = 0x10021;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__,
               __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created MC PBS entry id: %#x \n", pbs_id);
    pbs_entry_db_g[PBS_OUT_UC_2].pbs_id = pbs_id;
    pbs_entry_db_g[PBS_OUT_UC_2].pbs_port = pbs_ports[0];
    pbs_entry_db_g[PBS_OUT_UC_2].entry_type = pbs_entry.entry_type;

    /* Create OUTPUT entry: UC */
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST;
    pbs_entry.port_num = 1;
    pbs_entry.log_ports = pbs_ports;
    pbs_ports[0] = 0x10029;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__,
               __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created UC OUTPUT PBS entry id: %#x \n", pbs_id);
    pbs_entry_db_g[PBS_OUT_UC_3].pbs_id = pbs_id;
    pbs_entry_db_g[PBS_OUT_UC_3].pbs_port = pbs_ports[0];
    pbs_entry_db_g[PBS_OUT_UC_3].entry_type = pbs_entry.entry_type;

    /* Go through all actions and fix pbs_id values */
    for (iii = 0; iii < num_actions_ex; iii++) {
        if (action_set_example[iii].type == SX_FLEX_ACL_ACTION_PBS) {
            if (action_set_example[iii].fields.action_pbs.pbs_id < num_pbs_db) {
                pbs_id = pbs_entry_db_g[action_set_example[iii].fields.action_pbs.pbs_id].pbs_id;
                action_set_example[iii].fields.action_pbs.pbs_id = pbs_id;
            }
        }
    }


    return SX_STATUS_SUCCESS;
}

sx_status_t delete_pbs_entries(sx_api_handle_t api_handle)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_acl_pbs_entry_t pbs_entry;
    int                iii;

    memset(&pbs_entry, 0, sizeof(pbs_entry));

    for (iii = 0; iii < num_pbs_db; iii++) {
        sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                          SX_ACCESS_CMD_DELETE,
                                                          SWID,
                                                          &pbs_entry,
                                                          &pbs_entry_db_g[iii].pbs_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
                   __func__, __LINE__, sx_status_str(sx_status));
            exit(1);
        }
        printf("SDK API: deleted PBS ID: %#x \n", pbs_entry_db_g[iii].pbs_id);
    }

    return SX_STATUS_SUCCESS;
}

/* Set rules example values */
void set_rules_example(sx_flex_acl_flex_rule_t *rules_example)
{
    int     iii, jjj;
    uint8_t action_idx;

    printf("Generated rules example: %d rules\n", NUM_RULES);
    for (iii = 0; iii < NUM_RULES; iii++) {
        printf("Rule %d: \n", iii);
        /* Take random number between [0,num_keys_example] */
/*        rules_example[iii].key_desc_count = rand() % (num_keys_ex); */
        rules_example[iii].key_desc_count = num_keys_ex;
        printf("\t Keys count: %d\n", rules_example[iii].key_desc_count);
        for (jjj = 0; jjj < rules_example[iii].key_desc_count; jjj++) {
            rules_example[iii].key_desc_list_p[jjj].key_id = key_id_set_example[jjj];
            rules_example[iii].key_desc_list_p[jjj].key = key_value_set_example[jjj];
            rules_example[iii].key_desc_list_p[jjj].mask = key_mask_set_example[jjj];
            printf("\t\t Key %d: key_id:%d\n", jjj, rules_example[iii].key_desc_list_p[jjj].key_id);
        }

        /* rules_example[iii].action_count = rand() % (num_actions_ex); */
        rules_example[iii].action_count = num_actions_ex;
        printf("\t Actions count: %d\n", rules_example[iii].action_count);
        for (jjj = 0; jjj < rules_example[iii].action_count; jjj++) {
            /* Choose action randomly from the example actions */
            /* action_idx=rand() % num_actions_ex; */
            action_idx = jjj;
            rules_example[iii].action_list_p[jjj] = action_set_example[action_idx];
            printf("\t\t Action %d: action type:%s(%d) Index:%d\n", jjj,
                   API_ACT_2SHORT(rules_example[iii].action_list_p[jjj].type),
                   rules_example[iii].action_list_p[jjj].type,
                   action_idx);
        }

        rules_example[iii].valid = 1;
        offset_list_example[iii] = iii;
    }
    printf("End of rules example: %d rules\n", NUM_RULES);
}

int main(int argc, char *argv[])
{
    sx_status_t           sx_status;
    sx_api_handle_t       api_handle;
    sx_acl_key_type_t     key_handle;
    int                   iii;
    int                   rules_to_send = 0;
    int                   rule_count = 0;
    int                   rule_count_start = 0;
    sx_acl_region_id_t    region_id;
    sx_acl_region_group_t acl_region_group;
    sx_acl_id_t           acl_id;
    sx_acl_direction_t    acl_direction = SX_ACL_DIRECTION_INGRESS;
    sx_acl_id_t           acl_group_id;
    sx_acl_id_t           acl_id_list[1];
    char                  sss[8];
    sx_acl_pbs_entry_t    pbs_entry;
    sx_port_log_id_t      pbs_ports[4];
    char                  fname[80];
    sx_port_log_id_t      bind_port = 0x10001;

    memset(&rules_example, 0, sizeof(rules_example));
    memset(&offset_list_example, 0, sizeof(offset_list_example));

    /* Open SDK API */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_open failed. [%s]\n", __func__, __LINE__, sx_status_str(sx_status));
        exit(1);
    }

    /* Create key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_set_example,
                                        num_keys_ex,
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_flex_key_set failed: [%s] \n", __func__, __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }

    /* Create region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_CREATE,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      NUM_RULES,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_region_set failed: [%s] \n", __func__, __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }

    /* Create ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_CREATE,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_set failed: [%s] \n", __func__, __LINE__, sx_status_str(sx_status));
        exit(1);
    }

    /* Create ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_CREATE,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_group_set failed: [%s] \n", __func__, __LINE__, sx_status_str(
                   sx_status));
        exit(1);
    }

    acl_id_list[0] = acl_id;
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_SET,
                                     acl_direction,
                                     acl_id_list,
                                     1,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_group_set failed: [%s] \n", __func__, __LINE__, sx_status_str(
                   sx_status));
        exit(1);
    }

    /* Bind ACL group to port */
    sx_status = sx_api_acl_port_bind_set(api_handle,
                                         SX_ACCESS_CMD_BIND,
                                         bind_port,
                                         acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_port_bind_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: ACL group id %#x bound to port %#x\n", acl_group_id, bind_port);

    /* Initialize rules array */
    for (iii = 0; iii < NUM_RULES; iii++) {
        /* Each rule is initialized to max number of keys and max number of actions */
        sx_status = sx_lib_flex_acl_rule_init(key_handle, num_actions_ex, &rules_example[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_lib_flex_acl_rule_init failed: [%s] \n", __func__, __LINE__,
                   sx_status_str(sx_status));
            exit(1);
        }
    }

    create_pbs_entries(api_handle);
    create_counters(api_handle);

    /* Set example rule values: keys and actions */
    set_rules_example(rules_example);

    /* Create rules in SDK */
    rule_count = NUM_RULES;
    rule_count_start = 0;
    rules_to_send = 20;
    while (rule_count > 0) {
        if (rule_count < rules_to_send) {
            rules_to_send = rule_count;
        }
        printf("DBG: Setting %d rules: start:%d rules left:%d \n", rules_to_send, rule_count_start, rule_count);
        sx_status = sx_api_acl_flex_rules_set(api_handle,
                                              SX_ACCESS_CMD_SET,
                                              region_id,
                                              &offset_list_example[rule_count_start],
                                              &rules_example[rule_count_start],
                                              rules_to_send);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_acl_flex_rules_set failed [%s]\n", __func__, __LINE__,
                   sx_status_str(sx_status));
            exit(1);
        }

        rule_count -= rules_to_send;
        rule_count_start += rules_to_send;
    }

    /* De-Initialize rules array */
    for (iii = 0; iii < NUM_RULES; iii++) {
        /* Each rule is initialized to max number of keys and max number of actions */
        sx_status = sx_lib_flex_acl_rule_deinit(&rules_example[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_lib_flex_acl_rule_deinit failed: [%s] \n",
                   __func__,
                   __LINE__,
                   sx_status_str(sx_status));
            exit(1);
        }
    }

    printf("%s: configuration created.\n", argv[0]);
    printf("Enter any character and press enter to create debug dump \n");
    scanf("%1s", sss);

    /* Create Debug Dump */
    sx_status = sx_api_dbg_generate_dump(api_handle, "/tmp/sdkdump_conf");
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_dbg_generate_dump failed [%s]\n", __func__, __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }

    /******************************************************************************************/
    /* Delete port of the PBS-es *************************************************************/
    for (iii = 0; iii < num_pbs_db; iii++) {
        printf("Enter any character and press enter to Delete port %#x of the PBS #%d (pbs_id=%#x)\n",
               pbs_entry_db_g[iii].pbs_port, iii, pbs_entry_db_g[iii].pbs_id);
        scanf("%1s", sss);

        pbs_entry.entry_type = pbs_entry_db_g[iii].entry_type;
        pbs_entry.port_num = 1;
        pbs_entry.log_ports = pbs_ports;
        pbs_ports[0] = pbs_entry_db_g[iii].pbs_port;

        sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                          SX_ACCESS_CMD_DELETE_PORTS,
                                                          SWID,
                                                          &pbs_entry,
                                                          &pbs_entry_db_g[iii].pbs_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
                   __func__, __LINE__, sx_status_str(sx_status));
            exit(1);
        }
        printf("SDK API: deleted port %#x from PBS id %#x\n",
               pbs_entry_db_g[iii].pbs_port, pbs_entry_db_g[iii].pbs_id);

        /* Create Debug Dump */
        sprintf(fname, "/tmp/sdkdump_pbs_deleted_%d", iii);
        sx_status = sx_api_dbg_generate_dump(api_handle, fname);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_dbg_generate_dump failed. fname:'%s' [%s]\n",
                   __func__, __LINE__, fname, sx_status_str(sx_status));
            exit(1);
        }
    }

    /******************************************************************************************/
    /* Recreate! */
    for (iii = num_pbs_db - 1; iii >= 0; iii--) {
        printf("Enter any character and press enter to ADD port %#x to the PBS #%d (pbs_id=%#x)\n",
               pbs_entry_db_g[iii].pbs_port, iii, pbs_entry_db_g[iii].pbs_id);
        scanf("%1s", sss);

        pbs_entry.entry_type = pbs_entry_db_g[iii].entry_type;
        pbs_entry.port_num = 1;
        pbs_entry.log_ports = pbs_ports;
        pbs_ports[0] = pbs_entry_db_g[iii].pbs_port;

        sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                          SX_ACCESS_CMD_ADD_PORTS,
                                                          SWID,
                                                          &pbs_entry,
                                                          &pbs_entry_db_g[iii].pbs_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
                   __func__, __LINE__, sx_status_str(sx_status));
            exit(1);
        }
        printf("SDK API: re-created port %#x in PBS id %#x\n",
               pbs_entry_db_g[iii].pbs_port, pbs_entry_db_g[iii].pbs_id);

        /* Create Debug Dump */
        sprintf(fname, "/tmp/sdkdump_pbs_recreate_%d", iii);
        sx_status = sx_api_dbg_generate_dump(api_handle, fname);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_dbg_generate_dump failed. fname:'%s' [%s]\n",
                   __func__, __LINE__, fname, sx_status_str(sx_status));
            exit(1);
        }
    }


    /******************************************************************************************/
    printf("Enter any character and press enter to proceed to cleanup \n");
    scanf("%1s", sss);

    /* Unbind ACL group from port */
    sx_status = sx_api_acl_port_bind_set(api_handle,
                                         SX_ACCESS_CMD_UNBIND,
                                         bind_port,
                                         acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR: SDK API sx_api_acl_port_bind_set failed: [%s]\n", sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: ACL group id %#x unbound from port %#x\n", acl_group_id, bind_port);

    /* Delete rules in SDK */
    rule_count = NUM_RULES;
    rule_count_start = 0;
    rules_to_send = 20;
    while (rule_count > 0) {
        if (rule_count < rules_to_send) {
            rules_to_send = rule_count;
        }
        printf("DBG: Deleting %d rules: start:%d rules left:%d \n", rules_to_send, rule_count_start, rule_count);
        sx_status = sx_api_acl_flex_rules_set(api_handle,
                                              SX_ACCESS_CMD_DELETE,
                                              region_id,
                                              &offset_list_example[rule_count_start],
                                              NULL,
                                              rules_to_send);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_acl_flex_rules_set failed [%s]\n", __func__, __LINE__,
                   sx_status_str(sx_status));
            exit(1);
        }

        rule_count -= rules_to_send;
        rule_count_start += rules_to_send;
    }

    delete_pbs_entries(api_handle);
    delete_counters(api_handle);

    /* Delete ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_group_set failed: [%s] \n", __func__, __LINE__, sx_status_str(
                   sx_status));
        exit(1);
    }

    /* Delete ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_set failed: [%s] \n", __func__, __LINE__, sx_status_str(sx_status));
        exit(1);
    }

    /* Delete region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      NUM_RULES,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_region_set failed: [%s] \n", __func__, __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }

    /* Delete key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_DELETE,
                                        key_id_set_example,
                                        num_keys_ex,
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_flex_key_set failed: [%s] \n", __func__, __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }

    /* Close SDK API */
    sx_status = sx_api_close(&api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_open failed. [%s]\n", __func__, __LINE__, sx_status_str(sx_status));
        exit(1);
    }

    printf("Successfully finished\n");
    return 0;
}
