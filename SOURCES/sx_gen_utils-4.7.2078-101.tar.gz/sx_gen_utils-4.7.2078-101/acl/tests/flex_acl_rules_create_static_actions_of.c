/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_dbg.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_trap_id.h>
#include <complib/sx_log.h>
#include <arpa/inet.h>
#include "sx/sdk/sx_strings.h"

/*
 * Example of FLEX ACL rules creation/deletion
 */

/*
 * Local test definitions
 */
#define NUM_RULES 1
#define SWID      0

static char * api_action_short[SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST + 1] = {
    [SX_FLEX_ACL_ACTION_FORWARD] = "FWD",
    [SX_FLEX_ACL_ACTION_TRAP] = "TRAP",
    [SX_FLEX_ACL_ACTION_COUNTER] = "CNTR",
    [SX_FLEX_ACL_ACTION_MIRROR] = "MIRR",
    [SX_FLEX_ACL_ACTION_EGRESS_MIRROR] = "EGMIRR",
    [SX_FLEX_ACL_ACTION_POLICER] = "POLCR",
    [SX_FLEX_ACL_ACTION_SET_PRIO] = "PRIO",
    [SX_FLEX_ACL_ACTION_SET_VLAN] = "VLAN",
    [SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI] = "INVPRI",
    [SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI] = "OUVPRI",
    [SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID] = "INVID",
    [SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID] = "OUVID",
    [SX_FLEX_ACL_ACTION_SET_SRC_MAC] = "SMAC",
    [SX_FLEX_ACL_ACTION_SET_DST_MAC] = "DMAC",
    [SX_FLEX_ACL_ACTION_SET_DSCP] = "DSCP",
    [SX_FLEX_ACL_ACTION_SET_BRIDGE] = "BRDG",
    [SX_FLEX_ACL_ACTION_PBS] = "PBS",
    [SX_FLEX_ACL_ACTION_SET_TC] = "TC",
    [SX_FLEX_ACL_ACTION_DEC_TTL] = "DECTTL",
    [SX_FLEX_ACL_ACTION_SET_TTL] = "TTL",
    [SX_FLEX_ACL_ACTION_SET_COLOR] = "CLR",
    [SX_FLEX_ACL_ACTION_SET_ECN] = "ECN",
    [SX_FLEX_ACL_ACTION_SET_USER_TOKEN] = "USRTKN",
    [SX_FLEX_ACL_ACTION_DONT_LEARN] = "DNTLRN",
    [SX_FLEX_ACL_ACTION_TUNNEL_DECAP] = "TUNDCP",
    [SX_FLEX_ACL_ACTION_GOTO] = "GOTO",
    [SX_FLEX_ACL_ACTION_RPF] = "RPF",
    [SX_FLEX_ACL_ACTION_MC_ROUTE] = "MCROUT",
    [SX_FLEX_ACL_ACTION_SET_ROUTER] = "ROUTER",
    [SX_FLEX_ACL_ACTION_MC] = "MCPBS",
    [SX_FLEX_ACL_ACTION_UC_ROUTE] = "UCROUT",
    [SX_FLEX_ACL_ACTION_SET_DSCP_REWRITE] = "DSCPRW",
    [SX_FLEX_ACL_ACTION_SET_PCP_REWRITE] = "PCPRW",
    [SX_FLEX_ACL_ACTION_IGNORE_EGRESS_VLAN_FILTER] = "IGEVFL",
    [SX_FLEX_ACL_ACTION_IGNORE_EGRESS_STP_FILTER] = "IGESTP",
    [SX_FLEX_ACL_ACTION_DISABLE_OVERLAY_LEARNING] = "DISOVLN",
    [SX_FLEX_ACL_ACTION_PORT_FILTER] = "PRTFLT",
    [SX_FLEX_ACL_ACTION_PORT_FILTER] = "TRUNC",
    [SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST] = "LAST",
};
#define API_ACT_2SHORT(act_type)                                \
    (((act_type) > SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST) ? "***" : \
     (api_action_short[act_type] ? : "###"))


void set_rules_example(sx_flex_acl_flex_rule_t *rules);

sx_acl_key_t         key_id_set_example[] = {
    FLEX_ACL_KEY_DMAC,
    FLEX_ACL_KEY_SMAC,
    FLEX_ACL_KEY_ETHERTYPE,
    FLEX_ACL_KEY_VLAN_ID,
    FLEX_ACL_KEY_DIP,
    FLEX_ACL_KEY_SIP,
    FLEX_ACL_KEY_IP_PROTO,
    FLEX_ACL_KEY_TTL,
    FLEX_ACL_KEY_L4_DESTINATION_PORT,
    FLEX_ACL_KEY_L4_SOURCE_PORT
};
sx_acl_key_fields_t  key_value_set_example[] = {
    {.dmac = {
         {0x00, 0x25, 0x90, 0xd1, 0xd9, 0x3e}
     }
    },
    {.smac = {
         {0x00, 0x25, 0x90, 0xd1, 0xd9, 0x3f}
     }
    },
    {.ethertype = 0x1234},
    {.vlan_id = 0x567},
    {.dip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xC0A80101}
             }
     }
    },
    {.sip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xC0A80101}
             }
     }
    },
    {.ip_proto = 1},
    {.ttl = 1},
    {.l4_destination_port = 100},
    {.l4_source_port = 101},
};
sx_acl_mask_fields_t key_mask_set_example[] = {
    {.dmac = {
         {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}
     }
    },
    {.smac = {
         {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}
     }
    },
    {.ethertype = 0xFFFF},
    {.vlan_id = 0xFFF},
    {.dip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xFFFFFFFF}
             }
     }
    },
    {.sip = {.version = SX_IP_VERSION_IPV4, {.ipv4 = {0xFFFFFFFF}
             }
     }
    },
    {.ip_proto = 0xFF},
    {.ttl = 0xFF},
    {.l4_destination_port = 0xFFFF},
    {.l4_source_port = 0xFFFF},
};

#define PBS_ID_UC           0
#define PBS_ID_MC           1
#define PBS_ID_OUT_UC       2
#define PBS_ID_OUT_MC       3
#define PBS_ID_MC_EMPTY     4
#define PBS_ID_OUT_UC_EMPTY 5
#define PBS_ID_OUT_MC_EMPTY 6
#define PBS_ID_NUM          7

sx_acl_pbs_id_t           pbs_ids_g[PBS_ID_NUM];
int                       num_pbs_ids = sizeof(pbs_ids_g) / sizeof(pbs_ids_g[0]);
sx_flex_acl_flex_action_t action_set_example[] = {
    {.type = SX_FLEX_ACL_ACTION_TRAP, .fields =
     {.action_trap = {.action = SX_ACL_TRAP_ACTION_TYPE_TRAP, .trap_id = SX_TRAP_ID_ACL_MIN}
     }
    }, /* TRAP */
    {.type = SX_FLEX_ACL_ACTION_SET_VLAN, .fields =
     {.action_set_vlan = {.cmd = SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH, .vlan_id = 0x111}
     }
    }, /* VLAN */
    {.type = SX_FLEX_ACL_ACTION_SET_PRIO, .fields =
     {.action_set_prio = {.prio_val = 10}
     }
    }, /* QoS */
    {.type = SX_FLEX_ACL_ACTION_SET_SRC_MAC, .fields =
     {.action_set_src_mac = {.mac.ether_addr_octet = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05}
      }
     }
    }, /* SRC MAC */
    {.type = SX_FLEX_ACL_ACTION_PBS, .fields =
     {.action_pbs = {.pbs_id = PBS_ID_OUT_UC}
     }
    }, /* OUTPUT */
    {.type = SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID, .fields =
     {.action_set_outer_vlan_id = {.vlan_id = 0x222}
     }
    }, /* VLAN */
    {.type = SX_FLEX_ACL_ACTION_SET_SRC_MAC, .fields =
     {.action_set_src_mac = {.mac.ether_addr_octet = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05}
      }
     }
    }, /* SRC MAC */
    {.type = SX_FLEX_ACL_ACTION_PBS, .fields =
     {.action_pbs = {.pbs_id = PBS_ID_OUT_UC}
     }
    }, /* OUTPUT */
    {.type = SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID, .fields =
     {.action_set_outer_vlan_id = {.vlan_id = 0x333}
     }
    }, /* VLAN */
    {.type = SX_FLEX_ACL_ACTION_SET_DSCP, .fields =
     {.action_set_dscp = {.dscp_val = 0}
     }
    }, /* SET DSCP */
    {.type = SX_FLEX_ACL_ACTION_SET_TC, .fields =
     {.action_set_tc = {.tc_val = 0}
     }
    }, /* SET TC */
    {.type = SX_FLEX_ACL_ACTION_DEC_TTL, .fields =
     {.action_dec_ttl = {.ttl_val = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_SET_COLOR, .fields =
     {.action_set_color = {.color_val = 0}
     }
    },
    {.type = SX_FLEX_ACL_ACTION_PBS, .fields =
     {.action_pbs = {.pbs_id = PBS_ID_OUT_MC}
     }
    }, /* OUTPUT */
    {.type = SX_FLEX_ACL_ACTION_FORWARD, .fields =
     {.action_forward = {.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD}
     }
    }, /* SOFT DISCARD */
    {.type = SX_FLEX_ACL_ACTION_PBS, .fields =
     {.action_pbs = {.pbs_id = PBS_ID_UC}
     }
    }, /* PBS-UC */
};
int                       num_keys_ex = sizeof(key_id_set_example) / sizeof(key_id_set_example[0]);
int                       num_actions_ex = sizeof(action_set_example) / sizeof(action_set_example[0]);
sx_flex_acl_flex_rule_t   rules_example[NUM_RULES];
sx_acl_rule_offset_t      offset_list_example[NUM_RULES];

sx_status_t create_pbs_entries(sx_api_handle_t api_handle)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_acl_pbs_entry_t pbs_entry;
    sx_port_log_id_t   pbs_ports[4];
    sx_acl_pbs_id_t    pbs_id;
    int                iii;

    /* Create PBS entry: UC */
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_UNICAST;
    pbs_entry.port_num = 1;
    pbs_entry.log_ports = pbs_ports;
    pbs_ports[0] = 0x10025;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__,
               __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created UC PBS entry id: %#x \n", pbs_id);
    pbs_ids_g[PBS_ID_UC] = pbs_id;

    /* Create PBS entry: MC */
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_MULTICAST;
    pbs_entry.port_num = 3;
    pbs_entry.log_ports = pbs_ports;
    pbs_ports[0] = 0x10009;
    pbs_ports[1] = 0x10021;
    pbs_ports[2] = 0x10025;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__,
               __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created MC PBS entry id: %#x \n", pbs_id);
    pbs_ids_g[PBS_ID_MC] = pbs_id;

    /* Create PBS entry: OUT UC */
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST;
    pbs_entry.port_num = 1;
    pbs_entry.log_ports = pbs_ports;
    pbs_ports[0] = 0x10009;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__,
               __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created UC OUTPUT PBS entry id: %#x \n", pbs_id);
    pbs_ids_g[PBS_ID_OUT_UC] = pbs_id;

    /* Create PBS entry: OUT MC */
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST;
    pbs_entry.port_num = 3;
    pbs_entry.log_ports = pbs_ports;
    pbs_ports[0] = 0x10009;
    pbs_ports[1] = 0x10021;
    pbs_ports[2] = 0x10025;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__,
               __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created MC OUTPUT PBS entry id: %#x \n", pbs_id);
    pbs_ids_g[PBS_ID_OUT_MC] = pbs_id;

    /* Create PBS entry: OUT UC EMPTY*/
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST;
    pbs_entry.port_num = 0;
    pbs_entry.log_ports = pbs_ports;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__,
               __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created UC OUTPUT EMPTY PBS entry id: %#x \n", pbs_id);
    pbs_ids_g[PBS_ID_OUT_UC_EMPTY] = pbs_id;

    /* Create PBS entry: MC EMPTY*/
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_MULTICAST;
    pbs_entry.port_num = 0;
    pbs_entry.log_ports = pbs_ports;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__,
               __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created MC EMPTY PBS entry id: %#x \n", pbs_id);
    pbs_ids_g[PBS_ID_MC_EMPTY] = pbs_id;

    /* Create PBS entry: OUT MC EMPTY*/
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST;
    pbs_entry.port_num = 0;
    pbs_entry.log_ports = pbs_ports;

    sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                      SX_ACCESS_CMD_ADD,
                                                      SWID,
                                                      &pbs_entry,
                                                      &pbs_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
               __func__,
               __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }
    printf("SDK API: created MC OUTPUT EMPTY PBS entry id: %#x \n", pbs_id);
    pbs_ids_g[PBS_ID_OUT_MC_EMPTY] = pbs_id;

    /* Go through all actions and fix pbs_id values */
    for (iii = 0; iii < num_actions_ex; iii++) {
        if (action_set_example[iii].type == SX_FLEX_ACL_ACTION_PBS) {
            if (action_set_example[iii].fields.action_pbs.pbs_id < num_pbs_ids) {
                pbs_id = pbs_ids_g[action_set_example[iii].fields.action_pbs.pbs_id];
                action_set_example[iii].fields.action_pbs.pbs_id = pbs_id;
            }
        }
    }


    return SX_STATUS_SUCCESS;
}

sx_status_t delete_pbs_entries(sx_api_handle_t api_handle)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_acl_pbs_entry_t pbs_entry;
    int                iii;

    memset(&pbs_entry, 0, sizeof(pbs_entry));

    for (iii = 0; iii < num_pbs_ids; iii++) {
        sx_status = sx_api_acl_policy_based_switching_set(api_handle,
                                                          SX_ACCESS_CMD_DELETE,
                                                          SWID,
                                                          &pbs_entry,
                                                          &pbs_ids_g[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_acl_policy_based_switching_set failed: [%s]\n",
                   __func__, __LINE__, sx_status_str(sx_status));
            exit(1);
        }
        printf("SDK API: deleted PBS ID: %#x \n", pbs_ids_g[iii]);
    }

    return SX_STATUS_SUCCESS;
}

/* Set rules example values */
void set_rules_example(sx_flex_acl_flex_rule_t *rules_example)
{
    int     iii, jjj;
    uint8_t action_idx;

    printf("Generated rules example: %d rules\n", NUM_RULES);
    for (iii = 0; iii < NUM_RULES; iii++) {
        printf("Rule %d: \n", iii);
        /* Take random number between [0,num_keys_example] */
/*        rules_example[iii].key_desc_count = rand() % (num_keys_ex); */
        rules_example[iii].key_desc_count = num_keys_ex;
        printf("\t Keys count: %d\n", rules_example[iii].key_desc_count);
        for (jjj = 0; jjj < rules_example[iii].key_desc_count; jjj++) {
            rules_example[iii].key_desc_list_p[jjj].key_id = key_id_set_example[jjj];
            rules_example[iii].key_desc_list_p[jjj].key = key_value_set_example[jjj];
            rules_example[iii].key_desc_list_p[jjj].mask = key_mask_set_example[jjj];
            printf("\t\t Key %d: key_id:%d\n", jjj, rules_example[iii].key_desc_list_p[jjj].key_id);
        }

        /* rules_example[iii].action_count = rand() % (num_actions_ex); */
        rules_example[iii].action_count = num_actions_ex;
        printf("\t Actions count: %d\n", rules_example[iii].action_count);
        for (jjj = 0; jjj < rules_example[iii].action_count; jjj++) {
            /* Choose action randomly from the example actions */
            /* action_idx=rand() % num_actions_ex; */
            action_idx = jjj;
            rules_example[iii].action_list_p[jjj] = action_set_example[action_idx];
            printf("\t\t Action %d: action type:%s(%d) Index:%d\n", jjj,
                   API_ACT_2SHORT(rules_example[iii].action_list_p[jjj].type),
                   rules_example[iii].action_list_p[jjj].type,
                   action_idx);
        }

        rules_example[iii].valid = 1;
        offset_list_example[iii] = iii;
    }
    printf("End of rules example: %d rules\n", NUM_RULES);
}

int main(int argc, char *argv[])
{
    sx_status_t           sx_status;
    sx_api_handle_t       api_handle;
    sx_acl_key_type_t     key_handle;
    int                   iii;
    int                   rules_to_send = 0;
    int                   rule_count = 0;
    int                   rule_count_start = 0;
    sx_acl_region_id_t    region_id;
    sx_acl_region_group_t acl_region_group;
    sx_acl_id_t           acl_id;
    sx_acl_direction_t    acl_direction = SX_ACL_DIRECTION_INGRESS;
    sx_acl_id_t           acl_group_id;
    sx_acl_id_t           acl_id_list[1];
    char                  sss[8];

    memset(&rules_example, 0, sizeof(rules_example));
    memset(&offset_list_example, 0, sizeof(offset_list_example));

    /* Open SDK API */
    sx_status = sx_api_open(NULL, &api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_open failed. [%s]\n", __func__, __LINE__, sx_status_str(sx_status));
        exit(1);
    }

    /* Create key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_set_example,
                                        num_keys_ex,
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_flex_key_set failed: [%s] \n", __func__, __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }

    /* Create region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_CREATE,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      NUM_RULES,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_region_set failed: [%s] \n", __func__, __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }

    /* Create ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_CREATE,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_set failed: [%s] \n", __func__, __LINE__, sx_status_str(sx_status));
        exit(1);
    }

    /* Create ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_CREATE,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_group_set failed: [%s] \n", __func__, __LINE__, sx_status_str(
                   sx_status));
        exit(1);
    }

    acl_id_list[0] = acl_id;
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_SET,
                                     acl_direction,
                                     acl_id_list,
                                     1,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_group_set failed: [%s] \n", __func__, __LINE__, sx_status_str(
                   sx_status));
        exit(1);
    }

    /* Initialize rules array */
    for (iii = 0; iii < NUM_RULES; iii++) {
        /* Each rule is initialized to max number of keys and max number of actions */
        sx_status = sx_lib_flex_acl_rule_init(key_handle, num_actions_ex, &rules_example[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_lib_flex_acl_rule_init failed: [%s] \n", __func__, __LINE__,
                   sx_status_str(sx_status));
            exit(1);
        }
    }

    create_pbs_entries(api_handle);

    /* Set example rule values: keys and actions */
    set_rules_example(rules_example);

    /* Create rules in SDK */
    rule_count = NUM_RULES;
    rule_count_start = 0;
    rules_to_send = 20;
    while (rule_count > 0) {
        if (rule_count < rules_to_send) {
            rules_to_send = rule_count;
        }
        printf("DBG: Setting %d rules: start:%d rules left:%d \n", rules_to_send, rule_count_start, rule_count);
        sx_status = sx_api_acl_flex_rules_set(api_handle,
                                              SX_ACCESS_CMD_SET,
                                              region_id,
                                              &offset_list_example[rule_count_start],
                                              &rules_example[rule_count_start],
                                              rules_to_send);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_acl_flex_rules_set failed [%s]\n", __func__, __LINE__,
                   sx_status_str(sx_status));
            exit(1);
        }

        rule_count -= rules_to_send;
        rule_count_start += rules_to_send;
    }

    /* De-Initialize rules array */
    for (iii = 0; iii < NUM_RULES; iii++) {
        /* Each rule is initialized to max number of keys and max number of actions */
        sx_status = sx_lib_flex_acl_rule_deinit(&rules_example[iii]);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_lib_flex_acl_rule_deinit failed: [%s] \n",
                   __func__,
                   __LINE__,
                   sx_status_str(sx_status));
            exit(1);
        }
    }

    printf("%s: configuration created.\n", argv[0]);
    printf("Enter any character and press enter to create debug dump \n");
    scanf("%1s", sss);

    /* Create Debug Dump */
    sx_status = sx_api_dbg_generate_dump(api_handle, "/tmp/sdkdump");
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_dbg_generate_dump failed [%s]\n", __func__, __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }

    printf("Enter any character and press enter to proceed to cleanup \n");
    scanf("%1s", sss);

    /* Delete rules in SDK */
    rule_count = NUM_RULES;
    rule_count_start = 0;
    rules_to_send = 20;
    while (rule_count > 0) {
        if (rule_count < rules_to_send) {
            rules_to_send = rule_count;
        }
        printf("DBG: Deleting %d rules: start:%d rules left:%d \n", rules_to_send, rule_count_start, rule_count);
        sx_status = sx_api_acl_flex_rules_set(api_handle,
                                              SX_ACCESS_CMD_DELETE,
                                              region_id,
                                              &offset_list_example[rule_count_start],
                                              NULL,
                                              rules_to_send);
        if (sx_status != SX_STATUS_SUCCESS) {
            printf("ERROR:%s.%d  SDK API sx_api_acl_flex_rules_set failed [%s]\n", __func__, __LINE__,
                   sx_status_str(sx_status));
            exit(1);
        }

        rule_count -= rules_to_send;
        rule_count_start += rules_to_send;
    }

    delete_pbs_entries(api_handle);

    /* Delete ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     acl_direction,
                                     acl_id_list,
                                     0,
                                     &acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_group_set failed: [%s] \n", __func__, __LINE__, sx_status_str(
                   sx_status));
        exit(1);
    }

    /* Delete ACL */
    acl_region_group.regions.acl_packet_agnostic.region = region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               acl_direction,
                               &acl_region_group,
                               &acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_set failed: [%s] \n", __func__, __LINE__, sx_status_str(sx_status));
        exit(1);
    }

    /* Delete region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      NUM_RULES,
                                      &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_region_set failed: [%s] \n", __func__, __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }

    /* Delete key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_DELETE,
                                        key_id_set_example,
                                        num_keys_ex,
                                        &key_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_acl_flex_key_set failed: [%s] \n", __func__, __LINE__,
               sx_status_str(sx_status));
        exit(1);
    }

    /* Close SDK API */
    sx_status = sx_api_close(&api_handle);
    if (sx_status != SX_STATUS_SUCCESS) {
        printf("ERROR:%s.%d  SDK API sx_api_open failed. [%s]\n", __func__, __LINE__, sx_status_str(sx_status));
        exit(1);
    }

    printf("Successfully finished\n");
    return 0;
}
