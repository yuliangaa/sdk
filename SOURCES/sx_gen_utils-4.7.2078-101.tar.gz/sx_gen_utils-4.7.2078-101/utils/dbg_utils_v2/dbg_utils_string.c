/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#undef  __MODULE__
#define __MODULE__ DBG_UTILS_STRING

#include <string.h>
#include <stdio.h>

#include "sx/utils/dbg_utils_string.h"

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
char* dbg_utils_string_hex_get(char *buf, int buf_len, const unsigned char *data, int data_len)
{
    int   i = 0;
    char *cp = buf;

    memset(buf, 0, buf_len);
    for (i = 0; (i < data_len) && (buf_len - (cp - buf) >= 3); i++) {
        cp += snprintf(cp, buf_len - (cp - buf), "%02x", data[i]);
        if (i == data_len - 1) {
            break;
        }
        strncpy(cp, ":", buf_len - (cp - buf));
        cp++;
    }
    buf[buf_len - 1] = 0;
    return buf;
}

void dbg_utils_string_return_remove(char * value)
{
    int i = 0;

    /*replace \n \t with space due to json format requirement */
    for (i = 0; i < (int)strlen(value); i++) {
        if ((value[i] == '\n') || (value[i] == '\t')) {
            value[i] = ' ';
        }
    }
}

void dbg_utils_string_leading_sp_remove(char * value)
{
    int i = 0;
    int len = strlen(value);

    for (i = 0; i < len; i++) {
        if ((value[i] == ' ') || (value[i] == '\t')) {
            continue;
        } else {
            break;
        }
    }
    if (i != 0) {
        memmove(value, value + i, len - i);
        value[len - i] = 0;
    }
}

void dbg_utils_string_capitalize(const char *string, char *capitalized_string)
{
    int i = 0;

    for (i = 0; i < ((int)strlen(string)); i++) {
        if ((i == 0) ||
            (string[i - 1] == ' ')) {
            if (((string[i] >= 'a') &&
                 (string[i] <= 'z'))) {
                capitalized_string[i] = string[i] - 32;
            } else {
                capitalized_string[i] = string[i];
            }
        } else {
            capitalized_string[i] = string[i];
        }
    }
    capitalized_string[i] = '\0';
}
