/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#undef  __MODULE__
#define __MODULE__ DBG_UTILS_CHEAT_SHEET

#include <stdio.h>
#include <stddef.h>

#include "complib/cl_mem.h"

#include "sx/utils/dbg_utils_types.h"
#include "sx/utils/dbg_utils_cheat_sheet.h"

/************************************************
 *  Defines
 ***********************************************/
#define DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE 8172

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
struct cheat_sheet {
    char   cheat_sheet_buffer[DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE];
    size_t cheat_sheet_total_written;
    int    cheat_sheet_dump_in_progress;
};

typedef enum cheat_sheet_entry_level {
    CHEAT_SHEET_ENTRY_LEVEL_MODULE_HEADER_E     = 1,    /**< must start from 1 - is used to check the space in the buffer */
    CHEAT_SHEET_ENTRY_LEVEL_SUB_MODULE_HEADER_E = 2,
    CHEAT_SHEET_ENTRY_LEVEL_GENERAL_HEADER_E    = 3,
    CHEAT_SHEET_ENTRY_LEVEL_MIN_E               = CHEAT_SHEET_ENTRY_LEVEL_MODULE_HEADER_E, /**< the first level does not get any offset */
} cheat_sheet_entry_level_e;

/************************************************
 *  Global variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Function declarations
 ***********************************************/
static void __dbg_utils_cheat_sheet_entry_print(cheat_sheet_ptr           cheat_sheet_p,
                                                const char               *entry_str,
                                                cheat_sheet_entry_level_e entry_level);

/************************************************
 *  Function implementations
 ***********************************************/
sx_utils_status_t dbg_utils_cheat_sheet_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

cheat_sheet_ptr dbg_utils_cheat_sheet_create(void)
{
    cheat_sheet_ptr cheat_sheet_p = cl_malloc(sizeof(*cheat_sheet_p));

    if (cheat_sheet_p) {
        cheat_sheet_p->cheat_sheet_total_written = 0;
        cheat_sheet_p->cheat_sheet_dump_in_progress = 1;
        memset(cheat_sheet_p->cheat_sheet_buffer,
               0,
               sizeof(cheat_sheet_p->cheat_sheet_buffer));
    }

    return cheat_sheet_p;
}

void dbg_utils_cheat_sheet_destroy(cheat_sheet_ptr cheat_sheet_p)
{
    cl_free(cheat_sheet_p);
}

cheat_sheet_ptr dbg_utils_cheat_sheet_clone(cheat_sheet_ptr src_cheat_sheet_p)
{
    cheat_sheet_ptr cheat_sheet_p = cl_malloc(sizeof(*cheat_sheet_p));

    if (cheat_sheet_p) {
        cheat_sheet_p->cheat_sheet_total_written = 0;
        cheat_sheet_p->cheat_sheet_dump_in_progress = 1;
        dbg_utils_cheat_sheet_append(cheat_sheet_p, src_cheat_sheet_p);
        cheat_sheet_p->cheat_sheet_buffer[DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE - 1] = '\0';
    }

    return cheat_sheet_p;
}

void dbg_utils_cheat_sheet_append(cheat_sheet_ptr dst_cheat_sheet_p, cheat_sheet_ptr src_cheat_sheet_p)
{
    if (dst_cheat_sheet_p->cheat_sheet_total_written + src_cheat_sheet_p->cheat_sheet_total_written >=
        DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE) {
        return;
    }

    strncpy(&dst_cheat_sheet_p->cheat_sheet_buffer[dst_cheat_sheet_p->cheat_sheet_total_written],
            src_cheat_sheet_p->cheat_sheet_buffer,
            src_cheat_sheet_p->cheat_sheet_total_written);
    dst_cheat_sheet_p->cheat_sheet_total_written += src_cheat_sheet_p->cheat_sheet_total_written;
}

void dbg_utils_cheat_sheet_print(cheat_sheet_ptr cheat_sheet_p, char ** cheat_sheet_str)
{
    *cheat_sheet_str = cheat_sheet_p->cheat_sheet_buffer;
    cheat_sheet_p->cheat_sheet_dump_in_progress = 0;
}

static void __dbg_utils_cheat_sheet_entry_print(cheat_sheet_ptr           cheat_sheet_p,
                                                const char               *entry_str,
                                                cheat_sheet_entry_level_e entry_level)
{
    uint32_t cur_level = 0;
    size_t   header_len = 0;

    if (!cheat_sheet_p->cheat_sheet_dump_in_progress) {
        return;
    }

    header_len = strlen(entry_str);
    header_len = (header_len < 48) ? header_len : 48;

    if (cheat_sheet_p->cheat_sheet_total_written + header_len + entry_level >=
        DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE) {
        return;
    }

    for (cur_level = CHEAT_SHEET_ENTRY_LEVEL_MIN_E; cur_level < entry_level; cur_level++) {
        cheat_sheet_p->cheat_sheet_buffer[cheat_sheet_p->cheat_sheet_total_written] = '\t';
        cheat_sheet_p->cheat_sheet_total_written++;
    }

    strncpy(&cheat_sheet_p->cheat_sheet_buffer[cheat_sheet_p->cheat_sheet_total_written],
            entry_str,
            (DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE - (cheat_sheet_p->cheat_sheet_total_written + 1)));
    cheat_sheet_p->cheat_sheet_total_written += header_len;

    cheat_sheet_p->cheat_sheet_buffer[cheat_sheet_p->cheat_sheet_total_written] = '\n';
    cheat_sheet_p->cheat_sheet_total_written++;
}


void dbg_utils_cheat_sheet_module_header_print(cheat_sheet_ptr cheat_sheet_p, const char *module_name)
{
    __dbg_utils_cheat_sheet_entry_print(cheat_sheet_p, module_name, CHEAT_SHEET_ENTRY_LEVEL_MODULE_HEADER_E);
}

void dbg_utils_cheat_sheet_general_header_print(cheat_sheet_ptr cheat_sheet_p, const char            *general_header)
{
    __dbg_utils_cheat_sheet_entry_print(cheat_sheet_p, general_header,
                                        CHEAT_SHEET_ENTRY_LEVEL_GENERAL_HEADER_E);
}

void dbg_utils_cheat_sheet_sub_module_header_print(cheat_sheet_ptr cheat_sheet_p, const char     *sub_module_header)
{
    __dbg_utils_cheat_sheet_entry_print(cheat_sheet_p,
                                        sub_module_header,
                                        CHEAT_SHEET_ENTRY_LEVEL_SUB_MODULE_HEADER_E);
}
