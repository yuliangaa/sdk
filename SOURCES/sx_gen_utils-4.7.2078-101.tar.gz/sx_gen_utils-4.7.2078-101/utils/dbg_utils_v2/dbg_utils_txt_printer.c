/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#undef  __MODULE__
#define __MODULE__ DBG_UTILS_TXT_PRINTER

#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "complib/cl_mem.h"

#include "sx/utils/dbg_utils_types.h"
#include "sx/utils/dbg_utils_string.h"
#include "sx/utils/dbg_utils_txt_printer.h"

/************************************************
 *  Defines
 ***********************************************/
#define DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH     40
#define DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION 65
#define DBG_UTILS_JSON_PRINTER_VAL_STR_PRECISION 128

#define DBG_UTILS_TXT_PRINTER_PARAM_STR_ARR_LEN (sizeof(param_str_g) / sizeof(char*))

/************************************************
 *  Macros
 ***********************************************/
#define DBG_UTILS_TXT_PRINTER_PARAM_TO_STR(param_type) \
    (param_type <                                      \
     DBG_UTILS_TXT_PRINTER_PARAM_STR_ARR_LEN ? param_str_g[param_type] : "u")

/************************************************
 *  Type definitions
 ***********************************************/
struct txt_printer {
    FILE *txt_fp;
};

typedef struct draw_txt_tree_node_context {
    txt_printer_ptr         txt_printer_p;
    const dbg_utils_tree_t* tree;
    uint32_t                right_depth;
    boolean_t             * verticals;
    boolean_t               line_broken;
} draw_txt_tree_node_context_t;

/************************************************
 *  Global variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

static char* param_str_g[] =
{"u", "u", "u", "llu", "X", "s", "s", "s", "s", "s", "s", "s", "s", ".2f", "d", "X", "s", "x", PRIx64};

/************************************************
 *  Function declarations
 ***********************************************/
static void __type_to_str(dbg_utils_param_type_e type_enum, char *str_type);
static void __dbg_utils_txt_printer_3_digits_center_print(txt_printer_ptr txt_printer_p, uint32_t number);
static void __dbg_utils_txt_printer_binary_tree_node_draw(draw_txt_tree_node_context_t* context, uint32_t cur_node);

/************************************************
 *  Function implementations
 ***********************************************/
sx_utils_status_t dbg_utils_txt_printer_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

static void __type_to_str(dbg_utils_param_type_e type_enum, char *str_type)
{
    strcpy(str_type, DBG_UTILS_TXT_PRINTER_PARAM_TO_STR(type_enum));
}

static void __dbg_utils_txt_printer_3_digits_center_print(txt_printer_ptr txt_printer_p, uint32_t number)
{
    uint32_t before = 1, after = 1;

    if (number >= 100) {
        before = 0;
        after = 0;
    } else if (number >= 10) {
        before = 0;
        after = 1;
    }
    dbg_utils_txt_printer_print(txt_printer_p, "%*s%u%*s", before, "", number, after, "");
}

txt_printer_ptr dbg_utils_txt_printer_create(FILE *txt_fp)
{
    txt_printer_ptr txt_printer_p = cl_malloc(sizeof(*txt_printer_p));

    if (txt_printer_p) {
        txt_printer_p->txt_fp = txt_fp;
    }

    return txt_printer_p;
}

void dbg_utils_txt_printer_destroy(txt_printer_ptr txt_printer_p)
{
    cl_free(txt_printer_p);
}

void dbg_utils_txt_printer_fp_get(txt_printer_ptr txt_printer_p, FILE **txt_fpp)
{
    *txt_fpp = txt_printer_p->txt_fp;
}

void dbg_utils_txt_printer_print(txt_printer_ptr txt_printer_p, const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    vfprintf(txt_printer_p->txt_fp, fmt, args);
    va_end(args);
}

void dbg_utils_txt_printer_string_print(txt_printer_ptr txt_printer_p, const char *str)
{
    fprintf(txt_printer_p->txt_fp, "%s", str);
}

const char* dbg_utils_txt_printer_extended_str_print(txt_printer_ptr txt_printer_p, const char* str, int width)
{
    char        add[20];
    char        buf[width + 1];
    char        help_buf[width + 1];
    const char *p, *p_help;
    int         buf_count, help_buf_count;

    buf[0] = '\0';
    buf_count = 0;
    p = str;

    while (*p != '\0' && buf_count < width) {
        help_buf_count = 0;
        help_buf[0] = '\0';
        p_help = p;
        while (*p_help != ' ' && *p_help != '\0' && help_buf_count < width) {
            if ((*p_help > 32) && (*p_help < 127)) {
                help_buf[help_buf_count] = *p_help;
                help_buf_count++;
            }
            p_help++;
        }
        if ((*p_help != ' ') && (*p_help != '\0')) {
            dbg_utils_txt_printer_print(txt_printer_p, "/nERROR - the column's width is not enough/n/n");
            return NULL;
        }
        help_buf[help_buf_count] = '\0';
        if (help_buf_count + buf_count < width) {
            strcat(buf, help_buf);
            strcat(buf, " ");
            if (*p_help != '\0') {
                p_help++;
            }
            p = p_help;
            buf_count += help_buf_count + 1;
        } else {
            break;
        }
    }
    sprintf(add, "%%-%-us|", width);
    dbg_utils_txt_printer_print(txt_printer_p, add, buf);
    return p;
}

void dbg_utils_txt_printer_empty_clmn_print(txt_printer_ptr txt_printer_p, int width)
{
    char add[20];

    sprintf(add, "%%%us|", width);
    dbg_utils_txt_printer_print(txt_printer_p, add, ""); /* padding to columns[iii].width */
}

void dbg_utils_txt_printer_field_w_len_print(txt_printer_ptr        txt_printer_p,
                                             const char            *name,
                                             const void            *data,
                                             dbg_utils_param_type_e type,
                                             unsigned int           data_len)
{
    char buff[DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION];

    switch (type) {
    case PARAM_HEX_STRING_E:
        dbg_utils_string_hex_get(buff, sizeof(buff), (unsigned char*)data, data_len);
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %.*s\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    (char*)buff);
        break;

    default:
        SX_LOG_ERR("Internal error: wrong use of dbg_utils_param_type %u\n", type);
        break;
    }
}

void dbg_utils_txt_printer_field_simple_print(txt_printer_ptr        txt_printer_p,
                                              const char            *name,
                                              const void            *data,
                                              dbg_utils_param_type_e type)
{
    const char * str_p;
    uint8_t     *mac_p;
    uint32_t     ipv6_idx;

    switch (type) {
    case PARAM_UINT8_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %hu\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((uint8_t*)data));
        break;

    case PARAM_UINT16_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %u\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((uint16_t*)data));
        break;

    case PARAM_UINT32_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %u\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((uint32_t*)data));
        break;

    case PARAM_UINT64_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %" PRIu64 "\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((uint64_t*)data));
        break;

    case PARAM_HEX_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s 0x%X\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((uint32_t*)data));
        break;

    case PARAM_HEX16_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s 0x%X\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((uint16_t*)data));
        break;

    case PARAM_HEX64_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s 0x%" PRIx64 "\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((uint64_t*)data));
        break;

    case PARAM_PORT_ID_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s 0x%x\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((uint32_t*)data));
        break;

    case PARAM_STRING_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %.*s\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    DBG_UTILS_JSON_PRINTER_VAL_STR_PRECISION,
                                    (char*)data);
        break;

    case PARAM_EXT_STRING_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name);
        str_p =
            dbg_utils_txt_printer_extended_str_print(txt_printer_p, data, DBG_UTILS_JSON_PRINTER_VAL_STR_PRECISION);
        dbg_utils_txt_printer_print(txt_printer_p, "\n");

        while (*str_p != 0) {
            dbg_utils_txt_printer_print(txt_printer_p,
                                        "%-*.*s",
                                        DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                        DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                        "");
            str_p = dbg_utils_txt_printer_extended_str_print(txt_printer_p,
                                                             data,
                                                             DBG_UTILS_JSON_PRINTER_VAL_STR_PRECISION);
            dbg_utils_txt_printer_print(txt_printer_p, "\n");
        }
        break;

    case PARAM_BOOL_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %s\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((boolean_t*)data) ? "TRUE" : "FALSE");
        break;

    case PARAM_MAC_ADDR_E:
        mac_p = ((uint8_t*)(data));
        dbg_utils_txt_printer_print(txt_printer_p, "%-*.*s %.2X:%.2X:%.2X:%.2X:%.2X:%.2X\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    mac_p[0], mac_p[1], mac_p[2], mac_p[3], mac_p[4], mac_p[5]);
        break;

    case PARAM_IPV4_E:
    case PARAM_IPV4_MASK_E:
    {
        struct in_addr ip;
        char           addr[INET_ADDRSTRLEN];
        ip.s_addr = htonl(*((uint32_t*)data));
        if (!inet_ntop(AF_INET, &ip, addr, INET_ADDRSTRLEN)) {
            strcpy(addr, "???");
        }
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %s\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    addr);
        break;
    }

    case PARAM_IPV6_E:
    {
        struct in6_addr ipv6;
        char            addr[INET6_ADDRSTRLEN];
        for (ipv6_idx = 0; ipv6_idx < 4; ipv6_idx++) {
            ipv6.s6_addr32[ipv6_idx] = htonl(((struct in6_addr*)data)->s6_addr32[ipv6_idx]);
        }
        if (!inet_ntop(AF_INET6, &ipv6, addr, INET6_ADDRSTRLEN)) {
            strcpy(addr, "???");
        }
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %s\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    addr);
        break;
    }

    case PARAM_FC_ADDR_E:
    {
        uint8_t *map_p;
        map_p = ((uint8_t*)(data));
        dbg_utils_txt_printer_print(txt_printer_p, "%-*.*s %.2X:%.2X:%.2X\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH, DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name, map_p[0], map_p[1], map_p[2]);
        break;
    }

    case PARAM_DOUBLE_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %.2f\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((double*)data));
        break;

    case PARAM_INT_E:
        dbg_utils_txt_printer_print(txt_printer_p,
                                    "%-*.*s %d\n",
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_WIDTH,
                                    DBG_UTILS_TXT_PRINTER_DATA_STR_PRECISION,
                                    name,
                                    *((int*)data));
        break;

    default:
        SX_LOG_ERR("Internal error: wrong use of dbg_utils_param_type %u\n", type);
        break;
    }
}

void dbg_utils_txt_printer_module_header_print(txt_printer_ptr txt_printer_p, const char *module_name)
{
    dbg_utils_txt_printer_print(txt_printer_p, "\n***********************************************\n");
    dbg_utils_txt_printer_print(txt_printer_p, " %.48s \n", module_name);
    dbg_utils_txt_printer_print(txt_printer_p, "***********************************************\n");
}

void dbg_utils_txt_printer_table_headline_with_name_print(txt_printer_ptr            txt_printer_p,
                                                          dbg_utils_table_columns_t *columns,
                                                          char                     * name)
{
    int   i;
    char  add[20];
    int   num_of_columns = 0;
    int   total_width = 0;
    char *capitalized_name = NULL;

    UNUSED_PARAM(name);

    while (columns[num_of_columns].name) {
        total_width += columns[num_of_columns].width;
        num_of_columns++;
    }
    total_width += num_of_columns;

    if (total_width <= DBG_UTILS_SCRN_WIDTH_MAX) {
        dbg_utils_txt_printer_print(txt_printer_p, "\n");
        dbg_utils_txt_printer_separator_line_print(txt_printer_p, total_width, DBG_UTILS_DEFAULT_SEPARATOR_CHAR);

        for (i = 0; i < num_of_columns; i++) {
            capitalized_name = (char*)cl_malloc(strlen(columns[i].name) + 1);
            sprintf(add, "%%-%-us|", columns[i].width);
            dbg_utils_string_capitalize(columns[i].name, capitalized_name);
            dbg_utils_txt_printer_print(txt_printer_p, add, capitalized_name);
            cl_free(capitalized_name);
        }
        dbg_utils_txt_printer_print(txt_printer_p, "\n");
        dbg_utils_txt_printer_separator_line_print(txt_printer_p, total_width, DBG_UTILS_DEFAULT_SEPARATOR_CHAR);
    }
}

int dbg_utils_txt_printer_table_data_line_nosep_print(txt_printer_ptr            txt_printer_p,
                                                      dbg_utils_table_columns_t *columns)
{
    int                          i, k, ipv6_idx;
    char                         add[30];
    char                         str_type[20];
    char                         name[150];
    int                          column_print_flag[DBG_UTILS_COLUMN_NUM_MAX];
    const char                  *p;
    uint8_t                     *mac_ptr;
    uint8_t                     *fc_ptr;
    int                          more_to_print = 1;
    int                          num_of_columns = 0;
    int                          total_width = 0;
    int                          tbl_display = 0;
    dbg_utils_table_tlv_field_t *tlv_field_p;
    const void                 **original_data_p = NULL;

    while (columns[num_of_columns].name && (num_of_columns < DBG_UTILS_COLUMN_NUM_MAX)) {
        column_print_flag[num_of_columns] = 1;
        if (sizeof(name) <= (unsigned)columns[num_of_columns].width) {
            columns[num_of_columns].width = sizeof(name) - 1;
        }
        total_width += columns[num_of_columns].width;
        num_of_columns++;
    }
    total_width += num_of_columns;

    if (total_width <= DBG_UTILS_SCRN_WIDTH_MAX) {
        tbl_display = 1;
    }

    original_data_p = (const void**)cl_calloc(num_of_columns, sizeof(void *));
    if (original_data_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for %d backup pointers.\n", num_of_columns);
    }

    if (original_data_p != NULL) {
        for (i = 0; i < num_of_columns; i++) {
            original_data_p[i] = columns[i].data;
        }
    }

    while (more_to_print) {
        more_to_print = 0;
        for (i = 0; i < num_of_columns; i++) {
            __type_to_str(columns[i].type, str_type);
            snprintf(add, sizeof(add) - 1, "%%%-u%s|", columns[i].width, str_type);
            add[sizeof(add) - 1] = 0;

            switch (columns[i].type) {
            case PARAM_EXT_STRING_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        p = dbg_utils_txt_printer_extended_str_print(txt_printer_p,
                                                                     (char*)columns[i].data,
                                                                     columns[i].width);
                        if ((p == NULL) || (0 == *p)) {
                            column_print_flag[i] = 0;
                        } else {
                            columns[i].data = p;
                            more_to_print++;
                        }
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_STRING_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        snprintf(add, sizeof(add) - 1, "%%-%-u%s|", columns[i].width, str_type);
                        /* limit name up to width */
                        strncpy(name, (char*)columns[i].data, sizeof(name) - 1);
                        name[sizeof(name) - 1] = 0;
                        name[columns[i].width] = 0;
                        dbg_utils_txt_printer_print(txt_printer_p, add, name);
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_MAC_ADDR_E:
                mac_ptr = ((uint8_t*)(columns[i].data));
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        k = columns[i].width - 17;
                        sprintf(add, "%%%us", k >= 0 ? k : 2);
                        dbg_utils_txt_printer_print(txt_printer_p, add, "");
                        dbg_utils_txt_printer_print(txt_printer_p,
                                                    "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X|",
                                                    mac_ptr[0],
                                                    mac_ptr[1],
                                                    mac_ptr[2],
                                                    mac_ptr[3],
                                                    mac_ptr[4],
                                                    mac_ptr[5]);
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_FC_ADDR_E:
                fc_ptr = ((uint8_t*)(columns[i].data));
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        k = columns[i].width - 8;
                        sprintf(add, "%%%us", k >= 0 ? k : 2);
                        dbg_utils_txt_printer_print(txt_printer_p, add, "");
                        dbg_utils_txt_printer_print(txt_printer_p, "%.2X:%.2X:%.2X|", fc_ptr[0], fc_ptr[1], fc_ptr[2]);
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_IPV4_E:
            case PARAM_IPV4_MASK_E:
            {
                struct in_addr ip;
                char           addr[20];
                ip.s_addr = htonl(*((uint32_t*)(columns[i].data)));
                if (!inet_ntop(AF_INET, &ip, addr, 20)) {
                    strcpy(addr, "???");
                }
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        k = columns[i].width - strlen(addr);
                        sprintf(add, "%%%us", k >= 0 ? k : 2);
                        dbg_utils_txt_printer_print(txt_printer_p, add, "");
                        dbg_utils_txt_printer_print(txt_printer_p, "%s|", addr);
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;
            }

            case PARAM_IPV6_E:
            {
                struct in6_addr ipv6;
                char            addr[44];
                for (ipv6_idx = 0; ipv6_idx < 4; ipv6_idx++) {
                    ipv6.s6_addr32[ipv6_idx] =
                        htonl(((struct in6_addr*)columns[i].data)->s6_addr32[ipv6_idx]);
                }
                if (!inet_ntop(AF_INET6, &ipv6, addr, 44)) {
                    strcpy(addr, "???");
                }
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        k = columns[i].width - strlen(addr);
                        sprintf(add, "%%%us", k >= 0 ? k : 2);
                        dbg_utils_txt_printer_print(txt_printer_p, add, "");
                        dbg_utils_txt_printer_print(txt_printer_p, "%s|", addr);
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;
            }

            case PARAM_HEX64_E:
                sprintf(add, "0x%%.%u%s|", columns[i].width - 2, str_type);

            /* fall through */
            case PARAM_UINT64_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_txt_printer_print(txt_printer_p, add, *((uint64_t*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_BOOL_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        snprintf(add, sizeof(add) - 1, "%%-%-u%s|", columns[i].width, str_type);
                        dbg_utils_txt_printer_print(txt_printer_p, add, *((uint32_t*)(columns[i].data)) ?
                                                    "TRUE" : "FALSE");
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_UINT8_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_txt_printer_print(txt_printer_p, add, *((uint8_t*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_HEX16_E:
                sprintf(add, "0x%%.%u%s|", columns[i].width - 2, str_type);

            /* fall through */
            case PARAM_UINT16_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_txt_printer_print(txt_printer_p, add, *((uint16_t*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_DOUBLE_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_txt_printer_print(txt_printer_p, add, *((double*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_INT_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_txt_printer_print(txt_printer_p, add, *((int*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_HEX_STRING_E:
                tlv_field_p = (dbg_utils_table_tlv_field_t*)columns[i].data;
                if (!tbl_display || column_print_flag[i]) {
                    if (tlv_field_p->data_len > DBG_UTILS_SCRN_WIDTH_MAX) {
                        SX_LOG_ERR("Internal error: bad length of field:%d type:%u\n", i, columns[i].type);
                        continue;
                    }
                }
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        if (sizeof(name) < (unsigned)columns[i].width) {
                            columns[i].width = sizeof(name);
                        }
                        dbg_utils_string_hex_get(name, columns[i].width,
                                                 (unsigned char*)tlv_field_p->data,
                                                 tlv_field_p->data_len);
                        dbg_utils_txt_printer_print(txt_printer_p, add, name);
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_w_len_print(txt_printer_p, columns[i].name,
                                                            tlv_field_p->data,
                                                            columns[i].type,
                                                            tlv_field_p->data_len);
                }
                break;

            case PARAM_PORT_ID_E:
                sprintf(add, "0x%%-%u%s|", columns[i].width - 2, str_type);
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_txt_printer_print(txt_printer_p, add, *((uint32_t*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;

            case PARAM_HEX_E:
                sprintf(add, "0x%%.%u%s|", columns[i].width - 2, str_type);

            /* fall through */

            case PARAM_UINT32_E:
            default:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_txt_printer_print(txt_printer_p, add, *((uint32_t*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        dbg_utils_txt_printer_empty_clmn_print(txt_printer_p, columns[i].width);
                    }
                } else {
                    dbg_utils_txt_printer_field_simple_print(txt_printer_p,
                                                             columns[i].name,
                                                             columns[i].data,
                                                             columns[i].type);
                }
                break;
            } /*switch*/
        } /*for*/

        if (tbl_display) {
            dbg_utils_txt_printer_print(txt_printer_p, "\n");
        }
    } /*while*/

    if (original_data_p != NULL) {
        for (i = 0; i < num_of_columns; i++) {
            columns[i].data = original_data_p[i];
        }

        cl_free(original_data_p);
        original_data_p = NULL;
    }

    return total_width;
}

void dbg_utils_txt_printer_separator_line_print(txt_printer_ptr txt_printer_p, int total_width, char separator_char)
{
    char separator_line[DBG_UTILS_SCRN_WIDTH_MAX + 1];

    if (total_width > DBG_UTILS_SCRN_WIDTH_MAX) {
        total_width = DBG_UTILS_SCRN_WIDTH_MAX;
    }

    memset(separator_line, 0, sizeof(separator_line));
    memset(separator_line, separator_char, total_width);
    dbg_utils_txt_printer_print(txt_printer_p, "%s\n", separator_line);
}

void dbg_utils_txt_printer_counters_group_header_print(txt_printer_ptr txt_printer_p,
                                                       const char     *cntr_grp_name,
                                                       uint32_t        port_id)
{
    dbg_utils_txt_printer_print(txt_printer_p, "\n Port 0x%x - %.30s Counters Group \n", port_id, cntr_grp_name);
    dbg_utils_txt_printer_print(txt_printer_p, "==================================================\n");
}

void dbg_utils_txt_printer_counters_group_sub_header_print(txt_printer_ptr txt_printer_p, const char *buf)
{
    dbg_utils_txt_printer_print(txt_printer_p, "\n");

    fprintf(txt_printer_p->txt_fp, "%s", buf);

    dbg_utils_txt_printer_print(txt_printer_p, "\n..............................\n");
}

void dbg_utils_txt_printer_counter_print(txt_printer_ptr txt_printer_p, const char *cntr_name, uint64_t cntr_value)
{
    dbg_utils_txt_printer_field_simple_print(txt_printer_p, cntr_name, &cntr_value, PARAM_UINT64_E);
}

void dbg_utils_txt_printer_general_header_print(txt_printer_ptr txt_printer_p, const char *general_header)
{
    dbg_utils_txt_printer_print(txt_printer_p, "\n..................................................\n");
    dbg_utils_txt_printer_print(txt_printer_p, " %.48s \n", general_header);
    dbg_utils_txt_printer_print(txt_printer_p, "..................................................\n");
}

void dbg_utils_txt_printer_sub_module_header_print(txt_printer_ptr txt_printer_p, const char *sub_module_header)
{
    dbg_utils_txt_printer_print(txt_printer_p, "\n--------------------------------------------------\n");
    dbg_utils_txt_printer_print(txt_printer_p, " %.48s \n", sub_module_header);
    dbg_utils_txt_printer_print(txt_printer_p, "--------------------------------------------------\n");
}

void dbg_utils_txt_printer_plain_text_secondary_header_print(txt_printer_ptr txt_printer_p, const char *buf)
{
    dbg_utils_txt_printer_print(txt_printer_p, "\n");

    fprintf(txt_printer_p->txt_fp, "%s", buf);

    dbg_utils_txt_printer_print(txt_printer_p, "\n..............................\n");
}

void dbg_utils_txt_printer_user_defined_header_print(txt_printer_ptr txt_printer_p, const char       *buf)
{
    dbg_utils_txt_printer_plain_text_secondary_header_print(txt_printer_p, buf);
}

void dbg_utils_txt_printer_secondary_header_print(txt_printer_ptr txt_printer_p, const char *buf)
{
    dbg_utils_txt_printer_plain_text_secondary_header_print(txt_printer_p, buf);
}

void dbg_utils_txt_printer_time_stamp_print(txt_printer_ptr txt_printer_p, const char * name, char *stime)
{
    dbg_utils_txt_printer_print(txt_printer_p, "\n%s: %s\n", name, stime);
}

static void __dbg_utils_txt_printer_binary_tree_node_draw(draw_txt_tree_node_context_t* context, uint32_t cur_node)
{
    uint32_t depth = 0;

    if (cur_node > context->tree->node_count) {
        SX_LOG_ERR("Cannot dump tree node %u which is out of bound %u\n", cur_node, context->tree->node_count);
        return;
    }

    if (context->line_broken) {
        for (depth = 0; depth < context->right_depth; depth++) {
            if (context->verticals[depth]) {
                dbg_utils_txt_printer_print(context->txt_printer_p, " |    ");
            } else {
                dbg_utils_txt_printer_print(context->txt_printer_p, "      ");
            }
        }
        dbg_utils_txt_printer_print(context->txt_printer_p, " |\n");
        for (depth = 0; depth < context->right_depth; depth++) {
            if (context->verticals[depth]) {
                dbg_utils_txt_printer_print(context->txt_printer_p, " |    ");
            } else {
                dbg_utils_txt_printer_print(context->txt_printer_p, "      ");
            }
        }
        context->line_broken = FALSE;
    }

    __dbg_utils_txt_printer_3_digits_center_print(context->txt_printer_p, cur_node);

    if (context->tree->nodes[cur_node].right_child != 0) {
        dbg_utils_txt_printer_print(context->txt_printer_p, "---");
    }

    if (context->tree->nodes[cur_node].left_child != 0) {
        context->verticals[context->right_depth] = TRUE;
    } else {
        context->verticals[context->right_depth] = FALSE;
    }

    if (context->tree->nodes[cur_node].right_child != 0) {
        context->right_depth++;

        __dbg_utils_txt_printer_binary_tree_node_draw(context, context->tree->nodes[cur_node].right_child);

        context->right_depth--;
    } else {
        dbg_utils_txt_printer_print(context->txt_printer_p, "\n");
        context->line_broken = TRUE;
    }

    if (context->tree->nodes[cur_node].left_child != 0) {
        __dbg_utils_txt_printer_binary_tree_node_draw(context, context->tree->nodes[cur_node].left_child);
    }

    context->verticals[context->right_depth] = FALSE;
}

void dbg_utils_txt_printer_binary_tree_draw(txt_printer_ptr txt_printer_p, const dbg_utils_tree_t* tree)
{
    boolean_t                    verticals[DBG_UTILS_NODES_MAX];
    draw_txt_tree_node_context_t context;

    memset(verticals, 0, sizeof(verticals));
    context.txt_printer_p = txt_printer_p;
    context.tree = tree;
    context.right_depth = 0;
    context.verticals = verticals;
    context.line_broken = FALSE;

    __dbg_utils_txt_printer_binary_tree_node_draw(&context, tree->root);
}

void dbg_utils_txt_printer_data_unavailable_print(txt_printer_ptr txt_printer_p)
{
    dbg_utils_txt_printer_print(txt_printer_p, "\nData is currently unavailable\n");
}
