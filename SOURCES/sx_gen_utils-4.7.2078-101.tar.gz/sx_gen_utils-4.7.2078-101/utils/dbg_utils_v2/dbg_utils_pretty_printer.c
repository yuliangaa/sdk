/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#undef  __MODULE__
#define __MODULE__ DBG_UTILS_PRETTY_PRINTER

#include <time.h>

#include "complib/cl_spinlock.h"

#include "sx/utils/dbg_utils_string.h"
#include "sx/utils/dbg_utils_txt_printer.h"
#include "sx/utils/dbg_utils_json_printer.h"

#include "sx/utils/dbg_utils_pretty_printer.h"

/************************************************
 *  Defines
 ***********************************************/
#define DBG_UTILS_PPRINTER_DB_SIZE 16

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct dbg_utils_pprinter {
    txt_printer_ptr  txt_printer_p;
    json_printer_ptr json_printer_p;
    cheat_sheet_ptr  cheat_sheet_p;
} dbg_utils_pprinter_t;

typedef struct dbg_utils_json_printer_writers_db_entry {
    FILE               * key;
    dbg_utils_pprinter_t data;
} dbg_utils_json_printer_writers_db_entry_t;

typedef struct dbg_utils_json_printer_writers_db {
    cl_spinlock_t                             entries_lock;
    dbg_utils_json_printer_writers_db_entry_t entries[DBG_UTILS_PPRINTER_DB_SIZE];
} dbg_utils_json_printer_writers_db;

/************************************************
 *  Global variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

static dbg_utils_json_printer_writers_db g_json_writers_db;

/************************************************
 *  Function declarations
 ***********************************************/
static sx_utils_status_t __dbg_utils_pprinter_get(FILE* key, dbg_utils_pprinter_t **dbg_writer_p);

/************************************************
 *  Function implementations
 ***********************************************/
static sx_utils_status_t __dbg_utils_pprinter_add(dbg_utils_json_printer_writers_db_entry_t *entry_p,
                                                  FILE                                      *key,
                                                  const dbg_utils_pprinter_params_t         *params_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    entry_p->key = key;

    if (params_p->txt_fp) {
        entry_p->data.txt_printer_p = dbg_utils_txt_printer_create(params_p->txt_fp);
    } else {
        entry_p->data.txt_printer_p = NULL;
    }

    if (params_p->json_fp) {
        entry_p->data.json_printer_p = dbg_utils_json_printer_create(params_p->json_fp, params_p->json_compressed);
    } else {
        entry_p->data.json_printer_p = NULL;
    }

    entry_p->data.cheat_sheet_p = params_p->cheat_sheet_p;

    return err;
}

static sx_utils_status_t __dbg_utils_pprinter_remove(dbg_utils_json_printer_writers_db_entry_t *entry_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if (entry_p->data.txt_printer_p != NULL) {
        dbg_utils_txt_printer_destroy(entry_p->data.txt_printer_p);
    }
    if (entry_p->data.json_printer_p != NULL) {
        dbg_utils_json_printer_destroy(entry_p->data.json_printer_p);
    }

    entry_p->key = NULL;

    return err;
}

sx_utils_status_t dbg_utils_pprinter_init(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    memset(&g_json_writers_db, 0, sizeof(g_json_writers_db));

    cl_spinlock_init(&g_json_writers_db.entries_lock);

    return err;
}

sx_utils_status_t dbg_utils_pprinter_deinit(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t pr_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          idx = 0;

    for (idx = 0; idx < DBG_UTILS_PPRINTER_DB_SIZE; idx++) {
        if (g_json_writers_db.entries[idx].key != NULL) {
            pr_err = __dbg_utils_pprinter_remove(&g_json_writers_db.entries[idx]);
            if (pr_err) {
                err = pr_err;
                continue;
            }
        }
    }

    return err;
}

sx_utils_status_t dbg_utils_pprinter_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    (void)dbg_utils_txt_printer_log_verbosity_level_set(verbosity_level);
    (void)dbg_utils_json_printer_log_verbosity_level_set(verbosity_level);
    (void)dbg_utils_cheat_sheet_log_verbosity_level_set(verbosity_level);

    return err;
}

sx_utils_status_t dbg_utils_pprinter_add(FILE *key, const dbg_utils_pprinter_params_t *params_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          idx = 0;
    boolean_t         found = FALSE;

    /**
     * Multiple threads may access this function to
     * modify the same resource (a free DB entry) at the same time.
     *
     * The rest of the APIs are designed to be called from the same thread for one given printer and,
     * therefore, do not require synchronization.
     */
    cl_spinlock_acquire(&g_json_writers_db.entries_lock);

    for (idx = 0; idx < DBG_UTILS_PPRINTER_DB_SIZE; idx++) {
        if (g_json_writers_db.entries[idx].key == NULL) {
            err = __dbg_utils_pprinter_add(&g_json_writers_db.entries[idx], key, params_p);
            if (err) {
                goto out;
            }

            found = TRUE;
            break;
        }
    }

    if (found == FALSE) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
    }

out:
    cl_spinlock_release(&g_json_writers_db.entries_lock);

    return err;
}

sx_utils_status_t dbg_utils_pprinter_remove(FILE* key)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          idx = 0;
    boolean_t         found = FALSE;

    for (idx = 0; idx < DBG_UTILS_PPRINTER_DB_SIZE; idx++) {
        if (g_json_writers_db.entries[idx].key == key) {
            err = __dbg_utils_pprinter_remove(&g_json_writers_db.entries[idx]);
            if (err) {
                goto out;
            }

            found = TRUE;
            break;
        }
    }

    if (found == FALSE) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    }

out:
    return err;
}

sx_utils_status_t __dbg_utils_pprinter_get(FILE* key, dbg_utils_pprinter_t **dbg_writer_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          idx = 0;
    boolean_t         found = FALSE;

    for (idx = 0; idx < DBG_UTILS_PPRINTER_DB_SIZE; idx++) {
        if (g_json_writers_db.entries[idx].key == key) {
            *dbg_writer_p = &g_json_writers_db.entries[idx].data;
            found = TRUE;
            break;
        }
    }

    if (found == FALSE) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    }

    return err;
}

cheat_sheet_ptr dbg_utils_pprinter_cheat_sheet_ptr_get(FILE *key)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return NULL;
    }

    return printer_p->cheat_sheet_p;
}

void dbg_utils_pprinter_txt_fp_get(FILE* key, FILE **txt_fpp)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p == NULL) {
        return;
    }

    dbg_utils_txt_printer_fp_get(printer_p->txt_printer_p, txt_fpp);
}

void dbg_utils_pprinter_print(FILE* key, const char *fmt, ...)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p == NULL) {
        return;
    }

    char    buffer[1024];
    va_list args;

    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    dbg_utils_txt_printer_string_print(printer_p->txt_printer_p, buffer);
}

void dbg_utils_pprinter_txt_string_print(FILE* key, const char *buffer)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p == NULL) {
        return;
    }

    dbg_utils_txt_printer_string_print(printer_p->txt_printer_p, buffer);
}

void dbg_utils_pprinter_field_print(FILE *key, const char *name, const void *data, dbg_utils_param_type_e type)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_field_simple_print(printer_p->txt_printer_p, name, data, type);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_field_simple_print(printer_p->json_printer_p, name, data, type);
    }
}

void dbg_utils_pprinter_field_with_level_print(FILE                  *key,
                                               const char            *name,
                                               const void            *data,
                                               dbg_utils_param_type_e type,
                                               dbg_utils_level_e      new_level)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_field_simple_print(printer_p->txt_printer_p, name, data, type);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_field_with_level_print(printer_p->json_printer_p, name, data, type, new_level);
    }
}

void dbg_utils_pprinter_module_header_print(FILE *key, const char *module_name)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_module_header_print(printer_p->txt_printer_p, module_name);
    }

    if (printer_p->cheat_sheet_p != NULL) {
        dbg_utils_cheat_sheet_module_header_print(printer_p->cheat_sheet_p, module_name);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_module_header_print(printer_p->json_printer_p, module_name);
    }
}

void dbg_utils_pprinter_table_headline_with_name_print(FILE *key, dbg_utils_table_columns_t *columns, char * name)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_table_headline_with_name_print(printer_p->txt_printer_p, columns, name);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_table_headline_with_name_print(printer_p->json_printer_p, columns, name);
    }
}

int dbg_utils_pprinter_table_data_line_nosep_print(FILE *key, dbg_utils_table_columns_t *columns)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;
    int                    total_width = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return total_width;
    }

    if (printer_p->txt_printer_p != NULL) {
        total_width = dbg_utils_txt_printer_table_data_line_nosep_print(printer_p->txt_printer_p, columns);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_table_data_line_nosep_print(printer_p->json_printer_p, columns);
    }

    return total_width;
}

int dbg_utils_pprinter_table_data_line_print(FILE *key, dbg_utils_table_columns_t *columns)
{
    int total_width = 0;

    total_width = dbg_utils_pprinter_table_data_line_nosep_print(key, columns);
    dbg_utils_pprinter_separator_line_print(key, total_width, DBG_UTILS_DEFAULT_SEPARATOR_CHAR);
    return total_width;
}

void dbg_utils_pprinter_separator_line_print(FILE *key, int total_width, char separator_char)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_separator_line_print(printer_p->txt_printer_p, total_width, separator_char);
    }
}

void dbg_utils_pprinter_counters_group_header_print(FILE *key, const char *cntr_grp_name, uint32_t port_id)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_counters_group_header_print(printer_p->txt_printer_p, cntr_grp_name, port_id);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_counters_group_header_print(printer_p->json_printer_p, cntr_grp_name, port_id);
    }
}

void dbg_utils_pprinter_counters_group_sub_header_print(FILE *key, const char *headline_fmt, ...)
{
    va_list                args;
    char                   cptl_headline_fmt[strlen(headline_fmt) + 1];
    char                   buf[DBG_UTILS_JSON_BUF_SIZE];
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    dbg_utils_string_capitalize(headline_fmt, cptl_headline_fmt);

    va_start(args, headline_fmt);
    vsnprintf(buf, sizeof(buf), cptl_headline_fmt, args);
    va_end(args);

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_counters_group_sub_header_print(printer_p->txt_printer_p, buf);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_counters_group_sub_header_print(printer_p->json_printer_p, buf);
    }
}

void dbg_utils_pprinter_counter_print(FILE *key, const char *cntr_name, uint64_t cntr_value)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_counter_print(printer_p->txt_printer_p, cntr_name, cntr_value);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_counter_print(printer_p->json_printer_p, cntr_name, cntr_value);
    }
}

void dbg_utils_pprinter_counter_with_level_print(FILE             *key,
                                                 const char       *cntr_name,
                                                 uint64_t          cntr_value,
                                                 dbg_utils_level_e new_level)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_counter_print(printer_p->txt_printer_p, cntr_name, cntr_value);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_counter_with_level_print(printer_p->json_printer_p, cntr_name, cntr_value, new_level);
    }
}

void dbg_utils_pprinter_general_header_print(FILE *key, const char *general_header)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_general_header_print(printer_p->txt_printer_p, general_header);
    }

    if (printer_p->cheat_sheet_p != NULL) {
        dbg_utils_cheat_sheet_general_header_print(printer_p->cheat_sheet_p, general_header);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_general_header_print(printer_p->json_printer_p, general_header);
    }
}

void dbg_utils_pprinter_sub_module_header_print(FILE *key, const char *sub_module_header)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_sub_module_header_print(printer_p->txt_printer_p, sub_module_header);
    }

    if (printer_p->cheat_sheet_p != NULL) {
        dbg_utils_cheat_sheet_sub_module_header_print(printer_p->cheat_sheet_p, sub_module_header);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_sub_module_header_print(printer_p->json_printer_p, sub_module_header);
    }
}

void dbg_utils_pprinter_plain_text_secondary_header_print(FILE *key, const char *headline_fmt, ...)
{
    va_list                args;
    char                   cptl_headline_fmt[strlen(headline_fmt) + 1];
    char                   buf[1024];
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    dbg_utils_string_capitalize(headline_fmt, cptl_headline_fmt);

    va_start(args, headline_fmt);
    vsnprintf(buf, sizeof(buf), cptl_headline_fmt, args);
    va_end(args);

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_plain_text_secondary_header_print(printer_p->txt_printer_p, buf);
    }
}

void dbg_utils_pprinter_user_defined_header_print(FILE             *key,
                                                  dbg_utils_level_e user_defined_level,
                                                  const char       *headline_fmt,
                                                  ...)
{
    va_list                args;
    char                   cptl_headline_fmt[strlen(headline_fmt) + 1];
    char                   buf[DBG_UTILS_JSON_BUF_SIZE];
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    dbg_utils_string_capitalize(headline_fmt, cptl_headline_fmt);

    va_start(args, headline_fmt);
    vsnprintf(buf, sizeof(buf), cptl_headline_fmt, args);
    va_end(args);

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_user_defined_header_print(printer_p->txt_printer_p, buf);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_user_defined_header_print(printer_p->json_printer_p, user_defined_level, buf);
    }
}

void dbg_utils_pprinter_secondary_header_print(FILE *key, const char *headline_fmt, ...)
{
    va_list                args;
    char                   cptl_headline_fmt[strlen(headline_fmt) + 1];
    char                   buf[DBG_UTILS_JSON_BUF_SIZE];
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    dbg_utils_string_capitalize(headline_fmt, cptl_headline_fmt);

    va_start(args, headline_fmt);
    vsnprintf(buf, sizeof(buf), cptl_headline_fmt, args);
    va_end(args);

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_secondary_header_print(printer_p->txt_printer_p, buf);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_secondary_header_print(printer_p->json_printer_p, buf);
    }
}

void dbg_utils_pprinter_time_stamp_print(FILE *key, const char * name)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;
    time_t                 ltime;
    struct tm              result;
    char                   stime[32];

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    ltime = time(NULL);
    localtime_r(&ltime, &result);
    asctime_r(&result, stime);

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_time_stamp_print(printer_p->txt_printer_p, name, stime);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_time_stamp_print(printer_p->json_printer_p, name, stime);
    }
}

void dbg_utils_pprinter_binary_tree_draw(FILE *key, const dbg_utils_tree_t* tree)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    if (tree->root > tree->node_count) {
        SX_LOG_ERR("Fail to draw binary tree because root is deeper than node, and json tree may be broken\n");
        return;
    }

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_binary_tree_draw(printer_p->txt_printer_p, tree);
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_binary_tree_draw(printer_p->json_printer_p, tree);
    }
}

void dbg_utils_pprinter_data_unavailable_print(FILE *key)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->txt_printer_p != NULL) {
        dbg_utils_txt_printer_data_unavailable_print(printer_p->txt_printer_p);
    }
}

void dbg_utils_pprinter_json_header_object_create(FILE             *key,
                                                  dbg_utils_level_e current_level,
                                                  const char      * object_name,
                                                  boolean_t         is_table)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_header_object_create(printer_p->json_printer_p, current_level, object_name, is_table);
    }
}

void dbg_utils_pprinter_json_string_object_create(FILE *key, dbg_utils_level_e current_level, char *value)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_string_object_create(printer_p->json_printer_p, current_level, value);
    }
}

void dbg_utils_pprinter_json_table_item_create(FILE *key, dbg_utils_level_e current_level)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_table_item_create(printer_p->json_printer_p, current_level);
    }
}

void dbg_utils_pprinter_json_table_name_set(FILE *key, char *table_name)
{
    dbg_utils_pprinter_t * printer_p = NULL;
    int                    rc = 0;

    rc = __dbg_utils_pprinter_get(key, &printer_p);
    if (rc != 0) {
        return;
    }

    if (printer_p->json_printer_p != NULL) {
        dbg_utils_json_printer_table_name_set(printer_p->json_printer_p, table_name);
    }
}
