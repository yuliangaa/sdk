/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#undef  __MODULE__
#define __MODULE__ DBG_UTILS_JSON_PRINTER

#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "complib/cl_types.h"
#include "complib/cl_mem.h"

#include "sx/utils/dbg_utils_types.h"
#include "sx/utils/dbg_utils_string.h"
#include "sx/utils/dbg_utils_json_printer.h"

/************************************************
 *  Defines
 ***********************************************/
#define DBG_UTILS_JSON_PRINTER_DATA_STR_PRECISION 65

/*Max level here is increased by 128 to accommodate the SHSPM tree dump in tree format.*/
#define DBG_UTILS_JSON_PRINTER_LEVEL_MAX (DBG_UTILS_NODES_MAX + DBG_UTILS_LEVEL_MAX_E + 1)

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
/* json object stack, for json print */
typedef struct _sx_stack_json_t {
    char      type; /* '}' as object ,']' as array*/
    boolean_t has_child; /*This is set at run time when new child is encountered to add "," after the previous one.*/
    int16_t   level;  /*This is passed during the invocation of dump inside SDK code*/
} sx_stack_json_t;

typedef void (*json_stack_rewind_pfn)(json_printer_ptr json_printer_p, dbg_utils_level_e new_level);
typedef void (*json_stack_final_rewind_pfn)(json_printer_ptr json_printer_p);

struct json_printer {
    FILE                       *json_fp;
    boolean_t                   valid;
    int32_t                     stack_json_top;
    sx_stack_json_t             stacked_json_arr[DBG_UTILS_JSON_PRINTER_LEVEL_MAX];
    char                        json_table_name[DBG_UTILS_JSON_BUF_SIZE]; /* for table name setting in stack json print */
    json_stack_rewind_pfn       json_stack_rewind_cb;
    json_stack_final_rewind_pfn json_stack_final_rewind_cb;
};

typedef struct draw_json_tree_node_context {
    json_printer_ptr        json_printer_p;
    const dbg_utils_tree_t* tree;
    uint32_t                right_depth;
    boolean_t             * verticals;
} draw_json_tree_node_context_t;

/************************************************
 *  Global variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Function declarations
 ***********************************************/
/**
 * __dbg_utils_json_printer_stack_rewind
 *
 * rewind stack to given level. usually called when we print objects at
 * the same level or when an object is encountered that needs to be printed in
 * the next level.
 *
 */
static void __dbg_utils_json_printer_stack_rewind(json_printer_ptr json_printer_p, dbg_utils_level_e new_level);
static void __dbg_utils_json_printer_stack_rewind_compressed(json_printer_ptr  json_printer_p,
                                                             dbg_utils_level_e new_level);

static void __dbg_utils_json_printer_stack_final_rewind(json_printer_ptr json_printer_p);
static void __dbg_utils_json_printer_stack_final_rewind_compressed(json_printer_ptr json_printer_p);

static void __dbg_utils_json_printer_data_object_create(json_printer_ptr  json_printer_p,
                                                        dbg_utils_level_e new_level,
                                                        const char       *name,
                                                        char             *value);
/************************************************
 *  Function implementations
 ***********************************************/
sx_utils_status_t dbg_utils_json_printer_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

json_printer_ptr dbg_utils_json_printer_create(FILE *json_fp, boolean_t json_compressed)
{
    json_printer_ptr json_printer_p = cl_malloc(sizeof(*json_printer_p));

    if (json_printer_p) {
        json_printer_p->json_fp = json_fp;
        json_printer_p->valid = TRUE;
        json_printer_p->stack_json_top = 0;
        json_printer_p->stacked_json_arr[0].type = '}';
        json_printer_p->stacked_json_arr[0].has_child = FALSE;
        json_printer_p->stacked_json_arr[0].level = 0;

        json_printer_p->json_table_name[0] = '\0';

        if (json_compressed) {
            json_printer_p->json_stack_rewind_cb = __dbg_utils_json_printer_stack_rewind_compressed;
            json_printer_p->json_stack_final_rewind_cb = __dbg_utils_json_printer_stack_final_rewind_compressed;
        } else {
            json_printer_p->json_stack_rewind_cb = __dbg_utils_json_printer_stack_rewind;
            json_printer_p->json_stack_final_rewind_cb = __dbg_utils_json_printer_stack_final_rewind;
        }

        dbg_utils_json_printer_print(json_printer_p, "{");
    }

    return json_printer_p;
}


static void __dbg_utils_json_printer_stack_final_rewind(json_printer_ptr json_printer_p)
{
#define DBG_UTILS_JSON_PRINTER_INDENT "  "
    int i = 0;
    /*rewind the current level to given level*/
    while (json_printer_p->stack_json_top) {
        /* Move cursor to the correct position to put the closing "}" or "]"*/
        if (json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].has_child) {
            dbg_utils_json_printer_print(json_printer_p, "\n");
            for (i = 0; i < json_printer_p->stack_json_top; i++) {
                dbg_utils_json_printer_print(json_printer_p, DBG_UTILS_JSON_PRINTER_INDENT);
            }
        }
        dbg_utils_json_printer_print(json_printer_p, "%c",
                                     json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].type);
        --json_printer_p->stack_json_top;
    }
}


static void __dbg_utils_json_printer_stack_final_rewind_compressed(json_printer_ptr json_printer_p)
{
    /*rewind the current level to given level*/
    while (json_printer_p->stack_json_top) {
        dbg_utils_json_printer_print(json_printer_p, "%c",
                                     json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].type);
        --json_printer_p->stack_json_top;
    }
}


void dbg_utils_json_printer_destroy(json_printer_ptr json_printer_p)
{
    json_printer_p->json_stack_final_rewind_cb(json_printer_p);
    dbg_utils_json_printer_print(json_printer_p, "\n}");

    cl_free(json_printer_p);
}

void dbg_utils_json_printer_print(json_printer_ptr json_printer_p, const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    vfprintf(json_printer_p->json_fp, fmt, args);
    va_end(args);
}

static void __dbg_utils_json_printer_stack_rewind(json_printer_ptr json_printer_p, dbg_utils_level_e new_level)
{
#define DBG_UTILS_JSON_PRINTER_INDENT "  "
    int i = 0;
    /*rewind the current level to given level*/
    while (json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].level >= (int)new_level) {
        /* Move cursor to the correct position to put the closing "}" or "]"*/
        if (json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].has_child) {
            dbg_utils_json_printer_print(json_printer_p, "\n");
            for (i = 0; i < json_printer_p->stack_json_top; i++) {
                dbg_utils_json_printer_print(json_printer_p, DBG_UTILS_JSON_PRINTER_INDENT);
            }
        }
        dbg_utils_json_printer_print(json_printer_p, "%c",
                                     json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].type);
        --json_printer_p->stack_json_top;
        if (json_printer_p->stack_json_top < 0) {
            SX_LOG_ERR("stacked_json_arr underflow\n");
            json_printer_p->valid = FALSE;
            return;
        }
    }

    if (json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].has_child) {
        dbg_utils_json_printer_print(json_printer_p, ",\n");
    } else {
        dbg_utils_json_printer_print(json_printer_p, "\n");
    }
    /*set child as true so that comma can be added along with closing braces next time if there are more children, otherwise just closing braces will be added by above snippet.*/
    json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].has_child = TRUE;
    for (i = 0; i < json_printer_p->stack_json_top + 1; i++) {
        dbg_utils_json_printer_print(json_printer_p, DBG_UTILS_JSON_PRINTER_INDENT);
    }
}

static void __dbg_utils_json_printer_stack_rewind_compressed(json_printer_ptr  json_printer_p,
                                                             dbg_utils_level_e new_level)
{
    /*rewind the current level to given level*/
    while (json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].level >= (int)new_level) {
        dbg_utils_json_printer_print(json_printer_p, "%c",
                                     json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].type);
        --json_printer_p->stack_json_top;
        if (json_printer_p->stack_json_top < 0) {
            SX_LOG_ERR("stacked_json_arr underflow\n");
            json_printer_p->valid = FALSE;
            return;
        }
    }

    if (json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].has_child) {
        dbg_utils_json_printer_print(json_printer_p, ",");
    }

    /*set child as true so that comma can be added along with closing braces next time if there are more children, otherwise just closing braces will be added by above snippet.*/
    json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].has_child = TRUE;
}

void dbg_utils_json_printer_header_object_create(json_printer_ptr  json_printer_p,
                                                 dbg_utils_level_e new_level,
                                                 const char      * object_name,
                                                 boolean_t         is_table)
{
    char table_name_str[DBG_UTILS_JSON_BUF_SIZE];

    if (!json_printer_p->valid) {
        return;
    }

    if ((((int)new_level) >= DBG_UTILS_JSON_PRINTER_LEVEL_MAX) || (((int)new_level) < DBG_UTILS_LEVEL_MIN_E)) {
        goto out;
    }

    json_printer_p->json_stack_rewind_cb(json_printer_p, new_level);

    /*add a new level*/
    json_printer_p->stack_json_top++;
    if (json_printer_p->stack_json_top >= DBG_UTILS_JSON_PRINTER_LEVEL_MAX) {
        SX_LOG_ERR("stacked_json_arr overflow\n");
        json_printer_p->valid = FALSE;
        return;
    }

    if (is_table) {
        if (json_printer_p->json_table_name[0] != '\0') {
            snprintf(table_name_str, sizeof(table_name_str), "%s", json_printer_p->json_table_name);
        } else {
            snprintf(table_name_str, sizeof(table_name_str), "%s", object_name);
        }
        json_printer_p->json_table_name[0] = '\0';
        dbg_utils_json_printer_print(json_printer_p, "\"%s\": [", table_name_str);
        json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].type = ']';
    } else {
        dbg_utils_json_printer_print(json_printer_p, "\"%s\": {", object_name);
        json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].type = '}';
    }

    json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].has_child = FALSE;
    json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].level = new_level;

out:
    return;
}

void dbg_utils_json_printer_string_object_create(json_printer_ptr  json_printer_p,
                                                 dbg_utils_level_e new_level,
                                                 char             *value)
{
    if (!json_printer_p->valid) {
        return;
    }

    json_printer_p->json_stack_rewind_cb(json_printer_p, new_level);
    dbg_utils_string_return_remove(value);
    dbg_utils_json_printer_print(json_printer_p, "\"%s\"", value);
}

static void __dbg_utils_json_printer_data_object_create(json_printer_ptr  json_printer_p,
                                                        dbg_utils_level_e new_level,
                                                        const char       *name,
                                                        char             *value)
{
    char buf[DBG_UTILS_JSON_BUF_SIZE];

    if (!json_printer_p->valid) {
        return;
    }

    json_printer_p->json_stack_rewind_cb(json_printer_p, new_level);

    snprintf(buf, sizeof(buf), "%s", name);
    dbg_utils_string_leading_sp_remove(buf);
    dbg_utils_string_return_remove(value);
    dbg_utils_json_printer_print(json_printer_p, "\"%s\": \"%s\"", buf, value);
}

void dbg_utils_json_printer_table_item_create(json_printer_ptr json_printer_p, dbg_utils_level_e new_level)
{
    if (!json_printer_p->valid) {
        return;
    }

    json_printer_p->json_stack_rewind_cb(json_printer_p, new_level);

    json_printer_p->stack_json_top++;
    if (json_printer_p->stack_json_top >= DBG_UTILS_JSON_PRINTER_LEVEL_MAX) {
        SX_LOG_ERR("stacked_json_arr overflow\n");
        json_printer_p->valid = FALSE;
        return;
    }
    json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].type = '}';
    json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].has_child = FALSE;
    json_printer_p->stacked_json_arr[json_printer_p->stack_json_top].level = new_level;
    dbg_utils_json_printer_print(json_printer_p, "{");
}

void __field_to_buf_convert(char *buf, size_t buf_size, const void            *data, dbg_utils_param_type_e type)
{
    uint8_t *mac_p;
    uint32_t ipv6_idx;

    switch (type) {
    case PARAM_UINT8_E:
        snprintf(buf, buf_size, "%hu", *((uint8_t*)data));
        break;

    case PARAM_UINT16_E:
        snprintf(buf, buf_size, "%u", *((uint16_t*)data));
        break;

    case PARAM_UINT32_E:
        snprintf(buf, buf_size, "%u", *((uint32_t*)data));
        break;

    case PARAM_UINT64_E:
        snprintf(buf, buf_size, "%" PRIu64 "", *((uint64_t*)data));
        break;

    case PARAM_HEX_E:
        snprintf(buf, buf_size, "0x%X", *((uint32_t*)data));
        break;

    case PARAM_HEX16_E:
        snprintf(buf, buf_size, "0x%X", *((uint16_t*)data));
        break;

    case PARAM_HEX64_E:
        snprintf(buf, buf_size, "0x%" PRIx64 "", *((uint64_t*)data));
        break;

    case PARAM_PORT_ID_E:
        snprintf(buf, buf_size, "0x%x", *((uint32_t*)data));
        break;

    case PARAM_STRING_E:
        snprintf(buf, buf_size, "%s", (const char*)data);
        break;

    case PARAM_EXT_STRING_E:
        snprintf(buf, buf_size, "%s", (const char*)data);
        break;

    case PARAM_BOOL_E:
        snprintf(buf, buf_size, "%s", *((boolean_t*)data) ? "TRUE" : "FALSE");
        break;

    case PARAM_MAC_ADDR_E:
        mac_p = ((uint8_t*)(data));
        snprintf(buf,
                 buf_size,
                 "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X",
                 mac_p[0],
                 mac_p[1],
                 mac_p[2],
                 mac_p[3],
                 mac_p[4],
                 mac_p[5]);
        break;

    case PARAM_IPV4_E:
    case PARAM_IPV4_MASK_E:
    {
        struct in_addr ip;
        char           addr[INET_ADDRSTRLEN];
        ip.s_addr = htonl(*((uint32_t*)data));
        if (!inet_ntop(AF_INET, &ip, addr, INET_ADDRSTRLEN)) {
            strcpy(addr, "???");
        }
        snprintf(buf, buf_size, "%s", addr);
        break;
    }

    case PARAM_IPV6_E:
    {
        struct in6_addr ipv6;
        char            addr[INET6_ADDRSTRLEN];
        for (ipv6_idx = 0; ipv6_idx < 4; ipv6_idx++) {
            ipv6.s6_addr32[ipv6_idx] = htonl(((struct in6_addr*)data)->s6_addr32[ipv6_idx]);
        }
        if (!inet_ntop(AF_INET6, &ipv6, addr, INET6_ADDRSTRLEN)) {
            strcpy(addr, "???");
        }
        snprintf(buf, buf_size, "%s", addr);
        break;
    }

    case PARAM_FC_ADDR_E:
    {
        uint8_t *map_p;
        map_p = ((uint8_t*)(data));
        snprintf(buf, buf_size, "%.2X:%.2X:%.2X", map_p[0], map_p[1], map_p[2]);
        break;
    }

    case PARAM_DOUBLE_E:
        snprintf(buf, buf_size, "%.2f", *((double*)data));
        break;

    case PARAM_INT_E:
        snprintf(buf, buf_size, "%d", *((int*)data));
        break;

    default:
        SX_LOG_ERR("Internal error: wrong use of dbg_utils_param_type %u\n", type);
        break;
    }
}

void dbg_utils_json_printer_field_simple_print(json_printer_ptr       json_printer_p,
                                               const char            *name,
                                               const void            *data,
                                               dbg_utils_param_type_e type)
{
    dbg_utils_json_printer_field_with_level_print(json_printer_p,
                                                  name,
                                                  data,
                                                  type,
                                                  DBG_UTILS_LEVEL_DATA_E);
}

void dbg_utils_json_printer_field_with_level_print(json_printer_ptr       json_printer_p,
                                                   const char            *name,
                                                   const void            *data,
                                                   dbg_utils_param_type_e type,
                                                   dbg_utils_level_e      new_level)
{
    char buf[DBG_UTILS_JSON_BUF_SIZE];

    __field_to_buf_convert(buf, sizeof(buf), data, type);
    __dbg_utils_json_printer_data_object_create(json_printer_p, new_level, name, buf);
}

void dbg_utils_json_printer_module_header_print(json_printer_ptr json_printer_p, const char *module_name)
{
    dbg_utils_json_printer_header_object_create(json_printer_p, DBG_UTILS_LEVEL_MODULE_E, module_name, FALSE);
}

void dbg_utils_json_printer_table_headline_with_name_print(json_printer_ptr           json_printer_p,
                                                           dbg_utils_table_columns_t *columns,
                                                           char                     * name)
{
    UNUSED_PARAM(columns);
    dbg_utils_json_printer_header_object_create(json_printer_p, DBG_UTILS_LEVEL_HEADER_E, name, TRUE);
}

void dbg_utils_json_printer_table_name_set(json_printer_ptr json_printer_p, char *table_name)
{
    if (!json_printer_p->valid) {
        return;
    }

    strncpy(json_printer_p->json_table_name, table_name, DBG_UTILS_JSON_BUF_SIZE - 1);
}

int dbg_utils_json_printer_table_data_line_nosep_print(json_printer_ptr           json_printer_p,
                                                       dbg_utils_table_columns_t *columns)
{
    int                          i = 0;
    int                          ipv6_idx;
    uint8_t                     *mac_ptr;
    uint8_t                     *fc_ptr;
    dbg_utils_table_tlv_field_t *tlv_field_p;
    char                         json_buf[DBG_UTILS_JSON_BUF_SIZE];

    if (!json_printer_p->valid) {
        return 0;
    }

    dbg_utils_json_printer_table_item_create(json_printer_p, DBG_UTILS_LEVEL_SUB_HEADER_E);

    while (columns[i].name) {
        switch (columns[i].type) {
        case PARAM_EXT_STRING_E:
            snprintf(json_buf, sizeof(json_buf), "%s", (const char*)(columns[i].data));
            break;

        case PARAM_STRING_E:
            snprintf(json_buf, sizeof(json_buf), "%s", (const char*)(columns[i].data));
            break;

        case PARAM_MAC_ADDR_E:
            mac_ptr = ((uint8_t*)(columns[i].data));
            snprintf(json_buf, sizeof(json_buf), "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X",
                     mac_ptr[0], mac_ptr[1], mac_ptr[2], mac_ptr[3], mac_ptr[4], mac_ptr[5]);
            break;

        case PARAM_FC_ADDR_E:
            fc_ptr = ((uint8_t*)(columns[i].data));
            snprintf(json_buf, sizeof(json_buf), "%.2X:%.2X:%.2X", fc_ptr[0], fc_ptr[1], fc_ptr[2]);
            break;

        case PARAM_IPV4_E:
        case PARAM_IPV4_MASK_E:
        {
            struct in_addr ip;
            char           addr[20];
            ip.s_addr = htonl(*((uint32_t*)(columns[i].data)));
            if (!inet_ntop(AF_INET, &ip, addr, 20)) {
                strcpy(addr, "???");
            }
            snprintf(json_buf, sizeof(json_buf), "%s", addr);
            break;
        }

        case PARAM_IPV6_E:
        {
            struct in6_addr ipv6;
            char            addr[44];
            for (ipv6_idx = 0; ipv6_idx < 4; ipv6_idx++) {
                ipv6.s6_addr32[ipv6_idx] =
                    htonl(((struct in6_addr*)columns[i].data)->s6_addr32[ipv6_idx]);
            }
            if (!inet_ntop(AF_INET6, &ipv6, addr, 44)) {
                strcpy(addr, "???");
            }
            snprintf(json_buf, sizeof(json_buf), "%s", addr);
            break;
        }

        case PARAM_HEX64_E:
        /* fall through */
        case PARAM_UINT64_E:
            if (columns[i].type == PARAM_HEX64_E) {
                snprintf(json_buf, sizeof(json_buf), "0x%" PRIx64 "", *((uint64_t*)(columns[i].data)));
            } else {
                snprintf(json_buf, sizeof(json_buf), "%" PRIu64 "", *((uint64_t*)(columns[i].data)));
            }
            break;

        case PARAM_BOOL_E:
            snprintf(json_buf, sizeof(json_buf), "%s", *((boolean_t*)(columns[i].data)) ? "TRUE" : "FALSE");
            break;

        case PARAM_UINT8_E:
            snprintf(json_buf, sizeof(json_buf), "%hu", *((uint8_t*)(columns[i].data)));
            break;

        case PARAM_HEX16_E:
        /* fall through */
        case PARAM_UINT16_E:
            if (columns[i].type == PARAM_HEX16_E) {
                snprintf(json_buf, sizeof(json_buf), "0x%X", *((uint16_t*)(columns[i].data)));
            } else {
                snprintf(json_buf, sizeof(json_buf), "%u", *((uint16_t*)(columns[i].data)));
            }
            break;

        case PARAM_DOUBLE_E:
            snprintf(json_buf, sizeof(json_buf), "%.2f", *((double*)(columns[i].data)));
            break;

        case PARAM_INT_E:
            snprintf(json_buf, sizeof(json_buf), "%d", *((int*)(columns[i].data)));
            break;

        case PARAM_HEX_STRING_E:
            tlv_field_p = (dbg_utils_table_tlv_field_t*)columns[i].data;
            dbg_utils_string_hex_get(json_buf,
                                     DBG_UTILS_JSON_PRINTER_DATA_STR_PRECISION,
                                     tlv_field_p->data,
                                     tlv_field_p->data_len);
            break;

        case PARAM_PORT_ID_E:
            snprintf(json_buf, sizeof(json_buf), "0x%x", *((uint32_t*)(columns[i].data)));
            break;

        case PARAM_HEX_E:
        /* fall through */
        case PARAM_UINT32_E:
        default:
            if (columns[i].type == PARAM_HEX_E) {
                snprintf(json_buf, sizeof(json_buf), "0x%X", *((uint32_t*)(columns[i].data)));
            } else {
                snprintf(json_buf, sizeof(json_buf), "%u", *((uint32_t*)(columns[i].data)));
            }
            break;
        } /*switch*/

        __dbg_utils_json_printer_data_object_create(json_printer_p, DBG_UTILS_LEVEL_DATA_E, columns[i].name, json_buf);
        i++;
    } /*while*/

    return 0;
}

void dbg_utils_json_printer_counters_group_header_print(json_printer_ptr json_printer_p,
                                                        const char      *cntr_grp_name,
                                                        uint32_t         port_id)
{
    char cntr_grp_name_buf[DBG_UTILS_JSON_BUF_SIZE];

    snprintf(cntr_grp_name_buf, sizeof(cntr_grp_name_buf), "Port 0x%x - %.30s Counters Group", port_id, cntr_grp_name);
    dbg_utils_json_printer_header_object_create(json_printer_p, DBG_UTILS_LEVEL_HEADER_E, cntr_grp_name_buf, FALSE);
}

void dbg_utils_json_printer_counters_group_sub_header_print(json_printer_ptr json_printer_p, const char *buf)
{
    dbg_utils_json_printer_header_object_create(json_printer_p, DBG_UTILS_LEVEL_SUB_HEADER_E, buf, FALSE);
}

void dbg_utils_json_printer_counter_print(json_printer_ptr json_printer_p, const char *cntr_name, uint64_t cntr_value)
{
    char buf[DBG_UTILS_JSON_BUF_SIZE];

    __field_to_buf_convert(buf, sizeof(buf), &cntr_value, PARAM_UINT64_E);
    __dbg_utils_json_printer_data_object_create(json_printer_p, DBG_UTILS_LEVEL_DATA_E, cntr_name, buf);
}

void dbg_utils_json_printer_counter_with_level_print(json_printer_ptr  json_printer_p,
                                                     const char       *cntr_name,
                                                     uint64_t          cntr_value,
                                                     dbg_utils_level_e new_level)
{
    char buf[DBG_UTILS_JSON_BUF_SIZE];

    __field_to_buf_convert(buf, sizeof(buf), &cntr_value, PARAM_UINT64_E);
    __dbg_utils_json_printer_data_object_create(json_printer_p, new_level, cntr_name, buf);
}

void dbg_utils_json_printer_general_header_print(json_printer_ptr json_printer_p, const char *general_header)
{
    dbg_utils_json_printer_header_object_create(json_printer_p, DBG_UTILS_LEVEL_GENERAL_E, general_header, FALSE);
}

void dbg_utils_json_printer_sub_module_header_print(json_printer_ptr json_printer_p, const char *sub_module_header)
{
    dbg_utils_json_printer_header_object_create(json_printer_p, DBG_UTILS_LEVEL_SUB_MODULE_E, sub_module_header,
                                                FALSE);
}

void dbg_utils_json_printer_user_defined_header_print(json_printer_ptr  json_printer_p,
                                                      dbg_utils_level_e user_defined_level,
                                                      const char       *buf)
{
    if ((user_defined_level < DBG_UTILS_LEVEL_USER_DEFINED_MIN_E) ||
        (user_defined_level > DBG_UTILS_LEVEL_USER_DEFINED_MAX_E)) {
        SX_LOG_ERR("Invalid user_defined_level:%u\n", user_defined_level);
        return;
    }
    dbg_utils_json_printer_header_object_create(json_printer_p, user_defined_level, buf, FALSE);
}

void dbg_utils_json_printer_secondary_header_print(json_printer_ptr json_printer_p, const char       *buf)
{
    dbg_utils_json_printer_header_object_create(json_printer_p, DBG_UTILS_LEVEL_SECONDARY_E, buf, FALSE);
}

void dbg_utils_json_printer_time_stamp_print(json_printer_ptr json_printer_p, const char * name, char *stime)
{
    __dbg_utils_json_printer_data_object_create(json_printer_p, DBG_UTILS_LEVEL_MODULE_E, name, stime);
}

static void __dbg_utils_json_printer_binary_tree_node_draw(draw_json_tree_node_context_t* context, uint32_t cur_node)
{
    char buf[64] = {0};
    int  json_level_save = context->json_printer_p->stacked_json_arr[context->json_printer_p->stack_json_top].level;

    if (cur_node > context->tree->node_count) {
        SX_LOG_ERR("Cannot dump tree node %u which is out of bound %u\n", cur_node, context->tree->node_count);
        return;
    }

    snprintf(buf, sizeof(buf) - 1, "%u", cur_node);
    __dbg_utils_json_printer_data_object_create(context->json_printer_p, json_level_save + 1, "value", buf);

    if (context->tree->nodes[cur_node].left_child != 0) {
        context->verticals[context->right_depth] = TRUE;
    } else {
        context->verticals[context->right_depth] = FALSE;
    }

    if (context->tree->nodes[cur_node].right_child != 0) {
        context->right_depth++;

        dbg_utils_json_printer_header_object_create(context->json_printer_p, json_level_save + 1, "right", FALSE);

        __dbg_utils_json_printer_binary_tree_node_draw(context, context->tree->nodes[cur_node].right_child);

        context->right_depth--;
    }

    if (context->tree->nodes[cur_node].left_child != 0) {
        /* prepare json object for left tree node*/
        dbg_utils_json_printer_header_object_create(context->json_printer_p, json_level_save + 1, "left", FALSE);

        __dbg_utils_json_printer_binary_tree_node_draw(context, context->tree->nodes[cur_node].left_child);
    }

    context->verticals[context->right_depth] = FALSE;
}

void dbg_utils_json_printer_binary_tree_draw(json_printer_ptr json_printer_p, const dbg_utils_tree_t* tree)
{
    boolean_t                     verticals[DBG_UTILS_NODES_MAX];
    draw_json_tree_node_context_t context;

    memset(verticals, 0, sizeof(verticals));
    context.json_printer_p = json_printer_p;
    context.tree = tree;
    context.right_depth = 0;
    context.verticals = verticals;

    dbg_utils_json_printer_header_object_create(json_printer_p, DBG_UTILS_LEVEL_HEADER_E, "root", FALSE);

    __dbg_utils_json_printer_binary_tree_node_draw(&context, tree->root);
}
