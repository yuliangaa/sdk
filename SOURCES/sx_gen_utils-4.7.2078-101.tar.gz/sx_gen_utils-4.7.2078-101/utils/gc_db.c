/*
 * Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "gc_db.h"
#include "gen_utils.h"
#include "sx/utils/gc.h"
#include "sx/utils/sx_utils_types.h"
#include "sx/utils/dbg_utils.h"
#include "sx/utils/dbg_utils_pretty_printer.h"
#include "complib/cl_qlist.h"
#include "complib/cl_qpool.h"
#include <complib/cl_dbg.h>

#undef  __MODULE__
#define __MODULE__ GC

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

typedef struct gc_object_type_data {
    boolean_t                     is_initialized;
    gc_object_type_t              object_type;
    gc_object_type_attributes_t   object_attr;
    gc_object_completion_pfn      completion_cb;
    gc_object_post_completion_pfn post_completion_cb;
    cl_qlist_t                    per_object_queue;
    sdk_timer_handle_t            timer_handle;
    boolean_t                     timer_started;
    uint32_t                      total_size;
    uint32_t                      wm_high; /* High WM for per object type DB */
} gc_object_type_data_t;

typedef struct gc_db {
    cl_qpool_t            object_pool;
    cl_qlist_t            gc_queue;
    gc_object_type_data_t object_types[GC_OBJECT_TYPE_NUMBER];
    uint32_t              wm_high; /* High WM for global DB */
} gc_db_t;

typedef struct gc_object_entry {
    cl_pool_item_t   pool_item;
    cl_list_item_t   global_gc_list_item;
    cl_list_item_t   per_object_gc_list_item;
    gc_object_data_t data;
} gc_object_entry_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static gc_db_t   g_gc_db;
static boolean_t g_db_initialized = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
sx_utils_status_t gc_db_init(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;

    SX_LOG_ENTER();

    if (g_db_initialized) {
        err = SX_UTILS_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("GC DB is already initialized\n");
        goto out;
    }

    M_GEN_UTILS_MEM_CLR(g_gc_db);

    cl_err = CL_QPOOL_INIT(&g_gc_db.object_pool, 0, CL_POOL_UNLIMITED_MAX_SIZE, 0,
                           sizeof(gc_object_entry_t), NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Failed to initialize GC qpool, cl_err = [%s]\n",
                   CL_STATUS_MSG(cl_err));
        goto out;
    }

    cl_qlist_init(&g_gc_db.gc_queue);

    g_db_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_deinit(void)
{
    sx_utils_status_t     err = SX_UTILS_STATUS_SUCCESS;
    uint32_t              obj_idx = 0;
    const cl_list_item_t *p_end = NULL;
    cl_list_item_t       *p_head = NULL;
    gc_object_entry_t    *p_object = NULL;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    for (obj_idx = 0; obj_idx < GC_OBJECT_TYPE_NUMBER; obj_idx++) {
        if (g_gc_db.object_types[obj_idx].is_initialized) {
            cl_qlist_remove_all(&g_gc_db.object_types[obj_idx].per_object_queue);
            M_GEN_UTILS_MEM_CLR(g_gc_db.object_types[obj_idx]);
        }
    }

    p_end = cl_qlist_end(&g_gc_db.gc_queue);
    p_head = cl_qlist_remove_head(&g_gc_db.gc_queue);

    while (p_head != p_end) {
        p_object = PARENT_STRUCT(p_head, gc_object_entry_t, global_gc_list_item);
        cl_qpool_put(&g_gc_db.object_pool, &p_object->pool_item);

        p_head = cl_qlist_remove_head(&g_gc_db.gc_queue);
    }

    CL_QPOOL_DESTROY(&g_gc_db.object_pool);
    g_db_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_init(gc_object_type_t                   object_type,
                                    const gc_object_type_attributes_t *object_attr,
                                    gc_object_completion_pfn           completion_cb,
                                    gc_object_post_completion_pfn      post_completion_cb,
                                    gc_object_type_t                 **object_context)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (object_attr == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("object_attr is NULL\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    /* TODO: Make initialization per-subtype. For now just accept multiple
     * initialization from the same client.
     */
    if (g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_ALREADY_INITIALIZED;
        SX_LOG_DBG("Object DB for object type %s is already initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    g_gc_db.object_types[object_type].object_type = object_type;
    g_gc_db.object_types[object_type].object_attr = *object_attr;
    g_gc_db.object_types[object_type].completion_cb = completion_cb;
    g_gc_db.object_types[object_type].post_completion_cb = post_completion_cb;
    cl_qlist_init(&g_gc_db.object_types[object_type].per_object_queue);
    g_gc_db.object_types[object_type].is_initialized = TRUE;

    if (object_context) {
        *object_context = &g_gc_db.object_types[object_type].object_type;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_deinit(gc_object_type_t object_type)
{
    sx_utils_status_t     err = SX_UTILS_STATUS_SUCCESS;
    const cl_list_item_t *p_end = NULL;
    cl_list_item_t       *p_head = NULL;
    gc_object_entry_t    *p_object = NULL;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    p_end = cl_qlist_end(&g_gc_db.object_types[object_type].per_object_queue);
    p_head = cl_qlist_remove_head(&g_gc_db.object_types[object_type].per_object_queue);

    while (p_head != p_end) {
        p_object = PARENT_STRUCT(p_head, gc_object_entry_t, per_object_gc_list_item);
        cl_qlist_remove_item(&g_gc_db.gc_queue, &p_object->global_gc_list_item);
        cl_qpool_put(&g_gc_db.object_pool, &p_object->pool_item);

        p_head = cl_qlist_remove_head(&g_gc_db.object_types[object_type].per_object_queue);
    }

    M_GEN_UTILS_MEM_CLR(g_gc_db.object_types[object_type]);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_type_attributes_get(gc_object_type_t             object_type,
                                                   gc_object_type_attributes_t *object_attr)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (object_attr == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("object_attr is NULL\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    *object_attr = g_gc_db.object_types[object_type].object_attr;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_completion_cb_get(gc_object_type_t               object_type,
                                                 gc_object_completion_pfn      *completion_cb,
                                                 gc_object_post_completion_pfn *post_completion_cb)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (completion_cb == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("completion_cb is NULL\n");
        goto out;
    }

    if (post_completion_cb == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("post_completion_cb is NULL\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    *completion_cb = g_gc_db.object_types[object_type].completion_cb;
    *post_completion_cb = g_gc_db.object_types[object_type].post_completion_cb;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_timer_handle_set(gc_object_type_t object_type, sdk_timer_handle_t timer_handle)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    g_gc_db.object_types[object_type].timer_handle = timer_handle;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_timer_handle_get(gc_object_type_t object_type, sdk_timer_handle_t *timer_handle)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (timer_handle == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("timer_handle is NULL\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    *timer_handle = g_gc_db.object_types[object_type].timer_handle;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_queue_push(gc_object_type_t    object_type,
                                   gc_state_t          state,
                                   uint32_t            seq_num,
                                   uint32_t            alt_seq_num,
                                   const void         *gc_context,
                                   uint32_t            size,
                                   gc_object_subtype_t subtype,
                                   uint32_t            start_index,
                                   gc_handle_t        *gc_handle)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t        cl_err = CL_SUCCESS;
    cl_pool_item_t    *p_pool_item = NULL;
    gc_object_entry_t *p_object = NULL;
    uint32_t           grow_size = 0;
    uint32_t           count = 0;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    p_pool_item = cl_qpool_get(&g_gc_db.object_pool);
    if (!p_pool_item) {
        grow_size = g_gc_db.object_types[object_type].object_attr.per_object_threshold == 0 ?
                    GC_DEFAULT_GROW_SIZE :
                    g_gc_db.object_types[object_type].object_attr.per_object_threshold;

        cl_err = cl_qpool_grow(&g_gc_db.object_pool, grow_size);
        if (cl_err != CL_SUCCESS) {
            err = SX_UTILS_STATUS_ERROR;
            SX_LOG_ERR("Failed to grow GC object pool by %u entries, cl_err = [%s]\n",
                       grow_size, CL_STATUS_MSG(cl_err));
            goto out;
        }

        p_pool_item = cl_qpool_get(&g_gc_db.object_pool);
        if (!p_pool_item) {
            err = SX_UTILS_STATUS_NO_MEMORY;
            SX_LOG_ERR("No memory left in GC qpool\n");
            goto out;
        }
    }

    p_object = PARENT_STRUCT(p_pool_item, gc_object_entry_t, pool_item);
    p_object->data.object_type = object_type;
    p_object->data.seq_num = seq_num;
    p_object->data.alt_seq_num = alt_seq_num;
    p_object->data.state = state;
    p_object->data.gc_context = gc_context;
    p_object->data.size = size;
    p_object->data.start_index = start_index;
    p_object->data.subtype = subtype;
    cl_qlist_insert_tail(&g_gc_db.gc_queue, &p_object->global_gc_list_item);
    count = cl_qlist_count(&g_gc_db.gc_queue);
    g_gc_db.wm_high = (count > g_gc_db.wm_high) ? count : g_gc_db.wm_high;
    cl_qlist_insert_tail(&g_gc_db.object_types[object_type].per_object_queue,
                         &p_object->per_object_gc_list_item);
    count = cl_qlist_count(&g_gc_db.object_types[object_type].per_object_queue);
    g_gc_db.object_types[object_type].total_size += size;
    g_gc_db.object_types[object_type].wm_high =
        (count > g_gc_db.object_types[object_type].wm_high) ? count : g_gc_db.object_types[object_type].wm_high;
    if (gc_handle) {
        *gc_handle = (gc_handle_t)p_object;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_global_queue_top(gc_object_data_t *object_data)
{
    sx_utils_status_t     err = SX_UTILS_STATUS_SUCCESS;
    const cl_list_item_t *p_end = NULL;
    cl_list_item_t       *p_head = NULL;
    gc_object_entry_t    *p_object = NULL;


    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (object_data == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("object_data is NULL\n");
        goto out;
    }

    p_end = cl_qlist_end(&g_gc_db.gc_queue);
    p_head = cl_qlist_head(&g_gc_db.gc_queue);
    if (p_head == p_end) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_INF("GC global queue is empty\n");
        goto out;
    }

    p_object = PARENT_STRUCT(p_head, gc_object_entry_t, global_gc_list_item);
    *object_data = p_object->data;

out:
    return err;
}

sx_utils_status_t gc_db_object_type_queue_top(gc_object_type_t object_type, gc_object_data_t *object_data)
{
    sx_utils_status_t     err = SX_UTILS_STATUS_SUCCESS;
    const cl_list_item_t *p_end = NULL;
    cl_list_item_t       *p_head = NULL;
    gc_object_entry_t    *p_object = NULL;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (object_data == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("object_data is NULL\n");
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    p_end = cl_qlist_end(&g_gc_db.object_types[object_type].per_object_queue);
    p_head = cl_qlist_head(&g_gc_db.object_types[object_type].per_object_queue);
    if (p_head == p_end) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_INF("GC object [%s] queue is empty\n", GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    p_object = PARENT_STRUCT(p_head, gc_object_entry_t, per_object_gc_list_item);
    *object_data = p_object->data;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_global_queue_pop(gc_object_data_t *object_data)
{
    sx_utils_status_t     err = SX_UTILS_STATUS_SUCCESS;
    const cl_list_item_t *p_end = NULL;
    cl_list_item_t       *p_head = NULL;
    gc_object_entry_t    *p_object = NULL;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    p_end = cl_qlist_end(&g_gc_db.gc_queue);
    p_head = cl_qlist_remove_head(&g_gc_db.gc_queue);
    if (p_head == p_end) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_INF("GC global queue is empty\n");
        goto out;
    }

    p_object = PARENT_STRUCT(p_head, gc_object_entry_t, global_gc_list_item);

    if (!GC_OBJECT_TYPE_CHECK_RANGE(p_object->data.object_type)) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("GC Object type is out of range, err %s.\n", SX_UTILS_STATUS_MSG(err));
        goto out;
    }
    cl_qlist_remove_item(&g_gc_db.object_types[p_object->data.object_type].per_object_queue,
                         &p_object->per_object_gc_list_item);

    if (object_data) {
        *object_data = p_object->data;
    }

    g_gc_db.object_types[p_object->data.object_type].total_size -= p_object->data.size;
    cl_qpool_put(&g_gc_db.object_pool, &p_object->pool_item);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_type_queue_pop(gc_object_type_t object_type, gc_object_data_t *object_data)
{
    sx_utils_status_t     err = SX_UTILS_STATUS_SUCCESS;
    const cl_list_item_t *p_end = NULL;
    cl_list_item_t       *p_head = NULL;
    gc_object_entry_t    *p_object = NULL;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    p_end = cl_qlist_end(&g_gc_db.object_types[object_type].per_object_queue);
    p_head = cl_qlist_remove_head(&g_gc_db.object_types[object_type].per_object_queue);
    if (p_head == p_end) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_INF("GC object [%s] queue is empty\n", GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    p_object = PARENT_STRUCT(p_head, gc_object_entry_t, per_object_gc_list_item);
    cl_qlist_remove_item(&g_gc_db.gc_queue, &p_object->global_gc_list_item);
    if (object_data) {
        *object_data = p_object->data;
    }

    g_gc_db.object_types[p_object->data.object_type].total_size -= p_object->data.size;
    cl_qpool_put(&g_gc_db.object_pool, &p_object->pool_item);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_dump_queues(FILE* stream,  gc_object_type_t resource, boolean_t print_empty)
{
    sx_utils_status_t         err = SX_UTILS_STATUS_SUCCESS;
    gc_object_data_t          object_data;
    const char               *object_type_str = NULL;
    const char               *state_str = NULL;
    const cl_list_item_t     *p_end = NULL;
    cl_list_item_t           *p_item = NULL;
    gc_object_entry_t        *p_object = NULL;
    dbg_utils_table_columns_t queue_columns[] = {
        { "Object type",   15,  PARAM_STRING_E, NULL},
        { "Seq num",   10,  PARAM_UINT32_E, &object_data.seq_num},
        { "Alt Seq num",   10,  PARAM_UINT32_E, &object_data.alt_seq_num},
        { "State",   15,  PARAM_STRING_E, NULL},
        { "Size",   10,  PARAM_UINT32_E, &object_data.size},
        {NULL, 0, 0, NULL}
    };
    uint32_t                  count = 0;
    gc_object_type_t          loop_start, loop_end;

    M_GEN_UTILS_MEM_CLR(object_data);

    if (stream == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("stream is NULL\n");
        goto out;
    }

    if ((resource != GC_OBECT_TYPE_INVALID) &&
        (!SX_CHECK_RANGE(GC_OBJECT_TYPE_MIN, resource, GC_OBJECT_TYPE_MAX))) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unknown resource is received - %d \n", resource);
        goto out;
    }

    if (resource == GC_OBECT_TYPE_INVALID) {
        p_end = cl_qlist_end(&g_gc_db.gc_queue);
        p_item = cl_qlist_head(&g_gc_db.gc_queue);
        dbg_utils_pprinter_table_headline_print(stream, queue_columns);
        while (p_item != p_end) {
            p_object = PARENT_STRUCT(p_item, gc_object_entry_t, global_gc_list_item);
            object_data = p_object->data;
            object_type_str = GC_OBJECT_TYPE_STR(object_data.object_type);
            state_str = GC_STATE_STR(object_data.state);
            queue_columns[0].data = object_type_str;
            queue_columns[3].data = state_str;
            dbg_utils_pprinter_table_data_line_print(stream, queue_columns);

            p_item = cl_qlist_next(p_item);
        }
        loop_start = GC_OBJECT_TYPE_MIN;
        loop_end = GC_OBJECT_TYPE_MAX;
    } else {
        loop_start = resource;
        loop_end = resource + 1;
    }

    for (resource = loop_start; resource < loop_end; resource++) {
        if (g_gc_db.object_types[resource].is_initialized) {
            count = cl_qlist_count(&g_gc_db.object_types[resource].per_object_queue);
            if ((count == 0) && !print_empty) {
                continue;
            }
            if (resource >= GC_OBJECT_TYPE_UENGINE_UTCAM_RANGE_START) {
                /*make the object type GC_OBJECT_TYPE_UENGINE_UTCAM unique*/
                dbg_utils_pprinter_secondary_header_print(stream,
                                                          "Object Type %s%d queue",
                                                          GC_OBJECT_TYPE_STR(resource),
                                                          resource - GC_OBJECT_TYPE_UENGINE_UTCAM_RANGE_START);
            } else {
                dbg_utils_pprinter_secondary_header_print(stream, "Object Type %s queue",
                                                          GC_OBJECT_TYPE_STR(resource));
            }
            dbg_utils_pprinter_field_print(stream, "Object count", &count, PARAM_UINT32_E);
            /* coverity[overrun-local] */
            dbg_utils_pprinter_field_print(stream, "High WM", &g_gc_db.object_types[resource].wm_high, PARAM_UINT32_E);

            p_end = cl_qlist_end(&g_gc_db.object_types[resource].per_object_queue);
            p_item = cl_qlist_head(&g_gc_db.object_types[resource].per_object_queue);
            dbg_utils_pprinter_table_headline_print(stream, queue_columns);
            while (p_item != p_end) {
                p_object = PARENT_STRUCT(p_item, gc_object_entry_t, per_object_gc_list_item);
                object_data = p_object->data;
                object_type_str = GC_OBJECT_TYPE_STR(object_data.object_type);
                state_str = GC_STATE_STR(object_data.state);
                queue_columns[0].data = object_type_str;
                queue_columns[2].data = state_str;
                dbg_utils_pprinter_table_data_line_print(stream, queue_columns);

                p_item = cl_qlist_next(p_item);
            }
        }
    }
out:

    return err;
}


sx_utils_status_t gc_db_dump(FILE* stream)
{
    sx_utils_status_t           err = SX_UTILS_STATUS_SUCCESS;
    gc_object_type_attributes_t object_attr;
    dbg_utils_table_columns_t   object_columns[] = {
        { "Per obj thresh",   14,  PARAM_UINT32_E, &object_attr.per_object_threshold},
        { "Free obj thresh",   15,  PARAM_UINT32_E, &object_attr.free_objects_threshold},
        { "Fence type",   10,  PARAM_STRING_E, NULL},
        { "HW op needed",   12,  PARAM_BOOL_E, &object_attr.hw_operation_needed},
        {NULL, 0, 0, NULL}
    };
    gc_object_type_t            resource = 0;
    const char                 *fence_type_str = NULL;
    uint32_t                    count = 0;

    SX_LOG_ENTER();

    M_GEN_UTILS_MEM_CLR(object_attr);

    if (stream == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("stream is NULL\n");
        goto out;
    }

    dbg_utils_pprinter_field_print(stream, "DB initialized", &g_db_initialized, PARAM_BOOL_E);

    if (!g_db_initialized) {
        goto out;
    }

    dbg_utils_pprinter_secondary_header_print(stream, "Object types database");
    for (resource = GC_OBJECT_TYPE_MIN; resource < GC_OBJECT_TYPE_MAX; resource++) {
        if (g_gc_db.object_types[resource].is_initialized) {
            if (resource >= GC_OBJECT_TYPE_UENGINE_UTCAM_RANGE_START) {
                /*make the object type GC_OBJECT_TYPE_UENGINE_UTCAM unique*/
                dbg_utils_pprinter_secondary_header_print(stream,
                                                          "Object Type %s%d",
                                                          GC_OBJECT_TYPE_STR(resource),
                                                          resource - GC_OBJECT_TYPE_UENGINE_UTCAM_RANGE_START);
            } else {
                dbg_utils_pprinter_secondary_header_print(stream, "Object Type %s", GC_OBJECT_TYPE_STR(resource));
            }
            object_attr = g_gc_db.object_types[resource].object_attr;
            dbg_utils_pprinter_table_headline_print(stream, object_columns);
            fence_type_str = GC_FENCE_TYPE_STR(object_attr.fence_type);
            object_columns[2].data = fence_type_str;
            dbg_utils_pprinter_table_data_line_print(stream, object_columns);
        }
    }

    dbg_utils_pprinter_secondary_header_print(stream, "Global fence queue");

    count = cl_qlist_count(&g_gc_db.gc_queue);
    dbg_utils_pprinter_field_print(stream, "Object count", &count, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Global High Watermark", &g_gc_db.wm_high, PARAM_UINT32_E);

    err = gc_db_dump_queues(stream,  GC_OBECT_TYPE_INVALID, TRUE);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

sx_utils_status_t gc_db_object_timer_started_set(gc_object_type_t object_type, boolean_t timer_started)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    g_gc_db.object_types[object_type].timer_started = timer_started;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_timer_started_get(gc_object_type_t object_type, boolean_t *timer_started)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (timer_started == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("timer_started is NULL\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    *timer_started = g_gc_db.object_types[object_type].timer_started;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_type_total_size_get(gc_object_type_t object_type, uint32_t *total_size)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (total_size == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("total_size is NULL\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!g_gc_db.object_types[object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    *total_size = g_gc_db.object_types[object_type].total_size;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_type_count_get(gc_object_type_t object_type, uint32_t *count)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (count == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("count is NULL\n");
        goto out;
    }

    if (object_type != GC_OBECT_TYPE_INVALID) {
        if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
            err = SX_UTILS_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid object type %u given\n", object_type);
            goto out;
        }
    }

    if (object_type == GC_OBECT_TYPE_INVALID) {
        *count = cl_qlist_count(&g_gc_db.gc_queue);
    } else {
        if (!g_gc_db.object_types[object_type].is_initialized) {
            err = SX_UTILS_STATUS_NOT_INITIALIZED;
            SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                       GC_OBJECT_TYPE_STR(object_type));
            goto out;
        }
        *count = cl_qlist_count(&g_gc_db.object_types[object_type].per_object_queue);
    }


out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_remove(gc_handle_t gc_handle)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    gc_object_entry_t *p_object = (gc_object_entry_t*)gc_handle;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (!p_object) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid handle given!\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(p_object->data.object_type)) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("GC Object type is out of range, err %s.\n", SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if (!g_gc_db.object_types[p_object->data.object_type].is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(p_object->data.object_type));
        goto out;
    }

    cl_qlist_remove_item(&g_gc_db.object_types[p_object->data.object_type].per_object_queue,
                         &p_object->per_object_gc_list_item);
    cl_qlist_remove_item(&g_gc_db.gc_queue, &p_object->global_gc_list_item);
    g_gc_db.object_types[p_object->data.object_type].total_size -= p_object->data.size;
    cl_qpool_put(&g_gc_db.object_pool, &p_object->pool_item);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_object_type_is_initialized(gc_object_type_t object_type, boolean_t *is_initialized)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_db_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC DB is not initialized\n");
        goto out;
    }

    if (is_initialized == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("is_initialized is NULL\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    *is_initialized = g_gc_db.object_types[object_type].is_initialized;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_db_context_get(gc_handle_t gc_handle, void** gc_context)
{
    gc_object_entry_t *gc_entry;
    sx_utils_status_t  status = SX_UTILS_STATUS_SUCCESS;


    SX_LOG_ENTER();

    if (gc_handle == NULL) {
        status = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("gc_handle is NULL\n");
        goto out;
    }
    gc_entry = (gc_object_entry_t*)gc_handle;
    *gc_context = ((void*)(gc_entry->data.gc_context));
    gc_entry->data.gc_context = NULL;
out:
    SX_LOG_EXIT();
    return status;
}
