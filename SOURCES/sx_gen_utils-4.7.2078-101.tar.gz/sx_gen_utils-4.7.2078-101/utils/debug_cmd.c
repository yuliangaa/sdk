/*
 * Copyright (C) 2001-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <linux/un.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <complib/cl_types.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_qlist.h>
#include <complib/cl_qpool.h>
#include <complib/cl_dbg.h>
#include <complib/sx_log.h>

#include <sx/utils/debug_cmd.h>

#undef  __MODULE__
#define __MODULE__ GEN_UTILS_DEBUG_CMD

#define DEBUG_CMD_IS_ARG_STR(str) ((str) && (str)[0] == '<' && (str)[strlen(str) - 1] == '>')

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t     g_initialized = FALSE;
static cl_spinlock_t g_debug_cmd_db_lock;
static cl_qpool_t    g_debug_cmd_db_pool;
static cl_qlist_t    g_debug_cmd_db;
static int           g_debug_cmd_fd = -1;
struct debug_cmd_entry {
    cl_pool_item_t          pool_item;
    cl_list_item_t          list_item;
    struct debug_cmd_entry *parent;
    cl_qlist_t              children;   /* children commands */
    char                    command[256];
    sx_utils_debug_cmd_cb_t handler_cb;
    void                   *handler_context;
    boolean_t               is_default;
    int                     depth;
};
struct debug_cmd_argc_argv {
    int argc;

#define DEBUG_CMD_ARGC_MAX (256)
    const char *argv[DEBUG_CMD_ARGC_MAX];
};
struct usage_param_ctx {
    FILE                         *stream;
    char                          buff[SX_UTILS_DBG_CMD_BUFFER_SIZE];
    const char                   *prefix;
    uint32_t                      bufflen;
    const struct debug_cmd_entry *root;
};

sx_utils_status_t sx_utils_debug_cmd_get_fd(int *fd)
{
    sx_utils_status_t st = SX_UTILS_STATUS_SUCCESS;

    if (!g_initialized) {
        st = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if (!fd) {
        st = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    *fd = g_debug_cmd_fd;

out:
    return st;
}

sx_utils_status_t sx_utils_debug_cmd_init(void)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t        cl_st = CL_SUCCESS;
    struct sockaddr_un sa;
    int                rc = 0;

    if (g_initialized) {
        SX_LOG_ERR("debug cmd is already initialized\n");
        err = SX_UTILS_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    cl_st = cl_spinlock_init(&g_debug_cmd_db_lock);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("debug cmd init - failed to initialize db lock\n");
        err = SX_UTILS_STATUS_ERROR;
        goto spinlock_init_failed;
    }

    cl_st = CL_QPOOL_INIT(&g_debug_cmd_db_pool, 256, CL_POOL_UNLIMITED_MAX_SIZE, 256, sizeof(struct debug_cmd_entry),
                          NULL, NULL, NULL);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("debug cmd init - failed to initialize qpool\n");
        err = SX_UTILS_STATUS_ERROR;
        goto qpool_init_failed;
    }

    cl_qlist_init(&g_debug_cmd_db);

    g_debug_cmd_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (g_debug_cmd_fd < 0) {
        SX_LOG_ERR("debug cmd init - failed to create domain socket\n");
        err = SX_UTILS_STATUS_ERROR;
        goto domain_socket_failed;
    }

    unlink(SX_UTILS_DBG_CMD_PATH);

    memset(&sa, 0, sizeof(sa));
    sa.sun_family = AF_UNIX;
    strcpy(sa.sun_path, SX_UTILS_DBG_CMD_PATH);
    rc = bind(g_debug_cmd_fd, (struct sockaddr*)&sa, sizeof(sa));
    if (rc) {
        SX_LOG_ERR("debug cmd init - failed to bind domain socket\n");
        err = SX_UTILS_STATUS_ERROR;
        goto domain_socket_bind_failed;
    }

    rc = listen(g_debug_cmd_fd, 5);
    if (rc) {
        SX_LOG_ERR("debug cmd init - failed to listen on domain socket\n");
        err = SX_UTILS_STATUS_ERROR;
        goto domain_socket_listen_failed;
    }

    g_initialized = TRUE;
    goto out;

domain_socket_listen_failed:
domain_socket_bind_failed:
    close(g_debug_cmd_fd);

domain_socket_failed:
    CL_QPOOL_DESTROY(&g_debug_cmd_db_pool);

qpool_init_failed:
    cl_spinlock_destroy(&g_debug_cmd_db_lock);

spinlock_init_failed:
out:
    return err;
}


static void __create_argv(char *buff, struct debug_cmd_argc_argv *argc_argv)
{
    char *tmp = NULL, *token = NULL;

    argc_argv->argc = 0;
    if (!buff) {
        return;
    }

    token = strtok_r(buff, " ", &tmp);

    while (token && argc_argv->argc < DEBUG_CMD_ARGC_MAX) {
        argc_argv->argv[argc_argv->argc++] = token;
        token = strtok_r(NULL, " ", &tmp);
    }
}


static void __create_command_argv(char                       *buff,
                                  struct debug_cmd_argc_argv *argc_argv,
                                  boolean_t                  *is_help,
                                  boolean_t                  *is_space)
{
    int   len = strlen(buff);
    char *last_char = buff + len - 1;

    *is_help = FALSE;

    while (last_char >= buff && *last_char == ' ') {
        *last_char = '\0';
        last_char--;
        len--;
    }

    if (len > 0) {
        last_char = &buff[len - 1];

        if (*last_char == '?') {
            *is_help = TRUE;
            *last_char = '\0';

            if (last_char > buff) {
                last_char--;
                *is_space = (*last_char == ' ');
            }
        }
    }

    __create_argv(buff, argc_argv);
}


static struct debug_cmd_entry * __find_direct_child(struct debug_cmd_entry *dc_parent, const char *command)
{
    cl_qlist_t             *list = (dc_parent == NULL) ? &g_debug_cmd_db : &dc_parent->children;
    struct debug_cmd_entry *dc_entry = NULL, *dc_found = NULL;
    cl_list_item_t         *iter = NULL;

    for (iter = cl_qlist_head(list); iter != cl_qlist_end(list); iter = cl_qlist_next(iter)) {
        dc_entry = PARENT_STRUCT(iter, struct debug_cmd_entry, list_item);

        if (dc_entry->is_default) {
            dc_found = dc_entry;
        } else if (strcmp(dc_entry->command, command) == 0) {
            dc_found = dc_entry;
            break;
        }
    }

    return dc_found;
}


static void __delete_entry(struct debug_cmd_entry *dc_entry)
{
    cl_qlist_t             *list = (dc_entry->parent) ? &dc_entry->parent->children : &g_debug_cmd_db;
    struct debug_cmd_entry *dc_child = NULL;
    cl_list_item_t         *list_entry = NULL;

    while ((list_entry = cl_qlist_head(&dc_entry->children)) != cl_qlist_end(&dc_entry->children)) {
        dc_child = PARENT_STRUCT(list_entry, struct debug_cmd_entry, list_item);
        __delete_entry(dc_child);
    }

    cl_qlist_remove_item(list, &dc_entry->list_item);
    cl_qpool_put(&g_debug_cmd_db_pool, &dc_entry->pool_item);
}


static void __delete_all(void)
{
    struct debug_cmd_entry *dc_child = NULL;
    cl_list_item_t         *list_entry = NULL;

    while ((list_entry = cl_qlist_head(&g_debug_cmd_db)) != cl_qlist_end(&g_debug_cmd_db)) {
        dc_child = PARENT_STRUCT(list_entry, struct debug_cmd_entry, list_item);
        __delete_entry(dc_child);
    }
}


sx_utils_status_t sx_utils_debug_cmd_deinit(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if (!g_initialized) {
        SX_LOG_ERR("debug cmd is not initialized\n");
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    cl_spinlock_acquire(&g_debug_cmd_db_lock);

    __delete_all();
    CL_QPOOL_DESTROY(&g_debug_cmd_db_pool);

    cl_spinlock_release(&g_debug_cmd_db_lock);

    cl_spinlock_destroy(&g_debug_cmd_db_lock);

    close(g_debug_cmd_fd);
    unlink(SX_UTILS_DBG_CMD_PATH);

    g_initialized = FALSE;

out:
    return err;
}


static sx_utils_status_t __sx_utils_debug_cmd_register_path(struct debug_cmd_entry           *dc_parent,
                                                            const struct debug_cmd_argc_argv *argc_argv,
                                                            sx_utils_debug_cmd_cb_t           handler_cb,
                                                            void                             *handler_context)
{
    cl_pool_item_t         *pool_entry = NULL;
    struct debug_cmd_entry *dc_entry = NULL;
    cl_qlist_t             *list = NULL;
    sx_utils_status_t       err = SX_UTILS_STATUS_SUCCESS;
    int                     depth = (dc_parent == NULL) ? 0 : dc_parent->depth + 1;

    while (depth < argc_argv->argc) {
        pool_entry = cl_qpool_get(&g_debug_cmd_db_pool);
        if (!pool_entry) {
            err = SX_UTILS_STATUS_NO_MEMORY;
            goto out;
        }

        dc_entry = PARENT_STRUCT(pool_entry, struct debug_cmd_entry, pool_item);

        dc_entry->depth = depth;
        dc_entry->parent = dc_parent;
        cl_qlist_init(&dc_entry->children);
        dc_entry->is_default = DEBUG_CMD_IS_ARG_STR(argc_argv->argv[depth]);
        strncpy(dc_entry->command, argc_argv->argv[depth], sizeof(dc_entry->command) - 1);

        list = (dc_parent == NULL) ? &g_debug_cmd_db : &dc_parent->children;
        cl_qlist_insert_tail(list, &dc_entry->list_item);

        dc_entry->handler_cb = NULL;
        dc_entry->handler_context = NULL;

        depth++;
        dc_parent = dc_entry;
    }

    dc_entry->handler_cb = handler_cb;
    dc_entry->handler_context = handler_context;

out:
    return err;
}


static sx_utils_status_t __is_valid_path(const struct debug_cmd_argc_argv *argc_argv,
                                         struct debug_cmd_entry          **dc_last_match)
{
    struct debug_cmd_entry *dc_parent = NULL, *dc_entry = NULL;
    sx_utils_status_t       ret = SX_UTILS_STATUS_SUCCESS;
    int                     i = 0;

    /*
     * invalid paths:
     * 1) empty argv (argc == 0)
     * 2) too much args (argc > DEBUG_CMD_ARGC_MAX)
     * 3) path is creating second default entry in entry's children list
     * 4) path is a duplicate of an existing path.
     */

    if ((argc_argv->argc == 0) || (argc_argv->argc > DEBUG_CMD_ARGC_MAX)) {
        ret = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    for (i = 0; i < argc_argv->argc; i++) {
        dc_entry = __find_direct_child(dc_parent, argc_argv->argv[i]);

        if (!dc_entry) { /* new path is an extension of an existing path */
            break;
        }

        if (strcmp(dc_entry->command, argc_argv->argv[i]) != 0) {
            if (dc_entry->is_default && DEBUG_CMD_IS_ARG_STR(argc_argv->argv[i])) {
                ret = SX_UTILS_STATUS_PARAM_ERROR;
                goto out;
            }

            break;
        }

        dc_parent = dc_entry;
    }

    if (i == argc_argv->argc) { /* duplicate path */
        ret = SX_UTILS_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    *dc_last_match = dc_parent;

out:
    return ret;
}


sx_utils_status_t sx_utils_debug_cmd_register_path(const char             *path,
                                                   sx_utils_debug_cmd_cb_t handler_cb,
                                                   void                   *handler_context)
{
    char                       buff[SX_UTILS_DBG_CMD_BUFFER_SIZE] = { 0 };
    struct debug_cmd_argc_argv argc_argv;
    struct debug_cmd_entry    *dc_entry = NULL;
    sx_utils_status_t          err = SX_UTILS_STATUS_SUCCESS;

    if (!g_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if (!path) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    strncpy(buff, path, sizeof(buff) - 1);
    memset(&argc_argv, 0, sizeof(argc_argv));
    __create_argv(buff, &argc_argv);

    cl_spinlock_acquire(&g_debug_cmd_db_lock);

    err = __is_valid_path(&argc_argv, &dc_entry);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        goto unlock;
    }

    err = __sx_utils_debug_cmd_register_path(dc_entry,
                                             &argc_argv,
                                             handler_cb,
                                             handler_context);

unlock:
    cl_spinlock_release(&g_debug_cmd_db_lock);

out:
    return err;
}


sx_utils_status_t sx_utils_debug_cmd_unregister_path(const char *path)
{
    char                       buff[SX_UTILS_DBG_CMD_BUFFER_SIZE] = { 0 };
    struct debug_cmd_argc_argv argc_argv;
    sx_utils_status_t          err = SX_UTILS_STATUS_SUCCESS;
    struct debug_cmd_entry    *dc_entry = NULL, *dc_parent = NULL;
    int                        i = 0;

    if (!g_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    memset(&argc_argv, 0, sizeof(argc_argv));

    if (path) {
        strncpy(buff, path, sizeof(buff) - 1);
        __create_argv(buff, &argc_argv);
    }

    cl_spinlock_acquire(&g_debug_cmd_db_lock);

    if (path) {
        for (i = 0; i < argc_argv.argc; i++) {
            dc_entry = __find_direct_child(dc_parent, argc_argv.argv[i]);
            if (!dc_entry) {
                break;
            }

            dc_parent = dc_entry;
        }

        if (!dc_entry) {
            err = SX_UTILS_STATUS_ERROR;
            goto unlock;
        }

        __delete_entry(dc_entry);
    } else {
        __delete_all();
    }

unlock:
    cl_spinlock_release(&g_debug_cmd_db_lock);

out:
    return err;
}


static void __dump_options(cl_list_item_t * const list_entry, void *context)
{
    struct usage_param_ctx *upc = (struct usage_param_ctx*)context;
    uint32_t                old_bufflen = upc->bufflen;
    struct debug_cmd_entry *dc_entry = NULL;

    dc_entry = PARENT_STRUCT(list_entry, struct debug_cmd_entry, list_item);

    if (!dc_entry->is_default && upc->prefix && (upc->root == dc_entry->parent) &&
        (strncmp(dc_entry->command, upc->prefix, strlen(upc->prefix)) != 0)) {
        return;
    }

    if (upc->buff[0]) {
        strcat(upc->buff, " ");
    }

    strcat(upc->buff, dc_entry->command);
    upc->bufflen = strlen(upc->buff);

    cl_qlist_apply_func(&dc_entry->children, __dump_options, context);

    if (dc_entry->handler_cb) {
        fprintf(upc->stream, "%s\n", upc->buff);
    }

    upc->bufflen = old_bufflen;
    upc->buff[old_bufflen] = '\0';
}


static void __debug_cmd_usage(FILE                             *stream,
                              boolean_t                         is_space,
                              const struct debug_cmd_entry     *dc_entry,
                              const struct debug_cmd_argc_argv *argc_argv)
{
    struct usage_param_ctx ctx;
    const cl_qlist_t      *list = NULL;
    const char            *last_arg = NULL;
    int                    argc = 0;
    int                    depth = 0;

    memset(&ctx, 0, sizeof(ctx));

    if (!is_space) {
        argc = argc_argv->argc;
        last_arg = argc_argv->argv[argc - 1];

        if (dc_entry) {
            if (dc_entry->is_default) {
                if (dc_entry->depth == argc - 1) {
                    dc_entry = dc_entry->parent;
                }
            } else {
                if (strncmp(last_arg, dc_entry->command, strlen(last_arg)) == 0) {
                    dc_entry = dc_entry->parent;
                }
            }
        }
    }

    depth = (dc_entry == NULL) ? 0 : dc_entry->depth + 1;

    ctx.stream = stream;
    ctx.prefix = argc_argv->argv[depth];
    ctx.root = dc_entry;

    list = (dc_entry == NULL) ? &g_debug_cmd_db : &dc_entry->children;
    cl_qlist_apply_func(list, __dump_options, &ctx);
}


sx_utils_status_t sx_utils_debug_cmd_handle_command(void)
{
    sx_utils_status_t          err = SX_UTILS_STATUS_SUCCESS;
    char                       buff[SX_UTILS_DBG_CMD_BUFFER_SIZE] = { 0 };
    struct debug_cmd_argc_argv argc_argv, only_args;
    int                        fd = -1, bytes = 0, i = 0;
    FILE                      *f_stream = NULL;
    struct debug_cmd_entry    *dc_entry = NULL, *dc_parent = NULL;
    boolean_t                  is_help = FALSE, is_space = FALSE;

    if (!g_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    fd = accept(g_debug_cmd_fd, NULL, NULL);
    if (fd < 0) {
        SX_LOG_ERR("debug cmd handle request - failed to accept connection\n");
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    bytes = recv(fd, buff, sizeof(buff), 0);
    if (bytes <= 0) {
        SX_LOG_ERR("debug cmd handle request - failed to receive buffer\n");
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    memset(&argc_argv, 0, sizeof(argc_argv));
    memset(&only_args, 0, sizeof(only_args));
    /* coverity[string_null] */
    __create_command_argv(buff, &argc_argv, &is_help, &is_space);

    if (!is_help && (argc_argv.argc == 0)) {
        goto out;
    }

    f_stream = fdopen(fd, "w");
    if (!f_stream) {
        SX_LOG_ERR("debug cmd handle request - failed to convert fd to FILE\n");
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    cl_spinlock_acquire(&g_debug_cmd_db_lock);

    for (i = 0; i < argc_argv.argc; i++) {
        dc_entry = __find_direct_child(dc_parent, argc_argv.argv[i]);
        if (!dc_entry) {
            dc_entry = dc_parent;
            break;
        }

        if (dc_entry->is_default) {
            only_args.argv[only_args.argc++] = argc_argv.argv[i];
        }

        dc_parent = dc_entry;
    }

    /* at this point, 'dc_entry' is the last entry found in the path */

    for (; i < argc_argv.argc; i++) { /* copy the rest of the parameters */
        only_args.argv[only_args.argc++] = argc_argv.argv[i];
    }

    if (is_help) {
        __debug_cmd_usage(f_stream, is_space, dc_entry, &argc_argv);
    } else if (dc_entry && dc_entry->handler_cb) {
        dc_entry->handler_cb(f_stream,
                             only_args.argc,
                             only_args.argv,
                             dc_entry->handler_context);
    }

    cl_spinlock_release(&g_debug_cmd_db_lock);

out:
    if (f_stream) {
        fclose(f_stream);
    } else if (fd >= 0) { /* before creating f_stream */
        close(fd);
    }

    return err;
}
