/*
 * Copyright (C) 2001-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#define SDK_TIMER_C_

#include "gen_utils.h"
#include "sx/utils/sdk_timer.h"
#include "complib/cl_timer.h"
#include "complib/cl_types.h"
#include "complib/cl_spinlock.h"

#undef  __MODULE__
#define __MODULE__ TIMER

/************************************************
 *  Local Defines
 ***********************************************/
#define MAX_TIMERS 158

/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/
typedef struct sdk_timer {
    cl_timer_t                 timer;
    sdk_timer_type_t           type;
    sx_utils_int_cmd_e         cmd;
    uint32_t                   interval;
    boolean_t                  is_valid;
    void                      *context;
    uint32_t                   context_size;
    sx_utils_prio_buffer_num_e priority;
} sdk_timer_t;

typedef struct sdk_timer_db {
    sdk_timer_t   timers[MAX_TIMERS];
    cl_spinlock_t job_cb_lock;
} sdk_timer_db_t;

/************************************************
 *  Local variables
 ***********************************************/
static sdk_timer_db_t             g_timer_db;
static boolean_t                  g_is_initialized = FALSE;
static sx_utils_add_intern_job_cb __add_internal_job_cb;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/
static void __timer_cb(void *context)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    sdk_timer_t      *p_timer = (sdk_timer_t*)context;
    cl_status_t       cl_err = CL_SUCCESS;
    boolean_t         job_cb_locked = FALSE;
    boolean_t         restart_timer = FALSE;

    if (!p_timer) {
        SX_LOG_ERR("NULL context given!\n");
        goto out;
    }

    if (!g_is_initialized) {
        SX_LOG_ERR("SDK timer module is not initialized\n");
        goto out;
    }

    cl_spinlock_acquire(&g_timer_db.job_cb_lock);
    job_cb_locked = TRUE;

    if (__add_internal_job_cb) {
        err = __add_internal_job_cb(p_timer->cmd, p_timer->context,
                                    p_timer->context_size, p_timer->priority);
        if (SX_UTILS_CHECK_FAIL(err)) {
            if (err == SX_UTILS_STATUS_NO_RESOURCES) {
                /* If there was no room in the work queue for this job,
                 * try again */
                restart_timer = TRUE;
            } else {
                SX_LOG_ERR("Failed to add internal job with command %u to queue with priority %u, err = [%s]\n",
                           p_timer->cmd, p_timer->priority,
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }
        }
    } else {
        /* Periodic timers will not be reset when there is no internal job callback. */
        goto out;
    }

    cl_spinlock_release(&g_timer_db.job_cb_lock);
    job_cb_locked = FALSE;

    if ((p_timer->type == SDK_TIMER_TYPE_PERIODIC) || (restart_timer)) {
        cl_err = cl_timer_start(&p_timer->timer, p_timer->interval);
        if (cl_err != CL_SUCCESS) {
            SX_LOG_ERR("cl_timer_start failed for cmd %u, cl_err = [%s]\n",
                       p_timer->cmd, CL_STATUS_MSG(cl_err));
            goto out;
        }
    }

out:
    if (job_cb_locked) {
        cl_spinlock_release(&g_timer_db.job_cb_lock);
    }
    return;
}

void sdk_timer_register_cb(sx_utils_add_intern_job_cb cb)
{
    if (!g_is_initialized) {
        SX_LOG_INF("SDK timer module is not initialized\n");
        return;
    }
    cl_spinlock_acquire(&g_timer_db.job_cb_lock);
    __add_internal_job_cb = cb;
    cl_spinlock_release(&g_timer_db.job_cb_lock);
}

sx_utils_status_t sdk_timer_init(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;

    SX_LOG_ENTER();

    if (g_is_initialized) {
        err = SX_UTILS_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("SDK timer module is already initialized\n");
        goto out;
    }

    M_GEN_UTILS_MEM_CLR(g_timer_db);

    cl_err = cl_spinlock_init(&g_timer_db.job_cb_lock);
    if (cl_err != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("cl_spinlock_init failed, cl_err = [%s]\n",
                   CL_STATUS_MSG(cl_err));
        goto out;
    }

    g_is_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t sdk_timer_deinit(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i = 0;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("SDK timer module is not initialized\n");
        goto out;
    }

    for (i = 0; i < MAX_TIMERS; i++) {
        if (g_timer_db.timers[i].is_valid) {
            cl_timer_destroy(&g_timer_db.timers[i].timer);
        }
    }

    cl_spinlock_destroy(&g_timer_db.job_cb_lock);

    M_GEN_UTILS_MEM_CLR(g_timer_db);
    g_is_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t sdk_timer_get(sx_utils_int_cmd_e         cmd,
                                sdk_timer_type_t           type,
                                void                      *context,
                                uint32_t                   context_size,
                                sx_utils_prio_buffer_num_e priority,
                                sdk_timer_handle_t        *p_timer_hdl)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t        cl_err = CL_SUCCESS;
    sdk_timer_handle_t hdl = 0;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("SDK timer module is not initialized\n");
        goto out;
    }

    if (p_timer_hdl == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_timer_hdl is NULL\n");
        goto out;
    }

    if (!SDK_TIMER_TYPE_CHECK_RANGE(type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid timer type %u given\n", type);
        goto out;
    }

    if (priority > SX_UTILS_MAX_PRIO_BUF_E) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid priority %u given\n", priority);
        goto out;
    }

    for (hdl = 0; hdl < MAX_TIMERS; hdl++) {
        if (g_timer_db.timers[hdl].is_valid) {
            continue;
        }

        break;
    }

    if (hdl >= MAX_TIMERS) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        SX_LOG_ERR("No timer resources remaining for cmd %u\n", cmd);
        goto out;
    }

    cl_err = cl_timer_init(&g_timer_db.timers[hdl].timer, __timer_cb,
                           &g_timer_db.timers[hdl]);
    if (cl_err != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("cl_timer_init failed for cmd %u, cl_err = [%s]\n",
                   cmd, CL_STATUS_MSG(cl_err));
        goto out;
    }

    g_timer_db.timers[hdl].type = type;
    g_timer_db.timers[hdl].is_valid = TRUE;
    g_timer_db.timers[hdl].cmd = cmd;
    g_timer_db.timers[hdl].context = context;
    g_timer_db.timers[hdl].context_size = context_size;
    g_timer_db.timers[hdl].priority = priority;

    *p_timer_hdl = hdl;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t sdk_timer_put(sdk_timer_handle_t timer_hdl)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("SDK timer module is not initialized\n");
        goto out;
    }

    if (timer_hdl >= MAX_TIMERS) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid timer handle %u given\n", timer_hdl);
        goto out;
    }

    if (!g_timer_db.timers[timer_hdl].is_valid) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Timer handle %u not found\n", timer_hdl);
        goto out;
    }

    cl_timer_destroy(&g_timer_db.timers[timer_hdl].timer);

    M_GEN_UTILS_MEM_CLR(g_timer_db.timers[timer_hdl]);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t sdk_timer_start(sdk_timer_handle_t timer_hdl, uint32_t interval)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;


    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("SDK timer module is not initialized\n");
        goto out;
    }

    if (timer_hdl >= MAX_TIMERS) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid timer handle %u given\n", timer_hdl);
        goto out;
    }

    if (!g_timer_db.timers[timer_hdl].is_valid) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Timer handle %u not found\n", timer_hdl);
        goto out;
    }

    /* We'll allow an interval of 0, but only for one-shot timers. A zero
     * interval means that the timer will expire immediately.
     */
    if ((g_timer_db.timers[timer_hdl].type == SDK_TIMER_TYPE_PERIODIC) &&
        (interval == 0)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Timer interval can't be 0 for periodic timers\n");
        goto out;
    }

    g_timer_db.timers[timer_hdl].interval = interval;
    cl_err = cl_timer_start(&g_timer_db.timers[timer_hdl].timer,
                            interval);
    if (cl_err != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("cl_timer_start failed for handle %u, cl_err = [%s]\n",
                   timer_hdl, CL_STATUS_MSG(cl_err));
        goto out;
    }

out:
    return err;
}

sx_utils_status_t sdk_timer_stop(sdk_timer_handle_t timer_hdl)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("SDK timer module is not initialized\n");
        goto out;
    }

    if (timer_hdl >= MAX_TIMERS) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid timer handle %u given\n", timer_hdl);
        goto out;
    }

    if (!g_timer_db.timers[timer_hdl].is_valid) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Timer handle %u not found\n", timer_hdl);
        goto out;
    }

    cl_timer_stop(&g_timer_db.timers[timer_hdl].timer);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t sdk_timer_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}
