/*
 * Copyright (C) 2001-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef GC_DB_H_
#define GC_DB_H_

#include "sx/utils/gc.h"
#include "sx/utils/sdk_timer.h"


/************************************************
 *  Defines
 ***********************************************/
#define GC_DEFAULT_GROW_SIZE 64

/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

sx_utils_status_t gc_db_init(void);
sx_utils_status_t gc_db_deinit(void);
sx_utils_status_t gc_db_object_init(gc_object_type_t                   object_type,
                                    const gc_object_type_attributes_t *object_attr,
                                    gc_object_completion_pfn           completion_cb,
                                    gc_object_post_completion_pfn      post_completion_cb,
                                    gc_object_type_t                 **object_context);
sx_utils_status_t gc_db_object_deinit(gc_object_type_t object_type);
sx_utils_status_t gc_db_object_type_attributes_get(gc_object_type_t             object_type,
                                                   gc_object_type_attributes_t *object_attr);
sx_utils_status_t gc_db_object_completion_cb_get(gc_object_type_t               object_type,
                                                 gc_object_completion_pfn      *completion_cb,
                                                 gc_object_post_completion_pfn *post_completion_cb);
sx_utils_status_t gc_db_object_timer_handle_set(gc_object_type_t   object_type,
                                                sdk_timer_handle_t timer_handle);
sx_utils_status_t gc_db_object_timer_handle_get(gc_object_type_t    object_type,
                                                sdk_timer_handle_t *timer_handle);
sx_utils_status_t gc_db_queue_push(gc_object_type_t    object_type,
                                   gc_state_t          state,
                                   uint32_t            seq_num,
                                   uint32_t            alt_seq_num,
                                   const void         *gc_context,
                                   uint32_t            size,
                                   gc_object_subtype_t subtype,
                                   uint32_t            start_index,
                                   gc_handle_t        *gc_handle);
sx_utils_status_t gc_db_global_queue_top(gc_object_data_t *object_data);
sx_utils_status_t gc_db_object_type_queue_top(gc_object_type_t  object_type,
                                              gc_object_data_t *object_data);
sx_utils_status_t gc_db_global_queue_pop(gc_object_data_t *object_data);
sx_utils_status_t gc_db_object_type_queue_pop(gc_object_type_t  object_type,
                                              gc_object_data_t *object_data);
sx_utils_status_t gc_db_dump(FILE* stream);
sx_utils_status_t gc_db_dump_queues(FILE* stream,  gc_object_type_t resource, boolean_t print_empty);
sx_utils_status_t gc_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_utils_status_t gc_db_object_timer_started_set(gc_object_type_t object_type,
                                                 boolean_t        timer_started);
sx_utils_status_t gc_db_object_timer_started_get(gc_object_type_t object_type,
                                                 boolean_t       *timer_started);
sx_utils_status_t gc_db_object_type_total_size_get(gc_object_type_t object_type,
                                                   uint32_t        *total_size);
sx_utils_status_t gc_db_object_remove(gc_handle_t gc_handle);
sx_utils_status_t gc_db_object_type_is_initialized(gc_object_type_t object_type,
                                                   boolean_t       *is_initialized);
sx_utils_status_t gc_db_object_type_count_get(gc_object_type_t object_type, uint32_t *count);
sx_utils_status_t gc_db_context_get(gc_handle_t gc_handle, void** gc_context);

#endif /* GC_DB_H_ */
