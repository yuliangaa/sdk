/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#undef  __MODULE__
#define __MODULE__ GEN_UTILS

#include "sx/utils/sdk_refcount.h"
#include "sx/utils/dbg_utils.h"
#include "sx/utils/dbg_utils_pretty_printer.h"
#include "complib/cl_atomic.h"
#include "complib/cl_qmap.h"
#include "complib/cl_qpool.h"
#include <complib/cl_dbg.h>
#include <complib/cl_mem.h>
#include <execinfo.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cl_qpool_t g_refcount_pool;
static cl_qlist_t g_refcount_db;
static cl_qpool_t g_ref_pool;
static boolean_t  g_initialized = FALSE;

/************************************************
 *  Local definitions
 ***********************************************/

#define SMALL_STACK_TRACE_LENGTH 5
#define REF_CNT_DB_MIN_SIZE      1000
#define REF_DB_MIN_SIZE          1000
#define MAX_REFERENCE_DATA_SIZE  160

#define VERIFY_DB_INITIALIZED                                           \
    if (g_initialized == FALSE) {                                       \
        SX_LOG(SX_LOG_ERROR, "ref_count system was not initialized\n"); \
        err = SX_UTILS_STATUS_NOT_INITIALIZED;                          \
        goto out;                                                       \
    }

#define VALIDATE_POINTER_NOT_NULL(x)                               \
    if (x == NULL) {                                               \
        SX_LOG(SX_LOG_ERROR, "Parameter " #x " was given NULL\n"); \
        err = SX_UTILS_STATUS_PARAM_ERROR;                         \
        goto out;                                                  \
    }

typedef struct ref_db_obj {
    cl_pool_item_t      pool_item;
    cl_list_item_t      list_item;
    uint8_t            *reference_name_data;
    size_t              reference_name_data_size;
    cl_ref_print_func_p print_func_p;
} ref_db_obj_t;

typedef struct refcount_db_obj {
    cl_pool_item_t      pool_item;
    cl_list_item_t      list_item;
    atomic32_t          refcount;
    uint8_t            *referenced_name_data;
    size_t              referenced_name_data_size;
    cl_qlist_t          references;
    cl_ref_print_func_p print_func_p;
    uint64_t            delete_id;
    cl_delete_func_p    delete_func_p;
} refcount_db_obj_t;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

static const char* __get_referenced_name(char* name_buff, size_t name_size, refcount_db_obj_t *refcount_entry_p)
{
    const char* str_p = NULL;

    str_p = refcount_entry_p->print_func_p(name_buff, name_size, refcount_entry_p->referenced_name_data);
    return str_p;
}

static const char* __get_reference_name(char* name_buff, size_t name_size, ref_db_obj_t *ref_entry_p)
{
    const char* str_p = NULL;

    str_p = ref_entry_p->print_func_p(name_buff, name_size, ref_entry_p->reference_name_data);
    return str_p;
}

static char* __get_ref_line(char* line_buf, int len, refcount_db_obj_t *refcount_entry_p)
{
    const cl_list_item_t *ref_end_p;
    cl_list_item_t       *ref_iter_p;
    int                   total = 0;
    ref_db_obj_t         *ref_entry_p;
    char                  refname[REFERENCE_NAME_MAX_LEN];

    ref_iter_p = cl_qlist_head(&refcount_entry_p->references);
    ref_end_p = cl_qlist_end(&refcount_entry_p->references);

    if (len != 0) {
        line_buf[0] = '\0';
    }

    while (ref_iter_p != ref_end_p) {
        ref_entry_p = PARENT_STRUCT(ref_iter_p, ref_db_obj_t, list_item);
        total +=
            snprintf(line_buf + total, len - total, "%s, ",
                     __get_reference_name(refname, sizeof(refname), ref_entry_p));
        if (total >= len) {
            break;
        }
        ref_iter_p = cl_qlist_next(ref_iter_p);
    }

    return line_buf;
}

sx_utils_status_t sdk_refcount_system_init(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    boolean_t         refcount_pool_inited = FALSE;

    SX_LOG_ENTER();

    if (g_initialized) {
        SX_LOG(SX_LOG_ERROR, "The reference count system was already initialized\n");
        err = SX_UTILS_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    err = CL_QPOOL_INIT(&g_refcount_pool,
                        REF_CNT_DB_MIN_SIZE,
                        CL_POOL_UNLIMITED_MAX_SIZE,
                        64,
                        sizeof(refcount_db_obj_t),
                        NULL,
                        NULL,
                        NULL);

    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to init the refcount system. "
               "cl_qpool_init failed."
               "err: %s.\n", CL_STATUS_MSG(err));
        goto out;
    }
    refcount_pool_inited = TRUE;

    err = CL_QPOOL_INIT(&g_ref_pool, REF_DB_MIN_SIZE, CL_POOL_UNLIMITED_MAX_SIZE,
                        64, sizeof(ref_db_obj_t), NULL, NULL, NULL);

    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to init the refcount system. "
               "cl_qpool_init failed."
               "err: %s.\n", CL_STATUS_MSG(err));
        goto out;
    }

    cl_qlist_init(&g_refcount_db);

    g_initialized = TRUE;

out:
    if (err != SX_UTILS_STATUS_SUCCESS) {
        if (refcount_pool_inited) {
            CL_QPOOL_DESTROY(&g_refcount_pool);
        }
    }
    SX_LOG_EXIT();
    return err;
}

static void __clear_refcount_refs(refcount_db_obj_t *refcount_entry_p)
{
    ref_db_obj_t         *ref_entry_p;
    cl_list_item_t       *ref_iter_p;
    const cl_list_item_t *ref_end_p;

    ref_iter_p = cl_qlist_head(&refcount_entry_p->references);
    ref_end_p = cl_qlist_end(&refcount_entry_p->references);

    while (ref_iter_p != ref_end_p) {
        ref_entry_p = PARENT_STRUCT(ref_iter_p, ref_db_obj_t, list_item);

        ref_iter_p = cl_qlist_next(ref_iter_p);

        if (ref_entry_p->reference_name_data != NULL) {
            cl_free(ref_entry_p->reference_name_data);
        }
        cl_qlist_remove_item(&refcount_entry_p->references, &(ref_entry_p->list_item));
        cl_qpool_put(&g_ref_pool, &(ref_entry_p->pool_item));
    }
}

sx_utils_status_t sdk_refcount_system_deinit(boolean_t is_forced)
{
    const cl_list_item_t *refcount_end_p;
    cl_list_item_t       *refcount_iter_p;
    sx_utils_status_t     err = SX_UTILS_STATUS_SUCCESS;
    refcount_db_obj_t    *refcount_entry_p;

    SX_LOG_ENTER();

    VERIFY_DB_INITIALIZED;

    refcount_iter_p = cl_qlist_head(&g_refcount_db);
    refcount_end_p = cl_qlist_end(&g_refcount_db);

    if (is_forced == FALSE) {
        if (refcount_iter_p != refcount_end_p) {
            err = SX_UTILS_STATUS_ERROR;
            SX_LOG(SX_LOG_ERROR, "Found pending references, cannot deinit.\n");
            goto out;
        }
    }

    /* clear the refcount map */
    while (refcount_iter_p != refcount_end_p) {
        refcount_entry_p = PARENT_STRUCT(refcount_iter_p, refcount_db_obj_t, list_item);
        refcount_iter_p = cl_qlist_next(refcount_iter_p);

        __clear_refcount_refs(refcount_entry_p);

        if (refcount_entry_p->referenced_name_data != NULL) {
            cl_free(refcount_entry_p->referenced_name_data);
        }
        cl_qlist_remove_item(&g_refcount_db, &(refcount_entry_p->list_item));
        cl_qpool_put(&g_refcount_pool, &(refcount_entry_p->pool_item));
    }

    CL_QPOOL_DESTROY(&g_refcount_pool);
    CL_QPOOL_DESTROY(&g_ref_pool);
    g_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t sdk_refcount_init(sdk_refcount_t          *refcount_p,
                                    const ref_name_data_t   *ref_name_data,
                                    const ref_delete_data_t *delete_data_p)
{
    cl_pool_item_t    *pool_item_p;
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    refcount_db_obj_t *refcount_entry_p;

    SX_LOG_ENTER();

    VERIFY_DB_INITIALIZED;

    VALIDATE_POINTER_NOT_NULL(refcount_p);
    VALIDATE_POINTER_NOT_NULL(ref_name_data);
    VALIDATE_POINTER_NOT_NULL(ref_name_data->print_func_p);

    /* If we are using a data make sure it fits in our storage */
    if ((ref_name_data->ref_data_p != NULL) &&
        (ref_name_data->data_size > MAX_REFERENCE_DATA_SIZE)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "Size of reference data (%zu) is larger than allowed (%d).\n",
               ref_name_data->data_size, MAX_REFERENCE_DATA_SIZE);
        goto out;
    }

    pool_item_p = cl_qpool_get(&g_refcount_pool);
    if (NULL == pool_item_p) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        SX_LOG(SX_LOG_ERROR, "No resources to allocate new refcount pool entry.\n");
        goto out;
    }

    refcount_entry_p = PARENT_STRUCT(pool_item_p, refcount_db_obj_t, pool_item);
    /* Store the data if it exists.*/
    if ((ref_name_data->ref_data_p != NULL) && (ref_name_data->data_size > 0)) {
        refcount_entry_p->referenced_name_data = cl_malloc(ref_name_data->data_size);
        if (refcount_entry_p->referenced_name_data == NULL) {
            err = SX_UTILS_STATUS_NO_MEMORY;
            SX_LOG_ERR("No memory to allocate referenced name data for new refcount pool entry.\n");
            goto out_put_pool_obj;
        }
        refcount_entry_p->referenced_name_data_size = ref_name_data->data_size;
        memcpy(refcount_entry_p->referenced_name_data, ref_name_data->ref_data_p, ref_name_data->data_size);
    } else {
        refcount_entry_p->referenced_name_data = NULL;
        refcount_entry_p->referenced_name_data_size = 0;
    }

    if (delete_data_p != NULL) {
        refcount_entry_p->delete_func_p = delete_data_p->delete_func_p;
        refcount_entry_p->delete_id = delete_data_p->id;
    } else {
        refcount_entry_p->delete_func_p = NULL;
        refcount_entry_p->delete_id = 0xFFFFFFFF;
    }

    refcount_entry_p->print_func_p = ref_name_data->print_func_p;
    cl_qlist_init(&refcount_entry_p->references);

    refcount_entry_p->refcount = 0;
    cl_qlist_insert_tail(&g_refcount_db, &refcount_entry_p->list_item);
    *refcount_p = refcount_entry_p;
    goto out;

out_put_pool_obj:
    cl_qpool_put(&g_refcount_pool, pool_item_p);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t sdk_refcount_deinit(sdk_refcount_t *refcount_p, boolean_t is_forced)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    refcount_db_obj_t *refcount_entry_p;
    char               refs_line[400];
    char               refname[REFERENCED_NAME_MAX_LEN];

    SX_LOG_ENTER();

    VERIFY_DB_INITIALIZED;

    refcount_entry_p = *refcount_p;

    if (is_forced) {
        __clear_refcount_refs(refcount_entry_p);
    } else {
        if (refcount_entry_p->refcount != 0) {
            SX_LOG_ERR("Failed to deinit %s reference count as it still has %d references: %s\n",
                       __get_referenced_name(refname, sizeof(refname), refcount_entry_p), refcount_entry_p->refcount,
                       __get_ref_line(refs_line, 400, refcount_entry_p));
            err = SX_UTILS_STATUS_RESOURCE_IN_USE;
            goto out;
        }
    }

    if (refcount_entry_p->referenced_name_data != NULL) {
        cl_free(refcount_entry_p->referenced_name_data);
    }
    cl_qlist_remove_item(&g_refcount_db, &refcount_entry_p->list_item);
    cl_qpool_put(&g_refcount_pool, &(refcount_entry_p->pool_item));

out:
    SX_LOG_EXIT();
    return err;
}


#ifdef _DEBUG
static inline void sdk_refcount_print_small_stack_trace(void)
{
    void * array[SMALL_STACK_TRACE_LENGTH];
    char** strings;
    int    size, i;

    size = backtrace(array, SMALL_STACK_TRACE_LENGTH);
    strings = backtrace_symbols(array, size);

    if (strings) {
        for (i = 0; i < size; i++) {
            SX_LOG(SX_LOG_DEBUG, "%s\n", strings[i]);
        }

        free(strings);
    } else {
        SX_LOG(SX_LOG_INFO, "backtrace_symbols failed on refcount system.\n");
    }
}
#endif


sx_utils_status_t sdk_refcount_inc(sdk_refcount_t        *refcount_p,
                                   const ref_name_data_t *ref_name_data,
                                   sdk_ref_t             *reference)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    cl_pool_item_t    *pool_item_p;
    refcount_db_obj_t *refcount_entry_p;
    ref_db_obj_t      *ref_entry_p;

    SX_LOG_ENTER();

    VERIFY_DB_INITIALIZED;

    VALIDATE_POINTER_NOT_NULL(reference);
    VALIDATE_POINTER_NOT_NULL(refcount_p);
    VALIDATE_POINTER_NOT_NULL(ref_name_data);
    VALIDATE_POINTER_NOT_NULL(ref_name_data->print_func_p);

    /* If we are using a data make sure it fits in our storage */
    if ((ref_name_data->ref_data_p != NULL) && (ref_name_data->data_size > MAX_REFERENCE_DATA_SIZE)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "Size of reference data (%zu) is larger than allowed (%d).\n",
               ref_name_data->data_size, MAX_REFERENCE_DATA_SIZE);
        goto out;
    }

    refcount_entry_p = *refcount_p;

    pool_item_p = cl_qpool_get(&g_ref_pool);
    if (NULL == pool_item_p) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        SX_LOG(SX_LOG_ERROR, "No resources to allocate new reference pool entry.\n");
        goto out;
    }

    ref_entry_p = PARENT_STRUCT(pool_item_p, ref_db_obj_t, pool_item);
    /* Store the data if it exists.*/
    if ((ref_name_data->ref_data_p != NULL) && (ref_name_data->data_size > 0)) {
        ref_entry_p->reference_name_data = cl_malloc(ref_name_data->data_size);
        if (ref_entry_p->reference_name_data == NULL) {
            err = SX_UTILS_STATUS_NO_MEMORY;
            SX_LOG_ERR("No memory to allocate reference name data for new reference pool entry.\n");
            goto out_put_pool_obj;
        }
        ref_entry_p->reference_name_data_size = ref_name_data->data_size;
        memcpy(ref_entry_p->reference_name_data, ref_name_data->ref_data_p, ref_name_data->data_size);
    } else {
        ref_entry_p->reference_name_data = NULL;
        ref_entry_p->reference_name_data_size = 0;
    }
    ref_entry_p->print_func_p = ref_name_data->print_func_p;

    cl_qlist_insert_tail(&refcount_entry_p->references, &ref_entry_p->list_item);
    *reference = ref_entry_p;

    cl_atomic_inc(&refcount_entry_p->refcount);

#ifdef _DEBUG
    char refname[REFERENCED_NAME_MAX_LEN];
    SX_LOG(SX_LOG_DEBUG, "reference to %s (%p) increased to %d. Stack trace:\n",
           __get_referenced_name(refname, refcount_entry_p),
           refcount_entry_p,
           refcount_entry_p->refcount);

    sdk_refcount_print_small_stack_trace();
#endif

    goto out;

out_put_pool_obj:
    cl_qpool_put(&g_ref_pool, pool_item_p);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t sdk_refcount_dec(sdk_refcount_t *refcount_p, const sdk_ref_t *reference)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    refcount_db_obj_t *refcount_entry_p;
    ref_db_obj_t      *ref_entry_p;
    char               refname[REFERENCED_NAME_MAX_LEN];

    SX_LOG_ENTER();

    VERIFY_DB_INITIALIZED;
    VALIDATE_POINTER_NOT_NULL(reference);
    VALIDATE_POINTER_NOT_NULL(refcount_p);

    refcount_entry_p = *refcount_p;

    if (refcount_entry_p->refcount == 0) {
        err = SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR,
               "Tried to reduce refcount to negative number on %s\n",
               __get_referenced_name(refname, sizeof(refname), refcount_entry_p));
        goto out;
    }

    ref_entry_p = *reference;

    if (ref_entry_p->reference_name_data != NULL) {
        cl_free(ref_entry_p->reference_name_data);
    }
    cl_qlist_remove_item(&refcount_entry_p->references, &ref_entry_p->list_item);
    cl_qpool_put(&g_ref_pool, &ref_entry_p->pool_item);

    /* Decrease the refcount counter */
    cl_atomic_dec(&refcount_entry_p->refcount);

    if ((refcount_entry_p->refcount == 0) && (refcount_entry_p->delete_func_p != NULL)) {
        refcount_entry_p->delete_func_p(refcount_entry_p->delete_id);
    }

#ifdef _DEBUG
    SX_LOG(SX_LOG_DEBUG, "reference to %s (%p) decreased to %d. Stack trace:\n",
           __get_referenced_name(refname, refcount_entry_p),
           refcount_entry_p,
           refcount_entry_p->refcount);

    sdk_refcount_print_small_stack_trace(void);
#endif

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t sdk_refcount_rename_ref(const sdk_ref_t *reference, const ref_name_data_t *ref_name_data)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    ref_db_obj_t     *ref_entry_p;
    uint8_t          *new_reference_name_data_p = NULL;

    SX_LOG_ENTER();

    VERIFY_DB_INITIALIZED;
    VALIDATE_POINTER_NOT_NULL(reference);
    VALIDATE_POINTER_NOT_NULL(ref_name_data);
    VALIDATE_POINTER_NOT_NULL(ref_name_data->print_func_p);

    /* If we are using a data make sure it fits in our storage */
    if ((ref_name_data->ref_data_p != NULL) && (ref_name_data->data_size > MAX_REFERENCE_DATA_SIZE)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "Size of reference data (%zu) is larger than allowed (%d).\n",
               ref_name_data->data_size, MAX_REFERENCE_DATA_SIZE);
        goto out;
    }

    ref_entry_p = *reference;

#ifdef _DEBUG
    char refname[REFERENCED_NAME_MAX_LEN];
    SX_LOG(SX_LOG_DEBUG, "Reference renamed for %s. Stack trace:\n",
           __get_reference_name(refname, ref_entry_p));

    sdk_refcount_print_small_stack_trace(void);
#endif

    /* Store the data if it exists.*/
    if ((ref_name_data->ref_data_p != NULL) && (ref_name_data->data_size > 0)) {
        if (ref_entry_p->reference_name_data_size != ref_name_data->data_size) {
            new_reference_name_data_p = cl_malloc(ref_name_data->data_size);
            if (new_reference_name_data_p == NULL) {
                err = SX_UTILS_STATUS_NO_MEMORY;
                SX_LOG_ERR("No memory to allocate new reference name data for reference entry.\n");
                goto out;
            }
            if (ref_entry_p->reference_name_data != NULL) {
                cl_free(ref_entry_p->reference_name_data);
            }
            ref_entry_p->reference_name_data = new_reference_name_data_p;
            ref_entry_p->reference_name_data_size = ref_name_data->data_size;
        }
        memcpy(ref_entry_p->reference_name_data, ref_name_data->ref_data_p, ref_name_data->data_size);
    }
    ref_entry_p->print_func_p = ref_name_data->print_func_p;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t sdk_refcount_get(sdk_refcount_t *refcount_p, int32_t* val)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    refcount_db_obj_t *refcount_entry_p;

    SX_LOG_ENTER();

    VERIFY_DB_INITIALIZED;

    refcount_entry_p = *refcount_p;
    *val = cl_atomic_add(&refcount_entry_p->refcount, 0);

out:
    SX_LOG_EXIT();
    return err;
}

/**
 * Return a name of all reference for refcount object.
 *
 * @param[in] refcount_p - the reference to rename.
 * @param[in] buf_size  - size of output buffer for reference
 *       name
 * @param[out] reference_name - the name of all references.
 *
 */
sx_utils_status_t sdk_refcount_getname_ref(sdk_refcount_t *refcount_p, uint32_t buf_size, char* references_name)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    refcount_db_obj_t *refcount_entry_p = NULL;

    SX_LOG_ENTER();

    VERIFY_DB_INITIALIZED;
    VALIDATE_POINTER_NOT_NULL(refcount_p);
    VALIDATE_POINTER_NOT_NULL(references_name);

    refcount_entry_p = *refcount_p;

    __get_ref_line(references_name, buf_size, refcount_entry_p);

#ifdef _DEBUG
    SX_LOG(SX_LOG_DEBUG, "Name for reference (%p) is %s. Stack trace:\n",
           reference, reference_name);

    sdk_refcount_print_small_stack_trace(void);
#endif

out:
    SX_LOG_EXIT();
    return err;
}

const char* print_reference_name(ref_name_data_t *ref_name_data)
{
    const char* str_p = NULL;

    str_p = ref_name_data->print_func_p(&(ref_name_data->result_str[0]),
                                        sizeof(ref_name_data->result_str),
                                        ref_name_data->ref_data_p);
    return str_p;
}

void sdk_refcount_debug_dump(FILE* stream)
{
    const cl_list_item_t            *ref_end_p;
    cl_list_item_t                  *ref_iter_p;
    ref_db_obj_t                    *ref_entry_p;
    const cl_list_item_t            *refcount_end_p;
    cl_list_item_t                  *refcount_iter_p;
    refcount_db_obj_t               *refcount_entry_p;
    int32_t                          refcountn;
    char                             refcount_str[10];
    char                             reference_name[REFERENCE_NAME_MAX_LEN];
    char                             referenced_name[REFERENCED_NAME_MAX_LEN];
    char                             delete_id_str[25] = "N/A";
    static dbg_utils_table_columns_t sdk_router_refcount_dump_columns[] = {
        { "Referenced",   REFERENCED_NAME_MAX_LEN,  PARAM_STRING_E,     NULL }, /* 0 */
        { "Refcount",     8,                        PARAM_STRING_E,     NULL }, /* 1 */
        { "Reference",    REFERENCE_NAME_MAX_LEN,   PARAM_STRING_E,     NULL }, /* 2 */
        { "Delete id",    16,                        PARAM_STRING_E,     NULL }, /* 3 */
        { NULL, 0, 0, NULL}
    };

    SX_LOG_ENTER();

    dbg_utils_pprinter_module_header_print(stream, "Reference Count Infrastructure Debug Dump");
    dbg_utils_pprinter_field_print(stream, "DB initialized", &(g_initialized), PARAM_BOOL_E);
    if (g_initialized) {
        dbg_utils_pprinter_general_header_print(stream, "Active Reference Summary");
        dbg_utils_pprinter_table_headline_print(stream, sdk_router_refcount_dump_columns);

        refcount_iter_p = cl_qlist_head(&g_refcount_db);
        refcount_end_p = cl_qlist_end(&g_refcount_db);

        while (refcount_iter_p != refcount_end_p) {
            refcount_entry_p = PARENT_STRUCT(refcount_iter_p, refcount_db_obj_t, list_item);
            refcount_iter_p = cl_qlist_next(refcount_iter_p);

            refcountn = cl_atomic_add(&refcount_entry_p->refcount, 0);
            snprintf(refcount_str, 10, "%d", refcountn);

            ref_iter_p = cl_qlist_head(&refcount_entry_p->references);
            ref_end_p = cl_qlist_end(&refcount_entry_p->references);

            while (ref_iter_p != ref_end_p) {
                ref_entry_p = PARENT_STRUCT(ref_iter_p, ref_db_obj_t, list_item);
                ref_iter_p = cl_qlist_next(ref_iter_p);

                sdk_router_refcount_dump_columns[0].data =
                    __get_referenced_name(referenced_name, sizeof(referenced_name), refcount_entry_p);
                sdk_router_refcount_dump_columns[1].data = refcount_str;
                sdk_router_refcount_dump_columns[2].data = __get_reference_name(reference_name,
                                                                                sizeof(reference_name),
                                                                                ref_entry_p);
                if (refcount_entry_p->delete_id != 0xFFFFFFFF) {
                    snprintf(delete_id_str, sizeof(delete_id_str), "(%" PRIu64 ")", refcount_entry_p->delete_id);
                }
                sdk_router_refcount_dump_columns[3].data = delete_id_str;

                dbg_utils_pprinter_table_data_line_print(stream, sdk_router_refcount_dump_columns);
            }
        }
    }

    SX_LOG_EXIT();
}
