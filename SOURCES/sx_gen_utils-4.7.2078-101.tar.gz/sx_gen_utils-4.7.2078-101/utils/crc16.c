/*
 * Copyright (C) 2016-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sx/utils/crc16.h"

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Definitions
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local definitions
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

/*
 * static void init_crc16_tab( void );
 *
 * For optimal performance uses the CRC16 routine a lookup table with values
 * that can be used directly in the XOR arithmetic in the algorithm. This
 * lookup table is calculated by the init_crc16_tab() routine, the first time
 * the CRC function is called. Bits in bytes are processed lsb-to-msb.
 */

static void init_crc16_tab(crc16_table_t *crc16_table, uint16_t crc16_poly)
{
    uint16_t i;
    uint16_t j;
    uint16_t crc;

    for (i = 0; i < CRC16_TABLE_SIZE; i++) {
        crc = i;

        for (j = 0; j < BYTE_SIZE; j++) {
            if (crc & 0x0001) {
                crc = (crc >> 1) ^ crc16_poly;
            } else {
                crc = crc >> 1;
            }
        }

        crc16_table->table[i] = crc;
    }

    crc16_table->table_init = TRUE;
}

/* Same as above but bits in bytes are processed msb-to-lsb. */

static void init_crc16_tab_msb(crc16_table_t *crc16_table, uint16_t crc16_poly)
{
    uint16_t i;
    uint16_t j;
    uint16_t crc;

    for (i = 0; i < CRC16_TABLE_SIZE; i++) {
        crc = i << 8;

        for (j = 0; j < BYTE_SIZE; j++) {
            if (crc & 0x8000) {
                crc = (crc << 1) ^ crc16_poly;
            } else {
                crc = crc << 1;
            }
        }

        crc16_table->table[i] = crc;
    }

    crc16_table->table_init = TRUE;
}


static void init_crc_tab_msb(crc16_table_t *crc16_table, uint16_t crc16_poly, uint16_t crc_length)
{
    uint16_t i;
    uint16_t j;
    uint16_t crc;
    uint16_t msb_mask = (1 << (crc_length - 1));
    uint16_t mask = ((msb_mask - 1) << 1) + 1;
    uint16_t shift = (crc_length >= 8) ? 0 : (8 - crc_length);

    for (i = 0; i < CRC16_TABLE_SIZE; i++) {
        crc = i << (crc_length + shift - 8);

        for (j = 0; j < BYTE_SIZE; j++) {
            if (crc & (msb_mask << shift)) {
                crc = (crc << 1) ^ (crc16_poly << shift);
            } else {
                crc = crc << 1;
            }
        }

        crc16_table->table[i] = (crc >> shift) & mask;
    }

    crc16_table->table_init = TRUE;
}


/*
 * uint16_t crc_16( const unsigned char *input_str, size_t num_bytes );
 *
 * The function crc_16() calculates the 16 bits CRC16 in one pass for a byte
 * string of which the beginning has been passed to the function. The number of
 * bytes to check is also a parameter. The number of the bytes in the string is
 * limited by the constant SIZE_MAX. . Bits in bytes are processed lsb-to-msb.
 */

uint16_t crc_16(crc16_table_t *crc16_table, const uint8_t *input_str, size_t num_bytes, uint16_t crc16_poly)
{
    uint16_t             crc;
    uint16_t             tmp;
    uint16_t             short_c;
    const unsigned char *ptr;
    size_t               a;

    if (!crc16_table->table_init) {
        init_crc16_tab(crc16_table, crc16_poly);
    }

    crc = CRC_START_16;
    ptr = input_str;

    if (ptr != NULL) {
        for (a = 0; a < num_bytes; a++) {
            short_c = 0x00ff & (uint16_t)*ptr;
            tmp = crc ^ short_c;
            crc = (crc >> 8) ^ crc16_table->table[tmp & 0xff];

            ptr++;
        }
    }

    return crc;
}

/* Similar to crc_16 but bits in bytes are processed msb-to-lsb (i.e. reflected).*/

uint16_t crc_16_msb(crc16_table_t *crc16_table, const uint8_t *input_str, size_t num_bytes, uint16_t crc16_poly)
{
    uint16_t             crc;
    uint16_t             tmp;
    uint16_t             short_c;
    const unsigned char *ptr;
    size_t               a;

    if (!crc16_table->table_init) {
        init_crc16_tab_msb(crc16_table, crc16_poly);
    }

    crc = CRC_START_16;
    ptr = input_str;

    if (ptr != NULL) {
        for (a = 0; a < num_bytes; a++) {
            short_c = 0x00ff & (uint16_t)*ptr;
            tmp = (crc >> 8) ^ short_c;
            crc = (crc << 8) ^ crc16_table->table[tmp & 0xff];

            ptr++;
        }
    }

    return crc;
}

uint16_t crc_msb(crc16_table_t *crc16_table,
                 const uint8_t *input_str,
                 size_t         num_bytes,
                 uint16_t       crc16_poly,
                 uint16_t       crc_length)
{
    uint16_t             crc;
    uint16_t             tmp;
    uint16_t             short_c;
    const unsigned char *ptr;
    size_t               a;
    uint16_t             msb_mask = (1 << (crc_length - 1));
    uint16_t             mask = ((msb_mask - 1) << 1) + 1;
    uint16_t             shift = (crc_length >= 8) ? 0 : (8 - crc_length);


    if (!crc16_table->table_init) {
        init_crc_tab_msb(crc16_table, crc16_poly, crc_length);
    }

    crc = CRC_START_16;
    ptr = input_str;

    if (ptr != NULL) {
        for (a = 0; a < num_bytes; a++) {
            short_c = 0x00ff & (uint16_t)*ptr;
            tmp = (crc >> (crc_length + shift - 8)) ^ short_c;
            crc = (crc << (8 - shift)) ^ (crc16_table->table[tmp & 0xff] << shift);
            crc &= mask << shift;

            ptr++;
        }
        crc >>= shift;
    }

    return crc;
}

/*
 * uint16_t update_crc_16( uint16_t crc, unsigned char c );
 *
 * The function update_crc_16() calculates a new CRC-16 value based on the
 * previous value of the CRC and the next byte of data to be checked.
 */
uint16_t update_crc_16(crc16_table_t *crc16_table, uint16_t crc, uint8_t c, uint16_t crc16_poly)
{
    uint16_t tmp;
    uint16_t short_c;

    short_c = 0x00ff & (uint16_t)c;

    if (!crc16_table->table_init) {
        init_crc16_tab(crc16_table, crc16_poly);
    }

    tmp = crc ^ short_c;
    crc = (crc >> 8) ^ crc16_table->table[tmp & 0xff];

    return crc;
}
