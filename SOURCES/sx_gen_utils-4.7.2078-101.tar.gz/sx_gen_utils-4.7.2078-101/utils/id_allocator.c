/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <unistd.h>
#include <string.h>
#include <complib/cl_mem.h>
#include "sx/utils/id_allocator.h"
#include "sx/utils/dbg_utils.h"
#include "utils/gen_utils.h"

#undef      __MODULE__
#define     __MODULE__ ID_ALLOCATOR

/************************************************
 *  Global variables
 *********************************************/
#define SX_MEM_CLR_P(src_p) (memset((src_p), 0, sizeof(*(src_p))))
/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_utils_status_t __next_free_index_get(id_allocator_t* id_allocator,
                                               uint32_t       *index);
/************************************************
 *  Function implementations
 ***********************************************/

void id_allocator_log_verbosity_level_set(sx_verbosity_level_t level)
{
    LOG_VAR_NAME(__MODULE__) = level;
}

sx_utils_status_t id_allocator_init_ext(id_allocator_params_t params, id_allocator_t* id_allocator)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    err = is_id_allocator_initialize(id_allocator);
    if (err == SX_UTILS_STATUS_SUCCESS) {
        err = SX_UTILS_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("id_allocator is already initialize. err = [%s]\n", CL_STATUS_MSG(err));
        return err;
    }
    if (err == SX_UTILS_STATUS_PARAM_NULL) {
        return err;
    }

    if ((params.grow_size == 0) || ((params.max_size > 0) && (params.grow_size > params.max_size))) {
        return SX_UTILS_STATUS_PARAM_ERROR;
    }
    if ((0xFFFFFFFF - params.start_id) <= params.max_size) {
        SX_LOG_ERR("Should be 0xFFFFFFFF <= max_size %u + start_size %u\n", params.max_size, params.start_id);
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    id_allocator->grow_size = params.grow_size;
    id_allocator->max_size = params.max_size;
    id_allocator->last_min_free_index = 0;
    id_allocator->start_id = params.start_id;
    id_allocator->step = params.step;
    err = bit_vector_allocate(params.grow_size, &(id_allocator->index_vector));
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate indexes at size %d\n", params.grow_size);
    }

    id_allocator->is_initialize = TRUE;

    return err;
}

sx_utils_status_t id_allocator_init(uint32_t        max_size,
                                    uint32_t        grow_size,
                                    uint32_t        start_id,
                                    id_allocator_t* id_allocator)
{
    id_allocator_params_t params;

    params.max_size = max_size;
    params.grow_size = grow_size;
    params.start_id = start_id;
    params.step = 1;

    return id_allocator_init_ext(params, id_allocator);
}

sx_utils_status_t id_allocator_get(id_allocator_t* id_allocator, uint32_t *id_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    err = is_id_allocator_initialize(id_allocator);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("id_allocator is not initialize, cannot get new index. err = [%s]\n", CL_STATUS_MSG(err));
        return err;
    }

    err = __next_free_index_get(id_allocator, id_p);
    if (err == SX_UTILS_STATUS_SUCCESS) {
        *id_p = (*id_p * id_allocator->step) + id_allocator->start_id;
    }
    return err;
}

sx_utils_status_t id_allocator_put(id_allocator_t* id_allocator, uint32_t id)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    err = is_id_allocator_initialize(id_allocator);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("id_allocator is not initialize, cannot return index %d. err = [%s]\n", id, CL_STATUS_MSG(err));
        return err;
    }

    if (id < id_allocator->start_id) {
        return SX_UTILS_STATUS_PARAM_ERROR;
    }
    id = (id - id_allocator->start_id) / id_allocator->step;

    if (id >= bit_vector_size(id_allocator->index_vector)) {
        SX_LOG_ERR("Trying to clear id %u in an id allocator of size %u \n", id,
                   bit_vector_size(id_allocator->index_vector));
        return SX_UTILS_STATUS_ERROR;
    }

    err = bit_vector_clear(id_allocator->index_vector, id);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear index %d\n", id);
    }

    id_allocator->last_min_free_index = id;

    return err;
}

sx_utils_status_t id_allocator_set(id_allocator_t* id_allocator, uint32_t id)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          new_size = 0;

    err = is_id_allocator_initialize(id_allocator);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("id_allocator is not initialize, cannot set index %d. err = [%s]\n", id, CL_STATUS_MSG(err));
        goto out;
    }

    if (id < id_allocator->start_id) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }
    id = (id - id_allocator->start_id) / id_allocator->step;

    /* If we don't have enough bits in the current vector we need to enlarge it */
    if (id >= bit_vector_size(id_allocator->index_vector)) {
        if ((id_allocator->max_size != 0) && (id_allocator->max_size <= id)) {
            SX_LOG_ERR("Trying to set id %u in an id allocator of size %u \n", id,
                       id_allocator->max_size);
            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }
        new_size = id + 1;
        /* Make sure that the new size is a multiply of the grow size */
        if ((new_size % id_allocator->grow_size) != 0) {
            new_size += id_allocator->grow_size;
            new_size -= new_size % id_allocator->grow_size;
            if ((id_allocator->max_size != 0) && (id_allocator->max_size < new_size)) {
                new_size = id_allocator->max_size;
            }
        }
        err = bit_vector_resize(&(id_allocator->index_vector), new_size);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to resize id_allocator to new size %d\n", new_size);
            goto out;
        }
    }
    err = bit_vector_set(id_allocator->index_vector, id);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear index %d\n", id);
        goto out;
    }

out:
    return err;
}


sx_utils_status_t id_allocator_validate_allocated_id(id_allocator_t* id_allocator, uint32_t id)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    boolean_t         value = FALSE;

    err = is_id_allocator_initialize(id_allocator);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("id_allocator is not initialize, cannot return index %d. err = [%s]\n", id, CL_STATUS_MSG(err));
        goto out;
    }

    if (id < id_allocator->start_id) {
        SX_LOG_ERR("Given id %u is out of range.\n", id);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }
    id = (id - id_allocator->start_id) / id_allocator->step;

    if (id > bit_vector_size(id_allocator->index_vector)) {
        SX_LOG_ERR("Given id %u is out of range.\n", id);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    err = bit_vector_get(id_allocator->index_vector, id, &value);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get index %d\n", id);
        goto out;
    }

    if (FALSE == value) {
        SX_LOG_ERR("Index %d was not allocated\n", id);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return err;
}

sx_utils_status_t id_allocator_destroy(id_allocator_t *id_allocator)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    err = is_id_allocator_initialize(id_allocator);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Trying to destroy not initialized id allocator\n");
        return err;
    }

    err = bit_vector_free(id_allocator->index_vector);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to free bit_vector index\n");
    }

    SX_MEM_CLR_P(id_allocator);

    id_allocator->is_initialize = FALSE;

    return err;
}

uint32_t id_allocator_in_use_count(const id_allocator_t* id_allocator)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    err = is_id_allocator_initialize(id_allocator);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("id_allocator is not initialize. err = [%s]\n", CL_STATUS_MSG(err));
        return err;
    }

    return bit_vector_count(id_allocator->index_vector);
}

uint32_t id_allocator_size(const id_allocator_t* id_allocator)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    err = is_id_allocator_initialize(id_allocator);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("id_allocator is not initialize. err = [%s]\n", CL_STATUS_MSG(err));
        return err;
    }
    return bit_vector_size(id_allocator->index_vector);
}


static sx_utils_status_t __next_free_index_get(id_allocator_t *id_allocator, uint32_t     *index)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          new_size = 0;
    uint32_t          resize_grow_size = id_allocator->grow_size;

    /* if vector is full, resize the vector to a bigger size */
    if (bit_vector_count(id_allocator->index_vector) == bit_vector_size(id_allocator->index_vector)) {
        if (id_allocator->max_size != 0) {
            if (bit_vector_count(id_allocator->index_vector) >= id_allocator->max_size) {
                SX_LOG(SX_LOG_DEBUG, "Maximum reached, max %u, allocated %u\n",
                       id_allocator->max_size,
                       bit_vector_count(id_allocator->index_vector));
                err = SX_UTILS_STATUS_NO_RESOURCES;
                goto out;
            }
            if ((id_allocator->max_size - bit_vector_count(id_allocator->index_vector)) < id_allocator->grow_size) {
                resize_grow_size = (id_allocator->max_size - bit_vector_count(id_allocator->index_vector));
            }
        }
        new_size = bit_vector_size(id_allocator->index_vector) + resize_grow_size;
        SX_LOG_DBG("Resize vector from %u to %u, maximum is %u, %u bits allocated\n",
                   bit_vector_size(id_allocator->index_vector),
                   new_size,
                   id_allocator->max_size,
                   bit_vector_count(id_allocator->index_vector));
        err = bit_vector_resize(&(id_allocator->index_vector), new_size);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to resize id_allocator to new size %d\n", new_size);
            goto out;
        }
    }
    /* start to search from the last set index ( to set index 501 we will start to search from index 500 and not from 0) */
    err = bit_vector_find_first_unset_bit(id_allocator->index_vector, id_allocator->last_min_free_index, index);
    if (err == SX_UTILS_STATUS_ENTRY_NOT_FOUND) {
        /* if the free bits are not at the last bits, start the search from the beginning. */
        id_allocator->last_min_free_index = 0;
        err = bit_vector_find_first_unset_bit(id_allocator->index_vector, id_allocator->last_min_free_index, index);
    }

    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find free index\n");
        goto out;
    }

    err = bit_vector_set(id_allocator->index_vector, *index);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set index %d \n", *index);
    }

    id_allocator->last_min_free_index = *index;

out:
    return err;
}

sx_utils_status_t is_id_allocator_initialize(const id_allocator_t* id_allocator)
{
    if (id_allocator == NULL) {
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    if (id_allocator->is_initialize == TRUE) {
        return SX_UTILS_STATUS_SUCCESS;
    }

    return SX_UTILS_STATUS_NOT_INITIALIZED;
}
