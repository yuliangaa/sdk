/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __PSORT_DB_H_INCL__
#define __PSORT_DB_H_INCL__

#include <sx/utils/sx_utils_status.h>
#include <sx/utils/sx_utils_types.h>
#include <sx/utils/psort.h>

#ifdef PSORT_DB_C_

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/

#endif

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sx_acl_dmac_type_t enumerated type is used to note
 * Destination MAC type used in ACL keys
 */
typedef enum {
    PSORT_REGION_TYPE_HOLE_E     = 0,       /**< Unicast destination MAC  */
    PSORT_REGION_TYPE_PRIORITY_E = 1,         /**< Multicast destination MAC  */
} psort_region_type_e;

typedef enum {
    TOP_HOLE_E    = 0,        /**< Top/Above Hole  */
    BOTTOM_HOLE_E = 1,        /**< Bottom Hole  */
} psort_hole_side_e;

typedef enum {
    RESIZE_DIRECITON_UP_E   = 0,         /**< Top/Above Hole  */
    RESIZE_DIRECITON_DOWN_E = 1,        /**< Bottom Hole  */
} psort_db_reize_direction_e;

typedef enum {
    PSORT_DB_DIRECITON_UP_E   = 0,         /**< Direction up  */
    PSORT_DB_DIRECITON_DOWN_E = 1,        /**< Direction down  */
} psort_db_direction_e;

typedef enum {
    MOVE_DIRECITON_UP_E   = 0,         /**< Top/Above Hole  */
    MOVE_DIRECITON_DOWN_E = 1,        /**< Bottom Hole  */
} psort_db_move_direction_e;

typedef enum {
    PSORT_TABLE_STATE_UNKNOWN_E              = 0, /**< Unknown state after modification. Need to re-evaluate */
    PSORT_TABLE_STATE_RESIZE_JUST_ENLARGED_E = 1, /**< Resizing state. Previously enlarged */
    PSORT_TABLE_STATE_RESIZE_JUST_REDUCED_E  = 2, /**< Resizing state. Previously reduced */
    PSORT_TABLE_STATE_NOT_STEADY_E           = 3, /**< Not steady, hole re-balancing in progress */
    PSORT_TABLE_STATE_STEADY_E               = 4, /**< Steady state  */
    PSORT_TABLE_STATE_MAX_E                  = PSORT_TABLE_STATE_STEADY_E,
} psort_table_state_e;

static __attribute__((__used__)) const char* psort_table_state_str[PSORT_TABLE_STATE_MAX_E + 1] = {
    "Unknown",
    "Resizing Enlarged",
    "Resizing Reduced",
    "Not steady",
    "Steady",
};

/**
 * logport table record structure
 */
typedef struct {
    cl_map_item_t map_item;
    psort_entry_t entry;
} psort_entry_item_t;

typedef struct {
    cl_pool_item_t      pool_item;
    int                 priority;
    uint32_t            size; /**< Amount of entries in this region */
    uint32_t            start; /**< Index of first entry in this region */
    uint32_t            end; /**< Index of last entry in this region */
    cl_qmap_t           empty_space; /**< Map of unused entries in this region. Key is the index */
    cl_qmap_t           used_space; /**< Map of used entries in this region. Key is the index */
    psort_region_type_e type; /**< Region type can Hole or Priority */
    cl_map_item_t       map_item; /**< Map item in the psort_db_table_db's region_map */
    cl_list_item_t     *list_item_p;
} psort_db_region_hole_t;

typedef struct {
    uint32_t  num_of_entries;
    cl_list_t free_pool;
} psort_db_entries_db_t;

typedef struct {
    cl_qpool_t                    regions_holes_pool;
    psort_db_entries_db_t         psort_db_entries_db;
    cl_qmap_t                     region_hole_map;
    cl_list_t                     table;
    uint32_t                      delta_size;
    int                           max_priority;
    int                           min_priority;
    uint32_t                      regions_holes_cnt; /**< Amount of regions and holes in the table */
    uint32_t                      regions_cnt; /**< Amount of different priority regions in the table */
    uint32_t                      holes_cnt; /**< Amount of holes in the table */
    uint32_t                      background_worker_non_complete_cnt;
    uint32_t                      table_almost_full_val_threshold;
    uint32_t                      table_almost_empty_val_threshold;
    uint32_t                      table_almost_full_precentage_threshold;
    uint32_t                      table_almost_empty_precentage_threshold;
    uint32_t                      sum_of_holes; /**< Sum of sizes of all holes. This does not include unused entries inside regions */
    uint32_t                      total_free_entries; /**< Total number of unused entries. This includes holes and unused entries inside regions */
    uint32_t                      table_size;
    void                         *cookie;
    psort_notification_func_ptr_t notif_callback;
    uint32_t                      cntr_num_of_shifts;
    psort_table_state_e           state;
    uint32_t                      refcount;
    boolean_t                     destroy_table;
} psort_db_table_db_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/*sx_utils_status_t psort_db_init(acl_db_attributes_t *db_attributes);
 *  void psort_db_deinit();*/

sx_utils_status_t psort_db_init(psort_handle_t           *handle,
                                const psort_init_param_t *params);

sx_utils_status_t psort_db_allocate_region(const psort_handle_t handle,
                                           psort_region_type_e  type,
                                           int                  priority,
                                           uint32_t             offset,
                                           uint32_t             size);
uint8_t psort_db_get_region(const psort_handle_t handle, int priority, psort_db_region_hole_t** region_p);
sx_utils_status_t psort_db_get_table(const psort_handle_t handle,
                                     psort_entry_info_t  *entries_p,
                                     uint32_t            *num_of_entries_p);
uint32_t psort_db_get_region_free_space(psort_db_region_hole_t* region_p);
uint32_t psort_db_get_region_used_space(psort_db_region_hole_t* region_p);
sx_utils_status_t psort_db_add_entry(const psort_handle_t handle, psort_entry_t *entry_p);
sx_utils_status_t psort_db_prio_change(const psort_handle_t handle,
                                       const int            min_prio,
                                       const int            max_prio,
                                       const int            prio_change);
uint32_t psort_db_get_table_actual_free_space(const psort_handle_t handle);

uint32_t psort_db_get_table_size(const psort_handle_t handle);

sx_utils_status_t psort_db_expand_region(const psort_handle_t    handle,
                                         psort_db_region_hole_t* region_p,
                                         psort_hole_side_e       hole_side,
                                         uint32_t                size);
uint32_t psort_db_get_hole_free_space(const psort_handle_t    handle,
                                      psort_db_region_hole_t* region_p,
                                      psort_hole_side_e       hole_side);
sx_utils_status_t psort_db_insert_entry_to_region(const psort_handle_t    handle,
                                                  psort_db_region_hole_t* region_p,
                                                  psort_entry_t         * entry_p);
sx_utils_status_t psort_db_remove_entry_from_region(const psort_handle_t    handle,
                                                    psort_db_region_hole_t* region_p,
                                                    psort_entry_t         * entry_p);
sx_utils_status_t psort_db_get_table_optimal_hole_size(const psort_handle_t handle,
                                                       uint32_t            *optimal_hole_size_div_part,
                                                       uint32_t           * optimal_hole_size_mod_part);
sx_utils_status_t psort_db_get_new_region_space(const psort_handle_t     handle,
                                                uint32_t               * new_hole_size,
                                                psort_db_region_hole_t **hole_p,
                                                psort_db_region_hole_t **closet_region_p,
                                                int                      priority);
sx_utils_status_t psort_db_split_hole_and_allocate_region(const psort_handle_t    handle,
                                                          psort_db_region_hole_t *hole_p,
                                                          psort_region_type_e     type,
                                                          int                     priority,
                                                          uint32_t                hole_above_size,
                                                          uint32_t                hole_below_size);
sx_utils_status_t psort_db_validate_priority(const psort_handle_t handle, int priority);
sx_utils_status_t psort_db_validate_index_exist(psort_db_region_hole_t* region_p, psort_entry_t*  entry_p);

sx_utils_status_t psort_db_move_regions_for_insertion(const psort_handle_t      handle,
                                                      psort_db_region_hole_t  * region_p,
                                                      boolean_t                 isMoveForAllocate,
                                                      psort_db_move_direction_e dir);
sx_utils_status_t psort_db_resize_regions_for_insertion(const psort_handle_t      handle,
                                                        psort_db_region_hole_t  * region_p,
                                                        psort_db_move_direction_e dir);
sx_utils_status_t psort_db_resize_region(const psort_handle_t    handle,
                                         psort_db_region_hole_t* region_p,
                                         uint32_t                resize_size,
                                         psort_hole_side_e       hole_side,
                                         boolean_t               is_background,
                                         uint32_t               *shift_count_p);

uint32_t psort_db_get_table_almost_full_threshold_num(const psort_handle_t handle);
uint32_t psort_db_get_table_almost_empty_threshold_num(const psort_handle_t handle);

sx_utils_status_t psort_db_notify_almost_full_event(const psort_handle_t handle, uint32_t* shift_count_p);
sx_utils_status_t psort_db_notify_almost_empty_event(const psort_handle_t handle, uint32_t* shift_count_p);

/* shiftregion to top or bottom hole */
sx_utils_status_t psort_db_shift_region(const psort_handle_t    handle,
                                        psort_db_region_hole_t* region_p,
                                        uint32_t                shift_block_size,
                                        psort_hole_side_e       hole_side,
                                        uint32_t               *shift_count_p);

sx_utils_status_t psort_db_increase_table_size(const psort_handle_t handle, uint32_t new_size);
sx_utils_status_t psort_db_clear_table(const psort_handle_t handle);

sx_utils_status_t psort_db_decrease_table_size(const psort_handle_t handle,
                                               uint32_t             new_size,
                                               boolean_t            is_background,
                                               uint32_t           * shift_count_p);

sx_utils_status_t psort_db_get_table_total_regions_size(const psort_handle_t handle, uint32_t  *total_regions_size_p);
sx_utils_status_t psort_db_is_single_priority(const psort_handle_t handle, boolean_t* is_single_priority);
sx_utils_status_t psort_db_defrag_single_priority(const psort_handle_t handle,
                                                  boolean_t            is_background,
                                                  uint32_t            *shift_count_p);
void psort_db_take_ref(psort_handle_t handle);
sx_utils_status_t psort_db_release_ref(psort_handle_t handle, boolean_t allow_destroy);
boolean_t psort_db_is_deleted(psort_handle_t handle);

#endif /* ifndef __PSORT_DB_H_INCL__ */
