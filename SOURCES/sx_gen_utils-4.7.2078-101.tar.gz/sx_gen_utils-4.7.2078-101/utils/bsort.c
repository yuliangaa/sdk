/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#include <complib/sx_log.h>
#include <complib/cl_types.h>
#include <complib/cl_list.h>
#include <complib/cl_qmap.h>
#include <complib/cl_mem.h>

#include <sx/utils/bsort.h>
#include "utils/gen_utils.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>

#undef  __MODULE__
#define __MODULE__ BSORT

#define SX_MEM_CLR(src)     (memset(&(src), 0, sizeof(src)))
#define SX_MEM_CLR_P(src_p) (memset((src_p), 0, sizeof(*(src_p))))
#define INVALID_INDEX 0xFFFFFFFF

sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

sx_utils_status_t bsort_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

static sx_utils_status_t __bsort_extend_table(bsort_db_table_db_t *bsort_db)
{
    sx_utils_status_t          rc = SX_UTILS_STATUS_SUCCESS;
    bsort_callback_param_t     callback_param;
    bsort_move_param_t         move_param;
    bsort_resize_table_param_t resize_param;
    uint32_t                   move_size;
    uint32_t                   low_part_size;
    boolean_t                  rb_resize_flag = FALSE;

    SX_LOG(SX_LOG_DEBUG, "table_size=%u\n", bsort_db->current_table_size);

    SX_MEM_CLR(callback_param);
    SX_MEM_CLR(move_param);
    SX_MEM_CLR(resize_param);

    low_part_size = bsort_db->current_table_size - bsort_db->low_priority_index;

    if (low_part_size > 0) {
        move_size = (low_part_size > bsort_db->resize_threshold) ? bsort_db->resize_threshold : low_part_size;
        move_param.old_index = bsort_db->low_priority_index;
        move_param.new_index = bsort_db->resize_threshold + bsort_db->current_table_size - move_size;
        move_param.block_size = move_size;
    }

    bsort_db->low_priority_index += bsort_db->resize_threshold;
    bsort_db->next_low_priority_index = bsort_db->low_priority_index - 1;

    resize_param.old_size = bsort_db->current_table_size;
    bsort_db->current_table_size += bsort_db->resize_threshold;
    resize_param.new_size = bsort_db->current_table_size;

    rb_resize_flag = TRUE;
    callback_param.resize_param = resize_param;
    rc = bsort_db->notif_callback(BSORT_RESIZE_TABLE_E, &callback_param, bsort_db->context);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        if (rc == SX_UTILS_STATUS_NO_RESOURCES) {
            SX_LOG(SX_LOG_NOTICE, "Failed to enlarge table to %u\n", bsort_db->current_table_size);
        } else {
            SX_LOG(SX_LOG_ERROR, "Failed to enlarge table to %u\n", bsort_db->current_table_size);
        }
        goto out;
    }

    if (move_param.block_size > 0) {
        SX_MEM_CLR(callback_param);
        callback_param.move_param = move_param;
        rc = bsort_db->notif_callback(BSORT_MOVE_ENTRY_E, &callback_param, bsort_db->context);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to move entries\n");
            goto out;
        }
    }

    SX_LOG(SX_LOG_DEBUG, "new table_size=%u\n", bsort_db->current_table_size);

out:
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        if (rb_resize_flag == TRUE) {
            bsort_db->low_priority_index -= bsort_db->resize_threshold;
            bsort_db->next_low_priority_index = bsort_db->low_priority_index - 1;
            bsort_db->current_table_size -= bsort_db->resize_threshold;
        }
    }
    return rc;
}

static sx_utils_status_t __bsort_reduce_table(bsort_db_table_db_t *bsort_db)
{
    sx_utils_status_t          rc = SX_UTILS_STATUS_SUCCESS;
    bsort_callback_param_t     callback_param;
    bsort_move_param_t         move_param;
    bsort_resize_table_param_t resize_param;
    uint32_t                   move_size;
    uint32_t                   low_part_size;

    SX_LOG(SX_LOG_DEBUG, "table_size=%u, empty slots number=%u\n",
           bsort_db->current_table_size, bsort_db->low_priority_index - bsort_db->next_high_priority_index);

    SX_MEM_CLR(callback_param);
    SX_MEM_CLR(move_param);
    SX_MEM_CLR(resize_param);

    low_part_size = bsort_db->current_table_size - bsort_db->low_priority_index;
    if (low_part_size > 0) {
        /* move low priority part if there is low priority entries */
        move_size = (low_part_size > bsort_db->resize_threshold) ? bsort_db->resize_threshold : low_part_size;
        move_param.old_index = bsort_db->current_table_size - move_size;
        move_param.new_index = bsort_db->low_priority_index - bsort_db->resize_threshold;
        move_param.block_size = move_size;
    }

    bsort_db->low_priority_index -= bsort_db->resize_threshold;
    bsort_db->next_low_priority_index = bsort_db->low_priority_index - 1;

    resize_param.old_size = bsort_db->current_table_size;
    bsort_db->current_table_size -= bsort_db->resize_threshold;
    resize_param.new_size = bsort_db->current_table_size;

    if (move_param.block_size > 0) {
        callback_param.move_param = move_param;
        rc = bsort_db->notif_callback(BSORT_MOVE_ENTRY_E, &callback_param, bsort_db->context);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to move entries\n");
            goto out;
        }
    }
    callback_param.resize_param = resize_param;
    bsort_db->notif_callback(BSORT_RESIZE_TABLE_E, &callback_param, bsort_db->context);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to reduce table to %u\n", bsort_db->current_table_size);
        goto out;
    }

out:
    return rc;
}

sx_utils_status_t bsort_init(const bsort_init_param_t *param, bsort_handle_t *handle)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    bsort_db_table_db_t *bsort_db = NULL;

    if (handle == NULL) {
        SX_LOG(SX_LOG_ERROR, "bsort handle is NULL.\n");
        rc = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (param == NULL) {
        SX_LOG(SX_LOG_ERROR, "init param is NULL.\n");
        rc = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    bsort_db = cl_malloc(sizeof(bsort_db_table_db_t));

    if (bsort_db == NULL) {
        rc = SX_UTILS_STATUS_NO_MEMORY;
        goto out;
    }

    SX_MEM_CLR_P(bsort_db);

    bsort_db->context = param->context;
    bsort_db->reduce_threshold = param->reduce_threshold;
    bsort_db->high_priority_index = INVALID_INDEX;
    bsort_db->next_high_priority_index = 0;
    bsort_db->low_priority_index = param->initial_table_size;
    bsort_db->next_low_priority_index = param->initial_table_size - 1;
    bsort_db->notif_callback = param->notif_callback;
    bsort_db->current_table_size = param->initial_table_size;
    bsort_db->resize_threshold = param->resize_threshold;

    *handle = (bsort_handle_t)bsort_db;

out:
    return rc;
}

sx_utils_status_t bsort_deinit(const bsort_handle_t handle)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    bsort_db_table_db_t *bsort_db = (bsort_db_table_db_t*)handle;

    if (bsort_db == NULL) {
        SX_LOG(SX_LOG_ERROR, "bsort handle is NULL.\n");
        rc = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    cl_free(bsort_db);

out:
    return rc;
}

sx_utils_status_t bsort_add_entry(const bsort_handle_t handle, bsort_entry_param_t* param)
{
    sx_utils_status_t      rc = SX_UTILS_STATUS_SUCCESS;
    bsort_callback_param_t callback_param;
    bsort_db_table_db_t   *bsort_db = (bsort_db_table_db_t*)handle;

    SX_MEM_CLR(callback_param);

    if (bsort_db == NULL) {
        SX_LOG(SX_LOG_ERROR, "bsort handle is NULL.\n");
        rc = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (param == NULL) {
        SX_LOG(SX_LOG_ERROR, "init param is NULL.\n");
        rc = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG(SX_LOG_DEBUG, "priority=%u\n", param->priority);

    /* The table is full */
    if (bsort_db->next_high_priority_index == bsort_db->low_priority_index) {
        rc = __bsort_extend_table(bsort_db);
        if (SX_UTILS_STATUS_SUCCESS != rc) {
            if (rc == SX_UTILS_STATUS_NO_RESOURCES) {
                SX_LOG(SX_LOG_NOTICE, "Failed to enlarge table to %u\n", bsort_db->current_table_size);
            } else {
                SX_LOG(SX_LOG_ERROR, "Failed to enlarge table to %u\n", bsort_db->current_table_size);
            }
            goto out;
        }
    }

    switch (param->priority) {
    case BSORT_HIGH_PRIORITY:
        callback_param.add_param.index = bsort_db->next_high_priority_index;
        bsort_db->high_priority_index = bsort_db->next_high_priority_index;
        bsort_db->next_high_priority_index++;
        break;

    case BSORT_LOW_PRIORITY:
        callback_param.add_param.index = bsort_db->next_low_priority_index;
        bsort_db->low_priority_index = bsort_db->next_low_priority_index;
        /* In case the new low priority index is 0, have to set teh new next_low_priority_index to invalid */
        bsort_db->next_low_priority_index = (bsort_db->low_priority_index) ?
                                            (bsort_db->low_priority_index - 1) : INVALID_INDEX;
        break;
    }

    CL_ASSERT(callback_param.add_param.index != INVALID_INDEX);

    SX_LOG(SX_LOG_DEBUG, "index=%u\n", callback_param.add_param.index);
    rc = bsort_db->notif_callback(BSORT_ADD_ENTRY_E, &callback_param, bsort_db->context);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to add entry to %u\n", callback_param.add_param.index);
        goto out;
    }

    param->index = callback_param.add_param.index;

out:
    return rc;
}

sx_utils_status_t bsort_delete_entry(const bsort_handle_t handle, const bsort_entry_param_t *param)
{
    sx_utils_status_t         rc = SX_UTILS_STATUS_SUCCESS;
    uint16_t                  empty_slots_count;
    bsort_callback_param_t    callback_param;
    bsort_notification_type_e notify_type;
    bsort_db_table_db_t     * bsort_db = (bsort_db_table_db_t*)handle;

    SX_MEM_CLR(callback_param);

    if (bsort_db == NULL) {
        SX_LOG(SX_LOG_ERROR, "bsort handle is NULL.\n");
        rc = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (param == NULL) {
        SX_LOG(SX_LOG_ERROR, "init param is NULL.\n");
        rc = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG(SX_LOG_DEBUG, "index=%u\n", param->index);

    if (param->index >= bsort_db->current_table_size) {
        rc = SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if ((param->index != bsort_db->high_priority_index) &&
        (param->index != bsort_db->low_priority_index)) {
        /* The index is inside high or low priority part */
        callback_param.move_param.block_size = 1;
        callback_param.move_param.new_index = param->index;

        if (param->index < bsort_db->next_high_priority_index) {
            callback_param.move_param.old_index = bsort_db->high_priority_index;
            bsort_db->high_priority_index--;
            bsort_db->next_high_priority_index--;
        } else {
            callback_param.move_param.old_index = bsort_db->low_priority_index;
            bsort_db->low_priority_index++;
            bsort_db->next_low_priority_index++;
        }

        notify_type = BSORT_MOVE_ENTRY_E;
    } else {
        /* The index is high_priority_index or low_priority_index */
        callback_param.delete_param.index = param->index;

        if (param->index == bsort_db->high_priority_index) {
            bsort_db->next_high_priority_index = bsort_db->high_priority_index;
            /* In case current high_priority_index is 0, have to set the new high_priority_index to invalid  */
            bsort_db->high_priority_index = (bsort_db->high_priority_index) ?
                                            (bsort_db->high_priority_index - 1) : INVALID_INDEX;
        } else {
            bsort_db->next_low_priority_index = bsort_db->low_priority_index;
            bsort_db->low_priority_index++;
        }

        notify_type = BSORT_DELETE_ENTRY_E;
    }

    rc = bsort_db->notif_callback(notify_type, &callback_param, bsort_db->context);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to manipulate entry, notify_type = %u.\n", notify_type);
        goto out;
    }

    empty_slots_count = bsort_db->low_priority_index - bsort_db->next_high_priority_index;

    if (empty_slots_count >= bsort_db->reduce_threshold) {
        rc = __bsort_reduce_table(bsort_db);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to reduce table\n");
            goto out;
        }
    }

out:
    return rc;
}

sx_utils_status_t bsort_debug_dump(const bsort_handle_t handle, FILE* stream)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    bsort_db_table_db_t *bsort_db = (bsort_db_table_db_t*)handle;

    SX_LOG_ENTER();

    if (NULL == stream) {
        SX_LOG_ERR("stream is NULL\n");
        rc = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (bsort_db == NULL) {
        SX_LOG(SX_LOG_ERROR, "bsort handle is NULL.\n");
        rc = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    dbg_utils_pprinter_field_print(stream, "high_priority_index", &(bsort_db->high_priority_index), PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "low_priority_index", &(bsort_db->low_priority_index), PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "next_high_priority_index",
                                   &(bsort_db->next_high_priority_index),
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "next_low_priority_index",
                                   &(bsort_db->next_low_priority_index),
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "current_table_size", &(bsort_db->current_table_size), PARAM_UINT32_E);

out:
    return rc;
}
