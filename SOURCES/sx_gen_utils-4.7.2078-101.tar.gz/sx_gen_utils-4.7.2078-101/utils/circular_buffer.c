/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#include <unistd.h>
#include "complib/cl_mem.h"
#include "complib/sx_log.h"
#include "complib/cl_circular_buffer.h"
#include "sx/utils/circular_buffer.h"
#include "sx/utils/dbg_utils.h"
#include "utils/gen_utils.h"


#undef      __MODULE__
#define     __MODULE__ CIRCULAR_BUFFER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 *
 *  NOTE:
 *  Current implementation wrap cl_cyclic_buffer logic in order to add log capability to cyclic buffer
 *  SDK log module uses cl_cyclic_buffer therefore we can't do that at that layer.
 ***********************************************/

void circ_buff_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    SX_LOG_EXIT();
}

sx_utils_status_t circ_buff_allocate(uint32_t obj_size, uint32_t max_num_entries, sx_circ_buff_t *buff_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = cl_circ_buff_allocate(obj_size, max_num_entries, buff_p);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate buffer. object_size = %d, max_num_entries = %d\n", obj_size, max_num_entries);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t circ_buff_free(sx_circ_buff_t buffer, boolean_t force)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    err = cl_circ_buff_free(buffer, force);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to free buffer.\n");
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_utils_status_t circ_buff_reset(sx_circ_buff_t buffer)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    err = cl_circ_buff_reset(buffer);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to reset buffer.\n");
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t circ_buff_write(sx_circ_buff_t buffer, void *new_entry_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = cl_buff_write(buffer, new_entry_p);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write entry to buffer.\n");
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t circ_buff_read(sx_circ_buff_t buffer, void *entry_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    err = cl_circ_buff_read(buffer, entry_p);

    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to read entry from buffer.\n");
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t circ_buff_peek(sx_circ_buff_t buffer, void *entry_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    err = cl_circ_buff_peek(buffer, entry_p);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to peak entry from buffer.\n");
    }


out:
    SX_LOG_EXIT();
    return err;
}
