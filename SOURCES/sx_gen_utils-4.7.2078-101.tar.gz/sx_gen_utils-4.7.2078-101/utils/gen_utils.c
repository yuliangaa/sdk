/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#include <unistd.h>
#include <complib/cl_mem.h>
#include "complib/cl_timer.h"
#include "gen_utils.h"

#undef      __MODULE__
#define     __MODULE__ GEN_UTILS

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
cl_spinlock_t gen_utils_mem_type_count_lock = CL_SPINLOCK_INITIALIZER;


/************************************************
 *  MEMORY
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/
static uint32_t    mem_type_count[GEN_UTILS_MEM_TYPE_ID_MAX_E + 1] = { 0 };
static const char* mem_type_name[GEN_UTILS_MEM_TYPE_ID_MAX_E + 1] = {
    /* GEN_UTILS_MEM_TYPE_ID_ALL_E = 0,	*/
    "ALL",
    /* GEN_UTILS_MEM_TYPE_ID_PSORT = 1,	*/
    "PSORT",
    /* GEN_UTILS_MEM_TYPE_ID_LINEAR_MANAGER_E = 2, */
    "LINEAR_MANAGER",
    /* GEN_UTILS_MEM_TYPE_ID_BIN = 3,	*/
    "BIN",
    /* GEN_UTILS_MEM_TYPE_ID_BIT_VECTOR_E = 4 */
    "BIT_VECTOR",
};

/************************************************
 *  Function implementations
 ***********************************************/

sx_utils_status_t gen_utils_log_verbosity_level(IN sx_utils_command_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_UTILS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SX_UTILS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SX_UTILS_CMD_STR(cmd));
        err = SX_UTILS_STATUS_CMD_UNSUPPORTED;
    }

    SX_LOG_EXIT();
    return err;
}

/**
 * This function allocate memory
 *
 * @param[out] buf_p        - pointer to a buffer pointer
 * @param[in]  buf_size     - size of memory to allocate (in bytes)
 * @param[in]  mem_type_id  - memory type id - ascribe memory allocation for this memory type
 */
sx_utils_status_t gen_utils_memory_get(void **buf_p, uint32_t buf_size, gen_utils_mem_type_id_e mem_type_id)
{
    sx_utils_status_t rc = SX_UTILS_STATUS_SUCCESS;

#ifdef      __DEBUG_GEN_UTILS__
    SX_LOG_ENTER();
#endif  /*	__DEBUG_GEN_UTILS__	*/

    if (!M_GEN_UTILS_MEM_TYPE_ID_CHECK_RANGE(mem_type_id)) {
        return M_GEN_UTILS_SX_LOG_EXIT(SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE);
    }
    /* O/W: */
    if (SX_UTILS_CHECK_FAIL(rc = gen_utils_check_pointer(buf_p, "Buffer pointer"))) {
        return M_GEN_UTILS_SX_LOG_EXIT(SX_UTILS_STATUS_PARAM_NULL);
    }
    /* O/W: */
    if (NULL == (*buf_p = cl_malloc(sizeof(uint32_t) + buf_size))) {
        return M_GEN_UTILS_SX_LOG_EXIT(SX_UTILS_STATUS_NO_MEMORY);
    }
    /* O/W: */
    /* Save buffer size in the head */
    (*((uint32_t*)(*buf_p))) = buf_size;

    cl_spinlock_acquire(&gen_utils_mem_type_count_lock);
    /*update mem_type_count array*/
    mem_type_count[mem_type_id] += (buf_size);
    mem_type_count[GEN_UTILS_MEM_TYPE_ID_ALL_E] += (buf_size);
    cl_spinlock_release(&gen_utils_mem_type_count_lock);

    /*update buffer to point after the buffer size */
    (*(uint8_t**)buf_p) += sizeof(uint32_t);

    SX_LOG_DBG("Allocated %u bytes for memory type %s; Total memory for this type = %u;\n",
               buf_size, mem_type_name[mem_type_id], mem_type_count[mem_type_id]);

#ifdef      __DEBUG_GEN_UTILS__
    SX_LOG_EXIT();
#endif  /*	__DEBUG_GEN_UTILS__	*/

    return rc;
}

/**
 * This function allocate memory and zero allocated memory items.
 *
 * @param[out] buf_p        - allocate memory into this buffer
 * @param[in]  items_number - number of items to allocate
 * @param[in]  item_size    - item size in bytes
 * @param[in]  mem_type_id  - memory type id - ascribe memory allocation for this memory type
 *
 * @return sx_status
 */
sx_utils_status_t gen_utils_clr_memory_get(void                 ** buf_p,
                                           uint32_t                items_number,
                                           uint32_t                item_size,
                                           gen_utils_mem_type_id_e mem_type_id)
{
    sx_utils_status_t rc = SX_UTILS_STATUS_SUCCESS;
    uint32_t          buf_size = items_number * item_size;

#ifdef      __DEBUG_GEN_UTILS__
    SX_LOG_ENTER();
#endif  /*	__DEBUG_GEN_UTILS__	*/

    if (SX_UTILS_CHECK_FAIL(rc = gen_utils_memory_get(buf_p, buf_size, mem_type_id))) {
        return M_GEN_UTILS_SX_LOG_EXIT(rc);
    }
    /* O/W: */
    /* Zero the entire buffer */
    memset(*buf_p, 0, buf_size);

#ifdef      __DEBUG_GEN_UTILS__
    SX_LOG_EXIT();
#endif  /*	__DEBUG_GEN_UTILS__	*/

    return rc;
}

/**
 * This function free memory using free.
 *
 * @param[in]  buf_p          - buffer to free
 * @param[in]  mem_type_id    - memory type id - ascribe memory deallocation for this memory type
 */
sx_utils_status_t gen_utils_memory_put(void *buf_p, gen_utils_mem_type_id_e mem_type_id)
{
    sx_utils_status_t rc = SX_UTILS_STATUS_SUCCESS;
    void             *block_start = NULL;
    uint32_t          buf_size = 0;

#ifdef      __DEBUG_GEN_UTILS__
    SX_LOG_ENTER();
#endif  /*	__DEBUG_GEN_UTILS__	*/

    if (!M_GEN_UTILS_MEM_TYPE_ID_CHECK_RANGE(mem_type_id)) {
        return M_GEN_UTILS_SX_LOG_EXIT(SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE);
    }
    /* O/W: */
    if (SX_UTILS_CHECK_FAIL(rc = gen_utils_check_pointer(buf_p, "Buffer pointer"))) {
        return M_GEN_UTILS_SX_LOG_EXIT(SX_UTILS_STATUS_PARAM_NULL);
    }
    /* O/W: */
    /* point to the buffer's header		*/
    block_start = ((uint8_t*)buf_p) - sizeof(uint32_t);

    /*update mem_type_count array*/
    memcpy(&buf_size, block_start, sizeof(uint32_t));

    if (buf_size > mem_type_count[mem_type_id]) {
        SX_LOG_ERR("Block size exceeds total size for memory type %s\n", mem_type_name[mem_type_id]);
        return M_GEN_UTILS_SX_LOG_EXIT(SX_UTILS_STATUS_MEMORY_ERROR);
    }
    /* O/W: */
    cl_spinlock_acquire(&gen_utils_mem_type_count_lock);
    mem_type_count[mem_type_id] -= buf_size;
    mem_type_count[GEN_UTILS_MEM_TYPE_ID_ALL_E] -= (buf_size);
    cl_spinlock_release(&gen_utils_mem_type_count_lock);

    cl_free(block_start);

    SX_LOG_DBG("Freed %u bytes for memory type %s; Total memory for this type = %u;\n",
               buf_size, mem_type_name[mem_type_id], mem_type_count[mem_type_id]);

#ifdef      __DEBUG_GEN_UTILS__
    SX_LOG_EXIT();
#endif  /*	__DEBUG_GEN_UTILS__	*/

    return rc;
}

sx_utils_status_t gen_utils_sx_log_exit(sx_utils_status_t rc, const char *func_name)
{
    SX_LOG_FUNC_WRAP(func_name, "%s: ]\n");
    return rc;
}

/************************************************
 *  VALIDATION
 ***********************************************/

/**
 *  This function checks if the given pointer isn't NULL.
 *
 * @param[in] ptr - Generic pointer
 * @param[in] description - Description of what "stands behind" the pointer
 *
 * @return sx_utils_status_t
 */
sx_utils_status_t gen_utils_check_pointer(IN const void *ptr, IN const char *description)
{
#ifdef          __DEBUG_GEN_UTILS__
    SX_LOG_ENTER();
#endif  /*      __DEBUG_GEN_UTILS__ */

    if (NULL == ptr) {
        if (NULL == description) {
            description = "no pointer description";
        }
        SX_LOG_ERR("NULL Pointer (%s)\n", description);
        return M_GEN_UTILS_SX_LOG_EXIT(SX_UTILS_STATUS_PARAM_NULL);
    }
    /* O/W: */
#ifdef          __DEBUG_GEN_UTILS__
    SX_LOG_EXIT();
#endif  /*      __DEBUG_GEN_UTILS__ */

    return SX_UTILS_STATUS_SUCCESS;
}


unsigned int gen_utils_bits(uint64_t n)
{
    n = (n & 0x5555555555555555LL) + ((n >> 1) & 0x5555555555555555LL);
    n = (n & 0x3333333333333333LL) + ((n >> 2) & 0x3333333333333333LL);
    n = (n & 0x0F0F0F0F0F0F0F0FLL) + ((n >> 4) & 0x0F0F0F0F0F0F0F0FLL);
    n = (n & 0x00FF00FF00FF00FFLL) + ((n >> 8) & 0x00FF00FF00FF00FFLL);
    n = (n & 0x0000FFFF0000FFFFLL) + ((n >> 16) & 0x0000FFFF0000FFFFLL);
    n = (n & 0x00000000FFFFFFFFLL) + (n >> 32);

    return (unsigned int)n;
}

sx_utils_status_t gen_utils_timed_poll(uint32_t              polling_interval,
                                       uint32_t              timeout,
                                       gen_utils_polling_pfn polling_cb,
                                       void                 *context)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    struct timeval    timeout_tv;
    uint64_t          curr_ts = 0;
    uint64_t          end_ts = 0;

    SX_LOG_ENTER();

    M_GEN_UTILS_MEM_CLR(timeout_tv);

    if (polling_cb == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("polling_cb is NULL\n");
        goto out;
    }

    if (polling_interval == 0) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Polling interval must be larger than 0\n");
        goto out;
    }

    if (timeout <= polling_interval) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Timeout [%u] must be larger than than polling interval [%u]\n",
                   timeout, polling_interval);
        goto out;
    }

    timeout_tv.tv_sec = polling_interval / 1000000;
    timeout_tv.tv_usec = (polling_interval % 1000000);
    curr_ts = cl_get_time_stamp();
    end_ts = curr_ts + timeout;

    err = polling_cb(context);
    if (SX_UTILS_CHECK_FAIL(err)) {
        if (err == SX_UTILS_STATUS_PARTIALLY_COMPLETE) {
            curr_ts = cl_get_time_stamp();
            while (curr_ts <= end_ts) {
                if ((curr_ts + polling_interval) > end_ts) {
                    err = SX_UTILS_STATUS_ERROR;
                    SX_LOG_ERR("Polling timer ([%u] us) expired\n", timeout);
                    goto out;
                }

                select(0, NULL, NULL, NULL, &timeout_tv);
                err = polling_cb(context);
                if (SX_UTILS_CHECK_FAIL(err)) {
                    if (err == SX_UTILS_STATUS_PARTIALLY_COMPLETE) {
                        err = SX_UTILS_STATUS_SUCCESS;
                        curr_ts = cl_get_time_stamp();
                        continue;
                    } else {
                        SX_LOG_ERR("Polling callback failed, err = [%s]\n", SX_UTILS_STATUS_MSG(err));
                        goto out;
                    }
                }
                break;
            }

            if (curr_ts > end_ts) {
                err = SX_UTILS_STATUS_ERROR;
                SX_LOG_ERR("Polling timer ([%u] us) expired\n", timeout);
                goto out;
            }
        } else {
            SX_LOG_ERR("Polling callback failed, err = [%s]\n", SX_UTILS_STATUS_MSG(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}
