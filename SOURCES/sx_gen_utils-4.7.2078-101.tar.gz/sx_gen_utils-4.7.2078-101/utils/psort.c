/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <complib/cl_types.h>
#include <complib/cl_list.h>
#include <complib/cl_qmap.h>
#include <complib/cl_mem.h>

#include <sx/utils/psort.h>
#include "utils/gen_utils.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "psort_db.h"

#undef  __MODULE__
#define __MODULE__ PSORT


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

typedef enum {
    PSORT_LOOKUP_DIRECITON_UP_E   = 0,         /**< search direction up */
    PSORT_LOOKUP_DIRECITON_DOWN_E = 1,        /**< search direction down  */
} psort_lookup_direction_e;


/************************************************
 *  Local Defines
 ***********************************************/

#define PSORT_BACKGROUND_MOVE_SIZE    1
#define PSORT_REGION_FULL_SIZE_CHECK  0
#define POSRT_DECREASE_SIZE_THRESHOLD 1.5
#define POSRT_HOLE_MIN_SIZE_FACTOR    3

/************************************************
 *  Local variables
 ***********************************************/

sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

sx_utils_status_t __psort_get_background_worker_state(const psort_handle_t handle, psort_table_state_e* table_state_p);
static sx_utils_status_t __psort_regions_size_check_and_resize(const psort_handle_t handle, uint32_t* shift_count_p);
static sx_utils_status_t __psort_optimal_hole_size_check(const psort_handle_t handle, boolean_t *is_complete);
static sx_utils_status_t __psort_thresholds_check(const psort_handle_t handle,
                                                  uint32_t           * shift_count_p,
                                                  boolean_t          * resized);
sx_utils_status_t __psort_optimal_hole_size_find_region_to_shift(psort_lookup_direction_e direction,
                                                                 psort_db_table_db_t     *psort_db_table_db_p,
                                                                 psort_db_region_hole_t * hole_p,
                                                                 boolean_t              * can_shift_region_p,
                                                                 psort_db_region_hole_t** region_to_shift_p_p);

/************************************************
 *  Function implementations
 ***********************************************/

sx_utils_status_t psort_init(psort_handle_t *handle, const psort_init_param_t *params)
{
    sx_utils_status_t rc;
    uint32_t          offset = 0;
    uint32_t          size = 0;

    SX_LOG(SX_LOG_DEBUG,
           "psort_init table_size [%d] delta_size [%d] max_priority [%d] min_priority [%d] table_almost_full_precentage_threshold [%d] table_almost_empty_precentage_threshold [%d]\n",
           params->table_size,
           params->delta_size,
           params->max_priority,
           params->min_priority,
           params->table_almost_full_precentage_threshold,
           params->table_almost_empty_precentage_threshold);


    if (params->table_size < 1) {
        /* validation error */
        SX_LOG_ERR("Error pSort table size [%d] is too small\n",
                   params->table_size);
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    rc = psort_db_init(handle, params);
    SX_UTILS_CHECK_RC(rc, "pSort Init");

    offset = 0;
    /* Add initial region with maximum priority at the top of the table */
    if (params->table_size >= params->delta_size) {
        size = params->delta_size;
        rc = psort_db_allocate_region(*handle, PSORT_REGION_TYPE_PRIORITY_E, params->max_priority, offset, size);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Allocate pSort region priority [%d] offset [%d]\n", params->max_priority, offset);
            return rc;
        }
        offset += size;

        if (params->max_priority != params->min_priority) {
            /* Add hole between maximum-region and minimum-region */
            if (params->table_size > 2 * (params->delta_size)) {
                size = params->table_size - 2 * (params->delta_size);
                rc = psort_db_allocate_region(*handle, PSORT_REGION_TYPE_HOLE_E, 0, offset, size);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Allocate pSort Hole offset [%d]\n", offset);
                    return rc;
                }
                offset += size;
            }

            /* Add initial region with minimum priority at the bottom of the table */
            if (params->table_size >= 2 * (params->delta_size)) {
                size = params->delta_size;
                rc =
                    psort_db_allocate_region(*handle, PSORT_REGION_TYPE_PRIORITY_E, params->min_priority, offset,
                                             size);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Allocate pSort region priority [%d] offset [%d]\n", params->min_priority, offset);
                    return rc;
                }
                offset += size;
            }
        }
    }

    /* Add hole at bottom of table, if we didn't create a minimum-region */
    if (offset < params->table_size) {
        size = params->table_size - offset;
        rc = psort_db_allocate_region(*handle, PSORT_REGION_TYPE_HOLE_E, 0, offset, size);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Allocate pSort Hole offset [%d]\n", offset);
            return rc;
        }
        offset += size;
    }

    return SX_UTILS_STATUS_SUCCESS;
}


static cl_list_t psort_background_registration_list;
static boolean_t is_psort_background_registration_list_init = FALSE;
static uint32_t  psort_clients = 0;
sx_utils_status_t psort_background_register(const psort_handle_t handle, sx_utils_command_t cmd)
{
    cl_status_t        status;
    cl_list_iterator_t itor;
    cl_list_iterator_t list_end;
    boolean_t          found = FALSE;

    switch (cmd) {
    case SX_UTILS_CMD_ADD:
        /* add handle to list */
        if (FALSE == is_psort_background_registration_list_init) {
            status = cl_list_init(&psort_background_registration_list,  MAX_PSORT_CLIENTS);
            if (status != CL_SUCCESS) {
                return SX_UTILS_STATUS_ERROR;
            }
            is_psort_background_registration_list_init = TRUE;
        }
        /* is entry exist ? */
        itor = cl_list_head(&psort_background_registration_list);
        list_end = cl_list_end(&psort_background_registration_list);
        while (itor != list_end) {
            psort_handle_t item = (psort_handle_t)(uintptr_t)(cl_list_obj(itor));
            if (item == handle) {
                found = TRUE;
                break;
            }

            itor = cl_list_next(itor);
        }

        if (found == TRUE) {
            return SX_UTILS_STATUS_ENTRY_ALREADY_EXISTS;
        }

        if (psort_clients > MAX_PSORT_CLIENTS) {
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        /* add to list */
        status = cl_list_insert_tail(&psort_background_registration_list, (void*)(uintptr_t)handle);
        if (status != CL_SUCCESS) {
            return SX_UTILS_STATUS_ERROR;
        }

        psort_clients++;

        break;

    case SX_UTILS_CMD_DELETE:
        if (FALSE == is_psort_background_registration_list_init) {
            return SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        }

        /* remove from  list */
        itor = cl_list_head(&psort_background_registration_list);
        list_end = cl_list_end(&psort_background_registration_list);
        while (itor != list_end) {
            psort_handle_t item = (psort_handle_t)(uintptr_t)(cl_list_obj(itor));
            if (item == handle) {
                found = TRUE;
                break;
            }

            itor = cl_list_next(itor);
        }

        /* is entry exist ? */
        if (found == TRUE) {
            cl_list_remove_item(&psort_background_registration_list, itor);
            psort_clients--;
        } else {
            return SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        }
        break;

    default:
        /* cmd not supported */
        return SX_UTILS_STATUS_CMD_UNSUPPORTED;
    }


    return SX_UTILS_STATUS_SUCCESS;
}


sx_utils_status_t psort_background_checker(boolean_t *is_complete_p)
{
    cl_list_iterator_t itor;
    cl_list_iterator_t list_end;
    sx_utils_status_t  rc = SX_UTILS_STATUS_SUCCESS;
    boolean_t          is_complete = FALSE;

    *is_complete_p = TRUE;

    if (FALSE == is_psort_background_registration_list_init) {
        return rc;
    }


    itor = cl_list_head(&psort_background_registration_list);
    list_end = cl_list_end(&psort_background_registration_list);
    while (itor != list_end) {
        psort_handle_t item = (psort_handle_t)(uintptr_t)(cl_list_obj(itor));
        itor = cl_list_next(itor);

        is_complete = FALSE;

        rc = psort_background_worker(item, &is_complete);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error executing psort background worker handle  [%" PRIu64 "] rc [%s]\n",
                       item,
                       SX_UTILS_STATUS_MSG(rc));
            return rc;
        }

        /* If background did not complete then we need to mark it */
        if (is_complete == FALSE) {
            *is_complete_p = FALSE;
        }
    }

    return rc;
}


sx_utils_status_t psort_entry_set(const psort_handle_t handle, sx_utils_command_t cmd, psort_entry_t     *entry_p)
{
    int                     i = 0;
    sx_utils_status_t       rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_region_hole_t* region_p = NULL;
    int                     num_of_entries = 1;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    /* Validate enough free space (also check actual space */
    for (i = 0; i < num_of_entries; i++) {
        rc = psort_db_validate_priority(handle, entry_p[i].priority);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error validate bad priority [%d] for entry [%d] rc [%s]\n",
                       entry_p[i].priority,
                       i,
                       SX_UTILS_STATUS_MSG(rc));
            return rc;
        }
    }

    switch (cmd) {
    case SX_UTILS_CMD_ADD:
        rc = psort_db_add_entry(handle, entry_p);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            if (rc == SX_UTILS_STATUS_NO_RESOURCES) {
                SX_LOG_INF("psort_db_add_entries rc [%s]\n", SX_UTILS_STATUS_MSG(rc));
            } else {
                SX_LOG_ERR("Error psort_db_add_entries rc [%s]\n", SX_UTILS_STATUS_MSG(rc));
            }
            return rc;
        }

        break;

    case SX_UTILS_CMD_DELETE:
        for (i = 0; i < num_of_entries; i++) {
            if (psort_db_get_region(handle, entry_p[i].priority, &region_p) == TRUE) {
                /* Validate index exist */
                rc = psort_db_validate_index_exist(region_p, &entry_p[i]);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error validate bad index [%d] for entry [%d] rc [%s]\n",
                               entry_p[i].index,
                               i,
                               SX_UTILS_STATUS_MSG(rc));
                    return rc;
                }
            } else {
                return SX_UTILS_STATUS_ENTRY_NOT_FOUND;
            }
        }

        for (i = 0; i < num_of_entries; i++) {
            if (psort_db_get_region(handle, entry_p[i].priority, &region_p) == TRUE) {
                /* Remove entry from region*/
                rc = psort_db_remove_entry_from_region(handle, region_p, &entry_p[i]);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error removing entry region priority [%d] index [%d] rc [%s]\n",
                               entry_p[i].priority,
                               entry_p[i].index,
                               SX_UTILS_STATUS_MSG(rc));
                    return rc;
                }
            } else {
                /*return SX_UTILS_STATUS_ENTRY_NOT_FOUND;*/
            }
        }      /* end for */
        break;

    default:
        /* cmd not supported */
        return SX_UTILS_STATUS_CMD_UNSUPPORTED;
    }

    return rc;
}

sx_utils_status_t psort_prio_change(const psort_handle_t handle,
                                    uint32_t             min_prio,
                                    uint32_t             max_prio,
                                    int32_t              prio_change)
{
    sx_utils_status_t rc = SX_UTILS_STATUS_SUCCESS;

    rc = psort_db_prio_change(handle, min_prio, max_prio, prio_change);

    return rc;
}

sx_utils_status_t psort_get_table_free_space(const psort_handle_t handle, uint32_t *size)
{
    *size = psort_db_get_table_actual_free_space(handle);
    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t psort_get_table_used_space(const psort_handle_t handle, uint32_t *size)
{
    *size = psort_db_get_table_size(handle) - psort_db_get_table_actual_free_space(handle);
    return SX_UTILS_STATUS_SUCCESS;
}


sx_utils_status_t psort_table_resize(const psort_handle_t handle,
                                     uint32_t             new_size,
                                     boolean_t            is_background,
                                     uint32_t           * shift_count_p)
{
    sx_utils_status_t rc = SX_UTILS_STATUS_SUCCESS;
    uint32_t          actual_free_space = psort_db_get_table_actual_free_space(handle);
    uint32_t          table_size = psort_db_get_table_size(handle);
    uint32_t          used_size = table_size - actual_free_space;


    if (new_size == table_size) {
        /* nothing to be done.. */
        return rc;
    } else if (new_size > table_size) {
        /* increase table size */
        rc = psort_db_increase_table_size(handle, new_size);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error increasing table size handle [%" PRIu64 "] rc [%s]\n", handle, SX_UTILS_STATUS_MSG(rc));
            return rc;
        }
    } else {
        /* validate */
        if (used_size > new_size) {
            /* Cannot resize table without data loss */
            SX_LOG_ERR("Cannot decrease table size without data loss\n");
            return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
        }

        /* decrease table size */

        rc = psort_db_decrease_table_size(handle, new_size, is_background, shift_count_p);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error decreasing table size handle [%" PRIu64 "] rc [%s]\n", handle, SX_UTILS_STATUS_MSG(rc));
            return rc;
        }
    }

    return rc;
}


/* Background worker . Used for defragment and reorder of the table */
sx_utils_status_t psort_background_worker(const psort_handle_t handle, boolean_t *is_complete_p)
{
    sx_utils_status_t   rc = SX_UTILS_STATUS_SUCCESS;
    uint32_t            shift_count = 0;
    psort_table_state_e table_state;
    boolean_t           is_single_priority = FALSE, resized = FALSE;

    /* 1.	For each region Check if there is a need to Increase or decrease each region size (From Top to Bottom) (Allocated at chunks of Delta  size).
     *       For each region */

    /* if Region Full */
    *is_complete_p = FALSE;

    rc = __psort_get_background_worker_state(handle, &table_state);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at __psort_get_background_worker_state\n");
        return rc;
    }

    if (table_state == PSORT_TABLE_STATE_STEADY_E) {
        *is_complete_p = TRUE;
        return SX_UTILS_STATUS_SUCCESS;
    }

    if (table_state <= PSORT_TABLE_STATE_RESIZE_JUST_REDUCED_E) {
        psort_db_take_ref(handle);
        rc = __psort_thresholds_check(handle, &shift_count, &resized);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at __psort_thresholds_check\n");
            psort_db_release_ref(handle, FALSE);
            return rc;
        }
        if ((shift_count != 0) || resized) {
            /* Not complete. But continue on next background */
            psort_db_release_ref(handle, TRUE);
            return SX_UTILS_STATUS_SUCCESS;
        }
        if (psort_db_is_deleted(handle)) {
            /* Table deleted. Done working on it for this background */
            psort_db_release_ref(handle, TRUE);
            return SX_UTILS_STATUS_SUCCESS;
        }
        psort_db_release_ref(handle, FALSE);
    }

    rc = psort_db_is_single_priority(handle, &is_single_priority);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at psort_db_is_single_priority\n");
        return rc;
    }

    if (!is_single_priority) {
        /* If region not Full */
        rc = __psort_regions_size_check_and_resize(handle, &shift_count);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at psort_db_regions_size_check\n");
            return rc;
        }

        if (shift_count == 0) {
            /* only one move is allowed */
            rc = __psort_optimal_hole_size_check(handle, is_complete_p);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Error at __psort_optimal_hole_size_check\n");
                return rc;
            }
        }
    } else {
        rc = psort_db_defrag_single_priority(handle, TRUE, &shift_count);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at psort_db_defrag_single_priority\n");
            return rc;
        }
        if (shift_count == 0) {
            *is_complete_p = TRUE;
        }
    }

    return SX_UTILS_STATUS_SUCCESS;
}

/* Free resources and destroy table*/
sx_utils_status_t psort_clear_table(const psort_handle_t handle)
{
    sx_utils_status_t rc = SX_UTILS_STATUS_SUCCESS;

    /* clear table */
    rc = psort_db_clear_table(handle);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at psort_db_clear_table\n");
        return rc;
    }

    return rc;
}


sx_utils_status_t psort_dump_table(const psort_handle_t handle,
                                   psort_entry_info_t  *entries_p,
                                   uint32_t            *num_of_entries_p)
{
    sx_utils_status_t rc = SX_UTILS_STATUS_SUCCESS;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    rc = psort_db_get_table(handle, entries_p, num_of_entries_p);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at psort_db_get_table\n");
        return rc;
    }

    return rc;
}

/* debug function to dump table */
sx_utils_status_t psort_debug_dump(const psort_handle_t handle, FILE* stream)
{
    sx_utils_status_t         rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_region_hole_t   *region_hole = NULL;
    cl_list_iterator_t        itor;
    cl_list_iterator_t        list_end;
    psort_db_table_db_t      *psort_db_table_db = NULL;
    uint32_t                  num, empty, used;
    const char              * value;
    dbg_utils_table_columns_t region_hole_table[] = {
        {"Num", 4, PARAM_UINT32_E, NULL},
        {"Type", 6, PARAM_STRING_E, NULL},
        {"Prio", 10, PARAM_INT_E, NULL},
        {"Start", 5, PARAM_UINT32_E, NULL},
        {"End", 5, PARAM_UINT32_E, NULL},
        {"Size", 5, PARAM_UINT32_E, NULL},
        {"Empty", 5, PARAM_UINT32_E, NULL},
        {"Used", 5, PARAM_UINT32_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;


    num = cl_qpool_count(&psort_db_table_db->regions_holes_pool);
    dbg_utils_pprinter_field_print(stream, "Region-Hole pool count", &num, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Num of entries",
                                   &psort_db_table_db->psort_db_entries_db.num_of_entries,
                                   PARAM_UINT32_E);
    num = cl_list_count(&psort_db_table_db->psort_db_entries_db.free_pool);
    dbg_utils_pprinter_field_print(stream, "Entry pool count", &num, PARAM_UINT32_E);

    num = cl_qmap_count(&psort_db_table_db->region_hole_map);
    dbg_utils_pprinter_field_print(stream, "Region-Hole map count", &num, PARAM_UINT32_E);

    dbg_utils_pprinter_field_print(stream, "Delta", &psort_db_table_db->delta_size, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Minimum priority", &psort_db_table_db->min_priority, PARAM_INT_E);
    dbg_utils_pprinter_field_print(stream, "Maximum priority", &psort_db_table_db->max_priority, PARAM_INT_E);

    dbg_utils_pprinter_field_print(stream, "Region-Holes", &psort_db_table_db->regions_holes_cnt, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Regions", &psort_db_table_db->regions_cnt, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Holes", &psort_db_table_db->holes_cnt, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Background non-complete",
                                   &psort_db_table_db->background_worker_non_complete_cnt,
                                   PARAM_UINT32_E);

    dbg_utils_pprinter_field_print(stream,
                                   "Almost-empty threshold",
                                   &psort_db_table_db->table_almost_empty_val_threshold,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Almost-full threshold",
                                   &psort_db_table_db->table_almost_full_val_threshold,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Almost-empty %",
                                   &psort_db_table_db->table_almost_empty_precentage_threshold,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Almost-full %",
                                   &psort_db_table_db->table_almost_full_precentage_threshold,
                                   PARAM_UINT32_E);

    dbg_utils_pprinter_field_print(stream, "Sum of holes", &psort_db_table_db->sum_of_holes, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Total free entries", &psort_db_table_db->total_free_entries,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Table Size", &psort_db_table_db->table_size, PARAM_UINT32_E);

    dbg_utils_pprinter_field_print(stream, "Number of shifts", &psort_db_table_db->cntr_num_of_shifts, PARAM_UINT32_E);
    if (psort_db_table_db->state <= PSORT_TABLE_STATE_MAX_E) {
        value = psort_table_state_str[psort_db_table_db->state];
    } else {
        value = "N/A";
    }
    dbg_utils_pprinter_field_print(stream, "State", value, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream, "Refcount", &psort_db_table_db->refcount, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Destroy", &psort_db_table_db->destroy_table, PARAM_BOOL_E);

    dbg_utils_pprinter_table_headline_print(stream, region_hole_table);

    num = 0;
    itor = cl_list_head(&psort_db_table_db->table);
    list_end = cl_list_end(&psort_db_table_db->table);
    /* 1. Lookup for the closet region for insertion top or bottom*/

    while (itor != list_end) {
        region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));

        region_hole_table[0].data = &num;
        region_hole_table[1].data = (region_hole->type == PSORT_REGION_TYPE_HOLE_E) ? "Hole" : "Region";
        region_hole_table[2].data = &region_hole->priority;
        region_hole_table[3].data = &region_hole->start;
        region_hole_table[4].data = &region_hole->end;
        region_hole_table[5].data = &region_hole->size;
        empty = cl_qmap_count(&region_hole->empty_space);
        region_hole_table[6].data = &empty;
        used = cl_qmap_count(&region_hole->used_space);
        region_hole_table[7].data = &used;

        dbg_utils_pprinter_table_data_line_print(stream, region_hole_table);

        num++;

        itor = cl_list_next(itor);
    }

    return rc;
}


/* Get info and statisticsCounters */
sx_utils_status_t psort_info_stats_get(const psort_handle_t handle, psort_info_stats_t* info_stats_p)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_table_db_t *psort_db_table_db = NULL;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;


    info_stats_p->num_of_shifts = psort_db_table_db->cntr_num_of_shifts;
    rc = psort_db_get_table_total_regions_size(handle, &info_stats_p->total_regions_size);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Error get table total regions size handle [%" PRIu64 "] rc [%s]\n", handle,
                   SX_UTILS_STATUS_MSG(rc));
        return rc;
    }

    info_stats_p->num_of_regions = psort_db_table_db->regions_cnt;
    info_stats_p->total_region_hole_num = psort_db_table_db->regions_holes_cnt;

    return rc;
}

sx_utils_status_t __psort_get_background_worker_state(const psort_handle_t handle, psort_table_state_e* table_state_p)
{
    psort_db_table_db_t *psort_db_table_db = NULL;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    *table_state_p = psort_db_table_db->state;

    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t __psort_regions_size_check_and_resize(const psort_handle_t handle, uint32_t* shift_count_p)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_table_db_t *psort_db_table_db = NULL;
    cl_list_iterator_t   itor;
    uint32_t             free_space = 0;
    uint32_t             used_space = 0;
    uint32_t             free_space_above = 0;
    uint32_t             free_space_below = 0;
    uint32_t             decrease_size_threshold_val = 0;
    uint32_t             resize_size = 0;
    boolean_t            iterate_next_flag = FALSE;
    cl_list_iterator_t   list_end;


    /* 1.	For each region Check if there is a need to Increase or decrease each region size (From Top to Bottom) (Allocated at chunks of Delta  size).
     *       For each region:
     *       1. If Region Full:
     *        a. If Habove > HBelow . Take space from largest hole.
     *        b. Increase pool by Delta
     *
     *       2. If region is not full:
     *        a. if Total Region size - Actual used region size > 1.5*delta:
     *        Region size Decrease by Delta.
     *        Relased buffer is given back to Hole with less Space (H above or H below).
     *        Defragment operation of the region might be needed */

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;


    itor = cl_list_head(&psort_db_table_db->table);
    list_end = cl_list_end(&psort_db_table_db->table);
    while (itor != list_end) {
        psort_db_region_hole_t *region_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
        iterate_next_flag = TRUE;
        if (region_p->type == PSORT_REGION_TYPE_PRIORITY_E) {
            /* Read region Empty space */
            /* read region used space */

            free_space = psort_db_get_region_free_space(region_p);
            /* is region Full? */
            if (free_space <= PSORT_REGION_FULL_SIZE_CHECK) {
                /* Expand region toward the largest hole */
                /* Available space in above or below hole */
                free_space_above = psort_db_get_hole_free_space(handle, region_p, TOP_HOLE_E);
                free_space_below = psort_db_get_hole_free_space(handle, region_p, BOTTOM_HOLE_E);
                if ((free_space_above == 0) && (free_space_below == 0)) {
                    /* No space to expand  */
                } else if (free_space_above >= free_space_below) {
                    /* Expand to top */
                    rc = psort_db_expand_region(handle, region_p, TOP_HOLE_E, psort_db_table_db->delta_size);
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error expanding region priority [%d] to above hole rc [%s]\n",
                                   region_p->priority,
                                   SX_UTILS_STATUS_MSG(rc));
                        return rc;
                    }
                } else {
                    /* Expand to bottom */
                    rc = psort_db_expand_region(handle, region_p, BOTTOM_HOLE_E, psort_db_table_db->delta_size);
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error expanding region priority [%d] to bottom hole rc [%s]\n",
                                   region_p->priority,
                                   SX_UTILS_STATUS_MSG(rc));
                        return rc;
                    }
                }
            } else {
                /* If if Total Region size - Actual used region size > 1.5*delta: */

                free_space = psort_db_get_region_free_space(region_p);
                used_space = psort_db_get_region_used_space(region_p);
                decrease_size_threshold_val =
                    (uint32_t)(POSRT_DECREASE_SIZE_THRESHOLD * psort_db_table_db->delta_size);

                if (used_space == 0) {
                    /* Remove region , resize region to 0 */
                    free_space_above = psort_db_get_hole_free_space(handle, region_p, TOP_HOLE_E);
                    free_space_below = psort_db_get_hole_free_space(handle, region_p, BOTTOM_HOLE_E);

                    if (itor == cl_list_head(&psort_db_table_db->table)) {
                        if (region_p->priority != psort_db_table_db->max_priority) {
                            itor = cl_list_next(itor);
                            iterate_next_flag = FALSE;

                            /* release space to below hole */
                            rc = psort_db_resize_region(handle, region_p, free_space, TOP_HOLE_E, TRUE, shift_count_p);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error shifting region\n");
                                return rc;
                            }
                        } else {
                            /* decrease to Delta Size */
                            if (region_p->size > psort_db_table_db->delta_size) {
                                resize_size = region_p->size - psort_db_table_db->delta_size;
                                /* release space to below hole */
                                rc = psort_db_resize_region(handle,
                                                            region_p,
                                                            resize_size,
                                                            TOP_HOLE_E,
                                                            TRUE,
                                                            shift_count_p);
                                if (rc != SX_UTILS_STATUS_SUCCESS) {
                                    SX_LOG_ERR("Error shifting region\n");
                                    return rc;
                                }
                            } /* end if */
                        }
                    } else if (itor == cl_list_tail(&psort_db_table_db->table)) {
                        if (region_p->priority != psort_db_table_db->min_priority) {
                            itor = cl_list_next(itor);
                            iterate_next_flag = FALSE;

                            /* release space to upper hole */
                            rc = psort_db_resize_region(handle,
                                                        region_p,
                                                        free_space,
                                                        BOTTOM_HOLE_E,
                                                        TRUE,
                                                        shift_count_p);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error shifting region\n");
                                return rc;
                            }
                        } else {
                            /* decrease to Delta Size */
                            if (region_p->size > psort_db_table_db->delta_size) {
                                resize_size = region_p->size - psort_db_table_db->delta_size;
                                /* release space to upper hole */
                                rc = psort_db_resize_region(handle,
                                                            region_p,
                                                            resize_size,
                                                            BOTTOM_HOLE_E,
                                                            TRUE,
                                                            shift_count_p);
                                if (rc != SX_UTILS_STATUS_SUCCESS) {
                                    SX_LOG_ERR("Error shifting region\n");
                                    return rc;
                                }
                            } /* end if */
                        }
                    } else {
                        itor = cl_list_next(itor);
                        iterate_next_flag = FALSE;

                        if (free_space_above >= free_space_below) {
                            /* release space to below hole */
                            rc = psort_db_resize_region(handle, region_p, free_space, TOP_HOLE_E, TRUE, shift_count_p);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error shifting region\n");
                                return rc;
                            }
                        } else {
                            rc = psort_db_resize_region(handle,
                                                        region_p,
                                                        free_space,
                                                        BOTTOM_HOLE_E,
                                                        TRUE,
                                                        shift_count_p);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error shifting region\n");
                                return rc;
                            }
                        }
                    }

                    if (*shift_count_p != 0) {
                        goto out;
                    }
                } else if (free_space > decrease_size_threshold_val) {
                    /* decrease region size by delta */
                    free_space_above = psort_db_get_hole_free_space(handle, region_p, TOP_HOLE_E);
                    free_space_below = psort_db_get_hole_free_space(handle, region_p, BOTTOM_HOLE_E);

                    if (free_space_above >= free_space_below) {
                        if (region_p->priority != psort_db_table_db->min_priority) {
                            /* release space to below hole */
                            rc = psort_db_resize_region(handle,
                                                        region_p,
                                                        psort_db_table_db->delta_size,
                                                        TOP_HOLE_E,
                                                        TRUE,
                                                        shift_count_p);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error shifting region\n");
                                return rc;
                            }
                        } else {
                            rc = psort_db_resize_region(handle,
                                                        region_p,
                                                        psort_db_table_db->delta_size,
                                                        BOTTOM_HOLE_E,
                                                        TRUE,
                                                        shift_count_p);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error shifting region\n");
                                return rc;
                            }
                        }
                    } else {
                        if (region_p->priority != psort_db_table_db->max_priority) {
                            rc = psort_db_resize_region(handle,
                                                        region_p,
                                                        psort_db_table_db->delta_size,
                                                        BOTTOM_HOLE_E,
                                                        TRUE,
                                                        shift_count_p);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error shifting region\n");
                                return rc;
                            }
                        } else {
                            rc = psort_db_resize_region(handle,
                                                        region_p,
                                                        psort_db_table_db->delta_size,
                                                        TOP_HOLE_E,
                                                        TRUE,
                                                        shift_count_p);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error shifting region\n");
                                return rc;
                            }
                        }
                    }

                    if (*shift_count_p != 0) {
                        goto out;
                    }
                }
            } /* end if free_space <= PSORT_REGION_FULL_SIZE_CHECK*/
        }
        if (iterate_next_flag) {
            itor = cl_list_next(itor);
        }
    } /* end while */

out:
    return rc;
}

int __psort_compare_region_func(const void * a, const void * b)
{
    int                     ret = 0;
    psort_db_region_hole_t* p1 = (psort_db_region_hole_t*)a;
    psort_db_region_hole_t* p2 = (psort_db_region_hole_t*)b;

    if (p1->size < p2->size) {
        ret = -1;
    } else if (p1->size == p2->size) {
        ret = 0;
    } else { /*if ( p1->size > p2->size ) */
        ret = 1;
    }

    return ret;
}

sx_utils_status_t __psort_optimal_hole_size_find_region_to_shift(psort_lookup_direction_e direction,
                                                                 psort_db_table_db_t     *psort_db_table_db_p,
                                                                 psort_db_region_hole_t * hole_p,
                                                                 boolean_t              * can_shift_region_p,
                                                                 psort_db_region_hole_t** region_to_shift_p_p)
{
    sx_utils_status_t       rc = SX_UTILS_STATUS_SUCCESS;
    cl_list_iterator_t      itor;
    boolean_t               can_expand_top = FALSE;
    boolean_t               can_expand_bottom = FALSE;
    uint32_t                size = 0;
    psort_db_region_hole_t *prev_region_p = NULL;
    psort_db_region_hole_t *prev_prev_region_p = NULL;
    psort_db_region_hole_t *next_region_p = NULL;
    psort_db_region_hole_t *next_next_region_p = NULL;
    uint32_t                hole_size_above = 0;
    uint32_t                hole_size_below = 0;
    psort_db_region_hole_t *region_p = NULL;

    *can_shift_region_p = FALSE;

    /* check if the hole is in top or bottom */
    if (hole_p == NULL) {
        goto out;
    }

    switch (direction) {
    case PSORT_LOOKUP_DIRECITON_UP_E:
        itor = hole_p->list_item_p;
        if (itor == cl_list_head(&psort_db_table_db_p->table)) {
            goto out;
        }
        itor = cl_list_prev(itor);

        while (itor != cl_list_head(&psort_db_table_db_p->table) && *can_shift_region_p == FALSE) {
            can_expand_top = TRUE;
            region_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_p->type == PSORT_REGION_TYPE_HOLE_E) {
                /* check above hole */
                size = region_p->size;
                prev_region_p = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_prev));
                itor = prev_region_p->list_item_p;
                if (itor != cl_list_head(&psort_db_table_db_p->table)) {
                    prev_prev_region_p = (psort_db_region_hole_t*)(cl_list_obj(prev_region_p->list_item_p->p_prev));
                    if (prev_prev_region_p->type != PSORT_REGION_TYPE_HOLE_E) {
                        /* cannot expand to top */
                        can_expand_top = FALSE;
                    } else {
                        hole_size_above = prev_prev_region_p->size;
                    }
                } else {
                    can_expand_top = FALSE;
                }
                if (can_expand_top == TRUE) {
                    if (!(size + PSORT_BACKGROUND_MOVE_SIZE >= hole_size_above)) {
                        /* found hole */
                        *can_shift_region_p = TRUE;
                        *region_to_shift_p_p = prev_region_p;  /*region_above*/
                    }
                } else {
                    /* cannot expand to top and didn't find hole that can be resized , break */
                    break;
                }
            }
            itor = cl_list_prev(itor);
        }
        break;

    case PSORT_LOOKUP_DIRECITON_DOWN_E:
        itor = hole_p->list_item_p;
        while (itor != cl_list_tail(&psort_db_table_db_p->table) && *can_shift_region_p == FALSE) {
            can_expand_bottom = TRUE;
            region_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_p->type == PSORT_REGION_TYPE_HOLE_E) {
                size = region_p->size;
                next_region_p = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_next));
                itor = next_region_p->list_item_p;
                if (itor != cl_list_tail(&psort_db_table_db_p->table)) {
                    next_next_region_p = (psort_db_region_hole_t*)(cl_list_obj(next_region_p->list_item_p->p_next));
                    if (next_next_region_p->type != PSORT_REGION_TYPE_HOLE_E) {
                        /* cannot expand to bottom */
                        /* if we cannot expand to top or bottom - do not save the hole */
                        can_expand_bottom = FALSE;
                    } else {
                        hole_size_below = next_next_region_p->size;
                    }
                } else {
                    /* next region is the most bottom region . we cannot expand toward it */
                    can_expand_bottom = FALSE;
                }

                if (can_expand_bottom == TRUE) {
                    if (!(size + PSORT_BACKGROUND_MOVE_SIZE >= hole_size_below)) {
                        /* found hole */
                        *can_shift_region_p = TRUE;
                        *region_to_shift_p_p = next_region_p;     /* region_below */
                    }
                } else {
                    /* cannot expand to top and didn't find hole that can be resized , break */
                    break;
                }
            }
            itor = cl_list_next(itor);
        }
        break;

    default:
        /* unexpected switch case */
        rc = SX_UTILS_STATUS_ERROR;
    }

out:
    return rc;
}
sx_utils_status_t __psort_optimal_hole_size_check(const psort_handle_t handle, boolean_t *is_complete)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_table_db_t *psort_db_table_db = NULL;
    cl_list_iterator_t   itor;
    uint32_t             free_space_above = 0;
    uint32_t             free_space_below = 0;
    uint32_t             shift_count = 0;
    /* counter for calculating the desired hole size */
    uint32_t                optimal_hole_size_div_part = 0;
    uint32_t                optimal_hole_size = 0;
    uint32_t                optimal_hole_size_mod_part = 0;
    uint32_t                min_hole_size = 9999;
    psort_db_region_hole_t *region_above_min_hole_p = NULL;
    psort_db_region_hole_t *region_below_min_hole_p = NULL;
    psort_db_region_hole_t *next_region_p = NULL;
    psort_db_region_hole_t *next_next_region_p = NULL;
    psort_db_region_hole_t *prev_region_p = NULL;
    psort_db_region_hole_t *prev_prev_region_p = NULL;
    uint32_t                hole_size_above = 0;
    uint32_t                hole_size_below = 0;
    uint32_t                min_hole_size_above = 0;
    uint32_t                min_hole_size_below = 0;
    uint32_t                size = 0;
    psort_db_region_hole_t *region_below_p = NULL;
    psort_db_region_hole_t *region_above_p = NULL;
    boolean_t               can_expand_top = FALSE;
    boolean_t               can_expand_bottom = FALSE;
    boolean_t               found_min_hole = FALSE;
    uint32_t                above_hole_size_cnt = 0;
    uint32_t                above_regions_priority_cnt = 0;
    psort_db_region_hole_t *region_p = NULL;
    boolean_t               is_finish_move = FALSE;
    uint32_t                iteration_num = 0;
    boolean_t               found_new_min = FALSE;
    boolean_t               can_shift_region = FALSE;
    cl_list_iterator_t      list_end;


    /* 1.	For each region Check if there is a need to Increase or decrease each region size (From Top to Bottom) (Allocated at chunks of Delta  size).
     *       For each region:
     *       1. If Region Full:
     *        a. If Habove > HBelow . Take space from largest hole.
     *        b. Increase pool by Delta
     *
     *       2. If region is not full:
     *        a. if Total Region size - Actual used region size > 1.5*delta:
     *        Region size Decrease by Delta.
     *        Relased buffer is given back to Hole with less Space (H above or H below).
     *        Defragment operation of the region might be needed */

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;


    /* Create At Least [Total Regions+1] Holes */

    /* calculate optimal H */
    rc = psort_db_get_table_optimal_hole_size(handle, &optimal_hole_size_div_part, &optimal_hole_size_mod_part);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Error get table optimal size rc [%s]\n", SX_UTILS_STATUS_MSG(rc));
        return rc;
    }

    optimal_hole_size = optimal_hole_size_div_part;

    if (optimal_hole_size == 0) {
        /* nothing to do */
        goto out;
    }

    while (FALSE == is_finish_move && iteration_num < psort_db_table_db->regions_holes_cnt) {
        min_hole_size = 9999;
        /* make array with hole - small to large */
        itor = cl_list_head(&psort_db_table_db->table);
        list_end = cl_list_end(&psort_db_table_db->table);
        while (itor != list_end) {
            region_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
            region_below_p = NULL;
            region_above_p = NULL;
            can_expand_top = TRUE;
            can_expand_bottom = TRUE;
            next_next_region_p = NULL;
            next_region_p = NULL;
            found_min_hole = FALSE;
            hole_size_below = 0;
            hole_size_above = 0;
            if (region_p->type == PSORT_REGION_TYPE_HOLE_E) {
                size = region_p->size;
                if ((size < optimal_hole_size) && (size <= min_hole_size)) {
                    found_min_hole = TRUE;
                    /* if next and previous hole is also size of 0 we cannot expand the hole */
                    /* check next next and prev prev regions */

                    itor = region_p->list_item_p;
                    if (itor != cl_list_head(&psort_db_table_db->table)) {
                        prev_region_p = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_prev));
                        itor = prev_region_p->list_item_p;
                        if (itor != cl_list_head(&psort_db_table_db->table)) {
                            prev_prev_region_p =
                                (psort_db_region_hole_t*)(cl_list_obj(prev_region_p->list_item_p->p_prev));
                            if (prev_prev_region_p->type != PSORT_REGION_TYPE_HOLE_E) {
                                /* cannot expand to top */
                                can_expand_top = FALSE;
                            } else {
                                hole_size_above = prev_prev_region_p->size;
                            }
                        } else {
                            can_expand_top = FALSE;
                        }

                        region_above_p = prev_region_p;
                    } else {
                        can_expand_top = FALSE;
                    }

                    itor = region_p->list_item_p;
                    if (itor != cl_list_tail(&psort_db_table_db->table)) {
                        next_region_p = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_next));
                        itor = next_region_p->list_item_p;
                        if (itor != cl_list_tail(&psort_db_table_db->table)) {
                            next_next_region_p =
                                (psort_db_region_hole_t*)(cl_list_obj(next_region_p->list_item_p->p_next));
                            if (next_next_region_p->type != PSORT_REGION_TYPE_HOLE_E) {
                                /* cannot expand to bottom */
                                /* if we cannot expand to top or bottom - do not save the hole */
                                can_expand_bottom = FALSE;
                            } else {
                                hole_size_below = next_next_region_p->size;
                            }
                        } else {
                            /* next region is the most bottom region . we cannot expand toward it */
                            can_expand_bottom = FALSE;
                        }

                        region_below_p = next_region_p;
                    } else {
                        can_expand_bottom = FALSE;
                    }
                }
                above_hole_size_cnt += size;
            } else if (region_p->type == PSORT_REGION_TYPE_PRIORITY_E) {
                /* read next region */
                itor = region_p->list_item_p;
                if (itor != cl_list_tail(&psort_db_table_db->table)) {
                    next_region_p = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_next));
                    if (next_region_p->type == PSORT_REGION_TYPE_PRIORITY_E) {
                        /* found virtual hole with size of 0  */
                        size = 0;
                        found_min_hole = TRUE;
                        region_above_p = region_p;
                        region_below_p = next_region_p;

                        itor = region_p->list_item_p;
                        if (itor != cl_list_head(&psort_db_table_db->table)) {
                            prev_region_p = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_prev));
                            if (prev_region_p->type != PSORT_REGION_TYPE_HOLE_E) {
                                /* cannot expand to top */
                                can_expand_top = FALSE;
                            } else {
                                hole_size_above = prev_region_p->size;
                            }
                        } else {
                            can_expand_top = FALSE;
                        }

                        itor = region_p->list_item_p;
                        if (itor != cl_list_tail(&psort_db_table_db->table)) {
                            itor = next_region_p->list_item_p;
                            if (itor != cl_list_tail(&psort_db_table_db->table)) {
                                next_next_region_p =
                                    (psort_db_region_hole_t*)(cl_list_obj(next_region_p->list_item_p->p_next));
                                if (next_next_region_p->type != PSORT_REGION_TYPE_HOLE_E) {
                                    /* cannot expand to bottom */
                                    /* if we cannot expand to top or bottom - do not save the hole */
                                    can_expand_bottom = FALSE;
                                } else {
                                    hole_size_below = next_next_region_p->size;
                                    /*if (hole_size_below <= size + 1){
                                     *   can_expand_bottom = FALSE;
                                     *  }*/
                                }
                            } else {
                                /* next region is the most bottom region . we cannot expand toward it */
                                can_expand_bottom = FALSE;
                            }
                        } else {
                            can_expand_bottom = FALSE;
                        }
                    }
                }
                above_regions_priority_cnt++;
            }

            if ((found_min_hole == TRUE) && ((can_expand_bottom == TRUE) || (can_expand_top == TRUE))) {
                if (size == min_hole_size) {
                    found_new_min = FALSE;
                    if (hole_size_above > hole_size_below) {
                        if ((hole_size_above > min_hole_size_below) && (hole_size_above > min_hole_size_above)) {
                            found_new_min = TRUE;
                        }
                    } else {
                        if ((hole_size_below > min_hole_size_below) && (hole_size_below > min_hole_size_above)) {
                            found_new_min = TRUE;
                        }
                    }
                    if (found_new_min == TRUE) {
                        min_hole_size = size;
                        region_above_min_hole_p = region_above_p;
                        region_below_min_hole_p = region_below_p;
                        min_hole_size_above = hole_size_above;
                        min_hole_size_below = hole_size_below;
                    }
                } else {
                    min_hole_size = size;
                    region_above_min_hole_p = region_above_p;
                    region_below_min_hole_p = region_below_p;
                    min_hole_size_above = hole_size_above;
                    min_hole_size_below = hole_size_below;
                }
            } /*if (can_expand_bottom == TRUE || can_expand_top == TRUE){ */
            itor = region_p->list_item_p;
            itor = cl_list_next(itor);
        }

        if (min_hole_size != 9999) {
            can_shift_region = FALSE;

            /* we have a minimum hole */
            /* check if size is smaller than factor*delta */
            if (min_hole_size_above > min_hole_size_below) {
                if (min_hole_size + PSORT_BACKGROUND_MOVE_SIZE >= min_hole_size_above) {
                    /* look for a hole that can be resized */

                    rc = __psort_optimal_hole_size_find_region_to_shift(PSORT_LOOKUP_DIRECITON_UP_E,
                                                                        psort_db_table_db,
                                                                        region_above_min_hole_p,
                                                                        &can_shift_region,
                                                                        &region_above_min_hole_p);
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error at __psort_optimal_hole_size_find_region_to_shift\n");
                        goto out;
                    }
                } else {
                    can_shift_region = TRUE;
                }

                if (can_shift_region == TRUE) {
                    /* move the above regions up by 1 */
                    rc = psort_db_shift_region(handle,
                                               region_above_min_hole_p,
                                               PSORT_BACKGROUND_MOVE_SIZE,
                                               TOP_HOLE_E,
                                               &shift_count);
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error shifting region\n");
                        goto out;
                    }
                } else {
                    rc = __psort_optimal_hole_size_find_region_to_shift(PSORT_LOOKUP_DIRECITON_DOWN_E,
                                                                        psort_db_table_db,
                                                                        region_below_min_hole_p,
                                                                        &can_shift_region,
                                                                        &region_below_min_hole_p);
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error at __psort_optimal_hole_size_find_region_to_shift\n");
                        goto out;
                    }
                    if (can_shift_region == TRUE) {
                        rc = psort_db_shift_region(handle,
                                                   region_below_min_hole_p,
                                                   PSORT_BACKGROUND_MOVE_SIZE,
                                                   BOTTOM_HOLE_E,
                                                   &shift_count);
                        if (rc != SX_UTILS_STATUS_SUCCESS) {
                            SX_LOG_ERR("Error shifting region\n");
                            goto out;
                        }
                    } else {
                        /* can't shift either in up or down direction. */
                        is_finish_move = TRUE;
                    }
                }
            } else {
                if (min_hole_size_below != 0) {
                    if (min_hole_size + PSORT_BACKGROUND_MOVE_SIZE >= min_hole_size_below) {
                        rc = __psort_optimal_hole_size_find_region_to_shift(PSORT_LOOKUP_DIRECITON_DOWN_E,
                                                                            psort_db_table_db,
                                                                            region_below_min_hole_p,
                                                                            &can_shift_region,
                                                                            &region_below_min_hole_p);
                        if (rc != SX_UTILS_STATUS_SUCCESS) {
                            SX_LOG_ERR("Error at __psort_optimal_hole_size_find_region_to_shift\n");
                            goto out;
                        }
                    } else {
                        can_shift_region = TRUE;
                    }


                    if (can_shift_region == TRUE) {
                        rc = psort_db_shift_region(handle,
                                                   region_below_min_hole_p,
                                                   PSORT_BACKGROUND_MOVE_SIZE,
                                                   BOTTOM_HOLE_E,
                                                   &shift_count);
                        if (rc != SX_UTILS_STATUS_SUCCESS) {
                            SX_LOG_ERR("Error shifting region\n");
                            goto out;
                        }
                    } else {
                        rc = __psort_optimal_hole_size_find_region_to_shift(PSORT_LOOKUP_DIRECITON_UP_E,
                                                                            psort_db_table_db,
                                                                            region_above_min_hole_p,
                                                                            &can_shift_region,
                                                                            &region_above_min_hole_p);
                        if (rc != SX_UTILS_STATUS_SUCCESS) {
                            SX_LOG_ERR("Error at __psort_optimal_hole_size_find_region_to_shift\n");
                            goto out;
                        }

                        if (can_shift_region == TRUE) {
                            rc = psort_db_shift_region(handle,
                                                       region_above_min_hole_p,
                                                       PSORT_BACKGROUND_MOVE_SIZE,
                                                       TOP_HOLE_E,
                                                       &shift_count);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error shifting region\n");
                                goto out;
                            }
                        } else {
                            /* can't shift either in up or down direction. */
                            is_finish_move = TRUE;
                        }
                    }
                }
            }

            if (shift_count != 0) {
                break;
            }
        } else {
            is_finish_move = TRUE;
        }
        iteration_num++;
    }

    /* if no movement occur. check top regions and bottom regions to be aligned to frame. */
    if (shift_count == 0) {
        /* check top and bottom region */
        /* validate */
        psort_db_region_hole_t *top_region_p = NULL;
        psort_db_region_hole_t *bottom_region_p = NULL;

        itor = cl_list_head(&psort_db_table_db->table);
        list_end = cl_list_end(&psort_db_table_db->table);
        while (itor != list_end) {
            region_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_p->type == PSORT_REGION_TYPE_PRIORITY_E) {
                top_region_p = region_p;
                break;
            }
            itor = cl_list_next(itor);
        }

        itor = cl_list_tail(&psort_db_table_db->table);
        while (itor != cl_list_head(&psort_db_table_db->table)) {
            region_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_p->type == PSORT_REGION_TYPE_PRIORITY_E) {
                bottom_region_p = region_p;
                break;
            }
            itor = cl_list_prev(itor);
        }

        if (top_region_p != NULL) {
            free_space_above = psort_db_get_hole_free_space(handle, top_region_p, TOP_HOLE_E);

            if ((free_space_above != 0) && (top_region_p->priority == psort_db_table_db->max_priority)) {
                while (free_space_above > 0 && shift_count != 0) {
                    if (free_space_above > PSORT_BACKGROUND_MOVE_SIZE) {
                        rc = psort_db_shift_region(handle,
                                                   top_region_p,
                                                   PSORT_BACKGROUND_MOVE_SIZE,
                                                   TOP_HOLE_E,
                                                   &shift_count);
                    } else {
                        rc = psort_db_shift_region(handle, top_region_p, free_space_above, TOP_HOLE_E, &shift_count);
                    }
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error shifting region\n");
                        goto out;
                    }

                    if (shift_count != 0) {
                        free_space_above = psort_db_get_hole_free_space(handle, top_region_p, TOP_HOLE_E);
                    } else {
                        break;
                    }
                }
            }
        }

        if (bottom_region_p != NULL) {
            free_space_below = psort_db_get_hole_free_space(handle, bottom_region_p, BOTTOM_HOLE_E);

            if ((free_space_below != 0) && (bottom_region_p->priority == psort_db_table_db->min_priority)) {
                while (free_space_below > 0 && shift_count != 0) {
                    if (free_space_below > PSORT_BACKGROUND_MOVE_SIZE) {
                        rc = psort_db_shift_region(handle,
                                                   bottom_region_p,
                                                   PSORT_BACKGROUND_MOVE_SIZE,
                                                   BOTTOM_HOLE_E,
                                                   &shift_count);
                    } else {
                        rc = psort_db_shift_region(handle,
                                                   bottom_region_p,
                                                   free_space_below,
                                                   BOTTOM_HOLE_E,
                                                   &shift_count);
                    }
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error shifting region\n");
                        goto out;
                    }

                    if (shift_count != 0) {
                        free_space_below = psort_db_get_hole_free_space(handle, bottom_region_p, BOTTOM_HOLE_E);
                    } else {
                        break;
                    }
                }
            }
        }
    }

out:
    if ((shift_count == 0) && (iteration_num < psort_db_table_db->regions_holes_cnt) &&
        (psort_db_table_db->state != PSORT_TABLE_STATE_STEADY_E)) {
        *is_complete = TRUE;
        psort_db_table_db->state = PSORT_TABLE_STATE_STEADY_E;
        psort_db_table_db->background_worker_non_complete_cnt = 0;
    } else {
        /* Current state stays */
        *is_complete = FALSE;
        psort_db_table_db->background_worker_non_complete_cnt++;
        if (psort_db_table_db->background_worker_non_complete_cnt >=
            (psort_db_table_db->table_size * psort_db_table_db->regions_cnt)) {
            *is_complete = TRUE;
            psort_db_table_db->background_worker_non_complete_cnt = 0;
        }
    }


    return rc;
}


sx_utils_status_t __psort_thresholds_check(const psort_handle_t handle, uint32_t* shift_count_p, boolean_t* resized)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_table_db_t *psort_db_table_db = NULL;
    uint32_t             almost_full_val = 0;
    uint32_t             almost_empty_val = 0;
    uint32_t             actual_free_space, table_size, used_size;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (shift_count_p != NULL) {
        *shift_count_p = 0;
    }

    almost_full_val = psort_db_get_table_almost_full_threshold_num(handle);
    almost_empty_val = psort_db_get_table_almost_empty_threshold_num(handle);

    actual_free_space = psort_db_get_table_actual_free_space(handle);
    table_size = psort_db_get_table_size(handle);
    used_size = table_size - actual_free_space;

    /* Check almost full threshold*/
    if ((used_size >= almost_full_val) && (almost_full_val > 0) &&
        (psort_db_table_db->state != PSORT_TABLE_STATE_RESIZE_JUST_REDUCED_E)) {
        rc = psort_db_notify_almost_full_event(handle, shift_count_p);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error notify almost big\n");
            return rc;
        }
        if (shift_count_p != NULL) {
            if (*shift_count_p != 0) {
                /* Client wishes to resize, but it's not done doing so. State stays, not complete */
                if (resized != NULL) {
                    *resized = TRUE;
                }
                goto out;
            }
        }
        if (psort_db_get_table_size(handle) > table_size) {
            /* Client ended up with larger table. Move to enlarging state, indicate not complete */
            if (resized != NULL) {
                *resized = TRUE;
            }
            psort_db_table_db->state = PSORT_TABLE_STATE_RESIZE_JUST_ENLARGED_E;
            goto out;
        }
        /* Client ended up with same table size or smaller. Done resizing, move on to shifting */
        if (resized != NULL) {
            *resized = FALSE;
        }
        psort_db_table_db->state = PSORT_TABLE_STATE_NOT_STEADY_E;
        goto out;
    }

    /* Check almost empty threshold */
    if ((used_size <= almost_empty_val) &&
        (psort_db_table_db->state != PSORT_TABLE_STATE_RESIZE_JUST_ENLARGED_E)) {
        rc = psort_db_notify_almost_empty_event(handle, shift_count_p);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error notify almost empty\n");
            return rc;
        }
        if (shift_count_p != NULL) {
            if (*shift_count_p != 0) {
                /* Client wishes to resize, but it's not done doing so. State stays, not complete */
                if (resized != NULL) {
                    *resized = TRUE;
                }
                goto out;
            }
        }
        if (psort_db_get_table_size(handle) < table_size) {
            /* Client ended up with smaller table. Move to reducing state, indicate not complete */
            if (resized != NULL) {
                *resized = TRUE;
            }
            psort_db_table_db->state = PSORT_TABLE_STATE_RESIZE_JUST_REDUCED_E;
            goto out;
        }
        /* Client ended up with same table size or larger. Done resizing, move on to shifting */
        if (resized != NULL) {
            *resized = FALSE;
        }
        psort_db_table_db->state = PSORT_TABLE_STATE_NOT_STEADY_E;
        goto out;
    }

out:
    return rc;
}


sx_utils_status_t psort_params_set(psort_handle_t *handle, const psort_set_param_t *params)
{
    sx_utils_status_t rc = SX_UTILS_STATUS_SUCCESS;

    UNUSED_PARAM(handle);
    UNUSED_PARAM(params);

    return rc;
}
