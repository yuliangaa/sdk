/*
 * Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sx/utils/gc.h"
#include "gen_utils.h"
#include "gc_db.h"
#include "sx/utils/sdk_timer.h"
#include "sx/utils/dbg_utils.h"
#include "sx/utils/dbg_utils_pretty_printer.h"
#include "complib/cl_mem.h"
#include "complib/cl_thread.h"
#include <complib/cl_dbg.h>
#include "complib/cl_fcntl.h"
#include <sx/utils/debug_cmd.h>

#undef  __MODULE__
#define __MODULE__ GC

/************************************************
 *  Local Defines
 ***********************************************/
#ifndef PD_BU
#define SYNC_FENCE_TIMEOUT_uS 10000000
#else
#define SYNC_FENCE_TIMEOUT_uS 100000000
#endif

#define MAX_PROCESS_SIZE (0xFFFFFFFF)
/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/
typedef struct post_queue_thread_param {
    uint32_t  timer_interval;
    boolean_t stop_thread;
    uint32_t  bg_limit;
} post_queue_thread_param_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t                 g_is_initialized = FALSE;
static gc_init_params_t          g_gc_params;
static uint32_t                  g_gc_timer_interval_default = 0;
static uint32_t                  g_fast_fence_seq_num = 0;
static uint32_t                  g_slow_fence_seq_num = 0;
static gc_fence_type_t           g_curr_fence = GC_FENCE_TYPE_NONE;
static hwi_gc_ops_t              g_gc_ops;
static sdk_timer_handle_t        g_global_timer_handle;
static sdk_timer_handle_t        g_global_completion_timer_handle;
gc_object_type_t                 g_completion_object_context = GC_OBJECT_TYPE_MAX + 1;
static gc_post_queue_t           gc_post_queue_s;
static cl_thread_t               post_queue_thread_s;
static post_queue_thread_param_t post_queue_thread_params_s;
static uint32_t                  gc_object_threshold_cnt_s[GC_OBJECT_TYPE_NUMBER];


#define GC_RESOURCES_OPT                                                                                         \
    "<all|kvd|pgt|counters|rif|vrid|global_policer|host_ifc_policer|storm_ctrl_policer|mpe|shspm|fid|port|span|" \
    "erp|hw_region|span_policer|accuflow_counters|uengine_utcam|uengine_utcam_range_start|uengine_utcam_range_end>"
#define GC_POST_Q_OPT "<all|ratr_rtdp|mpls_nhlfe|acl_action_set|ppbd_hmcb|mpls_ilm|rigr_v2|rpf_group|ipv6|tnumt>"

#define GC_FLUSH(TYPE)                                                                        \
    status = gc_object_process_queue(TYPE);                                                   \
    if (SX_UTILS_CHECK_FAIL(status)) {                                                        \
        dbg_utils_print(stream, "Failed to process GC queue for object type %s err = [%s]\n", \
                        GC_OBJECT_TYPE_STR(TYPE), SX_UTILS_STATUS_MSG(status));               \
    }

#define GC_POST_Q_CLEAN(TYPE)                                                                   \
    status = gc_post_queue_cleanup(TRUE, TYPE);                                                 \
    if (SX_UTILS_CHECK_FAIL(status)) {                                                          \
        dbg_utils_print(stream, "Failed to cleanup post queue for object type %s err = [%s]\n", \
                        GC_OBJECT_SUBTYPE_STR(TYPE), SX_UTILS_STATUS_MSG(status));              \
    }

/************************************************
 *  Local function declarations
 ***********************************************/
static void __gc_post_queue_timer_thread(void *context);
static void __fence_send_cb(FILE* stream, int argc, const char *argv[], void *handler_context);
static void __gc_flush_cb(FILE* stream, int argc, const char *argv[], void *handler_context);
static void __gc_post_q_cb(FILE* stream, int argc, const char *argv[], void *handler_context);
static void __gc_resource_cnt_get_cb(FILE *stream, int argc, const char *argv[], void *handler_context);
static void __gc_resource_queue_dump_cb(FILE *stream, int argc, const char *argv[], void *handler_context);


/************************************************
 *  Function implementations
 ***********************************************/
static sx_utils_status_t __validate_gc_params(const gc_init_params_t *gc_params)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (gc_params->gc_timer_interval == 0) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("GC timer interval must be larger than 0\n");
        goto out;
    }

    if (gc_params->slow_fence_timer_interval == 0) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Slow fence timer interval must be larger than 0\n");
        goto out;
    }

    if (gc_params->fast_fence_timer_interval == 0) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Fast fence timer interval must be larger than 0\n");
        goto out;
    }

    if (gc_params->sync_slow_fence_timer_interval == 0) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Synchronous slow fence timer interval must be larger than 0\n");
        goto out;
    }

    if (gc_params->sync_fast_fence_timer_interval == 0) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Synchronous fast fence timer interval must be larger than 0\n");
        goto out;
    }

    if (gc_params->max_hw_operations == 0) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Max HW operations must be larger than 0\n");
        goto out;
    }

    if (((gc_params->gc_timer_interval * 1000) <= gc_params->slow_fence_timer_interval) ||
        ((gc_params->gc_timer_interval * 1000) <= gc_params->fast_fence_timer_interval)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("GC timer interval (%u s) must be larger than slow fence timer interval "
                   "(%u ms) and fast fence timer interval (%u ms)\n",
                   gc_params->gc_timer_interval,
                   gc_params->slow_fence_timer_interval,
                   gc_params->fast_fence_timer_interval);
        goto out;
    }

    /* Validate additional gc_params */
    if (g_gc_ops.gc_handle_post_queue_pfn != NULL) {
        if (gc_params->post_queue_timer_interval == 0) {
            err = SX_UTILS_STATUS_PARAM_ERROR;
            SX_LOG_ERR("GC post queue timer interval must be larger than 0\n");
            goto out;
        }

        if (gc_params->post_queue_bg_limit > 100) {
            err = SX_UTILS_STATUS_PARAM_ERROR;
            SX_LOG_ERR("GC background delete limit should be in range 0..100\n");
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_utils_status_t __validate_object_attributes(const gc_object_type_attributes_t *object_attr)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!GC_FENCE_TYPE_CHECK_RANGE(object_attr->fence_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid fence type %u given\n", object_attr->fence_type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

/* If the last time the GC was activated, a fence was performed, check
 * if it has completed. If not, set the timer again. If it has, update the
 * global sequence number.
 */
static sx_utils_status_t __check_fence_async(sdk_timer_handle_t timer_handle,
                                             gc_fence_state_t  *fence_state,
                                             boolean_t         *timer_started)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    CL_ASSERT(g_gc_ops.gc_fence_state_read_pfn);

    err = g_gc_ops.gc_fence_state_read_pfn(fence_state);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get fence state, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }
    SX_LOG_DBG("Fence state is %s\n", GC_FENCE_STATE_STR(*fence_state));

    if (*fence_state == GC_FENCE_STATE_NONE) {
        if (g_curr_fence == GC_FENCE_TYPE_SLOW) {
            g_slow_fence_seq_num++;
        } else { /* GC_FENCE_TYPE_FAST */
            CL_ASSERT(g_curr_fence == GC_FENCE_TYPE_FAST);
            g_fast_fence_seq_num++;
        }

        g_curr_fence = GC_FENCE_TYPE_NONE;
    } else {
        CL_ASSERT(*fence_state == GC_FENCE_STATE_ONGOING);

        if (g_curr_fence == GC_FENCE_TYPE_SLOW) {
            err = sdk_timer_start(timer_handle, g_gc_params.slow_fence_timer_interval);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to start slow fence timer for handle %u, err = [%s]\n",
                           timer_handle, SX_UTILS_STATUS_MSG(err));
                goto out;
            }
        } else { /* GC_FENCE_TYPE_FAST */
            CL_ASSERT(g_curr_fence == GC_FENCE_TYPE_FAST);
            err = sdk_timer_start(timer_handle, g_gc_params.fast_fence_timer_interval);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to start fast fence timer for handle %u, err = [%s]\n",
                           timer_handle, SX_UTILS_STATUS_MSG(err));
                goto out;
            }
        }

        if (timer_started) {
            *timer_started = TRUE;
        }

        SX_LOG_DBG("%s fence is ongoing, waiting for fence to complete\n",
                   GC_FENCE_TYPE_STR(g_curr_fence));

        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_utils_status_t __check_fence_sync_cb(void *context)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    gc_fence_state_t  fence_state = 0;

    UNUSED_PARAM(context);

    CL_ASSERT(g_gc_ops.gc_fence_state_read_pfn);

    err = g_gc_ops.gc_fence_state_read_pfn(&fence_state);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get fence state, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if (fence_state == GC_FENCE_STATE_NONE) {
        err = SX_UTILS_STATUS_SUCCESS;
    } else {
        CL_ASSERT(fence_state == GC_FENCE_STATE_ONGOING);
        err = SX_UTILS_STATUS_PARTIALLY_COMPLETE;
    }

out:
    return err;
}

static sx_utils_status_t __do_sync_fence(gc_fence_type_t fence_type)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          polling_interval = (g_curr_fence == GC_FENCE_TYPE_SLOW) ?
                                         g_gc_params.sync_slow_fence_timer_interval :
                                         g_gc_params.sync_fast_fence_timer_interval;

    SX_LOG_ENTER();

    CL_ASSERT(g_gc_ops.gc_fence_pfn);

    if (g_curr_fence != GC_FENCE_TYPE_NONE) {
        err = gen_utils_timed_poll(polling_interval,
                                   SYNC_FENCE_TIMEOUT_uS,
                                   __check_fence_sync_cb, NULL);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to poll for synchronous fence, err = [%s]\n",
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        g_curr_fence = GC_FENCE_TYPE_NONE;
    }

    err = g_gc_ops.gc_fence_pfn(fence_type);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to perform %s fence type, err = [%s]\n",
                   GC_FENCE_TYPE_STR(fence_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    g_curr_fence = fence_type;
    polling_interval = (g_curr_fence == GC_FENCE_TYPE_SLOW) ?
                       g_gc_params.sync_slow_fence_timer_interval :
                       g_gc_params.sync_fast_fence_timer_interval;

    err = gen_utils_timed_poll(polling_interval,
                               SYNC_FENCE_TIMEOUT_uS,
                               __check_fence_sync_cb, NULL);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to poll synchronous fence, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if (fence_type == GC_FENCE_TYPE_SLOW) {
        g_slow_fence_seq_num++;
    } else {
        g_fast_fence_seq_num++;
    }

    g_curr_fence = GC_FENCE_TYPE_NONE;

out:
    SX_LOG_EXIT();
    return err;
}

/* Main GC algorithm:
 * 1. Check if the top object in the queue needs fencing, based on the
 *    sequence number.
 * 2. If it does, perform the appropriate fence type, set the timer, and exit.
 * 3. If it doesn't:
 *      3a. If the object requires post-processing, insert it into the
 *          post-processing queue, and pop it from the main processing queue.
 *      3b. If the object doesn't require post-processing, call its completion
 *          callback, and pop it from the queue.
 * 4. When we've exceeded the maximum number of HW operations per iteration, or
 *    when the main processing queue is empty:
 *      4a. Perform post-processing on all objects that required post-processing
 *          (completions for these objects will be performed as well).
 *      4b. Start the relevant timer and exit.
 */
static sx_utils_status_t __process_queue_async(boolean_t          is_global,
                                               gc_object_type_t   object_type,
                                               sdk_timer_handle_t timer_handle,
                                               boolean_t         *timer_started)
{
    sx_utils_status_t             err = SX_UTILS_STATUS_SUCCESS;
    gc_object_data_t              object_data;
    gc_object_type_attributes_t   object_attr;
    gc_object_completion_pfn      completion_cb;
    gc_object_post_completion_pfn post_completion_cb;
    uint32_t                      hw_operation_cnt = 0;
    uint64_t                      sll_time = 0;
    uint32_t                      gc_time = 0;


    M_GEN_UTILS_MEM_CLR(object_data);
    M_GEN_UTILS_MEM_CLR(object_attr);
    M_GEN_UTILS_MEM_CLR(completion_cb);
    M_GEN_UTILS_MEM_CLR(post_completion_cb);

    CL_ASSERT(g_gc_ops.gc_fence_pfn);
    CL_ASSERT(g_gc_ops.gc_delay_completion_pfn);

    if (is_global) {
        err = gc_db_global_queue_top(&object_data);
    } else {
        err = gc_db_object_type_queue_top(object_type, &object_data);
    }

    while (err != SX_UTILS_STATUS_ENTRY_NOT_FOUND) {
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get top of GC queue, err = [%s]\n",
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        err = gc_db_object_type_attributes_get(object_data.object_type, &object_attr);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get attributes for object type %s, err = [%s]\n",
                       GC_OBJECT_TYPE_STR(object_data.object_type), SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        if ((object_attr.fence_type == GC_FENCE_TYPE_SLOW) &&
            (object_data.seq_num >= g_slow_fence_seq_num)) {
            err = g_gc_ops.gc_fence_pfn(GC_FENCE_TYPE_SLOW);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to perform slow fence, err = [%s]\n",
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            g_curr_fence = GC_FENCE_TYPE_SLOW;
            err = sdk_timer_start(timer_handle, g_gc_params.slow_fence_timer_interval);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to start slow fence timer for handle %u, err = [%s]\n",
                           timer_handle, SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            SX_LOG_DBG("Slow timer started for timer handle %u\n", timer_handle);
            if (timer_started) {
                *timer_started = TRUE;
            }

            goto out;
        } else if ((object_attr.fence_type == GC_FENCE_TYPE_FAST) &&
                   ((object_data.seq_num >= g_fast_fence_seq_num) &&
                    (object_data.alt_seq_num >= g_slow_fence_seq_num))) {
            err = g_gc_ops.gc_fence_pfn(GC_FENCE_TYPE_FAST);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to perform fast fence, err = [%s]\n",
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            g_curr_fence = GC_FENCE_TYPE_FAST;
            err = sdk_timer_start(timer_handle, g_gc_params.fast_fence_timer_interval);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to start fast fence timer for handle %u, err = [%s]\n",
                           timer_handle, SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            SX_LOG_DBG("Fast timer started for timer handle %u\n", timer_handle);
            if (timer_started) {
                *timer_started = TRUE;
            }

            goto out;
        } else {
            CL_ASSERT(((object_attr.fence_type == GC_FENCE_TYPE_SLOW) &&
                       (object_data.seq_num < g_slow_fence_seq_num)) ||
                      ((object_attr.fence_type == GC_FENCE_TYPE_FAST) &&
                       (object_data.seq_num < g_fast_fence_seq_num)) ||
                      ((object_attr.fence_type == GC_FENCE_TYPE_FAST) &&
                       (object_data.alt_seq_num < g_slow_fence_seq_num)) ||
                      (object_attr.fence_type == GC_FENCE_TYPE_NONE));

            err = gc_db_object_completion_cb_get(object_data.object_type, &completion_cb, &post_completion_cb);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to get completion callback for object type %s, err = [%s]\n",
                           GC_OBJECT_TYPE_STR(object_data.object_type),
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            /* Some objects require additional post-processing before completion.
             * This is determined based on chip type and object type.
             */
            if (!g_gc_ops.gc_delay_completion_pfn(object_data.object_type)) {
                if (completion_cb) {
                    err = completion_cb(object_data.gc_context);
                    if (SX_UTILS_CHECK_FAIL(err)) {
                        SX_LOG_ERR("Completion callback for object type %s (sequence number %u) failed, err = [%s]\n",
                                   GC_OBJECT_TYPE_STR(object_data.object_type),
                                   object_data.seq_num, SX_UTILS_STATUS_MSG(err));
                        goto out;
                    }

                    if (object_attr.hw_operation_needed) {
                        hw_operation_cnt++;
                    }
                }
            } else {
                err = gc_post_queue_push(&object_data,
                                         completion_cb,
                                         post_completion_cb);
                if (SX_UTILS_CHECK_FAIL(err)) {
                    SX_LOG_ERR(
                        "Failed to push the element #[%d] with type [%s] to GC post processing queue, err[%s]\n",
                        object_data.seq_num,
                        GC_OBJECT_TYPE_STR(object_data.object_type),
                        SX_UTILS_STATUS_MSG(err));
                    goto out;
                }
            }

            if (is_global) {
                err = gc_db_global_queue_pop(NULL);
            } else {
                err = gc_db_object_type_queue_pop(object_type, NULL);
            }

            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to pop entry from GC queue, err = [%s]\n",
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            SX_LOG_DBG("Removed object of type %s from GC queue\n",
                       GC_OBJECT_TYPE_STR(object_data.object_type));
        }

        if (hw_operation_cnt >= g_gc_params.max_hw_operations) {
            SX_LOG_DBG("HW operation count exceeds max\n");
            break;
        }

        if (is_global) {
            err = gc_db_global_queue_top(&object_data);
        } else {
            err = gc_db_object_type_queue_top(object_type, &object_data);
        }
    }

    if (is_global) {
        if (g_gc_ops.gc_get_sll_time_pfn != NULL) {
            err = g_gc_ops.gc_get_sll_time_pfn(&sll_time);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_WRN("Failed to read SLL time for handle %u starting with default, err = [%s]\n",
                           timer_handle, SX_UTILS_STATUS_MSG(err));
                err = SX_UTILS_STATUS_SUCCESS;
            }
            if (sll_time != 0) {
                gc_time = (uint32_t)(2 * ((long double)sll_time * 1e-6) + 1);
                SX_LOG_DBG("Sll time %" PRIu64 " GC Time %u\n", sll_time, gc_time);
                /* If new GC time is within acceptable range, then change it else retain the current value*/
                if ((g_gc_params.gc_timer_interval != gc_time) && (gc_time < g_gc_timer_interval_default) &&
                    ((gc_time * 1000) >= g_gc_params.slow_fence_timer_interval)) {
                    g_gc_params.gc_timer_interval = gc_time;
                    SX_LOG_DBG("Changing GC timers Sll time %" PRIu64 " GC Time %u\n", sll_time, gc_time);
                }
            }
        }

        err = sdk_timer_start(timer_handle, g_gc_params.gc_timer_interval * 1000);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to start GC timer for handle %u, err = [%s]\n",
                       timer_handle, SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        SX_LOG_DBG("Global timer started for timer handle %u\n", timer_handle);
        if (timer_started) {
            *timer_started = TRUE;
        }
    } else if (hw_operation_cnt >= g_gc_params.max_hw_operations) {
        /* In this case, we're trying to empty the object queue, but can't do it
         * all in one timer iteration.
         */
        err = sdk_timer_start(timer_handle, 0);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to start GC timer for handle %u, err = [%s]\n",
                       timer_handle, SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        SX_LOG_DBG("Zero-timer started for timer handle %u\n", timer_handle);
        if (timer_started) {
            *timer_started = TRUE;
        }
    } else {
        err = SX_UTILS_STATUS_SUCCESS;
    }

out:
    return err;
}

static sx_utils_status_t __process_queue_sync(gc_object_type_t object_type, uint32_t process_amount)
{
    sx_utils_status_t             err = SX_UTILS_STATUS_SUCCESS;
    gc_object_data_t              object_data;
    gc_object_type_attributes_t   object_attr;
    gc_object_completion_pfn      completion_cb;
    gc_object_post_completion_pfn post_completion_cb;
    uint32_t                      total_size = 0;

    SX_LOG_ENTER();

    M_GEN_UTILS_MEM_CLR(object_data);
    M_GEN_UTILS_MEM_CLR(object_attr);
    M_GEN_UTILS_MEM_CLR(completion_cb);
    M_GEN_UTILS_MEM_CLR(post_completion_cb);

    err = gc_db_object_type_queue_pop(object_type, &object_data);

    while (err != SX_UTILS_STATUS_ENTRY_NOT_FOUND) {
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to pop object from GC queue, err = [%s]\n",
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        SX_LOG_DBG("Removed object of type %s from GC queue\n",
                   GC_OBJECT_TYPE_STR(object_data.object_type));

        err = gc_db_object_type_attributes_get(object_data.object_type,
                                               &object_attr);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get attributes of object type %s, err = [%s]\n",
                       GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        if (((object_attr.fence_type == GC_FENCE_TYPE_SLOW) &&
             (object_data.seq_num >= g_slow_fence_seq_num)) ||
            ((object_attr.fence_type == GC_FENCE_TYPE_FAST) &&
             (object_data.seq_num >= g_fast_fence_seq_num))) {
            err = __do_sync_fence(object_attr.fence_type);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to perform synchronous fence of type %s, err = [%s]\n",
                           GC_FENCE_TYPE_STR(object_attr.fence_type),
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }
        }

        err = gc_db_object_completion_cb_get(object_data.object_type,
                                             &completion_cb, &post_completion_cb);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get completion callback for object type %s, err = [%s]\n",
                       GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        if (g_gc_ops.gc_delay_completion_pfn(object_type)) {
            err = gc_post_queue_push(&object_data,
                                     completion_cb, post_completion_cb);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to push the element #[%d] with type [%s] to post processing queue, err[%s]\n",
                           object_data.seq_num,
                           GC_OBJECT_TYPE_STR(object_data.object_type),
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }
        } else if (completion_cb) {
            err = completion_cb(object_data.gc_context);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Completion callback for object failed, err = [%s]\n",
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }
        }

        /* If we've processed enough entries we can stop */
        total_size += object_data.size;
        if (total_size >= process_amount) {
            break;
        }

        err = gc_db_object_type_queue_pop(object_type, &object_data);
    }

    err = SX_UTILS_STATUS_SUCCESS;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_init(const gc_init_params_t *gc_params, hwi_gc_ops_t *ops)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t rollback_err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;
    boolean_t         db_initialized = FALSE;
    boolean_t         timer_received = FALSE;
    boolean_t         completion_timer_received = FALSE;
    boolean_t         post_queue_initialized = FALSE;
    uint32_t          i;

    SX_LOG_ENTER();

    if (g_is_initialized) {
        err = SX_UTILS_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("GC module is already initialized\n");
        goto out;
    }

    M_GEN_UTILS_MEM_CLR(g_gc_ops);
    g_fast_fence_seq_num = 0;
    g_slow_fence_seq_num = 0;

    if (gc_params == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("gc_params is NULL\n");
        goto out;
    }

    if (ops == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("ops is NULL\n");
        goto out;
    }

    M_GEN_UTILS_MEM_CPY_TYPE(&g_gc_ops, ops, hwi_gc_ops_t);

    err = __validate_gc_params(gc_params);
    if (SX_UTILS_CHECK_FAIL(err)) {
        goto out;
    }

    err = gc_db_init();
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to initialize GC DB, err = [%s]\n", SX_UTILS_STATUS_MSG(err));
        goto out;
    }
    db_initialized = TRUE;

    for (i = 0; i < GC_OBJECT_TYPE_NUMBER; i++) {
        gc_object_threshold_cnt_s[i] = 0;
    }


    err = sdk_timer_get(SX_UTILS_INT_CMD_GC_ACTIVATE_BACKGROUND_SET_E,
                        SDK_TIMER_TYPE_ONE_SHOT, NULL, 0,
                        SX_UTILS_MED_PRIO_BUF_E,
                        &g_global_timer_handle);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get global timer, err = [%s]\n", SX_UTILS_STATUS_MSG(err));
        goto out;
    }
    timer_received = TRUE;


    err = sdk_timer_get(SX_UTILS_INT_CMD_GC_ACTIVATE_BACKGROUND_SET_E,
                        SDK_TIMER_TYPE_PERIODIC, &g_completion_object_context, sizeof(g_completion_object_context),
                        SX_UTILS_MED_PRIO_BUF_E,
                        &g_global_completion_timer_handle);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get global completion timer, err = [%s]\n", SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    completion_timer_received = TRUE;

    memset(&g_gc_params, 0, sizeof(g_gc_params));
    memcpy(&g_gc_params, gc_params, sizeof(g_gc_params));
    g_gc_timer_interval_default = gc_params->gc_timer_interval;

#ifdef PD_BU
    g_gc_params.sync_fast_fence_timer_interval *= 100;
    g_gc_params.sync_slow_fence_timer_interval *= 100;
    SX_LOG_NTC("%s:%d: Increased for PALLADIUM fast/slow fence_timer_interval:%u/%u "
               "SYNC_FENCE_TIMEOUT_uS:%u \n",
               __func__,
               __LINE__,
               g_gc_params.sync_fast_fence_timer_interval,
               g_gc_params.sync_slow_fence_timer_interval,
               SYNC_FENCE_TIMEOUT_uS);
#endif
    g_curr_fence = GC_FENCE_TYPE_NONE;
    g_gc_params.use_sw_lazy_delete = gc_params->use_sw_lazy_delete;

    err = sdk_timer_start(g_global_timer_handle,
                          g_gc_params.gc_timer_interval * 1000);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to start timer for handle %u, err = [%s]\n",
                   g_global_timer_handle, SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    err = sdk_timer_start(g_global_completion_timer_handle,
                          g_gc_params.gc_timer_interval);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to start timer for handle %u, err = [%s]\n",
                   g_global_completion_timer_handle, SX_UTILS_STATUS_MSG(err));
        goto out;
    }


    /* Init GC post processing queue:
     * for elements that requires additional FW work for delete
     */
    if (g_gc_ops.gc_handle_post_queue_pfn != NULL) {
        cl_spinlock_init(&gc_post_queue_s.lock);

        cl_spinlock_acquire(&gc_post_queue_s.lock);
        gc_post_queue_s.on_pause = TRUE;

        /* Pool init*/
        cl_err = CL_QPOOL_INIT(&gc_post_queue_s.pool,
                               0, CL_POOL_UNLIMITED_MAX_SIZE, 0,
                               sizeof(gc_post_queue_entry_t),
                               NULL, NULL, NULL);
        if (cl_err != CL_SUCCESS) {
            err = SX_UTILS_STATUS_ERROR;
            SX_LOG_ERR("Failed to initialize GC post queue qpool, cl_err = [%s]\n",
                       CL_STATUS_MSG(cl_err));
            goto release_lock;
        }

        /* List init */
        cl_qlist_init(&gc_post_queue_s.list);

        post_queue_initialized = TRUE;

        /* Init new thread, which will handle GC post queue */
        post_queue_thread_params_s.timer_interval = gc_params->post_queue_timer_interval;
        post_queue_thread_params_s.bg_limit = gc_params->post_queue_bg_limit;

        cl_err = cl_thread_init(&post_queue_thread_s,
                                __gc_post_queue_timer_thread,
                                NULL,
                                "gcPostQueueTimer", THREAD_MAX_ALLOWED_TIME_DEFAULT);
        if (cl_err != CL_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not create GC post queue handling thread.\n");
            err = SX_UTILS_STATUS_ERROR;
            goto release_lock;
        }

        post_queue_thread_params_s.stop_thread = FALSE;
        gc_post_queue_s.on_pause = FALSE;
        gc_post_queue_s.total_size = 0;
        M_GEN_UTILS_MEM_CLR(gc_post_queue_s.size_per_subtype);
        M_GEN_UTILS_MEM_CLR(gc_post_queue_s.count_per_subtype);

release_lock:
        cl_spinlock_release(&gc_post_queue_s.lock);
    }

    if (err == SX_UTILS_STATUS_SUCCESS) {
        g_is_initialized = TRUE;
        SX_LOG_DBG("Initialized GC module\n");
    }

    sx_utils_debug_cmd_register_path("sync fence send <slow|fast>",
                                     __fence_send_cb,
                                     NULL);
    sx_utils_debug_cmd_register_path("gc flush "GC_RESOURCES_OPT,
                                     __gc_flush_cb,
                                     NULL);

    sx_utils_debug_cmd_register_path("gc post_q cleanup "GC_POST_Q_OPT,
                                     __gc_post_q_cb,
                                     NULL);

    sx_utils_debug_cmd_register_path("gc count get "GC_RESOURCES_OPT,
                                     __gc_resource_cnt_get_cb,
                                     NULL);

    sx_utils_debug_cmd_register_path("gc queue dump "GC_RESOURCES_OPT,
                                     __gc_resource_queue_dump_cb,
                                     NULL);


out:
    if (SX_UTILS_CHECK_FAIL(err)) {
        if (timer_received) {
            rollback_err = sdk_timer_put(g_global_timer_handle);
            if (SX_UTILS_CHECK_FAIL(rollback_err)) {
                SX_LOG_ERR("Failed to put timer handle %u, err = [%s]\n",
                           g_global_timer_handle, SX_UTILS_STATUS_MSG(rollback_err));
            }
        }
        if (completion_timer_received) {
            rollback_err = sdk_timer_put(g_global_completion_timer_handle);
            if (SX_UTILS_CHECK_FAIL(rollback_err)) {
                SX_LOG_ERR("Failed to put timer handle %u, err = [%s]\n",
                           g_global_completion_timer_handle, SX_UTILS_STATUS_MSG(rollback_err));
            }
        }
        if (db_initialized) {
            rollback_err = gc_db_deinit();
            if (SX_UTILS_CHECK_FAIL(rollback_err)) {
                SX_LOG_ERR("Failed to deinitialize GC DB, err = [%s]\n",
                           SX_UTILS_STATUS_MSG(rollback_err));
            }
        }
        if (post_queue_initialized) {
            CL_QPOOL_DESTROY(&gc_post_queue_s.pool);
        }
    }

    SX_LOG_EXIT();
    return err;
}

static gc_object_type_t str2gcType(const char *obj_str)
{
    if (strcmp(obj_str, "kvd") == 0) {
        return GC_OBJECT_TYPE_KVD_LINEAR;
    } else if (strcmp(obj_str, "pgt") == 0) {
        return GC_OBJECT_TYPE_PGT;
    } else if (strcmp(obj_str, "counters") == 0) {
        return GC_OBJECT_TYPE_COUNTERS;
    } else if (strcmp(obj_str, "rif") == 0) {
        return GC_OBJECT_TYPE_RIF;
    } else if (strcmp(obj_str, "vrid") == 0) {
        return GC_OBJECT_TYPE_VRID;
    } else if (strcmp(obj_str, "global_policer") == 0) {
        return GC_OBJECT_TYPE_GLOBAL_POLICER;
    } else if (strcmp(obj_str, "host_ifc_policer") == 0) {
        return GC_OBJECT_TYPE_HOST_IFC_POLICER;
    } else if (strcmp(obj_str, "storm_ctrl_policer") == 0) {
        return GC_OBJECT_TYPE_STORM_CTRL_POLICER;
    } else if (strcmp(obj_str, "mpe") == 0) {
        return GC_OBJECT_TYPE_MPE;
    } else if (strcmp(obj_str, "shspm") == 0) {
        return GC_OBJECT_TYPE_SHSPM_TREE;
    } else if (strcmp(obj_str, "fid") == 0) {
        return GC_OBJECT_TYPE_FID;
    } else if (strcmp(obj_str, "port") == 0) {
        return GC_OBJECT_TYPE_PORT;
    } else if (strcmp(obj_str, "span") == 0) {
        return GC_OBJECT_TYPE_SPAN;
    } else if (strcmp(obj_str, "erp") == 0) {
        return GC_OBJECT_TYPE_ERP;
    } else if (strcmp(obj_str, "hw_region") == 0) {
        return GC_OBJECT_TYPE_HW_REGION;
    } else if (strcmp(obj_str, "span_policer") == 0) {
        return GC_OBJECT_TYPE_SPAN_POLICER;
    } else if (strcmp(obj_str, "accuflow_counters") == 0) {
        return GC_OBJECT_TYPE_ACCUFLOW_COUNTERS;
    } else if (strcmp(obj_str, "uengine_utcam") == 0) {
        return GC_OBJECT_TYPE_UENGINE_UTCAM;
    } else if (strcmp(obj_str, "uengine_utcam_range_start") == 0) {
        return GC_OBJECT_TYPE_UENGINE_UTCAM_RANGE_START;
    } else if (strcmp(obj_str, "uengine_utcam_range_end") == 0) {
        return GC_OBJECT_TYPE_UENGINE_UTCAM_RANGE_END;
    } else {
        return GC_OBECT_TYPE_INVALID;
    }
}

static void __gc_flush_cb(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    gc_object_type_t  gc_object_type;

    UNUSED_PARAM(handler_context);

    if (argc != 1) {
        dbg_utils_print(stream, "Invalid params. valid values: %s\n", GC_RESOURCES_OPT);
        return;
    }

    if (strcmp(argv[0], "all") == 0) {
        status = gc_clean();
        if (SX_UTILS_CHECK_FAIL(status)) {
            dbg_utils_print(stream, "Failed to gc_clean queue, err = [%s]\n",
                            SX_UTILS_STATUS_MSG(status));
        }
        status = gc_post_queue_cleanup(FALSE, GC_OBJECT_SUBTYPE_NONE);
        if (SX_UTILS_CHECK_FAIL(status)) {
            dbg_utils_print(stream, "Failed to cleanup GC post queue, err = [%s]\n",
                            SX_UTILS_STATUS_MSG(status));
        }
    } else {
        gc_object_type = str2gcType((argv[0]));
        if (gc_object_type != GC_OBECT_TYPE_INVALID) {
            GC_FLUSH(gc_object_type);
        } else {
            dbg_utils_print(stream, "Invalid param %s. valid values: %s\n", argv[0], GC_RESOURCES_OPT);
            return;
        }
    }

    if (status == SX_UTILS_STATUS_SUCCESS) {
        dbg_utils_print(stream, "GC flush successfully\n");
    } else {
        dbg_utils_print(stream, "Failed to do gc flush\n");
    }
}

static void __gc_resource_cnt_get_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    gc_object_type_t  gc_object_type;
    uint32_t          resource_count;
    uint32_t          total_size;

    UNUSED_PARAM(handler_context);

    if (argc != 1) {
        dbg_utils_print(stream, "Invalid params. valid values: %s\n", GC_RESOURCES_OPT);
        return;
    }

    if (strcmp(argv[0], "all") == 0) {
        gc_db_object_type_count_get(GC_OBECT_TYPE_INVALID, &resource_count);
        dbg_utils_print_general_header(stream, "Global GC Resource Count");
        dbg_utils_print(stream, "Resource count %u\n",  resource_count);
    } else {
        gc_object_type = str2gcType((argv[0]));
        if (gc_object_type != GC_OBECT_TYPE_INVALID) {
            status = gc_db_object_type_count_get(gc_object_type, &resource_count);
            if (SX_UTILS_CHECK_FAIL(status)) {
                dbg_utils_print(stream, "Failed to get GC count for resource, err = [%s]\n",
                                SX_UTILS_STATUS_MSG(status));
                goto out;
            }

            status = gc_db_object_type_total_size_get(gc_object_type, &total_size);
            if (SX_UTILS_CHECK_FAIL(status)) {
                dbg_utils_print(stream, "Failed to get GC size for resource, err = [%s]\n",
                                SX_UTILS_STATUS_MSG(status));
                goto out;
            }

            dbg_utils_print_general_header(stream, "GC Resource Count");
            dbg_utils_print(stream,
                            "Resource [%s] Count %u Size %u\n",
                            GC_OBJECT_TYPE_STR(gc_object_type),
                            resource_count,
                            total_size);
        } else {
            dbg_utils_print(stream, "Invalid param %s. valid values: %s\n", argv[0], GC_RESOURCES_OPT);
            return;
        }
    }

out:
    if (status == SX_UTILS_STATUS_SUCCESS) {
        dbg_utils_print(stream, "GC print successful\n");
    } else {
        dbg_utils_print(stream, "GC print failed \n");
    }
}


static void __gc_resource_queue_dump_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    gc_object_type_t            gc_object_type;

    memset(&printer_params, 0, sizeof(printer_params));

    UNUSED_PARAM(handler_context);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("__gc_resource_queue_dump_cb failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("__gc_resource_queue_dump_cb failed to create a printer.\n");
        goto out;
    }

    if (argc != 1) {
        dbg_utils_pprinter_print(key_fp, "Invalid params. valid values: %s\n", GC_RESOURCES_OPT);
        return;
    }

    if (strcmp(argv[0], "all") == 0) {
        gc_db_dump_queues(key_fp,  GC_OBECT_TYPE_INVALID, FALSE);
    } else {
        gc_object_type = str2gcType((argv[0]));
        if (gc_object_type != GC_OBECT_TYPE_INVALID) {
            gc_db_dump_queues(key_fp, gc_object_type, TRUE);
        } else {
            dbg_utils_pprinter_print(key_fp, "Invalid param %s. valid values: %s\n", argv[0], GC_RESOURCES_OPT);
            return;
        }
    }

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("__gc_resource_queue_dump_cb failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("__gc_resource_queue_dump_cb failed to close file /dev/null.\n");
        }
    }
}

static void __gc_post_q_cb(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    UNUSED_PARAM(handler_context);

    if (argc != 1) {
        dbg_utils_print(stream, "Invalid params. valid values: %s\n", GC_POST_Q_OPT);
        return;
    }

    if (strcmp(argv[0], "ratr_rtdp") == 0) {
        GC_POST_Q_CLEAN(GC_OBJECT_SUBTYPE_RATR_RTDP);
    } else if (strcmp(argv[0], "mpls_nhlfe") == 0) {
        GC_POST_Q_CLEAN(GC_OBJECT_SUBTYPE_MPLS_NHLFE);
    } else if (strcmp(argv[0], "acl_action_set") == 0) {
        GC_POST_Q_CLEAN(GC_OBJECT_SUBTYPE_ACL_ACTION_SET);
    } else if (strcmp(argv[0], "ppbd_hmcb") == 0) {
        GC_POST_Q_CLEAN(GC_OBJECT_SUBTYPE_PPBD_HMCB);
    } else if (strcmp(argv[0], "mpls_ilm") == 0) {
        GC_POST_Q_CLEAN(GC_OBJECT_SUBTYPE_MPLS_ILM);
    } else if (strcmp(argv[0], "rigr_v2") == 0) {
        GC_POST_Q_CLEAN(GC_OBJECT_SUBTYPE_RIGR_V2);
    } else if (strcmp(argv[0], "rpf_group") == 0) {
        GC_POST_Q_CLEAN(GC_OBJECT_SUBTYPE_RPF_GROUP);
    } else if (strcmp(argv[0], "ipv6") == 0) {
        GC_POST_Q_CLEAN(GC_OBJECT_SUBTYPE_IPV6);
    } else if (strcmp(argv[0], "tnumt") == 0) {
        GC_POST_Q_CLEAN(GC_OBJECT_SUBTYPE_TNUMT);
    } else if (strcmp(argv[0], "all") == 0) {
        status = gc_post_queue_cleanup(FALSE, GC_OBJECT_SUBTYPE_NONE);
        if (SX_UTILS_CHECK_FAIL(status)) {
            dbg_utils_print(stream, "Failed to cleanup GC post queue, err = [%s]\n",
                            SX_UTILS_STATUS_MSG(status));
        }
    } else {
        dbg_utils_print(stream, "Invalid param %s. valid values: %s\n", argv[0], GC_POST_Q_OPT);
        return;
    }

    if (status == SX_UTILS_STATUS_SUCCESS) {
        dbg_utils_print(stream, "GC post queue cleanup successfully\n");
    } else {
        dbg_utils_print(stream, "Failed to do GC post queue cleanup\n");
    }
}

sx_utils_status_t gc_deinit(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    if (g_gc_ops.gc_handle_post_queue_pfn != NULL) {
        /* Delete all elements from GC post queue*/
        err = gc_post_queue_cleanup(FALSE, GC_OBJECT_SUBTYPE_NONE);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to cleanup GC post queue, err = [%s]\n",
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        cl_spinlock_acquire(&gc_post_queue_s.lock);
        CL_QPOOL_DESTROY(&gc_post_queue_s.pool);
        cl_spinlock_release(&gc_post_queue_s.lock);

        cl_spinlock_destroy(&gc_post_queue_s.lock);
    }

    err = sdk_timer_put(g_global_timer_handle);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to put timer handle %u, err = [%s]\n",
                   g_global_timer_handle, SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    err = gc_db_deinit();
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinitialize GC DB, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    g_is_initialized = FALSE;

    sx_utils_debug_cmd_unregister_path("sync fence send <slow|fast>");

    sx_utils_debug_cmd_unregister_path("gc flush "GC_RESOURCES_OPT);

    sx_utils_debug_cmd_unregister_path("gc post_q cleanup "GC_POST_Q_OPT);

    sx_utils_debug_cmd_unregister_path("gc count get "GC_RESOURCES_OPT);

    sx_utils_debug_cmd_unregister_path("gc queue dump "GC_RESOURCES_OPT);


    SX_LOG_DBG("Deinitialized GC module\n");

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_object_init(gc_object_type_t                   object_type,
                                 const gc_object_type_attributes_t *object_attr,
                                 gc_object_completion_pfn           completion_cb,
                                 gc_object_post_completion_pfn      post_completion_cb)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t  rollback_err = SX_UTILS_STATUS_SUCCESS;
    sdk_timer_handle_t timer_handle = 0;
    gc_object_type_t  *object_context = NULL;
    boolean_t          db_initialized = FALSE;
    boolean_t          timer_received = FALSE;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    if (object_attr == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("object_attr is NULL\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    err = __validate_object_attributes(object_attr);
    if (SX_UTILS_CHECK_FAIL(err)) {
        goto out;
    }

    err = gc_db_object_init(object_type, object_attr,
                            completion_cb,
                            post_completion_cb,
                            &object_context);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to initialize object type %s in DB, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }
    db_initialized = TRUE;
    CL_ASSERT(object_context);

    err = sdk_timer_get(SX_UTILS_INT_CMD_GC_ACTIVATE_BACKGROUND_SET_E,
                        SDK_TIMER_TYPE_ONE_SHOT, object_context,
                        sizeof(*object_context),
                        SX_UTILS_LOW_PRIO_BUF_E,
                        &timer_handle);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get timer handle for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }
    timer_received = TRUE;

    err = gc_db_object_timer_handle_set(object_type, timer_handle);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set timer handle %u to object type %s, err = %s\n",
                   timer_handle,
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    SX_LOG_DBG("Initialized GC object type %s\n", GC_OBJECT_TYPE_STR(object_type));

out:
    if (SX_UTILS_CHECK_FAIL(err)) {
        if (timer_received) {
            rollback_err = sdk_timer_put(timer_handle);
            if (SX_UTILS_CHECK_FAIL(rollback_err)) {
                SX_LOG_ERR("Failed to put timer handle %u, err = [%s]\n",
                           timer_handle, SX_UTILS_STATUS_MSG(rollback_err));
            }
        }
        if (db_initialized) {
            rollback_err = gc_db_object_deinit(object_type);
            if (SX_UTILS_CHECK_FAIL(rollback_err)) {
                SX_LOG_ERR("Failed to deinit object type %s in DB, err = [%s]\n",
                           GC_OBJECT_TYPE_STR(object_type),
                           SX_UTILS_STATUS_MSG(rollback_err));
            }
        }
    }
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_object_deinit(gc_object_type_t object_type)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    sdk_timer_handle_t timer_handle = 0;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    err = __process_queue_sync(object_type, MAX_PROCESS_SIZE);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to synchronously process queue for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    err = gc_db_object_timer_handle_get(object_type, &timer_handle);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get timer handle for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    err = sdk_timer_put(timer_handle);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to put timer handle %u, err = [%s]\n",
                   timer_handle, SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    err = gc_db_object_deinit(object_type);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinit object type %s in DB, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    SX_LOG_DBG("Deinitialized GC object type %s\n", GC_OBJECT_TYPE_STR(object_type));

out:
    SX_LOG_EXIT();
    return err;
}

static boolean_t __subtype_valid(gc_object_type_t object_type, gc_object_subtype_t subtype)
{
    switch (object_type) {
    case GC_OBJECT_TYPE_KVD_LINEAR:
        switch (subtype) {
        case GC_OBJECT_SUBTYPE_RATR_RTDP:
        case GC_OBJECT_SUBTYPE_MPLS_NHLFE:
        case GC_OBJECT_SUBTYPE_ACL_ACTION_SET:
        case GC_OBJECT_SUBTYPE_PPBD_HMCB:
        case GC_OBJECT_SUBTYPE_MPLS_ILM:
        case GC_OBJECT_SUBTYPE_RIGR_V2:
        case GC_OBJECT_SUBTYPE_RPF_GROUP:
        case GC_OBJECT_SUBTYPE_IPV6:
        case GC_OBJECT_SUBTYPE_TNUMT:
        case GC_OBJECT_SUBTYPE_NONE:
            return TRUE;

        default:
            return FALSE;
        }
        break;

    default:
        return (subtype == GC_OBJECT_SUBTYPE_NONE);
    }
}

sx_utils_status_t gc_object_push(gc_object_type_t    object_type,
                                 const void         *gc_context,
                                 gc_state_t          state,
                                 uint32_t            size,
                                 gc_object_subtype_t subtype,
                                 uint32_t            start_index,
                                 gc_handle_t        *gc_handle)
{
    sx_utils_status_t           err = SX_UTILS_STATUS_SUCCESS;
    gc_object_type_attributes_t object_attr;
    uint32_t                    seq_num = 0;
    uint32_t                    alt_seq_num = 0;
    uint32_t                    total_size = 0;
    sdk_timer_handle_t          timer_handle = 0;
    boolean_t                   timer_started = FALSE;
    uint32_t                    utilization = 0;
    uint32_t                    process_amount = 0;

    SX_LOG_ENTER();

    M_GEN_UTILS_MEM_CLR(object_attr);

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    if (!GC_STATE_CHECK_RANGE(state)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid GC state %u given\n", state);
        goto out;
    }

    if (!GC_OBJECT_SUBTYPE_CHECK_RANGE(subtype)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object subtype %u given\n", subtype);
        goto out;
    }

    if (state != GC_STATE_PENDING_FENCE) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Object GC state must be PENDING_FENCE when pushing to queue, given %s\n",
                   GC_STATE_STR(state));
        goto out;
    }

    if (!__subtype_valid(object_type, subtype)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Given subtype %s is not a valid subtype of object type %s\n",
                   GC_OBJECT_SUBTYPE_STR(subtype),
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    err = gc_db_object_type_attributes_get(object_type, &object_attr);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get object attributes for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if (object_attr.fence_type == GC_FENCE_TYPE_SLOW) {
        seq_num = g_slow_fence_seq_num;
    } else if (object_attr.fence_type == GC_FENCE_TYPE_FAST) {
        seq_num = g_fast_fence_seq_num;
        alt_seq_num = g_slow_fence_seq_num;
    }

    /* Cleanup the queue if needed before pushing a new one*/
    if ((g_gc_params.utilization_mid > 0) && (object_attr.max_object_count > 0)) {
        err = gc_db_object_type_total_size_get(object_type, &total_size);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get GC object total size for object type %s, err = [%s]\n",
                       GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
            goto out;
        }
        utilization = (uint32_t)(double)((total_size) * 100.0 / object_attr.max_object_count);
        if (utilization > g_gc_params.utilization_mid) {
            process_amount = object_attr.max_object_count / 10;
            /* If max count < 10, make sure we process something*/
            process_amount = (process_amount == 0) ? 1 : process_amount;
        } else {
            process_amount = 0;
        }

        if (process_amount > 0) {
            SX_LOG_DBG("Triggering Sync fence on Delete: Utilization [%u] for Object [%s] process amount [%u]\n",
                       utilization,
                       GC_OBJECT_TYPE_STR(object_type),
                       process_amount);
            err = __process_queue_sync(object_type, process_amount);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed in synchronous global queue processing, err = [%s]\n",
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }
            if (g_gc_ops.gc_delay_completion_pfn(object_type)) {
                err = gc_post_queue_cleanup_amount(FALSE, GC_OBJECT_SUBTYPE_NONE, process_amount);
                if (SX_UTILS_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to process GC post queue: err = [%s]\n",
                               SX_UTILS_STATUS_MSG(err));
                    goto out;
                }
            }
        }
    }


    err = gc_db_queue_push(object_type, state, seq_num, alt_seq_num, gc_context, size,
                           subtype, start_index, gc_handle);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to push object type %s to GC queue, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if (object_attr.immediate_fence_needed == TRUE) {
        SX_LOG_DBG("Triggering Sync Fence for %s object type\n", GC_OBJECT_TYPE_STR(object_type));
        __process_queue_sync(object_type, MAX_PROCESS_SIZE);
        goto out;
    }

    err = gc_db_object_type_total_size_get(object_type, &total_size);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get GC object total size for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    /* Check if we've exceeded the per-object threshold as a result of this
     * push. If we have, we need to activate the per-object GC.
     */
    if (total_size > object_attr.per_object_threshold) {
        err = gc_db_object_timer_started_get(object_type, &timer_started);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get timer started field for object type %s, err = [%s]\n",
                       GC_OBJECT_TYPE_STR(object_type),
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        if (timer_started) {
            goto out;
        }

        SX_LOG_DBG("%s threshold passed: object_queue_cnt = %u\n",
                   GC_OBJECT_TYPE_STR(object_type),
                   total_size);

        err = gc_db_object_timer_handle_get(object_type, &timer_handle);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get timer handle for object type %s, err = [%s]\n",
                       GC_OBJECT_TYPE_STR(object_type),
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        /* Set the timer to expire immediately. This is equivalent to pushing a
         * GC activation job to the queue right now.
         */
        err = sdk_timer_start(timer_handle, 0);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to start timer for handle %u, err = [%s]\n",
                       timer_handle, SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        err = gc_db_object_timer_started_set(object_type, TRUE);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set timer started field for object type %s, err = [%s]\n",
                       GC_OBJECT_TYPE_STR(object_type),
                       SX_UTILS_STATUS_MSG(err));
        }
    }


out:
    if (err == SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_DBG("Pushed object of type %s (size %u) to GC queue\n",
                   GC_OBJECT_TYPE_STR(object_type), size);
    }
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_activate(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t err2 = SX_UTILS_STATUS_SUCCESS;
    gc_fence_state_t  fence_state = 0;
    boolean_t         timer_started = FALSE;


    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    SX_LOG_DBG("Activating global GC queue\n");

    if (g_curr_fence != GC_FENCE_TYPE_NONE) {
        err = __check_fence_async(g_global_timer_handle, &fence_state,
                                  &timer_started);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in performing asynchronous fence check, err = [%s]\n",
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        if (fence_state == GC_FENCE_STATE_ONGOING) {
            goto out;
        }
    }

    err = __process_queue_async(TRUE, GC_OBJECT_TYPE_MAX + 1,
                                g_global_timer_handle, &timer_started);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in processing global GC queue, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

out:
    if (!timer_started) {
        SX_LOG_WRN("Global timer not reset when completing GC cycle! Starting with default: %us\n",
                   g_gc_params.gc_timer_interval);
        err2 = sdk_timer_start(g_global_timer_handle,
                               g_gc_params.gc_timer_interval * 1000);
        if (SX_UTILS_CHECK_FAIL(err2)) {
            SX_LOG_ERR("Failed to start GC timer for handle %u, err = [%s]\n",
                       g_global_timer_handle, SX_UTILS_STATUS_MSG(err2));
        }
    }
    return err;
}


sx_utils_status_t gc_completion_activate(void)
{
    sx_utils_status_t             err = SX_UTILS_STATUS_SUCCESS;
    gc_object_data_t              object_data;
    gc_object_type_attributes_t   object_attr;
    gc_object_completion_pfn      completion_cb;
    gc_object_post_completion_pfn post_completion_cb;
    uint32_t                      hw_operation_cnt = 0;
    gc_fence_state_t              fence_state;


    M_GEN_UTILS_MEM_CLR(object_data);
    M_GEN_UTILS_MEM_CLR(object_attr);
    M_GEN_UTILS_MEM_CLR(completion_cb);
    M_GEN_UTILS_MEM_CLR(post_completion_cb);

    CL_ASSERT(g_gc_ops.gc_fence_pfn);
    CL_ASSERT(g_gc_ops.gc_delay_completion_pfn);
    CL_ASSERT(g_gc_ops.gc_fence_state_read_pfn);

    /* Check Fence state since it would have been triggered by the activate
    *  If it is completed, reset fence state and update sequence numbers */
    if (g_curr_fence != GC_FENCE_TYPE_NONE) {
        err = g_gc_ops.gc_fence_state_read_pfn(&fence_state);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get fence state, err = [%s]\n",
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        if (fence_state == GC_FENCE_STATE_NONE) {
            if (g_curr_fence == GC_FENCE_TYPE_SLOW) {
                g_slow_fence_seq_num++;
            } else { /* GC_FENCE_TYPE_FAST */
                CL_ASSERT(g_curr_fence == GC_FENCE_TYPE_FAST);
                g_fast_fence_seq_num++;
            }
            g_curr_fence = GC_FENCE_TYPE_NONE;
        }
    }

    err = gc_db_global_queue_top(&object_data);
    while (err != SX_UTILS_STATUS_ENTRY_NOT_FOUND) {
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get top of GC queue, err = [%s]\n",
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        err = gc_db_object_type_attributes_get(object_data.object_type, &object_attr);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get attributes for object type %s, err = [%s]\n",
                       GC_OBJECT_TYPE_STR(object_data.object_type), SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        if ((object_attr.fence_type == GC_FENCE_TYPE_SLOW) &&
            (object_data.seq_num >= g_slow_fence_seq_num)) {
            goto out;
        } else if ((object_attr.fence_type == GC_FENCE_TYPE_FAST) &&
                   ((object_data.seq_num >= g_fast_fence_seq_num) &&
                    (object_data.alt_seq_num >= g_slow_fence_seq_num))) {
            goto out;
        } else {
            err = gc_db_object_completion_cb_get(object_data.object_type, &completion_cb, &post_completion_cb);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to get completion callback for object type %s, err = [%s]\n",
                           GC_OBJECT_TYPE_STR(object_data.object_type),
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            /* Some objects require additional post-processing before completion.
             * This is determined based on chip type and object type.
             */
            if (!g_gc_ops.gc_delay_completion_pfn(object_data.object_type)) {
                if (completion_cb) {
                    err = completion_cb(object_data.gc_context);
                    if (SX_UTILS_CHECK_FAIL(err)) {
                        SX_LOG_ERR("Completion callback for object type %s (sequence number %u) failed, err = [%s]\n",
                                   GC_OBJECT_TYPE_STR(object_data.object_type),
                                   object_data.seq_num, SX_UTILS_STATUS_MSG(err));
                        goto out;
                    }

                    if (object_attr.hw_operation_needed) {
                        hw_operation_cnt++;
                    }
                }
            } else {
                err = gc_post_queue_push(&object_data,
                                         completion_cb,
                                         post_completion_cb);
                if (SX_UTILS_CHECK_FAIL(err)) {
                    SX_LOG_ERR(
                        "Failed to push the element #[%d] with type [%s] to GC post processing queue, err[%s]\n",
                        object_data.seq_num,
                        GC_OBJECT_TYPE_STR(object_data.object_type),
                        SX_UTILS_STATUS_MSG(err));
                    goto out;
                }
            }

            err = gc_db_global_queue_pop(NULL);

            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to pop entry from GC queue, err = [%s]\n",
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            SX_LOG_DBG("Removed object of type %s from GC queue\n",
                       GC_OBJECT_TYPE_STR(object_data.object_type));
        }

        if (hw_operation_cnt >= g_gc_params.max_hw_operations) {
            SX_LOG_DBG("HW operation count exceeds max\n");
            break;
        }

        err = gc_db_global_queue_top(&object_data);
    }


out:
    return err;
}


sx_utils_status_t gc_object_check_thresholds(gc_object_type_t object_type, uint32_t free_object_cnt)
{
    sx_utils_status_t           err = SX_UTILS_STATUS_SUCCESS;
    uint32_t                    total_size = 0;
    gc_object_type_attributes_t object_attr;
    sdk_timer_handle_t          timer_handle = 0;
    boolean_t                   timer_started = FALSE;

    SX_LOG_ENTER();

    M_GEN_UTILS_MEM_CLR(object_attr);

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    err = gc_db_object_timer_started_get(object_type, &timer_started);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get timer started field for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if (timer_started) {
        SX_LOG_DBG("Timer for object type %s already started, aborting threshold check\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    err = gc_db_object_type_total_size_get(object_type, &total_size);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get GC object count for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    err = gc_db_object_type_attributes_get(object_type, &object_attr);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get attributes of object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if ((total_size > object_attr.per_object_threshold) ||
        ((free_object_cnt < object_attr.free_objects_threshold) &&
         (total_size > 0))) {
        SX_LOG_DBG("%s threshold passed: object_queue_cnt = %u, free_object_cnt = %u\n",
                   GC_OBJECT_TYPE_STR(object_type),
                   total_size, free_object_cnt);
        /* Update threshold counter according to object type */
        gc_object_threshold_cnt_s[object_type - GC_OBJECT_TYPE_MIN]++;

        err = gc_db_object_timer_handle_get(object_type, &timer_handle);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get timer handle for object type %s, err = [%s]\n",
                       GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        /* Set the timer to expire immediately. This is equivalent to pushing a
         * GC activation job to the queue right now.
         */
        err = sdk_timer_start(timer_handle, 0);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to start timer for handle %u, err = [%s]\n",
                       timer_handle, SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        err = gc_db_object_timer_started_set(object_type, TRUE);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set timer started field for object type %s, err = [%s]\n",
                       GC_OBJECT_TYPE_STR(object_type),
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_object_activate(gc_object_type_t object_type)
{
    sx_utils_status_t           err = SX_UTILS_STATUS_SUCCESS;
    gc_object_type_attributes_t object_attr;
    sdk_timer_handle_t          timer_handle = 0;
    gc_fence_state_t            fence_state = 0;
    boolean_t                   object_initialized = FALSE;

    SX_LOG_ENTER();

    M_GEN_UTILS_MEM_CLR(object_attr);

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    err = gc_db_object_type_is_initialized(object_type, &object_initialized);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get initialized status for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if (!object_initialized) {
        SX_LOG_DBG("Object %s is not initialized - aborting queue activation\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    err = gc_db_object_type_attributes_get(object_type, &object_attr);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get attributes for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    err = gc_db_object_timer_handle_get(object_type, &timer_handle);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get timer handle for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    err = gc_db_object_timer_started_set(object_type, FALSE);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set timer started field for object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    SX_LOG_DBG("Activating GC queue for object type %s\n",
               GC_OBJECT_TYPE_STR(object_type));

    if (g_curr_fence != GC_FENCE_TYPE_NONE) {
        err = __check_fence_async(timer_handle, &fence_state, NULL);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in performing asynchronous fence check, err = [%s]\n",
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        if (fence_state == GC_FENCE_STATE_ONGOING) {
            goto out;
        }
    }

    err = __process_queue_async(FALSE, object_type, timer_handle, NULL);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in processing GC queue of object %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_object_fence(gc_fence_type_t fence_type)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    if (!GC_FENCE_TYPE_CHECK_RANGE(fence_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid fence type %u given\n", fence_type);
        goto out;
    }

    if (fence_type == GC_FENCE_TYPE_NONE) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Fence type must be SLOW or FAST\n");
        goto out;
    }

    err = __do_sync_fence(fence_type);
    if (SX_UTILS_CHECK_FAIL(err)) {
        goto out;
    }

    SX_LOG_DBG("Performed synchronous %s fence\n", GC_FENCE_TYPE_STR(fence_type));

out:
    SX_LOG_EXIT();
    return err;
}

static void __fence_send_cb(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;
    gc_fence_type_t   fence_type = GC_FENCE_TYPE_NONE;

    UNUSED_PARAM(handler_context);

    if (argc != 1) {
        dbg_utils_print(stream, "Invalid params. valid values: <slow|fast>\n");
        return;
    }

    if (strcmp(argv[0], "slow") == 0) {
        fence_type = GC_FENCE_TYPE_SLOW;
    } else if (strcmp(argv[0], "fast") == 0) {
        fence_type = GC_FENCE_TYPE_FAST;
    } else {
        dbg_utils_print(stream, "Invalid param %s. valid values: <slow|fast>\n", argv[0]);
        return;
    }

    status = gc_object_fence(fence_type);

    if (status == SX_UTILS_STATUS_SUCCESS) {
        fprintf(stream, "Done sync fence successfully\n");
    } else {
        fprintf(stream, "Failed to do sync fence\n");
    }
}

sx_utils_status_t gc_object_process_queue_amount(gc_object_type_t object_type, uint32_t process_amount)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    SX_LOG_DBG("Starting synchronous processing of GC queue of type %s\n",
               GC_OBJECT_TYPE_STR(object_type));

    err = __process_queue_sync(object_type, process_amount);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in synchronous global queue processing, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_object_process_queue(gc_object_type_t object_type)
{
    return gc_object_process_queue_amount(object_type, MAX_PROCESS_SIZE);
}

sx_utils_status_t gc_debug_dump(FILE *stream)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    const char       *fence_str = NULL;
    uint16_t          i;
    char              type_buf[128];

    SX_LOG_ENTER();

    if (stream == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("stream is NULL\n");
        goto out;
    }

    dbg_utils_pprinter_module_header_print(stream, "Garbage collector module");
    dbg_utils_pprinter_field_print(stream, "Module initialized", &g_is_initialized, PARAM_BOOL_E);

    if (!g_is_initialized) {
        goto out;
    }

    dbg_utils_pprinter_field_print(stream, "GC timer interval", &g_gc_params.gc_timer_interval, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Fast fence timer interval",
                                   &g_gc_params.fast_fence_timer_interval,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Slow fence timer interval",
                                   &g_gc_params.slow_fence_timer_interval,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Max HW operations", &g_gc_params.max_hw_operations, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Fast fence sequence number", &g_fast_fence_seq_num, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Slow fence sequence number", &g_slow_fence_seq_num, PARAM_UINT32_E);
    fence_str = GC_FENCE_TYPE_STR(g_curr_fence);
    dbg_utils_pprinter_field_print(stream, "Current fence state", fence_str, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream, "Global timer handle", &g_global_timer_handle, PARAM_UINT32_E);

    err = gc_db_dump(stream);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to generate GC DB dump, err = [%s]\n", SX_UTILS_STATUS_MSG(err));
        err = SX_UTILS_STATUS_SUCCESS;
        goto out;
    }

    /* Generate GC post queue dump if the queue is supported */
    if (g_gc_ops.gc_handle_post_queue_pfn != NULL) {
        err = gc_post_queue_dump(stream);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to generate GC post queue dump, err = [%s]\n", SX_UTILS_STATUS_MSG(err));
            err = SX_UTILS_STATUS_SUCCESS;
            goto out;
        }
    }

    /* Print GC threshold counters  */
    dbg_utils_pprinter_general_header_print(stream, "GC threshold pass counters");
    for (i = 0; i < GC_OBJECT_TYPE_NUMBER; i++) {
        if (i >= GC_OBJECT_TYPE_UENGINE_UTCAM_RANGE_START) {
            /*make the object type GC_OBJECT_TYPE_UENGINE_UTCAM unique in json*/
            snprintf(type_buf,
                     sizeof(type_buf),
                     "%s%d",
                     GC_OBJECT_TYPE_STR(i),
                     i - GC_OBJECT_TYPE_UENGINE_UTCAM_RANGE_START);
            dbg_utils_pprinter_field_print(stream,
                                           type_buf,
                                           &gc_object_threshold_cnt_s[i],
                                           PARAM_UINT32_E);
        } else {
            dbg_utils_pprinter_field_print(stream,
                                           GC_OBJECT_TYPE_STR(i + GC_OBJECT_TYPE_MIN),
                                           &gc_object_threshold_cnt_s[i],
                                           PARAM_UINT32_E);
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_object_remove(gc_handle_t gc_handle)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    err = gc_db_object_remove(gc_handle);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to remove GC handle, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    SX_LOG_DBG("Removed GC handle\n");

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    gc_db_log_verbosity_level_set(verbosity_level);

    return err;
}

sx_utils_status_t gc_context_get(gc_handle_t gc_handle, void** gc_context)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    status = gc_db_context_get(gc_handle, gc_context);

    return status;
}

sx_utils_status_t gc_lazy_delete_mode_get(boolean_t* lazy_del_mode_p)
{
    sx_utils_status_t status = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (lazy_del_mode_p == NULL) {
        status = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("lazy_del_mode_p is NULL\n");
        goto out;
    }

    *lazy_del_mode_p = g_gc_params.use_sw_lazy_delete;

out:
    SX_LOG_EXIT();
    return status;
}

sx_utils_status_t gc_clean(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    gc_object_type_t  object_type;
    boolean_t         is_initialized = FALSE;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    SX_LOG_DBG("Starting synchronous processing of GC queue of all type \n");

    for (object_type = GC_OBJECT_TYPE_MIN; object_type < GC_OBJECT_TYPE_MAX; object_type++) {
        err = gc_db_object_type_is_initialized(object_type, &is_initialized);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in object type initialization check, err = [%s]\n",
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }
        if (is_initialized) {
            err = __process_queue_sync(object_type, MAX_PROCESS_SIZE);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed in synchronous global queue processing, err = [%s]\n",
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_object_type_total_size_get(gc_object_type_t object_type, uint32_t *total_size)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC module is not initialized\n");
        goto out;
    }

    if (!GC_OBJECT_TYPE_CHECK_RANGE(object_type)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given\n", object_type);
        goto out;
    }

    err = gc_db_object_type_total_size_get(object_type, total_size);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get object type %s total size, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(object_type), SX_UTILS_STATUS_MSG(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

pthread_t gc_post_queue_timer_thread_tid()
{
    if (g_gc_ops.gc_handle_post_queue_pfn != NULL) {
        return post_queue_thread_s.osd.id;
    }
    return (pthread_t)NULL;
}

cl_thread_t* gc_post_queue_timer_thread_obj()
{
    if (g_gc_ops.gc_handle_post_queue_pfn != NULL) {
        return &post_queue_thread_s;
    }
    return (cl_thread_t*)NULL;
}

void gc_post_queue_timer_thread_exit_signal_issued(boolean_t signal_issued)
{
    post_queue_thread_params_s.stop_thread = signal_issued;
}


static void __gc_post_queue_timer_thread(void *context)
{
    sx_utils_status_t util_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          timer_interval = 0;
    /** Caching the bp_ctl DB entry for this thread.
     *  This variable is used due to performance concerns.
     *  It allows accessing the Process Background DB entry of the current thread
     *  without requesting the entry each time from the DB. One more point:
     *  that in such a way, we omit the continuous need to acquire the spinlock.*/
    cl_dbg_bp_ctl_db_entry_t *bp_ctl_db_entry_p = NULL;
    struct timeval            timeout;
    int                       hc_fd = -1;
    fd_set                    read_fds;
    int                       rc = 0;


    UNUSED_PARAM(context);
    SX_LOG_ENTER();


    timer_interval = post_queue_thread_params_s.timer_interval * 1000;
    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, TRUE);
    cl_dbg_bp_ctl_thread_period_register(&bp_ctl_db_entry_p, &timer_interval, 1);

    if (bp_ctl_db_entry_p != NULL) {
        hc_fd = bp_ctl_db_entry_p->health_check_fd;
    }
    memset(&timeout, 0, sizeof(timeout));
    while (TRUE) {
        timeout.tv_usec = cl_dbg_bp_ctl_thread_period_get(bp_ctl_db_entry_p, timer_interval);
        if (hc_fd < 0) {
            usleep(timeout.tv_usec);
        } else {
            /* This code related to Health check Thread monitor. Indicate once this thread is a live*/
            FD_ZERO(&read_fds);
            FD_SET(hc_fd, &read_fds);
            /* Thread is blocking until timeout expired( the original thread "usleep" time) OR
             *  health check FD got signal*/
            cl_fd_wait_on(hc_fd, &read_fds, NULL, &timeout, &rc);
            /* in case its first loop and we did not invoke from timeout we must
             * sleep to make sure gc g_is_initialized*/

            if (rc < 0) {
                SX_LOG_ERR("GC POST QUEUE TIMER thread: select() failed [err=%d]\n", rc);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
            }
            /* In case hc_fd is triggered this function will update that this thread is alive */
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, FALSE);
        }
        cl_dbg_bp_ctl_thread_sync(&bp_ctl_db_entry_p);

        /* check if we need to stop the thread */
        if (post_queue_thread_params_s.stop_thread == TRUE) {
            SX_LOG_NTC(
                "Thread __gc_post_queue_timer_thread is gracefully ending.\n");
            break;
        }
        /*Go to the gc handle only if GC is  initialized */
        if (g_is_initialized != TRUE) {
            continue;
        }
        /* Call the handle post queue callback */
        util_err = gc_handle_post_queue();
        if (SX_UTILS_CHECK_FAIL(util_err)) {
            SX_LOG_ERR("Failed to handle gc post queue, err=[%s]\n",
                       SX_UTILS_STATUS_MSG(util_err));
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
            break;
        }
    }
    SX_LOG_EXIT();
    return;
}


sx_utils_status_t gc_post_queue_push(gc_object_data_t             *object_data_p,
                                     gc_object_completion_pfn      completion_cb,
                                     gc_object_post_completion_pfn post_completion_cb)
{
    sx_utils_status_t      err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t            cl_err = CL_SUCCESS;
    cl_pool_item_t        *p_pool_item = NULL;
    gc_post_queue_entry_t *p_object = NULL;
    gc_object_type_t       object_type = GC_OBJECT_TYPE_KVD_LINEAR;
    boolean_t              is_initialized = FALSE;

    SX_LOG_ENTER();

    /* Validate input parameters */
    if (g_is_initialized != TRUE) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC is not initialized\n");
        goto out;
    }

    if (gen_utils_check_pointer(object_data_p, "object_data_p")) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (gen_utils_check_pointer(completion_cb, "completion_cb")) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (gen_utils_check_pointer(post_completion_cb, "post_completion_cb")) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Post queue supports only KVD objects */
    object_type = object_data_p->object_type;
    if (object_type != GC_OBJECT_TYPE_KVD_LINEAR) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object type %u given. Post queue supports only KVD objects.\n", object_type);
        goto out;
    }

    err = gc_db_object_type_is_initialized(object_type, &is_initialized);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get DB status for object type %s\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    } else if (!is_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Object DB for object type %s is not initialized\n",
                   GC_OBJECT_TYPE_STR(object_type));
        goto out;
    }

    /* Try to get new item from the post queue pool */
    cl_spinlock_acquire(&gc_post_queue_s.lock);

    p_pool_item = cl_qpool_get(&gc_post_queue_s.pool);
    if (!p_pool_item) {
        cl_err = cl_qpool_grow(&gc_post_queue_s.pool, GC_DEFAULT_GROW_SIZE);
        if (cl_err != CL_SUCCESS) {
            err = SX_UTILS_STATUS_ERROR;
            SX_LOG_ERR("Failed to grow GC post queue pool by %u entries, cl_err = [%s]\n",
                       GC_DEFAULT_GROW_SIZE, CL_STATUS_MSG(cl_err));
            goto release_lock;
        }

        p_pool_item = cl_qpool_get(&gc_post_queue_s.pool);
        if (!p_pool_item) {
            err = SX_UTILS_STATUS_ERROR;
            SX_LOG_ERR("No memory left in GC post queue qpool\n");
            goto release_lock;
        }
    }

    /* Add new element to the post queue */
    p_object = PARENT_STRUCT(p_pool_item, gc_post_queue_entry_t, pool_item);

    p_object->data.object_type = object_type;
    p_object->data.subtype = object_data_p->subtype;
    p_object->data.completion_cb = completion_cb;
    p_object->data.post_completion_cb = post_completion_cb;
    p_object->data.gc_context = object_data_p->gc_context;
    p_object->data.size = object_data_p->size;
    p_object->data.start_index = object_data_p->start_index;

    cl_qlist_insert_tail(&gc_post_queue_s.list, &p_object->list_item);
    gc_post_queue_s.total_size += object_data_p->size;
    gc_post_queue_s.size_per_subtype[object_data_p->subtype] += object_data_p->size;
    gc_post_queue_s.count_per_subtype[object_data_p->subtype]++;

release_lock:
    cl_spinlock_release(&gc_post_queue_s.lock);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_post_queue_top(gc_post_queue_data_t *data_p, boolean_t per_subtype,
                                    gc_object_subtype_t gc_subtype)
{
    sx_utils_status_t      err = SX_UTILS_STATUS_SUCCESS;
    const cl_list_item_t  *p_end = NULL;
    cl_list_item_t        *p_iter = NULL;
    gc_post_queue_entry_t *p_object = NULL;

    SX_LOG_ENTER();

    /* Validate input parameters */
    if (g_is_initialized != TRUE) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC is not initialized\n");
        goto out;
    }

    if (gen_utils_check_pointer(data_p, "data_p")) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((per_subtype == TRUE) &&
        (!GC_OBJECT_SUBTYPE_CHECK_RANGE(gc_subtype))) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object subtype %u given\n", gc_subtype);
        goto out;
    }

    /* Try to get the first element in the queue */
    cl_spinlock_acquire(&gc_post_queue_s.lock);

    p_end = cl_qlist_end(&gc_post_queue_s.list);
    p_iter = cl_qlist_head(&gc_post_queue_s.list);

    while (p_iter != p_end) {
        p_object = PARENT_STRUCT(p_iter, gc_post_queue_entry_t, list_item);

        if ((per_subtype == FALSE) ||
            (p_object->data.subtype == gc_subtype)) {
            *data_p = p_object->data;
            goto release_lock;
        }

        /* iterate through GC post queue elements */
        p_iter = cl_qlist_next(p_iter);
    }

    err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    if (per_subtype == FALSE) {
        SX_LOG_INF("GC post queue is empty.\n");
    } else {
        SX_LOG_INF("GC post queue doesn't contain elements with subtype %s.\n",
                   GC_OBJECT_SUBTYPE_STR(gc_subtype));
    }

release_lock:
    cl_spinlock_release(&gc_post_queue_s.lock);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_post_queue_pop(gc_post_queue_data_t *data_p, boolean_t per_subtype,
                                    gc_object_subtype_t gc_subtype)
{
    sx_utils_status_t      err = SX_UTILS_STATUS_SUCCESS;
    const cl_list_item_t  *p_end = NULL;
    cl_list_item_t        *p_iter = NULL;
    gc_post_queue_entry_t *p_object = NULL;

    SX_LOG_ENTER();

    /* Validate input parameters */
    if (g_is_initialized != TRUE) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC is not initialized\n");
        goto out;
    }

    if ((per_subtype == TRUE) &&
        (!GC_OBJECT_SUBTYPE_CHECK_RANGE(gc_subtype))) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object subtype %u given\n", gc_subtype);
        goto out;
    }

    /* Try to get the first element in the queue */
    cl_spinlock_acquire(&gc_post_queue_s.lock);

    p_end = cl_qlist_end(&gc_post_queue_s.list);
    p_iter = cl_qlist_head(&gc_post_queue_s.list);

    while (p_iter != p_end) {
        p_object = PARENT_STRUCT(p_iter, gc_post_queue_entry_t, list_item);

        if ((per_subtype == FALSE) ||
            (p_object->data.subtype == gc_subtype)) {
            if (data_p != NULL) {
                *data_p = p_object->data;
            }
            gc_post_queue_s.total_size -= p_object->data.size;
            gc_post_queue_s.size_per_subtype[p_object->data.subtype] -= p_object->data.size;
            gc_post_queue_s.count_per_subtype[p_object->data.subtype]--;

            cl_qlist_remove_item(&gc_post_queue_s.list, p_iter);
            cl_qpool_put(&gc_post_queue_s.pool, &p_object->pool_item);

            goto release_lock;
        }

        /* iterate through GC post queue elements */
        p_iter = cl_qlist_next(p_iter);
    }

    err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    if (per_subtype == FALSE) {
        SX_LOG_INF("GC post queue is empty.\n");
    } else {
        SX_LOG_INF("GC post queue doesn't contain elements with subtype %s.\n",
                   GC_OBJECT_SUBTYPE_STR(gc_subtype));
    }

release_lock:
    cl_spinlock_release(&gc_post_queue_s.lock);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_handle_post_queue()
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    boolean_t         is_post_queue_empty = TRUE;
    boolean_t         is_post_queue_on_pause = FALSE;
    uint32_t          bg_limit = post_queue_thread_params_s.bg_limit;


    SX_LOG_ENTER();

    /* Validate input parameters */
    if (g_is_initialized != TRUE) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC is not initialized for gc_post_queue\n");
        goto out;
    }

    if (g_gc_ops.gc_handle_post_queue_pfn == NULL) {
        /* post queue is not supported */
        goto out;
    }

    /* Check if GC post queue isn't empty */
    err = gc_post_queue_is_empty(&is_post_queue_empty);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot check if GC post queue is empty, err=[%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    /* Check if GC post queue isn't locked */
    err = gc_post_queue_is_on_pause(&is_post_queue_on_pause);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot check if GC post queue is on pause, err=[%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if ((is_post_queue_empty == TRUE) ||
        (is_post_queue_on_pause == TRUE)) {
        /* Do nothing */
        goto out;
    }

    err = g_gc_ops.gc_handle_post_queue_pfn(bg_limit);
    if (err == SX_UTILS_STATUS_NO_RESOURCES) {
        SX_LOG_WRN("g_gc_ops.gc_handle_post_queue_pfn failed with %s\n",
                   SX_UTILS_STATUS_MSG(err));
    } else if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("g_gc_ops.gc_handle_post_queue_pfn failed with %s\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_post_queue_cleanup_amount(boolean_t           per_subtype,
                                               gc_object_subtype_t gc_subtype,
                                               uint32_t            cleanup_amount)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Validate input parameters */
    if (g_is_initialized != TRUE) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC is not initialized\n");
        goto out;
    }

    if (g_gc_ops.gc_handle_post_queue_cleanup_pfn == NULL) {
        /* post queue is not supported */
        goto out;
    }

    if ((per_subtype == TRUE) &&
        (!GC_OBJECT_SUBTYPE_CHECK_RANGE(gc_subtype))) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object subtype %u given\n", gc_subtype);
        goto out;
    }

    err = gc_post_queue_set_on_pause(TRUE);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to pause processing GC post queue, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    err = g_gc_ops.gc_handle_post_queue_cleanup_pfn(per_subtype, gc_subtype, cleanup_amount);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to process GC post queue of object subtype %s, err = [%s]\n",
                   GC_OBJECT_SUBTYPE_STR(gc_subtype),
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    err = gc_post_queue_set_on_pause(FALSE);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to resume processing GC post queue, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_post_queue_cleanup(boolean_t per_subtype, gc_object_subtype_t gc_subtype)
{
    return gc_post_queue_cleanup_amount(per_subtype, gc_subtype, MAX_PROCESS_SIZE);
}

sx_utils_status_t gc_post_queue_is_empty(boolean_t *is_empty_p)
{
    sx_utils_status_t     err = SX_UTILS_STATUS_SUCCESS;
    const cl_list_item_t *p_end = NULL;
    const cl_list_item_t *p_head = NULL;

    /* Validate input parameters */
    if (g_is_initialized != TRUE) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC is not initialized\n");
        goto out;
    }

    if (gen_utils_check_pointer(is_empty_p, "is_empty_p")) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Try to get the first element in the queue */
    cl_spinlock_acquire(&gc_post_queue_s.lock);

    p_end = cl_qlist_end(&gc_post_queue_s.list);
    p_head = cl_qlist_head(&gc_post_queue_s.list);

    if (p_head == p_end) {
        *is_empty_p = TRUE;
    } else {
        *is_empty_p = FALSE;
    }

    cl_spinlock_release(&gc_post_queue_s.lock);

out:
    return err;
}

sx_utils_status_t gc_post_queue_set_on_pause(boolean_t set_on_pause)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Validate input parameters */
    if (g_is_initialized != TRUE) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC is not initialized\n");
        goto out;
    }

    cl_spinlock_acquire(&gc_post_queue_s.lock);

    gc_post_queue_s.on_pause = set_on_pause;

    cl_spinlock_release(&gc_post_queue_s.lock);

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_post_queue_is_on_pause(boolean_t *is_on_pause_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    /* Validate input parameters */
    if (g_is_initialized != TRUE) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC is not initialized\n");
        goto out;
    }

    if (gen_utils_check_pointer(is_on_pause_p, "is_on_pause_p")) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    cl_spinlock_acquire(&gc_post_queue_s.lock);

    *is_on_pause_p = gc_post_queue_s.on_pause;

    cl_spinlock_release(&gc_post_queue_s.lock);

out:
    return err;
}

sx_utils_status_t gc_post_queue_size_get(boolean_t per_subtype, gc_object_subtype_t gc_subtype, uint32_t *total_size)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Validate input parameters */
    if (g_is_initialized != TRUE) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC is not initialized\n");
        goto out;
    }

    if ((per_subtype == TRUE) &&
        (!GC_OBJECT_SUBTYPE_CHECK_RANGE(gc_subtype))) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid object subtype %u given\n", gc_subtype);
        goto out;
    }

    if (total_size == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("total_size is NULL\n");
        goto out;
    }

    if (per_subtype != TRUE) {
        *total_size = gc_post_queue_s.total_size;
    } else {
        *total_size = gc_post_queue_s.size_per_subtype[gc_subtype];
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t gc_post_queue_dump(FILE *stream)
{
    sx_utils_status_t         err = SX_UTILS_STATUS_SUCCESS;
    gc_post_queue_data_t      data;
    uint32_t                  count = 0;
    const char               *object_subtype_str = NULL;
    gc_object_subtype_t       subtype = GC_OBJECT_SUBTYPE_NONE;
    dbg_utils_table_columns_t subtype_size_columns[] = {
        { "GC object subtype", 20, PARAM_STRING_E, NULL},
        { "Total Count", 15, PARAM_UINT32_E, NULL},
        { "Total Size", 15, PARAM_UINT32_E, NULL},
        {NULL, 0, 0, NULL}
    };

    SX_LOG_ENTER();

    M_GEN_UTILS_MEM_CLR(data);

    if (gen_utils_check_pointer(stream, "stream")) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    dbg_utils_pprinter_secondary_header_print(stream, "GC Post Queue");

    dbg_utils_pprinter_field_print(stream, "GC Post Queue timer interval (us)",
                                   &post_queue_thread_params_s.timer_interval, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Max KVD Utilization for background delete (%)",
                                   &post_queue_thread_params_s.bg_limit, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "GC Post Queue is on pause",
                                   &post_queue_thread_params_s.stop_thread, PARAM_BOOL_E);
    count = cl_qlist_count(&gc_post_queue_s.list);
    dbg_utils_pprinter_field_print(stream, "Object count", &count, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Total Size", &gc_post_queue_s.total_size, PARAM_UINT32_E);

    if (count > 0) {
        dbg_utils_pprinter_table_headline_print(stream, subtype_size_columns);

        for (subtype = GC_OBJECT_SUBTYPE_MIN; subtype <= GC_OBJECT_SUBTYPE_MAX; subtype++) {
            object_subtype_str = GC_OBJECT_SUBTYPE_STR(subtype);
            subtype_size_columns[0].data = object_subtype_str;
            subtype_size_columns[1].data = &gc_post_queue_s.count_per_subtype[subtype];
            subtype_size_columns[2].data = &gc_post_queue_s.size_per_subtype[subtype];

            dbg_utils_pprinter_table_data_line_print(stream, subtype_size_columns);
        }
    } else {
        dbg_utils_pprinter_print(stream, "GC Post Queue is empty");
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_utils_status_t gc_get_params(gc_init_params_t *gc_params_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Validate input parameters */
    if (g_is_initialized != TRUE) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC is not initialized\n");
        goto out;
    }

    if (gc_params_p == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("gc_params_p is NULL\n");
        goto out;
    }

    *gc_params_p = g_gc_params;

out:
    SX_LOG_EXIT();
    return err;
}
