/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#undef  __MODULE__
#define __MODULE__ GEN_UTILS

#include <sx/utils/bloom_filter.h>
#include "complib/cl_mem.h"

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local definitions
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/


sx_utils_status_t bloom_filter_init(IN bf_hash_func hash_func, IN uint32_t size, OUT bloom_filter_t **bf)
{
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((hash_func == NULL) || (bf == NULL)) {
        SX_LOG(SX_LOG_ERROR, "Null params were given\n");
        sx_utils_status = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    *bf = (bloom_filter_t*)cl_malloc(sizeof(bloom_filter_t));
    if (*bf == NULL) {
        SX_LOG(SX_LOG_ERROR, "Memory error while allocating bloom_filter\n");
        sx_utils_status = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }


    (*bf)->data = (uint16_t*)cl_calloc(size, sizeof(uint16_t));
    if ((*bf)->data == NULL) {
        sx_utils_status = SX_UTILS_STATUS_MEMORY_ERROR;
        SX_LOG(SX_LOG_ERROR, "Memory error while allocating bloom_filter data\n");
        goto mem_error;
    }

    (*bf)->hash_func = hash_func;
    (*bf)->size = size;
    (*bf)->is_initialized = TRUE;

    goto out;

mem_error:

    if (*bf) {
        cl_free(*bf);
    }

out:
    SX_LOG_EXIT();
    return sx_utils_status;
}


sx_utils_status_t bloom_filter_deinit(IN bloom_filter_t **bf)
{
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((bf == NULL) || (*bf == NULL)) {
        SX_LOG(SX_LOG_ERROR, "bloom_filter_deinit: Null param was given\n");
        sx_utils_status = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*bf)->is_initialized) {
        cl_free((*bf)->data);
        cl_free(*bf);
        *bf = NULL;
    }

out:
    SX_LOG_EXIT();
    return sx_utils_status;
}


sx_utils_status_t bloom_filter_size(IN const bloom_filter_t* bf, OUT uint16_t* size)
{
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((bf == NULL) || (size == NULL)) {
        SX_LOG(SX_LOG_ERROR, "bloom_filter_size: Null param was given\n");
        sx_utils_status = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    *size = bf->size;

out:
    SX_LOG_EXIT();
    return sx_utils_status;
}


sx_utils_status_t bloom_filter_increase(IN const bloom_filter_t *bf,
                                        IN const uint8_t        *key,
                                        IN uint32_t              key_size,
                                        OUT uint32_t            *res_index,
                                        OUT boolean_t           *is_first)
{
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    uint32_t          hash_res_index = 0;

    sx_utils_status = bloom_filter_calculate_res_index(bf,
                                                       key,
                                                       key_size,
                                                       &hash_res_index);
    if (SX_UTILS_STATUS_SUCCESS != sx_utils_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bloom_filter_calculate_res_index failed: when accessing bf\n");
        goto out;
    }

    sx_utils_status = bloom_filter_update_data(bf,
                                               hash_res_index,
                                               TRUE,
                                               is_first);
    if (SX_UTILS_STATUS_SUCCESS != sx_utils_status) {
        SX_LOG(SX_LOG_ERROR,
               "atcam_bloom_filter_update_erp_in_bulk failed: when accessing bf\n");
        goto out;
    }
    /* We only return the values to the caller who asked for them (gave non NULL values) */
    if (res_index) {
        *res_index = hash_res_index;
    }

out:
    SX_LOG_EXIT();
    return sx_utils_status;
}


/**
 *
 */
sx_utils_status_t bloom_filter_decrease(IN const bloom_filter_t *bf,
                                        IN const uint8_t        *key,
                                        IN uint32_t              key_size,
                                        OUT uint32_t            *res_index,
                                        OUT boolean_t           *is_last)
{
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    uint32_t          hash_res_index = 0;

    SX_LOG_ENTER();

    sx_utils_status = bloom_filter_calculate_res_index(bf,
                                                       key,
                                                       key_size,
                                                       &hash_res_index);
    if (SX_UTILS_STATUS_SUCCESS != sx_utils_status) {
        SX_LOG(SX_LOG_ERROR, "atcam_bloom_filter_calculate_res_index failed: when accessing bf\n");
        goto out;
    }

    sx_utils_status = bloom_filter_update_data(bf,
                                               hash_res_index,
                                               FALSE,
                                               is_last);
    if (SX_UTILS_STATUS_SUCCESS != sx_utils_status) {
        SX_LOG(SX_LOG_ERROR,
               "atcam_bloom_filter_update_erp_in_bulk failed: when accessing bf\n");
        goto out;
    }

    /* We only return the values to the caller who asked for them (gave non NULL values) */
    if (res_index) {
        *res_index = hash_res_index;
    }

out:
    SX_LOG_EXIT();
    return sx_utils_status;
}

sx_utils_status_t bloom_filter_calculate_res_index(IN const bloom_filter_t *bf,
                                                   IN const uint8_t        *key,
                                                   IN uint32_t              key_size,
                                                   OUT uint32_t            *res_index)
{
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    uint16_t          hash_res_index;


    if (!bf || !bf->is_initialized) {
        SX_LOG(SX_LOG_ERROR, "bloom_filter_calculate_res_index: module is not initialized\n");
        sx_utils_status = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if (key == NULL) {
        SX_LOG(SX_LOG_ERROR, "bloom_filter_calculate_res_index: Null param was given\n");
        sx_utils_status = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (res_index == NULL) {
        SX_LOG(SX_LOG_ERROR, "bloom_filter_calculate_res_index: Null param was given\n");
        sx_utils_status = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    hash_res_index = bf->hash_func(key, key_size) % bf->size;

    *res_index = hash_res_index;

out:
    SX_LOG_EXIT();
    return sx_utils_status;
}

sx_utils_status_t bloom_filter_update_data(IN const bloom_filter_t *bf,
                                           IN uint16_t              res_index,
                                           boolean_t                is_increase,
                                           boolean_t               *need_to_update_hw)
{
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();
    if (!bf || !bf->is_initialized) {
        SX_LOG(SX_LOG_ERROR, "bloom_filter_increase: module is not initialized\n");
        sx_utils_status = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if (need_to_update_hw) {
        *need_to_update_hw = FALSE;
    }

    if (is_increase) {
        if (bf->data[res_index] < UINT16_MAX) {
            (bf->data[res_index])++;
        } else {
            SX_LOG(SX_LOG_ERROR, "bloom_filter_update_data: bucket at %d is overflowed.\n", res_index);
            sx_utils_status = SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        if (need_to_update_hw) {
            *need_to_update_hw = bf->data[res_index] == 1;
        }
    } else {
        if (bf->data[res_index] > 0) {
            (bf->data[res_index])--;
        } else {
            SX_LOG(SX_LOG_ERROR, "bloom_filter_update_data: bucket at %d was decremented while being 0.\n", res_index);
            sx_utils_status = SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        if (need_to_update_hw) {
            *need_to_update_hw = bf->data[res_index] == 0;
        }
    }


out:
    SX_LOG_EXIT();
    return sx_utils_status;
}

/**
 *
 */
sx_utils_status_t bloom_filter_get(IN const bloom_filter_t *bf,
                                   IN const uint8_t        *key,
                                   IN uint32_t              key_size,
                                   OUT uint32_t            *res_index,
                                   OUT uint32_t            *res_value)
{
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!bf || !bf->is_initialized) {
        SX_LOG(SX_LOG_ERROR, "bloom_filter_get: module is not initialized\n");
        sx_utils_status = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if ((key == NULL) || (res_index == NULL) || (res_value == NULL)) {
        SX_LOG(SX_LOG_ERROR, "bloom_filter_get: Null param was given\n");
        sx_utils_status = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }


    *res_index = bf->hash_func(key, key_size) % bf->size;
    *res_value = bf->data[*res_index];

out:
    SX_LOG_EXIT();
    return sx_utils_status;
}
