/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <unistd.h>
#include <string.h>
#include <complib/cl_mem.h>
#include "sx/utils/bit_vector.h"
#include "sx/utils/dbg_utils.h"
#include "sx/utils/dbg_utils_pretty_printer.h"
#include "utils/gen_utils.h"

#undef      __MODULE__
#define     __MODULE__ GEN_UTILS

/************************************************
 *  Global variables
 ***********************************************/
#define BIT_VECTOR_BITS_IN_WORD 64
typedef uint64_t bit_vector_word_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
typedef struct bit_vector_data {
    uint32_t          size_in_bits; /**< Number of bits in the vector */
    uint32_t          size_in_words; /**< Number of words that comprise the vector */
    uint32_t          bits_set_count; /**< Number of bits which are set in the vector */
    bit_vector_word_t contents[0]; /**< The vector of words and bits. Extra bits at last word are always kept clear */
} bit_vector_data_t;

/************************************************
 *  Function implementations
 ***********************************************/

void bit_vector_log_verbosity_level_set(sx_verbosity_level_t level)
{
    LOG_VAR_NAME(__MODULE__) = level;
}

static inline bit_vector_word_t __bit_vector_bit(uint32_t bit_in_word)
{
    return 1UL << bit_in_word;
}

static inline boolean_t __bit_vector_bit_value(const bit_vector_data_t* bit_vector, uint32_t idx, uint32_t bit_in_word)
{
    return (bit_vector->contents[idx] & __bit_vector_bit(bit_in_word)) != 0;
}

static inline uint32_t __bit_vector_bit_index(uint32_t bit_num, uint32_t* bit_in_word)
{
    *bit_in_word = bit_num % BIT_VECTOR_BITS_IN_WORD;
    return bit_num / BIT_VECTOR_BITS_IN_WORD;
}

static inline uint32_t __bit_vector_bit_num(uint32_t idx, uint32_t bit_idx)
{
    return (idx * BIT_VECTOR_BITS_IN_WORD) + bit_idx;
}

static inline uint32_t __bit_vector_bits_to_words(uint32_t size_bits)
{
    return (size_bits + (BIT_VECTOR_BITS_IN_WORD - 1)) / BIT_VECTOR_BITS_IN_WORD;
}
/* Compute buffer size for a vector of specified bit-size, including control block */
static inline uint32_t __bit_vector_buffer_size(uint32_t size_bits)
{
    return sizeof(bit_vector_data_t) + (sizeof(bit_vector_word_t) * __bit_vector_bits_to_words(size_bits));
}

static void __bit_vector_compute_bit_count(bit_vector_data_t* vector)
{
    uint32_t idx;

    vector->bits_set_count = 0;
    for (idx = 0; idx < vector->size_in_words; idx++) {
        vector->bits_set_count += gen_utils_bits(vector->contents[idx]);
    }
}

sx_utils_status_t bit_vector_allocate(uint32_t size_bits, bit_vector_t* vector)
{
    bit_vector_data_t* new_vector = NULL;
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;

    M_GEN_UTILS_CLR_MEM_GET(&new_vector, 1, __bit_vector_buffer_size(
                                size_bits), GEN_UTILS_MEM_TYPE_ID_BIT_VECTOR_E, "Allocate bit vector", err);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        goto out;
    }

    new_vector->size_in_bits = size_bits;
    new_vector->size_in_words = __bit_vector_bits_to_words(size_bits);
    new_vector->bits_set_count = 0;
    *vector = (bit_vector_t)new_vector;

out:
    return err;
}

sx_utils_status_t bit_vector_free(bit_vector_t vector)
{
    bit_vector_data_t* bit_vector = (bit_vector_data_t*)vector;
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;

    M_GEN_UTILS_MEM_PUT(bit_vector, GEN_UTILS_MEM_TYPE_ID_BIT_VECTOR_E, "Failed to free bit_vector", err);
    return err;
}

sx_utils_status_t bit_vector_resize(bit_vector_t* vector, uint32_t new_size_bits)
{
    bit_vector_data_t* new_vector = NULL;
    bit_vector_data_t* old_vector = *(bit_vector_data_t**)vector;
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    uint32_t           idx, bit_num;

    if (new_size_bits == old_vector->size_in_bits) {
        /* Resize to same size, so nothing to do */
        goto out;
    }

    M_GEN_UTILS_CLR_MEM_GET(&new_vector, 1, __bit_vector_buffer_size(
                                new_size_bits), GEN_UTILS_MEM_TYPE_ID_BIT_VECTOR_E, "Resize bit vector", err);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        goto out;
    }

    new_vector->size_in_bits = new_size_bits;
    new_vector->size_in_words = __bit_vector_bits_to_words(new_size_bits);
    if (new_size_bits > old_vector->size_in_bits) {
        /* Enlarging - bit count does not change */
        memcpy(&new_vector->contents, &old_vector->contents, sizeof(bit_vector_word_t) * old_vector->size_in_words);
        new_vector->bits_set_count = old_vector->bits_set_count;
    } else {
        /* Reducing - need to recompute bit count */
        memcpy(&new_vector->contents, &old_vector->contents, sizeof(bit_vector_word_t) * new_vector->size_in_words);

        /* Clear extra bits in last word, after end of vector */
        idx = __bit_vector_bit_index(new_size_bits, &bit_num);
        if (idx == (new_vector->size_in_words - 1)) {
            new_vector->contents[idx] &= __bit_vector_bit(bit_num) - 1;
        }

        __bit_vector_compute_bit_count(new_vector);
    }

    M_GEN_UTILS_MEM_PUT(old_vector, GEN_UTILS_MEM_TYPE_ID_BIT_VECTOR_E, "Failed to resize bit_vector", err);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        goto out;
    }

    *vector = (bit_vector_t)new_vector;

out:
    if (err != SX_UTILS_STATUS_SUCCESS) {
        if (new_vector != NULL) {
            M_GEN_UTILS_MEM_PUT(new_vector,
                                GEN_UTILS_MEM_TYPE_ID_BIT_VECTOR_E,
                                "Failed to rollback resize bit_vector",
                                err);
            new_vector = NULL;
        }
    }
    return err;
}

sx_utils_status_t bit_vector_set(bit_vector_t vector, uint32_t bit_num)
{
    bit_vector_data_t* bit_vector = (bit_vector_data_t*)vector;
    uint32_t           idx, bit_in_word;
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;

    if (bit_num >= bit_vector->size_in_bits) {
        SX_LOG_ERR("Trying to set bit %u in a vector of %u bits\n", bit_num, bit_vector->size_in_bits);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    idx = __bit_vector_bit_index(bit_num, &bit_in_word);
    if (!__bit_vector_bit_value(bit_vector, idx, bit_in_word)) {
        bit_vector->bits_set_count++;
        bit_vector->contents[idx] |= __bit_vector_bit(bit_in_word);
    }

out:
    return err;
}

sx_utils_status_t bit_vector_clear(bit_vector_t vector, uint32_t bit_num)
{
    bit_vector_data_t* bit_vector = (bit_vector_data_t*)vector;
    uint32_t           idx, bit_in_word;
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;

    if (bit_num >= bit_vector->size_in_bits) {
        SX_LOG_ERR("Trying to clear bit %u in a vector of %u bits\n", bit_num, bit_vector->size_in_bits);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    idx = __bit_vector_bit_index(bit_num, &bit_in_word);
    if (__bit_vector_bit_value(bit_vector, idx, bit_in_word)) {
        CL_ASSERT(bit_vector->bits_set_count > 0);
        bit_vector->bits_set_count--;
        bit_vector->contents[idx] &= ~__bit_vector_bit(bit_in_word);
    }

out:
    return err;
}

sx_utils_status_t bit_vector_get(const bit_vector_t vector, uint32_t bit_num, boolean_t* value)
{
    const bit_vector_data_t* bit_vector = (const bit_vector_data_t*)vector;
    uint32_t                 idx, bit_in_word;
    sx_utils_status_t        err = SX_UTILS_STATUS_SUCCESS;

    if (bit_num >= bit_vector->size_in_bits) {
        SX_LOG_ERR("Trying to get bit %u in a vector of %u bits\n", bit_num, bit_vector->size_in_bits);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    idx = __bit_vector_bit_index(bit_num, &bit_in_word);
    *value = __bit_vector_bit_value(bit_vector, idx, bit_in_word);

out:
    return err;
}

uint32_t bit_vector_count(const bit_vector_t vector)
{
    const bit_vector_data_t* bit_vector = (const bit_vector_data_t*)vector;

    return bit_vector->bits_set_count;
}

uint32_t bit_vector_size(const bit_vector_t vector)
{
    const bit_vector_data_t* bit_vector = (const bit_vector_data_t*)vector;

    return bit_vector->size_in_bits;
}

static inline sx_utils_status_t __bit_vector_find_first_in_word(const bit_vector_data_t* bit_vector,
                                                                uint32_t                 idx,
                                                                uint32_t               * bit_num)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          bit_idx;

    for (; idx < bit_vector->size_in_words; idx++) {
        bit_idx = ffsll(bit_vector->contents[idx]);
        if (bit_idx > 0) {
            *bit_num = __bit_vector_bit_num(idx, bit_idx - 1);
            goto out;
        }
    }
    err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;

out:
    return err;
}

sx_utils_status_t bit_vector_find_first_set(const bit_vector_t vector, uint32_t* bit_num)
{
    const bit_vector_data_t* bit_vector = (const bit_vector_data_t*)vector;

    return __bit_vector_find_first_in_word(bit_vector, 0, bit_num);
}


sx_utils_status_t bit_vector_find_first_unset_bit(const bit_vector_t vector,
                                                  uint32_t           search_from_bit_index,
                                                  uint32_t         * bit_num)
{
    sx_utils_status_t        err = SX_UTILS_STATUS_SUCCESS;
    const bit_vector_data_t* bit_vector = (const bit_vector_data_t*)vector;
    uint32_t                 bit_idx;
    uint32_t                 word_idx = search_from_bit_index / BIT_VECTOR_BITS_IN_WORD;
    uint64_t                 first_word_to_search = 0;
    uint64_t                 mask = 0;

    if (search_from_bit_index > bit_vector_size(vector)) {
        SX_LOG_ERR("Trying to search from bit %u in a vector of %u bits\n",
                   search_from_bit_index,
                   bit_vector->size_in_bits);
        return SX_UTILS_STATUS_PARAM_ERROR;
    }
    first_word_to_search = bit_vector->contents[word_idx];

    /* *bit_num should be smaller then search_from_bit_index */
    /* coverity[large_shift] */
    mask = (uint64_t)1 << (search_from_bit_index % BIT_VECTOR_BITS_IN_WORD);
    mask = mask - 1;
    first_word_to_search |= mask;

    bit_idx = ffsll(~first_word_to_search);
    if (bit_idx > 0) {
        *bit_num = __bit_vector_bit_num(word_idx, bit_idx - 1);
        goto out;
    }

    word_idx++;

    for (; word_idx < bit_vector->size_in_words; word_idx++) {
        bit_idx = ffsll(~(bit_vector->contents[word_idx]));
        if (bit_idx > 0) {
            *bit_num = __bit_vector_bit_num(word_idx, bit_idx - 1);
            goto out;
        }
    }

    err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;

out:
    if ((err == SX_UTILS_STATUS_SUCCESS) && (*bit_num >= bit_vector_size(vector))) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    }
    return err;
}

sx_utils_status_t bit_vector_find_next_set(const bit_vector_t vector, uint32_t* bit_num)
{
    const bit_vector_data_t* bit_vector = (const bit_vector_data_t*)vector;
    uint32_t                 idx = 0, bit_idx;
    bit_vector_word_t        value;
    sx_utils_status_t        err = SX_UTILS_STATUS_SUCCESS;

    idx = __bit_vector_bit_index(*bit_num, &bit_idx);

    bit_idx++;
    if (bit_idx != BIT_VECTOR_BITS_IN_WORD) {
        /* Look for another bit in same word */
        value = bit_vector->contents[idx];
        /* Mask-off bits already covered */
        value &= ~(__bit_vector_bit(bit_idx) - 1);
        bit_idx = ffsll(value);
        if (bit_idx > 0) {
            *bit_num = __bit_vector_bit_num(idx, bit_idx - 1);
            goto out;
        }
    }

    /* Continue looking for first bit in next word */
    idx++;
    err = __bit_vector_find_first_in_word(bit_vector, idx, bit_num);

out:
    return err;
}

sx_utils_status_t bit_vector_foreach_set(const bit_vector_t vector, bit_vector_callback_t cb, void* context)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          bit_num;

    err = bit_vector_find_first_set(vector, &bit_num);
    while (err == SX_UTILS_STATUS_SUCCESS) {
        err = cb(bit_num, context);
        if (err == SX_UTILS_STATUS_PARTIALLY_COMPLETE) {
            err = SX_UTILS_STATUS_SUCCESS;
            goto out;
        }
        if (err != SX_UTILS_STATUS_SUCCESS) {
            goto out;
        }
        err = bit_vector_find_next_set(vector, &bit_num);
    }

    CL_ASSERT(err == SX_UTILS_STATUS_ENTRY_NOT_FOUND);
    err = SX_UTILS_STATUS_SUCCESS;

out:
    return err;
}

sx_utils_status_t bit_vector_and(bit_vector_t dst, const bit_vector_t src)
{
    const bit_vector_data_t* bit_vector_src = (const bit_vector_data_t*)src;
    bit_vector_data_t      * bit_vector_dst = (bit_vector_data_t*)dst;
    uint32_t                 idx;
    sx_utils_status_t        err = SX_UTILS_STATUS_SUCCESS;

    if (bit_vector_src->size_in_bits != bit_vector_dst->size_in_bits) {
        SX_LOG_ERR("Bit vector of size %u is incompatible for logic operation AND with bit vector of size %u\n",
                   bit_vector_src->size_in_bits,
                   bit_vector_dst->size_in_bits);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    for (idx = 0; idx < bit_vector_src->size_in_words; idx++) {
        bit_vector_dst->contents[idx] &= bit_vector_src->contents[idx];
    }
    __bit_vector_compute_bit_count(bit_vector_dst);

out:
    return err;
}

sx_utils_status_t bit_vector_or(bit_vector_t dst, const bit_vector_t src)
{
    const bit_vector_data_t* bit_vector_src = (const bit_vector_data_t*)src;
    bit_vector_data_t      * bit_vector_dst = (bit_vector_data_t*)dst;
    uint32_t                 idx;
    sx_utils_status_t        err = SX_UTILS_STATUS_SUCCESS;

    if (bit_vector_src->size_in_bits != bit_vector_dst->size_in_bits) {
        SX_LOG_ERR("Bit vector of size %u is incompatible for logic operation OR with bit vector of size %u\n",
                   bit_vector_src->size_in_bits,
                   bit_vector_dst->size_in_bits);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    for (idx = 0; idx < bit_vector_src->size_in_words; idx++) {
        bit_vector_dst->contents[idx] |= bit_vector_src->contents[idx];
    }
    __bit_vector_compute_bit_count(bit_vector_dst);

out:
    return err;
}

sx_utils_status_t bit_vector_xor(bit_vector_t dst, const bit_vector_t src)
{
    const bit_vector_data_t* bit_vector_src = (const bit_vector_data_t*)src;
    bit_vector_data_t      * bit_vector_dst = (bit_vector_data_t*)dst;
    uint32_t                 idx;
    sx_utils_status_t        err = SX_UTILS_STATUS_SUCCESS;

    if (bit_vector_src->size_in_bits != bit_vector_dst->size_in_bits) {
        SX_LOG_ERR("Bit vector of size %u is incompatible for logic operation XOR with bit vector of size %u\n",
                   bit_vector_src->size_in_bits,
                   bit_vector_dst->size_in_bits);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    for (idx = 0; idx < bit_vector_src->size_in_words; idx++) {
        bit_vector_dst->contents[idx] ^= bit_vector_src->contents[idx];
    }
    __bit_vector_compute_bit_count(bit_vector_dst);

out:
    return err;
}

sx_utils_status_t bit_vector_not(bit_vector_t dst)
{
    bit_vector_data_t* bit_vector = (bit_vector_data_t*)dst;
    uint32_t           idx, bit_num;

    for (idx = 0; idx < bit_vector->size_in_words; idx++) {
        bit_vector->contents[idx] = ~bit_vector->contents[idx];
    }

    /* Un-flip extra bits at end of contents, which are not part of the vector */
    idx = __bit_vector_bit_index(bit_vector->size_in_bits, &bit_num);
    if (idx == (bit_vector->size_in_words - 1)) {
        bit_vector->contents[idx] &= __bit_vector_bit(bit_num) - 1;
    }
    bit_vector->bits_set_count = bit_vector->size_in_bits - bit_vector->bits_set_count;

    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t bit_vector_assign(bit_vector_t dst, const bit_vector_t src)
{
    const bit_vector_data_t* bit_vector_src = (const bit_vector_data_t*)src;
    bit_vector_data_t      * bit_vector_dst = (bit_vector_data_t*)dst;
    uint32_t                 idx;
    sx_utils_status_t        err = SX_UTILS_STATUS_SUCCESS;

    if (bit_vector_src->size_in_bits != bit_vector_dst->size_in_bits) {
        SX_LOG_ERR("Bit vector of size %u is incompatible for assignment with bit vector of size %u\n",
                   bit_vector_src->size_in_bits,
                   bit_vector_dst->size_in_bits);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    for (idx = 0; idx < bit_vector_src->size_in_words; idx++) {
        bit_vector_dst->contents[idx] = bit_vector_src->contents[idx];
    }
    bit_vector_dst->bits_set_count = bit_vector_src->bits_set_count;

out:
    return err;
}

sx_utils_status_t bit_vector_assign_array(bit_vector_t *bit_vector_p, const uint32_t *src, uint32_t array_size)
{
    bit_vector_data_t* bit_vector = *(bit_vector_data_t**)bit_vector_p;
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    uint32_t           size_in_words = ((sizeof(*src) * array_size) / sizeof(bit_vector_word_t));

    if (size_in_words > bit_vector->size_in_words) {
        err = SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Source array of size %u is incompatible for assignment with bit vector of size %u\n",
                   array_size, bit_vector->size_in_words);
        goto out;
    }

    /* copy array to contents - need to recompute bit count */
    memcpy(bit_vector->contents, src, (sizeof(*src) * array_size));

    /* recompute bit count */
    __bit_vector_compute_bit_count(bit_vector);

    /* return bit vector to user */
    *bit_vector_p = (bit_vector_t)bit_vector;

out:
    return err;
}

void bit_vector_debug_dump(const bit_vector_t vector, FILE* stream)
{
    const bit_vector_data_t* bit_vector = (const bit_vector_data_t*)vector;
    char                     str[DBG_UTILS_SCRN_WIDTH_MAX + 1];
    uint32_t                 bit_idx, idx = 0;
    uint32_t                 bit_start = 0;
    boolean_t                value;
    sx_utils_status_t        err;

    memset(str, 0, sizeof(str));

    dbg_utils_pprinter_field_print(stream, "Size in bits", &bit_vector->size_in_bits, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Size in words", &bit_vector->size_in_words, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "bits set", &bit_vector->bits_set_count, PARAM_UINT32_E);

    for (bit_idx = 0; bit_idx < bit_vector->size_in_bits; bit_idx++) {
        err = bit_vector_get(vector, bit_idx, &value);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to dump bit %u/%u of bit vector\n", bit_idx, bit_vector->size_in_bits);
            break;
        }
        str[idx] = value ? '1' : '0';
        idx++;
        if (idx == DBG_UTILS_SCRN_WIDTH_MAX - 10) {
            dbg_utils_pprinter_print(stream, "%7u: %s\n", bit_start, str);
            memset(str, 0, sizeof(str));
            bit_start = bit_idx + 1;
            idx = 0;
        }
    }

    if (idx > 0) {
        dbg_utils_pprinter_print(stream, "%7u: %s\n", bit_start, str);
    }
}
