/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef     __GEN_UTILS_H__
#define     __GEN_UTILS_H__

#include <stdlib.h>
#include <errno.h>

#include <complib/cl_types.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>

#include <complib/sx_log.h>

#include <sx/utils/sx_utils_status.h>
#include <sx/utils/sx_utils_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/*
 * Defines the polling callback prototype that should be used for the
 * sdk_timer_poll() function.
 *
 * @param[in] context - client context
 *
 * @return SX_UTILS_STATUS_SUCCESS if polling is complete
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE if more polling is necessary
 * @return any other value if function fails
 */
typedef sx_utils_status_t (*gen_utils_polling_pfn) (void *context);

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


/************************************************
 *  DEFINES
 ***********************************************/

typedef enum gen_utils_mem_type_id {
    GEN_UTILS_MEM_TYPE_ID_ALL_E = 0,
    GEN_UTILS_MEM_TYPE_ID_PSORT_E,
    GEN_UTILS_MEM_TYPE_ID_LINEAR_MANAGER_E,
    GEN_UTILS_MEM_TYPE_ID_BIN_E,
    GEN_UTILS_MEM_TYPE_ID_BIT_VECTOR_E,
    GEN_UTILS_MEM_TYPE_ID_CIRCULAR_BUFFER_E,
    GEN_UTILS_MEM_TYPE_ID_ID_ALLOCATOR_E,
    GEN_UTILS_MEM_TYPE_ID_MIN_E = GEN_UTILS_MEM_TYPE_ID_PSORT_E,
    GEN_UTILS_MEM_TYPE_ID_MAX_E = GEN_UTILS_MEM_TYPE_ID_ID_ALLOCATOR_E,
} gen_utils_mem_type_id_e;

/************************************************
 *  MACROS
 ***********************************************/

/*
 * This macro clears a region of memory
 */
#define M_GEN_UTILS_MEM_CLR(src) (memset(&(src), 0, sizeof(src)))

/*
 * This macro checks if the given memory-type is within the valid range
 */
#define M_GEN_UTILS_MEM_TYPE_ID_CHECK_RANGE(mem_type_id) \
    SX_CHECK_RANGE(GEN_UTILS_MEM_TYPE_ID_MIN_E,          \
                   mem_type_id,                          \
                   GEN_UTILS_MEM_TYPE_ID_MAX_E)

/*
 * The macro calls the gen_utils_sx_log_exit(...) function with __FUNCTION__
 */
#define M_GEN_UTILS_SX_LOG_EXIT(status) (gen_utils_sx_log_exit(status, __FUNCTION__))

/*
 * The macro calls the utils_clr_memory_get(...) function and prints error message at failure
 */
#define M_GEN_UTILS_CLR_MEM_GET(ptr, num, size, id, err_msg, result)       \
    result = gen_utils_clr_memory_get((void**)(ptr), (uint32_t)(num),      \
                                      (uint32_t)(size), id);               \
    if ((result) != SX_UTILS_STATUS_SUCCESS) {                             \
        SX_LOG_ERR("Failed to allocate memory %d ("err_msg ")\n", result); \
    }

/*
 * The macro calls the gen_utils_memory_put(...) function and prints error message at failure
 */
#define M_GEN_UTILS_MEM_PUT(ptr, id, err_msg, result) \
    result = gen_utils_memory_put((void*)(ptr), id);  \
    if ((result) != SX_UTILS_STATUS_SUCCESS) {        \
        SX_LOG_ERR(err_msg);                          \
    }

/*
 * This macro clears a region of memory
 */
#define M_GEN_UTILS_MEM_CLR_PTR(ptr, size) memset(ptr, 0, size)

/*
 * This macro copies sizeof(type) bytes from src to dst.
 */
#define M_GEN_UTILS_MEM_CPY_TYPE(dst, src, type) (memcpy((dst), (src), sizeof(type)))

/************************************************
 *  GLOBAL VARIABLES
 ***********************************************/

/************************************************
 *  API Functions
 ***********************************************/

/**
 * This function prints the exit (from function) message
 * & returns the error status that was given to it.
 *
 * @param[in]  rc	        - The error status that needs to be returned.
 * @param[in]  func_name        - calling function name for log print
 *
 * @return sx_utils_status_t		- The error status that was given.
 *
 */
sx_utils_status_t gen_utils_sx_log_exit(IN sx_utils_status_t rc,
                                        IN const char       *func_name);

/**
 *  This function checks if the given pointer isn't NULL.
 *
 * @param[in] ptr - Generic pointer
 * @param[in] description - Description of what "stands behind" the pointer
 *
 * @return sx_utils_status_t
 */
sx_utils_status_t gen_utils_check_pointer(IN const void *ptr,
                                          IN const char *description);


/**
 * This function sets the log verbosity level of UTILS MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_UTILS_STATUS_SUCCESS operation completes successfully
 *          SX_UTILS_STATUS_ERROR   general error
 */
sx_utils_status_t gen_utils_log_verbosity_level(IN sx_utils_command_t    cmd,
                                                IN sx_verbosity_level_t *verbosity_level_p);

/**
 * This function allocate memory and zero allocated memory items.
 *
 * @param[out] buf_p        - allocate memory into this buffer
 * @param[in]  items_number - number of items to allocate
 * @param[in]  item_size    - item size in bytes
 * @param[in]  mem_type_id  - memory type id - ascribe memory allocation for this memory type
 *
 * @return sx_status
 */
sx_utils_status_t gen_utils_clr_memory_get(OUT void                ** buf_p,
                                           IN uint32_t                items_number,
                                           IN uint32_t                item_size,
                                           IN gen_utils_mem_type_id_e mem_type_id);

/**
 * This function allocate memory
 *
 * @param[out] buf_p        - pointer to a buffer pointer
 * @param[in]  buf_size     - size of memory to allocate (in bytes)
 * @param[in]  mem_type_id  - memory type id - ascribe memory allocation for this memory type
 */
sx_utils_status_t gen_utils_memory_get(OUT void                 **buf_p,
                                       IN uint32_t                buf_size,
                                       IN gen_utils_mem_type_id_e mem_type_id);

/**
 * This function free memory using free.
 *
 * @param[in]  buf_p          - buffer to free
 * @param[in]  mem_type_id    - memory type id - ascribe memory deallocation for this memory type
 *
 * @return sx_status
 */
sx_utils_status_t gen_utils_memory_put(IN void                   *buf_p,
                                       IN gen_utils_mem_type_id_e mem_type_id);

/**
 * @param[in] n   - A number
 * @return the number of bits in a number
 */
unsigned int gen_utils_bits(uint64_t n);

/**
 * Polls on a callback. The function will call the given callback until it returns
 * SX_UTILS_STATUS_SUCCESS, or until the given timeout expires. It will wait
 * polling_interval milliseconds between each call to the callback that doesn't
 * succeed.
 *
 * @param[in] polling_interval - time to wait between each poll, in microseconds.
 * @param[in] timeout - maximum time to wait, in microseconds
 * @param[in] polling_cb - polling callback
 * @param[in] context - client context for polling callback
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR      if an invalid parameter is given
 * @return SX_UTILS_STATUS_PARAM_NULL if a NULL parameter is given
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gen_utils_timed_poll(uint32_t polling_interval, uint32_t timeout,
                                       gen_utils_polling_pfn polling_cb, void *context);

#endif  /*	__GEN_UTILS_H__	*/
