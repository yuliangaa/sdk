/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#undef  __MODULE__
#define __MODULE__ DBG_UTILS

#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "sx/utils/dbg_utils.h"
#include <complib/cl_mem.h>

#undef  __MODULE__
#define __MODULE__ DBG_UTILS

/*Max level here is increased by 128 to accommodate the SHSPM tree dump in tree format.*/
#define STACK_JSON_MAX_LEVEL (DBG_UTILS_NODES_MAX + DBG_UTILS_LEVEL_MAX_E + 1)

#define DBG_UTILS_DATA_STR_WIDTH          40
#define DBG_UTILS_DATA_STR_PRECISION      65
#define DBG_UTILS_VAL_STR_PRECISION       128
#define DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE 8172

/************************************************
 *  Global variables
 ***********************************************/
char      cheat_sheet_buffer[DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE];
size_t    cheat_sheet_total_written = 0;
int       cheat_sheet_dump_in_progress = 0;
boolean_t debug_dump_json_g = FALSE;

/************************************************
 *  Local variables
 ***********************************************/
typedef struct draw_tree_node_context {
    FILE                  * stream;
    const dbg_utils_tree_t* tree;
    uint32_t                right_depth;
    boolean_t             * verticals;
    boolean_t               line_broken;
} draw_tree_node_context_t;

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static char* param_str_g[] =
{"u", "u", "u", "llu", "X", "s", "s", "s", "s", "s", "s", "s", "s", ".2f", "d", "X", "s", "x", PRIx64};

/* json object stack, for json print */
typedef struct _sx_stack_json_t {
    char      type; /* '}' as object ,']' as array*/
    boolean_t has_child; /*This is set at run time when new child is encountered to add "," after the previous one.*/
    int16_t   level;  /*This is passed during the invocation of dump inside SDK code*/
} sx_stack_json_t;

static int32_t         stack_json_top = 0;
static sx_stack_json_t stacked_json_arr[STACK_JSON_MAX_LEVEL];
/* for table name setting in stack json print */
static char  json_table_name[DBG_UTILS_JSON_BUF_SIZE] = {0};
static FILE *json_fp = NULL;

#define PARAM_STR_ARR_LEN (sizeof(param_str_g) / sizeof(char*))
#define PARAM_TO_STR(param_type) (param_type < PARAM_STR_ARR_LEN ? param_str_g[param_type] : "u")

/************************************************
 *  Local function declarations
 ***********************************************/
void __type_to_str(dbg_utils_param_type_e type_enum, char *str_type);

const char* __print_extended_string(FILE *stream, const char* str, int width);

void __print_empty_clmn(FILE *stream, int width);

/************************************************
 *  Function implementations
 ***********************************************/
static char* __print_hex_string(char *buf, int buf_len, const unsigned char *data, int data_len)
{
    int   i;
    char *cp = buf;

    memset(buf, 0, buf_len);
    for (i = 0; (i < data_len) && (buf_len - (cp - buf) >= 3); i++) {
        cp += snprintf(cp, buf_len - (cp - buf), "%02x", data[i]);
        if (i == data_len - 1) {
            break;
        }
        strncpy(cp, ":", buf_len - (cp - buf));
        cp++;
    }
    buf[buf_len - 1] = 0;
    return buf;
}

static void _remove_return(char * value)
{
    int i = 0;

    /*replace \n \t with space due to json format requirement */
    for (i = 0; i < (int)strlen(value); i++) {
        if ((value[i] == '\n') || (value[i] == '\t')) {
            value[i] = ' ';
        }
    }
}

static void _remove_leading_sp(char * value)
{
    int i = 0;
    int len = strlen(value);

    for (i = 0; i < len; i++) {
        if ((value[i] == ' ') || (value[i] == '\t')) {
            continue;
        } else {
            break;
        }
    }
    if (i != 0) {
        memmove(value, value + i, len - i);
        value[len - i] = 0;
    }
}

/*rewind stack to given level. usually called when we print objects at the same level or when an object is encountered that needs to be printed in the next level.
 */
void dbg_json_rewind_stack(dbg_utils_level_e new_level)
{
#define JSON_INDENT "  "
    int i = 0;
    /*rewind the current level to given level*/
    while (stacked_json_arr[stack_json_top].level >= (int)new_level) {
        /* Move cursor to the correct position to put the closing "}" or "]"*/
        if (stacked_json_arr[stack_json_top].has_child) {
            dbg_utils_print(json_fp, "\n");
            for (i = 0; i < stack_json_top; i++) {
                dbg_utils_print(json_fp, JSON_INDENT);
            }
        }
        dbg_utils_print(json_fp, "%c", stacked_json_arr[stack_json_top].type);
        --stack_json_top;
        if (stack_json_top < 0) {
            SX_LOG_ERR("stacked_json_arr underflow\n");
            debug_dump_json_g = FALSE;
            return;
        }
    }

    if (stacked_json_arr[stack_json_top].has_child) {
        dbg_utils_print(json_fp, ",\n");
    } else {
        dbg_utils_print(json_fp, "\n");
    }
    /*set child as true so that comma can be added along with closing braces next time if there are more children, otherwise just closing braces will be added by above snippet.*/
    stacked_json_arr[stack_json_top].has_child = TRUE;
    for (i = 0; i < stack_json_top + 1; i++) {
        dbg_utils_print(json_fp, JSON_INDENT);
    }
}

void dbg_json_create_header_object(dbg_utils_level_e new_level, const char* object_name, boolean_t is_table)
{
    char table_name_str[DBG_UTILS_JSON_BUF_SIZE];

    if (!debug_dump_json_g || !json_fp) {
        return;
    }

    if ((((int)new_level) >= STACK_JSON_MAX_LEVEL) || (((int)new_level) < DBG_UTILS_LEVEL_MIN_E)) {
        goto out;
    }

    dbg_json_rewind_stack(new_level);

    /*add a new level*/
    stack_json_top++;
    if (stack_json_top >= STACK_JSON_MAX_LEVEL) {
        SX_LOG_ERR("stacked_json_arr overflow\n");
        debug_dump_json_g = FALSE;
        return;
    }

    if (is_table) {
        if (json_table_name[0] != '\0') {
            snprintf(table_name_str, sizeof(table_name_str), "%s", json_table_name);
        } else {
            snprintf(table_name_str, sizeof(table_name_str), "%s", object_name);
        }
        json_table_name[0] = '\0';
        dbg_utils_print(json_fp, "\"%s\": [", table_name_str);
        stacked_json_arr[stack_json_top].type = ']';
    } else {
        dbg_utils_print(json_fp, "\"%s\": {", object_name);
        stacked_json_arr[stack_json_top].type = '}';
    }

    stacked_json_arr[stack_json_top].has_child = FALSE;
    stacked_json_arr[stack_json_top].level = new_level;

out:
    return;
}

void dbg_json_create_string_object(dbg_utils_level_e new_level, char *value)
{
    if (!debug_dump_json_g) {
        return;
    }

    dbg_json_rewind_stack(new_level);
    _remove_return(value);
    dbg_utils_print(json_fp, "\"%s\"", value);
}

static void __create_data_object(dbg_utils_level_e new_level, const char *name, char *value)
{
    char buf[DBG_UTILS_JSON_BUF_SIZE];

    if (!debug_dump_json_g) {
        return;
    }

    dbg_json_rewind_stack(new_level);

    snprintf(buf, sizeof(buf), "%s", name);
    _remove_leading_sp(buf);
    _remove_return(value);
    dbg_utils_print(json_fp, "\"%s\": \"%s\"", buf, value);
}

void dbg_json_create_table_item(dbg_utils_level_e new_level)
{
    if (!debug_dump_json_g) {
        return;
    }
    dbg_json_rewind_stack(new_level);

    stack_json_top++;
    if (stack_json_top >= STACK_JSON_MAX_LEVEL) {
        SX_LOG_ERR("stacked_json_arr overflow\n");
        debug_dump_json_g = FALSE;
        return;
    }
    stacked_json_arr[stack_json_top].type = '}';
    stacked_json_arr[stack_json_top].has_child = FALSE;
    stacked_json_arr[stack_json_top].level = new_level;
    dbg_utils_print(json_fp, "{");
}

void dbg_utils_global_json_init(void)
{
    stacked_json_arr[0].type = '}';
    stacked_json_arr[0].has_child = FALSE;
    stacked_json_arr[0].level = 0;
    stack_json_top = 0;
    dbg_utils_print(json_fp, "{");
}

void dbg_utils_cheat_sheet_init()
{
    cheat_sheet_total_written = 0;
    cheat_sheet_dump_in_progress = 1;
    memset(cheat_sheet_buffer, 0, sizeof(cheat_sheet_buffer));
}

void dbg_utils_print_cheat_sheet(FILE *stream)
{
    dbg_utils_print_module_header(stream, "Cheat Sheet");
    dbg_utils_print(stream, "%s", cheat_sheet_buffer);
    cheat_sheet_dump_in_progress = 0;
}

void dbg_utils_print(FILE *stream, const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    vfprintf(stream, fmt, args);
    va_end(args);
}

void dbg_utils_print_field_w_len(FILE                  *stream,
                                 const char            *name,
                                 const void            *data,
                                 dbg_utils_param_type_e type,
                                 unsigned int           data_len)
{
    static char buff[DBG_UTILS_DATA_STR_PRECISION];

    switch (type) {
    case PARAM_HEX_STRING_E:
        __print_hex_string(buff, sizeof(buff), (unsigned char*)data, data_len);
        dbg_utils_print(stream, "%-*.*s %.*s\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, DBG_UTILS_DATA_STR_WIDTH, (char*)buff);
        break;

    default:
        SX_LOG_ERR("Internal error: wrong use of dbg_utils_param_type %u\n", type);
        break;
    }
}

/*
 * this func prints simple data by type
 */
void dbg_utils_print_field_simple(FILE                  *stream,
                                  const char            *name,
                                  const void            *data,
                                  dbg_utils_param_type_e type,
                                  char                  *buf,
                                  size_t                 buf_size)
{
    const char * str_p;
    uint8_t     *mac_p;
    uint32_t     ipv6_idx;

    switch (type) {
    case PARAM_UINT8_E:
        dbg_utils_print(stream, "%-*.*s %hu\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((uint8_t*)data));
        if (buf != NULL) {
            snprintf(buf, buf_size, "%hu", *((uint8_t*)data));
        }
        break;

    case PARAM_UINT16_E:
        dbg_utils_print(stream, "%-*.*s %u\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((uint16_t*)data));
        if (buf != NULL) {
            snprintf(buf, buf_size, "%u", *((uint16_t*)data));
        }
        break;

    case PARAM_UINT32_E:
        dbg_utils_print(stream, "%-*.*s %u\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((uint32_t*)data));
        if (buf != NULL) {
            snprintf(buf, buf_size, "%u", *((uint32_t*)data));
        }
        break;

    case PARAM_UINT64_E:
        dbg_utils_print(stream, "%-*.*s %" PRIu64 "\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((uint64_t*)data));
        if (buf != NULL) {
            snprintf(buf, buf_size, "%" PRIu64 "", *((uint64_t*)data));
        }
        break;

    case PARAM_HEX_E:
        dbg_utils_print(stream, "%-*.*s 0x%X\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((uint32_t*)data));
        if (buf != NULL) {
            snprintf(buf, buf_size, "0x%X", *((uint32_t*)data));
        }
        break;

    case PARAM_HEX16_E:
        dbg_utils_print(stream, "%-*.*s 0x%X\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((uint16_t*)data));
        if (buf != NULL) {
            snprintf(buf, buf_size, "0x%X", *((uint16_t*)data));
        }
        break;

    case PARAM_HEX64_E:
        dbg_utils_print(stream, "%-*.*s 0x%" PRIx64 "\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((uint64_t*)data));
        if (buf != NULL) {
            snprintf(buf, buf_size, "0x%" PRIx64 "", *((uint64_t*)data));
        }
        break;

    case PARAM_PORT_ID_E:
        dbg_utils_print(stream, "%-*.*s 0x%x\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((uint32_t*)data));
        if (buf != NULL) {
            snprintf(buf, buf_size, "0x%x", *((uint32_t*)data));
        }
        break;

    case PARAM_STRING_E:
        dbg_utils_print(stream, "%-*.*s %.*s\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, DBG_UTILS_VAL_STR_PRECISION, (char*)data);
        if (buf != NULL) {
            snprintf(buf, buf_size, "%s", (const char*)data);
        }
        break;

    case PARAM_EXT_STRING_E:
        dbg_utils_print(stream, "%-*.*s", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION, name);
        str_p = __print_extended_string(stream, data, DBG_UTILS_VAL_STR_PRECISION);
        dbg_utils_print(stream, "\n");

        while (*str_p != 0) {
            dbg_utils_print(stream, "%-*.*s", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION, "");
            str_p = __print_extended_string(stream, data, DBG_UTILS_VAL_STR_PRECISION);
            dbg_utils_print(stream, "\n");
        }
        if (buf != NULL) {
            snprintf(buf, buf_size, "%s", (const char*)data);
        }
        break;

    case PARAM_BOOL_E:
        dbg_utils_print(stream, "%-*.*s %s\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((boolean_t*)data) ? "TRUE" : "FALSE");
        if (buf != NULL) {
            snprintf(buf, buf_size, "%s", *((boolean_t*)data) ? "TRUE" : "FALSE");
        }
        break;

    case PARAM_MAC_ADDR_E:
        mac_p = ((uint8_t*)(data));
        dbg_utils_print(stream, "%-*.*s %.2X:%.2X:%.2X:%.2X:%.2X:%.2X\n",
                        DBG_UTILS_DATA_STR_WIDTH,
                        DBG_UTILS_DATA_STR_PRECISION,
                        name,
                        mac_p[0], mac_p[1], mac_p[2], mac_p[3], mac_p[4], mac_p[5]);
        if (buf != NULL) {
            snprintf(buf,
                     buf_size,
                     "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X",
                     mac_p[0],
                     mac_p[1],
                     mac_p[2],
                     mac_p[3],
                     mac_p[4],
                     mac_p[5]);
        }
        break;

    case PARAM_IPV4_E:
    case PARAM_IPV4_MASK_E:
    {
        struct in_addr ip;
        char           addr[INET_ADDRSTRLEN];
        ip.s_addr = htonl(*((uint32_t*)data));
        if (!inet_ntop(AF_INET, &ip, addr, INET_ADDRSTRLEN)) {
            strcpy(addr, "???");
        }
        dbg_utils_print(stream, "%-*.*s %s\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, addr);
        if (buf != NULL) {
            snprintf(buf, buf_size, "%s", addr);
        }
        break;
    }

    case PARAM_IPV6_E:
    {
        struct in6_addr ipv6;
        char            addr[INET6_ADDRSTRLEN];
        for (ipv6_idx = 0; ipv6_idx < 4; ipv6_idx++) {
            ipv6.s6_addr32[ipv6_idx] = htonl(((struct in6_addr*)data)->s6_addr32[ipv6_idx]);
        }
        if (!inet_ntop(AF_INET6, &ipv6, addr, INET6_ADDRSTRLEN)) {
            strcpy(addr, "???");
        }
        dbg_utils_print(stream, "%-*.*s %s\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, addr);
        if (buf != NULL) {
            snprintf(buf, buf_size, "%s", addr);
        }
        break;
    }

    case PARAM_FC_ADDR_E:
    {
        uint8_t *map_p;
        map_p = ((uint8_t*)(data));
        dbg_utils_print(stream, "%-*.*s %.2X:%.2X:%.2X\n",
                        DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, map_p[0], map_p[1], map_p[2]);
        if (buf != NULL) {
            snprintf(buf, buf_size, "%.2X:%.2X:%.2X", map_p[0], map_p[1], map_p[2]);
        }
        break;
    }

    case PARAM_DOUBLE_E:
        dbg_utils_print(stream, "%-*.*s %.2f\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((double*)data));
        if (buf != NULL) {
            snprintf(buf, buf_size, "%.2f", *((double*)data));
        }
        break;

    case PARAM_INT_E:
        dbg_utils_print(stream, "%-*.*s %d\n", DBG_UTILS_DATA_STR_WIDTH, DBG_UTILS_DATA_STR_PRECISION,
                        name, *((int*)data));
        if (buf != NULL) {
            snprintf(buf, buf_size, "%d", *((int*)data));
        }
        break;

    default:
        SX_LOG_ERR("Internal error: wrong use of dbg_utils_param_type %u\n", type);
        break;
    }
}

void dbg_utils_print_field(FILE *stream, const char *name, const void *data, dbg_utils_param_type_e type)
{
    char buf[DBG_UTILS_JSON_BUF_SIZE];

    dbg_utils_print_field_simple(stream, name, data, type, buf, sizeof(buf));
    __create_data_object(DBG_UTILS_LEVEL_DATA_E, name, buf);
}

void dbg_utils_print_field_with_level(FILE                  *stream,
                                      const char            *name,
                                      const void            *data,
                                      dbg_utils_param_type_e type,
                                      dbg_utils_level_e      new_level)
{
    char buf[DBG_UTILS_JSON_BUF_SIZE];

    dbg_utils_print_field_simple(stream, name, data, type, buf, sizeof(buf));
    __create_data_object(new_level, name, buf);
}

void dbg_utils_capitalize_string(const char *string, char *capitalized_string)
{
    uint8_t i = 0;

    for (i = 0; i < (strlen(string)); i++) {
        if ((i == 0) ||
            (string[i - 1] == ' ')) {
            if (((string[i] >= 'a') &&
                 (string[i] <= 'z'))) {
                capitalized_string[i] = string[i] - 32;
            } else {
                capitalized_string[i] = string[i];
            }
        } else {
            capitalized_string[i] = string[i];
        }
    }
    capitalized_string[i] = '\0';
}

void dbg_utils_print_module_header(FILE *stream, const char *module_name)
{
    size_t module_len = 0;

    dbg_utils_print(stream, "\n***********************************************\n");
    dbg_utils_print(stream, " %.48s \n", module_name);
    dbg_utils_print(stream, "***********************************************\n");

    if (cheat_sheet_dump_in_progress) {
        module_len = strlen(module_name);
        module_len = (module_len < 48) ? module_len : 48;
        if (cheat_sheet_total_written + module_len + 1 < DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE) {
            strncpy(&cheat_sheet_buffer[cheat_sheet_total_written], module_name,
                    DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE - (cheat_sheet_total_written + 1));
            cheat_sheet_total_written += module_len;
            cheat_sheet_buffer[cheat_sheet_total_written] = '\n';
            cheat_sheet_total_written++;
        }
    }

    dbg_json_create_header_object(DBG_UTILS_LEVEL_MODULE_E, module_name, FALSE);
}

void dbg_utils_print_table_headline_with_name(FILE *stream, dbg_utils_table_columns_t *columns, char * name)
{
    int   i;
    char  add[20];
    int   num_of_columns = 0;
    int   total_width = 0;
    char *capitalized_name = NULL;

    while (columns[num_of_columns].name) {
        total_width += columns[num_of_columns].width;
        num_of_columns++;
    }
    total_width += num_of_columns;

    if (total_width <= DBG_UTILS_SCRN_WIDTH_MAX) {
        dbg_utils_print(stream, "\n");
        dbg_utils_print_separator_line(stream, total_width, DBG_UTILS_DEFAULT_SEPARATOR_CHAR);

        for (i = 0; i < num_of_columns; i++) {
            capitalized_name = (char*)cl_malloc(strlen(columns[i].name) + 1);
            sprintf(add, "%%-%-us|", columns[i].width);
            dbg_utils_capitalize_string(columns[i].name, capitalized_name);
            dbg_utils_print(stream, add, capitalized_name);
            cl_free(capitalized_name);
        }
        dbg_utils_print(stream, "\n");
        dbg_utils_print_separator_line(stream, total_width, DBG_UTILS_DEFAULT_SEPARATOR_CHAR);
    }

    dbg_json_create_header_object(DBG_UTILS_LEVEL_HEADER_E, name, TRUE);
}

void dbg_utils_set_json_table_name(char *table_name)
{
    if (debug_dump_json_g) {
        strncpy(json_table_name, table_name, DBG_UTILS_JSON_BUF_SIZE - 1);
    }
}


int dbg_utils_print_table_data_line_nosep(FILE *stream, dbg_utils_table_columns_t *columns)
{
    int                          i, k, ipv6_idx;
    char                         add[30];
    char                         str_type[20];
    char                         name[150];
    int                          column_print_flag[DBG_UTILS_COLUMN_NUM_MAX];
    const char                  *p;
    uint8_t                     *mac_ptr;
    uint8_t                     *fc_ptr;
    int                          more_to_print = 1;
    int                          num_of_columns = 0;
    int                          total_width = 0;
    int                          tbl_display = 0;
    dbg_utils_table_tlv_field_t *tlv_field_p;
    char                         json_buf[DBG_UTILS_JSON_BUF_SIZE];
    const void                 **original_data_p = NULL;

    while (columns[num_of_columns].name && (num_of_columns < DBG_UTILS_COLUMN_NUM_MAX)) {
        column_print_flag[num_of_columns] = 1;
        if (sizeof(name) <= (unsigned)columns[num_of_columns].width) {
            columns[num_of_columns].width = sizeof(name) - 1;
        }
        total_width += columns[num_of_columns].width;
        num_of_columns++;
    }
    total_width += num_of_columns;

    if (total_width <= DBG_UTILS_SCRN_WIDTH_MAX) {
        tbl_display = 1;
    }

    if (debug_dump_json_g) {
        dbg_json_create_table_item(DBG_UTILS_LEVEL_SUB_HEADER_E);
    }

    original_data_p = (const void**)cl_calloc(num_of_columns, sizeof(void *));
    if (original_data_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for %d backup pointers.\n", num_of_columns);
    }

    if (original_data_p != NULL) {
        for (i = 0; i < num_of_columns; i++) {
            original_data_p[i] = columns[i].data;
        }
    }

    while (more_to_print) {
        more_to_print = 0;
        for (i = 0; i < num_of_columns; i++) {
            __type_to_str(columns[i].type, str_type);
            snprintf(add, sizeof(add) - 1, "%%%-u%s|", columns[i].width, str_type);
            add[sizeof(add) - 1] = 0;

            switch (columns[i].type) {
            case PARAM_EXT_STRING_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        p = __print_extended_string(stream, (char*)columns[i].data, columns[i].width);
                        if ((p == NULL) || (0 == *p)) {
                            column_print_flag[i] = 0;
                        } else {
                            columns[i].data = p;
                            more_to_print++;
                        }
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "%s", (const char*)(columns[i].data));
                break;

            case PARAM_STRING_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        snprintf(add, sizeof(add) - 1, "%%-%-u%s|", columns[i].width, str_type);
                        /* limit name up to width */
                        strncpy(name, (char*)columns[i].data, sizeof(name) - 1);
                        name[sizeof(name) - 1] = 0;
                        name[columns[i].width] = 0;
                        dbg_utils_print(stream, add, name);
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "%s", (const char*)(columns[i].data));
                break;

            case PARAM_MAC_ADDR_E:
                mac_ptr = ((uint8_t*)(columns[i].data));
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        k = columns[i].width - 17;
                        sprintf(add, "%%%us", k >= 0 ? k : 2);
                        dbg_utils_print(stream, add, "");
                        dbg_utils_print(stream,
                                        "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X|",
                                        mac_ptr[0],
                                        mac_ptr[1],
                                        mac_ptr[2],
                                        mac_ptr[3],
                                        mac_ptr[4],
                                        mac_ptr[5]);
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X",
                         mac_ptr[0], mac_ptr[1], mac_ptr[2], mac_ptr[3], mac_ptr[4], mac_ptr[5]);
                break;

            case PARAM_FC_ADDR_E:
                fc_ptr = ((uint8_t*)(columns[i].data));
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        k = columns[i].width - 8;
                        sprintf(add, "%%%us", k >= 0 ? k : 2);
                        dbg_utils_print(stream, add, "");
                        dbg_utils_print(stream, "%.2X:%.2X:%.2X|", fc_ptr[0], fc_ptr[1], fc_ptr[2]);
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "%.2X:%.2X:%.2X", fc_ptr[0], fc_ptr[1], fc_ptr[2]);
                break;

            case PARAM_IPV4_E:
            case PARAM_IPV4_MASK_E:
            {
                struct in_addr ip;
                char           addr[20];
                ip.s_addr = htonl(*((uint32_t*)(columns[i].data)));
                if (!inet_ntop(AF_INET, &ip, addr, 20)) {
                    strcpy(addr, "???");
                }
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        k = columns[i].width - strlen(addr);
                        sprintf(add, "%%%us", k >= 0 ? k : 2);
                        dbg_utils_print(stream, add, "");
                        dbg_utils_print(stream, "%s|", addr);
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "%s", addr);
                break;
            }

            case PARAM_IPV6_E:
            {
                struct in6_addr ipv6;
                char            addr[44];
                for (ipv6_idx = 0; ipv6_idx < 4; ipv6_idx++) {
                    ipv6.s6_addr32[ipv6_idx] =
                        htonl(((struct in6_addr*)columns[i].data)->s6_addr32[ipv6_idx]);
                }
                if (!inet_ntop(AF_INET6, &ipv6, addr, 44)) {
                    strcpy(addr, "???");
                }
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        k = columns[i].width - strlen(addr);
                        sprintf(add, "%%%us", k >= 0 ? k : 2);
                        dbg_utils_print(stream, add, "");
                        dbg_utils_print(stream, "%s|", addr);
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "%s", addr);
                break;
            }

            case PARAM_HEX64_E:
                sprintf(add, "0x%%.%u%s|", columns[i].width - 2, str_type);
            /* fall through */

            case PARAM_UINT64_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_print(stream, add, *((uint64_t*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                if (columns[i].type == PARAM_HEX64_E) {
                    snprintf(json_buf, sizeof(json_buf), "0x%" PRIx64 "", *((uint64_t*)(columns[i].data)));
                } else {
                    snprintf(json_buf, sizeof(json_buf), "%" PRIu64 "", *((uint64_t*)(columns[i].data)));
                }
                break;

            case PARAM_BOOL_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        snprintf(add, sizeof(add) - 1, "%%-%-u%s|", columns[i].width, str_type);
                        dbg_utils_print(stream, add, *((uint32_t*)(columns[i].data)) ?
                                        "TRUE" : "FALSE");
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "%s", *((boolean_t*)(columns[i].data)) ? "TRUE" : "FALSE");
                break;

            case PARAM_UINT8_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_print(stream, add, *((uint8_t*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "%hu", *((uint8_t*)(columns[i].data)));
                break;

            case PARAM_HEX16_E:
                sprintf(add, "0x%%.%u%s|", columns[i].width - 2, str_type);
            /* fall through */

            case PARAM_UINT16_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_print(stream, add, *((uint16_t*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                if (columns[i].type == PARAM_HEX16_E) {
                    snprintf(json_buf, sizeof(json_buf), "0x%X", *((uint16_t*)(columns[i].data)));
                } else {
                    snprintf(json_buf, sizeof(json_buf), "%u", *((uint16_t*)(columns[i].data)));
                }
                break;

            case PARAM_DOUBLE_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_print(stream, add, *((double*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "%.2f", *((double*)(columns[i].data)));
                break;

            case PARAM_INT_E:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_print(stream, add, *((int*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "%d", *((int*)(columns[i].data)));
                break;

            case PARAM_HEX_STRING_E:
                tlv_field_p = (dbg_utils_table_tlv_field_t*)columns[i].data;
                if (!tbl_display || column_print_flag[i]) {
                    if (tlv_field_p->data_len > DBG_UTILS_SCRN_WIDTH_MAX) {
                        SX_LOG_ERR("Internal error: bad length of field:%d type:%u\n", i, columns[i].type);
                        continue;
                    }
                }
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        if (sizeof(name) < (unsigned)columns[i].width) {
                            columns[i].width = sizeof(name);
                        }
                        __print_hex_string(name, columns[i].width,
                                           (unsigned char*)tlv_field_p->data,
                                           tlv_field_p->data_len);
                        dbg_utils_print(stream, add, name);
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_w_len(stream, columns[i].name,
                                                tlv_field_p->data,
                                                columns[i].type,
                                                tlv_field_p->data_len);
                }
                __print_hex_string(json_buf, DBG_UTILS_DATA_STR_PRECISION, tlv_field_p->data, tlv_field_p->data_len);
                break;

            case PARAM_PORT_ID_E:
                sprintf(add, "0x%%-%u%s|", columns[i].width - 2, str_type);
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_print(stream, add, *((uint32_t*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                snprintf(json_buf, sizeof(json_buf), "0x%x", *((uint32_t*)(columns[i].data)));
                break;

            case PARAM_HEX_E:
                sprintf(add, "0x%%.%u%s|", columns[i].width - 2, str_type);

            /* fall through */

            case PARAM_UINT32_E:
            default:
                if (tbl_display) {
                    if (column_print_flag[i]) {
                        dbg_utils_print(stream, add, *((uint32_t*)(columns[i].data)));
                        column_print_flag[i] = 0;
                    } else {
                        __print_empty_clmn(stream, columns[i].width);
                    }
                } else {
                    dbg_utils_print_field_simple(stream, columns[i].name, columns[i].data, columns[i].type, NULL, 0);
                }
                if (columns[i].type == PARAM_HEX_E) {
                    snprintf(json_buf, sizeof(json_buf), "0x%X", *((uint32_t*)(columns[i].data)));
                } else {
                    snprintf(json_buf, sizeof(json_buf), "%u", *((uint32_t*)(columns[i].data)));
                }
                break;
            }     /*switch*/
            __create_data_object(DBG_UTILS_LEVEL_DATA_E, columns[i].name, json_buf);
        }     /*for*/

        if (tbl_display) {
            dbg_utils_print(stream, "\n");
        }
    }     /*while*/

    if (original_data_p != NULL) {
        for (i = 0; i < num_of_columns; i++) {
            columns[i].data = original_data_p[i];
        }

        cl_free(original_data_p);
        original_data_p = NULL;
    }

    return total_width;
}

int dbg_utils_print_table_data_line(FILE *stream, dbg_utils_table_columns_t *columns)
{
    int total_width = 0;

    total_width = dbg_utils_print_table_data_line_nosep(stream, columns);
    dbg_utils_print_separator_line(stream, total_width, DBG_UTILS_DEFAULT_SEPARATOR_CHAR);
    return total_width;
}

void dbg_utils_print_counters_group_header(FILE *stream, const char *cntr_grp_name, uint32_t port_id)
{
    char cntr_grp_name_buf[DBG_UTILS_JSON_BUF_SIZE];

    dbg_utils_print(stream, "\n Port 0x%x - %.30s Counters Group \n", port_id, cntr_grp_name);
    dbg_utils_print(stream, "==================================================\n");

    snprintf(cntr_grp_name_buf, sizeof(cntr_grp_name_buf), "Port 0x%x - %.30s Counters Group", port_id, cntr_grp_name);
    dbg_json_create_header_object(DBG_UTILS_LEVEL_HEADER_E, cntr_grp_name_buf, FALSE);
}

void dbg_utils_print_counters_group_sub_header(FILE *stream, const char *headline_fmt, ...)
{
    va_list args;
    char    cptl_headline_fmt[strlen(headline_fmt) + 1];
    char    buf[DBG_UTILS_JSON_BUF_SIZE];

    dbg_utils_print(stream, "\n");

    dbg_utils_capitalize_string(headline_fmt, cptl_headline_fmt);

    va_start(args, headline_fmt);
    vsnprintf(buf, sizeof(buf), cptl_headline_fmt, args);
    va_end(args);

    fprintf(stream, "%s", buf);

    dbg_utils_print(stream, "\n..............................\n");

    dbg_json_create_header_object(DBG_UTILS_LEVEL_SUB_HEADER_E, buf, FALSE);
}


void dbg_utils_print_counter(FILE *stream, const char *cntr_name, uint64_t cntr_value)
{
    char buf[DBG_UTILS_JSON_BUF_SIZE];

    dbg_utils_print_field_simple(stream, cntr_name, &cntr_value, PARAM_UINT64_E, buf, sizeof(buf));
    __create_data_object(DBG_UTILS_LEVEL_DATA_E, cntr_name, buf);
}

void dbg_utils_print_counter_with_level(FILE             *stream,
                                        const char       *cntr_name,
                                        uint64_t          cntr_value,
                                        dbg_utils_level_e new_level)
{
    char buf[DBG_UTILS_JSON_BUF_SIZE];

    dbg_utils_print_field_simple(stream, cntr_name, &cntr_value, PARAM_UINT64_E, buf, sizeof(buf));
    __create_data_object(new_level, cntr_name, buf);
}


void dbg_utils_print_general_header(FILE *stream, const char *general_header)
{
    size_t header_len = 0;

    dbg_utils_print(stream, "\n..................................................\n");
    dbg_utils_print(stream, " %.48s \n", general_header);
    dbg_utils_print(stream, "..................................................\n");

    if (cheat_sheet_dump_in_progress) {
        header_len = strlen(general_header);
        header_len = (header_len < 48) ? header_len : 48;
        if (cheat_sheet_total_written + header_len + 3 < DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE) {
            cheat_sheet_buffer[cheat_sheet_total_written] = '\t';
            cheat_sheet_total_written++;
            cheat_sheet_buffer[cheat_sheet_total_written] = '\t';
            cheat_sheet_total_written++;
            strncpy(&cheat_sheet_buffer[cheat_sheet_total_written], general_header, header_len);
            cheat_sheet_total_written += header_len;
            cheat_sheet_buffer[cheat_sheet_total_written] = '\n';
            cheat_sheet_total_written++;
        }
    }

    dbg_json_create_header_object(DBG_UTILS_LEVEL_GENERAL_E, general_header, FALSE);
}

void dbg_utils_print_sub_module_header(FILE *stream, const char *sub_module_header)
{
    size_t header_len = 0;

    dbg_utils_print(stream, "\n--------------------------------------------------\n");
    dbg_utils_print(stream, " %.48s \n", sub_module_header);
    dbg_utils_print(stream, "--------------------------------------------------\n");

    if (cheat_sheet_dump_in_progress) {
        header_len = strlen(sub_module_header);
        header_len = (header_len < 48) ? header_len : 48;
        if (cheat_sheet_total_written + header_len + 2 < DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE) {
            cheat_sheet_buffer[cheat_sheet_total_written] = '\t';
            cheat_sheet_total_written++;
            strncpy(&cheat_sheet_buffer[cheat_sheet_total_written], sub_module_header, header_len);
            cheat_sheet_total_written += header_len;
            cheat_sheet_buffer[cheat_sheet_total_written] = '\n';
            cheat_sheet_total_written++;
        }
    }

    dbg_json_create_header_object(DBG_UTILS_LEVEL_SUB_MODULE_E, sub_module_header, FALSE);
}

void dbg_utils_print_plain_text_secondary_header(FILE *stream, const char *headline_fmt, ...)
{
    va_list args;
    char    cptl_headline_fmt[strlen(headline_fmt) + 1];

    dbg_utils_print(stream, "\n");

    dbg_utils_capitalize_string(headline_fmt, cptl_headline_fmt);

    va_start(args, headline_fmt);
    vfprintf(stream, cptl_headline_fmt, args);
    va_end(args);

    dbg_utils_print(stream, "\n..............................\n");
}

/* print user defined head with levels between DBG_UTILS_LEVEL_GENERAL_E and DBG_UTILS_LEVEL_SECONDARY_E */
void dbg_utils_print_user_defined_header(FILE             *stream,
                                         dbg_utils_level_e user_defined_level,
                                         const char       *headline_fmt,
                                         ...)
{
    va_list args;
    char    cptl_headline_fmt[strlen(headline_fmt) + 1];
    char    buf[DBG_UTILS_JSON_BUF_SIZE];

    dbg_utils_print(stream, "\n");

    dbg_utils_capitalize_string(headline_fmt, cptl_headline_fmt);

    va_start(args, headline_fmt);
    vsnprintf(buf, sizeof(buf), cptl_headline_fmt, args);
    va_end(args);

    fprintf(stream, "%s", buf);

    dbg_utils_print(stream, "\n..............................\n");

    if ((user_defined_level < DBG_UTILS_LEVEL_USER_DEFINED_MIN_E) ||
        (user_defined_level > DBG_UTILS_LEVEL_USER_DEFINED_MAX_E)) {
        SX_LOG_ERR("Invalid user_defined_level:%u\n", user_defined_level);
        return;
    }
    dbg_json_create_header_object(user_defined_level, buf, FALSE);
}


void dbg_utils_print_secondary_header(FILE *stream, const char *headline_fmt, ...)
{
    va_list args;
    char    cptl_headline_fmt[strlen(headline_fmt) + 1];
    char    buf[DBG_UTILS_JSON_BUF_SIZE];

    dbg_utils_print(stream, "\n");

    dbg_utils_capitalize_string(headline_fmt, cptl_headline_fmt);

    va_start(args, headline_fmt);
    vsnprintf(buf, sizeof(buf), cptl_headline_fmt, args);
    va_end(args);

    fprintf(stream, "%s", buf);

    dbg_utils_print(stream, "\n..............................\n");

    dbg_json_create_header_object(DBG_UTILS_LEVEL_SECONDARY_E, buf, FALSE);
}

void dbg_utils_print_time_stamp(FILE *stream, const char * name)
{
    time_t    ltime;
    struct tm result;
    char      stime[32];

    ltime = time(NULL);
    localtime_r(&ltime, &result);
    asctime_r(&result, stime);
    dbg_utils_print(stream, "\n%s: %s\n", name, stime);

    __create_data_object(DBG_UTILS_LEVEL_MODULE_E, name, stime);
}

void dbg_utils_print_separator_line(FILE *stream, int total_width, char separator_char)
{
    static char separator_line[DBG_UTILS_SCRN_WIDTH_MAX + 1];

    if (total_width > DBG_UTILS_SCRN_WIDTH_MAX) {
        total_width = DBG_UTILS_SCRN_WIDTH_MAX;
    }

    memset(separator_line, 0, sizeof(separator_line));
    memset(separator_line, separator_char, total_width);
    dbg_utils_print(stream, "%s\n", separator_line);
}

void __type_to_str(dbg_utils_param_type_e type_enum, char *str_type)
{
    strcpy(str_type, PARAM_TO_STR(type_enum));
}

const char* __print_extended_string(FILE *stream, const char* str, int width)
{
    char        add[20];
    char        buf[width + 1];
    char        help_buf[width + 1];
    const char *p, *p_help;
    int         buf_count, help_buf_count;

    buf[0] = '\0';
    buf_count = 0;
    p = str;

    while (*p != '\0' && buf_count < width) {
        help_buf_count = 0;
        help_buf[0] = '\0';
        p_help = p;
        while (*p_help != ' ' && *p_help != '\0' && help_buf_count < width) {
            if ((*p_help > 32) && (*p_help < 127)) {
                help_buf[help_buf_count] = *p_help;
                help_buf_count++;
            }
            p_help++;
        }
        if ((*p_help != ' ') && (*p_help != '\0')) {
            dbg_utils_print(stream, "/nERROR - the column's width is not enough/n/n");
            return NULL;
        }
        help_buf[help_buf_count] = '\0';
        if (help_buf_count + buf_count < width) {
            strcat(buf, help_buf);
            strcat(buf, " ");
            if (*p_help != '\0') {
                p_help++;
            }
            p = p_help;
            buf_count += help_buf_count + 1;
        } else {
            break;
        }
    }
    sprintf(add, "%%-%-us|", width);
    dbg_utils_print(stream, add, buf);
    return p;
}

void __print_empty_clmn(FILE *stream, int width)
{
    char add[20];

    sprintf(add, "%%%us|", width);
    dbg_utils_print(stream, add, "");     /* padding to columns[iii].width */
}

/**
 * Print a 3-digit number aligned to center, with bias to left
 */
static void dbg_utils_3_digits_center(FILE* stream, uint32_t number)
{
    uint32_t before = 1, after = 1;

    if (number >= 100) {
        before = 0;
        after = 0;
    } else if (number >= 10) {
        before = 0;
        after = 1;
    }
    dbg_utils_print(stream, "%*s%u%*s", before, "", number, after, "");
}

void dbg_utils_draw_binary_tree_node(draw_tree_node_context_t* context, uint32_t cur_node)
{
    uint32_t depth;
    char     buf[64] = {0};
    int      json_level_save = stacked_json_arr[stack_json_top].level;

    if (cur_node > context->tree->node_count) {
        SX_LOG_ERR("Cannot dump tree node %u which is out of bound %u\n", cur_node, context->tree->node_count);
        return;
    }

    if (context->line_broken) {
        for (depth = 0; depth < context->right_depth; depth++) {
            if (context->verticals[depth]) {
                dbg_utils_print(context->stream, " |    ");
            } else {
                dbg_utils_print(context->stream, "      ");
            }
        }
        dbg_utils_print(context->stream, " |\n");
        for (depth = 0; depth < context->right_depth; depth++) {
            if (context->verticals[depth]) {
                dbg_utils_print(context->stream, " |    ");
            } else {
                dbg_utils_print(context->stream, "      ");
            }
        }
        context->line_broken = FALSE;
    }
    dbg_utils_3_digits_center(context->stream, cur_node);
    snprintf(buf, sizeof(buf) - 1, "%u", cur_node);
    __create_data_object(json_level_save + 1, "value", buf);
    if (context->tree->nodes[cur_node].right_child != 0) {
        dbg_utils_print(context->stream, "---");
    }

    if (context->tree->nodes[cur_node].left_child != 0) {
        context->verticals[context->right_depth] = TRUE;
    } else {
        context->verticals[context->right_depth] = FALSE;
    }

    if (context->tree->nodes[cur_node].right_child != 0) {
        context->right_depth++;

        dbg_json_create_header_object(json_level_save + 1, "right", FALSE);
        dbg_utils_draw_binary_tree_node(context, context->tree->nodes[cur_node].right_child);
        context->right_depth--;
    } else {
        dbg_utils_print(context->stream, "\n");
        context->line_broken = TRUE;
    }

    if (context->tree->nodes[cur_node].left_child != 0) {
        /* prepare json object for left tree node*/
        dbg_json_create_header_object(json_level_save + 1, "left", FALSE);
        dbg_utils_draw_binary_tree_node(context, context->tree->nodes[cur_node].left_child);
    }

    context->verticals[context->right_depth] = FALSE;
}


void dbg_utils_draw_binary_tree(FILE *stream, const dbg_utils_tree_t* tree)
{
    boolean_t                verticals[DBG_UTILS_NODES_MAX];
    draw_tree_node_context_t context;

    if (tree->root > tree->node_count) {
        SX_LOG_ERR("Fail to draw binary tree because root is deeper than node, and json tree may be broken\n");
        return;
    }
    memset(verticals, 0, sizeof(verticals));
    context.stream = stream;
    context.tree = tree;
    context.right_depth = 0;
    context.verticals = verticals;
    context.line_broken = FALSE;

    dbg_json_create_header_object(DBG_UTILS_LEVEL_HEADER_E, "root", FALSE);

    dbg_utils_draw_binary_tree_node(&context, tree->root);
}

void dbg_utils_set_json_fp(FILE *stream)
{
    json_fp = stream;
}

void dbg_utils_print_data_unavailable(FILE *stream)
{
    dbg_utils_print(stream, "\nData is currently unavailable\n");
}

void dbg_utils_clear_json_children(sx_json_t *parent)
{
    if (parent == NULL) {
        return;
    }

    if (!(parent->type & cJSON_IsReference) && (parent->child != NULL)) {
        sx_json_delete(parent->child);
        parent->child = NULL;
    }
}


int dbg_utils_gen_json_array(sx_json_t * parent, const char          * array_name, sx_json_t          ** array_pp)
{
    int rc = 0;

    if (!debug_dump_json_g || (parent == NULL) || (array_name == NULL)) {
        return rc;
    }

    *array_pp = sx_json_create_array();
    if (!sx_json_add_item_to_object(parent, array_name, *array_pp)) {
        SX_LOG_ERR("sx_json_add_item_to_object failed, parent name: %s, array name: %s\n",
                   (parent->string == NULL) ? "" : parent->string, array_name);
        rc = -1;
        goto out;
    }

out:
    if (rc != 0) {
        if (*array_pp != NULL) {
            sx_json_delete(*array_pp);
            *array_pp = NULL;
        }
    }
    return rc;
}

int dbg_utils_gen_json_array_elem(sx_json_t           * parent_array,
                                  sx_json_t          ** elem_pp,
                                  dbg_utils_json_type_e data_type,
                                  void                 *value)
{
    int rc = 0;

    if (!debug_dump_json_g) {
        return rc;
    }

    switch (data_type) {
    case DBG_UTILS_JSON_TYPE_OBJECT_E:
        *elem_pp = sx_json_create_object();
        break;

    case DBG_UTILS_JSON_TYPE_STRING_E:
        *elem_pp = sx_json_create_string((const char*)value);
        break;

    default:
        SX_LOG_ERR("Internal error: wrong use of dbg_utils_gen_json_array_elem %u\n", data_type);
        rc = -1;
        goto out;
    }

    if (!sx_json_add_item_to_array(parent_array, *elem_pp)) {
        sx_json_delete(*elem_pp);
        *elem_pp = NULL;
        SX_LOG_ERR("dbg_utils_gen_json_array_elem failed, parent name: %s, data_type:%d\n",
                   (parent_array->string == NULL) ? "" : parent_array->string, data_type);
        rc = -2;
    }

out:
    return rc;
}
