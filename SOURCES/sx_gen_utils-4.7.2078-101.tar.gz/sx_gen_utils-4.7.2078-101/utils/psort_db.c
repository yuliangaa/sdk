/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <complib/cl_types.h>
#include <complib/cl_list.h>
#include <complib/cl_qmap.h>
#include <complib/cl_mem.h>
#include <complib/cl_dbg.h>
#include "utils/gen_utils.h"
#include "psort_db.h"


#undef  __MODULE__
#define __MODULE__ PSORT

/************************************************
 *  Local Defines
 ***********************************************/

#define PSORT_FOREGROUND_MOVE_SIZE  1
#define PSORT_DB_MIN_POOL_GROW_SIZE 64

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_utils_status_t __psort_db_add_region_to_table(psort_db_table_db_t   * psort_db_table_db,
                                                        psort_db_region_hole_t *pool_element);
static sx_utils_status_t __psort_db_remove_region_from_table(psort_db_table_db_t   * psort_db_table_db,
                                                             psort_db_region_hole_t *region_hole);
static sx_utils_status_t __psort_db_add_hole_exact_location(psort_db_table_db_t   * psort_db_table_db,
                                                            psort_db_region_hole_t *pool_element,
                                                            psort_db_region_hole_t *region_p);

/************************************************
 *  Function implementations
 ***********************************************/

#define PRI_REGION_HOLE "%s P%d [%u..%u] size %u"
#define PRI_REGION_HOLE_PARAM(rh)                                   \
    (rh->type == PSORT_REGION_TYPE_PRIORITY_E) ? "Region" : "Hole", \
    rh->priority, rh->start, rh->end, rh->size

static void __psort_db_update_threshold_values(psort_db_table_db_t *psort_db_table_db)
{
    psort_db_table_db->table_almost_full_val_threshold = psort_db_table_db->table_size *
                                                         psort_db_table_db->table_almost_full_precentage_threshold /
                                                         100;
    psort_db_table_db->table_almost_empty_val_threshold = psort_db_table_db->table_size *
                                                          psort_db_table_db->table_almost_empty_precentage_threshold /
                                                          100;
}

/* Allocate pSort Db */
sx_utils_status_t psort_db_init(psort_handle_t *handle, const psort_init_param_t *params)
{
    sx_utils_status_t       rc;
    uint32_t                i;
    psort_db_entries_db_t * psort_db_entries_db = NULL;
    psort_db_table_db_t    *psort_db_table_db = NULL;
    uint32_t                pool_grow_size;
    uint32_t                min_num_of_regions_holes;

    /* Num of regions = Max Priority - Min Priority + 1 */
    /* Num of holes = Max Priority - Min Priority + 1 (plus one, because last hole is needed to increase table size)*/
    /* Maximum number of regions holes : Num of regions + Num of Holes + 1 for split-hole */
    uint32_t num_of_regions_holes =
        (params->max_priority - params->min_priority + 1) + (params->max_priority - params->min_priority + 1) + 1;

    min_num_of_regions_holes = num_of_regions_holes;

    if (min_num_of_regions_holes > params->table_size + 1) {
        min_num_of_regions_holes = params->table_size + 1;
    }

    pool_grow_size = min_num_of_regions_holes / 8;
    if (pool_grow_size < PSORT_DB_MIN_POOL_GROW_SIZE) {
        pool_grow_size = PSORT_DB_MIN_POOL_GROW_SIZE;
    }

    rc = gen_utils_clr_memory_get((void**)(&psort_db_table_db),
                                  1,
                                  sizeof(psort_db_table_db_t),
                                  GEN_UTILS_MEM_TYPE_ID_PSORT_E);
    SX_UTILS_CHECK_RC(rc, "Allocate pSort table memory");

    rc = cl_list_init(&psort_db_table_db->table, num_of_regions_holes);
    cl_qmap_init(&psort_db_table_db->region_hole_map);
    psort_db_table_db->regions_holes_cnt = 0;
    psort_db_table_db->regions_cnt = 0;
    psort_db_table_db->holes_cnt = 0;
    psort_db_table_db->delta_size = params->delta_size;
    psort_db_table_db->max_priority = params->max_priority;
    psort_db_table_db->min_priority = params->min_priority;
    psort_db_table_db->sum_of_holes = 0;
    psort_db_table_db->total_free_entries = params->table_size;
    psort_db_table_db->table_size = params->table_size;
    psort_db_table_db->cookie = params->cookie;
    psort_db_table_db->notif_callback = params->notif_callback;
    psort_db_table_db->cntr_num_of_shifts = 0;
    psort_db_table_db->state = PSORT_TABLE_STATE_UNKNOWN_E;
    psort_db_table_db->background_worker_non_complete_cnt = 0;
    psort_db_table_db->table_almost_full_precentage_threshold = params->table_almost_full_precentage_threshold;
    psort_db_table_db->table_almost_empty_precentage_threshold = params->table_almost_empty_precentage_threshold;
    psort_db_table_db->destroy_table = FALSE;
    psort_db_table_db->refcount = 0;

    __psort_db_update_threshold_values(psort_db_table_db);

    psort_db_entries_db = &psort_db_table_db->psort_db_entries_db;


    /* Now init pool of free entries and push pSort entries there */
    rc = cl_list_init(&psort_db_entries_db->free_pool, params->table_size);

    SX_UTILS_CHECK_RC(rc, "cl_list_init");
    psort_db_entries_db->num_of_entries = params->table_size;
    /* Push ACL IDs to free pool */
    for (i = 0; i < psort_db_entries_db->num_of_entries; i++) {
        psort_entry_item_t *entry = NULL;
        /* Allocate pSort Entry and insert it to the free pool*/
        rc = gen_utils_clr_memory_get((void**)(&entry),
                                      1,
                                      sizeof(psort_entry_item_t),
                                      GEN_UTILS_MEM_TYPE_ID_PSORT_E);
        SX_UTILS_CHECK_RC(rc, "Allocate pSort table memory");
        /* coverity[leaked_storage] */
        cl_list_insert_tail(&psort_db_entries_db->free_pool, entry);
    }

    rc = CL_QPOOL_INIT(&psort_db_table_db->regions_holes_pool, min_num_of_regions_holes, num_of_regions_holes,
                       pool_grow_size, sizeof(psort_db_region_hole_t), NULL, NULL, NULL);
    SX_UTILS_CHECK_RC(rc, "Allocate PSORT regions pool");

    *handle = (psort_handle_t)(uintptr_t)psort_db_table_db;

    return SX_UTILS_STATUS_SUCCESS;
}


void psort_db_deinit()
{
}

sx_utils_status_t psort_db_add_entry(const psort_handle_t handle, psort_entry_t     *entry_p)
{
    sx_utils_status_t         rc = SX_UTILS_STATUS_SUCCESS;
    uint32_t                  free_space = 0;
    uint32_t                  free_space_above = 0;
    uint32_t                  free_space_below = 0;
    psort_db_region_hole_t  * region_p = NULL;
    psort_db_table_db_t      *psort_db_table_db = NULL;
    psort_db_move_direction_e dir;

    if ((handle == 0) || (NULL == entry_p)) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    /* 1. Is Region Found for requested priority? */
    if (psort_db_get_region(handle, entry_p->priority, &region_p) == TRUE) {
        /* region exist */
        SX_LOG(SX_LOG_DEBUG, "region for priority [%d] exist\n", entry_p->priority);
        /* Available space to insert new entry */
        free_space = psort_db_get_region_free_space(region_p);
        if (free_space > 0) {
            /* Insert entry to region*/
            rc = psort_db_insert_entry_to_region(handle, region_p, entry_p);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Error inserting entry to region priority [%d] rc [%s]\n",
                           entry_p->priority,
                           SX_UTILS_STATUS_MSG(rc));
                return rc;
            }
        } else {
            /* Available space in above or below hole */
            free_space_above = psort_db_get_hole_free_space(handle, region_p, TOP_HOLE_E);
            free_space_below = psort_db_get_hole_free_space(handle, region_p, BOTTOM_HOLE_E);

            /* Take space from the bigger hole */
            if ((free_space_above == 0) && (free_space_below == 0)) {
                /* Make Movements */
                rc = psort_db_move_regions_for_insertion(handle, region_p, FALSE, MOVE_DIRECITON_UP_E);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    if (rc == SX_UTILS_STATUS_NO_RESOURCES) {
                        /* Make Resize */
                        rc = psort_db_resize_regions_for_insertion(handle, region_p, MOVE_DIRECITON_UP_E);
                        if (rc != SX_UTILS_STATUS_SUCCESS) {
                            if (rc == SX_UTILS_STATUS_NO_RESOURCES) {
                                SX_LOG_INF(
                                    "Failed to resize regions for insertion entry to region priority [%d] rc [%s]\n",
                                    entry_p->priority,
                                    SX_UTILS_STATUS_MSG(rc));
                            } else {
                                SX_LOG_ERR(
                                    "Error resize regions for insertion entry to region priority [%d] rc [%s]\n",
                                    entry_p->priority,
                                    SX_UTILS_STATUS_MSG(rc));
                            }
                            return rc;
                        }

                        /* Try to move again */
                        rc = psort_db_move_regions_for_insertion(handle, region_p, FALSE, MOVE_DIRECITON_UP_E);
                        if (rc != SX_UTILS_STATUS_SUCCESS) {
                            if (rc == SX_UTILS_STATUS_NO_RESOURCES) {
                                SX_LOG_INF(
                                    "Error moving regions for insertion entry to region priority [%d] rc [%s]\n",
                                    entry_p->priority,
                                    SX_UTILS_STATUS_MSG(rc));
                            } else {
                                SX_LOG_ERR(
                                    "Error moving regions for insertion entry to region priority [%d] rc [%s]\n",
                                    entry_p->priority,
                                    SX_UTILS_STATUS_MSG(rc));
                            }
                            return rc;
                        }
                    } else {
                        SX_LOG_ERR("Error moving regions for insertion entry to region priority [%d] rc [%s]\n",
                                   entry_p->priority,
                                   SX_UTILS_STATUS_MSG(rc));
                        return rc;
                    }
                }

                /* calculate free space of top and above hole */
                free_space_above = psort_db_get_hole_free_space(handle, region_p, TOP_HOLE_E);
                free_space_below = psort_db_get_hole_free_space(handle, region_p, BOTTOM_HOLE_E);
                if ((free_space_above == 0) && (free_space_below == 0)) {
                    return SX_UTILS_STATUS_NO_RESOURCES;
                }

                /* expand region */
            }

            if (free_space_above >= free_space_below) {
                /* Expand to top */
                rc = psort_db_expand_region(handle, region_p, TOP_HOLE_E, psort_db_table_db->delta_size);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Error while inserting entry and trying to expand region priority [%d] to above hole rc [%s]\n",
                        entry_p->priority,
                        SX_UTILS_STATUS_MSG(rc));
                    return rc;
                }

                /* Insert entry to region*/
                rc = psort_db_insert_entry_to_region(handle, region_p, entry_p);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error inserting entry to region priority [%d] rc [%s]\n",
                               entry_p->priority,
                               SX_UTILS_STATUS_MSG(rc));
                    return rc;
                }
            } else {
                /* Expand to bottom */
                rc = psort_db_expand_region(handle, region_p, BOTTOM_HOLE_E, psort_db_table_db->delta_size);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "Error while inserting entry and trying to expand region priority [%d] to bottom hole rc [%s]\n",
                        entry_p->priority,
                        SX_UTILS_STATUS_MSG(rc));
                    return rc;
                }

                /* Insert entry to region*/
                rc = psort_db_insert_entry_to_region(handle, region_p, entry_p);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error inserting entry to region priority [%d] rc [%s]\n",
                               entry_p->priority,
                               SX_UTILS_STATUS_MSG(rc));
                    return rc;
                }
            }
        }
    } else {
        /* region not found */

        /* Available space to create a new region with H above and H below */
        uint32_t                new_hole_size = 0;
        psort_db_region_hole_t *hole_p = NULL;
        region_p = NULL;
        /* Get offset to allocate the new region */
        rc = psort_db_get_new_region_space(handle, &new_hole_size, &hole_p, &region_p, entry_p->priority);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error while inserting entry, error get space for new region rc [%s]\n",
                       SX_UTILS_STATUS_MSG(rc));
            return rc;
        }

        if (hole_p == NULL) {
            /* Resize regions */
            /* Make Movements */

            /* Lookup for closet region */
            /* Make Movements */
            if (region_p == NULL) {
                SX_LOG_ERR("Error No closest region entry, cannot allocate new region priority [%d]\n",
                           entry_p->priority);
                return SX_UTILS_STATUS_NO_RESOURCES;
            }
            dir = region_p->priority > entry_p->priority ? MOVE_DIRECITON_UP_E : MOVE_DIRECITON_DOWN_E;
            rc = psort_db_move_regions_for_insertion(handle, region_p, TRUE, dir);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                if (rc == SX_UTILS_STATUS_NO_RESOURCES) {
                    /* Make Resize */
                    rc = psort_db_resize_regions_for_insertion(handle, region_p, dir);
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        if (rc == SX_UTILS_STATUS_NO_RESOURCES) {
                            SX_LOG_INF(
                                "Failed to resize regions for insertion entry to region priority [%d] rc [%s]\n",
                                entry_p->priority,
                                SX_UTILS_STATUS_MSG(rc));
                        } else {
                            SX_LOG_ERR("Error resize regions for insertion entry to region priority [%d] rc [%s]\n",
                                       entry_p->priority,
                                       SX_UTILS_STATUS_MSG(rc));
                        }
                        return rc;
                    }

                    /* Try to get space again */
                    rc = psort_db_get_new_region_space(handle, &new_hole_size, &hole_p, &region_p, entry_p->priority);
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error while inserting entry, error get space for new region rc [%s]\n",
                                   SX_UTILS_STATUS_MSG(rc));
                        return rc;
                    }

                    if (hole_p == NULL) {
                        /* Try to move again */
                        rc = psort_db_move_regions_for_insertion(handle, region_p, TRUE, dir);
                        if (rc != SX_UTILS_STATUS_SUCCESS) {
                            SX_LOG_ERR("Error moving regions for insertion entry to region priority [%d] rc [%s]\n",
                                       entry_p->priority,
                                       SX_UTILS_STATUS_MSG(rc));
                            return rc;
                        }
                    }
                } else {
                    SX_LOG_ERR("Error moving regions for insertion entry to region priority [%d] rc [%s]\n",
                               entry_p->priority,
                               SX_UTILS_STATUS_MSG(rc));
                    return rc;
                }

                rc = psort_db_get_new_region_space(handle, &new_hole_size, &hole_p, &region_p, entry_p->priority);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error while inserting entry, error get space for new region rc [%s]\n",
                               SX_UTILS_STATUS_MSG(rc));
                    return rc;
                }

                if (hole_p == NULL) {
                    /* Try to move again , this is for the case that region_p is the tail.*/
                    dir = region_p->priority > entry_p->priority ? MOVE_DIRECITON_UP_E : MOVE_DIRECITON_DOWN_E;
                    rc = psort_db_move_regions_for_insertion(handle, region_p, TRUE, dir);
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error moving regions for insertion entry to region priority [%d] rc [%s]\n",
                                   entry_p->priority,
                                   SX_UTILS_STATUS_MSG(rc));
                        return rc;
                    }

                    rc = psort_db_get_new_region_space(handle, &new_hole_size, &hole_p, &region_p, entry_p->priority);
                    if (rc != SX_UTILS_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error while inserting entry, error get space for new region rc [%s]\n",
                                   SX_UTILS_STATUS_MSG(rc));
                        return rc;
                    }
                    if (hole_p == NULL) {
                        return SX_UTILS_STATUS_NO_RESOURCES;
                    }
                }
            } else {
                /* Try to get space again */
                rc = psort_db_get_new_region_space(handle, &new_hole_size, &hole_p, &region_p, entry_p->priority);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error while inserting entry, error get space for new region rc [%s]\n",
                               SX_UTILS_STATUS_MSG(rc));
                    return rc;
                }

                if (hole_p == NULL) {
                    return SX_UTILS_STATUS_NO_RESOURCES;
                }
            }
        }

        /* allocate new region */

        rc = psort_db_split_hole_and_allocate_region(handle,
                                                     hole_p,
                                                     PSORT_REGION_TYPE_PRIORITY_E,
                                                     entry_p->priority,
                                                     new_hole_size,
                                                     new_hole_size);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error split hole and allocate region entry with priority [%d] rc [%s]\n",
                       entry_p->priority,
                       SX_UTILS_STATUS_MSG(rc));
            return rc;
        }


        if (psort_db_get_region(handle, entry_p->priority, &region_p) == TRUE) {
            /* Insert entry to region*/
            rc = psort_db_insert_entry_to_region(handle, region_p, entry_p);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Error inserting entry to region priority [%d] rc [%s]\n",
                           entry_p->priority,
                           SX_UTILS_STATUS_MSG(rc));
                return rc;
            }
        }
    }

    return rc;
}

sx_utils_status_t psort_db_prio_change(const psort_handle_t handle,
                                       const int            min_prio,
                                       const int            max_prio,
                                       const int            prio_change)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_table_db_t *psort_db_table_db = NULL;
    int                  max_limit = INT32_MIN, min_limit = INT32_MAX;
    int                  prio_upper_limit = 0, prio_lower_limit = 0;
    cl_list_iterator_t   itor, itor_end;
    cl_map_item_t       *map_item = NULL;
    cl_map_item_t       *used_space_map_item = NULL;
    cl_map_item_t       *empty_space_map_item = NULL;
    const cl_map_item_t *empty_map_end = NULL;
    const cl_map_item_t *used_map_end = NULL;
    int                  priority;
    boolean_t            is_rule_prio_exist = FALSE;
    psort_entry_item_t  *entry_p = NULL;
    int64_t              max_prio_bound = 0, min_prio_bound = 0;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        rc = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (min_prio > max_prio) {
        SX_LOG_ERR("Min prio can't be bigger than Max prio\n");
        rc = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;


    max_prio_bound = (int64_t)max_prio + (int64_t)prio_change;
    min_prio_bound = (int64_t)min_prio + (int64_t)prio_change;

    if ((max_prio_bound > psort_db_table_db->max_priority) || (min_prio_bound < psort_db_table_db->min_priority)) {
        rc = SX_UTILS_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed psort_db_prio_change - priority is have to be in the range "
                   "[table.min_priority, table.max_priority], err [%s]\n", SX_UTILS_STATUS_MSG(rc));
        goto out;
    }

    /*Limitation verification:
     * The priority can be changed only if there is no other entries in range
     *  [min priority + change, max priority + change]*/
    itor = cl_list_head(&psort_db_table_db->table);
    itor_end = cl_list_end(&psort_db_table_db->table);

    while (itor != itor_end) {
        psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));

        if ((region_hole->priority <= max_prio) &&
            (region_hole->priority >= min_prio)) {
            if (region_hole->priority > max_limit) {
                max_limit = region_hole->priority;
            }
            if (region_hole->priority < min_limit) {
                min_limit = region_hole->priority;
            }
            is_rule_prio_exist = TRUE;
        }
        itor = cl_list_next(itor);
    }

    /* We didn't find a matching rule in range [min_priority,max_priority] */
    if (!is_rule_prio_exist) {
        goto out;
    }

    max_limit = max_limit + prio_change;
    min_limit = min_limit + prio_change;

    if (prio_change > 0) {
        prio_lower_limit = max_prio + 1;
        prio_upper_limit = max_limit;
    } else {
        prio_lower_limit = min_limit;
        prio_upper_limit = min_prio - 1;
    }

    itor = cl_list_head(&psort_db_table_db->table);
    itor_end = cl_list_end(&psort_db_table_db->table);

    while (itor != itor_end) {
        psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
        if ((region_hole->priority <= prio_upper_limit) &&
            (region_hole->priority >= prio_lower_limit)) {
            rc = SX_UTILS_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Failed psort_db_prio_change - The priority can be changed "
                       "only if there is no other rules in range [max_prio + 1 , max exist priority + change]"
                       "if prio_change > 0, and in range [min exist priority + change, min_prio - 1] if prio_change < 0 , err [%s]\n",
                       SX_UTILS_STATUS_MSG(rc));
            goto out;
        }
        itor = cl_list_next(itor);
    }

    /*Find the priority (old_prio) in the regions list and change it to new_prio
     * Note: psort lists the entries from the highest priorities to the lowest priorities  */
    if (prio_change > 0) {
        itor = cl_list_head(&psort_db_table_db->table);
        itor_end = cl_list_end(&psort_db_table_db->table);
    } else {
        itor = cl_list_tail(&psort_db_table_db->table);
        itor_end = cl_list_end(&psort_db_table_db->table);
    }

    while (itor != itor_end) {
        psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));


        if ((region_hole->priority >= min_prio) &&
            (region_hole->priority <= max_prio)) {
            priority = region_hole->priority;
            region_hole->priority = region_hole->priority + prio_change;
            map_item = cl_qmap_remove(&psort_db_table_db->region_hole_map, (uint64_t)priority);
            cl_qmap_insert(&psort_db_table_db->region_hole_map, region_hole->priority, map_item);

            used_space_map_item = cl_qmap_head(&region_hole->used_space);
            empty_space_map_item = cl_qmap_head(&region_hole->empty_space);
            used_map_end = cl_qmap_end(&region_hole->used_space);
            while (used_space_map_item != used_map_end) {
                entry_p = PARENT_STRUCT(used_space_map_item, psort_entry_item_t, map_item);
                entry_p->entry.priority = entry_p->entry.priority + prio_change;
                used_space_map_item = cl_qmap_next(used_space_map_item);
            }
            empty_map_end = cl_qmap_end(&region_hole->empty_space);
            while (empty_space_map_item != empty_map_end) {
                entry_p = PARENT_STRUCT(empty_space_map_item, psort_entry_item_t, map_item);
                entry_p->entry.priority = entry_p->entry.priority + prio_change;
                empty_space_map_item = cl_qmap_next(empty_space_map_item);
            }
        }

        if (prio_change > 0) {
            itor = cl_list_next(itor);
        } else {
            itor = cl_list_prev(itor);
        }
    }

out:
    return rc;
}

sx_utils_status_t psort_db_increase_table_size(const psort_handle_t handle, uint32_t new_size)
{
    sx_utils_status_t       rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_entries_db_t * psort_db_entries_db = NULL;
    uint32_t                new_size_diff = 0;
    uint32_t                i = 0;
    uint32_t                offset;
    uint32_t                size = 0;
    cl_list_iterator_t      itor;
    psort_db_region_hole_t *region_hole = NULL;
    psort_db_table_db_t    *psort_db_table_db = NULL;
    psort_entry_item_t     *new_entry = NULL;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (new_size < psort_db_table_db->table_size) {
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    new_size_diff = new_size - psort_db_table_db->table_size;

    psort_db_table_db->total_free_entries += new_size_diff;
    psort_db_table_db->table_size += new_size_diff;

    __psort_db_update_threshold_values(psort_db_table_db);

    psort_db_entries_db = &psort_db_table_db->psort_db_entries_db;

    while (cl_list_count(&psort_db_entries_db->free_pool) < new_size_diff) {
        /* Allocate pSort entry */
        rc = gen_utils_clr_memory_get((void**)(&new_entry),
                                      1,
                                      sizeof(psort_entry_item_t),
                                      GEN_UTILS_MEM_TYPE_ID_PSORT_E);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_UTILS_CHECK_RC(rc, "Allocate pSort table memory");
            return SX_UTILS_STATUS_NO_MEMORY;
        }
        /* coverity[leaked_storage] */
        rc = cl_list_insert_tail(&psort_db_entries_db->free_pool, new_entry);
        if (rc != CL_SUCCESS) {
            return SX_UTILS_STATUS_ERROR;
        }
    }

    /* Move last region to end of table */
    itor = cl_list_tail(&psort_db_table_db->table);
    region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));

    /* Add Region After Last Region */
    if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
        /* Last region is already hole expand it */
        for (i = 0; i < new_size_diff; i++) {
            /* Pop up free space */
            psort_entry_item_t *pool_free_entry_element = NULL;
            /* get from free pool */
            pool_free_entry_element = cl_list_remove_head(&psort_db_entries_db->free_pool);
            if (NULL == pool_free_entry_element) {
                return SX_UTILS_STATUS_NO_RESOURCES;
            }
            pool_free_entry_element->entry.index = i + region_hole->end + 1;
            pool_free_entry_element->entry.key = 0;
            pool_free_entry_element->entry.priority = 0;

            cl_qmap_insert(&region_hole->empty_space,
                           pool_free_entry_element->entry.index,
                           &pool_free_entry_element->map_item);
        }

        region_hole->size += new_size_diff;
        region_hole->end += new_size_diff;
        psort_db_table_db->sum_of_holes += new_size_diff;
    } else {
        /* Add hole after current region */
        offset = region_hole->end + 1;
        size = new_size_diff;
        rc = psort_db_allocate_region(handle, PSORT_REGION_TYPE_HOLE_E, 0, offset, size);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Allocate pSort Hole offset [%d]\n", offset);
            /* coverity[leaked_storage] */
            return rc;
        }
    }
    /* coverity[leaked_storage] */
    return rc;
}

/* Move all entries in one qmap to another qmap.
 * Optionally set the priority of entries in the process */
static void __psort_db_combine_qmaps(cl_qmap_t* dest, cl_qmap_t* source, int* priority_p)
{
    cl_map_item_t     * map_item;
    psort_entry_item_t* entry_element = NULL;

    while (cl_qmap_count(source) > 0) {
        map_item = cl_qmap_head(source);
        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);

        cl_qmap_remove_item(source, &entry_element->map_item);
        if (priority_p != NULL) {
            entry_element->entry.priority = *priority_p;
        }
        cl_qmap_insert(dest, entry_element->entry.index, &entry_element->map_item);
    }
}

/* Perform a shift of a block of entries inside a region.
 * Effectively swapping some (potentially) used space with some empty space */
static sx_utils_status_t __psort_db_region_shift_entries(psort_db_table_db_t   * psort_db_table_db,
                                                         psort_db_region_hole_t* region_p,
                                                         uint32_t                dest_index,
                                                         uint32_t                source_index,
                                                         uint32_t                count)
{
    psort_shift_param_t   shift_param;
    sx_utils_status_t     rc;
    cl_qmap_t             dest_items, source_used_items, source_empty_items;
    cl_map_item_t       * map_item = NULL;
    const cl_map_item_t * empty_map_end = NULL;
    const cl_map_item_t * used_map_end = NULL;
    psort_entry_item_t   *entry_element = NULL;
    uint32_t              index;

    cl_qmap_init(&dest_items);
    cl_qmap_init(&source_used_items);
    cl_qmap_init(&source_empty_items);

    /* Collect destination empty items */
    empty_map_end = cl_qmap_end(&region_p->empty_space);
    for (index = dest_index; index < dest_index + count; index++) {
        map_item = cl_qmap_get(&region_p->empty_space, index);
        if (map_item == empty_map_end) {
            __psort_db_combine_qmaps(&region_p->empty_space, &dest_items, NULL);
            SX_LOG_ERR("Error shifting entries into non-empty index %u\n", index);
            return SX_UTILS_STATUS_ERROR;
        }
        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
        cl_qmap_remove_item(&region_p->empty_space, &entry_element->map_item);
        cl_qmap_insert(&dest_items, entry_element->entry.index, &entry_element->map_item);
    }

    /* Collect source empty+used items */
    used_map_end = cl_qmap_end(&region_p->used_space);
    for (index = source_index; index < source_index + count; index++) {
        map_item = cl_qmap_get(&region_p->used_space, index);
        if (map_item != used_map_end) {
            entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
            cl_qmap_remove_item(&region_p->used_space, &entry_element->map_item);
            cl_qmap_insert(&source_used_items, entry_element->entry.index, &entry_element->map_item);
        } else {
            map_item = cl_qmap_get(&region_p->empty_space, index);
            if (map_item != empty_map_end) {
                entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
                cl_qmap_remove_item(&region_p->empty_space, &entry_element->map_item);
                cl_qmap_insert(&source_empty_items, entry_element->entry.index, &entry_element->map_item);
            } else {
                __psort_db_combine_qmaps(&region_p->empty_space, &source_empty_items, NULL);
                __psort_db_combine_qmaps(&region_p->used_space, &source_used_items, NULL);
                __psort_db_combine_qmaps(&region_p->empty_space, &dest_items, NULL);
                SX_LOG_ERR("Error shifting entries from non-existing index %u\n", index);
                return SX_UTILS_STATUS_ERROR;
            }
        }
    }

    if (cl_qmap_count(&source_used_items) > 0) {
        /* Perform the shift of all contents of region */
        memset(&shift_param, 0, sizeof(shift_param));
        shift_param.old_index = source_index;
        shift_param.new_index = dest_index;
        shift_param.size = count;

        /* Set to first used entry's key */
        map_item = cl_qmap_head(&source_used_items);
        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
        shift_param.key = entry_element->entry.key;

        if (psort_db_table_db->notif_callback != NULL) {
            psort_db_take_ref((psort_handle_t)(uintptr_t)psort_db_table_db);
            rc = psort_db_table_db->notif_callback(PSORT_TABLE_SHIFT_E, &shift_param, psort_db_table_db->cookie);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                /* Rollback the change */
                __psort_db_combine_qmaps(&region_p->empty_space, &source_empty_items, NULL);
                __psort_db_combine_qmaps(&region_p->used_space, &source_used_items, NULL);
                __psort_db_combine_qmaps(&region_p->empty_space, &dest_items, NULL);
                SX_LOG_ERR("Error at psort notification callback handle\n");
                psort_db_release_ref((psort_handle_t)(uintptr_t)psort_db_table_db, FALSE);
                return rc;
            }
            psort_db_release_ref((psort_handle_t)(uintptr_t)psort_db_table_db, FALSE);
        }
        psort_db_table_db->cntr_num_of_shifts += shift_param.size;
    }

    /* Update source items and put them back into empty/used space */
    while (cl_qmap_count(&source_used_items) > 0) {
        map_item = cl_qmap_head(&source_used_items);
        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
        cl_qmap_remove_item(&source_used_items, map_item);
        entry_element->entry.index += dest_index;
        entry_element->entry.index -= source_index;
        cl_qmap_insert(&region_p->used_space, entry_element->entry.index, &entry_element->map_item);
    }
    while (cl_qmap_count(&source_empty_items) > 0) {
        map_item = cl_qmap_head(&source_empty_items);
        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
        cl_qmap_remove_item(&source_empty_items, map_item);
        entry_element->entry.index += dest_index;
        entry_element->entry.index -= source_index;
        cl_qmap_insert(&region_p->empty_space, entry_element->entry.index, &entry_element->map_item);
    }

    /* Update destination items and put them back into empty space */
    while (cl_qmap_count(&dest_items) > 0) {
        map_item = cl_qmap_head(&dest_items);
        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
        cl_qmap_remove_item(&dest_items, map_item);
        entry_element->entry.index += source_index;
        entry_element->entry.index -= dest_index;
        cl_qmap_insert(&region_p->empty_space, entry_element->entry.index, &entry_element->map_item);
    }

    return SX_UTILS_STATUS_SUCCESS;
}

/* Resize a region or hole, by taking away all empty-space entries after a certain index */
static sx_utils_status_t __psort_db_resize_region_empty_space(psort_db_region_hole_t *region_hole_p,
                                                              uint32_t                max_index)
{
    sx_utils_status_t     rc;
    cl_map_item_t       * map_item;
    const cl_map_item_t * empty_map_end;
    uint32_t              index;
    psort_entry_item_t  * entry_element = NULL;

    empty_map_end = cl_qmap_end(&region_hole_p->empty_space);
    for (index = region_hole_p->end; index > max_index; index--) {
        map_item = cl_qmap_get(&region_hole_p->empty_space, index);
        if (map_item == empty_map_end) {
            /* Rollback the change */
            SX_LOG_ERR("Error at __psort_db_resize_region_empty_space. Entry at index %u is not unused.\n", index);
            return SX_UTILS_STATUS_ERROR;
        }

        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
        cl_qmap_remove_item(&region_hole_p->empty_space, &entry_element->map_item);

        rc = gen_utils_memory_put(entry_element, GEN_UTILS_MEM_TYPE_ID_PSORT_E);
        SX_UTILS_CHECK_RC(rc, "Free pSort entry memory");
        region_hole_p->end--;
        region_hole_p->size--;
    }

    return SX_UTILS_STATUS_SUCCESS;
}

/* Retrieve a used entry at index, with sane checks */
static sx_utils_status_t psort_db_region_hole_get_used_entry(psort_db_region_hole_t *region_hole,
                                                             uint32_t                index,
                                                             psort_entry_item_t   ** entry)
{
    if ((index < region_hole->start) || (index > region_hole->end)) {
        SX_LOG_ERR("Index %u is not in " PRI_REGION_HOLE "\n", index, PRI_REGION_HOLE_PARAM(region_hole));
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* All entries of a hole are unused */
    if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
        *entry = NULL;
        return SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    }

    cl_map_item_t* map_item = cl_qmap_get(&region_hole->used_space, index);

    if (map_item == cl_qmap_end(&region_hole->used_space)) {
        *entry = NULL;
        return SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    }
    *entry = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
    return SX_UTILS_STATUS_SUCCESS;
}

/* Retrieve an unused entry at index, with sane checks */
static sx_utils_status_t psort_db_region_hole_get_empty_entry(psort_db_region_hole_t *region_hole,
                                                              uint32_t                index,
                                                              psort_entry_item_t   ** entry)
{
    if ((index < region_hole->start) || (index > region_hole->end)) {
        SX_LOG_ERR("Index %u is not in " PRI_REGION_HOLE "\n", index, PRI_REGION_HOLE_PARAM(region_hole));
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cl_map_item_t* map_item = cl_qmap_get(&region_hole->empty_space, index);

    if (map_item == cl_qmap_end(&region_hole->empty_space)) {
        *entry = NULL;
        return SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    }
    *entry = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
    return SX_UTILS_STATUS_SUCCESS;
}

/* Reassign empty space at the margin of a region, to another adjacent region */
static sx_utils_status_t __psort_db_region_hole_reassign_empty_space(psort_db_region_hole_t* dest_p,
                                                                     psort_db_region_hole_t* source_p,
                                                                     uint32_t                count)
{
    uint32_t            index, start_index, end_index;
    cl_qmap_t           temp_map;
    psort_entry_item_t *entry_element;

    if (count > source_p->size) {
        SX_LOG_ERR("Error moving empty space, count %u is larger than source " PRI_REGION_HOLE "\n",
                   count,
                   PRI_REGION_HOLE_PARAM(source_p));
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    /* Determine start and end indexes which are to be moved */
    if ((source_p->end + 1) == dest_p->start) {
        start_index = source_p->end - count + 1;
    } else if ((dest_p->end + 1) == source_p->start) {
        start_index = source_p->start;
    } else {
        SX_LOG_ERR(
            "Error moving empty space, source " PRI_REGION_HOLE "and destination " PRI_REGION_HOLE "not consecutive\n",
            PRI_REGION_HOLE_PARAM(source_p),
            PRI_REGION_HOLE_PARAM(dest_p));
        return SX_UTILS_STATUS_PARAM_ERROR;
    }
    end_index = start_index + count - 1;
    if ((end_index < source_p->start) || (end_index > source_p->end)) {
        SX_LOG_ERR("Error moving empty space, end index %u is not in source " PRI_REGION_HOLE "\n",
                   end_index,
                   PRI_REGION_HOLE_PARAM(source_p));
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    /* Collect entries which are about to be moved, into a temporary map */
    cl_qmap_init(&temp_map);
    cl_map_item_t* map_item = NULL;

    for (index = start_index; index <= end_index; index++) {
        map_item = cl_qmap_get(&source_p->empty_space, index);
        if (map_item == cl_qmap_end(&source_p->empty_space)) {
            /* Rollback the operation */
            __psort_db_combine_qmaps(&source_p->empty_space, &temp_map, NULL);
            SX_LOG_ERR("Error reassigning empty space, Index %u not found in source " PRI_REGION_HOLE " empty space\n",
                       index,
                       PRI_REGION_HOLE_PARAM(source_p));
            return SX_UTILS_STATUS_PARAM_ERROR;
        }
        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
        cl_qmap_remove_item(&source_p->empty_space, &entry_element->map_item);
        cl_qmap_insert(&temp_map, entry_element->entry.index, &entry_element->map_item);
    }

    /* Add collected items to the destination region's empty space */
    __psort_db_combine_qmaps(&dest_p->empty_space, &temp_map, &dest_p->priority);

    /* Update both regions' bounds */
    if ((source_p->end + 1) == dest_p->start) {
        source_p->end -= count;
        dest_p->start -= count;
    } else {
        source_p->start += count;
        dest_p->end += count;
    }
    dest_p->size += count;
    source_p->size -= count;
    return SX_UTILS_STATUS_SUCCESS;
}

static psort_db_region_hole_t* __psort_db_region_object_get(psort_db_table_db_t* table_db)
{
    psort_db_region_hole_t* ret;
    cl_pool_item_t        * pool_item = cl_qpool_get(&table_db->regions_holes_pool);

    if (pool_item == NULL) {
        return NULL;
    }

    ret = PARENT_STRUCT(pool_item, psort_db_region_hole_t, pool_item);
    cl_qmap_init(&ret->empty_space);
    cl_qmap_init(&ret->used_space);
    return ret;
}

static void __psort_db_region_object_put(psort_db_table_db_t* table_db, psort_db_region_hole_t* region_hole_p)
{
    CL_ASSERT(cl_qmap_count(&region_hole_p->used_space) == 0);
    CL_ASSERT(cl_qmap_count(&region_hole_p->empty_space) == 0);

    cl_qpool_put(&table_db->regions_holes_pool, &region_hole_p->pool_item);
}

/* Resize a region to its minimal size, after it has been compacted.
 * Spare empty space is re-assigned to the next adjacent region/hole.
 * Such a hole is created if it does not already exist
 * If the region is left of 0-size, then it is completely removed from the table */
static sx_utils_status_t __psort_db_resize_compact_region(psort_db_table_db_t   * psort_db_table_db,
                                                          psort_db_region_hole_t *region_p,
                                                          uint32_t                after_end)
{
    sx_utils_status_t       err;
    cl_list_iterator_t      itor;
    psort_db_region_hole_t *next_region_hole_p = NULL;
    uint32_t                count;

    if (region_p->end < after_end) {
        return SX_UTILS_STATUS_SUCCESS;
    }

    /* Find next region or hole */
    itor = cl_qlist_next(region_p->list_item_p);
    if (itor != cl_list_end(&psort_db_table_db->table)) {
        /* Create a hole and add after this region */
        next_region_hole_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
    }

    /* Create 0-size next hole if there is no next element */
    if (next_region_hole_p == NULL) {
        next_region_hole_p = __psort_db_region_object_get(psort_db_table_db);
        if (NULL == next_region_hole_p) {
            SX_LOG_ERR("No resources in regions holes free pool\n");
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        next_region_hole_p->size = 0;
        next_region_hole_p->start = psort_db_table_db->table_size;
        next_region_hole_p->end = psort_db_table_db->table_size - 1;
        next_region_hole_p->type = PSORT_REGION_TYPE_HOLE_E;
        next_region_hole_p->priority = 0;

        cl_list_insert_tail(&psort_db_table_db->table, next_region_hole_p);
        itor = cl_list_tail(&psort_db_table_db->table);
        next_region_hole_p->list_item_p = (cl_list_item_t*)itor;

        psort_db_table_db->holes_cnt++;
        psort_db_table_db->regions_holes_cnt++;
    }

    count = (region_p->end - after_end) + 1;
    if (count > psort_db_get_region_free_space(region_p)) {
        count = psort_db_get_region_free_space(region_p);
    }
    err = __psort_db_region_hole_reassign_empty_space(next_region_hole_p, region_p, count);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "Cannot resize compacted region. Failed to reassign %u empty space from " PRI_REGION_HOLE " to " PRI_REGION_HOLE "\n",
            count,
            PRI_REGION_HOLE_PARAM(region_p),
            PRI_REGION_HOLE_PARAM(next_region_hole_p));
        return err;
    }

    if (next_region_hole_p->type == PSORT_REGION_TYPE_HOLE_E) {
        psort_db_table_db->sum_of_holes += count;
    }

    /* If the region became empty, get rid of it. */
    if (region_p->size < 1) {
        err = __psort_db_remove_region_from_table(psort_db_table_db, region_p);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to remove a leftover empty " PRI_REGION_HOLE "\n",
                       PRI_REGION_HOLE_PARAM(region_p));
            return err;
        }
    }
    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t psort_db_decrease_table_size(const psort_handle_t handle,
                                               uint32_t             new_size,
                                               boolean_t            is_background,
                                               uint32_t           * shift_count_p)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    uint32_t             new_size_diff = 0;
    uint32_t             region_size_diff = 0;
    psort_db_table_db_t *psort_db_table_db = NULL;

    /* Available space to create a new region with H above and H below */
    int                priority;
    boolean_t          is_single_priority;
    cl_list_iterator_t itor;
    cl_list_iterator_t list_end;


    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;
    list_end = cl_list_end(&psort_db_table_db->table);


    if (new_size > psort_db_table_db->table_size) {
        SX_LOG_ERR("Cannot decrease from %u to %u\n", psort_db_table_db->table_size, new_size);
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    new_size_diff = psort_db_table_db->table_size - new_size;

    rc = psort_db_is_single_priority(handle, &is_single_priority);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at psort_db_is_single_priority rc [%s]\n", SX_UTILS_STATUS_MSG(rc));
        return rc;
    }

    if (is_single_priority) {
        psort_db_region_hole_t *hole_p = NULL;
        psort_db_region_hole_t *region_p = NULL;
        uint32_t                shift_count;
        priority = psort_db_table_db->min_priority;

        if (psort_db_get_region(handle, priority, &region_p) == TRUE) {
            if (region_p->end >= new_size) {
                /* Attempt to compact the region so that it falls completely before the resize point */
                region_size_diff = region_p->end - new_size + 1;
                rc = psort_db_resize_region(handle,
                                            region_p,
                                            region_size_diff,
                                            TOP_HOLE_E,
                                            is_background,
                                            &shift_count);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error shifting " PRI_REGION_HOLE " to top\n",
                               PRI_REGION_HOLE_PARAM(region_p));
                    return rc;
                }
                if (shift_count_p != NULL) {
                    *shift_count_p = shift_count;
                }
                if (is_background && (shift_count > 0)) {
                    return SX_UTILS_STATUS_SUCCESS;
                }
            }

            itor = cl_list_next((cl_list_iterator_t)region_p->list_item_p);
            hole_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
        } else {
            itor = cl_list_head(&psort_db_table_db->table);
            hole_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
        }
        if (hole_p->type != PSORT_REGION_TYPE_HOLE_E) {
            SX_LOG_ERR("Cannot decrease table size if last region is not a hole but " PRI_REGION_HOLE "\n",
                       PRI_REGION_HOLE_PARAM(hole_p));
            return SX_UTILS_STATUS_ERROR;
        }
        if (hole_p->start > new_size) {
            SX_LOG_ERR("Cannot decrease table size if last hole starts after diff area " PRI_REGION_HOLE "\n",
                       PRI_REGION_HOLE_PARAM(hole_p));
            return SX_UTILS_STATUS_ERROR;
        }
        if (hole_p->end != psort_db_table_db->table_size - 1) {
            SX_LOG_ERR(
                "Cannot decrease table size if last hole does not end at end of table %u: " PRI_REGION_HOLE "\n",
                psort_db_table_db->table_size,
                PRI_REGION_HOLE_PARAM(hole_p));
            return SX_UTILS_STATUS_ERROR;
        }

        if (hole_p->start < new_size) {
            /* Reduce the size of the hole after the region, which now includes the resize area */
            rc = __psort_db_resize_region_empty_space(hole_p, new_size - 1);
            psort_db_table_db->sum_of_holes -= new_size_diff;
        } else {
            /* Remove the hole after the region, which is now exactly the resize area */
            rc = __psort_db_remove_region_from_table(psort_db_table_db, hole_p);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Error removing " PRI_REGION_HOLE " from single-priority psort table handle [%p]\n",
                           PRI_REGION_HOLE_PARAM(hole_p), psort_db_table_db);
                return rc;
            }
        }
    } else {
        psort_db_region_hole_t *region_hole_p = NULL;
        psort_db_region_hole_t *region_p = NULL;
        uint32_t                index = 0, from_index = 0;
        uint32_t                used_count = 0, empty_count = 0;
        psort_entry_item_t     *to_entry = NULL;
        psort_entry_item_t     *from_entry = NULL;

        /* Locate the largest index (unused entry) in the table, from which we can compact all used entries *before* new_size */
        itor = cl_list_tail(&psort_db_table_db->table);

        index = psort_db_table_db->table_size;
        while (index > 0) {
            index--;
            region_hole_p = (psort_db_region_hole_t*)(cl_list_obj(itor));

            while (region_hole_p->start > index) {
                itor = cl_list_prev(itor);
                region_hole_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
            }

            if ((index < new_size) && (used_count == 0)) {
                break;
            }

            rc = psort_db_region_hole_get_used_entry(region_hole_p, index, &to_entry);
            if ((rc != SX_UTILS_STATUS_SUCCESS) && (rc != SX_UTILS_STATUS_ENTRY_NOT_FOUND)) {
                SX_LOG_ERR("Failed to find used index %u in region " PRI_REGION_HOLE "\n",
                           index, PRI_REGION_HOLE_PARAM(region_hole_p));
                return rc;
            }

            if (rc == SX_UTILS_STATUS_SUCCESS) {
                used_count++;
            }
            if (index < new_size) {
                empty_count++;
                if (empty_count >= used_count) {
                    break;
                }
            }
        }

        region_p = region_hole_p;
        if (used_count > 0) {
            /* Perform compaction: Shift used entries so all are before new_size, and compact the regions */
            from_index = index;

            while (index < new_size) {
                rc = psort_db_region_hole_get_empty_entry(region_p, index, &to_entry);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to find empty index %u in region " PRI_REGION_HOLE "\n",
                               index, PRI_REGION_HOLE_PARAM(region_hole_p));
                    return rc;
                }
                /* Now, index is an unused index inside to_region_p's range, into which we are going to shift some used entry */
                do {
                    from_index++;
                    if (from_index >= psort_db_table_db->table_size) {
                        SX_LOG_ERR("Index overflow %u while compacting table for decrease\n", from_index);
                        return SX_UTILS_STATUS_ERROR;
                    }
                    while (from_index > region_p->end) {
                        itor = cl_list_next(region_p->list_item_p);
                        if (itor == list_end) {
                            SX_LOG_ERR("Table overflow while compacting table for decrease\n");
                            return SX_UTILS_STATUS_ERROR;
                        }
                        region_hole_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
                        /* Resize region_p so it ends at index-1, or remove region if empty */
                        rc = __psort_db_resize_compact_region(psort_db_table_db, region_p, index);
                        if (rc != SX_UTILS_STATUS_SUCCESS) {
                            SX_LOG_ERR("Failed to resize a compact " PRI_REGION_HOLE "\n",
                                       PRI_REGION_HOLE_PARAM(region_p));
                            return SX_UTILS_STATUS_ERROR;
                        }
                        region_p = region_hole_p;
                    }
                    rc = psort_db_region_hole_get_used_entry(region_p, from_index, &from_entry);
                    if ((rc != SX_UTILS_STATUS_SUCCESS) && (rc != SX_UTILS_STATUS_ENTRY_NOT_FOUND)) {
                        SX_LOG_ERR("Failed to find used index %u in region " PRI_REGION_HOLE "\n",
                                   index, PRI_REGION_HOLE_PARAM(region_p));
                        return rc;
                    }
                } while (rc == SX_UTILS_STATUS_ENTRY_NOT_FOUND);

                /* Now, from_index is a used index inside region_p's range, from which we are going to shift some entry */
                rc = __psort_db_region_shift_entries(psort_db_table_db, region_p, index, from_entry->entry.index, 1);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to shift index %u to %u in " PRI_REGION_HOLE "\n",
                               from_entry->entry.index,
                               index,
                               PRI_REGION_HOLE_PARAM(region_p));
                    return rc;
                }

                if (shift_count_p != NULL) {
                    (*shift_count_p)++;
                }

                if (is_background) {
                    return SX_UTILS_STATUS_SUCCESS;
                }

                index++;
            }
        } else {
            index++;
        }

        do {
            /* Resize last-used and remaining regions so they all end at index-1, or remove regions if empty */
            itor = cl_list_next(region_p->list_item_p);
            rc = __psort_db_resize_compact_region(psort_db_table_db, region_p, index);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to resize a compact " PRI_REGION_HOLE "\n", PRI_REGION_HOLE_PARAM(region_p));
                return SX_UTILS_STATUS_ERROR;
            }

            if (itor != list_end) {
                region_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
            }
        } while (itor != list_end);

        /* Find last hole at end of table (after the last region) */
        itor = cl_list_tail(&psort_db_table_db->table);
        region_hole_p = (psort_db_region_hole_t*)(cl_list_obj(itor));
        if (region_hole_p->type != PSORT_REGION_TYPE_HOLE_E) {
            SX_LOG_ERR("Failed to reduce psort, last element is not a hole: " PRI_REGION_HOLE "\n",
                       PRI_REGION_HOLE_PARAM(region_hole_p));
            rc = SX_UTILS_STATUS_ERROR;
            return rc;
        }

        if (region_hole_p->size != new_size_diff) {
            SX_LOG_ERR("Failed to reduce psort, " PRI_REGION_HOLE " is not diff_size %u\n",
                       PRI_REGION_HOLE_PARAM(region_hole_p), new_size_diff);
            rc = SX_UTILS_STATUS_ERROR;
            return rc;
        }

        /* Remove the hole, which is now exactly the diff */
        rc = __psort_db_remove_region_from_table(psort_db_table_db, region_hole_p);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to reduce psort, error removing " PRI_REGION_HOLE "\n",
                       PRI_REGION_HOLE_PARAM(region_hole_p));
            return rc;
        }
    }

    /* TODO If we removed the last region then need to create a new hole . size of table*/

    if (rc == SX_UTILS_STATUS_SUCCESS) {
        psort_db_table_db->total_free_entries -= new_size_diff;
        psort_db_table_db->table_size -= new_size_diff;
        psort_db_table_db->psort_db_entries_db.num_of_entries -= new_size_diff;

        __psort_db_update_threshold_values(psort_db_table_db);
    }

    return rc;
}

sx_utils_status_t psort_db_allocate_region(const psort_handle_t handle,
                                           psort_region_type_e  type,
                                           int                  priority,
                                           uint32_t             offset,
                                           uint32_t             size)
{
    uint32_t i;
    /* get from free pool */
    psort_db_region_hole_t *pool_element = NULL;
    psort_db_table_db_t    *psort_db_table_db = NULL;
    psort_db_entries_db_t * psort_db_entries_db = NULL;
    cl_list_iterator_t      itor;
    cl_list_iterator_t      list_end;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    psort_db_entries_db = &psort_db_table_db->psort_db_entries_db;

    /* get from free pool */
    pool_element = __psort_db_region_object_get(psort_db_table_db);
    if (NULL == pool_element) {
        SX_LOG_ERR("No resources in regions holes free pool\n");
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    pool_element->size = size;
    pool_element->start = offset;
    pool_element->end = pool_element->start + pool_element->size - 1;
    pool_element->type = type;
    /* Populate the empty space of the new region/hole */
    for (i = 0; i < pool_element->size; i++) {
        psort_entry_item_t *pool_free_entry_element = NULL;
        pool_free_entry_element = cl_list_remove_head(&psort_db_entries_db->free_pool);
        if (NULL == pool_free_entry_element) {
            SX_LOG_ERR("Not enough entry elements in psort pool\n");
            return SX_UTILS_STATUS_NO_RESOURCES;
        }
        pool_free_entry_element->entry.index = i + pool_element->start;
        pool_free_entry_element->entry.key = 0;
        pool_free_entry_element->entry.priority = priority;

        cl_qmap_insert(&pool_element->empty_space,
                       pool_free_entry_element->entry.index,
                       &pool_free_entry_element->map_item);
    }

    /* Add the new region/hole to the table at the sorted place */
    itor = cl_list_head(&psort_db_table_db->table);
    list_end = cl_list_end(&psort_db_table_db->table);
    while (itor != list_end) {
        psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
        if (region_hole->start >= pool_element->start) {
            /* Insert Previous */
            cl_list_insert_prev(&psort_db_table_db->table,
                                itor, pool_element);
            itor = cl_list_prev(itor);
            break;
        } else {
            itor = cl_list_next(itor);
        }
    }

    if (itor == list_end) {
        cl_list_insert_tail(&psort_db_table_db->table, pool_element);
        itor = cl_list_tail(&psort_db_table_db->table);
    }
    pool_element->list_item_p = (cl_list_item_t*)itor;

    switch (type) {
    case PSORT_REGION_TYPE_PRIORITY_E:
        pool_element->priority = priority;
        psort_db_table_db->regions_cnt++;
        cl_qmap_insert(&psort_db_table_db->region_hole_map, pool_element->priority, &pool_element->map_item);
        break;

    case PSORT_REGION_TYPE_HOLE_E:
        pool_element->priority = 0;
        psort_db_table_db->holes_cnt++;
        psort_db_table_db->sum_of_holes += size;
        break;

    default:
        /* unexpected switch case */
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    psort_db_table_db->regions_holes_cnt++;

    return SX_UTILS_STATUS_SUCCESS;
}

/* split hole and allocate region */
sx_utils_status_t psort_db_split_hole_and_allocate_region(const psort_handle_t    handle,
                                                          psort_db_region_hole_t *hole_p,
                                                          psort_region_type_e     type,
                                                          int                     priority,
                                                          uint32_t                hole_above_size,
                                                          uint32_t                hole_below_size)
{
    uint32_t          offset = 0;
    uint32_t          i = 0;
    uint32_t          size = 0;
    sx_utils_status_t rc;
    /* get from free pool */
    psort_db_region_hole_t *pool_element = NULL;
    cl_map_item_t          *map_item = NULL;
    psort_db_table_db_t    *psort_db_table_db = NULL;
    uint32_t                orig_hole_total_size;
    cl_list_iterator_t      itor;
    int                     hole_below_size_calc;
    psort_entry_item_t     *entry_element;
    cl_list_iterator_t      list_end;


    UNUSED_PARAM(hole_below_size);

    if ((handle == 0) || (hole_p == NULL)) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    /* Split the hole - Create a new Region and a hole : H - R - H*/

    size = psort_db_table_db->delta_size;
    orig_hole_total_size = cl_qmap_count(&hole_p->empty_space);

    offset = hole_above_size;
    if (offset > orig_hole_total_size) {
        offset = orig_hole_total_size;
    }
    if (size > orig_hole_total_size - offset) {
        size = orig_hole_total_size - offset;
    }

    /* Allocate new Region */
    pool_element = __psort_db_region_object_get(psort_db_table_db);
    if (NULL == pool_element) {
        SX_LOG_ERR("No resources in regions holes free pool\n");
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    pool_element->start = offset + hole_p->start;
    pool_element->size = size;
    pool_element->end = pool_element->start + pool_element->size - 1;
    pool_element->type = type;
    switch (pool_element->type) {
    case PSORT_REGION_TYPE_PRIORITY_E:
        pool_element->priority = priority;
        break;

    case PSORT_REGION_TYPE_HOLE_E:
        pool_element->priority = 0;
        break;

    default:
        /* unexpected switch case */
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    hole_p->end -= size;
    hole_p->size -= size;

    /* Populate the new region/hole's empty space using entries from the old big hole */
    for (i = pool_element->start; i <= pool_element->end; i++) {
        map_item = cl_qmap_get(&hole_p->empty_space, i);
        if (map_item == cl_qmap_end(&hole_p->empty_space)) {
            SX_LOG_ERR("Failed to find empty entry at index %u\n", i);
            return SX_UTILS_STATUS_ERROR;
        }
        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
        cl_qmap_remove_item(&hole_p->empty_space, &entry_element->map_item);
        entry_element->entry.priority = pool_element->priority;
        cl_qmap_insert(&pool_element->empty_space, entry_element->entry.index, &entry_element->map_item);
    }

    offset += size;

    /* Insert the new region/hole into the table at the sorted place */
    itor = cl_list_head(&psort_db_table_db->table);
    list_end = cl_list_end(&psort_db_table_db->table);
    while (itor != list_end) {
        psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
        if (region_hole->start >= pool_element->start) {
            /* Insert Previous */
            cl_list_insert_prev(&psort_db_table_db->table,
                                itor, pool_element);
            itor = cl_list_prev(itor);
            break;
        } else {
            itor = cl_list_next(itor);
        }
    }

    if (itor == list_end) {
        cl_list_insert_tail(&psort_db_table_db->table, pool_element);
        itor = cl_list_tail(&psort_db_table_db->table);
    }
    pool_element->list_item_p = (cl_list_item_t*)itor;

    switch (pool_element->type) {
    case PSORT_REGION_TYPE_PRIORITY_E:
        psort_db_table_db->regions_cnt++;
        cl_qmap_insert(&psort_db_table_db->region_hole_map, pool_element->priority, &pool_element->map_item);
        psort_db_table_db->sum_of_holes -= size;
        break;

    case PSORT_REGION_TYPE_HOLE_E:
        psort_db_table_db->holes_cnt++;
        break;

    default:
        /* unexpected switch case */
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    psort_db_table_db->regions_holes_cnt++;

    if (hole_p->size == 0) {
        /* We should delete the hole from the table */
        rc = __psort_db_remove_region_from_table(psort_db_table_db, hole_p);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error removing hole from psort table handle [%p]\n", psort_db_table_db);
            return rc;
        }
    }

    /* Create the Below Hole */
    hole_below_size_calc = orig_hole_total_size - hole_above_size - size;

    if (hole_below_size_calc > 0) {
        /* get from free pool */
        pool_element = __psort_db_region_object_get(psort_db_table_db);
        if (NULL == pool_element) {
            SX_LOG_ERR("No resources in regions holes free pool\n");
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        pool_element->size = (uint32_t)hole_below_size_calc;
        pool_element->start = offset + hole_p->start;
        pool_element->end = pool_element->start + pool_element->size - 1;
        pool_element->type = PSORT_REGION_TYPE_HOLE_E;
        pool_element->priority = 0;

        hole_p->size -= hole_below_size_calc;
        hole_p->end -= hole_below_size_calc;

        for (i = pool_element->start; i <= pool_element->end; i++) {
            map_item = cl_qmap_get(&hole_p->empty_space, i);
            if (map_item == cl_qmap_end(&hole_p->empty_space)) {
                SX_LOG_ERR("Failed to find empty entry at index %u\n", i);
                return SX_UTILS_STATUS_ERROR;
            }
            entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
            cl_qmap_remove_item(&hole_p->empty_space, &entry_element->map_item);
            entry_element->entry.priority = pool_element->priority;
            cl_qmap_insert(&pool_element->empty_space, entry_element->entry.index, &entry_element->map_item);
        }

        itor = cl_list_head(&psort_db_table_db->table);
        while (itor != list_end) {
            psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_hole->start >= pool_element->start) {
                /* Insert Previous */
                cl_list_insert_prev(&psort_db_table_db->table,
                                    itor, pool_element);
                itor = cl_list_prev(itor);
                break;
            } else {
                itor = cl_list_next(itor);
            }
        }


        if (itor == list_end) {
            cl_list_insert_tail(&psort_db_table_db->table, pool_element);
            itor = cl_list_tail(&psort_db_table_db->table);
        }
        pool_element->list_item_p = (cl_list_item_t*)itor;
        psort_db_table_db->holes_cnt++;
        psort_db_table_db->regions_holes_cnt++;

        if (hole_p->size == 0) {
            /* We should delete the hole from the table */
            rc = __psort_db_remove_region_from_table(psort_db_table_db, hole_p);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Error removing hole from psort table handle [%p]\n", psort_db_table_db);
                return rc;
            }
        }
    }

    return SX_UTILS_STATUS_SUCCESS;
}


uint8_t psort_db_get_region(const psort_handle_t handle, int priority, psort_db_region_hole_t** region_p)
{
    psort_db_table_db_t *psort_db_table_db = NULL;
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    /* 1. Is Region Found for requested priority? */

    map_item = cl_qmap_get(&psort_db_table_db->region_hole_map, priority);
    map_end = cl_qmap_end(&psort_db_table_db->region_hole_map);
    if (map_item != map_end) {
        /* Found */
        *region_p = PARENT_STRUCT(map_item, psort_db_region_hole_t, map_item);
        return TRUE;
    } else {
        *region_p = NULL;
    }

    return FALSE;
}

sx_utils_status_t psort_db_validate_priority(const psort_handle_t handle, int priority)
{
    psort_db_table_db_t *psort_db_table_db = NULL;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if ((priority > psort_db_table_db->max_priority) || (priority < psort_db_table_db->min_priority)) {
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    return SX_UTILS_STATUS_SUCCESS;
}


sx_utils_status_t psort_db_validate_index_exist(psort_db_region_hole_t* region_p, psort_entry_t*  entry_p)
{
    sx_utils_status_t   rc;
    psort_entry_item_t* entry_item;

    if (region_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    rc = psort_db_region_hole_get_used_entry(region_p, entry_p->index, &entry_item);
    return rc;
}

uint32_t psort_db_get_region_free_space(psort_db_region_hole_t* region_p)
{
    uint32_t cnt = cl_qmap_count(&region_p->empty_space);

    return cnt;
}

uint32_t psort_db_get_region_used_space(psort_db_region_hole_t* region_p)
{
    uint32_t cnt = cl_qmap_count(&region_p->used_space);

    return cnt;
}

uint32_t psort_db_get_table_actual_free_space(const psort_handle_t handle)
{
    psort_db_table_db_t *psort_db_table_db = NULL;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }
    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    return psort_db_table_db->total_free_entries;
}

uint32_t psort_db_get_table_size(const psort_handle_t handle)
{
    psort_db_table_db_t *psort_db_table_db = NULL;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }
    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    return psort_db_table_db->table_size;
}

uint32_t psort_db_get_table_almost_full_threshold_num(const psort_handle_t handle)
{
    psort_db_table_db_t *psort_db_table_db = NULL;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }
    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    return psort_db_table_db->table_almost_full_val_threshold;
}

uint32_t psort_db_get_table_almost_empty_threshold_num(const psort_handle_t handle)
{
    psort_db_table_db_t *psort_db_table_db = NULL;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }
    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    return psort_db_table_db->table_almost_empty_val_threshold;
}

uint32_t psort_db_get_hole_free_space(const psort_handle_t    handle,
                                      psort_db_region_hole_t* region_p,
                                      psort_hole_side_e       hole_side)
{
    psort_db_table_db_t    *psort_db_table_db = NULL;
    psort_db_region_hole_t *neighb_region = NULL;
    uint32_t                cnt = 0;
    cl_list_iterator_t      itor;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (hole_side == TOP_HOLE_E) {
        itor = region_p->list_item_p;
        if (itor == cl_list_head(&psort_db_table_db->table)) {
            return 0;
        }

        neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_prev));

        if (neighb_region->type != PSORT_REGION_TYPE_HOLE_E) {
            return 0;
        }

        cnt = cl_qmap_count(&neighb_region->empty_space);
    } else {
        /* Bottom Hole */
        itor = region_p->list_item_p;
        if (itor == cl_list_tail(&psort_db_table_db->table)) {
            return 0;
        }

        neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_next));
        if (neighb_region->type != PSORT_REGION_TYPE_HOLE_E) {
            return 0;
        }

        cnt = cl_qmap_count(&neighb_region->empty_space);
    }


    return cnt;
}


/* Decrease region size for insertion */
sx_utils_status_t psort_db_resize_regions_for_insertion(const psort_handle_t      handle,
                                                        psort_db_region_hole_t  * region_p,
                                                        psort_db_move_direction_e dir)
{
    psort_db_table_db_t       *psort_db_table_db = NULL;
    psort_db_region_hole_t    *neighb_region = NULL;
    cl_list_iterator_t         itor;
    cl_list_iterator_t         list_end;
    psort_db_region_hole_t    *region_hole = NULL;
    psort_db_region_hole_t    *most_top_region_hole_to_resize = NULL;
    psort_db_region_hole_t    *most_bottom_region_hole_to_resize = NULL;
    uint32_t                   free_space = 0;
    uint32_t                   resized_steps_top = 0;
    uint32_t                   resized_steps_bottom = 0;
    boolean_t                  can_resize_top = FALSE;
    boolean_t                  can_resize_bottom = FALSE;
    psort_db_reize_direction_e resize_direction = RESIZE_DIRECITON_UP_E;
    sx_utils_status_t          rc = SX_UTILS_STATUS_SUCCESS;
    boolean_t                  cont = TRUE;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;


    if (region_p == NULL) {
        itor = cl_list_tail(&psort_db_table_db->table);
        neighb_region = (psort_db_region_hole_t*)(cl_list_obj(itor));
        itor = neighb_region->list_item_p;
    } else {
        itor = region_p->list_item_p;
        if (itor != cl_list_head(&psort_db_table_db->table)) {
            if (dir == MOVE_DIRECITON_UP_E) {
                neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_prev));
                itor = neighb_region->list_item_p;
            }
        } else {
            cont = FALSE;
        }
    }

    /* 1. Lookup for the closet region for insertion top or bottom*/

    while (cont) {
        region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
        free_space = psort_db_get_region_free_space(region_hole);
        if (free_space > 0) {
            can_resize_top = TRUE;
            most_top_region_hole_to_resize = region_hole;
            break;
        }
        resized_steps_top++;
        if (itor == cl_list_head(&psort_db_table_db->table)) {
            cont = FALSE;
        } else {
            itor = cl_list_prev(itor);
        }
    }

    /* LookUp for a region resize in the bottom direction */
    list_end = cl_list_end(&psort_db_table_db->table);

    if (region_p != NULL) {
        itor = region_p->list_item_p;

        if (itor != cl_list_tail(&psort_db_table_db->table)) {
            neighb_region = region_p;
            itor = neighb_region->list_item_p;

            while (itor != list_end) {
                region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));

                free_space = psort_db_get_region_free_space(region_hole);
                if (free_space > 0) {
                    can_resize_bottom = TRUE;
                    most_bottom_region_hole_to_resize = region_hole;
                    break;
                }

                resized_steps_bottom++;
                itor = cl_list_next(itor);
            }
        } else {
            region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));

            free_space = psort_db_get_region_free_space(region_hole);
            if (free_space > 0) {
                can_resize_bottom = TRUE;
                most_bottom_region_hole_to_resize = region_hole;
            }
        }
    }
    /* can resized at all ? */
    if (can_resize_bottom == FALSE) {
        if (can_resize_top == FALSE) {
            /* cannot resized/move either in top or bottom */
            SX_LOG_DBG("Cannot resized/move either in top or bottom\n");
            return SX_UTILS_STATUS_NO_RESOURCES;
        } else {
            /* resize direction is up */
            resize_direction = RESIZE_DIRECITON_UP_E;
        }
    } else {
        if (can_resize_top == FALSE) {
            /* resize direction is down */
            resize_direction = RESIZE_DIRECITON_DOWN_E;
        } else {
            if (resized_steps_top <= resized_steps_bottom) {
                /* resize direction is up */
                resize_direction = RESIZE_DIRECITON_UP_E;
            } else {
                /* resize direction is down */
                resize_direction = RESIZE_DIRECITON_DOWN_E;
            }
        }
    }

    switch (resize_direction) {
    case RESIZE_DIRECITON_UP_E:
        /* resize most_top_region_hole_to_resize */

        rc = psort_db_resize_region(handle,
                                    most_top_region_hole_to_resize,
                                    1 /*psort_db_table_db->delta_size*/,
                                    TOP_HOLE_E,
                                    FALSE,
                                    NULL);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error shifting region\n");
            return rc;
        }

        /* end case */
        break;

    case RESIZE_DIRECITON_DOWN_E:
        rc = psort_db_resize_region(handle,
                                    most_bottom_region_hole_to_resize,
                                    1 /*psort_db_table_db->delta_size*/,
                                    BOTTOM_HOLE_E,
                                    FALSE,
                                    NULL);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error shifting region\n");
            return rc;
        }

        /* end case */
        break;
    }

    return SX_UTILS_STATUS_SUCCESS;
}

/* Move regions to make free space for insertion */
sx_utils_status_t psort_db_move_regions_for_insertion(const psort_handle_t      handle,
                                                      psort_db_region_hole_t  * region_p,
                                                      boolean_t                 isMoveForAllocate,
                                                      psort_db_move_direction_e dir)
{
    psort_db_table_db_t      *psort_db_table_db = NULL;
    psort_db_region_hole_t   *neighb_region = NULL;
    cl_list_iterator_t        itor;
    psort_db_region_hole_t   *region_hole = NULL;
    uint32_t                  shift_count = 0;
    uint32_t                  free_space = 0;
    uint32_t                  move_steps_top = 0;
    uint32_t                  move_steps_bottom = 0;
    boolean_t                 can_move_top = FALSE;
    boolean_t                 can_move_bottom = FALSE;
    psort_db_region_hole_t ** regions_to_move = NULL;
    psort_db_move_direction_e move_direction = MOVE_DIRECITON_UP_E;
    uint32_t                  i = 0;
    boolean_t                 is_last_region = FALSE;
    int                       j = 0;
    sx_utils_status_t         rc = SX_UTILS_STATUS_SUCCESS;
    boolean_t                 cont = TRUE;
    cl_list_iterator_t        list_end;


    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;


    if (region_p == NULL) {
        if (isMoveForAllocate) {
            SX_LOG_ERR("NULL region specified with Move For Allocate\n");
            return SX_UTILS_STATUS_PARAM_NULL;
        }
        itor = cl_list_tail(&psort_db_table_db->table);
        neighb_region = (psort_db_region_hole_t*)(cl_list_obj(itor));
        itor = neighb_region->list_item_p;
        if (itor == cl_list_head(&psort_db_table_db->table)) {
            cont = FALSE;
        }
    } else {
        itor = region_p->list_item_p;
        if (itor != cl_list_head(&psort_db_table_db->table)) {
            /* Check if this is not the last region. Otherwise take the neighbor region */
            if ((itor == cl_list_tail(&psort_db_table_db->table)) &&
                (dir == MOVE_DIRECITON_UP_E)) {
                is_last_region = TRUE;
            } else {
                neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_prev));
                itor = neighb_region->list_item_p;
                is_last_region = FALSE;
            }
        } else {
            cont = FALSE;
        }
    }

    /* 1. Lookup for the closet region for insertion top or bottom*/

    while (cont) {
        region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
        if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
            free_space = psort_db_get_region_free_space(region_hole);
            if (free_space > 0) {
                can_move_top = TRUE;
                break;
            }
        }
        move_steps_top++;
        if (itor == cl_list_head(&psort_db_table_db->table)) {
            cont = FALSE;
        } else {
            itor = cl_list_prev(itor);
        }
    }

    /* LookUp for a region move in the bottom direction */
    list_end = cl_list_end(&psort_db_table_db->table);
    if (region_p != NULL) {
        itor = region_p->list_item_p;

        if (itor != cl_list_tail(&psort_db_table_db->table)) {
            neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_next));
            itor = neighb_region->list_item_p;

            while (itor != list_end) {
                region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
                if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
                    free_space = psort_db_get_region_free_space(region_hole);
                    if (free_space > 0) {
                        can_move_bottom = TRUE;
                        break;
                    }
                }
                move_steps_bottom++;
                itor = cl_list_next(itor);
            }
        } else {
            region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
                free_space = psort_db_get_region_free_space(region_hole);
                if (free_space > 0) {
                    can_move_bottom = TRUE;
                }
            }
        }
    } /* end if if (region_p != NULL) */

    /* can move at all ? */
    if (can_move_bottom == FALSE) {
        if (can_move_top == FALSE) {
            /* cannot move either in top or bottom */
            SX_LOG_DBG("Cannot move either in top or bottom\n");
            return SX_UTILS_STATUS_NO_RESOURCES;
        } else {
            /* move direction is up */
            move_direction = MOVE_DIRECITON_UP_E;
        }
    } else {
        if (can_move_top == FALSE) {
            /* move direction is down */
            move_direction = MOVE_DIRECITON_DOWN_E;
        } else {
            if (move_steps_top <= move_steps_bottom) {
                /* move direction is up */
                move_direction = MOVE_DIRECITON_UP_E;
            } else {
                /* move direction is down */
                move_direction = MOVE_DIRECITON_DOWN_E;
            }
        }
    }

    if (move_direction == MOVE_DIRECITON_UP_E) {
        if (move_steps_top == 0) {
            if (isMoveForAllocate == TRUE) {
                /* shift region down */
                rc = psort_db_shift_region(handle, region_p, PSORT_FOREGROUND_MOVE_SIZE, TOP_HOLE_E, &shift_count);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error shifting region\n");
                    return rc;
                }
            }
            goto out;
        }
        /*psort_db_region_hole_t* regions_to_move[move_steps_top];*/
        regions_to_move = (psort_db_region_hole_t**)cl_malloc(sizeof(psort_db_region_hole_t*) * move_steps_top);

        if (regions_to_move == NULL) {
            SX_LOG_ERR("Error allocating memory!\n");
            goto out;
        }
        for (i = 0; i < move_steps_top; i++) {
            *(regions_to_move + i) = NULL;
        }
        i = 0;

        if (region_p == NULL) {
            itor = cl_list_tail(&psort_db_table_db->table);
            neighb_region = (psort_db_region_hole_t*)(cl_list_obj(itor));
        } else {
            itor = region_p->list_item_p;
            /* check if this is the last region */
            if (is_last_region == FALSE) {
                neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_prev));
            } else {
                itor = cl_list_tail(&psort_db_table_db->table);
                neighb_region = (psort_db_region_hole_t*)(cl_list_obj(itor));
            }
        }
        itor = neighb_region->list_item_p;
        /* 1. Lookup for the closet region for insertion top or bottom*/
        while (i < move_steps_top) {
            region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
                free_space = psort_db_get_region_free_space(region_hole);
                if (free_space > 0) {
                    break;
                }
            }

            *(regions_to_move + i) = region_hole;

            i++;
            itor = cl_list_prev(itor);
        }

        /* Move one by one from j=i to 0 in the upper direction */
        if (i == 0) {
            j = 0;
        } else {
            j = i - 1;
        }
        while (j >= 0) {
            /* move region up by size*/

            if (regions_to_move[j] != NULL) {
                rc = psort_db_shift_region(handle,
                                           regions_to_move[j],
                                           PSORT_FOREGROUND_MOVE_SIZE,
                                           TOP_HOLE_E,
                                           &shift_count);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error shifting region\n");
                    goto out;
                }
            }
            j--;
        }
    } else {
        /* MOVE_DIRECITON_DOWN */
        if (move_steps_bottom == 0) {
            if (isMoveForAllocate == TRUE) {
                /* shift region down */
                rc = psort_db_shift_region(handle, region_p, PSORT_FOREGROUND_MOVE_SIZE, BOTTOM_HOLE_E, &shift_count);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error shifting region\n");
                    return rc;
                }
            }

            goto out;
        }

        /*psort_db_region_hole_t* regions_to_move[move_steps_bottom];*/

        regions_to_move = (psort_db_region_hole_t**)cl_malloc(sizeof(psort_db_region_hole_t*) * move_steps_bottom);

        if (regions_to_move == NULL) {
            SX_LOG_ERR("Error allocating memory!\n");
            goto out;
        }
        for (i = 0; i < move_steps_bottom; i++) {
            /*regions_to_move[i] = NULL;*/
            *(regions_to_move + i) = NULL;
        }
        i = 0;

        neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_next));
        itor = neighb_region->list_item_p;
        /* 1. Lookup for the closet region for insertion top or bottom*/
        while (i < move_steps_bottom) {
            region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
                free_space = psort_db_get_region_free_space(region_hole);
                if (free_space > 0) {
                    break;
                }
            }

            *(regions_to_move + i) = region_hole;
            /*regions_to_move[i] = region_hole;*/
            i++;
            itor = cl_list_next(itor);
        }

        /* Move one by one from j=i to 0 in the upper direction */
        if (i == 0) {
            j = 0;
        } else {
            j = i - 1;
        }
        while (j >= 0) {
            /* move region up by size*/

            if (regions_to_move[j] != NULL) {
                rc = psort_db_shift_region(handle,
                                           regions_to_move[j],
                                           PSORT_FOREGROUND_MOVE_SIZE,
                                           BOTTOM_HOLE_E,
                                           &shift_count);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error shifting region\n");
                    goto out;
                }
            }
            j--;
        }

        if (isMoveForAllocate == TRUE) {
            /* shift region down */
            rc = psort_db_shift_region(handle, region_p, PSORT_FOREGROUND_MOVE_SIZE, BOTTOM_HOLE_E, &shift_count);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Error shifting region\n");
                goto out;
            }
        }
    } /* end else */

out:

    if (regions_to_move != NULL) {
        cl_free(regions_to_move);
    }
    return rc;
}

/* Expand region from top or bottom hole */
sx_utils_status_t psort_db_expand_region(const psort_handle_t    handle,
                                         psort_db_region_hole_t* region_p,
                                         psort_hole_side_e       hole_side,
                                         uint32_t                size)
{
    psort_db_table_db_t    *psort_db_table_db = NULL;
    psort_db_region_hole_t *neighb_region = NULL;
    sx_utils_status_t       rc;
    uint32_t                count;
    uint32_t                hole_size = 0;
    cl_list_iterator_t      itor;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (hole_side == TOP_HOLE_E) {
        itor = region_p->list_item_p;
        if (itor == cl_list_head(&psort_db_table_db->table)) {
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_prev));
    } else {
        /* Bottom Hole */
        itor = region_p->list_item_p;
        if (itor == cl_list_tail(&psort_db_table_db->table)) {
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_next));
    }

    if (neighb_region->type != PSORT_REGION_TYPE_HOLE_E) {
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    hole_size = cl_qmap_count(&neighb_region->empty_space);
    if (hole_size == 0) {
        return SX_UTILS_STATUS_NO_RESOURCES;
    }
    count = size;
    if (count > hole_size) {
        count = hole_size;
    }

    rc = __psort_db_region_hole_reassign_empty_space(region_p, neighb_region, count);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Error reassigning empty space for region expansion [%p]\n", psort_db_table_db);
        return rc;
    }

    if (region_p->type != neighb_region->type) {
        if (region_p->type == PSORT_REGION_TYPE_HOLE_E) {
            psort_db_table_db->sum_of_holes += count;
        } else {
            psort_db_table_db->sum_of_holes -= count;
        }
    }

    if (neighb_region->size == 0) {
        rc = __psort_db_remove_region_from_table(psort_db_table_db, neighb_region);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error removing hole from psort table handle [%p]\n", psort_db_table_db);
            return rc;
        }
    }

    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t __psort_db_remove_region_from_table(psort_db_table_db_t   * psort_db_table_db,
                                                      psort_db_region_hole_t *region_hole)
{
    cl_map_item_t   * map_item = NULL;
    sx_utils_status_t rc;

    switch (region_hole->type) {
    case PSORT_REGION_TYPE_PRIORITY_E:
        psort_db_table_db->regions_cnt--;
        cl_qmap_remove_item(&psort_db_table_db->region_hole_map, &region_hole->map_item);
        break;

    case PSORT_REGION_TYPE_HOLE_E:
        region_hole->priority = 0;
        psort_db_table_db->holes_cnt--;
        psort_db_table_db->sum_of_holes -= region_hole->size;
        break;

    default:
        /* unexpected switch case */
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* release used item and empty items */
    while (cl_qmap_count(&region_hole->empty_space) > 0) {
        psort_entry_item_t *entry_element = NULL;
        map_item = cl_qmap_head(&region_hole->empty_space);
        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);

        cl_qmap_remove_item(&region_hole->empty_space, map_item);
        /* free back memory */
        rc = gen_utils_memory_put(entry_element, GEN_UTILS_MEM_TYPE_ID_PSORT_E);
        SX_UTILS_CHECK_RC(rc, "Free pSort entry memory");
    }

    /* release used item and empty items */
    while (cl_qmap_count(&region_hole->used_space) > 0) {
        psort_entry_item_t *entry_element = NULL;
        map_item = cl_qmap_head(&region_hole->used_space);
        entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);

        cl_qmap_remove_item(&region_hole->used_space, map_item);
        /* free back memory */
        rc = gen_utils_memory_put(entry_element, GEN_UTILS_MEM_TYPE_ID_PSORT_E);
        SX_UTILS_CHECK_RC(rc, "Free pSort entry memory");
        psort_db_table_db->total_free_entries++;
    }

    cl_list_remove_item(&psort_db_table_db->table, region_hole->list_item_p);

    psort_db_table_db->regions_holes_cnt--;

    /* put back in free pool */
    __psort_db_region_object_put(psort_db_table_db, region_hole);

    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t __psort_db_add_region_to_table(psort_db_table_db_t   * psort_db_table_db,
                                                 psort_db_region_hole_t *pool_element)
{
    cl_list_iterator_t itor;
    cl_status_t        cl_status = CL_SUCCESS;
    cl_list_iterator_t list_end;

    list_end = cl_list_end(&psort_db_table_db->table);
    itor = cl_list_head(&psort_db_table_db->table);

    while (itor != list_end) {
        psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
        if (region_hole->start >= pool_element->start) {
            /* Insert Previous */
            cl_list_insert_prev(&psort_db_table_db->table,
                                itor, pool_element);
            itor = cl_list_prev(itor);
            break;
        } else {
            itor = cl_list_next(itor);
        }
    }


    if (itor == list_end) {
        cl_status = cl_list_insert_tail(&psort_db_table_db->table, pool_element);
        if (cl_status != CL_SUCCESS) {
            return SX_UTILS_STATUS_ERROR;
        }
        itor = cl_list_tail(&psort_db_table_db->table);
    }
    pool_element->list_item_p = (cl_list_item_t*)itor;

    switch (pool_element->type) {
    case PSORT_REGION_TYPE_PRIORITY_E:
        psort_db_table_db->regions_cnt++;
        cl_qmap_insert(&psort_db_table_db->region_hole_map, pool_element->priority, &pool_element->map_item);
        break;

    case PSORT_REGION_TYPE_HOLE_E:
        pool_element->priority = 0;
        psort_db_table_db->holes_cnt++;
        break;

    default:
        /* unexpected switch case */
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    psort_db_table_db->regions_holes_cnt++;

    return SX_UTILS_STATUS_SUCCESS;
}
/* function add the new hole before or after the current region depends on start index */
static sx_utils_status_t __psort_db_add_hole_exact_location(psort_db_table_db_t   * psort_db_table_db,
                                                            psort_db_region_hole_t *pool_element,
                                                            psort_db_region_hole_t *region_p)
{
    cl_list_iterator_t itor;
    cl_status_t        cl_status = CL_SUCCESS;

    if (pool_element->type != PSORT_REGION_TYPE_HOLE_E) {
        SX_LOG_ERR("Wrong pool element type. Only holes are allowed \n");
        return SX_UTILS_STATUS_ERROR;
    }


    if (region_p->start >= pool_element->start) {
        cl_status = cl_list_insert_prev(&psort_db_table_db->table,
                                        region_p->list_item_p, pool_element);
        if (cl_status != CL_SUCCESS) {
            return SX_UTILS_STATUS_ERROR;
        }

        itor = cl_list_prev(region_p->list_item_p);
    } else {
        cl_status = cl_list_insert_next(&psort_db_table_db->table,
                                        region_p->list_item_p, pool_element);
        if (cl_status != CL_SUCCESS) {
            return SX_UTILS_STATUS_ERROR;
        }
        itor = cl_list_next(region_p->list_item_p);
    }

    pool_element->list_item_p = (cl_list_item_t*)itor;

    pool_element->priority = 0;
    psort_db_table_db->holes_cnt++;


    psort_db_table_db->regions_holes_cnt++;

    return SX_UTILS_STATUS_SUCCESS;
}


sx_utils_status_t psort_db_defrag_region_empty_space_list(const psort_handle_t    handle,
                                                          psort_db_direction_e    direction,
                                                          psort_db_region_hole_t* region_p,
                                                          uint32_t                first_index,
                                                          uint32_t                last_index,
                                                          boolean_t               is_background,
                                                          uint32_t               *shift_count_p)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_table_db_t *psort_db_table_db = NULL;
    uint32_t             left_to_sort = 0;
    uint32_t             current_sorting_index = 0;
    uint32_t             empty_space = 0;
    boolean_t            found = FALSE;
    uint32_t             empty_index;
    cl_map_item_t       *map_item;
    psort_entry_item_t  *empty_entry_element = NULL;

    if (shift_count_p != NULL) {
        *shift_count_p = 0;
    }

    if (PSORT_DB_DIRECITON_UP_E == direction) {
        current_sorting_index = last_index;
    } else {
        current_sorting_index = first_index;
    }
    empty_space = psort_db_get_region_free_space(region_p);

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    map_item = cl_qmap_head(&region_p->empty_space);
    if (map_item == cl_qmap_end(&region_p->empty_space)) {
        SX_LOG_ERR("No free space for defragging [%" PRIu64 "]\n", handle);
        return SX_UTILS_STATUS_ERROR;
    }

    empty_entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
    empty_index = empty_entry_element->entry.index;

    /* defrag empty space list */
    for (left_to_sort = 0; left_to_sort < empty_space; left_to_sort++) {
        /* lookup for  current_sorting_index in used list*/
        psort_entry_item_t *entry_element = NULL;
        rc = psort_db_region_hole_get_used_entry(region_p, current_sorting_index, &entry_element);
        if (rc == SX_UTILS_STATUS_SUCCESS) {
            /* switch with an empty list item, which is not within first_index...last_index */
            do {
                found = FALSE;
                if ((empty_index < first_index) ||
                    (empty_index > first_index + empty_space - 1)) {
                    map_item = cl_qmap_get(&region_p->empty_space, empty_index);
                    found = (map_item != cl_qmap_end(&region_p->empty_space));
                }
                if (!found) {
                    empty_index++;
                    if (empty_index > region_p->end) {
                        SX_LOG_ERR("Not enough free space for defragging [%" PRIu64 "]\n", handle);
                        return SX_UTILS_STATUS_ERROR;
                    }
                } else {
                    empty_entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
                }
            } while (!found);

            rc = __psort_db_region_shift_entries(psort_db_table_db,
                                                 region_p,
                                                 empty_entry_element->entry.index,
                                                 entry_element->entry.index,
                                                 1);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to shift entry %u to %u when splitting a hole [%" PRIu64 "]\n",
                           entry_element->entry.index,
                           empty_entry_element->entry.index,
                           handle);
                return SX_UTILS_STATUS_ERROR;
            }

            if (shift_count_p != NULL) {
                *shift_count_p = *shift_count_p + 1;
            }
            if (is_background == TRUE) {
                /* Background worker allowed only one move per cycle */
                goto out;
            }
        }
        rc = SX_UTILS_STATUS_SUCCESS;
        if (PSORT_DB_DIRECITON_UP_E == direction) {
            current_sorting_index--;
        } else {
            current_sorting_index++;
        }
    } /* end for */

out:
    return rc;
}

sx_utils_status_t psort_db_defrag_single_priority(const psort_handle_t handle,
                                                  boolean_t            is_background,
                                                  uint32_t            *shift_count_p)
{
    /* cut the region and create a hole underneath */

    sx_utils_status_t       rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_table_db_t    *psort_db_table_db = NULL;
    uint32_t                empty_space = 0;
    uint32_t                used_space = 0;
    uint32_t                first_index;
    uint32_t                last_index;
    psort_db_region_hole_t *region_p;
    boolean_t               is_single_priority;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    rc = psort_db_is_single_priority(handle, &is_single_priority);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check if single-priority\n");
        return rc;
    }

    if (!is_single_priority) {
        SX_LOG_ERR("Not single-priority\n");
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (psort_db_get_region(handle, psort_db_table_db->min_priority, &region_p) != TRUE) {
        if (shift_count_p != NULL) {
            *shift_count_p = 0;
        }
        return SX_UTILS_STATUS_SUCCESS;
    }

    empty_space = psort_db_get_region_free_space(region_p);
    if (empty_space == 0) {
        return SX_UTILS_STATUS_SUCCESS;
    }
    used_space = psort_db_get_region_used_space(region_p);
    if (used_space == 0) {
        return SX_UTILS_STATUS_SUCCESS;
    }

    first_index = region_p->end - empty_space + 1;
    last_index = region_p->end;

    /* defrag empty space list */
    rc = psort_db_defrag_region_empty_space_list(handle,
                                                 PSORT_DB_DIRECITON_UP_E,
                                                 region_p,
                                                 first_index,
                                                 last_index,
                                                 is_background,
                                                 shift_count_p);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Error defrag region priority [%d] from psort table handle [%p]\n",
                   region_p->priority,
                   psort_db_table_db);
        return rc;
    }

    return SX_UTILS_STATUS_SUCCESS;
}


/* shift region to top or bottom hole */
sx_utils_status_t psort_db_resize_region(const psort_handle_t    handle,
                                         psort_db_region_hole_t* region_p,
                                         uint32_t                resize_size,
                                         psort_hole_side_e       hole_side,
                                         boolean_t               is_background,
                                         uint32_t               *shift_count_p)
{
    /* cut the region and create a hole underneath */

    sx_utils_status_t       rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_table_db_t    *psort_db_table_db = NULL;
    psort_db_region_hole_t *pool_element = NULL;
    uint32_t                empty_space = 0;
    cl_list_iterator_t      itor;
    boolean_t               should_create_new_hole = FALSE;
    uint32_t                first_index;
    uint32_t                last_index;
    uint32_t                left_to_sort;
    psort_db_region_hole_t *region_hole;
    psort_db_region_hole_t *next_region;
    psort_db_region_hole_t *prev_region;
    uint32_t                expand_size = 0;
    cl_map_item_t          *map_item;
    uint32_t                index;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (hole_side == TOP_HOLE_E) {
        empty_space = psort_db_get_region_free_space(region_p);
        if (empty_space == 0) {
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        /* Take element from empty space in hole and insert it to empty space at region */

        if (resize_size > empty_space) {
            resize_size = empty_space;
        }
        first_index = region_p->end - resize_size + 1;
        last_index = region_p->end;
        left_to_sort = 0;

        /* defrag empty space list */
        rc = psort_db_defrag_region_empty_space_list(handle,
                                                     PSORT_DB_DIRECITON_UP_E,
                                                     region_p,
                                                     first_index,
                                                     last_index,
                                                     is_background,
                                                     shift_count_p);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error defrag region priority [%d] from psort table handle [%p]\n",
                       region_p->priority,
                       psort_db_table_db);
            return rc;
        }

        if (is_background == TRUE) {
            if (*shift_count_p == 0) {
                left_to_sort = resize_size;
            } else {
                left_to_sort = *shift_count_p;
            }
        } else {
            left_to_sort = resize_size;
        }

        /* Check if allocate new hole */
        itor = cl_list_next(region_p->list_item_p);

        if (itor == cl_list_end(&psort_db_table_db->table)) {
            should_create_new_hole = TRUE;
        } else {
            psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
                should_create_new_hole = FALSE;
                pool_element = region_hole;
            } else {
                should_create_new_hole = TRUE;
            }
        }

        if (TRUE == should_create_new_hole) {
            /* get from free pool */
            pool_element = __psort_db_region_object_get(psort_db_table_db);
            if (NULL == pool_element) {
                SX_LOG_ERR("No resources in regions holes free pool\n");
                return SX_UTILS_STATUS_NO_RESOURCES;
            }

            pool_element->start = region_p->end - left_to_sort + 1;
            pool_element->size = left_to_sort;
            pool_element->end = pool_element->start + pool_element->size - 1;
            pool_element->type = PSORT_REGION_TYPE_HOLE_E;
            pool_element->priority = 0;
        } else { /* if (TRUE == should_create_new_hole)*/
            pool_element->start -= left_to_sort;
            pool_element->size += left_to_sort;
        } /* end if */

        region_p->size -= left_to_sort;
        region_p->end -= left_to_sort;
        psort_db_table_db->sum_of_holes += left_to_sort;

        for (index = pool_element->start; index <= pool_element->start + left_to_sort - 1; index++) {
            psort_entry_item_t *entry_element = NULL;
            map_item = cl_qmap_get(&region_p->empty_space, index);
            if (map_item == cl_qmap_end(&region_p->empty_space)) {
                SX_LOG_ERR("Cannot find entry %u in empty space of region\n", index);
                return SX_UTILS_STATUS_ERROR;
            }
            entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
            cl_qmap_remove_item(&region_p->empty_space, &entry_element->map_item);
            entry_element->entry.priority = pool_element->priority;
            cl_qmap_insert(&pool_element->empty_space, entry_element->entry.index, &entry_element->map_item);
        }
    } else {
        empty_space = psort_db_get_region_free_space(region_p);
        if (empty_space == 0) {
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        /* Take element from empty space in hole and insert it to empty space at region */

        if (resize_size > empty_space) {
            resize_size = empty_space;
        }

        first_index = region_p->start;
        last_index = region_p->start + resize_size - 1;
        left_to_sort = 0;

        /* defrag empty space list */
        rc = psort_db_defrag_region_empty_space_list(handle,
                                                     PSORT_DB_DIRECITON_DOWN_E,
                                                     region_p,
                                                     first_index,
                                                     last_index,
                                                     is_background,
                                                     shift_count_p);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error defrag region priority [%d] from psort table handle [%p]\n",
                       region_p->priority,
                       psort_db_table_db);
            return rc;
        }

        if (is_background == TRUE) {
            if (*shift_count_p == 0) {
                left_to_sort = resize_size;
            } else {
                left_to_sort = *shift_count_p;
            }
        } else {
            left_to_sort = resize_size;
        }

        /* allocate region */

        if (region_p->list_item_p == cl_list_head(&psort_db_table_db->table)) {
            should_create_new_hole = TRUE;
        } else {
            /* Check if allocate new hole */
            itor = cl_list_prev(region_p->list_item_p);
            region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
                should_create_new_hole = FALSE;
                pool_element = region_hole;
            } else {
                should_create_new_hole = TRUE;
            }
        }

        if (TRUE == should_create_new_hole) {
            /* get from free pool */
            pool_element = __psort_db_region_object_get(psort_db_table_db);
            if (NULL == pool_element) {
                SX_LOG_ERR("No resources in regions holes free pool\n");
                return SX_UTILS_STATUS_NO_RESOURCES;
            }

            pool_element->start = region_p->start;
            pool_element->size = left_to_sort;
            pool_element->end = pool_element->start + pool_element->size - 1;
            pool_element->type = PSORT_REGION_TYPE_HOLE_E;
            pool_element->priority = 0;
        } else {
            pool_element->size += left_to_sort;
            pool_element->end += left_to_sort;
        }
        region_p->size -= left_to_sort;
        region_p->start += left_to_sort;
        psort_db_table_db->sum_of_holes += left_to_sort;

        for (index = pool_element->end - left_to_sort + 1; index <= pool_element->end; index++) {
            psort_entry_item_t *entry_element = NULL;
            map_item = cl_qmap_get(&region_p->empty_space, index);
            if (map_item == cl_qmap_end(&region_p->empty_space)) {
                SX_LOG_ERR("Cannot find entry %u in empty space of region\n", index);
                return SX_UTILS_STATUS_ERROR;
            }
            entry_element = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);
            cl_qmap_remove_item(&region_p->empty_space, &entry_element->map_item);
            entry_element->entry.priority = pool_element->priority;
            cl_qmap_insert(&pool_element->empty_space, entry_element->entry.index, &entry_element->map_item);
        }
    }

    if (should_create_new_hole) {
        rc = __psort_db_add_region_to_table(psort_db_table_db, pool_element);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error adding new hole to psort table\n");
            return rc;
        }
    }

    /* Should delete the region ? */
    if (region_p->size == 0) {
        /* If previous region is a hole then we need to combine 2 hole into 1 hole */
        /* check if next region and prev region is hole */

        itor = region_p->list_item_p;
        if ((itor != cl_list_head(&psort_db_table_db->table)) && (itor != cl_list_tail(&psort_db_table_db->table))) {
            /* Check if allocate new hole */
            itor = cl_list_next(region_p->list_item_p);
            next_region = (psort_db_region_hole_t*)(cl_list_obj(itor));
            itor = cl_list_prev(region_p->list_item_p);
            prev_region = (psort_db_region_hole_t*)(cl_list_obj(itor));
            /* We should delete the region from the table */
            rc = __psort_db_remove_region_from_table(psort_db_table_db, region_p);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Error removing region priority [%d] from psort table handle [%p]\n",
                           region_p->priority,
                           psort_db_table_db);
                return rc;
            }

            if ((next_region->type == PSORT_REGION_TYPE_HOLE_E) && (prev_region->type == PSORT_REGION_TYPE_HOLE_E)) {
                expand_size = psort_db_get_region_free_space(prev_region);

                /* Expand to top */
                rc = psort_db_expand_region(handle, next_region, TOP_HOLE_E, expand_size);
                if (rc != SX_UTILS_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error while trying to expand hole to above hole rc [%s]\n", SX_UTILS_STATUS_MSG(rc));
                    return rc;
                }
            } else {
                if (pool_element->type == PSORT_REGION_TYPE_HOLE_E) {
                    itor = pool_element->list_item_p;
                    if ((itor != cl_list_head(&psort_db_table_db->table)) &&
                        (itor != cl_list_tail(&psort_db_table_db->table))) {
                        itor = cl_list_next(pool_element->list_item_p);
                        next_region = (psort_db_region_hole_t*)(cl_list_obj(itor));
                        itor = cl_list_prev(pool_element->list_item_p);
                        prev_region = (psort_db_region_hole_t*)(cl_list_obj(itor));
                        if (next_region->type == PSORT_REGION_TYPE_HOLE_E) {
                            expand_size = psort_db_get_region_free_space(pool_element);

                            /* Expand to top */
                            rc = psort_db_expand_region(handle, next_region, TOP_HOLE_E, expand_size);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error while trying to expand hole to above hole rc [%s]\n",
                                           SX_UTILS_STATUS_MSG(rc));
                                return rc;
                            }
                        } else if (prev_region->type == PSORT_REGION_TYPE_HOLE_E) {
                            expand_size = psort_db_get_region_free_space(prev_region);

                            /* Expand to top */
                            rc = psort_db_expand_region(handle, pool_element, TOP_HOLE_E, expand_size);
                            if (rc != SX_UTILS_STATUS_SUCCESS) {
                                SX_LOG_ERR("Error while trying to expand hole to above hole rc [%s]\n",
                                           SX_UTILS_STATUS_MSG(rc));
                                return rc;
                            }
                        }
                    }
                }
            }
        } else {
            /* We should delete the region from the table */
            rc = __psort_db_remove_region_from_table(psort_db_table_db, region_p);
            if (rc != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Error removing region priority [%d] from psort table handle [%p]\n",
                           region_p->priority,
                           psort_db_table_db);
                return rc;
            }
        }
    }

    return SX_UTILS_STATUS_SUCCESS;
}

/* shift region to top or bottom hole */
sx_utils_status_t psort_db_shift_region(const psort_handle_t    handle,
                                        psort_db_region_hole_t* region_p,
                                        uint32_t                shift_block_size,
                                        psort_hole_side_e       hole_side,
                                        uint32_t               *shift_count_p)
{
    /* cut the region and create a hole underneath */
    sx_utils_status_t       rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_table_db_t    *psort_db_table_db = NULL;
    psort_db_region_hole_t *neighb_region = NULL;
    psort_db_region_hole_t *pool_element = NULL;
    uint32_t                shift_size = 0;
    cl_list_iterator_t      itor;
    uint32_t                hole_size = 0;
    boolean_t               should_create_new_hole = FALSE;
    psort_db_region_hole_t *region_hole;
    uint32_t                dest_index;
    uint32_t                source_index;
    uint32_t                hole_index = 0;

    *shift_count_p = 0;

    if (region_p->list_item_p == NULL) {
        SX_LOG_ERR("Validation Error region list item is NULL!\n");
        return SX_UTILS_STATUS_ERROR;
    }

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (hole_side == TOP_HOLE_E) {
        /* Top Hole */
        itor = region_p->list_item_p;
        if (itor == cl_list_head(&psort_db_table_db->table)) {
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_prev));
        if (neighb_region->type != PSORT_REGION_TYPE_HOLE_E) {
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        /* Make sure there is a hole below. If not, create it */
        itor = cl_list_next(region_p->list_item_p);
        if (itor == cl_list_end(&psort_db_table_db->table)) {
            should_create_new_hole = TRUE;
        } else {
            region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
                should_create_new_hole = FALSE;
                pool_element = region_hole;
            } else {
                should_create_new_hole = TRUE;
            }
        }
        if (should_create_new_hole) {
            hole_index = region_p->end + 1;
        }
    } else {
        /* Bottom Hole */
        itor = region_p->list_item_p;
        if (itor == cl_list_tail(&psort_db_table_db->table)) {
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        neighb_region = (psort_db_region_hole_t*)(cl_list_obj(region_p->list_item_p->p_next));
        if (neighb_region->type != PSORT_REGION_TYPE_HOLE_E) {
            return SX_UTILS_STATUS_NO_RESOURCES;
        }

        /* Check if need get a new Hole from free pool or add a space to existing Hole*/
        if (region_p->list_item_p != cl_list_head(&psort_db_table_db->table)) {
            itor = cl_list_prev(region_p->list_item_p);
            region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
            if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
                pool_element = region_hole;
                should_create_new_hole = FALSE;
            } else {
                should_create_new_hole = TRUE;
            }
        } else {
            should_create_new_hole = TRUE;
        }
        if (should_create_new_hole) {
            hole_index = region_p->start;
        }
    }

    hole_size = neighb_region->size;
    if (hole_size == 0) {
        return SX_UTILS_STATUS_NO_RESOURCES;
    }
    if (hole_size < shift_block_size) {
        shift_size = hole_size;
    } else {
        shift_size = shift_block_size;
    }

    if (shift_size > region_p->size) {
        shift_size = region_p->size;
    }

    /* Enlarge region to take some empty space from the hole above */
    rc = __psort_db_region_hole_reassign_empty_space(region_p, neighb_region, shift_size);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to move empty space from hole to region\n");
        return rc;
    }
    psort_db_table_db->sum_of_holes -= shift_size;

    /* Move chunk of data into new space at beginning of region */
    if (hole_side == TOP_HOLE_E) {
        dest_index = region_p->start;
        source_index = region_p->end - shift_size + 1;
    } else {
        dest_index = region_p->end - shift_size + 1;
        source_index = region_p->start;
    }
    rc = __psort_db_region_shift_entries(psort_db_table_db, region_p, dest_index, source_index, shift_size);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to shift %u entries from %u to %u\n", shift_size, source_index, dest_index);
        return rc;
    }
    *shift_count_p = 1;

    if (should_create_new_hole) {
        pool_element = __psort_db_region_object_get(psort_db_table_db);
        if (NULL == pool_element) {
            SX_LOG_ERR("No resources in regions holes free pool\n");
            return SX_UTILS_STATUS_NO_RESOURCES;
        }
        pool_element->start = hole_index;
        pool_element->size = 0;
        pool_element->end = hole_index - 1;
        pool_element->type = PSORT_REGION_TYPE_HOLE_E;
        pool_element->priority = 0;
    }

    /* Reduce region to give empty space to the hole below */
    rc = __psort_db_region_hole_reassign_empty_space(pool_element, region_p, shift_size);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to move empty space from hole to region\n");
        return rc;
    }
    psort_db_table_db->sum_of_holes += shift_size;

    if (should_create_new_hole) {
        rc = __psort_db_add_hole_exact_location(psort_db_table_db,
                                                pool_element,
                                                region_p);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error adding new hole to psort table\n");
            return rc;
        }
    }

    if (neighb_region->size == 0) {
        /* We should delete the hole from the table */
        rc = __psort_db_remove_region_from_table(psort_db_table_db, neighb_region);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error removing region/hole from psort table handle [%p]\n", psort_db_table_db);
            return rc;
        }
    }

    return SX_UTILS_STATUS_SUCCESS;
}

#define POSRT_HOLE_MIN_SIZE_FACTOR 3

sx_utils_status_t psort_db_get_table_optimal_hole_size(const psort_handle_t handle,
                                                       uint32_t            *optimal_hole_size_div_part,
                                                       uint32_t           * optimal_hole_size_mod_part)
{
    psort_db_table_db_t *psort_db_table_db = NULL;
    uint32_t             min_holes_size = 0;
    uint32_t             desired_size = 0;
    int                  optimal_holes_num = 0;
    int                  div = 0;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    /* optimal_hole_size = free_space /(total regions - (2[number of the top(max prio.)  and bottom(min prio.) regions] + 1) */
    if (psort_db_table_db->regions_cnt <= 1) {
        *optimal_hole_size_div_part = 0;
        *optimal_hole_size_mod_part = 0;
        goto out;
    }

    optimal_holes_num = psort_db_table_db->regions_cnt - 2 + 1;
    desired_size = POSRT_HOLE_MIN_SIZE_FACTOR * psort_db_table_db->delta_size;

    min_holes_size = (desired_size) * psort_db_table_db->holes_cnt;

    if (psort_db_table_db->sum_of_holes >= min_holes_size) {
        *optimal_hole_size_div_part = desired_size;
        *optimal_hole_size_mod_part = 0;
    } else {
        /* holes should be at equal size */
        div = optimal_holes_num;

        if (div <= 0) {
            return SX_UTILS_STATUS_ERROR;
        }


        *optimal_hole_size_mod_part = (psort_db_table_db->sum_of_holes) % ((uint32_t)div);
        *optimal_hole_size_div_part = (psort_db_table_db->sum_of_holes) / ((uint32_t)div);
    }
out:
    return SX_UTILS_STATUS_SUCCESS;
}


static int __psort_db_qsort_compare_items(const void *p1, const void *p2)
{
    psort_entry_info_t* entry1 = (psort_entry_info_t*)p1;
    psort_entry_info_t* entry2 = (psort_entry_info_t*)p2;

    /* If entry1 has lower index, we return a negative number,
    * because it should appear *before* entry2 in the array */
    return entry1->entry.index - entry2->entry.index;
}

sx_utils_status_t psort_db_get_table(const psort_handle_t handle,
                                     psort_entry_info_t  *entries_p,
                                     uint32_t            *num_of_entries_p)
{
    psort_db_table_db_t *psort_db_table_db = NULL;
    uint32_t             num = 0;
    cl_list_iterator_t   itor;
    cl_list_iterator_t   list_end;
    const cl_map_item_t *empty_map_end = NULL;
    const cl_map_item_t *used_map_end = NULL;


    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    /* Iterate Table */
    itor = cl_list_head(&psort_db_table_db->table);
    list_end = cl_list_end(&psort_db_table_db->table);

    while (itor != list_end) {
        psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
        used_map_end = cl_qmap_end(&region_hole->used_space);
        empty_map_end = cl_qmap_end(&region_hole->empty_space);
        if (region_hole->type == PSORT_REGION_TYPE_PRIORITY_E) {
            /* iterate list of entries in the hole */
            cl_map_item_t      *empty_space_item = NULL;
            cl_map_item_t      *used_space_item = NULL;
            psort_entry_item_t *entry_p = NULL;

            /* Iterate used space list*/
            used_space_item = cl_qmap_head(&region_hole->used_space);
            while (used_space_item != used_map_end) {
                entry_p = PARENT_STRUCT(used_space_item, psort_entry_item_t, map_item);

                if (num < *num_of_entries_p) {
                    entries_p[num].valid = 1;
                    entries_p[num].entry = entry_p->entry;
                } else {
                    goto out;
                }

                num++;
                used_space_item = cl_qmap_next(used_space_item);
            }

            /* Iterate empty space list*/
            empty_space_item = cl_qmap_head(&region_hole->empty_space);
            while (empty_space_item != empty_map_end) {
                entry_p = PARENT_STRUCT(empty_space_item, psort_entry_item_t, map_item);

                if (num < *num_of_entries_p) {
                    entries_p[num].valid = 0;
                    entries_p[num].entry = entry_p->entry;
                } else {
                    goto out;
                }
                num++;

                empty_space_item = cl_qmap_next(empty_space_item);
            }
        }

        itor = cl_list_next(itor);
    }


    *num_of_entries_p = num;
out:
    if (num > 1) {
        qsort(entries_p, num, sizeof(entries_p[0]), __psort_db_qsort_compare_items);
    }

    return SX_UTILS_STATUS_SUCCESS;
}


sx_utils_status_t psort_db_get_table_total_regions_size(const psort_handle_t handle, uint32_t  *total_regions_size_p)
{
    psort_db_table_db_t *psort_db_table_db = NULL;
    uint32_t             num = 0;
    cl_list_iterator_t   itor;
    cl_list_iterator_t   list_end;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    /* Iterate Table */

    itor = cl_list_head(&psort_db_table_db->table);


    list_end = cl_list_end(&psort_db_table_db->table);

    while (itor != list_end) {
        psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
        if (region_hole->type == PSORT_REGION_TYPE_PRIORITY_E) {
            num += region_hole->size;
        }

        itor = cl_list_next(itor);
    }


    *total_regions_size_p = num;

    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t psort_db_insert_entry_to_region(const psort_handle_t    handle,
                                                  psort_db_region_hole_t* region_p,
                                                  psort_entry_t         * entry_p)
{
    cl_map_item_t       *map_item = NULL;
    psort_entry_item_t  *new_entry_p = NULL;
    psort_db_table_db_t *psort_db_table_db = NULL;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (region_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db->state = PSORT_TABLE_STATE_UNKNOWN_E;

    if (cl_qmap_count(&region_p->empty_space) == 0) {
        SX_LOG_ERR("Failed to insert entry. No empty space in region\n");
        return SX_UTILS_STATUS_ERROR;
    }

    if (region_p->priority != entry_p->priority) {
        SX_LOG_ERR("Failed to insert entry with different priority to region\n");
        return SX_UTILS_STATUS_ERROR;
    }

    /* Take either the first or last empty item */
    if (cl_qmap_count(&region_p->used_space) == 0) {
        map_item = cl_qmap_head(&region_p->empty_space);
    } else {
        psort_entry_item_t* used_entry = NULL;
        cl_map_item_t     * used_item;

        map_item = cl_qmap_head(&region_p->empty_space);
        new_entry_p = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);

        used_item = cl_qmap_head(&region_p->used_space);
        used_entry = PARENT_STRUCT(used_item, psort_entry_item_t, map_item);

        if (used_entry->entry.index > new_entry_p->entry.index) {
            map_item = cl_qmap_tail(&region_p->empty_space);
        }
    }

    cl_qmap_remove_item(&region_p->empty_space, map_item);
    new_entry_p = PARENT_STRUCT(map_item, psort_entry_item_t, map_item);

    new_entry_p->entry.key = entry_p->key;
    new_entry_p->entry.priority = entry_p->priority;

    /* push to used space list */
    cl_qmap_insert(&region_p->used_space, new_entry_p->entry.index, &new_entry_p->map_item);

    entry_p->index = new_entry_p->entry.index;

    psort_db_table_db->total_free_entries--;

    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t psort_db_remove_entry_from_region(const psort_handle_t    handle,
                                                    psort_db_region_hole_t* region_p,
                                                    psort_entry_t         * entry_p)
{
    psort_db_table_db_t *psort_db_table_db = NULL;
    sx_utils_status_t    rc;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (region_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db->state = PSORT_TABLE_STATE_UNKNOWN_E;

    psort_entry_item_t *used_entry_p = NULL;

    /* Iterate used space list*/
    rc = psort_db_region_hole_get_used_entry(region_p, entry_p->index, &used_entry_p);
    if (rc != SX_UTILS_STATUS_SUCCESS) {
        return rc;
    }

    /* Take space From Head of empty list*/
    cl_qmap_remove_item(&region_p->used_space, &used_entry_p->map_item);

    /* push to empty space list. */
    cl_qmap_insert(&region_p->empty_space, used_entry_p->entry.index, &used_entry_p->map_item);

    psort_db_table_db->total_free_entries++;

    return SX_UTILS_STATUS_SUCCESS;
}


/* Calculate a new region offset, in case didn't found sufficient space, NULL will be returned */
sx_utils_status_t psort_db_get_new_region_space(const psort_handle_t     handle,
                                                uint32_t               * new_hole_size,
                                                psort_db_region_hole_t **hole_p,
                                                psort_db_region_hole_t **closet_region_p,
                                                int                      priority)
{
    psort_db_table_db_t    *psort_db_table_db = NULL;
    uint32_t                foundLocation = 0;
    int                     currentPriority = 0;
    psort_db_region_hole_t *region_hole = NULL;
    cl_list_iterator_t      itor;
    cl_list_iterator_t      list_end;

    *hole_p = NULL;
    *closet_region_p = NULL;
    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    /* Iterate Table and lookup for a free space at size of 2 Hole size + delta_size */

    /*uint32_t requested_size = (2*new_hole_size) + psort_db_table_db->delta_size;*/

    itor = cl_list_head(&psort_db_table_db->table);


    list_end = cl_list_end(&psort_db_table_db->table);


    while (itor != list_end && foundLocation == 0) {
        region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));

        if (region_hole->type == PSORT_REGION_TYPE_PRIORITY_E) {
            currentPriority = region_hole->priority;
            if (priority > currentPriority) {
                *closet_region_p = region_hole;
                foundLocation = 1;
            }
        }

        if (!foundLocation) {
            itor = cl_list_next(itor);
        }
    }

    if (foundLocation == 0) {
        /* Check if last region is hole and return it*/
        itor = cl_list_tail(&psort_db_table_db->table);
        region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));
        if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
            *hole_p = region_hole;
            goto out;
        } else {
            *closet_region_p = region_hole;
        }
    }
    /* find the closet hole */
    if (foundLocation == 1) {
        boolean_t cont = TRUE;
        if (itor != cl_list_head(&psort_db_table_db->table)) {
            itor = cl_list_prev(itor);
        } else {
            cont = FALSE;
        }

        while (cont) {
            region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));

            if (region_hole->type == PSORT_REGION_TYPE_HOLE_E) {
                /* found space*/
                *hole_p = region_hole;
                if (region_hole->size >= psort_db_table_db->delta_size) {
                    *new_hole_size = (region_hole->size - psort_db_table_db->delta_size) / 2;
                } else {
                    *new_hole_size = 0;
                }
                goto out;
                /*}*/
            } else {
                currentPriority = region_hole->priority;
                if (priority < currentPriority) {
                    /* No Hole between priorities */
                    goto out;
                }
            }
            if (itor == cl_list_head(&psort_db_table_db->table)) {
                cont = FALSE;
            } else {
                itor = cl_list_prev(itor);
            }
        } /* end while */
    } /* end if found Location */

out:
    return SX_UTILS_STATUS_SUCCESS;
}


sx_utils_status_t psort_db_notify_almost_full_event(const psort_handle_t handle, uint32_t* shift_count_p)
{
    psort_db_table_db_t *psort_db_table_db = NULL;
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (psort_db_table_db->notif_callback != NULL) {
        rc = psort_db_table_db->notif_callback(PSORT_TABLE_ALMOST_FULL_E, shift_count_p, psort_db_table_db->cookie);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            /* Log the error */
            SX_LOG_ERR("Error notify almost full notification callback handle [%" PRIu64 "]\n", handle);
        }
    }

    return rc;
}

sx_utils_status_t psort_db_notify_almost_empty_event(const psort_handle_t handle, uint32_t* shift_count_p)
{
    psort_db_table_db_t *psort_db_table_db = NULL;
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (psort_db_table_db->notif_callback != NULL) {
        rc = psort_db_table_db->notif_callback(PSORT_TABLE_ALMOST_EMPTY_E, shift_count_p, psort_db_table_db->cookie);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            /* Log the error */
            SX_LOG_ERR("Error notify almost empty notification callback handle [%" PRIu64 "]\n", handle);
        }
    }

    return rc;
}

static sx_utils_status_t __psort_db_free_table(psort_db_table_db_t* psort_db_table_db)
{
    sx_utils_status_t       rc = SX_UTILS_STATUS_SUCCESS;
    cl_list_iterator_t      itor;
    psort_db_entries_db_t * psort_db_entries_db = NULL;
    cl_list_iterator_t      list_end;

    /* Iterate Table */

    list_end = cl_list_end(&psort_db_table_db->table);
    itor = cl_list_head(&psort_db_table_db->table);
    while (itor != list_end) {
        psort_db_region_hole_t *region_hole = (psort_db_region_hole_t*)(cl_list_obj(itor));

        SX_LOG_INF("Removing region type [%s] priority [%d] psort handle [%p]\n",
                   (region_hole->type == PSORT_REGION_TYPE_HOLE_E) ? "Hole" : "Priority",
                   region_hole->priority, psort_db_table_db);

        itor = cl_list_next(itor);

        rc = __psort_db_remove_region_from_table(psort_db_table_db, region_hole);
        if (rc != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Error removing region/hole from psort table handle [%p]\n", psort_db_table_db);
            return rc;
        }
    }

    psort_db_entries_db = &psort_db_table_db->psort_db_entries_db;
    CL_QPOOL_DESTROY(&psort_db_table_db->regions_holes_pool);

    cl_list_destroy(&psort_db_entries_db->free_pool);

    cl_list_remove_all(&psort_db_table_db->table);
    cl_list_destroy(&psort_db_table_db->table);

    /* free back memory */
    rc = gen_utils_memory_put(psort_db_table_db, GEN_UTILS_MEM_TYPE_ID_PSORT_E);
    SX_UTILS_CHECK_RC(rc, "Free pSort table memory");
    return rc;
}

sx_utils_status_t psort_db_clear_table(const psort_handle_t handle)
{
    psort_db_table_db_t *psort_db_table_db = NULL;
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;

    if (handle == 0) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    if (psort_db_table_db->refcount == 0) {
        rc = __psort_db_free_table(psort_db_table_db);
    } else {
        if (psort_db_table_db->destroy_table) {
            SX_LOG_ERR("Trying to delete psort table twice while referenced\n");
        }
        psort_db_table_db->destroy_table = TRUE;
    }

    return rc;
}

sx_utils_status_t psort_db_is_single_priority(const psort_handle_t handle, boolean_t* is_single_priority)
{
    psort_db_table_db_t *psort_db_table_db = NULL;

    if ((handle == 0) || (is_single_priority == NULL)) {
        SX_LOG_ERR("NULL params\n");
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;
    *is_single_priority = (psort_db_table_db->min_priority == psort_db_table_db->max_priority);
    return SX_UTILS_STATUS_SUCCESS;
}

void psort_db_take_ref(psort_handle_t handle)
{
    psort_db_table_db_t *psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    psort_db_table_db->refcount++;
}

sx_utils_status_t psort_db_release_ref(psort_handle_t handle, boolean_t allow_destroy)
{
    sx_utils_status_t    rc = SX_UTILS_STATUS_SUCCESS;
    psort_db_table_db_t *psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    CL_ASSERT(psort_db_table_db->refcount > 0);
    psort_db_table_db->refcount--;
    if ((psort_db_table_db->refcount == 0) && (psort_db_table_db->destroy_table)) {
        if (allow_destroy) {
            rc = __psort_db_free_table(psort_db_table_db);
        } else {
            SX_LOG_ERR("Psort table deleted while referenced, in a flow where it is not allowed\n");
        }
    }
    return rc;
}

boolean_t psort_db_is_deleted(psort_handle_t handle)
{
    psort_db_table_db_t *psort_db_table_db = (psort_db_table_db_t*)(uintptr_t)handle;

    CL_ASSERT(psort_db_table_db->refcount > 0);
    return psort_db_table_db->destroy_table;
}
