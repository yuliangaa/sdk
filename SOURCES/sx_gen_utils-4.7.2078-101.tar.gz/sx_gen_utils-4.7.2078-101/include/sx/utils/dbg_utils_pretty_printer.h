/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __DBG_UTILS_PRETTY_PRINTER_H__
#define __DBG_UTILS_PRETTY_PRINTER_H__

#include <stdio.h>
#include <stdint.h>

#include "complib/sx_log.h"

#include "sx/utils/sx_utils_status.h"

#include "sx/utils/dbg_utils_types.h"
#include "sx/utils/dbg_utils_cheat_sheet.h"

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct dbg_utils_pprinter_params {
    FILE           *txt_fp;
    FILE           *json_fp;
    boolean_t       json_compressed;
    cheat_sheet_ptr cheat_sheet_p;
} dbg_utils_pprinter_params_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
/**
 * dbg_utils_pprinter_init
 *
 * This function initialize the module by setting up the DB and
 * other internals.
 */
sx_utils_status_t dbg_utils_pprinter_init(void);

/**
 * dbg_utils_pprinter_deinit
 *
 * This function deinitialize the module.
 */
sx_utils_status_t dbg_utils_pprinter_deinit(void);

/**
 * dbg_utils_pprinter_log_verbosity_level_set
 *
 * This function sets the log verbosity level for the module.
 */
sx_utils_status_t dbg_utils_pprinter_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

/**
 * dbg_utils_pprinter_add
 *
 * If there is a space in the printers DB and the given key is unique,
 * this function will allocate a new printer and associated it with the key.
 *
 * Later the key can be given to printer functions to write data to the files
 * associated with a printer that is associated with the key.
 *
 * If a text file pointer is not NULL, the printer functions will convert data
 * to a human-readable string and write to a text file.
 *
 * If a JSON file pointer is not NULL, the printer functions will convert data
 * to a JSON object and write to a JSON file.
 */
sx_utils_status_t dbg_utils_pprinter_add(FILE                              *key,
                                         const dbg_utils_pprinter_params_t *params_p);

/**
 * dbg_utils_pprinter_remove
 *
 * If the key is found in the printers DB,
 * this function will free the associated printer.
 */
sx_utils_status_t dbg_utils_pprinter_remove(FILE* key);

cheat_sheet_ptr dbg_utils_pprinter_cheat_sheet_ptr_get(FILE *key);

void dbg_utils_pprinter_txt_fp_get(FILE* key, FILE **txt_fpp);

/**
 * dbg_utils_pprinter_print
 *
 * If the key points to a printer that was enabled to produce a text file,
 * this function will print a string to the file associated with the printer.
 */
void dbg_utils_pprinter_print(FILE* key, const char *fmt, ...)  __attribute__ ((format(printf, 2, 3)));

void dbg_utils_pprinter_txt_string_print(FILE* key, const char *buffer);

/**
 * dbg_utils_pprinter_field_print
 *
 * If the key points to a printer,
 * this function will print a field to the files associated with the printer.
 *
 * prints field name and value in a fixed alignment.
 *
 * In case of the JSON file, the field has the DBG_UTILS_LEVEL_DATA_E nesting level.
 */
void dbg_utils_pprinter_field_print(FILE                  *key,
                                    const char            *name,
                                    const void            *data,
                                    dbg_utils_param_type_e type);

/**
 * dbg_utils_pprinter_field_with_level_print
 *
 * If the key points to a printer,
 * this function will print a field to the files associated with the printer.
 *
 * In case of the JSON file, the field has the 'level' nesting level.
 */
void dbg_utils_pprinter_field_with_level_print(FILE                  *key,
                                               const char            *name,
                                               const void            *data,
                                               dbg_utils_param_type_e type,
                                               dbg_utils_level_e      level);

/**
 * dbg_utils_pprinter_module_header_print
 *
 * prints module header
 * Use for SDK module: Router, Tunnel, Bridge etc.
 * Will be add to cheat sheet as main module.
 */
void dbg_utils_pprinter_module_header_print(FILE       *key,
                                            const char *module_name);

/**
 * dbg_utils_pprinter_table_headline_with_name_print
 *
 * prints table headline
 * tables with row width greater than DBG_UTILS_SCRN_WIDTH_MAX
 * will be printed as a series of fields with separator line.
 */
void dbg_utils_pprinter_table_headline_with_name_print(FILE                      *key,
                                                       dbg_utils_table_columns_t *columns,
                                                       char                     * name);

/**
 * dbg_utils_pprinter_table_headline_print
 */
#define dbg_utils_pprinter_table_headline_print(stream, columns) \
    dbg_utils_pprinter_table_headline_with_name_print(stream, columns, #columns)

/**
 * dbg_utils_pprinter_table_data_line_nosep_print
 *
 * Print table data line without line separator.
 * Returns total line width
 */
int dbg_utils_pprinter_table_data_line_nosep_print(FILE                      *key,
                                                   dbg_utils_table_columns_t *columns);

/**
 * dbg_utils_pprinter_table_data_line_print
 *
 * prints table data line with line separator
 * tables with row width greater than DBG_UTILS_SCRN_WIDTH_MAX
 * will be printed as a series of fields with separator line.
 * Returns: total line width
 */
int dbg_utils_pprinter_table_data_line_print(FILE                      *key,
                                             dbg_utils_table_columns_t *columns);

/**
 * dbg_utils_pprinter_separator_line_print
 *
 * Print separator line in table with custom character
 */
void dbg_utils_pprinter_separator_line_print(FILE *key,
                                             int   total_width,
                                             char  separator_char);


/**
 * dbg_utils_pprinter_counters_group_header_print
 *
 * prints counters group header with port ID info
 */
void dbg_utils_pprinter_counters_group_header_print(FILE       *key,
                                                    const char *cntr_grp_name,
                                                    uint32_t    port_id);

/**
 * dbg_utils_pprinter_counters_group_sub_header_print
 *
 * prints counters group sub-header
 */
void dbg_utils_pprinter_counters_group_sub_header_print(FILE       *key,
                                                        const char *headline_fmt,
                                                        ...) __attribute__ ((format(printf, 2, 3)));

/**
 * dbg_utils_pprinter_counter_print
 *
 * prints counter name and value
 * calls print field function
 */
void dbg_utils_pprinter_counter_print(FILE       *key,
                                      const char *cntr_name,
                                      uint64_t    cntr_value);

/**
 * dbg_utils_pprinter_counter_with_level_print
 */
void dbg_utils_pprinter_counter_with_level_print(FILE             *key,
                                                 const char       *cntr_name,
                                                 uint64_t          cntr_value,
                                                 dbg_utils_level_e level);

/**
 * dbg_utils_pprinter_general_header_print
 *
 * prints general purpose header.
 * Will be add to cheat sheet as general header.
 */
void dbg_utils_pprinter_general_header_print(FILE       *key,
                                             const char *general_header);

/**
 * dbg_utils_pprinter_sub_module_header_print
 *
 * prints sub module header.
 * Will be add to cheat sheet as sub-module.
 */
void dbg_utils_pprinter_sub_module_header_print(FILE       *key,
                                                const char *sub_module_header);

/**
 * dbg_utils_pprinter_plain_text_secondary_header_print
 *
 * prints secondary header only to plain text mode, compatible
 * to those legacy non-json dump print case.
 */
void dbg_utils_pprinter_plain_text_secondary_header_print(FILE *key, const char *headline_fmt,
                                                          ...)  __attribute__ ((format(printf, 2, 3)));

/**
 * dbg_utils_pprinter_user_defined_header_print
 *
 * prints user defined head with levels between DBG_UTILS_LEVEL_GENERAL_E
 * and DBG_UTILS_LEVEL_SECONDARY_E.
 */
void dbg_utils_pprinter_user_defined_header_print(FILE *key,
                                                  dbg_utils_level_e user_defined_level,
                                                  const char *headline_fmt, ...)  __attribute__ ((format(printf, 3,
                                                                                                         4)));

/**
 * dbg_utils_pprinter_secondary_header_print
 *
 * prints secondary header
 * provides headers hierarchy.
 * Secondary header will not be include in cheat sheet.
 *
 * In case of JSON, the nesting level is DBG_UTILS_LEVEL_SECONDARY_E.
 */
void dbg_utils_pprinter_secondary_header_print(FILE *key, const char *headline_fmt,
                                               ...)  __attribute__ ((format(printf, 2, 3)));

/**
 * dbg_utils_pprinter_time_stamp_print
 *
 * prints current time stamp
 *
 * In case of JSON, the nesting level is DBG_UTILS_LEVEL_MODULE_E.
 */
void dbg_utils_pprinter_time_stamp_print(FILE *key, const char * name);

/**
 * dbg_utils_pprinter_binary_tree_draw
 *
 * In case of JSON, the nesting level is DBG_UTILS_LEVEL_HEADER_E.
 */
void dbg_utils_pprinter_binary_tree_draw(FILE *key, const dbg_utils_tree_t* tree);

/**
 * dbg_utils_pprinter_data_unavailable_print
 *
 * Prints error message "Data is currently unavailable".
 *
 * If the key points to a printer that was enabled to produce a text file,
 * this function will print ""\nData is currently unavailable\n"" to the file
 * associated with the printer.
 */
void dbg_utils_pprinter_data_unavailable_print(FILE *key);

/**
 * dbg_utils_pprinter_json_header_object_create
 */
void dbg_utils_pprinter_json_header_object_create(FILE             *key,
                                                  dbg_utils_level_e current_level,
                                                  const char      * object_name,
                                                  boolean_t         is_table);

/**
 * dbg_utils_pprinter_json_string_object_create
 */
void dbg_utils_pprinter_json_string_object_create(FILE *key, dbg_utils_level_e current_level, char *value);

/**
 * dbg_utils_pprinter_json_table_item_create
 */
void dbg_utils_pprinter_json_table_item_create(FILE *key, dbg_utils_level_e current_level);

/**
 * dbg_utils_pprinter_json_table_name_set
 *
 * Set json dump name of the table before printing table headline.
 * It could be called before dbg_utils_pprinter_table_headline_print(..),
 * but not mandatory. If being called, it could provide clearer
 * structure for json dump.
 *
 */
void dbg_utils_pprinter_json_table_name_set(FILE *key, char *table_name);


#endif /* __DBG_UTILS_PRETTY_PRINTER_H__ */
