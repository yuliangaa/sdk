/*
 * Copyright (C) 2001-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef SX_GEN_UTILS_INCLUDE_SX_UTILS_ID_ALLOCATOR_H_
#define SX_GEN_UTILS_INCLUDE_SX_UTILS_ID_ALLOCATOR_H_


#include <complib/cl_types.h>
#include <sx/utils/sx_utils_status.h>
#include "sx/utils/bit_vector.h"

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct id_allocator {
    uint32_t     max_size;      /**< Maximum index size */
    uint32_t     grow_size;      /**< next block of indexes size */
    uint32_t     last_min_free_index;
    uint32_t     start_id;
    bit_vector_t index_vector;      /**< The vector of words and bits to store the indexes. bit = 0 index is free, bit = 1 index is in use */
    boolean_t    is_initialize;
    uint32_t     step;
} id_allocator_t;
typedef struct id_allocator_params {
    uint32_t max_size;          /**< Maximum index size */
    uint32_t grow_size;         /**< The initial number of indexes, and grow size */
    uint32_t start_id;          /**< The smallest id the allocator returns back */
    uint32_t step;              /**< The step of index increased */
} id_allocator_params_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
/**
 * Set the log verbosity level for this module
 * @param[in] level - A log level to set
 */
void id_counter_log_verbosity_level_set(sx_verbosity_level_t level);

/**
 * Allocates and initializes a new id allocator of the specified max and grow sizes.
 * When this function returns, all the indexes in the allocator are free.
 * @param[in] max_size - Maximum indexes the allocator can manage
 * @param[in] grow_size - the initial number of indexes. If grow_size < max_id,
 *            the id_allocator can resize the indexes list up to max_id.
 *            The resize steps will be at the size of grow_size.
 * @param[in] start_id - The smallest id the allocator returns back.
 * @param[out] id_allocator - Returns a newly allocated id_allocator.
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t id_allocator_init(uint32_t        max_size,
                                    uint32_t        grow_size,
                                    uint32_t        start_id,
                                    id_allocator_t* id_allocator);
/**
 * Allocates and initializes a new id allocator of the specified parameters.
 * When this function returns, all the indexes in the allocator are free.
 * @param[in] params - parameters
 * @param[out] id_allocator - Returns a newly allocated id_allocator.
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t id_allocator_init_ext(id_allocator_params_t params, id_allocator_t* id_allocator);

/**
 * Gets a single id in an id allocator.
 * @param[in] id_allocator - An id allocator to manipulate
 * @param[out] id_p - Pointer to the next available index to use
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t id_allocator_get(id_allocator_t* id_allocator, uint32_t *id_p);

/**
 * Return a single id in an id allocator.
 * @param[in] id_allocator - An id allocator to manipulate
 * @param[in] id - The index to free. Must be between 0 and the current id allocator size
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t id_allocator_put(id_allocator_t* id_allocator, uint32_t id);

/**
 * Sets single id in an id allocator. This is useful when the allocator's user want to specify
 * what ids are already set.
 * @param[in] id_allocator - An id allocator to manipulate
 * @param[in] id - The index to set. Must be between 0 and the current id allocator size
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t id_allocator_set(id_allocator_t* id_allocator, uint32_t id);

/**
 * Check if given allocated ID is valid.
 * @param[in] id_allocator - An ID allocator to manipulate
 * @param[in] id - The index to validate.
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t id_allocator_validate_allocated_id(id_allocator_t* id_allocator, uint32_t id);

/**
 * Frees a previously allocated id allocator
 * @param[in] id_allocator - A previously allocated id_allocator to free
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t id_allocator_destroy(id_allocator_t* id_allocator);


/**
 * Determines the amount of used indexes in the id allocator
 * @param[in] id_allocator - An id_allocator to count
 * @return The number of indexes that are in use in the id allocator
 */
uint32_t id_allocator_in_use_count(const id_allocator_t* id_allocator);

/**
 * Determines the size, in free + in use id in the id allocator
 * @param[in] id_allocator - An id allocator to inquire
 * @return The total number of indexes in the id_allocator
 */
uint32_t id_allocator_size(const id_allocator_t* id_allocator);

/**
 * Check if id_allocator is initialized
 * @param[in] id_allocator - An id allocator to inquire
 * @return SX_UTILS_STATUS_SUCCESS if initialized, SX_UTILS_STATUS_NOT_INITIALIZED if not.
 */
sx_utils_status_t is_id_allocator_initialize(const id_allocator_t* id_allocator);

#endif /* SX_GEN_UTILS_INCLUDE_SX_UTILS_ID_ALLOCATOR_H_ */
