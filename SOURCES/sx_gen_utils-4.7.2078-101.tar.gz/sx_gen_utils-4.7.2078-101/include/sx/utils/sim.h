/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/utils/psort.h>
#include <stdio.h>


#ifdef SIM_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#endif


/************************************************
 *  Defines
 ***********************************************/

#define LOG_FILE_PATH    "/tmp/psort_sim.log"
#define COMMAND_LOG_PATH "/tmp/psort_commands.log"

#define SIM_TABLE_SIZE    15
#define SIM_DELTA_DEFAULT 5

#define SIM_MAX_VAL 0xFFFFFFFF

#define PRINT                         "print"
#define SIM_STR_FIXED_SEED            "seed"
#define SIM_STR_NUM_OF_SEEDS          "num_of_seeds"
#define SIM_STR_NUM_OF_PRIOS          "num_of_prios"
#define SIM_STR_INSERTION_DELAY       "insertion_delay"
#define SIM_STR_INIT                  "init"
#define SIM_STR_TIMER_THREAD          "timer_thread"
#define SIM_STR_WAIT_FOR_STEADY_STATE "wait_for_steady_state"

#define SIM_STR_DELTA       "delta"
#define SIM_STR_INCREMENTAL "incremental"

#define SIM_STR_RAND_OPERATION      "rand_operation"
#define SIM_STR_ADD                 "add"
#define SIM_STR_FIXED               "fixed"
#define SIM_STR_RAND                "rand"
#define SIM_STR_RAND_VAL_FIXED_PRIO "rand_val_fixed_prio"
#define SIM_STR_RAND_BLOCK          "rand_block"

#define SIM_STR_REM "rem"

#define SIM_STR_REORDER    "reorder"
#define SIM_STR_N_CYCLES   "n_cycles"
#define SIM_STR_FULL       "full"
#define SIM_STR_WITH_CHECK "full_with_check"

#define SIM_STR_CHECK "check"

#define SIM_STR_RESIZE_TABLE "resize_table"

/* psort set params */
#define SIM_STR_PSORT_PARAMS_SET "psort_params_set"


/************************************************
 *  Macros
 ***********************************************/

#define SX_UTILS_CHECK_FAIL(STATUS) (SX_UTILS_STATUS_SUCCESS != (STATUS))

#define SIM_PRINT(fmt, arg ...) \
    printf(fmt, ## arg);        \
    fprintf(logfile, fmt, ## arg);

#define SIM_LOG_ERR(fmt, arg ...)             \
    SIM_PRINT("%s:%d: ", __FILE__, __LINE__); \
    SX_LOG_ERR(fmt, ## arg);

#define IS_STR_BEGINS_WITH(str, word) (0 == strncmp(str, word, strlen(word)))
#define IS_STR_EQUAL(str1, str2)      ((strlen(str1) == strlen(str2)) && (0 == memcmp(str1, str2, strlen(str1))))

#define MIN(X, Y) ((X) < (Y) ? (X) : (Y))
#define MAX(X, Y) ((X) > (Y) ? (X) : (Y))

#define SIM_RAND(min, max) rand() % (max - min + 1) + min

#define SIM_RESIZE_BUF(buf, new_len, type)  \
    SIM_MEMORY_PUT(buf);                    \
    SIM_CLR_MEMORY_GET(buf, new_len, type); \

#define SIM_ENLARGE_BUF_KEEP_DATA(buf, old_len, new_len, type) \
    if (new_len > old_len) {                                   \
        type *tmp_buf = NULL;                                  \
        SIM_CLR_MEMORY_GET(tmp_buf, new_len, type);            \
        memcpy(tmp_buf, buf, old_len * sizeof(type));          \
        SIM_MEMORY_PUT(buf);                                   \
        buf = tmp_buf;                                         \
    }

#define SIM_MEMORY_PUT(buf)                                       \
    if (buf != NULL) {                                            \
        gen_utils_memory_put(buf, GEN_UTILS_MEM_TYPE_ID_PSORT_E); \
        buf = NULL;                                               \
    }

#define SIM_CLR_MEMORY_GET(buf, length, type)                                                                 \
    if (buf == NULL) {                                                                                        \
        status = gen_utils_clr_memory_get((void**)&buf, length, sizeof(type), GEN_UTILS_MEM_TYPE_ID_PSORT_E); \
        if (SX_UTILS_CHECK_FAIL(status)) {                                                                    \
            status = SX_UTILS_STATUS_NO_MEMORY;                                                               \
            SX_LOG_ERR("memory allocation failed\n");                                                         \
            goto out;                                                                                         \
        }                                                                                                     \
    }

#define SIM_GET_RAND_PRIO_FROM_PRIO_ARR prios_arr[SIM_RAND(0, sim_init_params.num_of_prios - 1)];

/************************************************
 *  Type definitions
 ***********************************************/

typedef uint8_t bool;

typedef struct {
    bool     valid;
    uint64_t key;
    int      priority;
} sim_entry_t;

typedef struct bg_full_reorder_stats {
    uint32_t       num_shifts;
    uint32_t       max_shift_count;
    uint32_t       min_shift_count;
    uint32_t       total_shifts_count;
    struct timeval max_shift_time;
    struct timeval min_shift_time;
    struct timeval total_shift_time;
    bool           valid;
} bg_full_reorder_stats_t;

typedef struct statistics {
    struct timeval total_add_time;
    struct timeval total_bg_time;
    struct timeval min_add_time;
    struct timeval min_bg_time;
    struct timeval max_add_time;
    struct timeval max_bg_time;
    struct timeval min_fg_plus_bg_time;
    struct timeval max_fg_plus_bg_time;
    uint32_t       total_shifts;
    uint32_t       min_total_shift;
    uint32_t       max_total_shift;
    uint32_t       min_foreground_shift;
    uint32_t       max_foreground_shift;
    uint32_t       min_background_shift;
    uint32_t       max_background_shift;
    uint32_t       total_background_shifts;
    uint32_t       total_add_shifts;
} statistics_t;

typedef struct {
    uint32_t       total_shifts;
    uint32_t       foreground_shifts;
    uint32_t       background_shifts;
    struct timeval total_add_time;
    struct timeval total_bg_time;
} sim_run_seed_info;

typedef struct sim_init_params {
    uint32_t          table_size;
    uint32_t          num_of_prios;
    psort_set_param_t psort_set_param;
} sim_init_params_t;

typedef enum {
    PSORT_SIM_RUN_MODE_CONFORMANCE_E = 0,
    PSORT_SIM_RUN_MODE_PERFORMANCE_E = 1
} sx_run_mode_e;

/************************************************
 *  Global variables
 ***********************************************/

FILE *logfile;

/************************************************
 *  Function declarations
 ***********************************************/
