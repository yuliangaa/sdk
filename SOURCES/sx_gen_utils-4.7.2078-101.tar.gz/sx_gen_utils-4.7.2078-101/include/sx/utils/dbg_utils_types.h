/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __DBG_UTILS_TYPES_H__
#define __DBG_UTILS_TYPES_H__

#include <stdint.h>

#include "complib/cl_types.h"

/************************************************
 *  Defines
 ***********************************************/
#define DBG_UTILS_JSON_BUF_SIZE          1024
#define DBG_UTILS_SCRN_WIDTH_MAX         200
#define DBG_UTILS_NODES_MAX              129
#define DBG_UTILS_DEFAULT_SEPARATOR_CHAR '-'
#define DBG_UTILS_COLUMN_NUM_MAX         54

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef enum dbg_utils_param_type {
    PARAM_UINT8_E,
    PARAM_UINT16_E,
    PARAM_UINT32_E,
    PARAM_UINT64_E,
    PARAM_HEX_E,
    PARAM_STRING_E,
    PARAM_EXT_STRING_E,
    PARAM_BOOL_E,
    PARAM_MAC_ADDR_E,
    PARAM_IPV4_E,
    PARAM_IPV4_MASK_E,
    PARAM_IPV6_E,
    PARAM_FC_ADDR_E,
    PARAM_DOUBLE_E,
    PARAM_INT_E,
    PARAM_HEX16_E,
    PARAM_HEX_STRING_E,
    PARAM_PORT_ID_E,
    PARAM_HEX64_E,
    PARAM_LAST_E
} dbg_utils_param_type_e;

typedef enum dbg_utils_level {
    DBG_UTILS_LEVEL_ROOT_E,
    DBG_UTILS_LEVEL_MODULE_E,
    DBG_UTILS_LEVEL_SUB_MODULE_E,
    DBG_UTILS_LEVEL_GENERAL_E,
    DBG_UTILS_LEVEL_USER_DEFINED_1_E,
    DBG_UTILS_LEVEL_USER_DEFINED_2_E,
    DBG_UTILS_LEVEL_USER_DEFINED_3_E,
    DBG_UTILS_LEVEL_USER_DEFINED_4_E,
    DBG_UTILS_LEVEL_SECONDARY_E,
    DBG_UTILS_LEVEL_HEADER_E,
    DBG_UTILS_LEVEL_SUB_HEADER_E,
    DBG_UTILS_LEVEL_DATA_E,
    DBG_UTILS_LEVEL_USER_DEFINED_MIN_E = DBG_UTILS_LEVEL_USER_DEFINED_1_E,
    DBG_UTILS_LEVEL_USER_DEFINED_MAX_E = DBG_UTILS_LEVEL_USER_DEFINED_4_E,
    DBG_UTILS_LEVEL_MIN_E              = DBG_UTILS_LEVEL_ROOT_E,
    DBG_UTILS_LEVEL_MAX_E              = DBG_UTILS_LEVEL_DATA_E,
} dbg_utils_level_e;

typedef struct dbg_utils_table_columns {
    char                 * name;
    int                    width;
    dbg_utils_param_type_e type;
    const void            *data;
} dbg_utils_table_columns_t;

/* Following struct is used as "data" in dbg_utils_table_columns_t for
 * specific types, which require explicit data length.
 */
typedef struct dbg_utils_table_tlv_field {
    unsigned int data_len;              /* Length */
    const void  *data;                  /* Value */
} dbg_utils_table_tlv_field_t;

typedef struct dbg_utils_tree_node {
    uint32_t  left_child;
    uint32_t  right_child;
    boolean_t is_predefined;
} dbg_utils_tree_node_t;

typedef struct dbg_utils_tree {
    uint32_t              root;
    uint32_t              node_count;
    dbg_utils_tree_node_t nodes[DBG_UTILS_NODES_MAX];
} dbg_utils_tree_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __DBG_UTILS_TYPES_H__ */
