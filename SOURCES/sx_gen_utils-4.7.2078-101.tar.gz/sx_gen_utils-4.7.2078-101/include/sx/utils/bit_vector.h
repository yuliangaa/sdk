/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __UTILS_BIT_VECTOR_H__
#define __UTILS_BIT_VECTOR_H__

/**
 * This library implements the bit-vector data type and all operations defined on it
 */

#include <complib/cl_types.h>
#include <sx/utils/sx_utils_status.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define BIT_PER_BYTE 8

/************************************************
 *  Macros
 ***********************************************/
#define MIN(x, y) ((x) < (y) ? (x) : (y))

/************************************************
 *  Type definitions
 ***********************************************/

/** A bit vector type */
typedef struct bit_vector_data* bit_vector_t;

#define BIT_VECTOR_INVALID ((bit_vector_t)NULL)

/**
 * Callback function for use with bit_vector_foreach_set
 * @param[in] bit_num - The current bit which is set in the vector
 * @param[in] context - The callback context
 * @return SX_UTILS_STATUS_SUCCESS to continue
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE to gracefully abort the iteration
 * @return any other error value to abnormally abort the iteration
 */
typedef sx_utils_status_t (*bit_vector_callback_t)(uint32_t bit_num, void* context);

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Set the log verbosity level for this module
 * @param[in] level - A log level to set
 */
void bit_vector_log_verbosity_level_set(sx_verbosity_level_t level);

/**
 * Allocates and initializes a new bit vector of the specified size.
 * When this function returns, all bits of the vector are clear.
 * @param[in] size_bits - Requested size of the vector, in bits
 * @param[out] vector - Returns a newly allocated bit vector
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_allocate(uint32_t size_bits, bit_vector_t* vector);

/**
 * Frees a previously allocated bit vector
 * @param[in] vector - A previously allocated bit vector to free
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_free(bit_vector_t vector);

/**
 * Resizes a bit-vector to a new size
 * If enlarging the vector, new bits are cleared
 * If reducing the vector, truncated bit values are lost
 * @param[in,out] vector - A previously allocated bit vector to resize
 * @param[in] new_size - A new size, in bits, for the vector
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_resize(bit_vector_t* vector, uint32_t new_size_bits);

/**
 * Sets a single bit in a bit vector
 * @param[in] vector - A vector to manipulate
 * @param[in] bit_num - The number of the bit to set. Must be between 0 and the bit vector's size-1
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_set(bit_vector_t vector, uint32_t bit_num);

/**
 * Clears a single bit in a bit vector
 * @param[in] vector - A vector to manipulate
 * @param[in] bit_num - The number of the bit to clear. Must be between 0 and the bit vector's size-1
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_clear(bit_vector_t vector, uint32_t bit_num);

/**
 * Retrieves the state of a single bit in the vector
 * @param[in] vector - A vector to read from
 * @param[in] bit_num - The number of the bit to read. Must be between 0 and the bit vector's size-1
 * @param[out] value - Returns the value of the bit
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_get(const bit_vector_t vector, uint32_t bit_num, boolean_t* value);

/**
 * Determines the amount of set bits in the vector
 * @param[in] vector - A vector to count
 * @return The number of bits set in the vector
 */
uint32_t bit_vector_count(const bit_vector_t vector);

/**
 * Determines the size, in bits, of the vector
 * @param[in] vector - A vector to inquire
 * @return The total number of bits in the vector
 */
uint32_t bit_vector_size(const bit_vector_t vector);

/**
 * Finds the first set bit in the vector
 * @param[in] vector - A vector to search
 * @param[out] bit_num - Returns the first bit set found
 * @return SX_UTILS_STATUS_SUCCESS if successful
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND if all bits are cleared in the vector
 * @return any other error value otherwise
 */
sx_utils_status_t bit_vector_find_first_set(const bit_vector_t vector, uint32_t* bit_num);


/**
 * Finds the first clear bit in the vector
 * @param[in] vector - A vector to search
 * @param[in] search_from_index- search start index
 * @param[out] bit_num - Returns the first bit clear found
 * @return SX_UTILS_STATUS_SUCCESS if successful
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND if all bits are set in the vector
 * @return any other error value otherwise
 */
sx_utils_status_t bit_vector_find_first_unset_bit(const bit_vector_t vector, uint32_t search_from_index,
                                                  uint32_t* bit_num);

/**
 * Finds the next set bit in the vector
 * @param[in] vector - A vector to manipulate
 * @param[in,out] bit_num - The number of bit to search after.
 *                          Must be between 0 and the bit vector's size-1.
 *                          Returns the next set bit
 * @return SX_UTILS_STATUS_SUCCESS if successful
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND if all bits are cleared in the vector after bit_num
 * @return any other error value otherwise
 */
sx_utils_status_t bit_vector_find_next_set(const bit_vector_t vector, uint32_t* bit_num);

/**
 * Iterates the set bits in the vector, and calls a callback function for each one
 * @param[in] vector - A vector to iterate
 * @param[in] cb - A callback function to call for each set bit
 * @param[in] context - A context value to pass to the callback function unchanged
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_foreach_set(const bit_vector_t vector, bit_vector_callback_t cb, void* context);

/**
 * Performs logical AND operation between individual bits of two vectors.
 * The two vectors must have the same size
 * Stores the result in the first vector. In effect this does: dst = dst AND src
 * @param[in,out] dst - First vector for the operation, which also returns the result
 * @param[in] src - Second vector for the operation
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_and(bit_vector_t dst, const bit_vector_t src);

/**
 * Performs logical OR operation between individual bits of two vectors.
 * The two vectors must have the same size
 * Stores the result in the first vector. In effect this does: dst = dst OR src
 * @param[in,out] dst - First vector for the operation, which also returns the result
 * @param[in] src - Second vector for the operation
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_or(bit_vector_t dst, const bit_vector_t src);

/**
 * Performs logical XOR operation between individual bits of two vectors.
 * The two vectors must have the same size
 * Stores the result in the first vector. In effect this does: dst = dst XOR src
 * @param[in,out] dst - First vector for the operation, which also returns the result
 * @param[in] src - Second vector for the operation
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_xor(bit_vector_t dst, const bit_vector_t src);

/**
 * Performs logical NOT operation on the bits of a vector.
 * In effect this does: dst = NOT dst
 * @param[in,out] dst - Vector for the operation, which also returns the result
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_not(bit_vector_t dst);

/**
 * Assigns bit values from one vector to another vector
 * The two vectors must have the same size
 * @param[in,out] dst - Vector to assign values to
 * @param[in] src - Vector to assign values from
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_assign(bit_vector_t dst, const bit_vector_t src);

/**
 * Assigns bit values from array to vector
 * @param[in,out] dst - Vector to assign values to
 * @param[in] src - Array to assign values from
 * @param[in] num_entries - Number of entries to assign
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
sx_utils_status_t bit_vector_assign_array(bit_vector_t *dst, const uint32_t *src, uint32_t array_size);

/**
 * Dumps the size and contents of a bit vector to a debug dump stream, in a standard way
 * @param[in] vector - Vector to dump
 * @param[in] stream - debug-dump stream to dump into
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
void bit_vector_debug_dump(const bit_vector_t vector, FILE* stream);

#endif /* __UTILS_BIT_VECTOR_H__ */
