/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __DBG_UTILS_STRING_H__
#define __DBG_UTILS_STRING_H__

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
/**
 * dbg_utils_string_hex_get
 */
char* dbg_utils_string_hex_get(char                *buf,
                               int                  buf_len,
                               const unsigned char *data,
                               int                  data_len);

/**
 * dbg_utils_string_return_remove
 */
void dbg_utils_string_return_remove(char * value);

/**
 * dbg_utils_string_leading_sp_remove
 */
void dbg_utils_string_leading_sp_remove(char * value);

/**
 * dbg_utils_string_capitalize
 *
 * Capitalizes strings for headers and titles
 * ("this is an example" -> "This Is An Example")
 */
void dbg_utils_string_capitalize(const char *string,
                                 char       *capitalized_string);

#endif /* __DBG_UTILS_STRING_ */
