/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __DBG_UTILS_TXT_PRINTER_H__
#define __DBG_UTILS_TXT_PRINTER_H__

#include <stdio.h>

#include "complib/sx_log.h"

#include "sx/utils/sx_utils_status.h"

#include "sx/utils/dbg_utils_types.h"

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct txt_printer* txt_printer_ptr;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_utils_status_t dbg_utils_txt_printer_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

/**
 * dbg_utils_txt_printer_create
 */
txt_printer_ptr dbg_utils_txt_printer_create(FILE *txt_fp);

/**
 * dbg_utils_txt_printer_destroy
 */
void dbg_utils_txt_printer_destroy(txt_printer_ptr txt_printer_p);

void dbg_utils_txt_printer_fp_get(txt_printer_ptr txt_printer_p, FILE **txt_fpp);

/**
 * dbg_utils_txt_printer_print
 */
void dbg_utils_txt_printer_print(txt_printer_ptr txt_printer_p, const char *fmt, ...);

/**
 * dbg_utils_txt_printer_string_print
 */
void dbg_utils_txt_printer_string_print(txt_printer_ptr txt_printer_p, const char *str);

/**
 * dbg_utils_txt_printer_extended_str_print
 */
const char* dbg_utils_txt_printer_extended_str_print(txt_printer_ptr txt_printer_p,
                                                     const char    * str,
                                                     int             width);

/**
 * dbg_utils_txt_printer_empty_clmn_print
 */
void dbg_utils_txt_printer_empty_clmn_print(txt_printer_ptr txt_printer_p,
                                            int             width);

/**
 * dbg_utils_txt_printer_field_w_len_print
 *
 * If the key points to a printer that was enabled to produce a text file,
 * this function will print a string to the file associated with the printer.
 */
void dbg_utils_txt_printer_field_w_len_print(txt_printer_ptr        txt_printer_p,
                                             const char            *name,
                                             const void            *data,
                                             dbg_utils_param_type_e type,
                                             unsigned int           data_len);

/**
 * dbg_utils_txt_printer_field_simple_print
 *
 * this func prints simple data by type
 */
void dbg_utils_txt_printer_field_simple_print(txt_printer_ptr        txt_printer_p,
                                              const char            *name,
                                              const void            *data,
                                              dbg_utils_param_type_e type);

/**
 * dbg_utils_txt_printer_module_header_print
 */
void dbg_utils_txt_printer_module_header_print(txt_printer_ptr txt_printer_p, const char *module_name);

/**
 * dbg_utils_txt_printer_table_headline_with_name_print
 */
void dbg_utils_txt_printer_table_headline_with_name_print(txt_printer_ptr            txt_printer_p,
                                                          dbg_utils_table_columns_t *columns,
                                                          char                     * name);

/**
 * dbg_utils_txt_printer_table_data_line_nosep_print
 */
int dbg_utils_txt_printer_table_data_line_nosep_print(txt_printer_ptr            txt_printer_p,
                                                      dbg_utils_table_columns_t *columns);

/**
 * dbg_utils_txt_printer_separator_line_print
 */
void dbg_utils_txt_printer_separator_line_print(txt_printer_ptr txt_printer_p, int total_width, char separator_char);

/**
 * dbg_utils_txt_printer_counters_group_header_print
 */
void dbg_utils_txt_printer_counters_group_header_print(txt_printer_ptr txt_printer_p, const char *cntr_grp_name,
                                                       uint32_t port_id);

/**
 * dbg_utils_txt_printer_counters_group_sub_header_print
 */
void dbg_utils_txt_printer_counters_group_sub_header_print(txt_printer_ptr txt_printer_p, const char *buf);

/**
 * dbg_utils_txt_printer_counters_group_sub_header_print
 */
void dbg_utils_txt_printer_counter_print(txt_printer_ptr txt_printer_p, const char *cntr_name, uint64_t cntr_value);

/**
 * dbg_utils_txt_printer_general_header_print
 */
void dbg_utils_txt_printer_general_header_print(txt_printer_ptr txt_printer_p, const char *general_header);

/**
 * dbg_utils_txt_printer_sub_module_header_print
 */
void dbg_utils_txt_printer_sub_module_header_print(txt_printer_ptr txt_printer_p, const char *sub_module_header);

/**
 * dbg_utils_txt_printer_plain_text_secondary_header_print
 */
void dbg_utils_txt_printer_plain_text_secondary_header_print(txt_printer_ptr txt_printer_p, const char *buf);

/**
 * dbg_utils_txt_printer_user_defined_header_print
 */
void dbg_utils_txt_printer_user_defined_header_print(txt_printer_ptr txt_printer_p, const char       *buf);

/**
 * dbg_utils_txt_printer_secondary_header_print
 */
void dbg_utils_txt_printer_secondary_header_print(txt_printer_ptr txt_printer_p, const char *buf);

/**
 * dbg_utils_txt_printer_time_stamp_print
 */
void dbg_utils_txt_printer_time_stamp_print(txt_printer_ptr txt_printer_p, const char * name, char *stime);

/**
 * dbg_utils_txt_printer_binary_tree_draw
 */
void dbg_utils_txt_printer_binary_tree_draw(txt_printer_ptr txt_printer_p, const dbg_utils_tree_t* tree);

/**
 * dbg_utils_txt_printer_data_unavailable_print
 */
void dbg_utils_txt_printer_data_unavailable_print(txt_printer_ptr txt_printer_p);

#endif /* __DBG_UTILS_TXT_PRINTER_H__ */
