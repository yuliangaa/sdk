/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __DBG_UTILS_CHEAT_SHEET_H__
#define __DBG_UTILS_CHEAT_SHEET_H__

#include "complib/sx_log.h"

#include "sx/utils/sx_utils_status.h"

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct cheat_sheet* cheat_sheet_ptr;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_utils_status_t dbg_utils_cheat_sheet_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

/**
 * dbg_utils_cheat_sheet_create
 */
cheat_sheet_ptr dbg_utils_cheat_sheet_create(void);

/**
 * dbg_utils_cheat_sheet_destroy
 */
void dbg_utils_cheat_sheet_destroy(cheat_sheet_ptr cheat_sheet_p);

cheat_sheet_ptr dbg_utils_cheat_sheet_clone(cheat_sheet_ptr src_cheat_sheet_p);
void dbg_utils_cheat_sheet_append(cheat_sheet_ptr dst_cheat_sheet_p, cheat_sheet_ptr src_cheat_sheet_p);

/**
 * dbg_utils_cheat_sheet_print
 */
void dbg_utils_cheat_sheet_print(cheat_sheet_ptr cheat_sheet_p, char ** cheat_sheet_str);

/**
 * dbg_utils_cheat_sheet_module_header_print
 */
void dbg_utils_cheat_sheet_module_header_print(cheat_sheet_ptr cheat_sheet_p, const char *module_name);

/**
 * dbg_utils_cheat_sheet_module_header_print
 */
void dbg_utils_cheat_sheet_general_header_print(cheat_sheet_ptr cheat_sheet_p,
                                                const char     *general_header);

/**
 * dbg_utils_cheat_sheet_sub_module_header_print
 */
void dbg_utils_cheat_sheet_sub_module_header_print(cheat_sheet_ptr cheat_sheet_p,
                                                   const char     *sub_module_header);

#endif /* __DBG_UTILS_CHEAT_SHEET_H__ */
