/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __DBG_UTILS_JSON_PRINTER_H__
#define __DBG_UTILS_JSON_PRINTER_H__

#include <stdio.h>

#include "complib/sx_log.h"

#include "sx/utils/sx_utils_status.h"

#include "sx/utils/dbg_utils_types.h"

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct json_printer* json_printer_ptr;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_utils_status_t dbg_utils_json_printer_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

/**
 * dbg_utils_json_printer_create
 */
json_printer_ptr dbg_utils_json_printer_create(FILE *json_fp, boolean_t json_compressed);

/**
 * dbg_utils_json_printer_destroy
 */
void dbg_utils_json_printer_destroy(json_printer_ptr json_printer_p);

void dbg_utils_json_printer_print(json_printer_ptr json_printer_p, const char *fmt, ...);

void dbg_utils_json_printer_header_object_create(json_printer_ptr  json_printer_p,
                                                 dbg_utils_level_e new_level,
                                                 const char      * object_name,
                                                 boolean_t         is_table);

void dbg_utils_json_printer_string_object_create(json_printer_ptr  json_printer_p,
                                                 dbg_utils_level_e new_level,
                                                 char             *value);

void dbg_utils_json_printer_table_item_create(json_printer_ptr json_printer_p, dbg_utils_level_e new_level);

void dbg_utils_json_printer_field_simple_print(json_printer_ptr       json_printer_p,
                                               const char            *name,
                                               const void            *data,
                                               dbg_utils_param_type_e type);

void dbg_utils_json_printer_field_with_level_print(json_printer_ptr       json_printer_p,
                                                   const char            *name,
                                                   const void            *data,
                                                   dbg_utils_param_type_e type,
                                                   dbg_utils_level_e      new_level);

void dbg_utils_json_printer_module_header_print(json_printer_ptr json_printer_p, const char *module_name);

void dbg_utils_json_printer_table_headline_with_name_print(json_printer_ptr           json_printer_p,
                                                           dbg_utils_table_columns_t *columns,
                                                           char                     * name);

void dbg_utils_json_printer_table_name_set(json_printer_ptr json_printer_p, char *table_name);

int dbg_utils_json_printer_table_data_line_nosep_print(json_printer_ptr           json_printer_p,
                                                       dbg_utils_table_columns_t *columns);

void dbg_utils_json_printer_counters_group_header_print(json_printer_ptr json_printer_p,
                                                        const char      *cntr_grp_name,
                                                        uint32_t         port_id);

void dbg_utils_json_printer_counters_group_sub_header_print(json_printer_ptr json_printer_p, const char *buf);

void dbg_utils_json_printer_counter_print(json_printer_ptr json_printer_p, const char *cntr_name, uint64_t cntr_value);

void dbg_utils_json_printer_counter_with_level_print(json_printer_ptr  json_printer_p,
                                                     const char       *cntr_name,
                                                     uint64_t          cntr_value,
                                                     dbg_utils_level_e new_level);

void dbg_utils_json_printer_general_header_print(json_printer_ptr json_printer_p, const char *general_header);

void dbg_utils_json_printer_sub_module_header_print(json_printer_ptr json_printer_p, const char *sub_module_header);

void dbg_utils_json_printer_user_defined_header_print(json_printer_ptr  json_printer_p,
                                                      dbg_utils_level_e user_defined_level,
                                                      const char       *buf);

void dbg_utils_json_printer_secondary_header_print(json_printer_ptr json_printer_p, const char       *buf);

void dbg_utils_json_printer_time_stamp_print(json_printer_ptr json_printer_p, const char * name, char *stime);

void dbg_utils_json_printer_binary_tree_draw(json_printer_ptr json_printer_p, const dbg_utils_tree_t* tree);


#endif /* __DBG_UTILS_JSON_PRINTER_H__ */
