/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <unistd.h>
#include <string.h>
#include <sx/utils/linear_manager.h>
#include "../utils/gen_utils.h"
#include <sx/utils/id_allocator.h>
#include <complib/cl_dbg.h>

#undef  __MODULE__
#define __MODULE__ LINEAR_MANAGER


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/


static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;


/************************************************
 *  Local Type definitions
 ***********************************************/
typedef struct linear_manager_block_info {
    cl_pool_item_t                pool_item;
    cl_map_item_t                 map_item;
    cl_qlist_t                    ba_logical_id_list;
    cl_qlist_t                    relocate_cntx_list;
    linear_manager_block_length_t size;
    linear_manager_block_type_e   block_type;
    linear_manager_context_t      context;
    linear_manager_handle_t       handle;
} linear_manager_block_info_t;

typedef struct linear_manager_index_struct {
    cl_pool_item_t  pool_item;
    cl_list_item_t  list_item;
    ba_logical_id_t logical_id;
} linear_manager_ba_logical_id_struct_t;

typedef struct linear_manager_relocate_cntx_list_item {
    cl_pool_item_t pool_item;
    cl_list_item_t list_item;
    void         * relocate_cntx;
} linear_manager_relocate_cntx_list_item_t;

typedef struct linear_manager_phys_memory {
    cl_qpool_t     block_info_pool;
    cl_qpool_t     ba_logical_id_pool;
    cl_qpool_t     relocate_cntx_pool;
    char           phys_mem_name[LINEAR_MANAGER_MAX_PHYS_MEM_NAME];
    uint32_t       phys_mem_size;
    id_allocator_t block_info_id_allocator;
    uint32_t       ref_count;
} linear_manager_phys_memory_t;

typedef struct __linear_manager_db {
    ba_handle_t                     bin_allocator;
    linear_manager_index_t          table_size;
    cl_qmap_t                       handle_to_block_map;
    linear_manager_alloc_group_t    group_alloc;
    linear_manager_free_group_t     group_free;
    linear_manager_block_relocate_t block_relocate;
    boolean_t                       is_initialized;
    linear_manager_phys_memory_t   *p_phys_mem;
    boolean_t                       async_enabled;
    cl_spinlock_t                   thread_lock;
} __linear_manager_db_t;

static __linear_manager_db_t         linear_manager_db_array[LINEAR_MANAGER_MAX_CLIENTS];
static linear_manager_phys_memory_t  linear_manager_phys_mem_array[LINEAR_MANAGER_MAX_PHYS_MEM];
static linear_manager_async_params_t linear_manager_async_params;

#define LINEAR_MANAGER_THREAD_UNLOCK()                                                  \
    if (thread_lock) {                                                                  \
        utils_err_out = __linear_manager_thread_unlock(db_p);                           \
        if (SX_UTILS_CHECK_FAIL(utils_err_out)) {                                       \
            SX_LOG(SX_LOG_ERROR, "Linear manager : thread unlock failed, err = [%s]\n", \
                   SX_UTILS_STATUS_MSG(utils_err_out));                                 \
        }                                                                               \
    }

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_utils_status_t __init_param_check(linear_manager_params_t *param_p);
static sx_utils_status_t __block_type_param_check(linear_manager_block_type_e block_type);
static sx_utils_status_t __block_handle_get(__linear_manager_db_t        *database,
                                            linear_manager_handle_t       handle,
                                            linear_manager_block_info_t **pp_block_info);
static sx_utils_status_t __linear_manager_relocate(ba_handle_t handle,
                                                   ba_logical_id_t lid,
                                                   uint32_t cntx,
                                                   ba_index_t old_id,
                                                   ba_index_t new_id, void*           relocate_cntx);
static sx_utils_status_t __relocation_context_handle_pop(linear_manager_db_t     database,
                                                         linear_manager_handle_t handle,
                                                         void                  **pp_relocate_cntx);
static sx_utils_status_t __relocation_context_handle_push(linear_manager_db_t     database,
                                                          linear_manager_handle_t handle,
                                                          void                   *p_relocate_cntx);
static sx_utils_status_t __linear_manager_async_relocate(ba_handle_t ba_handle,
                                                         ba_logical_id_t lid,
                                                         uint32_t cntx,
                                                         ba_index_t old_id,
                                                         ba_index_t new_id, void* relocate_cntx);
static sx_utils_status_t __linear_manager_thread_lock_init(linear_manager_db_t database);
static sx_utils_status_t __linear_manager_thread_lock_deinit(linear_manager_db_t database);
static sx_utils_status_t __linear_manager_thread_lock(linear_manager_db_t database);
static sx_utils_status_t __linear_manager_thread_unlock(linear_manager_db_t database);

/************************************************
 *  Function implementations
 ***********************************************/

static sx_utils_status_t __phys_mem_init(linear_manager_params_t *param_p, __linear_manager_db_t *db_p)
{
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;
    uint32_t          phys_mem_i = 0;
    uint32_t          phys_mem_size = 0;
    boolean_t         block_info_pool_initialized = FALSE;
    uint32_t          first_free = 0;

    SX_LOG_ENTER();

    if (param_p->p_phys_init) {
        if (param_p->p_phys_init->phys_mem_name[0] == '\0') {
            utils_err = SX_UTILS_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Physical memory name cannot be empty, if given\n");
            goto out;
        }

        if (param_p->p_phys_init->phys_mem_size == 0) {
            utils_err = SX_UTILS_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Physical memory size cannot be 0, if given\n");
            goto out;
        }

        phys_mem_size = param_p->p_phys_init->phys_mem_size;
        first_free = LINEAR_MANAGER_MAX_PHYS_MEM;
        for (phys_mem_i = 0; phys_mem_i < LINEAR_MANAGER_MAX_PHYS_MEM;
             phys_mem_i++) {
            if (!strncmp(param_p->p_phys_init->phys_mem_name,
                         linear_manager_phys_mem_array[phys_mem_i].phys_mem_name,
                         sizeof(param_p->p_phys_init->phys_mem_name))) {
                if (param_p->p_phys_init->phys_mem_size !=
                    linear_manager_phys_mem_array[phys_mem_i].phys_mem_size) {
                    utils_err = SX_UTILS_STATUS_PARAM_ERROR;
                    SX_LOG_ERR("Given physical memory size %u of %s is different from existing size %u\n",
                               param_p->p_phys_init->phys_mem_size,
                               param_p->p_phys_init->phys_mem_name,
                               linear_manager_phys_mem_array[phys_mem_i].phys_mem_size);
                    goto out;
                }

                db_p->p_phys_mem = &linear_manager_phys_mem_array[phys_mem_i];
                db_p->p_phys_mem->ref_count++;
                goto out;
            } else if (linear_manager_phys_mem_array[phys_mem_i].phys_mem_size == 0) {
                first_free = phys_mem_i;
            }
        }

        if (first_free < LINEAR_MANAGER_MAX_PHYS_MEM) {
            db_p->p_phys_mem = &linear_manager_phys_mem_array[first_free];
            M_GEN_UTILS_MEM_CLR_PTR(db_p->p_phys_mem, sizeof(*(db_p->p_phys_mem)));
        }
    } else {
        phys_mem_size = db_p->table_size;
        for (phys_mem_i = 0; phys_mem_i < LINEAR_MANAGER_MAX_PHYS_MEM;
             phys_mem_i++) {
            if (linear_manager_phys_mem_array[phys_mem_i].phys_mem_size == 0) {
                db_p->p_phys_mem = &linear_manager_phys_mem_array[phys_mem_i];
                M_GEN_UTILS_MEM_CLR_PTR(db_p->p_phys_mem, sizeof(*(db_p->p_phys_mem)));
                break;
            }
        }
    }

    if (!db_p->p_phys_mem) {
        utils_err = SX_UTILS_STATUS_NO_RESOURCES;
        SX_LOG_ERR("No more physical memory resources exist!\n");
        goto out;
    }

    cl_err = id_allocator_init(phys_mem_size, phys_mem_size / 8, 0, &(db_p->p_phys_mem->block_info_id_allocator));
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Failed to initialize id_allocator for linear manager, cl_err = [%s]\n", CL_STATUS_MSG(cl_err));
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    cl_err = CL_QPOOL_INIT(&db_p->p_phys_mem->block_info_pool,
                           phys_mem_size / 8,
                           phys_mem_size,
                           phys_mem_size / 8,
                           sizeof(linear_manager_block_info_t),
                           NULL,
                           NULL,
                           NULL);
    if (cl_err != CL_SUCCESS) {
        utils_err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Failed to initialize block info pool, cl_err = [%s]\n",
                   CL_STATUS_MSG(cl_err));
        goto out;
    }
    block_info_pool_initialized = TRUE;

    cl_err = CL_QPOOL_INIT(&db_p->p_phys_mem->ba_logical_id_pool,
                           phys_mem_size / 8,
                           phys_mem_size,
                           phys_mem_size / 8,
                           sizeof(linear_manager_ba_logical_id_struct_t),
                           NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to init logical_id pool.\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    cl_err = CL_QPOOL_INIT(&db_p->p_phys_mem->relocate_cntx_pool,
                           phys_mem_size / 8,
                           phys_mem_size,
                           phys_mem_size / 8,
                           sizeof(linear_manager_relocate_cntx_list_item_t),
                           NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to init relocate cntx pool.\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    db_p->p_phys_mem->phys_mem_size = phys_mem_size;
    if (param_p->p_phys_init) {
        strncpy(db_p->p_phys_mem->phys_mem_name,
                param_p->p_phys_init->phys_mem_name,
                sizeof(db_p->p_phys_mem->phys_mem_name));
    }
    db_p->p_phys_mem->ref_count++;

out:
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        if (block_info_pool_initialized) {
            CL_QPOOL_DESTROY(&db_p->p_phys_mem->block_info_pool);
        }
    }
    SX_LOG_EXIT();
    return utils_err;
}

static void __phys_mem_deinit(__linear_manager_db_t *db_p)
{
    cl_status_t                   cl_err = CL_SUCCESS;
    linear_manager_phys_memory_t *p_phys_mem = NULL;

    SX_LOG_ENTER();

    if (db_p->p_phys_mem == NULL) {
        SX_LOG_ERR("Internal error - Physical memory pointer is NULL!\n");
        goto out;
    }

    p_phys_mem = db_p->p_phys_mem;

    if (p_phys_mem->ref_count == 0) {
        SX_LOG_ERR("Internal error - reference count of physical memory space is 0!\n");
        goto out;
    }

    db_p->p_phys_mem = NULL;

    p_phys_mem->ref_count--;
    if (p_phys_mem->ref_count > 0) {
        goto out;
    }

    CL_QPOOL_DESTROY(&p_phys_mem->block_info_pool);
    CL_QPOOL_DESTROY(&p_phys_mem->ba_logical_id_pool);
    CL_QPOOL_DESTROY(&p_phys_mem->relocate_cntx_pool);

    cl_err = id_allocator_destroy(&(p_phys_mem->block_info_id_allocator));
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Failed to deinit physical memory, failed to destroy id_allocator, err = [%s]\n",
                   CL_STATUS_MSG(cl_err));
    }
    M_GEN_UTILS_MEM_CLR_PTR(p_phys_mem, sizeof(*p_phys_mem));

out:
    SX_LOG_EXIT();
    return;
}

static sx_utils_status_t __group_alloc(ba_handle_t handle, uint32_t type, const ba_group_t **group_p)
{
    sx_utils_status_t      err = SX_UTILS_STATUS_SUCCESS;
    uint32_t               db_idx = 0;
    __linear_manager_db_t *db = NULL;

    SX_LOG_ENTER();

    for (db_idx = 0; db_idx < LINEAR_MANAGER_MAX_CLIENTS; db_idx++) {
        db = &linear_manager_db_array[db_idx];

        if (handle == db->bin_allocator) {
            err = db->group_alloc(db, type, group_p);
            if (SX_UTILS_CHECK_FAIL(err)) {
                if (err == SX_UTILS_STATUS_NO_RESOURCES) {
                    SX_LOG_DBG("Failed to allocate new group, err = [%s]\n",
                               SX_UTILS_STATUS_MSG(err));
                } else {
                    SX_LOG_ERR("Failed to allocate new group, err = [%s]\n",
                               SX_UTILS_STATUS_MSG(err));
                }
                goto out;
            }

            break;
        }
    }

    if (db_idx == LINEAR_MANAGER_MAX_CLIENTS) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Handle %p not found!\n", handle);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_utils_status_t __group_free(ba_handle_t handle, ba_group_t *group)
{
    sx_utils_status_t      err = SX_UTILS_STATUS_SUCCESS;
    uint32_t               db_idx = 0;
    __linear_manager_db_t *db = NULL;

    SX_LOG_ENTER();

    for (db_idx = 0; db_idx < LINEAR_MANAGER_MAX_CLIENTS; db_idx++) {
        db = &linear_manager_db_array[db_idx];

        if (handle == db->bin_allocator) {
            err = db->group_free(db, group);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to free group, err = [%s]\n",
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            break;
        }
    }

    if (db_idx == LINEAR_MANAGER_MAX_CLIENTS) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Handle %p not found!\n", handle);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_utils_status_t linear_manager_async_init(linear_manager_async_params_t *param_p, void    *info_p)
{
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_cb_relocate_t *cb_relocate_p = (ba_cb_relocate_t*)info_p;

    SX_LOG_ENTER();
    linear_manager_async_params.async_deinit_cb = param_p->async_deinit_cb;
    linear_manager_async_params.async_init_cb = param_p->async_init_cb;
    linear_manager_async_params.relocate_async_cb = param_p->relocate_async_cb;
    linear_manager_async_params.async_get_tid_cb = param_p->async_get_tid_cb;

    *cb_relocate_p = &__linear_manager_relocate;

    SX_LOG_EXIT();

    return utils_err;
}

sx_utils_status_t linear_manager_init(linear_manager_db_t * database_p, linear_manager_params_t           *param_p)
{
    sx_utils_status_t                 utils_err = SX_UTILS_STATUS_SUCCESS;
    __linear_manager_db_t            *db_p = NULL;
    linear_manager_allocation_types_t type;
    linear_manager_allocation_types_t type_index;
    ba_param_t                        bin_init_params;
    uint16_t                          alloc_size_i;
    uint8_t                           user_i;
    boolean_t                         phys_mem_initialized = FALSE;

    SX_LOG_ENTER();

    if (database_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "Called with NULL database param\n");
        utils_err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    utils_err = __init_param_check(param_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        goto out;
    }

    /*create instance of linear manager*/
    for (user_i = 0; user_i < LINEAR_MANAGER_MAX_CLIENTS; ++user_i) {
        if (linear_manager_db_array[user_i].is_initialized == FALSE) {
            db_p = &linear_manager_db_array[user_i];
            break;
        }
    }
    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "linear manager reached max num of users, cant create more users.\n");
        goto out;
    }

    db_p->table_size = param_p->array_size;

    utils_err = __phys_mem_init(param_p, db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG_ERR("Failed to initialize physical memory, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    phys_mem_initialized = TRUE;

    if (db_p->p_phys_mem == NULL) {
        utils_err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Internal error - Physical memory pointer is NULL!\n");
        goto out;
    }

    cl_qmap_init(&db_p->handle_to_block_map);

    /* set callbacks */
    db_p->block_relocate = param_p->relocate_cb;
    db_p->group_alloc = param_p->alloc_group_cb;
    db_p->group_free = param_p->free_group_cb;

    /* Is async enabled */
    db_p->async_enabled = param_p->async_enabled;

    /* thread lock init */
    utils_err = __linear_manager_thread_lock_init(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock init failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

    /*initialize bin allocator*/
    M_GEN_UTILS_MEM_CLR(bin_init_params);
    bin_init_params.alignment = param_p->alignment;
    bin_init_params.array_size = param_p->array_size;
    bin_init_params.group_cnt = param_p->array_size / param_p->alignment;
    bin_init_params.version = BIN_ALLOC_VERSION;
    bin_init_params.r_thresh = param_p->relocation_threshold;
    bin_init_params.r_count = param_p->relocation_count;
    if (param_p->relocation_disabled == FALSE) {
        /* Linear Manager Async perform GC in Background */
        bin_init_params.options = (RELOC_ASYNC_E);
        if (param_p->async_enabled == TRUE) {
            /* Linear Manager Async perform GC in Background and push object to GC in async mode*/
            bin_init_params.options = (RELOC_ASYNC_E | RELOC_ASYNC_GC_E);
        }
    }

    bin_init_params.total_size = param_p->total_size;
    bin_init_params.gc_object_type = param_p->gc_object_type;
    bin_init_params.gc_subtype = param_p->gc_subtype;
    bin_init_params.gc_attr = param_p->gc_attr;
    bin_init_params.gc_post_completion_cb = param_p->gc_post_completion_cb;
    bin_init_params.free_object_cb = NULL;
    bin_init_params.phys_init = (ba_phys_init_t*)param_p->p_phys_init;
    for (type = 1; type <= param_p->allocation_types_num; ++type) {
        type_index = type - 1;
        for (alloc_size_i = 0; alloc_size_i < LINEAR_MANAGER_MAX_ALLOC_SIZES; ++alloc_size_i) {
            bin_init_params.templates[type_index].alloc_sizes[alloc_size_i] =
                param_p->allocation_types_params[type_index].alloc_sizes[alloc_size_i];
        }
        bin_init_params.templates[type_index].type = type;
        bin_init_params.templates[type_index].cb_alloc = __group_alloc;
        bin_init_params.templates[type_index].cb_free = __group_free;
        bin_init_params.templates[type_index].length = param_p->alignment;
        bin_init_params.templates[type_index].cb_relocate = &__linear_manager_async_relocate;
    }

    utils_err = ba_client_init(&db_p->bin_allocator, &bin_init_params);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to init bin allocator.\n");
        goto out;
    }
    linear_manager_db_array[user_i].is_initialized = TRUE;

    *database_p = (linear_manager_db_t)db_p;

out:
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        if (phys_mem_initialized) {
            __phys_mem_deinit(db_p);
        }
    }
    SX_LOG_EXIT();
    return utils_err;
}

static sx_utils_status_t __force_remove_lid_references(__linear_manager_db_t       *p_db,
                                                       linear_manager_block_info_t *p_block_info)
{
    sx_utils_status_t                      err = SX_UTILS_STATUS_SUCCESS;
    cl_list_item_t                        *p_item = NULL;
    linear_manager_ba_logical_id_struct_t *p_lid_item = NULL;
    uint32_t                               ref = 0;

    SX_LOG_ENTER();

    p_item = cl_qlist_head(&p_block_info->ba_logical_id_list);
    p_lid_item = PARENT_STRUCT(p_item, linear_manager_ba_logical_id_struct_t,
                               list_item);

    err = ba_client_cntx_get(p_db->bin_allocator, p_lid_item->logical_id,
                             NULL, &ref);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get client context for LID %u, err = [%s]\n",
                   p_lid_item->logical_id, SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if (ref > 1) {
        SX_LOG_WRN("Reference count of LID %u is %u! Reducing to 1\n",
                   p_lid_item->logical_id, ref);
        err = ba_ref_modify(p_db->bin_allocator, p_lid_item->logical_id,
                            1 - ref);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to modify refcount of LID %u by %d, err = [%s]\n",
                       p_lid_item->logical_id, 1 - ref,
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t linear_manager_deinit(linear_manager_db_t database)
{
    sx_utils_status_t            utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t            utils_err_ba = SX_UTILS_STATUS_SUCCESS;
    __linear_manager_db_t       *db_p = (__linear_manager_db_t*)database;
    const cl_map_item_t         *p_end = NULL;
    cl_map_item_t               *p_head = NULL;
    linear_manager_block_info_t *p_block_info = NULL;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if (cl_qmap_count(&db_p->handle_to_block_map) > 0) {
        SX_LOG(SX_LOG_NOTICE, "Linear manager : DB is not empty.\n");

        p_end = cl_qmap_end(&db_p->handle_to_block_map);
        p_head = cl_qmap_head(&db_p->handle_to_block_map);
        while (p_head != p_end) {
            p_block_info = PARENT_STRUCT(p_head, linear_manager_block_info_t, map_item);

            /* Since this is a deinit, we need to remove any references to the
             * LID that the client may have forgotten to do so themselves.
             * Otherwise, the bin allocator will not let us delete the LID.
             */
            utils_err = __force_remove_lid_references(db_p, p_block_info);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                goto out;
            }
            utils_err = linear_manager_block_delete(database, p_block_info->handle, FALSE);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                goto out;
            }

            p_head = cl_qmap_head(&db_p->handle_to_block_map);
        }
    }

    /* thread lock deinit */
    utils_err = __linear_manager_thread_lock_deinit(database);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock deinit failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

    /*deinit bin allocator*/
    utils_err_ba = ba_client_deinit(db_p->bin_allocator);
    if (SX_UTILS_CHECK_FAIL(utils_err_ba)) {
        utils_err = SX_UTILS_STATUS_ERROR;
        SX_LOG(SX_LOG_ERROR, "Linear manager : bin allocator deinit failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err_ba));
    }


    db_p->is_initialized = FALSE;
    db_p->block_relocate = NULL;
    db_p->group_alloc = NULL;
    db_p->group_free = NULL;
    __phys_mem_deinit(db_p);

    M_GEN_UTILS_MEM_CLR(*db_p);

out:
    SX_LOG_EXIT();
    return utils_err;
}

sx_utils_status_t linear_manager_block_add(linear_manager_db_t               database,
                                           linear_manager_allocation_types_t allocation_type,
                                           linear_manager_block_type_e       block_type,
                                           linear_manager_block_length_t     size,
                                           linear_manager_context_t          context,
                                           boolean_t                         reuse_handle,
                                           linear_manager_handle_t         * handle_p)
{
    __linear_manager_db_t                 *db_p = (__linear_manager_db_t*)database;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_out = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_on_fail = SX_UTILS_STATUS_SUCCESS;
    cl_status_t                            cl_err = CL_SUCCESS;
    cl_pool_item_t                        *pool_item_p;
    cl_list_item_t                        *list_item_p;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    linear_manager_block_info_t           *block_struct_p;
    linear_manager_block_length_t          block_length_i;
    boolean_t                              thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    if (handle_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL param handle_p\n");
        utils_err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    utils_err = __block_type_param_check(block_type);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        goto out;
    }

    /* Sanity check - should never happen */
    if (db_p->p_phys_mem == NULL) {
        SX_LOG(SX_LOG_ERROR, "Internal error - Physical memory pointer NULL!\n");
        goto out;
    }

    if (TRUE == reuse_handle) {
        utils_err = id_allocator_validate_allocated_id(&(db_p->p_phys_mem->block_info_id_allocator), *handle_p);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "Given handle %u is out of range.\n", *handle_p);
            goto out;
        }

        /* Validate this handle is not in use */
        utils_err = __block_handle_get(db_p, *handle_p, &block_struct_p);
        if (SX_UTILS_STATUS_SUCCESS == utils_err) {
            /* Handle is in use - cannot reuse this handle for the new block */
            utils_err = SX_UTILS_STATUS_RESOURCE_IN_USE;
            SX_LOG(SX_LOG_ERROR, "Failed to add block with reuse handle flag enable."
                   "Given handle is in use.\n");
            goto out;
        }
    }

    /*get block from pool*/
    pool_item_p = cl_qpool_get(&db_p->p_phys_mem->block_info_pool);
    if (NULL == pool_item_p) {
        SX_LOG(SX_LOG_DEBUG, "Cannot get block info struct.\n");
        utils_err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }
    block_struct_p = PARENT_STRUCT(pool_item_p, linear_manager_block_info_t, pool_item);

    if (TRUE == reuse_handle) {
        block_struct_p->handle = *handle_p;
    } else {
        cl_err = id_allocator_get(&(db_p->p_phys_mem->block_info_id_allocator), &(block_struct_p->handle));
        if (cl_err != CL_SUCCESS) {
            SX_LOG_ERR("Failed to get new index for physical memory, err = [%s]\n",
                       CL_STATUS_MSG(cl_err));
            goto out;
        }
    }

    block_struct_p->size = size;
    block_struct_p->context = context;
    block_struct_p->block_type = block_type;
    cl_qlist_init(&block_struct_p->ba_logical_id_list);
    cl_qlist_init(&block_struct_p->relocate_cntx_list);

    /*get bin allocator logical id for block*/
    if (block_struct_p->block_type == LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E) {
        if (size != 0) {
            /*get logical_id_struct_p pool item*/
            pool_item_p = cl_qpool_get(&db_p->p_phys_mem->ba_logical_id_pool);
            if (NULL == pool_item_p) {
                SX_LOG(SX_LOG_DEBUG, "Cannot get logical_id struct for block.\n");
                utils_err = SX_UTILS_STATUS_NO_RESOURCES;
                goto err_out_after_block_get;
            }
            logical_id_struct_p = PARENT_STRUCT(pool_item_p, linear_manager_ba_logical_id_struct_t, pool_item);

            /*call bin allocator to get one block*/

            if (db_p->async_enabled == TRUE) {
                /* Lock BA */
                utils_err = ba_thread_lock(db_p->bin_allocator);
                if (SX_UTILS_CHECK_FAIL(utils_err)) {
                    SX_LOG(SX_LOG_ERROR, "Error at bin allocator thread lock.\n");
                    goto err_out_after_block_get;
                }
            }
            utils_err = ba_allocate(db_p->bin_allocator,
                                    allocation_type,
                                    size,
                                    block_struct_p->handle,
                                    &logical_id_struct_p->logical_id);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                if (utils_err == SX_UTILS_STATUS_NO_RESOURCES) {
                    SX_LOG(SX_LOG_DEBUG, "No resources for bin allocator block allocation\n");
                } else {
                    SX_LOG(SX_LOG_NOTICE, "Bin allocator block allocation failed, err = %d\n",
                           utils_err);
                }

                if (db_p->async_enabled == TRUE) {
                    /* Un Lock BA */
                    if (SX_UTILS_CHECK_FAIL(ba_thread_lock(db_p->bin_allocator))) {
                        SX_LOG(SX_LOG_ERROR, "Error at bin allocator thread unlock.\n");
                    }
                }

                goto err_out_after_bin_alloc_call;
            }
            if (db_p->async_enabled == TRUE) {
                /* Un Lock BA */
                if (SX_UTILS_CHECK_FAIL(ba_thread_unlock(db_p->bin_allocator))) {
                    SX_LOG(SX_LOG_ERROR, "Error at bin allocator thread unlock.\n");
                    goto err_out_after_bin_alloc_call;
                }
            }
            /*inset logical_id_struct_p item to list*/
            cl_qlist_insert_tail(&block_struct_p->ba_logical_id_list, &logical_id_struct_p->list_item);
        }
    } else { /*linked list*/
             /*call bin allocator to get size times block of size one*/
        for (block_length_i = 0; block_length_i < size; ++block_length_i) {
            /*get logical_id_struct_p pool item*/
            pool_item_p = cl_qpool_get(&db_p->p_phys_mem->ba_logical_id_pool);
            if (NULL == pool_item_p) {
                SX_LOG(SX_LOG_NOTICE, "Cannot get logical_id struct for block.\n");
                utils_err = SX_UTILS_STATUS_NO_RESOURCES;
                goto err_out_after_logical_id_get;
            }
            logical_id_struct_p = PARENT_STRUCT(pool_item_p, linear_manager_ba_logical_id_struct_t, pool_item);

            /*call bin allocator to get one block*/
            utils_err = ba_allocate(db_p->bin_allocator,
                                    allocation_type,
                                    1,
                                    block_struct_p->handle,
                                    &logical_id_struct_p->logical_id);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG(SX_LOG_NOTICE, "Bin allocator block allocation failed.\n");
                goto err_out_after_bin_alloc_call;
            }

            /*inset logical_id item to list*/
            cl_qlist_insert_tail(&block_struct_p->ba_logical_id_list, &logical_id_struct_p->list_item);
        }
    }

    /*insert block info to db_p*/
    cl_qmap_insert(&db_p->handle_to_block_map, block_struct_p->handle,
                   &block_struct_p->map_item);
    *handle_p = block_struct_p->handle;

    goto out;

err_out_after_bin_alloc_call:
    /*return logical_id to pool*/
    cl_qpool_put(&db_p->p_phys_mem->ba_logical_id_pool,
                 &logical_id_struct_p->pool_item);

err_out_after_logical_id_get:
    /*return logical_id to pool and delete entry from bin allocator*/
    while (0 != cl_qlist_count(&block_struct_p->ba_logical_id_list)) {
        list_item_p = cl_qlist_remove_head(&block_struct_p->ba_logical_id_list);
        logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
        utils_err_on_fail = ba_free(db_p->bin_allocator, logical_id_struct_p->logical_id);
        if (SX_UTILS_CHECK_FAIL(utils_err_on_fail)) {
            SX_LOG(SX_LOG_ERROR, "Failed to delete block from bin allocator in rollback.\n");
        }
        cl_qpool_put(&db_p->p_phys_mem->ba_logical_id_pool,
                     &logical_id_struct_p->pool_item);
    }

err_out_after_block_get:

    if (FALSE == reuse_handle) {
        cl_err = id_allocator_put(&(db_p->p_phys_mem->block_info_id_allocator), block_struct_p->handle);
        if (cl_err != CL_SUCCESS) {
            SX_LOG_ERR("Failed to delete physical memory index %d, err = [%s]\n",
                       block_struct_p->handle, CL_STATUS_MSG(cl_err));
            goto out;
        }
    }
    cl_qpool_put(&db_p->p_phys_mem->block_info_pool, &block_struct_p->pool_item);

out:
    LINEAR_MANAGER_THREAD_UNLOCK();
    SX_LOG_EXIT();
    return utils_err;
}


sx_utils_status_t linear_manager_block_delete(linear_manager_db_t     database,
                                              linear_manager_handle_t handle,
                                              boolean_t               reuse_handle)
{
    __linear_manager_db_t                 *db_p = (__linear_manager_db_t*)database;
    linear_manager_block_info_t           *block_struct_p = NULL;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_out = SX_UTILS_STATUS_SUCCESS;
    cl_status_t                            cl_err = CL_SUCCESS;
    cl_list_item_t                        *list_item_p;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    linear_manager_block_length_t          block_length_i;
    boolean_t                              thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    /* Sanity check - should never happen */
    if (db_p->p_phys_mem == NULL) {
        SX_LOG(SX_LOG_ERROR, "Internal error - Physical memory pointer NULL!\n");
        goto out;
    }

    utils_err = __block_handle_get(db_p, handle, &block_struct_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        goto out;
    }

    if (0 != cl_qlist_count(&block_struct_p->relocate_cntx_list)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager delete block error - Async Relocation is in progress.\n");
        utils_err = SX_UTILS_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    if (block_struct_p->block_type == LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E) {
        if (block_struct_p->size != 0) {
            /*get block logical_id*/
            list_item_p = cl_qlist_remove_head(&block_struct_p->ba_logical_id_list);
            if (list_item_p == cl_qlist_end(&block_struct_p->ba_logical_id_list)) {
                SX_LOG(SX_LOG_ERROR, "Internal error, Failed to remove logical_id struct from block\n");
                utils_err = SX_UTILS_STATUS_ERROR;
                goto out;
            }
            logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);


            if (db_p->async_enabled == TRUE) {
                /* Lock BA */
                utils_err = ba_thread_lock(db_p->bin_allocator);
                if (SX_UTILS_CHECK_FAIL(utils_err)) {
                    SX_LOG(SX_LOG_ERROR, "Error at bin allocator thread lock.\n");
                    goto out;
                }
            }
            /*call bin allocator delete blocks*/
            utils_err = ba_free(db_p->bin_allocator, logical_id_struct_p->logical_id);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG(SX_LOG_ERROR, "Failed to delete block from bin allocator.\n");
                utils_err = SX_UTILS_STATUS_ERROR;
                if (db_p->async_enabled == TRUE) {
                    /* Un Lock BA */
                    if (SX_UTILS_CHECK_FAIL(ba_thread_lock(db_p->bin_allocator))) {
                        SX_LOG(SX_LOG_ERROR, "Error at bin allocator thread unlock.\n");
                    }
                }
                goto out;
            }

            if (db_p->async_enabled == TRUE) {
                /* Un Lock BA */
                if (SX_UTILS_CHECK_FAIL(ba_thread_unlock(db_p->bin_allocator))) {
                    SX_LOG(SX_LOG_ERROR, "Error at bin allocator thread unlock.\n");
                    goto out;
                }
            }

            /*return logical_id to pool*/
            cl_qpool_put(&db_p->p_phys_mem->ba_logical_id_pool,
                         &logical_id_struct_p->pool_item);
        }
        /*return block to pool*/
        cl_qmap_remove_item(&db_p->handle_to_block_map,
                            &block_struct_p->map_item);
        if (FALSE == reuse_handle) {
            cl_err = id_allocator_put(&(db_p->p_phys_mem->block_info_id_allocator), block_struct_p->handle);
            if (cl_err != CL_SUCCESS) {
                SX_LOG_ERR("Failed to delete physical memory index %d, err = [%s]\n",
                           block_struct_p->handle, CL_STATUS_MSG(cl_err));
                utils_err = SX_UTILS_STATUS_ERROR;
                goto out;
            }
        }
        cl_qpool_put(&db_p->p_phys_mem->block_info_pool,
                     &block_struct_p->pool_item);
    } else { /*linked list*/
             /*call bin allocator to get size times block of size one*/
        for (block_length_i = 0; block_length_i < block_struct_p->size; ++block_length_i) {
            /*get block logical_id*/
            list_item_p = cl_qlist_remove_head(&block_struct_p->ba_logical_id_list);
            if (list_item_p == cl_qlist_end(&block_struct_p->ba_logical_id_list)) {
                SX_LOG(SX_LOG_ERROR, "Internal error, Failed to remove logical_id struct from block\n");
                utils_err = SX_UTILS_STATUS_ERROR;
                goto out;
            }
            logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);

            /*call bin allocator delete blocks*/
            utils_err = ba_free(db_p->bin_allocator, logical_id_struct_p->logical_id);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG(SX_LOG_ERROR, "Failed to delete block from bin allocator.\n");
                utils_err = SX_UTILS_STATUS_ERROR;
                goto out;
            }

            /*return logical_id to pool*/
            cl_qpool_put(&db_p->p_phys_mem->ba_logical_id_pool,
                         &logical_id_struct_p->pool_item);
        }
        /*return block to pool*/
        cl_qmap_remove_item(&db_p->handle_to_block_map,
                            &block_struct_p->map_item);
        if (FALSE == reuse_handle) {
            cl_err = id_allocator_put(&(db_p->p_phys_mem->block_info_id_allocator), block_struct_p->handle);
            if (cl_err != CL_SUCCESS) {
                SX_LOG_ERR("Failed to delete physical memory index %d, err = [%s]\n",
                           block_struct_p->handle, CL_STATUS_MSG(cl_err));
                utils_err = SX_UTILS_STATUS_ERROR;
                goto out;
            }
        }
        cl_qpool_put(&db_p->p_phys_mem->block_info_pool,
                     &block_struct_p->pool_item);
    }

out:
    LINEAR_MANAGER_THREAD_UNLOCK();

    SX_LOG_EXIT();
    return utils_err;
}

sx_utils_status_t linear_manager_block_size_get(linear_manager_db_t            database,
                                                linear_manager_handle_t        handle,
                                                linear_manager_block_length_t *size_p)
{
    __linear_manager_db_t       *db_p = (__linear_manager_db_t*)database;
    sx_utils_status_t            utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t            utils_err_out = SX_UTILS_STATUS_SUCCESS;
    linear_manager_block_info_t *p_block_info = NULL;
    boolean_t                    thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    utils_err = __block_handle_get(db_p, handle, &p_block_info);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        goto out;
    }

    if (NULL == size_p) {
        SX_LOG(SX_LOG_ERROR, "NULL param size\n");
        utils_err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    *size_p = p_block_info->size;

out:
    LINEAR_MANAGER_THREAD_UNLOCK();

    SX_LOG_EXIT();
    return utils_err;
}

sx_utils_status_t __linear_manager_thread_lock_init(linear_manager_db_t database)
{
    __linear_manager_db_t *db_p = (__linear_manager_db_t*)database;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cl_spinlock_init(&(db_p->thread_lock)) != CL_SUCCESS) {
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    SX_LOG_EXIT();
out:
    return utils_err;
}


sx_utils_status_t __linear_manager_thread_lock_deinit(linear_manager_db_t database)
{
    __linear_manager_db_t *db_p = (__linear_manager_db_t*)database;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();


    cl_spinlock_destroy(&(db_p->thread_lock));
    SX_LOG_EXIT();

    return utils_err;
}

sx_utils_status_t __linear_manager_thread_lock(linear_manager_db_t database)
{
    __linear_manager_db_t *db_p = (__linear_manager_db_t*)database;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    cl_spinlock_acquire(&(db_p->thread_lock));

    SX_LOG_EXIT();
out:
    return utils_err;
}

sx_utils_status_t __linear_manager_thread_unlock(linear_manager_db_t database)
{
    __linear_manager_db_t *db_p = (__linear_manager_db_t*)database;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    cl_spinlock_release(&(db_p->thread_lock));

    SX_LOG_EXIT();
out:
    return utils_err;
}

sx_utils_status_t linear_manager_handle_lock(linear_manager_db_t            database,
                                             linear_manager_handle_t        handle,
                                             linear_manager_index_t       * index_p,
                                             linear_manager_block_length_t *size_p)
{
    __linear_manager_db_t                 *db_p = (__linear_manager_db_t*)database;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_out = SX_UTILS_STATUS_SUCCESS;
    linear_manager_block_info_t           *block_struct_p = NULL;
    cl_list_item_t                        *list_item_p;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    linear_manager_block_length_t          block_length_i = 0;
    linear_manager_block_length_t          index_i;
    boolean_t                              thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    utils_err = __block_handle_get(db_p, handle, &block_struct_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        goto out;
    }

    if (NULL == index_p) {
        SX_LOG(SX_LOG_ERROR, "NULL param phy_id_p\n");
        utils_err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (NULL == size_p) {
        SX_LOG(SX_LOG_ERROR, "NULL param size_p\n");
        utils_err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    /*in case the block size is 0, lock/release not performed*/
    if (0 == block_struct_p->size) {
        *size_p = 0;
        utils_err = SX_UTILS_STATUS_SUCCESS;
        goto out;
    }

    /*get phy ids for block*/
    if (block_struct_p->block_type == LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E) {
        if (*size_p < block_struct_p->size) {
            SX_LOG(SX_LOG_ERROR, "array given for logical_id return is too small\n");
            utils_err = SX_UTILS_STATUS_PARAM_ERROR;
            goto out;
        }

        list_item_p = cl_qlist_head(&block_struct_p->ba_logical_id_list);
        if (list_item_p == cl_qlist_end(&block_struct_p->ba_logical_id_list)) {
            SX_LOG(SX_LOG_ERROR, "Internal error, Failed to get logical_id in block\n");
            utils_err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);

        /*call bin allocator to get phy ids*/
        utils_err = ba_lock(db_p->bin_allocator, logical_id_struct_p->logical_id, &index_p[0], NULL);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator failed to lock block.\n");
            goto out;
        }

        /*fill array of indexes with increment of index*/
        for (index_i = 1; index_i < block_struct_p->size; ++index_i) {
            index_p[index_i] = index_p[index_i - 1] + 1;
        }

        *size_p = block_struct_p->size;
    } else { /*linked list*/
        if (*size_p < block_struct_p->size) {
            SX_LOG(SX_LOG_ERROR, "array given for logical_id return is too small\n");
            utils_err = SX_UTILS_STATUS_PARAM_ERROR;
            goto out;
        }
        if (block_struct_p->size != cl_qlist_count(&block_struct_p->ba_logical_id_list)) {
            SX_LOG(SX_LOG_ERROR,
                   "Internal error, missing indexes of linked list block. block_struct_p->size [%u], qlist_count [%u]\n",
                   block_struct_p->size,
                   cl_qlist_count(&block_struct_p->ba_logical_id_list));
            utils_err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        /*call bin allocator to get size times block of size one*/
        block_length_i = 0;
        for (list_item_p = cl_qlist_head((&block_struct_p->ba_logical_id_list));
             list_item_p != cl_qlist_end((&block_struct_p->ba_logical_id_list));
             list_item_p = cl_qlist_next(list_item_p)) {
            logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);

            /*call bin allocator to get phy ids*/
            utils_err = ba_lock(db_p->bin_allocator, logical_id_struct_p->logical_id, &index_p[block_length_i], NULL);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG(SX_LOG_ERROR, "Bin allocator failed to lock block.\n");
                goto out;
            }
            block_length_i = block_length_i + 1;
        }
        *size_p = block_struct_p->size;
    }

out:
    LINEAR_MANAGER_THREAD_UNLOCK();

    SX_LOG_EXIT();
    return utils_err;
}

sx_utils_status_t linear_manager_handle_release(linear_manager_db_t database, linear_manager_handle_t handle)
{
    __linear_manager_db_t                 *db_p = (__linear_manager_db_t*)database;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_out = SX_UTILS_STATUS_SUCCESS;
    linear_manager_block_info_t           *block_struct_p = NULL;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    cl_list_item_t                        *list_item_p;
    boolean_t                              thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    utils_err = __block_handle_get(db_p, handle, &block_struct_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        goto out;
    }

    /*in case the block size is 0, lock/release not performed*/
    if (0 == block_struct_p->size) {
        utils_err = SX_UTILS_STATUS_SUCCESS;
        goto out;
    }

    if (block_struct_p->block_type == LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E) {
        list_item_p = cl_qlist_head((&block_struct_p->ba_logical_id_list));
        logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
        utils_err = ba_unlock(db_p->bin_allocator, logical_id_struct_p->logical_id);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator failed to unlock block.\n");
            goto out;
        }
    } else { /*linked list*/
             /*call bin allocator to unlock all links*/
        for (list_item_p = cl_qlist_head((&block_struct_p->ba_logical_id_list));
             list_item_p != cl_qlist_end((&block_struct_p->ba_logical_id_list));
             list_item_p = cl_qlist_next(list_item_p)) {
            logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
            utils_err = ba_unlock(db_p->bin_allocator, logical_id_struct_p->logical_id);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG(SX_LOG_ERROR, "Bin allocator failed to unlock block.\n");
                goto out;
            }
        }
    }

out:
    LINEAR_MANAGER_THREAD_UNLOCK();

    SX_LOG_EXIT();
    return utils_err;
}


sx_utils_status_t linear_manager_link_add(linear_manager_db_t               database,
                                          linear_manager_handle_t           handle,
                                          linear_manager_allocation_types_t allocation_type,
                                          linear_manager_block_length_t     offset,
                                          linear_manager_index_t          * index_p)
{
    __linear_manager_db_t                 *db_p = (__linear_manager_db_t*)database;
    linear_manager_block_info_t           *block_struct_p = NULL;
    linear_manager_block_length_t          block_length_i;
    cl_pool_item_t                        *pool_item_p;
    cl_list_item_t                        *list_item_p;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    linear_manager_ba_logical_id_struct_t* old_first_logical_id_struct_p = NULL;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_out = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_on_fail = SX_UTILS_STATUS_SUCCESS;
    linear_manager_block_length_t          block_size;
    boolean_t                              thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    if (db_p->p_phys_mem == NULL) {
        SX_LOG(SX_LOG_ERROR, "Internal error - Physical memory pointer is NULL!\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    if (NULL == index_p) {
        SX_LOG(SX_LOG_ERROR, "index_p param NULL\n");
        utils_err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    utils_err = __block_handle_get(db_p, handle, &block_struct_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        goto out;
    }

    if (block_struct_p->block_type != LINEAR_MANAGER_LINK_LIST_BLOCK_TYPE_E) {
        SX_LOG(SX_LOG_ERROR, "cant add link to not link list type\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /*can add link only to block in range 0 to block size(last element)*/
    if (offset > block_struct_p->size) {
        SX_LOG(SX_LOG_ERROR, "offset param invalid\n");
        utils_err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }
    block_size = cl_qlist_count(&block_struct_p->ba_logical_id_list);
    CL_ASSERT(block_struct_p->size == block_size);

    /*get logical_id pool item*/
    pool_item_p = cl_qpool_get(&db_p->p_phys_mem->ba_logical_id_pool);
    if (NULL == pool_item_p) {
        SX_LOG(SX_LOG_ERROR, "Cannot get logical_id struct for block.\n");
        utils_err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }
    logical_id_struct_p = PARENT_STRUCT(pool_item_p, linear_manager_ba_logical_id_struct_t, pool_item);

    /*call bin allocator to get one block*/
    utils_err = ba_allocate(db_p->bin_allocator, allocation_type, 1, handle, &logical_id_struct_p->logical_id);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Bin allocator block allocation failed.\n");
        goto err_out_after_bin_alloc;
    }

    /*inset logical_id item to list*/
    /*in case insert to end of linked list*/
    if (offset == block_struct_p->size) {
        cl_qlist_insert_tail(&block_struct_p->ba_logical_id_list, &logical_id_struct_p->list_item);
    }
    /*in case insert inside list*/
    else {
        block_length_i = 0;
        for (list_item_p = cl_qlist_head((&block_struct_p->ba_logical_id_list));
             list_item_p != cl_qlist_end((&block_struct_p->ba_logical_id_list));
             list_item_p = cl_qlist_next(list_item_p)) {
            if (block_length_i == offset) {
                cl_qlist_insert_prev(&block_struct_p->ba_logical_id_list, list_item_p,
                                     &logical_id_struct_p->list_item);
                if (offset == 0) {
                    old_first_logical_id_struct_p = PARENT_STRUCT(list_item_p,
                                                                  linear_manager_ba_logical_id_struct_t,
                                                                  list_item);
                    utils_err = ba_swap_metadata(db_p->bin_allocator,
                                                 logical_id_struct_p->logical_id,
                                                 old_first_logical_id_struct_p->logical_id);
                    if (SX_UTILS_CHECK_FAIL(utils_err)) {
                        SX_LOG(SX_LOG_ERROR, "Bin allocator failed swap meta data on blocks.\n");
                        goto err_out_after_swap_meta;
                    }
                }
                break;
            }
            block_length_i = block_length_i + 1;
        }
    }
    /*update block size*/
    block_struct_p->size = block_struct_p->size + 1;
    block_size = cl_qlist_count(&block_struct_p->ba_logical_id_list);
    CL_ASSERT(block_struct_p->size == block_size);

    /*call bin allocator to get phy ids*/
    utils_err = ba_lock(db_p->bin_allocator, logical_id_struct_p->logical_id, index_p, NULL);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Bin allocator failed to lock link.\n");
        goto err_out_after_block_lock;
    }

    goto out;

err_out_after_block_lock:
    block_struct_p->size = block_struct_p->size - 1;
    if ((offset == 0) && (block_struct_p->size != 0)) {
        utils_err_on_fail = ba_swap_metadata(db_p->bin_allocator,
                                             logical_id_struct_p->logical_id,
                                             old_first_logical_id_struct_p->logical_id);
        if (SX_UTILS_CHECK_FAIL(utils_err_on_fail)) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator failed swap meta data on blocks in rollback.\n");
        }
    }
err_out_after_swap_meta:
    cl_qlist_remove_item(&block_struct_p->ba_logical_id_list, &logical_id_struct_p->list_item);
    utils_err_on_fail = ba_free(db_p->bin_allocator, logical_id_struct_p->logical_id);
    if (SX_UTILS_CHECK_FAIL(utils_err_on_fail)) {
        SX_LOG(SX_LOG_ERROR, "Failed to delete block from bin allocator in rollback.\n");
    }
err_out_after_bin_alloc:
    cl_qpool_put(&db_p->p_phys_mem->ba_logical_id_pool,
                 &logical_id_struct_p->pool_item);
out:
    LINEAR_MANAGER_THREAD_UNLOCK();

    SX_LOG_EXIT();
    return utils_err;
}

sx_utils_status_t linear_manager_link_delete(linear_manager_db_t           database,
                                             linear_manager_handle_t       handle,
                                             linear_manager_block_length_t offset)
{
    __linear_manager_db_t                 *db_p = (__linear_manager_db_t*)database;
    linear_manager_block_info_t           *block_struct_p = NULL;
    linear_manager_block_length_t          block_length_i = 0;
    cl_list_item_t                        *list_item_p;
    cl_list_item_t                        *list_item_new_head_p;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    linear_manager_ba_logical_id_struct_t* new_first_logical_id_struct_p = NULL;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_out = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_err_flow = SX_UTILS_STATUS_SUCCESS;
    linear_manager_block_length_t          block_size;
    linear_manager_index_t                 index;
    boolean_t                              thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    utils_err = __block_handle_get(db_p, handle, &block_struct_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        goto out;
    }

    if (block_struct_p->block_type != LINEAR_MANAGER_LINK_LIST_BLOCK_TYPE_E) {
        SX_LOG(SX_LOG_ERROR, "cant delete link from none link list type\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    if (block_struct_p->size == 0) {
        SX_LOG(SX_LOG_ERROR, "can't delete link from block of size 0.\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }
    /*can remove link only to block in range 0 to block size-1*/
    if (offset > (block_struct_p->size - 1)) {
        SX_LOG(SX_LOG_ERROR, "offset param invalid\n");
        utils_err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }
    block_size = cl_qlist_count(&block_struct_p->ba_logical_id_list);
    CL_ASSERT(block_struct_p->size == block_size);

    /*remove item in offset*/
    block_length_i = 0;
    for (list_item_p = cl_qlist_head((&block_struct_p->ba_logical_id_list));
         list_item_p != cl_qlist_end((&block_struct_p->ba_logical_id_list));
         list_item_p = cl_qlist_next(list_item_p)) {
        if (block_length_i == offset) {
            logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
            /*if offset is 0 swap meta data*/
            if ((offset == 0) && (block_struct_p->size != 1)) {
                list_item_new_head_p = cl_qlist_next(list_item_p);
                new_first_logical_id_struct_p = PARENT_STRUCT(list_item_new_head_p,
                                                              linear_manager_ba_logical_id_struct_t,
                                                              list_item);
                utils_err = ba_swap_metadata(db_p->bin_allocator,
                                             logical_id_struct_p->logical_id,
                                             new_first_logical_id_struct_p->logical_id);
                if (SX_UTILS_CHECK_FAIL(utils_err)) {
                    SX_LOG(SX_LOG_ERROR, "Bin allocator failed swap meta data on blocks.\n");
                    goto out;
                }
            }

            utils_err = ba_unlock(db_p->bin_allocator, logical_id_struct_p->logical_id);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG(SX_LOG_ERROR, "Bin allocator failed to unlock block.\n");
                goto err_out_after_block_unlock;
            }
            /*call bin allocator delete blocks*/
            utils_err = ba_free(db_p->bin_allocator, logical_id_struct_p->logical_id);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG(SX_LOG_ERROR, "Failed to delete block from bin allocator.\n");
                goto err_out_after_bin_free;
            }
            /*remove logical id item from list*/
            cl_qlist_remove_item(&block_struct_p->ba_logical_id_list, list_item_p);
            /*return logical id to pool*/
            cl_qpool_put(&db_p->p_phys_mem->ba_logical_id_pool,
                         &logical_id_struct_p->pool_item);
            break;
        }

        block_length_i = block_length_i + 1;
    }

    /*update block size*/
    block_struct_p->size = block_struct_p->size - 1;
    block_size = cl_qlist_count(&block_struct_p->ba_logical_id_list);
    CL_ASSERT(block_struct_p->size == block_size);

    goto out;

err_out_after_bin_free:
    utils_err_err_flow = ba_lock(db_p->bin_allocator, logical_id_struct_p->logical_id, &index, NULL);
    if (SX_UTILS_CHECK_FAIL(utils_err_err_flow)) {
        SX_LOG(SX_LOG_ERROR, "Bin allocator failed to unlock block in rollback.\n");
    }

err_out_after_block_unlock:
    if ((offset == 0) && (block_struct_p->size != 1)) {
        utils_err_err_flow = ba_swap_metadata(db_p->bin_allocator,
                                              logical_id_struct_p->logical_id,
                                              new_first_logical_id_struct_p->logical_id);
        if (SX_UTILS_CHECK_FAIL(utils_err_err_flow)) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator failed swap meta data on blocks in rollback.\n");
        }
    }

out:
    LINEAR_MANAGER_THREAD_UNLOCK();
    SX_LOG_EXIT();
    return utils_err;
}


sx_utils_status_t linear_manager_ref_add(linear_manager_db_t database, linear_manager_handle_t handle)
{
    __linear_manager_db_t                 *db_p = (__linear_manager_db_t*)database;
    linear_manager_block_info_t           *block_struct_p = NULL;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_out = SX_UTILS_STATUS_SUCCESS;
    cl_list_item_t                        *list_item_p;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    boolean_t                              thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    utils_err = __block_handle_get(db_p, handle, &block_struct_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        goto out;
    }

    if (block_struct_p->size == 0) {
        SX_LOG(SX_LOG_ERROR, "Cant add reference to block of size 0\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    list_item_p = cl_qlist_head(&block_struct_p->ba_logical_id_list);
    logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);

    /*add ref update bin allocator*/
    utils_err = ba_ref_inc(db_p->bin_allocator, logical_id_struct_p->logical_id);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Bin allocator failed update ref count.\n");
        goto out;
    }

out:
    LINEAR_MANAGER_THREAD_UNLOCK();
    SX_LOG_EXIT();
    return utils_err;
}

sx_utils_status_t linear_manager_ref_delete(linear_manager_db_t database, linear_manager_handle_t handle)
{
    __linear_manager_db_t                 *db_p = (__linear_manager_db_t*)database;
    linear_manager_block_info_t           *block_struct_p = NULL;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_out = SX_UTILS_STATUS_SUCCESS;
    cl_list_item_t                        *list_item_p;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    boolean_t                              thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    utils_err = __block_handle_get(db_p, handle, &block_struct_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        goto out;
    }

    if (block_struct_p->size == 0) {
        SX_LOG(SX_LOG_ERROR, "Cant delete reference to block of size 0\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    list_item_p = cl_qlist_head(&block_struct_p->ba_logical_id_list);
    logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);

    /*delete ref update bin allocator*/
    utils_err = ba_ref_dec(db_p->bin_allocator, logical_id_struct_p->logical_id);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Bin allocator failed update ref count.\n");
        goto out;
    }

out:
    LINEAR_MANAGER_THREAD_UNLOCK();

    SX_LOG_EXIT();
    return utils_err;
}

sx_utils_status_t linear_manager_ref_modify(linear_manager_db_t database, linear_manager_handle_t handle, int32_t val)
{
    __linear_manager_db_t                 *db_p = (__linear_manager_db_t*)database;
    linear_manager_block_info_t           *block_struct_p = NULL;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_out = SX_UTILS_STATUS_SUCCESS;
    cl_list_item_t                        *list_item_p;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    boolean_t                              thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    utils_err = __block_handle_get(db_p, handle, &block_struct_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        goto out;
    }

    if (block_struct_p->size == 0) {
        SX_LOG(SX_LOG_ERROR, "Can't get reference to block of size 0\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    list_item_p = cl_qlist_head(&block_struct_p->ba_logical_id_list);
    logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);

    /*modify ref update bin allocator*/
    utils_err = ba_ref_modify(db_p->bin_allocator, logical_id_struct_p->logical_id, val);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Bin allocator failed update ref count.\n");
        goto out;
    }

out:
    LINEAR_MANAGER_THREAD_UNLOCK();

    SX_LOG_EXIT();
    return utils_err;
}

sx_utils_status_t linear_manager_swap_handles(linear_manager_db_t     database,
                                              linear_manager_handle_t first_handle,
                                              linear_manager_handle_t second_handle)
{
    __linear_manager_db_t                 *db_p = (__linear_manager_db_t*)database;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_out = SX_UTILS_STATUS_SUCCESS;
    cl_list_item_t                        *list_item_p;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    ba_logical_id_t                        first_logical_id;
    ba_logical_id_t                        second_logical_id;
    linear_manager_block_length_t          first_size = 0;
    linear_manager_block_length_t          second_size = 0;
    uint32_t                               ref_cnt = 0;
    linear_manager_block_info_t           *p_first_block_info = NULL;
    linear_manager_block_info_t           *p_second_block_info = NULL;
    cl_qlist_t                             tmp_list;
    boolean_t                              thread_lock = FALSE;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __linear_manager_thread_lock(db_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager : thread lock failed, err = [%s]\n",
               SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }
    thread_lock = TRUE;

    utils_err = __block_handle_get(db_p, first_handle, &p_first_block_info);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", first_handle);
        goto out;
    }

    utils_err = __block_handle_get(db_p, second_handle, &p_second_block_info);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", second_handle);
        goto out;
    }

    if (first_handle == second_handle) {
        SX_LOG(SX_LOG_ERROR, "can't swap handle with itself\n");
        utils_err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }


    if (p_first_block_info->block_type != p_second_block_info->block_type) {
        SX_LOG(SX_LOG_ERROR, "Can't swap between block of different type\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    first_size = p_first_block_info->size;
    second_size = p_second_block_info->size;

    /* If one of the handles is a handle to a block of size 0, then this block
     * doesn't exist in the bin allocator. Therefore, if the other handle is referenced,
     * then its references will be lost as a result of the swap. Thus, we should
     * verify that the other handle isn't referenced in this case. */
    if ((second_size == 0) && (first_size > 0)) {
        for (list_item_p = cl_qlist_head((&p_first_block_info->ba_logical_id_list));
             list_item_p != cl_qlist_end((&p_first_block_info->ba_logical_id_list));
             list_item_p = cl_qlist_next(list_item_p)) {
            logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
            utils_err = ba_client_cntx_get(db_p->bin_allocator,
                                           logical_id_struct_p->logical_id, NULL, &ref_cnt);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG_ERR("Failed to get context from bin allocator for handle %u, LID %u, err = [%s]\n",
                           first_handle, logical_id_struct_p->logical_id, SX_UTILS_STATUS_MSG(utils_err));
                goto out;
            }

            if (ref_cnt > 1) {
                utils_err = SX_UTILS_STATUS_RESOURCE_IN_USE;
                SX_LOG_ERR("Can't swap referenced handle %u with handle %u of size 0\n",
                           first_handle, second_handle);
                goto out;
            }
        }
    }

    if ((first_size == 0) && (second_size > 0)) {
        for (list_item_p = cl_qlist_head((&p_second_block_info->ba_logical_id_list));
             list_item_p != cl_qlist_end((&p_second_block_info->ba_logical_id_list));
             list_item_p = cl_qlist_next(list_item_p)) {
            logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
            utils_err = ba_client_cntx_get(db_p->bin_allocator,
                                           logical_id_struct_p->logical_id, NULL, &ref_cnt);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG_ERR("Failed to get context from bin allocator for handle %u, LID %u, err = [%s]\n",
                           first_handle, logical_id_struct_p->logical_id, SX_UTILS_STATUS_MSG(utils_err));
                goto out;
            }

            if (ref_cnt > 1) {
                utils_err = SX_UTILS_STATUS_RESOURCE_IN_USE;
                SX_LOG_ERR("Can't swap referenced handle %u with handle %u of size 0\n",
                           second_handle, first_handle);
                goto out;
            }
        }
    }

    p_first_block_info->size = second_size;
    p_second_block_info->size = first_size;
    cl_qlist_init(&tmp_list);
    cl_qlist_insert_list_head(&tmp_list, &p_first_block_info->ba_logical_id_list);
    cl_qlist_insert_list_head(&p_first_block_info->ba_logical_id_list,
                              &p_second_block_info->ba_logical_id_list);
    cl_qlist_insert_list_head(&p_second_block_info->ba_logical_id_list,
                              &tmp_list);

    for (list_item_p = cl_qlist_head((&p_first_block_info->ba_logical_id_list));
         list_item_p != cl_qlist_end((&p_first_block_info->ba_logical_id_list));
         list_item_p = cl_qlist_next(list_item_p)) {
        logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
        utils_err = ba_client_cntx_set(db_p->bin_allocator, logical_id_struct_p->logical_id, first_handle);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator failed setting block cntx.\n");
            goto out;
        }
    }

    for (list_item_p = cl_qlist_head((&p_second_block_info->ba_logical_id_list));
         list_item_p != cl_qlist_end((&p_second_block_info->ba_logical_id_list));
         list_item_p = cl_qlist_next(list_item_p)) {
        logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
        utils_err = ba_client_cntx_set(db_p->bin_allocator, logical_id_struct_p->logical_id, second_handle);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator failed setting block cntx.\n");
            goto out;
        }
    }

    list_item_p = cl_qlist_head(&p_first_block_info->ba_logical_id_list);
    logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
    first_logical_id = logical_id_struct_p->logical_id;

    list_item_p = cl_qlist_head(&p_second_block_info->ba_logical_id_list);
    logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
    second_logical_id = logical_id_struct_p->logical_id;

    if ((first_size > 0) && (second_size > 0)) {
        utils_err = ba_swap_metadata(db_p->bin_allocator, first_logical_id, second_logical_id);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator failed swapping metadata of blocks.\n");
            goto out;
        }
    }

out:
    LINEAR_MANAGER_THREAD_UNLOCK();

    SX_LOG_EXIT();
    return utils_err;
}

static sx_utils_status_t __linear_manager_async_relocate(ba_handle_t     ba_handle,
                                                         ba_logical_id_t lid,
                                                         uint32_t        cntx,
                                                         ba_index_t      old_id,
                                                         ba_index_t      new_id,
                                                         void          * relocate_cntx)
{
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;

    if (relocate_cntx != NULL) {
        /* call the async relocate cb*/
        if (linear_manager_async_params.relocate_async_cb == NULL) {
            SX_LOG(SX_LOG_ERROR, "Error Linear manager relocate async cb is NULL\n");
            goto out;
        }

        utils_err = linear_manager_async_params.relocate_async_cb(ba_handle, lid, cntx, old_id, new_id, relocate_cntx);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "Linear manager default flow relocation error\n");
            goto out;
        }
    } else {
        /* Default client */
        utils_err = __linear_manager_relocate(ba_handle, lid, cntx, old_id, new_id, relocate_cntx);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "Linear manager default flow relocation error\n");
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return utils_err;
}

static sx_utils_status_t __linear_manager_relocate(ba_handle_t     ba_handle,
                                                   ba_logical_id_t lid,
                                                   uint32_t        cntx,
                                                   ba_index_t      old_id,
                                                   ba_index_t      new_id,
                                                   void          * relocate_cntx)
{
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err_on_fail = SX_UTILS_STATUS_SUCCESS;
    linear_manager_block_info_t           *block_struct_p = NULL;
    linear_manager_block_length_t          offset = 0;
    linear_manager_ba_logical_id_struct_t *logical_id_struct_p;
    linear_manager_handle_t                handle;
    cl_list_item_t                        *list_item_p;
    cl_list_item_t                        *unlock_till_list_item_p;
    __linear_manager_db_t                 *db_p = NULL;
    linear_manager_index_t               * old_index_p = NULL;
    linear_manager_block_length_t          block_length_i;
    uint8_t                                user_i;

    SX_LOG_ENTER();

    /*find the relevant instance of linear manager*/
    for (user_i = 0; user_i < LINEAR_MANAGER_MAX_CLIENTS; ++user_i) {
        if (linear_manager_db_array[user_i].is_initialized == TRUE) {
            if (linear_manager_db_array[user_i].bin_allocator == ba_handle) {
                db_p = &linear_manager_db_array[user_i];
                break;
            }
        }
    }

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "Linear manager relocation callback Bin Allocator handle invalid\n");
        utils_err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    handle = (linear_manager_handle_t)cntx;
    utils_err = __block_handle_get(db_p, handle, &block_struct_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        goto out;
    }

    if (block_struct_p->block_type == LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E) {
        /*allocate memory for link list phy ids array*/
        M_GEN_UTILS_CLR_MEM_GET(&(old_index_p),
                                block_struct_p->size,
                                sizeof(linear_manager_index_t),
                                GEN_UTILS_MEM_TYPE_ID_LINEAR_MANAGER_E,
                                "Linear manager\n",
                                utils_err);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "Failed allocate space for phy id array in linear manager , "
                   "error: %s\n", SX_UTILS_STATUS_MSG(utils_err));
            goto out;
        }

        /*fill the index arr with incremental indexes*/
        old_index_p[0] = old_id;
        for (block_length_i = 1; block_length_i < block_struct_p->size; ++block_length_i) {
            old_index_p[block_length_i] = old_index_p[block_length_i - 1] + 1;
        }

        /* Push relocate context to the queue. user should call linear manager notify complete orderly */
        if (relocate_cntx != NULL) {
            /* Async GC. Linear manager's user should call linear_manager_notify_relocate_complete to delete the object */
            utils_err = __relocation_context_handle_push((linear_manager_db_t)db_p, handle, relocate_cntx);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG(SX_LOG_ERROR,
                       "relocation of block failed , Failed to push relocation context handle error: %s\n",
                       SX_UTILS_STATUS_MSG(utils_err));
                goto out;
            }
        }

        /* When performing block relocate each user of linear manager should get TID From Linear Manager Async and push orderly to dedicated relocate queue */
        utils_err = db_p->block_relocate(handle, block_struct_p->size, 0,
                                         block_struct_p->context,
                                         old_index_p, new_id);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "relocation of block failed , error: %s\n", SX_UTILS_STATUS_MSG(utils_err));
            goto out;
        }
    } else { /*link list*/
             /*allocate memory for link list phy ids array*/
        M_GEN_UTILS_CLR_MEM_GET(&(old_index_p),
                                block_struct_p->size,
                                sizeof(linear_manager_index_t),
                                GEN_UTILS_MEM_TYPE_ID_LINEAR_MANAGER_E,
                                "Linear manager\n",
                                utils_err);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "Failed allocate space for phy id array in linear manager , "
                   "error: %s\n", SX_UTILS_STATUS_MSG(utils_err));
            goto out;
        }

        block_length_i = 0;
        /*lock all links in link list except from the one that is relocated*/
        for (list_item_p = cl_qlist_head((&block_struct_p->ba_logical_id_list));
             list_item_p != cl_qlist_end((&block_struct_p->ba_logical_id_list));
             list_item_p = cl_qlist_next(list_item_p)) {
            logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);

            if (logical_id_struct_p->logical_id == lid) {
                old_index_p[block_length_i] = old_id;
                offset = block_length_i;
            } else {
                /*call bin allocator to get phy ids*/
                utils_err =
                    ba_lock(db_p->bin_allocator, logical_id_struct_p->logical_id, &old_index_p[block_length_i], NULL);
                if (SX_UTILS_CHECK_FAIL(utils_err)) {
                    SX_LOG(SX_LOG_ERROR, "Bin allocator failed to lock block.\n");
                    goto err_out_after_link_lock;
                }
            }
            block_length_i = block_length_i + 1;
        }

        /* Push relocate context to the queue. user should call linear manager notify complete orderly */
        if (relocate_cntx != NULL) {
            /* Async GC. Linear manager's user should call linear_manager_notify_relocate_complete to delete the object */
            utils_err = __relocation_context_handle_push((linear_manager_db_t)db_p, handle, relocate_cntx);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG(SX_LOG_ERROR,
                       "relocation of block failed , Failed to push relocation context handle error: %s\n",
                       SX_UTILS_STATUS_MSG(utils_err));
                goto out;
            }
        }


        /* When performing block relocate each user of linear manager should get TID From Linear Manager Async and push orderly to dedicated relocate queue */
        utils_err = db_p->block_relocate(handle, block_struct_p->size, offset,
                                         block_struct_p->context,
                                         old_index_p, new_id);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG(SX_LOG_ERROR, "relocation of block failed , error: %s\n", SX_UTILS_STATUS_MSG(utils_err));
            goto err_out_after_link_lock;
        }

        /*unlock all links except the one that is relocated*/
        for (list_item_p = cl_qlist_head((&block_struct_p->ba_logical_id_list));
             list_item_p != cl_qlist_end((&block_struct_p->ba_logical_id_list));
             list_item_p = cl_qlist_next(list_item_p)) {
            logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
            if (logical_id_struct_p->logical_id != lid) {
                utils_err = ba_unlock(db_p->bin_allocator, logical_id_struct_p->logical_id);
                if (SX_UTILS_CHECK_FAIL(utils_err)) {
                    SX_LOG(SX_LOG_ERROR, "Bin allocator failed to unlock block.\n");
                    goto out;
                }
            }
        }
    }

    goto out;

err_out_after_link_lock:
    unlock_till_list_item_p = list_item_p;
    for (list_item_p = cl_qlist_head((&block_struct_p->ba_logical_id_list));
         list_item_p != unlock_till_list_item_p;
         list_item_p = cl_qlist_next(list_item_p)) {
        logical_id_struct_p = PARENT_STRUCT(list_item_p, linear_manager_ba_logical_id_struct_t, list_item);
        if (logical_id_struct_p->logical_id != lid) {
            utils_err_on_fail = ba_unlock(db_p->bin_allocator, logical_id_struct_p->logical_id);
            if (SX_UTILS_CHECK_FAIL(utils_err_on_fail)) {
                SX_LOG(SX_LOG_ERROR, "Bin allocator failed to unlock block in rollback.\n");
            }
        }
    }

out:

    if (old_index_p) {
        M_GEN_UTILS_MEM_PUT(old_index_p, GEN_UTILS_MEM_TYPE_ID_LINEAR_MANAGER_E,
                            "Linear manager\n", utils_err_on_fail);
        if (SX_UTILS_CHECK_FAIL(utils_err_on_fail)) {
            SX_LOG(SX_LOG_ERROR, "Failed free  old_index_p, "
                   "error: %s\n", SX_UTILS_STATUS_MSG(utils_err_on_fail));
        }
    }

    SX_LOG_EXIT();
    return utils_err;
}


static sx_utils_status_t __block_type_param_check(linear_manager_block_type_e block_type)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();
    if (!((block_type >= LINEAR_MANAGER_BLOCK_TYPE_MIN_E) &&
          (block_type <= LINEAR_MANAGER_BLOCK_TYPE_MAX_E))) {
        SX_LOG(SX_LOG_ERROR, "Block type param invalid\n");
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

/**
 * Pop the relocation context from handle queue
 *
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to the block
 */
sx_utils_status_t __relocation_context_handle_pop(linear_manager_db_t     database,
                                                  linear_manager_handle_t handle,
                                                  void                  **pp_relocate_cntx)
{
    sx_utils_status_t                         utils_err = SX_UTILS_STATUS_SUCCESS;
    cl_map_item_t                            *p_item = NULL;
    cl_list_item_t                           *list_item_p;
    linear_manager_block_info_t              *linear_manager_block_info_p = NULL;
    __linear_manager_db_t                    *db_p = (__linear_manager_db_t*)database;
    linear_manager_relocate_cntx_list_item_t *linear_manager_relocate_cntx_list_item_p = NULL;

    p_item = cl_qmap_get(&db_p->handle_to_block_map, handle);
    if (p_item == cl_qmap_end(&db_p->handle_to_block_map)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        utils_err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    linear_manager_block_info_p = PARENT_STRUCT(p_item, linear_manager_block_info_t, map_item);

    /*get block logical_id*/
    list_item_p = cl_qlist_remove_head(&linear_manager_block_info_p->relocate_cntx_list);
    if (list_item_p == cl_qlist_end(&linear_manager_block_info_p->relocate_cntx_list)) {
        SX_LOG(SX_LOG_ERROR, "Internal error, Failed to remove item from relocate cntx list\n");
        utils_err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    linear_manager_relocate_cntx_list_item_p = PARENT_STRUCT(list_item_p,
                                                             linear_manager_relocate_cntx_list_item_t,
                                                             list_item);

    *pp_relocate_cntx = linear_manager_relocate_cntx_list_item_p->relocate_cntx;

    /*return logical id to pool*/
    cl_qpool_put(&db_p->p_phys_mem->relocate_cntx_pool,
                 &linear_manager_relocate_cntx_list_item_p->pool_item);

    /* If List is empty remove list and remove handle from map */
out:
    return utils_err;
}

/**
 * Push relocation context to queue
 *
 *
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to the block
 */
sx_utils_status_t __relocation_context_handle_push(linear_manager_db_t     database,
                                                   linear_manager_handle_t handle,
                                                   void                   *p_relocate_cntx)
{
    sx_utils_status_t                         utils_err = SX_UTILS_STATUS_SUCCESS;
    cl_map_item_t                            *p_item = NULL;
    cl_pool_item_t                           *pool_item_p;
    linear_manager_block_info_t              *linear_manager_block_info_p = NULL;
    __linear_manager_db_t                    *db_p = (__linear_manager_db_t*)database;
    linear_manager_relocate_cntx_list_item_t *linear_manager_relocate_cntx_list_item_p = NULL;

    p_item = cl_qmap_get(&db_p->handle_to_block_map, handle);
    if (p_item == cl_qmap_end(&db_p->handle_to_block_map)) {
        SX_LOG(SX_LOG_ERROR, "Handle %u not found\n", handle);
        utils_err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    linear_manager_block_info_p = PARENT_STRUCT(p_item, linear_manager_block_info_t, map_item);

    /*get logical_id_struct_p pool item*/
    pool_item_p = cl_qpool_get(&db_p->p_phys_mem->relocate_cntx_pool);
    if (NULL == pool_item_p) {
        SX_LOG(SX_LOG_ERROR, "Cannot get relocate cntx struct for block.\n");
        utils_err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    linear_manager_relocate_cntx_list_item_p = PARENT_STRUCT(pool_item_p,
                                                             linear_manager_relocate_cntx_list_item_t,
                                                             pool_item);
    linear_manager_relocate_cntx_list_item_p->relocate_cntx = p_relocate_cntx;

    /*inset relocate cntx item to list*/
    cl_qlist_insert_tail(&linear_manager_block_info_p->relocate_cntx_list,
                         &linear_manager_relocate_cntx_list_item_p->list_item);

out:
    return utils_err;
}

/**
 * Notify a relocation complete
 *
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to the block
 */
sx_utils_status_t linear_manager_notify_relocate_complete(linear_manager_db_t database, linear_manager_handle_t handle)
{
    __linear_manager_db_t *db_p = (__linear_manager_db_t*)database;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;
    void                  *ba_relocate_context_p = NULL;

    SX_LOG_ENTER();

    if (db_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        utils_err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    utils_err = __relocation_context_handle_pop(database,
                                                handle,
                                                (void*)&ba_relocate_context_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Linear manager failed to get relocate context.\n");
        goto out;
    }

    utils_err = ba_free_async(db_p->bin_allocator, ba_relocate_context_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Bin allocator failed free async.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return utils_err;
}


static sx_utils_status_t __block_handle_get(__linear_manager_db_t        *database,
                                            linear_manager_handle_t       handle,
                                            linear_manager_block_info_t **pp_block_info)
{
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    cl_map_item_t    *p_item = NULL;

    p_item = cl_qmap_get(&database->handle_to_block_map, handle);
    if (p_item == cl_qmap_end(&database->handle_to_block_map)) {
        utils_err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    *pp_block_info = PARENT_STRUCT(p_item, linear_manager_block_info_t, map_item);

out:
    return utils_err;
}

static sx_utils_status_t __init_param_check(linear_manager_params_t *param_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();
    if (param_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "init param is NULL\n");
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (param_p->relocate_cb == NULL) {
        SX_LOG(SX_LOG_ERROR, "relocate_cb param is NULL\n");
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (param_p->alloc_group_cb == NULL) {
        SX_LOG(SX_LOG_ERROR, "alloc_group_cb param is NULL\n");
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (param_p->free_group_cb == NULL) {
        SX_LOG(SX_LOG_ERROR, "free_group_cb param is NULL\n");
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t linear_manager_relocation_info_output(const char *relocation_info_str, ...)
{
    return ba_relocation_info_output(relocation_info_str);
}
