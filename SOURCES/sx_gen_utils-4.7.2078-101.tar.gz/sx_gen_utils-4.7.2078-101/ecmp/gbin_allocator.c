/*
 * Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "gbin_internal.h"
#include <sx/utils/debug_cmd.h>
#include <complib/cl_dbg.h>

#undef  __MODULE__
#define __MODULE__ GBIN_ALLOCATOR

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t         init_done_s = FALSE;
static boolean_t         no_changes_s = TRUE;
static boolean_t         gbin_trace_s = FALSE;
static bai_phys_memory_t phys_memory_s[BIN_ALLOC_MAX_PHYS_MEMORY];
static bai_user_t        users_s[BIN_ALLOC_MAX_USERS];
static uint32_t          log2tbl_s[] = {0xAAAAAAAA, 0xCCCCCCCC, 0xF0F0F0F0, 0xFF00FF00,
                                        0xFFFF0000};
static FILE            * relocation_info_output_stream_p = NULL;
static cl_spinlock_t     relocation_info_stream_lock = CL_SPINLOCK_INITIALIZER;
static cl_spinlock_t     relocation_handler_lock = CL_SPINLOCK_INITIALIZER;

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_utils_status_t __ba_gc_completion_cb(const void *context);
static sx_utils_status_t __ba_gc_post_completion_cb(const void *context, boolean_t is_last, uint32_t bg);
static void __debug_cmd_ba_relocation(FILE* stream, int argc, const char *argv[], void *handler_context);

#define LEN_LID_LABEL (11)

/**
 * Map a block to a LID
 *
 * @param[in] p_user - Pointer to user owning group
 * @param[in] p_group - Pointer to group
 * @param[in] index - Index in group that we need to find LID mapping
 * @param[out] label - Pointer to where to store info about LID mapping
 *
 * NOTE:
 *   - Size of out is LEN_LID_LABEL
 *   - Possible values:
 *        0123456789
 *       "##########" - LID number, right justified
 *       "    <NONE>" - No LID found
 *       "<NO BLOCK>" - index is not active in array_map[]
 *       "   <ERROR>" - Some other error
 */
static void __bai_lid_label(bai_user_t *p_user, bai_group_t *p_group, uint32_t index, char        *label)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   lid;

    err = bai_offset_to_lid(p_user, p_group, index, &lid);
    switch (err) {
    case SX_UTILS_STATUS_SUCCESS:
        snprintf(label, LEN_LID_LABEL, "%10u", lid);
        break;

    case SX_UTILS_STATUS_PARAM_NULL:
        snprintf(label, LEN_LID_LABEL, "   <ERROR>");
        break;

    case SX_UTILS_STATUS_PARAM_ERROR:
        snprintf(label, LEN_LID_LABEL, "<NO BLOCK>");
        break;

    case SX_UTILS_STATUS_ENTRY_NOT_FOUND:
        snprintf(label, LEN_LID_LABEL, "    <NONE>");
        break;

    default:
        snprintf(label, LEN_LID_LABEL, "   <ERROR>");
        break;
    }

    return;
}


/**
 * Output a dump
 *
 * @param[in] stream - File stream to output dump to
 *
 * @return SX_UTILS_STATUS_SUCCESS - successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal error
 */
#define LEN_UINT16_DEC (6)
sx_utils_status_t ba_dump(FILE *stream)
{
    sx_utils_status_t         err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t               *p_user;
    bai_group_t              *p_group;
    bai_hole_t               *p_hole;
    bai_bucket_t             *p_bucket;
    ba_template_t            *p_template;
    bai_logical_id_t          iLid;
    uint32_t                  i, j, k, l;
    uint32_t                  group_cnt, group_size, lids_map_cnt;
    uint32_t                  shift_type, mask_type, shift_group, mask_group, mask_line;
    uint32_t                  type, length, grp_idx, line_idx, ref, context;
    uint8_t                   r_thresh, act_thresh, r_count, act_count;
    uint16_t                  max_alloc_size, c_max_hole, c_max_size, c_efficiency;
    uint32_t                  free_lines, reloc_cnt, c_cost_sum;
    uint32_t                  offset, len;
    uint16_t                  size;
    uint32_t                  increment, alloc_cnt;
    uint32_t                  lids_in_use = 0;
    char                      str_options[5], align[10], str_type[10], str_label[LEN_LID_LABEL];
    char                      buffer[LEN_UINT16_DEC + 1];
    char                      index_str[(LEN_UINT16_DEC * BIN_ALLOC_MAX_ALLOC_SIZES) + 1];
    char                      phys_mem_name[BIN_ALLOC_MAX_PHYS_MEM_NAME];
    boolean_t                 do_header;
    cl_map_item_t            *p_item = NULL;
    bai_lid_info_t           *p_lid = NULL;
    const cl_map_item_t      *p_end = NULL;
    ba_logical_id_t           lid = 0;
    bai_phys_memory_t        *p_phys_mem = NULL;
    uint32_t                  phys_mem_size = 0;
    uint32_t                  phys_mem_idx = 0;
    dbg_utils_table_columns_t gbin_dump_clmns[] = {
        {"User ID",   8, PARAM_UINT32_E, &i},
        {"Opts",      5, PARAM_STRING_E, &str_options},
        {"Cnt",       4, PARAM_UINT32_E, &group_cnt},
        {"Size",      9, PARAM_UINT32_E, &group_size},
        {"Count",     5, PARAM_UINT32_E, &lids_map_cnt},
        {"PhMem",     5, PARAM_UINT32_E, &phys_mem_idx},
        {"s_type",    6, PARAM_UINT32_E, &shift_type},
        {"m_type",    9, PARAM_HEX_E,    &mask_type},
        {"s_grp",     5, PARAM_UINT32_E, &shift_group},
        {"m_grp",     9, PARAM_HEX_E,    &mask_group},
        {"m_line",    9, PARAM_HEX_E,    &mask_line},
        {NULL,        0, 0,              NULL}
    };
    dbg_utils_table_columns_t gbin_templates_clmns[] = {
        {"Type",      9, PARAM_UINT32_E, &type},
        {"Length",    9, PARAM_UINT32_E, &length},
        {"align",     9, PARAM_STRING_E, align},
        {NULL,        0, 0,              NULL},
    };
    dbg_utils_table_columns_t gbin_lids_clmns[] = {
        {"lid",       8, PARAM_UINT32_E, &lid},
        {"Type",      9, PARAM_UINT32_E, &type},
        {"Group",     5, PARAM_UINT32_E, &grp_idx},
        {"Offset",    9, PARAM_UINT32_E, &line_idx},
        {"context",   9, PARAM_UINT32_E, &context},
        {"ref",       9, PARAM_UINT32_E, &ref},
        {NULL,        0, 0,              NULL}
    };
    dbg_utils_table_columns_t gbin_groups_clmns[] = {
        {"Grp",       4, PARAM_UINT32_E, &j},
        {"Type",      9, PARAM_UINT32_E, &type},
        {"max_sz",    6, PARAM_UINT16_E, &max_alloc_size},
        {"Free",      9, PARAM_UINT32_E, &free_lines},
        {"r.ts",      4, PARAM_UINT8_E,  &r_thresh},
        {"a.th",      4, PARAM_UINT8_E,  &act_thresh},
        {"r.ct",      4, PARAM_UINT8_E,  &r_count},
        {"a.ct",      4, PARAM_UINT8_E,  &act_count},
        {"reloc_cnt", 9, PARAM_UINT32_E, &reloc_cnt},
        {"m_hole",    6, PARAM_UINT16_E, &c_max_hole},
        {"m_size",    6, PARAM_UINT16_E, &c_max_size},
        {"Eff",       4, PARAM_UINT16_E, &c_efficiency},
        {"cost",      9, PARAM_UINT32_E, &c_cost_sum},
        {NULL,        0, 0,              NULL}
    };
    dbg_utils_table_columns_t gbin_groups_holes_clmns[] = {
        {"Hole",      4, PARAM_UINT32_E, &k},
        {"offset",    9, PARAM_UINT32_E, &offset},
        {"length",    9, PARAM_UINT32_E, &len},
        {NULL,        0, 0,              NULL}
    };
    dbg_utils_table_columns_t gbin_groups_bucket_clmns[] = {
        {"Bucket",    6, PARAM_UINT32_E, &k},
        {"Size",      6, PARAM_UINT16_E, &size},
        {"Inc",       4, PARAM_UINT32_E, &increment},
        {"Count",     9, PARAM_UINT32_E, &alloc_cnt},
        {NULL,        0, 0,              NULL}
    };
    dbg_utils_table_columns_t gbin_groups_allocation_clmns[] = {
        {"Type",      5, PARAM_STRING_E, &str_type},
        {"Offset",    9, PARAM_UINT32_E, &offset},
        {"Length",    9, PARAM_UINT32_E, &len},
        {"LID",      10, PARAM_STRING_E, str_label},
        {NULL,        0, 0, NULL}
    };
    dbg_utils_table_columns_t gbin_phys_mem_clmns[] = {
        {"Index",     5, PARAM_UINT32_E, &i},
        {"Name",      24, PARAM_STRING_E, &phys_mem_name},
        {"Size",      10, PARAM_UINT32_E, &phys_mem_size},
        {"LIDs in use ",  10, PARAM_UINT32_E, &lids_in_use},
        {NULL,        0, 0, NULL}
    };

    M_GEN_UTILS_MEM_CLR_PTR(phys_mem_name, sizeof(phys_mem_name));

    if (!init_done_s) {
        SX_LOG_DBG("BA not initialized!\n");

        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    dbg_utils_pprinter_module_header_print(stream, "Bin Allocator module");
    dbg_utils_pprinter_general_header_print(stream, "Bin Allocator DB Dump");

    for (i = 0; i < BIN_ALLOC_MAX_USERS; i++) {
        p_user = &users_s[i];

        if (!p_user->allocated) {
            continue;
        }
        dbg_utils_pprinter_user_defined_header_print(stream, DBG_UTILS_LEVEL_USER_DEFINED_1_E,
                                                     "User %d:", i);

        str_options[0] = (p_user->options & RELOC_SYNC_E) ? 'S' : 's';
        str_options[1] = (p_user->options & RELOC_ASYNC_E) ? 'A' : 'a';
        str_options[2] = (p_user->options & RELOC_ASYNC_GC_E) ? 'G' : 'g';
        str_options[3] = (p_user->options & ENABLE_TRACE_E) ? 'T' : 't';
        str_options[4] = 0;

        group_cnt = p_user->group_cnt;
        group_size = p_user->group_size;
        lids_map_cnt = cl_qmap_count(&p_user->lids_map);
        shift_type = p_user->shift_type;
        mask_type = p_user->mask_type;
        shift_group = p_user->shift_group;
        mask_group = p_user->mask_group;
        mask_line = p_user->mask_line;
        if (p_user->p_phys_mem) {
            phys_mem_idx = p_user->p_phys_mem - phys_memory_s;
        } else {
            /* This is an invalid scenario, but dump should never fail */
            SX_LOG_ERR("No physical memory pointer for user %u!\n", i);
            phys_mem_idx = BIN_ALLOC_MAX_PHYS_MEMORY;
        }

        dbg_utils_pprinter_table_headline_print(stream, gbin_dump_clmns);
        dbg_utils_pprinter_table_data_line_print(stream, gbin_dump_clmns);


        dbg_utils_pprinter_table_headline_print(stream, gbin_templates_clmns);

        for (j = 0; j < p_user->template_count; j++) {
            p_template = &p_user->templates[j];
            dbg_utils_pprinter_user_defined_header_print(stream, DBG_UTILS_LEVEL_USER_DEFINED_2_E,
                                                         "Templates %d:", j);

            dbg_utils_pprinter_table_headline_print(stream, gbin_templates_clmns);
            switch (p_template->align) {
            case ALIGN_NONE_E:
                strncpy(align, "None", sizeof(align));
                break;

            case ALIGN_SIZE_E:
                strncpy(align, "Size", sizeof(align));
                break;

            case ALIGN_EVEN_E:
                strncpy(align, "Even", sizeof(align));
                break;

            default:
                strncpy(align, "????", sizeof(align));
                break;
            }

            type = p_template->type;
            length = p_template->length;

            dbg_utils_pprinter_table_data_line_print(stream, gbin_templates_clmns);

            index_str[0] = 0;
            for (k = 0; k < BIN_ALLOC_MAX_ALLOC_SIZES; k++) {
                if (p_template->alloc_sizes[k] == 0) {
                    break;
                }
                snprintf(buffer, sizeof(buffer), "%u ",
                         p_template->alloc_sizes[k]);

                strncat(index_str, buffer, sizeof(index_str) - 1);
            }

            dbg_utils_pprinter_field_print(stream, "Supported sizes:", index_str, PARAM_STRING_E);
        }

        do_header = TRUE;

        p_end = cl_qmap_end(&p_user->lids_map);
        p_item = cl_qmap_head(&p_user->lids_map);
        while (p_item != p_end) {
            p_lid = PARENT_STRUCT(p_item, bai_lid_info_t, map_item);
            iLid = p_lid->ilid;
            lid = p_lid->lid;

            err = bai_extract_i_lid(p_user, iLid, __func__, &type, &grp_idx,
                                    &line_idx);
            if (err) {
                goto out;
            }

            if (do_header) {
                dbg_utils_pprinter_secondary_header_print(stream, "Per-user LIDs table");
                dbg_utils_pprinter_table_headline_print(stream, gbin_lids_clmns);
                do_header = FALSE;
            }

            p_group = &p_user->groups[grp_idx];

            ref = p_group->lids[line_idx].ref;
            context = p_group->lids[line_idx].client_context;

            dbg_utils_pprinter_table_data_line_print(stream, gbin_lids_clmns);
            p_item = cl_qmap_next(p_item);
        }

        /* In case no groups are defined */
        if (!p_user->groups) {
            goto out;
        }

        for (j = 0; j < p_user->group_cnt; j++) {
            p_group = &p_user->groups[j];

            if (p_group->type == 0) {
                continue;
            }
            dbg_utils_pprinter_user_defined_header_print(stream, DBG_UTILS_LEVEL_USER_DEFINED_2_E,
                                                         "Group %d:", j);

            /* Reload caches for debug dump */
            err = bai_cache_update(p_group);
            if (err) {
                goto out;
            }

            dbg_utils_pprinter_table_headline_print(stream, gbin_groups_clmns);

            type = p_group->type;
            max_alloc_size = p_group->max_alloc_size;
            free_lines = p_group->free_lines;
            r_thresh = p_group->r_thresh;
            act_thresh = p_group->act_thresh;
            r_count = p_group->r_count;
            act_count = p_group->act_count;
            reloc_cnt = p_group->reloc_cnt;
            c_max_hole = p_group->c_max_hole;
            c_max_size = p_group->c_max_size;
            c_cost_sum = p_group->c_cost_sum;
            c_efficiency = p_group->c_efficiency;

            dbg_utils_pprinter_table_data_line_print(stream, gbin_groups_clmns);

            do_header = TRUE;
            for (k = 0; k < MAX_HOLES; k++) {
                p_hole = &p_group->holes[k];

                if (p_hole->len == 0) {
                    continue;
                }

                offset = p_hole->offset;
                len = p_hole->len;

                if (do_header) {
                    dbg_utils_pprinter_secondary_header_print(stream,
                                                              "Per-group holes DB");
                    dbg_utils_pprinter_table_headline_print(stream,
                                                            gbin_groups_holes_clmns);
                    do_header = FALSE;
                }

                dbg_utils_pprinter_table_data_line_print(stream,
                                                         gbin_groups_holes_clmns);
            }

            do_header = TRUE;
            for (k = 0; k < p_group->bucket_cnt; k++) {
                p_bucket = &p_group->buckets[k];

                if (p_bucket->alloc_cnt == 0) {
                    continue;
                }

                if (do_header) {
                    dbg_utils_pprinter_secondary_header_print(stream,
                                                              "Per-group allocation buckets");
                    dbg_utils_pprinter_table_headline_print(stream,
                                                            gbin_groups_bucket_clmns);
                    do_header = FALSE;
                }

                size = p_bucket->size;
                increment = p_bucket->increment;
                alloc_cnt = p_bucket->alloc_cnt;

                dbg_utils_pprinter_table_data_line_print(stream,
                                                         gbin_groups_bucket_clmns);
            }

            dbg_utils_pprinter_secondary_header_print(stream, "Per-group Allocation info");

            dbg_utils_pprinter_table_headline_print(stream,
                                                    gbin_groups_allocation_clmns);

            for (k = 0; k < p_group->alloc_size; k++) {
                offset = k;

                if (p_group->array_map[k]) {
                    snprintf(str_type, sizeof(str_type), "Alloc");

                    __bai_lid_label(p_user, p_group, k, str_label);

                    err = bai_block_size(p_group, k, &len);
                    if (err) {
                        goto out;
                    }
                } else {
                    snprintf(str_type, sizeof(str_type), "Free");
                    snprintf(str_label, sizeof(str_label), "         ");

                    len = 1;
                    for (l = k + 1; l < p_group->alloc_size; l++) {
                        if (p_group->array_map[l] != 0) {
                            break;
                        }

                        len++;
                    }
                }

                dbg_utils_pprinter_table_data_line_print(stream,
                                                         gbin_groups_allocation_clmns);

                k += len - 1;
            }
        }
    }

    dbg_utils_pprinter_user_defined_header_print(stream, DBG_UTILS_LEVEL_USER_DEFINED_1_E,
                                                 "Physical memory space info");
    dbg_utils_pprinter_table_headline_print(stream,
                                            gbin_phys_mem_clmns);

    for (i = 0; i < BIN_ALLOC_MAX_PHYS_MEMORY; i++) {
        p_phys_mem = &phys_memory_s[i];
        if (p_phys_mem->phys_mem_size == 0) {
            continue;
        }

        strncpy(phys_mem_name, p_phys_mem->phys_mem_name,
                sizeof(phys_mem_name) - 1);
        phys_mem_size = p_phys_mem->phys_mem_size;
        lids_in_use = id_allocator_in_use_count(&(p_phys_mem->lids_id_allocator));

        dbg_utils_pprinter_table_data_line_print(stream,
                                                 gbin_phys_mem_clmns);
    }
out:
    return err;
}


/**
 * Generate an API trace record
 * APIs provide only the values they use/return.  All others are given as 0.
 *
 * @param[in] func   - API generating the record
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] type   - Type of group or 0
 * @param[in] size   - Size of allocation request or 0
 * @param[in] cntx   - Client context or 0
 * @param[in] ref    - Reference count or 0
 * @param[in] index1 - offset in array or 0
 * @param[in] index2 - offset in array or 0
 * @param[in] lid1   - lid for one lid APIs or 0
 * @param[in] lid2   - lid for two lid APIs or 0
 * @param[in] err    - Error returned by the API
 */
static void __bai_trace(const gbin_api_e        func,
                        const ba_handle_t       handle,
                        const uint32_t          type,
                        const uint32_t          size,
                        const uint32_t          cntx,
                        const uint32_t          ref,
                        const uint32_t          index1,
                        const uint32_t          index2,
                        const ba_logical_id_t   lid1,
                        const ba_logical_id_t   lid2,
                        const sx_utils_status_t err)
{
    uint32_t    handle_idx;
    bai_user_t *p_user = (bai_user_t*)handle;

    handle_idx = (handle) ? p_user - users_s : BIN_ALLOC_MAX_USERS;

    SX_LOG_NTC("        {%u, %u, %u, %u, %u, %u, %u, %u, %u, %u, %u},\n",
               func, handle_idx, type, size, cntx, ref, index1, index2,
               lid1, lid2, err);
}


/**
 * Allocate an external LID and associate it with an internal LID
 *
 * @param[in] p_user - Pointer to user context to allocate LID in
 * @param[in] i_lid - Internal LID
 * @param]out r_lid - Pointer to where to store external LID
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_ERROR - User context invalid
 * @return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE - Internal LID not valid
 * @return SX_UTILS_STATUS_ENTRY_ALREADY_EXISTS - Free LID already exists
 * @return SX_UTILS_STATUS_NO_RESOURCES - No external LID available
 */
static sx_utils_status_t __bai_allocate_lid(bai_user_t *p_user, bai_logical_id_t i_lid, ba_logical_id_t  *r_lid)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_rc = CL_SUCCESS;
    cl_pool_item_t   *p_pool_item = NULL;
    cl_map_item_t    *p_item = NULL;
    bai_lid_info_t   *p_lid = NULL;

    /* Validate internal LID */
    err = bai_extract_i_lid(p_user, i_lid, __func__, NULL, NULL, NULL);
    if (err) {
        goto out;
    }

    p_pool_item = cl_qpool_get(&p_user->p_phys_mem->lids_pool);
    if (!p_pool_item) {
        /* This should not be possible - We have as many LIDs as lines */
        SX_LOG_NTC("No LIDs available!\n");
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }
    p_lid = PARENT_STRUCT(p_pool_item, bai_lid_info_t, pool_item);
    cl_rc = id_allocator_get(&(p_user->p_phys_mem->lids_id_allocator), &(p_lid->lid));
    if (cl_rc != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Failed to get new index LIDs pool, err = [%s]\n",
                   CL_STATUS_MSG(cl_rc));
        goto out;
    }
    /* Validate that LID isn't already in map - should never happen, but just
     * in case.
     */
    p_item = cl_qmap_get(&p_user->lids_map, p_lid->lid);
    if (p_item != cl_qmap_end(&p_user->lids_map)) {
        err = SX_UTILS_STATUS_ENTRY_ALREADY_EXISTS;
        SX_LOG_ERR("Internal error - LID %u already exists in user LIDs map!\n",
                   p_lid->lid);
        goto out;
    }

    p_lid->ilid = i_lid;
    cl_qmap_insert(&p_user->lids_map, p_lid->lid, &p_lid->map_item);

    *r_lid = p_lid->lid;

out:
    return err;
}


/**
 * Given a maximum value 'val', calculate the number of bits required to
 * hold the field (shift) and the mask value to isolate it assuming it is
 * right justified.
 *   See "Hacker's delight (2nd edition)"
 *
 * @param[in] cnt - Number of unique values allowed in this field
 * @param[out] shift_s - Optional pointer size of field in bits
 * @param[out] mask_s - Optional pointer mask to extract value from field
 *
 * @return SX_UTILS_STATUS_SUCCESS - Parameters OK
 * @return SX_UTILS_STATUS_SDK_ERROR - Value too big to round up
 */
static sx_utils_status_t __field_shift(uint32_t cnt, uint32_t *shift_s, uint32_t *mask_s)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          r, s_val, r_val;

    if (cnt == 0) {
        SX_LOG_ERR("Maximum value for valid fields must be > 0!\n");

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    if (cnt >= 0x80000000) {
        SX_LOG_ERR("Input value 0x%8.8X too big to round up!\n", cnt);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* Round (cnt + 1) up to the power-of-2 that holds it */
    if (cnt > 1) {
        cnt--;
        cnt |= cnt >> 1;
        cnt |= cnt >> 2;
        cnt |= cnt >> 4;
        cnt |= cnt >> 8;
        cnt |= cnt >> 16;
        cnt++;

        /* Find log2() of a value known to be a power of 2 */
        r = (cnt & log2tbl_s[0]) != 0;
        r |= ((cnt & log2tbl_s[4]) != 0) << 4;
        r |= ((cnt & log2tbl_s[3]) != 0) << 3;
        r |= ((cnt & log2tbl_s[2]) != 0) << 2;
        r |= ((cnt & log2tbl_s[1]) != 0) << 1;

        s_val = r;
        r_val = (1 << r) - 1;
    } else {
        s_val = 0;
        r_val = 0;
    }

    if (shift_s) {
        *shift_s = s_val;
    }

    if (mask_s) {
        *mask_s = r_val;
    }


out:
    return err;
}


/**
 * Validate client provided LID and internal LID it references
 *   Internal LIDs are valid only in the context of a single user.  They are
 * constructed out of three fields: <type> | <group_id> | <group_offset>.
 * The sizes of these fields depends on initialization parameters.
 *
 * @param[in] p_user - The user that owns the lid
 * @param[in] lid - The LID to resolve
 * @param[out] group_s - Pointer to group that owns LID
 * @param[out] index_s - Pointer to first line of LID in *group_s
 * @param[out] ilid_s - Pointer to internal LID value (optional)
 *
 * @return SX_UTILS_STATUS_SUCCESS - Parameters OK
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal SDK error; usually bad LID
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND - lid not active
 */
static sx_utils_status_t __bai_validate_lid(bai_user_t       *p_user,
                                            ba_logical_id_t   lid,
                                            bai_group_t     **group_s,
                                            ba_index_t       *index_s,
                                            bai_logical_id_t *ilid_s)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          group_idx, line_idx, type_val;
    bai_logical_id_t  lid_val;
    bai_group_t      *p_group;
    cl_map_item_t    *p_item = NULL;
    bai_lid_info_t   *p_lid = NULL;

    /* Make sure LID is in range and active */
    if (lid == INVALID_LID) {
        SX_LOG_WRN("Invalid LID %u\n", lid);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* Extract all fields */
    p_item = cl_qmap_get(&p_user->lids_map, lid);
    if (p_item == cl_qmap_end(&p_user->lids_map)) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("LID %u doesn't exist!\n", lid);
        goto out;
    }

    p_lid = PARENT_STRUCT(p_item, bai_lid_info_t, map_item);
    lid_val = p_lid->ilid;

    err = bai_extract_i_lid(p_user, lid_val, __func__, &type_val,
                            &group_idx, &line_idx);
    if (err) {
        goto out;
    }

    SX_LOG_INF("lid %u iLID 0x%8.8X: type=%u, group=%u, line=%u\n", lid,
               lid_val, type_val, group_idx, line_idx);

    /* Validate that group is active and matches LID type */
    p_group = &p_user->groups[group_idx];

    /* Make sure the user structure has allocated lids space */
    if (p_group->lids == NULL) {
        SX_LOG_ERR("User lids[] is NULL!\n");

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* Make sure this LID is still active */
    if (p_group->lids[line_idx].ref == 0) {
        SX_LOG_WRN("LID=0x%8.8X has reference count of 0!\n", lid_val);

        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (p_group->array_map == NULL) {
        SX_LOG_ERR("User array_map[] is NULL!\n");

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* Make sure first line of array at this offset is marked 'first' */
    if ((p_group->array_map[line_idx] & LS_FIRST_E) == 0) {
        SX_LOG_WRN("LID=0x%8.8X group %u line %u not marked first(%2.2X)!\n",
                   lid_val, group_idx, line_idx, p_group->array_map[line_idx]);

        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *group_s = p_group;
    *index_s = line_idx;
    if (ilid_s) {
        *ilid_s = lid_val;
    }


out:
    return err;
}


/**
 * Validate client provided session initialization parameters
 *   Also extract the constants that define the amount of local storage
 * we need to allocate in order to manage this array.
 *
 * @param param[in] - Pointer to initialization parameters
 *
 * @return SX_UTILS_STATUS_SUCCESS - Parameters OK
 * @return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE - Version not supported
 * @return SX_UTILS_STATUS_PARAM_ERROR - Invalid parameter in init params
 */
static sx_utils_status_t __bai_validate_param(ba_param_t *param)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    ba_template_t    *t;
    boolean_t         done = FALSE, last;
    uint16_t          prev;
    uint32_t          i, j;

    if (!param) {
        SX_LOG_WRN("No parameter!\n");

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (param->version != BIN_ALLOC_VERSION) {
        SX_LOG_ERR("Version %u not supported; only %u\n", param->version,
                   BIN_ALLOC_VERSION);

        err = SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Make sure options are valid */
    if (param->options & ~RELOC_VALID_E) {
        SX_LOG_ERR("Unsupported options specified 0x%8.8X!\n", param->options);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Group count must be non-zero */
    if (param->group_cnt == 0) {
        SX_LOG_WRN("Must have at least 1 group!\n");

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (param->group_cnt > MAX_GROUPS) {
        SX_LOG_WRN("Group count %d exceeds max %d!\n", param->group_cnt,
                   MAX_GROUPS);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Array size must be non-zero */
    if (param->array_size == 0) {
        SX_LOG_WRN("Managed array size must be > 0!\n");

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Alignment is the size of all groups */
    if ((param->alignment == 0) || (param->alignment > param->array_size)) {
        SX_LOG_WRN("Alignment %u not valid with array size %u!\n",
                   param->alignment, param->array_size);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Validate alignment, group_cnt, and array_size */
    if ((param->group_cnt * param->alignment) != param->array_size) {
        SX_LOG_WRN("Mismatch: group_cnt=%u alignment=%u array_size=%u\n",
                   param->group_cnt, param->alignment, param->array_size);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Relocate threshold: [0..100] percent */
    if (param->r_thresh > 100) {
        SX_LOG_WRN("Invalid threshold: %u; not in [0..100] percent!\n",
                   param->r_thresh);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* There must be at least one user supplied type */
    if (param->templates[0].type == GROUP_TYPE_FREE) {
        SX_LOG_WRN("Template 0 has no type!\n");

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Check the templates */
    for (i = 0; i < BIN_ALLOC_MAX_TYPES; i++) {
        t = &param->templates[i];

        /* Once you find end of templates list, no more allowed */
        if (done) {
            if (t->type != GROUP_TYPE_FREE) {
                SX_LOG_WRN("Template %d has non-zero type!\n", i);

                err = SX_UTILS_STATUS_PARAM_ERROR;
                goto out;
            }

            continue;
        }

        /* Once there are no more templates, mark we found the end */
        if (t->type == GROUP_TYPE_FREE) {
            done = TRUE;
            continue;
        }

        /* Length must be less than alignment */
        if (t->length > param->alignment) {
            SX_LOG_WRN("Template %d length(%u) exceeds group length(%u)!\n",
                       i, t->length, param->alignment);

            err = SX_UTILS_STATUS_PARAM_ERROR;
            goto out;
        }

        /* Make sure the type is not a duplicate */
        for (j = 0; j < i; j++) {
            if (param->templates[j].type == t->type) {
                SX_LOG_WRN("Template %d type %d duplicates template %d!\n",
                           i, t->type, j);

                err = SX_UTILS_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        /* Make sure we have at least one size */
        if (t->alloc_sizes[0] == 0) {
            SX_LOG_WRN("Template %d has no valid sizes!\n", i);

            err = SX_UTILS_STATUS_PARAM_ERROR;
            goto out;
        }

        /* Make sure sizes are ordered and fit in the group */
        prev = 0;
        last = FALSE;
        for (j = 0; j < BIN_ALLOC_MAX_ALLOC_SIZES; j++) {
            if (last) {
                if (t->alloc_sizes[j] != 0) {
                    SX_LOG_WRN("Template %d entry %d has non-zero size(%d)!\n",
                               i, j, t->alloc_sizes[j]);

                    err = SX_UTILS_STATUS_PARAM_ERROR;
                    goto out;
                }

                continue;
            }

            if (t->alloc_sizes[j] == 0) {
                last = TRUE;
                continue;
            }

            /* Sizes must be monotonically increasing */
            if (t->alloc_sizes[j] <= prev) {
                SX_LOG_WRN("Template %d entry %d size=%u <= previous %u!\n",
                           i, j, t->alloc_sizes[j], prev);

                err = SX_UTILS_STATUS_PARAM_ERROR;
                goto out;
            }

            prev = t->alloc_sizes[j];

            /* All sizes must fit into the part of the group available */
            if (prev > t->length) {
                SX_LOG_WRN("Template %d size %u exceeds max %u!\n", i, prev,
                           t->length);

                err = SX_UTILS_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        /* Make sure the allocate/free callbacks are initialized */
        if ((t->cb_alloc == NULL) || (t->cb_free == NULL)) {
            SX_LOG_ERR("Missing allocate and/or free callback!\n");

            err = SX_UTILS_STATUS_PARAM_ERROR;
            goto out;
        }

        SX_LOG_INF("Template %d size min=%u max=%u\n", i, t->alloc_sizes[0],
                   prev);
    }

    if (param->phys_init) {
        /* Make sure that the physical memory name isn't empty */
        if (param->phys_init->phys_mem_name[0] == '\0') {
            SX_LOG_ERR("Physical memory name can't be empty if a physical memory pointer is given\n");

            err = SX_UTILS_STATUS_PARAM_ERROR;
            goto out;
        }

        /* Make sure that the physical memory size isn't 0 */
        if (param->phys_init->phys_mem_size == 0) {
            SX_LOG_ERR("Physical memory size can't be 0 if a physical memory pointer is given\n");

            err = SX_UTILS_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    return err;
}

static sx_utils_status_t __bai_init_phys_memory(bai_phys_memory_t *p_phys_mem, const ba_param_t *param)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;
    boolean_t         qpool_initialized = FALSE;
    uint32_t          phys_mem_size = param->phys_init ?
                                      param->phys_init->phys_mem_size : param->array_size;


    cl_err = id_allocator_init(phys_mem_size, phys_mem_size / 8, 1, &(p_phys_mem->lids_id_allocator));
    if (cl_err != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Failed to initialize id_allocator for LIDs pool, cl_err = [%s]\n", CL_STATUS_MSG(cl_err));
    }

    p_phys_mem->phys_mem_size = phys_mem_size;

    cl_err = CL_QPOOL_INIT(&p_phys_mem->lids_pool,
                           phys_mem_size / 8,
                           phys_mem_size,
                           phys_mem_size / 8,
                           sizeof(bai_lid_info_t),
                           NULL,
                           NULL,
                           NULL);
    if (cl_err != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Failed to initialize LIDs pool, cl_err = [%s]\n",
                   CL_STATUS_MSG(cl_err));
        goto out;
    }
    qpool_initialized = TRUE;

    if (param->phys_init) {
        strncpy(p_phys_mem->phys_mem_name, param->phys_init->phys_mem_name,
                sizeof(p_phys_mem->phys_mem_name) - 1);
        p_phys_mem->phys_mem_name[sizeof(p_phys_mem->phys_mem_name) - 1] = '\0';
    }


    err = gc_object_init(param->gc_object_type, &param->gc_attr,
                         __ba_gc_completion_cb, __ba_gc_post_completion_cb);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to initialize GC object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(param->gc_object_type),
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

out:
    if (SX_UTILS_CHECK_FAIL(err)) {
        if (qpool_initialized) {
            CL_QPOOL_DESTROY(&p_phys_mem->lids_pool);
            cl_err = id_allocator_destroy(&(p_phys_mem->lids_id_allocator));
            if (cl_err != CL_SUCCESS) {
                SX_LOG_ERR("Failed to destroy id_allocator, cl_err = [%s]\n",
                           CL_STATUS_MSG(cl_err));
            }
            M_GEN_UTILS_MEM_CLR_PTR(p_phys_mem, sizeof(*p_phys_mem));
        }
    }
    return err;
}

static sx_utils_status_t __bai_deinit_phys_memory(bai_user_t *p_user)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t        cl_rc = CL_SUCCESS;
    bai_phys_memory_t *p_phys_mem = p_user->p_phys_mem;
    uint32_t           i = 0;

    SX_LOG_ENTER();

    p_user->p_phys_mem = NULL;
    if (p_phys_mem->phys_mem_name[0] != '\0') {
        for (i = 0; i < BIN_ALLOC_MAX_USERS; i++) {
            if (users_s[i].p_phys_mem == p_phys_mem) {
                goto out;
            }
        }
    }

    err = gc_object_deinit(p_user->gc_object_type);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinitialize GC object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(p_user->gc_object_type),
                   SX_UTILS_STATUS_MSG(err));
    }
    cl_rc = id_allocator_destroy(&(p_phys_mem->lids_id_allocator));
    if (cl_rc != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Failed to deinit id_allocator in LIDs pool, err = [%s]\n",
                   CL_STATUS_MSG(cl_rc));
    }
    CL_QPOOL_DESTROY(&p_phys_mem->lids_pool);

    M_GEN_UTILS_MEM_CLR_PTR(p_phys_mem, sizeof(*p_phys_mem));

out:
    SX_LOG_EXIT();
    return err;
}

/**
 * Allocate and initialize group memory for a new user
 *
 * @param[out] r_group - Where to store initialized group pointer
 * @param[in/out] r_mem - Memory used
 * @param[in] param - Group initialization parameters
 *
 * @return SX_UTILS_STATUS_SUCCESS - Subsystem initialized
 * @return SX_UTILS_STATUS_NO_RESOURCES - Not enough memory
 * @return SX_UTILS_STATUS_CMD_UNSUPPORTED - test not supported
 */
static sx_utils_status_t __bai_init_groups(bai_group_t **r_group, uint32_t          *r_mem, const ba_param_t  *param)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_group_t      *p_base = NULL, *p_group;
    uint32_t          mem_used;
    uint16_t          i;

    mem_used = *r_mem;

    /* Allocate and initialize to zeros */
    M_GEN_UTILS_CLR_MEM_GET(&p_base, (size_t)param->group_cnt,                \
                            sizeof(bai_group_t), GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                            "Group structures\n", err);
    if ((err != 0) || (p_base == NULL)) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }
    mem_used += param->group_cnt * param->alignment;

    /* Initialize the fields in each of the group structures */
    for (i = 0; i < param->group_cnt; i++) {
        p_group = &p_base[i];

        /* By definition, this group is free */
        p_group->type = GROUP_TYPE_FREE;

        /* Relocation constants - Never changed */
        p_group->r_thresh = param->r_thresh;
        p_group->r_count = param->r_count;
        p_group->array_map = NULL;
        p_group->lids = NULL;
    }

    /* Update memory efficiency tracking info */
    *r_mem = mem_used;

out:
    if (err != SX_UTILS_STATUS_SUCCESS) {
        /* Cleanup any partially allocated data */
        if (p_base) {
            for (i = 0; i < param->group_cnt; i++) {
                p_group = &p_base[i];

                if (p_group->array_map) {
                    M_GEN_UTILS_MEM_PUT(p_group->array_map,          \
                                        GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                                        "array_map", err);
                }
            }

            M_GEN_UTILS_MEM_PUT(p_base, GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                                "base", err);

            /* Any errors mean that group was not allocated */
            p_base = NULL;
        }
    }

    *r_group = p_base;

    return err;
}


/**
 * Cleanup groups data structure
 *
 * @param[in/out] r_group - Pointer to pointer to group.  Will be set to NULL
 * @param[in] group_cnt - Number of groups in *r_group
 *
 * @return SX_UTILS_STATUS_SUCCESS - Subsystem initialized
 * @return SX_UTILS_STATUS_SDK_ERROR - Invalid internal call
 */
static sx_utils_status_t __bai_deinit_groups(bai_group_t **r_group, const uint16_t group_cnt)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_group_t      *p_base = NULL, *p_group;
    uint16_t          i;

    p_base = *r_group;

    if (group_cnt > MAX_GROUPS) {
        SX_LOG_ERR("Group count %d exceeds max %d!\n", group_cnt, MAX_GROUPS);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    for (i = 0; i < group_cnt; i++) {
        p_group = &p_base[i];

        if (p_group->array_map) {
            M_GEN_UTILS_MEM_PUT(p_group->array_map,          \
                                GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                                "array_map", err);
        }
        p_group->array_map = NULL;

        if (p_group->lids) {
            M_GEN_UTILS_MEM_PUT(p_group->lids,               \
                                GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                                "lids", err);
        }
        p_group->lids = NULL;
    }

    M_GEN_UTILS_MEM_PUT(p_base, GEN_UTILS_MEM_TYPE_ID_BIN_E, "base", err);

    *r_group = NULL;


out:
    return err;
}


/**
 * Verify that a pointer is a valid handle and extract bai_user_t handle
 *
 * @param[in] handle - Pointer to test
 * @param[out] user_s - Optional pointer to where to store user struct pointer
 *
 * @return SX_UTILS_STATUS_SUCCESS - Handle is valid
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Handle not active
 * @return SX_UTILS_STATUS_PARAM_NULL - Handle pointer is NULL
 */
static sx_utils_status_t __bai_validate_handle(ba_handle_t handle, bai_user_t  **user_s)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          idx;
    bai_user_t       *p_user = handle;

    if (p_user == NULL) {
        SX_LOG_WRN("Handle NULL!\n");

        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if ((p_user < &users_s[0]) || (p_user >= &users_s[BIN_ALLOC_MAX_USERS])) {
        SX_LOG_WRN("Handle %p not in valid range!\n", handle);

        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    idx = p_user - users_s;

    if (p_user != &users_s[idx]) {
        SX_LOG_WRN("Handle %p is not aligned!\n", handle);

        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if (!p_user->allocated) {
        SX_LOG_WRN("Handle %p not active\n", handle);

        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if (user_s) {
        *user_s = p_user;
    }


out:
    return err;
}

static sx_utils_status_t __ba_gc_completion_cb(const void *context)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user = NULL;
    bai_group_t      *p_group = NULL;
    uint32_t          line_idx = 0;
    uint32_t          group_idx = 0;
    uint32_t          bucket_idx = 0;
    ba_gc_context_t  *p_gc_context = (ba_gc_context_t*)context;
    uint32_t          size = 0;
    bai_bucket_t     *p_bucket = NULL;
    ba_index_t        index;

    SX_LOG_ENTER();

    if (p_gc_context == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("context parameter is NULL\n");
        goto out;
    }

    /* Get the user from the handle */
    err = __bai_validate_handle(p_gc_context->data.handle, &p_user);
    if (err) {
        goto out;
    }

    /* Get the index of the first line from the iLID */
    err = bai_extract_i_lid(p_user, p_gc_context->data.i_lid, __func__, NULL,
                            &group_idx, &line_idx);
    if (err) {
        goto out;
    }

    p_group = &p_user->groups[group_idx];

    /* Get block size for later use */
    err = bai_block_size(p_group, line_idx, &size);
    if (err) {
        goto out;
    }

    /* Unlock the first line of the block, so any freeing operations requiring
     * block to be unlocked can be performed.
     */
    p_group->array_map[line_idx] &= ~LS_LOCKED_E;

    if (p_user->free_object_cb) {
        index = line_idx + group_idx * p_user->group_size;

        err = p_user->free_object_cb(p_gc_context->data.handle,
                                     p_gc_context->data.reloc_flow,
                                     p_gc_context->data.lid,
                                     p_group->lids[line_idx].client_context,
                                     index);
        if (err) {
            SX_LOG_ERR("Free object callback failed for the BA object with LID %u!\n",
                       p_gc_context->data.lid);
            goto out;
        }
    }

    switch (p_gc_context->data.reloc_flow) {
    case BA_RELOC_FLOW_NONE:
        /* Free the block represented by the iLID */
        err = bai_free(p_user, p_gc_context->data.i_lid);
        if (err) {
            goto out;
        }

        /* Something has changed - Background relocation should check */
        no_changes_s = FALSE;
        break;

    case BA_RELOC_FLOW_MERGE:
    case BA_RELOC_FLOW_IMPROVE:
        /*
         * Free the block from which the relocation occurred.
         *   If there is an error doing this, log it and mark space as unusable
         * for future allocation. There will be a problem doing shutdown, but
         * that is better than causing problems now.
         */
        err = bai_block_free(p_group, line_idx);
        if (err) {
            SX_LOG_WRN(
                "Internal error - G%u.%u len=%u error %d during free; continues\n",
                (uint32_t)(p_group - p_user->groups), line_idx, size, err);

            /* Mark the block as allocated and locked so we don't use */
            p_group->array_map[line_idx] |= LS_LOCKED_E;
            cl_spinlock_acquire(&p_group->lids[line_idx].lock);
            p_group->lids[line_idx].ref = MAX_REF_CNT;
            cl_spinlock_release(&p_group->lids[line_idx].lock);

            /* Disable relocation because internal data structures bad */
            SX_LOG_WRN("Relocation halted due to being unable to free!\n");
            p_user->options &= ~(RELOC_SYNC_E | RELOC_ASYNC_E | RELOC_ASYNC_GC_E);
        }

        /* Get the template associated with the freed group */
        err = bai_find_size(p_user, p_group->p_template, size, &bucket_idx);
        if (err) {
            goto out;
        }
        p_bucket = &p_group->buckets[bucket_idx];

        /* Update bucket counters in freed group */
        p_bucket->alloc_cnt--;

        /* Update total free line counts in freed group */
        p_group->free_lines += size;

        /* Mark the cache for freed group as invalid */
        p_group->alloc_cache_valid = FALSE;

        err = bai_cache_update(p_group);
        if (err) {
            goto out;
        }

        if ((p_gc_context->data.reloc_flow == BA_RELOC_FLOW_MERGE) &&
            (p_group->free_lines == p_group->alloc_size)) {
            err = bai_free_group(p_user, p_group);
            if (err) {
                goto out;
            }
        }

        break;

    case BA_RELOC_FLOW_SYNC:
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Synchronous relocation for G%u.%u len=%u handled asynchronously!\n",
                   (uint32_t)(p_group - p_user->groups), line_idx, size);
        goto out;

    default:
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Invalid relocation flow type %u\n",
                   p_gc_context->data.reloc_flow);
        goto out;
    }

    SX_LOG_DBG("Freed ILID %u in GC\n", p_gc_context->data.i_lid);

    /* Return GC context entry to pool */
    err = bai_gc_context_put(p_gc_context);
    if (err) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_utils_status_t __ba_gc_post_completion_cb(const void *context, boolean_t is_last, uint32_t bg)
{
    sx_utils_status_t            err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t                  *p_user = NULL;
    bai_group_t                 *p_group = NULL;
    uint32_t                     size = 0;
    uint32_t                     line_idx = 0;
    uint32_t                     group_idx = 0;
    ba_gc_context_t             *p_gc_context = (ba_gc_context_t*)context;
    ba_post_completion_context_t obj_context;

    SX_LOG_ENTER();

    if (p_gc_context == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("context parameter is NULL\n");
        goto out;
    }

    /* Get the user from the handle */
    err = __bai_validate_handle(p_gc_context->data.handle, &p_user);
    if (err) {
        goto out;
    }

    /* Get the index of the first line from the iLID */
    err = bai_extract_i_lid(p_user, p_gc_context->data.i_lid, __func__, NULL,
                            &group_idx, &line_idx);
    if (err) {
        goto out;
    }

    p_group = &p_user->groups[group_idx];

    /* Get block size*/
    err = bai_block_size(p_group, line_idx, &size);
    if (err) {
        goto out;
    }

    if (p_user->gc_post_completoion_cb == NULL) {
        SX_LOG_ERR("No post completion callback was given for object type %u\n", p_user->gc_object_type);
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    /* Calculate the real index by adding the group location*/
    line_idx += group_idx * p_user->group_size;

    obj_context.start_index = line_idx;
    obj_context.obj_size = size;
    obj_context.table_size = p_user->vm_size;
    obj_context.gc_object_type = p_user->gc_object_type;
    obj_context.gc_subtype = p_user->gc_subtype;

    err = p_user->gc_post_completoion_cb(&obj_context, is_last, bg);
    if (err) {
        SX_LOG_ERR("failed calling post completion callback for object type %u\n", p_user->gc_object_type);
        goto out;
    }


out:
    SX_LOG_EXIT();
    return err;
}
/************************************************
 *  Function implementations
 ***********************************************/


/**
 * Initialize Bin Allocator service
 *
 * @return SX_UTILS_STATUS_SUCCESS - Subsystem initialized
 * @return SX_UTILS_STATUS_ALREADY_INITIALIZED - Subsystem already initialized
 * @return SX_UTILS_STATUS_NO_RESOURCES - Not enough memory to initialize
 * @return SX_UTILS_STATUS_ERROR - Something prevented init
 */
sx_utils_status_t ba_init(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if (init_done_s) {
        SX_LOG_ERR("Already initialized!\n");

        err = SX_UTILS_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    /* User handle table initialized to empty */
    M_GEN_UTILS_MEM_CLR_PTR(users_s, sizeof(users_s));
    M_GEN_UTILS_MEM_CLR_PTR(phys_memory_s, sizeof(phys_memory_s));

    err = bai_gc_context_pool_init();
    if (err) {
        goto out;
    }

    err = bai_relocate_context_pool_init();
    if (err) {
        goto out;
    }

    if (cl_spinlock_init(&(relocation_info_stream_lock)) != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }
    if (cl_spinlock_init(&(relocation_handler_lock)) != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    sx_utils_debug_cmd_register_path("ba relocation",
                                     __debug_cmd_ba_relocation,
                                     NULL);

    init_done_s = TRUE;

out:
    if (gbin_trace_s) {
        __bai_trace(BA_INIT_E,
                    NULL,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    err);
    }

    return err;
}


/**
 * Deinitialize Bin Allocator service
 *
 * @return SX_UTILS_STATUS_SUCCESS - Subsystem shutdown ok
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Not initialized
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - At least one client still active
 * @return SX_UTILS_STATUS_ERROR - Something prevented shutdown
 */
sx_utils_status_t ba_deinit(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user;
    uint32_t          i;

    if (!init_done_s) {
        SX_LOG_ERR("Deinit called without previous init!\n");

        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    /* Make sure all users have closed */
    for (i = 0; i < BIN_ALLOC_MAX_USERS; i++) {
        p_user = &users_s[i];

        if (!p_user->allocated) {
            continue;
        }

        SX_LOG_ERR("Deinit called with at least one user active!\n");

        err = SX_UTILS_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    err = bai_gc_context_pool_deinit();
    if (err) {
        goto out;
    }

    err = bai_relocate_context_pool_deinit();
    if (err) {
        goto out;
    }

    cl_spinlock_destroy(&(relocation_handler_lock));
    cl_spinlock_destroy(&(relocation_info_stream_lock));

    sx_utils_debug_cmd_unregister_path("ba relocation");

    init_done_s = FALSE;

out:
    if (gbin_trace_s) {
        __bai_trace(BA_DEINIT_E,
                    NULL,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    err);
    }
    return err;
}


/**
 * Initialize a gbin_allocator client
 *
 * @param handle[out] - Pointer to location to return handle
 * @param param[in] - Pointer to initialization parameters
 *
 * @return SX_UTILS_STATUS_SUCCESS - Client initialized
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - Handle pointer is NULL
 * @return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE - Version not supported
 * @return SX_UTILS_STATUS_PARAM_ERROR - Invalid parameter in init params
 * @return SX_UTILS_STATUS_NO_RESOURCES - Not enough memory to initialize
 */
sx_utils_status_t ba_client_init(ba_handle_t *r_handle, ba_param_t *param)
{
    sx_utils_status_t    err = SX_UTILS_STATUS_SUCCESS, err2;
    ba_handle_t         *handle = NULL;
    bai_user_t          *p_user = NULL;
    bai_group_t         *p_group = NULL;
    bai_block_element_t *p_elem = NULL;
    uint32_t             i, j, shift;
    uint32_t             mem_used = 0;
    uint16_t             size;
    uint32_t             first_free = 0;
    boolean_t            found = FALSE;

    if (!init_done_s) {
        SX_LOG_ERR("One time initialization wasn't completed!\n");

        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if (!r_handle) {
        SX_LOG_ERR("Return handle pointer is NULL!\n");

        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    /* Validate the input parameters */
    err = __bai_validate_param(param);
    if (err) {
        goto out;
    }

    mem_used += sizeof(users_s);

    /* Find a free user structure - Doesn't happen often so linear is OK */
    for (i = 0; i < BIN_ALLOC_MAX_USERS; i++) {
        p_user = &users_s[i];

        if (p_user->allocated) {
            continue;
        }

        handle = (void*)p_user;
        break;
    }

    if (!handle) {
        SX_LOG_WRN("User handles exhausted!\n");

        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    /* When not allocated, only valid field is 'allocated' */
    M_GEN_UTILS_MEM_CLR_PTR(p_user, sizeof(*p_user));

    /* Physical memory initialization */
    first_free = BIN_ALLOC_MAX_PHYS_MEMORY;
    if (param->phys_init) {
        for (i = 0; i < BIN_ALLOC_MAX_PHYS_MEMORY; i++) {
            if (!strncmp(param->phys_init->phys_mem_name,
                         phys_memory_s[i].phys_mem_name,
                         sizeof(param->phys_init->phys_mem_name))) {
                if (param->phys_init->phys_mem_size !=
                    phys_memory_s[i].phys_mem_size) {
                    SX_LOG_ERR("Size %u of given physical memory %s is different from existing configured size %u\n",
                               param->phys_init->phys_mem_size,
                               param->phys_init->phys_mem_name,
                               phys_memory_s[i].phys_mem_size);

                    err = SX_UTILS_STATUS_PARAM_ERROR;
                    goto out;
                }

                found = TRUE;
                break;
            } else if ((first_free == BIN_ALLOC_MAX_PHYS_MEMORY) &&
                       (phys_memory_s[i].phys_mem_size == 0)) {
                first_free = i;
            }
        }

        if (found) {
            p_user->p_phys_mem = &phys_memory_s[i];
        } else if (first_free < BIN_ALLOC_MAX_PHYS_MEMORY) {
            err = __bai_init_phys_memory(&phys_memory_s[first_free], param);
            if (err) {
                SX_LOG_ERR("Failed to initialize physical memory at index %u, err = [%s]\n",
                           first_free, SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            p_user->p_phys_mem = &phys_memory_s[first_free];
        } else {
            SX_LOG_WRN("Physical memory entries exhausted!\n");

            err = SX_UTILS_STATUS_NO_RESOURCES;
            goto out;
        }
    } else {
        for (i = 0; i < BIN_ALLOC_MAX_PHYS_MEMORY; i++) {
            if (phys_memory_s[i].phys_mem_size == 0) {
                found = TRUE;
                break;
            }
        }

        if (found) {
            err = __bai_init_phys_memory(&phys_memory_s[i], param);
            if (err) {
                SX_LOG_ERR("Failed to initialize physical memory at index %u, err = [%s]\n",
                           i, SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            p_user->p_phys_mem = &phys_memory_s[i];
        } else {
            SX_LOG_WRN("Physical memory entries exhausted!\n");

            err = SX_UTILS_STATUS_NO_RESOURCES;
            goto out;
        }
    }


    /* Allocate per-group state and allocation tracking info */
    err = __bai_init_groups(&p_group, &mem_used, param);
    if (err) {
        goto out;
    }

    /*
     *   Cleanup will trigger on p_group not p_user->groups to avoid special
     * cases.  When p_user->allocated set false, values in other fields are
     * not valid.
     */
    p_user->groups = p_group;

    p_user->options = param->options;
    p_user->group_cnt = param->group_cnt;
    p_user->group_size = param->alignment;
    p_user->vm_size = param->array_size;

    /* Finally copy the param template info and calculate count */
    memcpy(p_user->templates, param->templates, sizeof(p_user->templates));

    for (i = 0; i < BIN_ALLOC_MAX_TYPES; i++) {
        if (p_user->templates[i].type == GROUP_TYPE_FREE) {
            break;
        }

        /* Init the direct lookup table */
        p_user->lookup_size[i].slow_start = UINT16_MAX;
        for (j = 0; j < BIN_ALLOC_MAX_ALLOC_SIZES; j++) {
            size = p_user->templates[i].alloc_sizes[j];

            /* If we have fewer sizes than spots */
            if (size == 0) {
                break;
            }

            /* If size fits in table, add the template.alloc_sizes[] index */
            if (size <= BIN_ALLOC_MAX_SIZE_LOOKUP) {
                p_user->lookup_size[i].index[size] = j;
            } else if (p_user->lookup_size[i].slow_start == UINT16_MAX) {
                /* Index to start linear search at */
                p_user->lookup_size[i].slow_start = j;
            }
        }
    }
    p_user->template_count = i;

    /* line is in range [0..group_size) so group_size values */
    err = __field_shift(p_user->group_size, &p_user->shift_group,
                        &p_user->mask_line);
    if (err) {
        goto out;
    }

    if (param->total_size > param->array_size) {
        err = __field_shift((param->total_size / p_user->group_size), &shift, NULL);
    } else {
        err = __field_shift(p_user->group_cnt, &shift, NULL);
    }

    if (err) {
        goto out;
    }

    /* Group is in range [0..group_cnt) so group_cnt values */
    err = __field_shift(p_user->group_cnt, NULL, &p_user->mask_group);
    if (err) {
        goto out;
    }
    p_user->shift_type = p_user->shift_group + shift;

    /* Type is in range [0..template_count] so template_count + 1 values */
    err = __field_shift(p_user->template_count + 1, NULL,
                        &p_user->mask_type);
    if (err) {
        goto out;
    }

    /* Initialize the external-LID to internal-ID map and attach it */
    cl_qmap_init(&p_user->lids_map);

    /* Allocate and initialize to zeros */
    M_GEN_UTILS_CLR_MEM_GET(&p_elem, (size_t)param->alignment,                        \
                            sizeof(bai_block_element_t), GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                            "Working storage", err);
    if ((err != 0) || (p_elem == NULL)) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }
    mem_used += param->alignment * sizeof(bai_block_element_t);

    /* Initialize the pointer to working space and mark it inactive */
    p_user->p_drain = NULL;
    p_user->blocks = p_elem;

    /* Set garbage collector attributes */
    p_user->gc_object_type = param->gc_object_type;
    p_user->gc_subtype = param->gc_subtype;
    p_user->gc_fence_type = param->gc_attr.fence_type;
    p_user->gc_post_completoion_cb = param->gc_post_completion_cb;
    p_user->free_object_cb = param->free_object_cb;

    if (cl_spinlock_init(&(p_user->thread_lock)) != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Internal user structure is now valid */
    p_user->allocated = TRUE;

    /* If trace trace is requested, set the flag now */
    if (p_user->options & ENABLE_TRACE_E) {
        gbin_trace_s = TRUE;
    }

    SX_LOG_DBG("User %p initialized %d groups %d types %u bytes used\n",
               handle, p_user->group_cnt, p_user->template_count, mem_used);


out:
    if (err != SX_UTILS_STATUS_SUCCESS) {
        /* Do cleanup of malloc() space here */
        if (p_group) {
            __bai_deinit_groups(&p_group, param->group_cnt);
        }
        if (p_elem) {
            M_GEN_UTILS_MEM_PUT(p_elem, GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                                "Working storage", err2);
        }
        if (p_user) {
            if (p_user->p_phys_mem) {
                __bai_deinit_phys_memory(p_user);
            }
            p_user->allocated = FALSE;
        }
    }

    if (r_handle) {
        *r_handle = handle;
    }

    if (gbin_trace_s) {
        __bai_trace(BA_CLIENT_INIT_E,
                    handle,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    err);
    }

    return err;
}


/**
 * Free all allocated resources.
 *   This call can both assert() or return an error if not all resources in
 * all groups are free.
 *
 * @param handle - Pointer to active set of initialization and runtime data
 *
 * @return SX_UTILS_STATUS_SUCCESS - Client connection closed
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Handle not active
 * @return SX_UTILS_STATUS_PARAM_NULL - Handle pointer is NULL
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - At least one register allocated
 */
sx_utils_status_t ba_client_deinit(ba_handle_t handle)
{
    sx_utils_status_t    err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t          cl_rc = CL_SUCCESS;
    bai_user_t          *p_user;
    const cl_map_item_t *p_end = NULL;
    cl_map_item_t       *p_head = NULL;
    bai_lid_info_t      *p_lid = NULL;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    /* Synchronously process GC queue of this object so there are no leftovers
     * of this user after the client is deinitialized.
     */
    err = gc_object_process_queue(p_user->gc_object_type);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to synchronously process GC queue of object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(p_user->gc_object_type),
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    /* KVD objects require additional processing in GC post queue */
    if (p_user->gc_object_type == GC_OBJECT_TYPE_KVD_LINEAR) {
        err = gc_post_queue_cleanup(TRUE, p_user->gc_subtype);
        if (SX_UTILS_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to process GC post queue of object subtype %s, err = [%s]\n",
                       GC_OBJECT_SUBTYPE_STR(p_user->gc_subtype),
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }
    }

    p_end = cl_qmap_end(&p_user->lids_map);
    p_head = cl_qmap_head(&p_user->lids_map);
    while (p_head != p_end) {
        p_lid = PARENT_STRUCT(p_head, bai_lid_info_t, map_item);
        cl_qmap_remove_item(&p_user->lids_map, p_head);
        cl_rc = id_allocator_put(&(p_user->p_phys_mem->lids_id_allocator), p_lid->lid);
        if (cl_rc != CL_SUCCESS) {
            err = SX_UTILS_STATUS_ERROR;
            SX_LOG_ERR("Failed to delete LIDs pool index %d, err = [%s]\n",
                       p_lid->lid, CL_STATUS_MSG(cl_rc));
            goto out;
        }
        cl_qpool_put(&p_user->p_phys_mem->lids_pool, &p_lid->pool_item);

        p_head = cl_qmap_head(&p_user->lids_map);
    }

    if (p_user->blocks) {
        M_GEN_UTILS_MEM_PUT(p_user->blocks, GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                            "Working storage", err);
    }
    if (err) {
        goto out;
    }

    if (p_user->p_phys_mem) {
        err = __bai_deinit_phys_memory(p_user);
        if (err) {
            goto out;
        }
    }

    err = __bai_deinit_groups(&p_user->groups, p_user->group_cnt);
    if (err) {
        goto out;
    }

    cl_spinlock_destroy(&(p_user->thread_lock));

    p_user->allocated = FALSE;

out:
    if (gbin_trace_s) {
        __bai_trace(BA_CLIENT_DEINIT_E,
                    handle,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    err);
    }

    return err;
}


/**
 * Increment reference count on previously allocated set of table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to increment reference count on
 *
 * @return SX_UTILS_STATUS_SUCCESS - Increment successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_SDK_ERROR - Reference count would exceed max count
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_ref_inc(ba_handle_t handle, ba_logical_id_t lid)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user;
    bai_group_t      *p_group = NULL;
    ba_index_t        index = ENTRY_EMPTY;
    boolean_t         ref_locked = FALSE;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    err = __bai_validate_lid(p_user, lid, &p_group, &index, NULL);
    if (err) {
        goto out;
    }

    cl_spinlock_acquire(&p_group->lids[index].lock);
    ref_locked = TRUE;

    if (p_group->lids[index].ref == MAX_REF_CNT) {
        SX_LOG_WRN("User %p lid 0x%8.8X reference count already at max %u!\n",
                   handle, lid, MAX_REF_CNT);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    p_group->lids[index].ref++;
    SX_LOG_DBG("LID 0x%8.8X idx 0x%8.8X reference increased by 1 new count %u!\n", lid, index,
               p_group->lids[index].ref);


out:
    if (ref_locked == TRUE) {
        cl_spinlock_release(&p_group->lids[index].lock);
    }
    if (gbin_trace_s) {
        uint32_t ref = (p_group) ? p_group->lids[index].ref : ENTRY_EMPTY;

        __bai_trace(BA_REF_INC_E,
                    handle,
                    0,
                    0,
                    0,
                    ref,
                    index,
                    0,
                    lid,
                    0,
                    err);
    }

    return err;
}


/**
 * Decrement reference count on previously allocated set of table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to increment reference count on
 *
 * @return SX_UTILS_STATUS_SUCCESS - Increment successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - Reference count was 1
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_ref_dec(ba_handle_t handle, ba_logical_id_t lid)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user;
    bai_group_t      *p_group = NULL;
    ba_index_t        index = ENTRY_EMPTY;
    boolean_t         ref_locked = FALSE;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    err = __bai_validate_lid(p_user, lid, &p_group, &index, NULL);
    if (err) {
        goto out;
    }

    cl_spinlock_acquire(&p_group->lids[index].lock);
    ref_locked = TRUE;
    /* Only reference counts > 1 are allowed to be decremented */
    if (p_group->lids[index].ref <= 1) {
        SX_LOG_WRN("User %p lid 0x%8.8X idx 0x%X reference count %u!\n",
                   handle, lid, index, p_group->lids[index].ref);

        err = SX_UTILS_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    p_group->lids[index].ref--;
    SX_LOG_DBG("LID 0x%8.8X idx 0x%8.8X reference decreased by 1 new count %u!\n", lid, index,
               p_group->lids[index].ref);


out:
    if (ref_locked == TRUE) {
        cl_spinlock_release(&p_group->lids[index].lock);
    }
    if (gbin_trace_s) {
        uint32_t ref = (p_group) ? p_group->lids[index].ref : ENTRY_EMPTY;

        __bai_trace(BA_REF_DEC_E,
                    handle,
                    0,
                    0,
                    0,
                    ref,
                    index,
                    0,
                    lid,
                    0,
                    err);
    }

    return err;
}


/**
 * Associate a client context pointer with a logical ID
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to increment reference count on
 * @param[in] cntx   - Client provided context
 *
 * @return SX_UTILS_STATUS_SUCCESS - Client context handle saved
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 */
sx_utils_status_t ba_client_cntx_set(ba_handle_t handle, ba_logical_id_t lid, uint32_t cntx)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user;
    bai_group_t      *p_group;
    ba_index_t        index;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    err = __bai_validate_lid(p_user, lid, &p_group, &index, NULL);
    if (err) {
        goto out;
    }

    p_group->lids[index].client_context = cntx;


out:
    if (gbin_trace_s) {
        __bai_trace(BA_CLIENT_CNTX_SET_E,
                    handle,
                    0,
                    0,
                    cntx,
                    0,
                    0,
                    0,
                    lid,
                    0,
                    err);
    }

    return err;
}


/**
 * Retrieve client context pointer and reference count
 *
 * @param[in] handle  - Pointer to initialized client handle
 * @param[in] lid     - The logical ID to increment reference count on
 * @param[out] cntx_p - Pointer to a location to save  context (or NULL)
 * @param[out] ref_p  - Pointer to location to save reference count (or NULL)
 *
 * @return SX_UTILS_STATUS_SUCCESS - Request succeeded
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 */
sx_utils_status_t ba_client_cntx_get(ba_handle_t     handle,
                                     ba_logical_id_t lid,
                                     uint32_t       *cntx_p,
                                     uint32_t       *ref_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user;
    bai_group_t      *p_group = NULL;
    ba_index_t        index = ENTRY_EMPTY;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    err = __bai_validate_lid(p_user, lid, &p_group, &index, NULL);
    if (err) {
        goto out;
    }
    cl_spinlock_acquire(&p_group->lids[index].lock);
    if (cntx_p) {
        *cntx_p = p_group->lids[index].client_context;
    }

    if (ref_p) {
        *ref_p = p_group->lids[index].ref;
    }

    cl_spinlock_release(&p_group->lids[index].lock);

out:
    if (gbin_trace_s) {
        uint32_t cntx, ref;

        if ((p_group == NULL) || (index == ENTRY_EMPTY)) {
            cntx = ENTRY_EMPTY;
            ref = ENTRY_EMPTY;
        } else {
            cntx = p_group->lids[index].client_context;
            ref = p_group->lids[index].ref;
        }

        __bai_trace(BA_CLIENT_CNTX_GET_E,
                    handle,
                    0,
                    0,
                    cntx,
                    ref,
                    index,
                    0,
                    lid,
                    0,
                    err);
    }

    return err;
}


/**
 * Lock a set of table entries
 *
 * @param[in] handle   - Pointer to initialized client handle
 * @param[in] lid      - The logical ID to increment reference count on
 * @param[out] index_p - Pointer to where to store current index for LID
 * @param[out] cntx_p  - Pointer to were to store client provided context
 *
 * @return SX_UTILS_STATUS_SUCCESS - Lock successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle or index_p is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - logical ID already locked
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_lock(ba_handle_t handle, ba_logical_id_t lid, ba_index_t *index_p, uint32_t *cntx_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user = NULL;
    bai_group_t      *p_group = NULL;
    ba_index_t        index = ENTRY_EMPTY;
    uint32_t          group_idx;

    if (!index_p) {
        SX_LOG_ERR("Index pointer is NULL!\n");

        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    err = __bai_validate_lid(p_user, lid, &p_group, &index, NULL);
    if (err) {
        goto out;
    }

    if (p_group->array_map[index] & LS_LOCKED_E) {
        SX_LOG_WRN("handle %p lid 0x%8.8X already locked!\n", handle, lid);

        err = SX_UTILS_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    p_group->array_map[index] |= LS_LOCKED_E;

    /* If they want the context too, return it before updating index */
    if (cntx_p) {
        *cntx_p = p_group->lids[index].client_context;
    }

    /* Calculate the real index */
    group_idx = p_group - p_user->groups;

    index += group_idx * p_user->group_size;

    *index_p = index;


out:
    if (gbin_trace_s) {
        uint32_t cntx, ref;

        if ((p_group == NULL) || (index == ENTRY_EMPTY)) {
            cntx = ENTRY_EMPTY;
            ref = ENTRY_EMPTY;
        } else {
            cntx = p_group->lids[index].client_context;
            ref = p_group->lids[index].ref;
        }

        if (p_group) {
            group_idx = p_group - p_user->groups;
            index += group_idx * p_user->group_size;
        } else {
            index = ENTRY_EMPTY;
        }

        __bai_trace(BA_LOCK_E,
                    handle,
                    0,
                    0,
                    cntx,
                    ref,
                    index,
                    0,
                    lid,
                    0,
                    err);
    }

    return err;
}


/**
 * Unlock a set of table entries
 *
 * @param[in] handle  - Pointer to initialized client handle
 * @param[in] lid     - The logical ID to increment reference count on
 *
 * @return SX_UTILS_STATUS_SUCCESS - Unlock successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle or lid is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_NO_RESOURCES - logical ID not locked
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_unlock(ba_handle_t handle, ba_logical_id_t lid)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user;
    bai_group_t      *p_group;
    ba_index_t        index;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    err = __bai_validate_lid(p_user, lid, &p_group, &index, NULL);
    if (err) {
        goto out;
    }

    if ((p_group->array_map[index] & LS_LOCKED_E) == 0) {
        SX_LOG_WRN("handle %p lid 0x%8.8X not locked!\n", handle, lid);

        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    p_group->array_map[index] &= ~LS_LOCKED_E;

    /* Locks cause relocation to fail when it might have succeeded */
    no_changes_s = FALSE;


out:
    if (gbin_trace_s) {
        __bai_trace(BA_UNLOCK_E,
                    handle,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    lid,
                    0,
                    err);
    }

    return err;
}

/**
 * Lock operation on handle to protect multi thread access
 *
 * @param[in] handle   - Pointer to initialized client handle
 *
 * @return SX_UTILS_STATUS_SUCCESS - Lock successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle or index_p is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - logical ID already locked
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_thread_lock(ba_handle_t handle)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    err = __bai_thread_lock(p_user);
    if (err) {
        goto out;
    }

out:
    if (gbin_trace_s) {
        __bai_trace(BA_THREAD_LOCK_E,
                    handle,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    err);
    }

    return err;
}

/**
 * UnLock operation on handle to protect multi thread access
 *
 * @param[in] handle   - Pointer to initialized client handle
 *
 * @return SX_UTILS_STATUS_SUCCESS - Lock successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle or index_p is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - logical ID already locked
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_thread_unlock(ba_handle_t handle)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    err = __bai_thread_unlock(p_user);
    if (err) {
        goto out;
    }

out:
    if (gbin_trace_s) {
        __bai_trace(BA_THREAD_UNLOCK_E,
                    handle,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    err);
    }

    return err;
}

sx_utils_status_t __bai_thread_lock(bai_user_t *p_user)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    cl_spinlock_acquire(&(p_user->thread_lock));

    return err;
}

sx_utils_status_t __bai_thread_unlock(bai_user_t *p_user)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    cl_spinlock_release(&(p_user->thread_lock));

    return err;
}

/**
 * Swap Bin Allocator meta-data between two LIDs
 *   In support of managing linked lists of blocks, we need to be able to
 * insert or remove a block from the front of the linked list.  Multiple
 * users of a linked list add references to only the first block, so when
 * it moves the reference counts need to move.
 *
 * @param[in] handle  - Pointer to initialized client handle
 * @param[in] lid1    - One logical ID
 * @param[in] lid2    - The other logical ID
 *
 * @return SX_UTILS_STATUS_SUCCESS - Request succeeded
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 */
sx_utils_status_t ba_swap_metadata(ba_handle_t handle, ba_logical_id_t lid1, ba_logical_id_t lid2)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user;
    bai_group_t      *p_group1 = NULL, *p_group2 = NULL;
    ba_index_t        index1 = ENTRY_EMPTY, index2 = ENTRY_EMPTY;
    uint32_t          tmp_ref;

    SX_LOG_DBG("Handle swap - LID 1 - 0x%8.8X  LID 2 - 0x%8.8X\n", lid1, lid2);
    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    err = __bai_validate_lid(p_user, lid1, &p_group1, &index1, NULL);
    if (err) {
        goto out;
    }

    err = __bai_validate_lid(p_user, lid2, &p_group2, &index2, NULL);
    if (err) {
        goto out;
    }
    if (index1 > index2) {
        cl_spinlock_acquire(&p_group1->lids[index1].lock);
        cl_spinlock_acquire(&p_group2->lids[index2].lock);
    } else {
        cl_spinlock_acquire(&p_group2->lids[index2].lock);
        cl_spinlock_acquire(&p_group1->lids[index1].lock);
    }

    /* Swap the reference counts - Simple vs cute xor tricks */
    tmp_ref = p_group1->lids[index1].ref;
    p_group1->lids[index1].ref = p_group2->lids[index2].ref;
    p_group2->lids[index2].ref = tmp_ref;

    cl_spinlock_release(&p_group1->lids[index1].lock);
    cl_spinlock_release(&p_group2->lids[index2].lock);

out:
    if (gbin_trace_s) {
        if ((p_group1 == NULL) || (index1 == ENTRY_EMPTY)) {
            index1 = ENTRY_EMPTY;
        } else {
            index1 = p_group1->lids[index1].ref;
        }

        if ((p_group2 == NULL) || (index2 == ENTRY_EMPTY)) {
            index2 = ENTRY_EMPTY;
        } else {
            index2 = p_group2->lids[index1].ref;
        }

        __bai_trace(BA_SWAP_METADATA_E,
                    handle,
                    0,
                    0,
                    0,
                    0,
                    index1,
                    index2,
                    lid1,
                    lid2,
                    err);
    }

    return err;
}


/**
 * Allocate a set of contiguous table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] type   - Type of entry to allocate
 * @param[in] size   - Number of contiguous entries needed
 * @param[in] cntx   - Initial value of user context associated with this lid
 * @param[out] group_p - Pointer to where to store logical ID for allocation
 *
 * @return SX_UTILS_STATUS_SUCCESS - Allocation successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle or lid_p pointer is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - type not supported
 * @return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE - Size not supported by type
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 */
sx_utils_status_t ba_allocate(ba_handle_t handle, uint32_t type, uint32_t size, uint32_t cntx, ba_logical_id_t *lid_p)
{
    sx_utils_status_t err, err2;
    bai_user_t       *p_user;
    bai_logical_id_t  i_lid;
    ba_logical_id_t   lid = INVALID_LID;
    uint32_t          idx;
    ba_template_t    *p_template;
    uint32_t          free_lines = 0;
    boolean_t         allocated = FALSE;

    if (lid_p == NULL) {
        SX_LOG_WRN("lid pointer is NULL!\n");

        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    /* Sanity check - no valid scenario in which this could occur */
    if (p_user->p_phys_mem == NULL) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Internal error - physical memory pointer for handle %p is NULL!\n",
                   handle);
        goto out;
    }

    /* Make sure the type is supported */
    for (idx = 0; idx < p_user->template_count; idx++) {
        p_template = &p_user->templates[idx];

        if (p_template->type == type) {
            break;
        }

        p_template = NULL;
    }

    if (!p_template) {
        SX_LOG_WRN("type %u not supported!\n", type);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* See if the size is supported by this template */
    err = bai_find_size(p_user, p_template, size, NULL);
    if (err == SX_UTILS_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_WRN("size %u not valid for type %u!\n", size, type);

        err = SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    if (err) {
        goto out;
    }

    /* Hand off to allocation plug-in for doing the work */
    err = bai_alloc(p_user, type, size, cntx, idx, &i_lid);
    if (err) {
        /* In case of no resources, try to process the GC queue synchronously.
         * If there are any objects waiting there to be freed, they'll be freed
         * now, and that might make room.
         */
        if (err == SX_UTILS_STATUS_NO_RESOURCES) {
            /* If user have requested async GC no sync deletion will be performed */
            if ((p_user->options & RELOC_ASYNC_GC_E) != 0) {
                goto out;
            }

            err = gc_object_process_queue(p_user->gc_object_type);
            if (SX_UTILS_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to process GC object queue for %s object type, err = [%s]\n",
                           GC_OBJECT_TYPE_STR(p_user->gc_object_type),
                           SX_UTILS_STATUS_MSG(err));
                goto out;
            }

            err = bai_alloc(p_user, type, size, cntx, idx, &i_lid);
            if (err) {
                goto out;
            }
        } else {
            goto out;
        }
    }

    /* Allocate an external LID and associate it with the internal one */
    err = __bai_allocate_lid(p_user, i_lid, &lid);
    if (err) {
        goto out;
    }
    allocated = TRUE;

    err = bai_user_free_lines_get(p_user, &free_lines);
    if (err) {
        goto out;
    }

    err = gc_object_check_thresholds(p_user->gc_object_type, free_lines);
    if (err) {
        SX_LOG_ERR("Failed to check GC thresholds for object type %s with %u free lines, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(p_user->gc_object_type), free_lines,
                   SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    *lid_p = lid;

    /* Something has changed - Background relocation should check */
    no_changes_s = FALSE;


out:
    if ((err) && (allocated)) {
        err2 = bai_free(p_user, i_lid);
        if (err2) {
            SX_LOG_ERR("Internal error - Internal LID 0x%8.8X fails free\n",
                       i_lid);
        }
    }
    if (gbin_trace_s) {
        __bai_trace(BA_ALLOCATE_E,
                    handle,
                    type,
                    size,
                    cntx,
                    0,
                    0,
                    0,
                    lid,
                    0,
                    err);
    }

    return err;
}

/**
 * Free a previously allocated set of contiguous table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to free
 *
 * @return SX_UTILS_STATUS_SUCCESS - Deallocation successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - lid is locked
 * @return SX_UTILS_STATUS_DB_NOT_EMPTY - The reference count was > 1
 */
sx_utils_status_t ba_free(ba_handle_t handle, ba_logical_id_t lid)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_rc = CL_SUCCESS;
    bai_user_t       *p_user;
    bai_group_t      *p_group;
    bai_logical_id_t  i_lid;
    ba_index_t        index;
    ba_gc_context_t  *p_gc_context = NULL;
    uint32_t          block_size = 0;
    cl_map_item_t    *p_item = NULL;
    bai_lid_info_t   *p_lid = NULL;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    /* Sanity check - no valid scenario in which this could occur */
    if (p_user->p_phys_mem == NULL) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Internal error - physical memory pointer for handle %p is NULL!\n",
                   handle);
        goto out;
    }

    err = __bai_validate_lid(p_user, lid, &p_group, &index, &i_lid);
    if (err) {
        goto out;
    }

    if (p_group->array_map[index] & LS_LOCKED_E) {
        SX_LOG_WRN("handle %p lid 0x%8.8X locked!\n", handle, lid);

        err = SX_UTILS_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    if (p_group->lids[index].ref != 1) {
        SX_LOG_WRN("handle %p lid 0x%8.8X reference count > 1(%u)!\n",
                   handle, lid, p_group->lids[index].ref);

        err = SX_UTILS_STATUS_DB_NOT_EMPTY;
        goto out;
    }

    err = bai_gc_context_get(p_user, &p_gc_context);
    if (err) {
        goto out;
    }

    if (!p_gc_context) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("NULL GC context returned!\n");
        goto out;
    }

    err = bai_block_size(p_group, index, &block_size);
    if (err) {
        SX_LOG_ERR("Failed to get block size of index %u in group, err = [%s]\n",
                   index, SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    /* Remove the mapping */
    p_item = cl_qmap_remove(&p_user->lids_map, lid);
    p_lid = PARENT_STRUCT(p_item, bai_lid_info_t, map_item);
    p_lid->ilid = GROUP_TYPE_FREE;
    cl_rc = id_allocator_put(&(p_user->p_phys_mem->lids_id_allocator), lid);
    if (cl_rc != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Failed to delete LIDs pool index %d, err = [%s]\n",
                   lid, CL_STATUS_MSG(cl_rc));
        goto out;
    }
    cl_qpool_put(&p_user->p_phys_mem->lids_pool, &p_lid->pool_item);

    /* Lock this index, to prevent any relocations on it while queued for
     * garbage collection. */
    p_group->array_map[index] |= LS_LOCKED_E;

    /* Push the block to the garbage collector queue. It will be freed
     * asynchronously in the background. */
    p_gc_context->data.reloc_flow = BA_RELOC_FLOW_NONE;
    p_gc_context->data.i_lid = i_lid;
    p_gc_context->data.handle = handle;
    p_gc_context->data.lid = lid;

    err = gc_object_push(p_user->gc_object_type, p_gc_context,
                         GC_STATE_PENDING_FENCE,
                         block_size, p_user->gc_subtype, i_lid,
                         NULL);
    if (SX_UTILS_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to push GC object type %s (i_lid %u) to GC queue, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(p_user->gc_object_type),
                   i_lid, SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    SX_LOG_DBG("Pushed LID %u (ILID %u) to GC queue\n", lid, i_lid);

out:
    if (gbin_trace_s) {
        __bai_trace(BA_FREE_E,
                    handle,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    lid,
                    0,
                    err);
    }
    if ((err) && (p_gc_context)) {
        bai_gc_context_put(p_gc_context);
    }

    return err;
}

/**
 * Free a previously allocated set of contiguous table entries asynchronous
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] context    - Relocate context
 *
 * @return SX_UTILS_STATUS_SUCCESS - Deallocation successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - lid is locked
 * @return SX_UTILS_STATUS_DB_NOT_EMPTY - The reference count was > 1
 */
sx_utils_status_t ba_free_async(ba_handle_t handle, const void *context)
{
    sx_utils_status_t      err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t            *p_user;
    ba_gc_context_t       *p_gc_context = NULL;
    ba_relocate_context_t *p_ba_relocate_context = NULL;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    /* Sanity check - no valid scenario in which this could occur */
    if (p_user->p_phys_mem == NULL) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Internal error - physical memory pointer for handle %p is NULL!\n",
                   handle);
        goto out;
    }

    p_ba_relocate_context = (ba_relocate_context_t*)context;

    if (!context) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("NULL relocate context provided!\n");
        goto out;
    }
    err = bai_gc_context_get(p_user, &p_gc_context);
    if (err) {
        goto out;
    }

    if (!p_gc_context) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("NULL GC context returned!\n");
        goto out;
    }

    err = __bai_gc_object_push(p_user,
                               p_gc_context,
                               p_ba_relocate_context->ilid,
                               p_ba_relocate_context->size,
                               p_ba_relocate_context->lid,
                               BA_RELOC_FLOW_SYNC);
    if (err) {
        SX_LOG_ERR("Failed to GC object push size %u in group, err = [%s]\n",
                   p_ba_relocate_context->size, SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    SX_LOG_DBG("Pushed ILID %u to GC queue\n",  p_ba_relocate_context->ilid);

out:
    if ((err) && (p_gc_context)) {
        bai_gc_context_put(p_gc_context);
    }

    return err;
}
/**
 * Modify reference count on previously allocated set of table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to modify count on
 * @param[in] val    - The increment/decrement value
 *
 * @return SX_UTILS_STATUS_SUCCESS - Increment successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE - Reference count would
 *                                               exceed max count.
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_ref_modify(ba_handle_t handle, ba_logical_id_t lid, int32_t val)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_user_t       *p_user;
    bai_group_t      *p_group;
    ba_index_t        index;
    uint32_t          cnt;
    boolean_t         ref_lock = FALSE;

    err = __bai_validate_handle(handle, &p_user);
    if (err) {
        goto out;
    }

    err = __bai_validate_lid(p_user, lid, &p_group, &index, NULL);
    if (err) {
        goto out;
    }

    cl_spinlock_acquire(&p_group->lids[index].lock);
    ref_lock = TRUE;
    /* Nothing to do - Not very interesting but easy */
    if (val == 0) {
        SX_LOG_INF("Called with value 0!\n");

        goto out;
    }

    if (val < 0) {
        cnt = (uint32_t)abs(val);

        /* Can't decrease reference count below 0 */
        if (cnt >= p_group->lids[index].ref) {
            SX_LOG_WRN("User %p lid 0x%8.8X val %d invalid with current(%u)!\n",
                       handle, lid, val, p_group->lids[index].ref);

            err = SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        p_group->lids[index].ref -= cnt;
        SX_LOG_DBG("LID 0x%8.8X idx 0x%8.8X ref decreased by -%u new count %u\n",
                   lid,
                   index,
                   cnt,
                   p_group->lids[index].ref);

        goto out;
    }

    cnt = (uint32_t)val;

    /* Can't increase reference count above maximum value */
    if (cnt > MAX_REF_CNT) {
        SX_LOG_WRN("User %p lid 0x%8.8X val %u exceeds MAX_REF_CNT(%u)!\n",
                   handle, lid, cnt, MAX_REF_CNT);

        err = SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Can't add enough that pushes total above maximum value */
    if (cnt > (MAX_REF_CNT - p_group->lids[index].ref)) {
        SX_LOG_WRN("User %p lid 0x%8.8X val=%u current=%u exceeds max(%u)!\n",
                   handle, lid, cnt, p_group->lids[index].ref, MAX_REF_CNT);

        err = SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    p_group->lids[index].ref += cnt;
    SX_LOG_DBG("LID 0x%8.8X idx 0x%8.8X increased by +%u new count %u \n", lid, index, cnt, p_group->lids[index].ref);

out:
    if (ref_lock == TRUE) {
        cl_spinlock_release(&p_group->lids[index].lock);
    }
    if (gbin_trace_s) {
        __bai_trace(BA_REF_MODIFY_E,
                    handle,
                    0,
                    0,
                    0,
                    val,
                    0,
                    0,
                    lid,
                    0,
                    err);
    }

    return err;
}

sx_utils_status_t ba_relocation_info_output(const char *relocation_info_str, ...)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    va_list           args;

    cl_spinlock_acquire(&relocation_info_stream_lock);

    if (relocation_info_output_stream_p == NULL) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    va_start(args, relocation_info_str);
    vfprintf(relocation_info_output_stream_p, relocation_info_str, args);
    va_end(args);

out:
    cl_spinlock_release(&relocation_info_stream_lock);
    return err;
}

sx_utils_status_t ba_relocation_info_stream_set(FILE* stream)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    cl_spinlock_acquire(&relocation_info_stream_lock);

    relocation_info_output_stream_p = stream;

    cl_spinlock_release(&relocation_info_stream_lock);

    return err;
}


void ba_relocation_handler(FILE* stream)
{
    sx_utils_status_t err;
    bai_user_t       *p_user;
    uint32_t          i;


    cl_spinlock_acquire(&relocation_handler_lock);

    ba_relocation_info_stream_set(stream);

    if (!init_done_s) {
        goto out;
    }

    if (no_changes_s) {
        goto out;
    }
    no_changes_s = TRUE;

    for (i = 0; i < BIN_ALLOC_MAX_USERS; i++) {
        p_user = &users_s[i];

        if (!p_user->allocated) {
            continue;
        }

        /* User must have requested async relocation */
        if ((p_user->options & RELOC_ASYNC_E) == 0) {
            continue;
        }

        err = bai_async_relocate(p_user);
        if (err == SX_UTILS_STATUS_SUCCESS) {
            continue;
        }

        /* If unable to relocate, try the next user */
        if (err == SX_UTILS_STATUS_NO_RESOURCES) {
            err = SX_UTILS_STATUS_SUCCESS;
            continue;
        }

        /* Partially complete means we need to call again */
        if (err == SX_UTILS_STATUS_PARTIALLY_COMPLETE) {
            no_changes_s = FALSE;
            err = SX_UTILS_STATUS_SUCCESS;
            continue;
        }

        /* Unexpected errors - disable async relocation */
        SX_LOG_ERR("Async relocation disabled due to error!\n");
        p_user->options &= ~(RELOC_ASYNC_E | RELOC_ASYNC_GC_E);
        goto out;
    }


out:
    ba_relocation_info_stream_set(NULL);
    cl_spinlock_release(&relocation_handler_lock);
    return;
}

/**
 * Timer function used to drive async relocation
 */
void ba_timer_handler(void)
{
    ba_relocation_handler(NULL);
}

static void __debug_cmd_ba_relocation(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    if (argc != 0) {
        dbg_utils_print(stream, "Invalid params\n");
        return;
    }

    fprintf(stream,
            "Start of debug cmd BA (Bin Allocator) relocation.\nThis attempts to coalesce "
            "small blocks of free lines in various groups into larger chunks.\n"
            "Currently, a notice of relocation will be printed only on "
            "relocations of KVD Linear Manager users.\n");

    ba_relocation_handler(stream);

    fprintf(stream, "End of debug cmd BA relocation.\n");
}

sx_utils_status_t ba_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}
