/*
 * Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __UTILS_GBIN_INTERNAL_H__
#define __UTILS_GBIN_INTERNAL_H__

#include <sx/utils/gbin_allocator.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <../utils/gen_utils.h>
#include <sx/utils/id_allocator.h>
/************************************************
 *  Local Defines
 ***********************************************/

/*
 * ENTRY_EMPTY
 *   In places where an index into the lines of a group are used, this value
 * means no index.
 *
 * MAX_USERS
 *   The maximum number of clients that Bin Allocator supports.
 *
 * MAX_GROUPS
 *   The maximum number of groups that can be supported
 *
 * MAX_HOLES
 *   The maximum number of holes we cache for a group
 *
 * MIN_RUNS
 *   Blocks less than this size will not use run length encoding.  The
 * minimum value is 2 (start of allocation + final line of allocation)
 * + the size of a uint32_t.
 *
 * MAX_REF_CNT
 *   The maximum reference count allowed on a single LID
 *
 * INVALID_LID
 *   No external LID has this value
 *
 * BIN_ALLOC_MAX_SIZE_LOOKUP
 *   A lookup table that converts from size to an index in a template
 * alloc_sizes[] array.  This avoids a linear search.
 *
 */
#define ENTRY_EMPTY               (0xffffffff)
#define MAX_USERS                 (10)
#define MAX_GROUPS                (2048)
#define MAX_HOLES                 (16)
#define MIN_RUNS                  ((sizeof(uint32_t) + 2))
#define MAX_REF_CNT               (0x7ffffffe)
#define INVALID_LID               (0)
#define BIN_ALLOC_MAX_SIZE_LOOKUP (512)

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

typedef uint32_t bai_logical_id_t;

/*
 * line_state
 *   Allocation is controlled using the per-group array_map[] structure. One
 * byte per-line is used to track allocation and locking status for each
 * line.
 *
 * Examples:
 *   1)  4 map bytes for an unlocked 4 line block: 0x01 0x02 0x02 0x04
 *   2)  2 map bytes for a locked 2 line block: 0x09 0x04
 *   3)  1 map byte for an unlocked 1 line block: 0x05
 *   4) 12 map bytes for an unlocked 12 line block: 0x11 0x0C 0x00 0x00 0x00 0 0 0 0 0 0 0x04
 */
typedef enum line_state {
    LS_FIRST_E  = (1 << 0),
    LS_MIDDLE_E = (1 << 1),
    LS_LAST_E   = (1 << 2),
    LS_LOCKED_E = (1 << 3),
    LS_RLE_E    = (1 << 4),
} line_state_e;


/*
 * hole_state
 *   When looking at a block, there might be a hole to the left, a hole to
 * the right, holes on both sides, and holes in neither.  If a hole exists,
 * it is either big enough for the maximum allocation or not.  This comes
 * down to three values to describe a hole
 */
typedef enum hole_state {
    HOLE_NONE_E,
    HOLE_SMALL_E,
    HOLE_MAX_E,
} hole_state_e;


/*
 * API numbers
 *   When having problems with BA failing, it is possible to have every API
 * call generate a trace record that can be converted into a unit test.
 */
typedef enum gbin_api {
    GBIN_API_DONE = 0,

    BA_INIT_E = 1,
    BA_DEINIT_E,
    BA_CLIENT_INIT_E,
    BA_CLIENT_DEINIT_E,
    BA_ALLOCATE_E,
    BA_FREE_E,
    BA_FREE_ASYNC_E,
    BA_REF_INC_E,
    BA_REF_DEC_E,
    BA_LOCK_E,
    BA_UNLOCK_E,
    BA_THREAD_LOCK_E,
    BA_THREAD_UNLOCK_E,
    BA_CLIENT_CNTX_SET_E,
    BA_CLIENT_CNTX_GET_E,
    BA_SWAP_METADATA_E,
    BA_REF_MODIFY_E,

    BA_CB_RELOCATE_E,
    BA_CB_ALLOC_GROUP_E,
    BA_CB_FREE_GROUP_E,
} gbin_api_e;

/*
 * API test vector
 */
typedef struct gbin_api_test {
    gbin_api_e        func;
    uint32_t          handle;   /* Index into user_s[] */
    uint32_t          type;
    uint32_t          size;
    uint32_t          cntx;
    uint32_t          ref;
    uint32_t          index1;
    uint32_t          index2;
    ba_logical_id_t   lid1;
    ba_logical_id_t   lid2;
    sx_utils_status_t err;
} gbin_api_test_t;


/*
 * Internal per-allocation size state
 *   Contains configuration info from user init + current active state
 */
typedef struct bai_bucket {
    uint16_t size;      /* Length of this allocation */
    int32_t  increment; /* Based on alignment and size */
    uint32_t alloc_cnt; /* Number of active blocks of this size */
} bai_bucket_t;


/*
 * Per-LID state
 *   Contains internal per-LID state (ex: reference count) and a bit of
 * user managed state (avoids them having to have a DB).
 */
typedef struct gbi_lid {
    uint32_t      ref;
    uint32_t      client_context;
    cl_spinlock_t lock;
} bai_lid_data_t;


/*
 * Per-hole state
 *   Unallocated space in a group may be cached.  This structure contains
 * info needed to find one hole.
 */
typedef struct bai_hole {
    uint32_t offset;
    uint32_t len;
} bai_hole_t;


/*
 * Internal group state
 *   Contains configuration info from user init + current active state
 */
typedef struct bai_group {
    uint32_t type;              /* type=0 means group is free */
    uint32_t options;           /* Relocation options */
    uint8_t *array_map;         /* one byte/line holds line_state */

    /* Set from template info */
    ba_template_t *p_template;     /* Template we got the data from */
    uint32_t       alloc_size;     /* Length of array_map[] for alloc */
    uint16_t       max_alloc_size; /* The largest entry in buckets[] */
    uint32_t       free_lines;     /* Number of array_map[] lines marked free */
    uint8_t        bucket_cnt;     /* Number of entries in buckets[] */
    bai_bucket_t   buckets[BIN_ALLOC_MAX_ALLOC_SIZES];

    /* Restrictions on alignment for blocks out of this group */
    ba_alignment_e align;

    /* User configuration and currently active threshold */
    uint8_t r_thresh;
    uint8_t act_thresh;

    /* User configuration blocks to relocate per-cycle + active */
    uint8_t r_count;
    uint8_t act_count;

    /* Number of blocks relocated in background since last alloc/free */
    uint32_t reloc_cnt;

    /* Per-lid state */
    bai_lid_data_t *lids;

    /* Information about empty holes that might hold blocks */
    boolean_t  hole_cache_valid;
    bai_hole_t holes[MAX_HOLES];

    /*
     * Allocation cache values - only valid when alloc_cache_valid == TRUE
     *   - c_valid
     *     The cache_* elements are valid.  Cleared whenever a block is
     *     allocated or freed.  Set when __bai_cache_update() runs.
     *
     *   - c_max_hole
     *     The size of the largest unallocated space in this group.
     *     There may be more than 1 such space.
     *
     *   - c_max_size
     *     If the amount of free space in the group is less than the
     *     largest valid block size, there is no reason to relocate all
     *     the free space into a single chunk.  Instead we relocate until
     *     free blocks are 'cache_max_size'.
     *
     *   - c_cost_sum
     *     The sum of the relocation costs of all blocks in this group.
     *
     *   - c_efficiency
     *     A value in [0..101] that roughly reflects the amount of
     *     fragmentation in the group.  A value >= 100 means the group is
     *     as defragmented as possible, while a value of 0 means it is
     *     badly fragmented.
     */
    boolean_t alloc_cache_valid;
    uint16_t  c_max_hole;
    uint16_t  c_max_size;
    uint32_t  c_cost_sum;
    uint16_t  c_efficiency;
} bai_group_t;


/*
 * Allocated blocks
 *   The relocation logic uses a sorted array of blocks to order single
 * block movement requests.
 */
typedef struct bai_block_element {
    uint32_t offset;
    uint32_t len;
    uint32_t ref;
} bai_block_element_t;


/*
 * Per-template size lookup table
 *   In order to avoid a linear search of the per-template list of valid
 * allocation sizes, we provide a direct lookup table for all sizes
 * below BIN_ALLOC_MAX_SIZE_LOOKUP and the biggest.
 */
typedef struct bai_lookup_size {
    uint16_t index[BIN_ALLOC_MAX_SIZE_LOOKUP + 1];
    uint16_t slow_start;

    /* The last group we allocated from for this type */
    bai_group_t *group_last;

    /* Per-type relocation summary data */
    uint32_t     total_free_lines;
    uint32_t     total_groups;
    bai_group_t *group_min_cost;
} bai_lookup_size_t;

/* Physical memory context.
 *   Each user is mapped to a physical memory context, where several users can
 * be mapped to the same physical memory.
 */
typedef struct bai_phys_memory {
    cl_qpool_t     lids_pool;
    char           phys_mem_name[BIN_ALLOC_MAX_PHYS_MEM_NAME];
    uint32_t       phys_mem_size;
    id_allocator_t lids_id_allocator;
} bai_phys_memory_t;

/* LID info
 *   Contains mapping of user LID to internal LID
 */
typedef struct bai_lid_info {
    cl_pool_item_t   pool_item;
    cl_map_item_t    map_item;
    ba_logical_id_t  lid;
    bai_logical_id_t ilid;
} bai_lid_info_t;

/*
 * Internal user context
 *
 * group_cnt - The maximum number of type specific contiguous suballocation
 *             regions for this register space.
 * groups[]  - Array of group_cnt group state objects
 */
typedef struct bai_user {
    boolean_t    allocated;
    uint32_t     options;
    uint16_t     group_cnt;
    bai_group_t *groups;

    /* All groups for this user have this many lines */
    uint32_t group_size;

    /* Type info passed from init */
    uint8_t           template_count;
    ba_template_t     templates[BIN_ALLOC_MAX_TYPES];
    bai_lookup_size_t lookup_size[BIN_ALLOC_MAX_TYPES];

    /* Convert external client LID to internal LID */
    cl_qmap_t lids_map;

    /* Per-user working storage - Avoids malloc/free */
    uint32_t             cnt_blocks;
    bai_group_t         *p_drain;
    bai_block_element_t *blocks;

    /* Shift values to create the lid */
    uint32_t shift_type;
    uint32_t mask_type;
    uint32_t shift_group;
    uint32_t mask_group;
    uint32_t mask_line;

    /* Garbage collector data */
    gc_object_type_t              gc_object_type;
    gc_object_subtype_t           gc_subtype;
    gc_fence_type_t               gc_fence_type;
    gc_object_post_completion_pfn gc_post_completoion_cb;

    /* Physical memory mapped to this user */
    bai_phys_memory_t *p_phys_mem;
    cl_spinlock_t      thread_lock;

    /* Virtual memory size mapped to this user */
    uint32_t vm_size;

    /* A callback that is called just before BA object is freed */
    ba_cb_free_object_t free_object_cb;
} bai_user_t;

typedef struct ba_gc_data {
    ba_reloc_flow_t  reloc_flow;
    bai_logical_id_t i_lid;
    ba_handle_t      handle;
    ba_logical_id_t  lid;
} ba_gc_data_t;

typedef struct ba_gc_context {
    cl_pool_item_t pool_item;
    ba_gc_data_t   data;
} ba_gc_context_t;

typedef struct ba_relocate_context {
    cl_pool_item_t   pool_item;
    bai_logical_id_t ilid;
    uint32_t         size;
    ba_logical_id_t  lid;
} ba_relocate_context_t;


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Allocate a set of contiguous table entries
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] type   - Type of entry to allocate
 * @param[in] size   - Number of contiguous entries needed
 * @param[in] cntx   - Initial value of user context associated with this lid
 * @param[in] idx    - Index in p_user->templates[] of template for type
 * @param[out] lid_p - Pointer to where to store logical ID for allocation
 *
 * @return SX_UTILS_STATUS_SUCCESS - Allocation successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 */
sx_utils_status_t bai_alloc(bai_user_t       *p_user,
                            uint32_t          type,
                            uint32_t          size,
                            uint32_t          cntx,
                            uint32_t          idx,
                            bai_logical_id_t *lid_p);

/**
 * Free a previously allocated set of contiguous table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to free
 *
 * @return SX_UTILS_STATUS_SUCCESS - Deallocation successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t bai_free(bai_user_t *p_user, bai_logical_id_t lid);

/**
 * Validate a user structure can be used
 *
 * @param[in] p_user  - User to check
 * @param[in] fn      - Name of calling function for error log
 *
 * @return SX_UTILS_STATUS_SUCCESS - Subsystem initialized
 * @return SX_UTILS_STATUS_ERROR - Invalid user and/or group pointer
 */
sx_utils_status_t bai_validate_user(const bai_user_t *p_user, const char *fn);

/**
 * Extract and validate the fields in an allocated internal LID
 *
 * @param[in] p_user - User context that holds i_lid
 * @param[in] i_lid - Internal lid value
 * @param[in] fn - Pointer to name of function for error log
 * @param[out] p_type - Pointer to where to store type
 * @param[out] p_group_idx - Pointer to where to store group index
 * @param[out] p_line_idx - Pointer to where to store line index
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - r_lid is NULL
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal LID is not valid
 */
sx_utils_status_t bai_extract_i_lid(bai_user_t      *p_user,
                                    bai_logical_id_t i_lid,
                                    const char      *fn,
                                    uint32_t        *p_type,
                                    uint32_t        *p_group_idx,
                                    uint32_t        *p_line_idx);


/**
 * Return 'index' in to <user, template> of 'size'
 *   Used both to verify size is valid, and return index of group bucket
 * associated with this size.
 *
 * @param[in] p_user     - User context to select template in
 * @param[in] p_template - The template to search for requested size
 * @param[in] size       - The allocation size requested
 * @param[out] index_p   - Optional location to store index
 *
 * @return SX_UTILS_STATUS_SUCCESS - Location found
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND - size not in template
 */
sx_utils_status_t bai_find_size(bai_user_t    *p_user,
                                ba_template_t *p_template,
                                uint32_t       size,
                                uint32_t      *index_p);


/**
 * Implement async relocation for a single user
 *   Called by the SDK timer thread to attempt to coalesce small blocks of
 * free lines in various groups into larger chunks.
 *
 * @param[in] p_user - Pointer to user context to defragment
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Try searching line-by-line
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t bai_async_relocate(bai_user_t *p_user);

/**
 * Update group cache
 *   The group cache is not needed for most logic so the cost of keeping
 * it up to date is not worthwhile.  Instead, things that cause a
 * full scan of group allocation logic to calculate new cache values
 * will usually just invalidate it.  Then functions that require up
 * to date cache values, can call this function to recalculate them.
 *
 * @param[in/out] p_group - The group to update; out is cache_* values
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - p_group is NULL
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal error
 */
sx_utils_status_t bai_cache_update(bai_group_t *p_group);

/**
 * Validate allocation and return size
 *
 * @param[in] p_group - Pointer to group containing allocation
 * @param[in] offset - Offset of first line of allocation
 * @param[out] size_p - Pointer to where to start size (optional)
 *
 * @return SX_UTILS_STATUS_SUCCESS - Successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t bai_block_size(bai_group_t *p_group,
                                 uint32_t     offset,
                                 uint32_t    *size_p);

/**
 * Lookup LID that owns a block
 *   - This is VERY inefficient.  Don't use in performance path...
 *
 * @param[in] p_user - User context that owns the group
 * @param[in] p_group - Group containing block
 * @param[in] offset - Offset of first line of the block
 * @param[out] lid_p - Pointer to where to store the LID
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - Null parameter(s) passed
 * @retrun SX_UTILS_STATUS_PARAM_ERROR - offset or group invalid
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND - No lid maps this offset
 */
sx_utils_status_t bai_offset_to_lid(bai_user_t      *p_user,
                                    bai_group_t     *p_group,
                                    uint32_t         offset,
                                    ba_logical_id_t *ilid_p);


/**
 * Invoke GC Object Push
 *
 * NOTE: When we go multi-threaded, locks are required here.
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] p_gc_context
 * @param[in] iLID -
 * @param[in] size - Length of the block being moved
 * @param[in] reloc_flow - relocation flow type initiating this relocation
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Relocation failed badly
 * @return SX_UTILS_STATUS_ERROR - Relocation failed but no wasted space
 */
sx_utils_status_t __bai_gc_object_push(bai_user_t      *p_user,
                                       ba_gc_context_t *p_gc_context,
                                       bai_logical_id_t iLID,
                                       uint32_t         size,
                                       ba_logical_id_t  lid,
                                       ba_reloc_flow_t  reloc_flow);
/**
 * Initialize the GC context pool.
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_ALREADY_INITIALIZED - Pool is already initialized
 * @return SX_UTILS_STATUS_ERROR - Internal complib error
 */
sx_utils_status_t bai_gc_context_pool_init(void);

/**
 * Deinitialize the GC context pool
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Pool is not initialized
 */
sx_utils_status_t bai_gc_context_pool_deinit(void);

/**
 * Get a free entry from the GC context pool.
 *
 * @param[in] p_user - User context for which entry is needed
 * @param[out] p_gc_context - Pointer to free GC context entry
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - Null parameter(s) passed
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Pool is not initialized
 * @return SX_UTILS_STATUS_NO_MEMORY - No memory available
 * @return SX_UTILS_STATUS_ERROR - Internal complib error
 */
sx_utils_status_t bai_gc_context_get(bai_user_t       *p_user,
                                     ba_gc_context_t **p_gc_context);

/**
 * Return an entry to the GC context pool.
 *
 * @param[in] p_gc_context - Entry to be returned
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - Null parameter(s) passed
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Pool is not initialized
 */
sx_utils_status_t bai_gc_context_put(ba_gc_context_t *p_gc_context);

/**
 * Remove a block from a group - No per-lid bookkeeping updates
 *
 * @param[in] p_group - Group containing the block
 * @param[in] offset - Offset of the block
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t bai_block_free(bai_group_t *p_group, uint32_t offset);

/**
 * Free a group when it has no more allocation
 *
 * @param[in] p_user - User context that owns the group
 * @param[in] p_group - Group containing the block
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_ERROR - Customer callback fails or not active
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - Group has active allocations
 */
sx_utils_status_t bai_free_group(bai_user_t *p_user, bai_group_t *p_group);

/**
 * Get the number of free lines available to a user.
 *
 * @param[in] p_user - User for which we are inquiring
 * @param[out] p_free_lines - Number of free lines available to user.
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - Null parameter(s) passed
 */
sx_utils_status_t bai_user_free_lines_get(bai_user_t *p_user,
                                          uint32_t   *p_free_lines);

/**
 * Initialize the Relocate context pool.
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_ALREADY_INITIALIZED - Pool is already initialized
 * @return SX_UTILS_STATUS_ERROR - Internal complib error
 */
sx_utils_status_t bai_relocate_context_pool_init(void);

/**
 * Deinitialize the Relocate context pool
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Pool is not initialized
 */
sx_utils_status_t bai_relocate_context_pool_deinit(void);

/**
 * Get a free entry from the Relocate context pool.
 *
 * @param[in] p_user - User context for which entry is needed
 * @param[out] p_relocate_context - Pointer to free Relocate context entry
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - Null parameter(s) passed
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Pool is not initialized
 * @return SX_UTILS_STATUS_NO_MEMORY - No memory available
 * @return SX_UTILS_STATUS_ERROR - Internal complib error
 */
sx_utils_status_t bai_relocate_context_get(bai_user_t             *p_user,
                                           ba_relocate_context_t **p_relocate_context);

/**
 * Return an entry to the Relocate context pool.
 *
 * @param[in] p_relocate_context - Entry to be returned
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - Null parameter(s) passed
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Pool is not initialized
 */
sx_utils_status_t bai_relocate_context_put(ba_relocate_context_t *p_relocate_context);

/**
 * Lock operation on handle to protect multi thread access
 *
 * @param[in] p_user - User context for which entry is needed
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - Null parameter(s) passed
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Pool is not initialized
 * @return SX_UTILS_STATUS_NO_MEMORY - No memory available
 * @return SX_UTILS_STATUS_ERROR - Internal complib error
 */
sx_utils_status_t __bai_thread_lock(bai_user_t *p_user);

/**
 * Unlock operation on handle to protect multi thread access
 *
 * @param[in] p_user - User context for which entry is needed
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - Null parameter(s) passed
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Pool is not initialized
 * @return SX_UTILS_STATUS_NO_MEMORY - No memory available
 * @return SX_UTILS_STATUS_ERROR - Internal complib error
 */
sx_utils_status_t __bai_thread_unlock(bai_user_t *p_user);

#endif /* __UTILS_GBIN_INTERNAL_H__ */
