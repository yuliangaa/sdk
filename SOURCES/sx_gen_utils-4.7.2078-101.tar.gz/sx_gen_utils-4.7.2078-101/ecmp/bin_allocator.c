/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <unistd.h>
#include <string.h>
#include <sx/utils/bin_allocator.h>
#include <../utils/gen_utils.h>
#include <complib/cl_dbg.h>

#undef  __MODULE__
#define __MODULE__ BIN_ALLOCATOR


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/


static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

#define NUM_OF_ENTRIES_PER_PAGE_MASK (NUM_OF_ENTRIES_PER_PAGE - 1)

#if NUM_OF_ENTRIES_PER_PAGE > 64
    #error \
    Please fix bin_entry_t.free_slots so it will contains ALL slots bitmasks (right now it is 64bit for max 64 entires)
#endif

/* @see bin_block_t.index translate from index to page number */
#define PAGE(x) ((x) >> NUM_OF_ENTRIES_PER_PAGE_SHIFT)
/* @see bin_block_t.index translate from index to page offset */
#define INDEX(x) ((x) & NUM_OF_ENTRIES_PER_PAGE_MASK)

/**
 * Index translate from page-type to bin locations
 */
#define BINTYPE_TO_PAGETYPE(x) ((x) + 1)
#define PAGETYPE_TO_BINTYPE(x) ((x) - 1)

/**
 * The number of bits used for
 */
#define MAX_BITS_PER_PAGE(page) (NUM_OF_ENTRIES_PER_PAGE >> PAGETYPE_TO_BINTYPE((page)->page_type))

/**
 * Helper macro. Test whether @__bin_page_entry_t* is inside @bin_database_t.not_full_bins or inside @bin_database_t.full_bins
 */
#define IS_PAGE_IN_FULL_LIST(page) ((((page)->free_slots) == 0) && (__bin_test_half_full(page)))
#define IS_PAGE_EMPTY(page)        ((((page)->free_slots) & (page)->free_slots_mask) == (page)->free_slots_mask)
#define IS_PAGE_EMPTY_HALF(page)   ((((page)->half_slots) & (page)->half_slots_mask) == (page)->half_slots_mask)
#define IS_PAGE_EMPTY_DOUBLE(page) ((((page)->double_slots) & (page)->double_slots_mask) == (page)->double_slots_mask)

#define IS_PAGE_MIXED(page) (!(IS_PAGE_EMPTY_HALF(page) && IS_PAGE_EMPTY_DOUBLE(page)))

#define CLR_FREE_SLOTS(page)                                                               \
    { (page)->free_slots = 1;                                                              \
      (page)->free_slots = (MAX_BITS_PER_PAGE(page) == 64) ? 0xFFFFFFFFFFFFFFFFLL :        \
                           ((page)->free_slots << MAX_BITS_PER_PAGE(page)) - 1;            \
      (page)->free_slots_mask = (page)->free_slots;                                        \
      (page)->double_slots = 1;                                                            \
      (page)->double_slots = ((page)->double_slots << (MAX_BITS_PER_PAGE(page) >> 1)) - 1; \
      (page)->half_slots = 1;                                                              \
      (page)->half_slots = (MAX_BITS_PER_PAGE(page) == 32) ? 0xFFFFFFFFFFFFFFFFLL :        \
                           ((page)->half_slots << (MAX_BITS_PER_PAGE(page) << 1)) - 1;     \
      (page)->half_slots_mask = (page)->half_slots;                                        \
      (page)->double_slots_mask = (page)->double_slots;                                    \
    }

typedef enum {
    HALF_SLOT_E,
    SLOT_E,
    DOUBLE_SLOT_E
} allocation_type_e;

/**
 * The pool is divided to NUM_OF_PAGES pages
 * Each page contains up to NUM_OF_ENTRIES_PER_PAGE entries depending on internal division
 */
typedef struct {
    /* There is a pool of pages as well as hash for page id to this structure */
    cl_pool_item_t pool_item;
    cl_map_item_t  map_item;
    cl_list_item_t list_item;
    cl_qlist_t   * bin;

    /**
     * The page first entry is at page_id*NUM_OF_ENTRIES_PER_PAGE index of the pool table
     */
    uint32_t page_id;

    /**
     * Each page is typed according to it's number of elements. Page of type 1 means that it contains NUM_OF_ENTRIES_PER_PAGE entries
     * Page of type 2 means it contains NUM_OF_ENTRIES_PER_PAGE/2 entries, and so on... until NUM_OF_ENTRIES_PER_PAGE/NUM_OF_ENTRIES_PER_PAGE page
     * This also mark on which bin the page is located
     * 0 mark a free page
     */
    int page_type;

    /**
     * A bitmask marking which bit is free in the table. 0 means occupied, 1 means free. Double slots and half slots are also marked as occupied here
     */
    uint64_t free_slots;

    /**
     * A bitmask marking which bit is a half slot. 0 means half slot, 1 means unknown.
     * The size of the bitmask is twice is much of free_slots
     */
    uint64_t half_slots;

    /**
     * A bitmask marking which bit is a double slot. 0 means double slot, 1 means unknown.
     * The size of the bitmask is half of free_slots
     */
    uint64_t double_slots;

    /**
     * free_slots state when the page is empty. Used to resolve older 32bit compiler issues
     */
    uint64_t free_slots_mask;
    uint64_t half_slots_mask;
    uint64_t double_slots_mask;
} __bin_page_entry_t;


#define NUM_OF_BINS (NUM_OF_ENTRIES_PER_PAGE_SHIFT + 1)
static const unsigned int bin_pool_scheme_bin_size_s[NUM_OF_BINS] = {1, 2, 4, 8, 16, 32, 64};

typedef struct {
    cl_qpool_t page_pool;
    /**
     * A page contains @NUM_OF_ENTRIES_PER_PAGE neigh entries
     * The paged pool contains @NUM_OF_PAGES pages
     * The type of each page is defined in @__bin_page_entry_t
     */
    cl_qlist_t free_page_list;

    /*
     * Contains a hash from page index into @__bin_page_entry_t structure
     */
    cl_qmap_t paged_map;

    /**
     * Contains a list of not fully allocated page per bin. Not fully allocated means that the pages contains some free slots
     * The type of each bin is defined in @__bin_page_entry_t
     */
    cl_qlist_t not_full_bins[NUM_OF_BINS];

    /**
     * Contains a list of mixed slots
     * The type of each bin is defined in @__bin_page_entry_t
     */
    cl_qlist_t mixed_not_full_bins[NUM_OF_BINS];
    cl_qlist_t mixed_full_bins[NUM_OF_BINS];

    /**
     * Contains a list of fully allocated slots per page per bin.
     * The type of each bin is defined in @__bin_page_entry_t
     */
    cl_qlist_t full_bins[NUM_OF_BINS];

    /**
     * User-supplied relocation API
     */
    bin_relocation_t      relocate;
    bin_relocation_cost_t relocate_cost;

    /**
     * A starting offset of the allocation table
     */
    uint32_t start_index;
    /**
     * The amount of entries in the allocation table
     */
    uint32_t page_count;

    /**
     * The relocation counters + threshold. Updates per every defrag() call
     */
    uint32_t reloc_counter;
    uint32_t old_reloc_counter;
    uint32_t relocation_threshold;

    /**
     * @see bin_defrag_features_e
     */
    bin_defrag_features_t defrag_features;
} __bin_database_t;


/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

/************************************************************************/

/**
 * Return a page to the free pool
 */
static void __bin_free_page(__bin_database_t* bin, __bin_page_entry_t* page)
{
    memset(&page->list_item, 0, sizeof(cl_list_item_t));
    page->page_type = 0;

    cl_qlist_insert_head(&bin->free_page_list, &page->list_item);
    page->bin = &bin->free_page_list;
}

/**
 * Test if all half are fully allocated. Assumes all free-slots are taken
 */
static int __bin_test_half_full(__bin_page_entry_t* page)
{
    uint64_t     mask = ((page->half_slots >> 1) ^ page->half_slots) & (0x5555555555555555LL);
    unsigned int index = (ffsll(mask) - 1);

    return (index > (unsigned int)(MAX_BITS_PER_PAGE(page) << 1)) || ((index == 0) && !(mask & 1));
}

static unsigned int __bin_calculate_page_offset(__bin_page_entry_t* page, unsigned int index, int half_index)
{
    unsigned int offset =
        (page->page_id << NUM_OF_ENTRIES_PER_PAGE_SHIFT) | (index << PAGETYPE_TO_BINTYPE(page->page_type));

    if (half_index) {
        offset += 1 << PAGETYPE_TO_BINTYPE(page->page_type - 1);
    }

    return offset;
}

static uint64_t __bits_duplicate(uint64_t mask)
{
    uint64_t ret = 0;
    uint64_t one = 1;
    int      i = 0;

    for (; i < 32; i++) {
        ret |= ((mask & (one << i)) * 3) << i;
    }

    return ret;
}

static void __bin_move_page_to_bin(__bin_database_t* db, __bin_page_entry_t* page)
{
    if (IS_PAGE_IN_FULL_LIST(page)) {
        if (IS_PAGE_MIXED(page)) {
            cl_qlist_insert_tail(&db->mixed_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
            page->bin = &db->mixed_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)];
        } else {
            cl_qlist_insert_tail(&db->full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
            page->bin = &db->full_bins[PAGETYPE_TO_BINTYPE(page->page_type)];
        }
    } else {
        if (IS_PAGE_MIXED(page)) {
            cl_qlist_insert_tail(&db->mixed_not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
            page->bin = &db->mixed_not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)];
        } else {
            cl_qlist_insert_tail(&db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
            page->bin = &db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)];
        }
    }
}


/**
 * From a none full page, allocate a continuous @size_of_type entries
 *
 * @param page  Free page with at least 'size_of_type' free slots in a raw
 * @param size_of_type The number of slots of allocate. Size 1 means that we allocate an entry of size page->page_type pool slots
 *
 */
static sx_utils_status_t __bin_allocate_from_page_and_move_to_bin(__bin_database_t  * db,
                                                                  __bin_page_entry_t* page,
                                                                  allocation_type_e   type,
                                                                  uint32_t          * offset)
{
    unsigned int index, max_bits_per_page, half_index = 0;
    uint64_t     one = 1; /* Compensate on old compilers */
    uint64_t     mask;

    if ((type == HALF_SLOT_E) && (page->page_type == 1)) {
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    index = max_bits_per_page = MAX_BITS_PER_PAGE(page);

    /* For half slot, try to scan the bit mask for only 01/10 patterns. */
    if (type == HALF_SLOT_E) {
        mask = ((page->half_slots >> 1) ^ page->half_slots) & (0x5555555555555555LL);
        index = ffsll(mask) - 1;
        half_index = !((page->half_slots >> index) & 1);
        index = index >> 1;
        index = ((index > max_bits_per_page) || ((index == 0) && !(mask & 1))) ? max_bits_per_page : index;
    } else if (type == DOUBLE_SLOT_E) {
        /* We need to find 2 free slots 2 bit aligned (11) */
        mask = ((page->free_slots >> 1) & page->free_slots) & (0x5555555555555555LL);
        index = ffsll(mask) - 1;
        if ((index > max_bits_per_page) || ((index == 0) && !(mask & 1))) {
            return SX_UTILS_STATUS_NO_RESOURCES;
        }
    } else {
        /* Try to allocate 2 near by adjacency so it will have room for double slots */
        mask = ((page->free_slots >> 1) ^ page->free_slots) & (0x5555555555555555LL);
        index = ffsll(mask) - 1;
        index |= ((page->free_slots >> index) & 1) ^ 1;
        index = ((index > max_bits_per_page) || ((index == 0) && !(mask & 1))) ? max_bits_per_page : index;
    }

    /* Allocate a slot or half slot in a new slot place */
    mask = page->free_slots;
    if (index == max_bits_per_page) {
        half_index = 0;
        index = ffsll(mask) - 1;
        if ((index > max_bits_per_page) || ((index == 0) && !(mask & 1))) {
            /* Couldn't find a free slot */
            return SX_UTILS_STATUS_NO_RESOURCES;
        }
    }

    CL_ASSERT(index <= max_bits_per_page);

    switch (type) {
    case HALF_SLOT_E:
        page->free_slots &= ~(one << index);
        page->half_slots &= ~((one << half_index) << (index << 1));
        break;

    case SLOT_E:
        page->free_slots &= ~(one << index);
        break;

    case DOUBLE_SLOT_E:
        page->free_slots &= ~(((one << 1) | one) << index);
        page->double_slots &= ~(one << (index >> 1));
        break;
    }

    *offset = __bin_calculate_page_offset(page, index, half_index && (type == HALF_SLOT_E));

    /* And putting back to mixed/full/non-full pages */
    __bin_move_page_to_bin(db, page);

    return SX_UTILS_STATUS_SUCCESS;
}

/**
 * From a none full page, free a continuous @size_of_type entries
 *
 * @param index            Index into free_slots
 * @param page             Free page with at least 'size_of_type' free slots in a raw
 * @param size_of_type     The number of slots of allocate. Size 1 means that we allocate an entry of size page->page_type pool slots
 *
 */
static sx_utils_status_t __bin_free_from_page_and_move_to_bin(__bin_database_t  * db,
                                                              int                 index,
                                                              __bin_page_entry_t* page,
                                                              allocation_type_e   type)
{
    int      was_in_full = 0;
    int      was_in_mixed = IS_PAGE_MIXED(page);
    int      index_shifted = index >> PAGETYPE_TO_BINTYPE(page->page_type);
    int      half_index = 0;
    uint64_t one = 1; /* Compensate on old compilers */
    uint64_t mask = 1;

    if (type == DOUBLE_SLOT_E) {
        if (((page->double_slots >> (index_shifted >> 1)) & 1) != 0) {
            return SX_UTILS_STATUS_PARAM_ERROR;
        }
        mask = 3;
    } else if (type == HALF_SLOT_E) {
        half_index = (index >> (PAGETYPE_TO_BINTYPE(page->page_type) - 1) & 1);
        if (((page->half_slots >> ((index_shifted << 1) + half_index)) & 1) != 0) {
            return SX_UTILS_STATUS_PARAM_ERROR;
        }
    }

    if (((page->free_slots >> index_shifted) & mask) != 0) {
        /* We can't deallocate a partial allocated slots! */
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    /* If it was in full, we want to remove it anyway */
    if (IS_PAGE_IN_FULL_LIST(page)) {
        was_in_full = 1;
        if (IS_PAGE_MIXED(page)) {
            cl_qlist_remove_item(&db->mixed_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
            page->bin = NULL;
        } else {
            cl_qlist_remove_item(&db->full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
            page->bin = NULL;
        }
    }

    if (type == HALF_SLOT_E) {
        page->half_slots |= one << ((index_shifted << 1) + half_index);
        if (((page->half_slots >> ((index_shifted << 1))) & 3) != 3) {
            /* Other half slot is not free (non 1) */
            mask = 0;
        }
    } else if (type == DOUBLE_SLOT_E) {
        page->double_slots |= one << (index_shifted >> 1);
    }
    page->free_slots |= (mask << index_shifted);

    /* Recycle the page */
    if (IS_PAGE_EMPTY(page)) {
        if (!was_in_full) {
            if (was_in_mixed) {
                cl_qlist_remove_item(&db->mixed_not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
                page->bin = NULL;
            } else {
                cl_qlist_remove_item(&db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
                page->bin = NULL;
            }
        }
        __bin_free_page(db, page);
    } else if (was_in_full) {
        /* Was in full and return to partial */
        if (IS_PAGE_MIXED(page)) {
            cl_qlist_insert_tail(&db->mixed_not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
            page->bin = &db->mixed_not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)];
        } else {
            cl_qlist_insert_tail(&db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
            page->bin = &db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)];
        }
    } else if ((type != SLOT_E) && !(IS_PAGE_MIXED(page))) {
        /* Remove the page from mixed page */
        cl_qlist_remove_item(&db->mixed_not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
        cl_qlist_insert_tail(&db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
        page->bin = &db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)];
    } else if ((was_in_mixed) && (IS_PAGE_EMPTY_HALF(page) ^ IS_PAGE_EMPTY_DOUBLE(page))) {
        if (IS_PAGE_EMPTY_HALF(page)) {
            if ((__bits_duplicate(page->double_slots) ^ page->free_slots) == 0) {
                /* All the slots are only double */
                mask = page->double_slots;
                page->page_type++;
                CLR_FREE_SLOTS(page);
                page->free_slots = mask;
                cl_qlist_remove_item(&db->mixed_not_full_bins[PAGETYPE_TO_BINTYPE(
                                                                  page->page_type) - 1], &page->list_item);
                cl_qlist_insert_tail(&db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
                page->bin = &db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)];
            }
        } else if (IS_PAGE_EMPTY_DOUBLE(page)) {
            mask = __bits_duplicate(page->free_slots) ^ page->half_slots;
            /* Check for 2 bits that are occupied in slots and free in halves (e.g. 00 vs 11) */
            if ((mask & (mask >> 1) & 0x5555555555555555LL) == 0) {
                /* All the slots are only half */
                mask = page->half_slots;
                page->page_type--;
                CLR_FREE_SLOTS(page);
                page->free_slots = mask;
                cl_qlist_remove_item(&db->mixed_not_full_bins[PAGETYPE_TO_BINTYPE(
                                                                  page->page_type) + 1], &page->list_item);
                cl_qlist_insert_tail(&db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)], &page->list_item);
                page->bin = &db->not_full_bins[PAGETYPE_TO_BINTYPE(page->page_type)];
            }
        }
    }

    return SX_UTILS_STATUS_SUCCESS;
}


/**
 * From @size, return it's bin location at @ret. @size must be power of 2 and inside @bin_pool_scheme_bin_size
 */
inline static sx_utils_status_t __get_bin_location(unsigned int size, int* ret)
{
    int bin_location = ffs(size) - 1;

    if (bin_location > NUM_OF_ENTRIES_PER_PAGE_SHIFT) {
        return SX_UTILS_STATUS_PARAM_ERROR;
    }
    if (bin_pool_scheme_bin_size_s[bin_location] != size) {
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    *ret = bin_location;

    return SX_UTILS_STATUS_SUCCESS;
}

/**
 * Free a bin
 */
void __free_bin(__bin_database_t* db, cl_qlist_t* bin)
{
    cl_list_item_t     *list_item;
    __bin_page_entry_t* page;

    for (list_item = cl_qlist_remove_head(bin); list_item != cl_qlist_end(bin); list_item =
             cl_qlist_remove_head(bin)) {
        page = PARENT_STRUCT(list_item, __bin_page_entry_t, list_item);
        __bin_free_page(db, page);
    }
}

static sx_utils_status_t __bin_demix(__bin_database_t* db,
                                     int               bin_location_to,
                                     int               bin_location_from,
                                     allocation_type_e slotType)
{
    cl_list_item_t     *list_item;
    __bin_page_entry_t* page;
    cl_qlist_t        * bin;
    int                 binType, max_bits_per_page, index, half_index = 0;
    bin_block_t         newBlock;
    bin_block_t         oldBlock;
    bin_block_t         testBlock;
    sx_utils_status_t   err = SX_UTILS_STATUS_NO_RESOURCES;
    uint32_t            relocation_cost, min_relocation_cost;
    uint64_t            mask = 0;
    uint64_t            mask_mask = 0;
    uint64_t            one = 1;

    if ((bin_location_from < 0) || (bin_location_from > NUM_OF_ENTRIES_PER_PAGE_SHIFT)) {
        return err;
    }

    /* Making sure there are pages to relocate */
    if (cl_is_qlist_empty(&db->not_full_bins[bin_location_to])) {
        return err;
    }

    min_relocation_cost = 0xFFFFFFFF;

    /* Go over all pages and try to find relocation pages */
    for (binType = 0; binType < 2; binType++) {
        if (binType & 1) {
            bin = &db->mixed_full_bins[bin_location_from];
        } else {
            bin = &db->mixed_not_full_bins[bin_location_from];
        }

        if (cl_is_qlist_empty(bin)) {
            continue;
        }

        testBlock.size = oldBlock.size = newBlock.size = 1 << bin_location_to;

        for (list_item = cl_qlist_head(bin); list_item != cl_qlist_end(bin); list_item = cl_qlist_next(list_item)) {
            page = PARENT_STRUCT(list_item, __bin_page_entry_t, list_item);

            /* For each mixed page, find half/double slot and relocate them */
            index = max_bits_per_page = MAX_BITS_PER_PAGE(page);

            if (slotType == HALF_SLOT_E) {
                if (IS_PAGE_EMPTY_HALF(page)) {
                    continue;
                }
                mask = page->half_slots;
                mask_mask = page->half_slots_mask;
            } else if (slotType == DOUBLE_SLOT_E) {
                if (IS_PAGE_EMPTY_DOUBLE(page)) {
                    continue;
                }
                mask = page->double_slots;
                mask_mask = page->double_slots_mask;
            }

            while ((mask & mask_mask) != mask_mask) {
                index = ffsll(~mask) - 1;
                mask |= one << index;

                if (slotType == HALF_SLOT_E) {
                    half_index = index & 1;
                    index = index >> 1;
                } else if (slotType == DOUBLE_SLOT_E) {
                    half_index = 0;
                    index = index << 1;
                }

                testBlock.index = __bin_calculate_page_offset(page, index, half_index);
                relocation_cost = db->relocate_cost((bin_database_t)db, &testBlock);
                if (relocation_cost < min_relocation_cost) {
                    min_relocation_cost = relocation_cost;
                    oldBlock.index = testBlock.index;
                }
            }
        }

        /* Relocate minimum page if exists */
        if (min_relocation_cost < db->relocation_threshold) {
            bin_allocate((bin_database_t)db, &newBlock);
            if (SX_UTILS_STATUS_SUCCESS == (err = db->relocate((bin_database_t)db, &oldBlock, &newBlock, FALSE))) {
                bin_free((bin_database_t)db, &oldBlock);
                db->reloc_counter += min_relocation_cost;
                err = SX_UTILS_STATUS_SUCCESS;
                goto out;
            } else {
                SX_LOG(SX_LOG_INFO,
                       "Demix relocation failed err = %d   from = %d to = %d\n",
                       err,
                       oldBlock.index,
                       newBlock.index);
                bin_free((bin_database_t)db, &newBlock);
            }
        } else {
            SX_LOG(SX_LOG_INFO,
                   "Demix is possible, deny due to a threshold (%d allowed %d)\n",
                   min_relocation_cost,
                   db->relocation_threshold);
        }
    }

out:
    return err;
}

/**
 * Relocate all slots of 'from' page to 'to' page. Return 1 if there more slots that needed to be relocated
 */
static sx_utils_status_t __bin_relocate_page(__bin_database_t  * db,
                                             cl_qlist_t        * bin,
                                             __bin_page_entry_t* from,
                                             __bin_page_entry_t* to,
                                             int                *cont)
{
    uint32_t          index, cost;
    bin_block_t       newBlock;
    bin_block_t       oldBlock;
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if ((db == NULL) || (bin == NULL) || (from == NULL) || (to == NULL) || (cont == NULL)) {
        return SX_UTILS_STATUS_PARAM_ERROR;
    }
    *cont = 0;

    oldBlock.size = newBlock.size = 1 << PAGETYPE_TO_BINTYPE(from->page_type);

    /* Until from page wasn't relocated */
    while ((from->page_type != 0) && !IS_PAGE_IN_FULL_LIST(to)) {
        index = (uint32_t)ffsll(~from->free_slots) - 1;
        oldBlock.index = __bin_calculate_page_offset(from, index, 0);
        cl_qlist_remove_item(bin, &to->list_item);
        to->bin = NULL;
        err = __bin_allocate_from_page_and_move_to_bin(db, to, SLOT_E, &index);
        CL_ASSERT(err == SX_UTILS_STATUS_SUCCESS);
        newBlock.index = index;

        /* Relocate slot (Must succeed) */
        cost = db->relocate_cost((bin_database_t)db, &oldBlock);
        err = db->relocate((bin_database_t)db, &oldBlock, &newBlock, FALSE);
        if (SX_UTILS_STATUS_SUCCESS == err) {
            bin_free((bin_database_t)db, &oldBlock);
            db->reloc_counter += cost;
        } else {
            SX_LOG(SX_LOG_ERROR, "Cannot relocate page, error = %d\n", err);
            bin_free((bin_database_t)db, &newBlock);
            return err;
        }
    }

    *cont = (from->page_type != 0);
    return err;
}

static sx_utils_status_t __bin_defrag(__bin_database_t* db, int bin_location)
{
    cl_list_item_t    * list_item = NULL;
    cl_list_item_t    * max_item_list = NULL;
    __bin_page_entry_t* min_item = NULL;
    __bin_page_entry_t* max_item = NULL;
    __bin_page_entry_t* page;
    cl_qlist_t        * bin = NULL;
    int                 free_count = 0;
    int                 occupy_size, min_occupy_size = 0, max_occupy_size = 0;
    unsigned int        occupy_reloc_cost, min_occupy_reloc_cost = 0;
    int                 bin_number_of_slots = NUM_OF_ENTRIES_PER_PAGE >> bin_location;
    int                 index, cont;
    uint64_t            mask, one = 1;
    bin_block_t         testBlock;
    sx_utils_status_t   err = SX_UTILS_STATUS_NO_RESOURCES;

    if ((bin_location < 0) || (bin_location > NUM_OF_ENTRIES_PER_PAGE_SHIFT)) {
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    bin = &db->not_full_bins[bin_location];

    testBlock.size = 1 << bin_location;

    /* Find the minimum page size and the total count of free slots */
    for (list_item = cl_qlist_head(bin); list_item != cl_qlist_end(bin); list_item = cl_qlist_next(list_item)) {
        page = PARENT_STRUCT(list_item, __bin_page_entry_t, list_item);

        occupy_size = (bin_number_of_slots - gen_utils_bits(page->free_slots));

        if ((max_item == NULL) || (occupy_size > max_occupy_size)) {
            max_occupy_size = occupy_size;
            max_item = page;
            max_item_list = list_item;
        }

        free_count += (bin_number_of_slots - occupy_size);

        /* Count the relocation cost for this page */
        occupy_reloc_cost = 0;
        mask = page->free_slots;
        while ((mask & page->free_slots_mask) != page->free_slots_mask) {
            index = ffsll(~mask) - 1;
            mask |= one << index;
            testBlock.index = __bin_calculate_page_offset(page, index, 0);
            occupy_reloc_cost += db->relocate_cost((bin_database_t)db, &testBlock);
        }

        if ((min_item == NULL) || (occupy_reloc_cost < min_occupy_reloc_cost)) {
            min_occupy_size = occupy_size;
            min_item = page;
            min_occupy_reloc_cost = occupy_reloc_cost;
        }
    }

    if ((min_item == NULL) || (max_item == NULL)) {
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    if (min_item == max_item) {
        max_item_list = cl_qlist_next(max_item_list);
        /* Check we have 2 different pages */
        if (max_item_list == cl_qlist_end(bin)) {
            max_item_list = cl_qlist_prev(&min_item->list_item);
            if (max_item_list == cl_qlist_end(bin)) {
                return SX_UTILS_STATUS_NO_RESOURCES;
            }
        }
        max_item = PARENT_STRUCT(max_item_list, __bin_page_entry_t, list_item);
    }

    /* Relocate min_item, min_occupy_size slots into all other "free_count" pages */
    /* Making sure we have enough space for relocation*/
    free_count -= (bin_number_of_slots - min_occupy_size);
    if (free_count < min_occupy_size) {
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    if (min_occupy_reloc_cost >= db->relocation_threshold) {
        SX_LOG(SX_LOG_INFO,
               "Defrag is possible, deny due to a threshold (%d allowed %d)\n",
               min_occupy_reloc_cost,
               db->relocation_threshold);
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    while (1) {
        /* Find the next max page */
        err = __bin_relocate_page(db, bin, min_item, max_item, &cont);
        if ((err != SX_UTILS_STATUS_SUCCESS) || (!cont)) {
            break;
        }
        max_item = NULL;
        for (list_item = cl_qlist_head(bin); list_item != cl_qlist_end(bin); list_item = cl_qlist_next(list_item)) {
            page = PARENT_STRUCT(list_item, __bin_page_entry_t, list_item);
            occupy_size = bin_number_of_slots - gen_utils_bits(page->free_slots);
            if (((max_item == NULL) || (occupy_size > max_occupy_size)) && (min_item != page)) {
                max_occupy_size = occupy_size;
                max_item = page;
                max_item_list = list_item;
            }
        }
    }
    return err;
}

/* Formal name is page defrag */
static sx_utils_status_t __bin_depage(__bin_database_t* db, int bin_location)
{
    cl_list_item_t    * list_item;
    cl_list_item_t    * min_to_list = NULL;
    __bin_page_entry_t* page = NULL;
    __bin_page_entry_t *min_to_page = NULL;
    cl_qlist_t        * bin = NULL;
    unsigned int        index, half_index, is_half_slot_or_normal, max_bits_per_page;
    uint64_t            mask, mask1, mask_mask, one = 1;
    bin_block_t         testBlock, minBlockFrom, minBlockTo;
    unsigned int        index_cost, min_cost = ((unsigned int)(-1));
    sx_utils_status_t   err;

    if ((bin_location < 0) || (bin_location > NUM_OF_ENTRIES_PER_PAGE_SHIFT)) {
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    bin = &db->not_full_bins[bin_location];

    /* For each page, try to find 2 halves or 2 slots */
    for (is_half_slot_or_normal = (bin_location == 0) ? 1 : 0; is_half_slot_or_normal < 2; is_half_slot_or_normal++) {
        if (is_half_slot_or_normal == 0) {
            bin = &db->mixed_not_full_bins[bin_location];
            testBlock.size = 1 << (bin_location - 1);
        } else {
            bin = &db->not_full_bins[bin_location];
            testBlock.size = 1 << bin_location;
        }
        minBlockTo.size = minBlockFrom.size = 0;
        minBlockTo.index = (uint32_t)(-1);

        for (list_item = cl_qlist_head(bin); list_item != cl_qlist_end(bin); list_item =
                 cl_qlist_next(list_item)) {
            page = PARENT_STRUCT(list_item, __bin_page_entry_t, list_item);
            max_bits_per_page = MAX_BITS_PER_PAGE(page);
            if (is_half_slot_or_normal == 0) {
                mask1 = page->half_slots;
                mask_mask = page->half_slots_mask;
            } else {
                mask1 = page->free_slots;
                mask_mask = page->free_slots_mask;
            }

            /* For all pairs */
            while (1) {
                if ((mask1 & mask_mask) == mask_mask) {
                    break;
                }
                mask = ((mask1 >> 1) ^ mask1) & (0x5555555555555555LL) & mask_mask;
                index = ffsll(mask) - 1;
                half_index = ((mask1 >> index) & 1);
                if ((index > max_bits_per_page) || ((mask1 & ((one + !half_index) << index)) == 0)) {
                    break;
                }
                mask1 |= ((one + half_index) << index);

                if (is_half_slot_or_normal == 0) {
                    index = index >> 1;
                } else if (half_index) {
                    index++;
                }

                /* We have a slot to move (In the alignment: one free and one occupied), try to calculate costs, and chose the lower */
                testBlock.index = __bin_calculate_page_offset(page,
                                                              index,
                                                              (is_half_slot_or_normal == 0) ? half_index : 0);
                index_cost = db->relocate_cost((bin_database_t)db, &testBlock);

                if ((minBlockFrom.size == 0) || (index_cost < min_cost)) {
                    minBlockFrom = testBlock;
                    min_cost = index_cost;
                    if (minBlockTo.size == 0) {
                        if (minBlockTo.index != (uint32_t)(-1)) {
                            minBlockTo.size = testBlock.size;  /* Mark previous min as "To" */
                        } else { /* Mark this transaction as possible "To" */
                            if (is_half_slot_or_normal == 0) {
                                minBlockTo.index = __bin_calculate_page_offset(page, index, !half_index);
                            } else {
                                minBlockTo.index = __bin_calculate_page_offset(page,
                                                                               (half_index) ? index - 1 : index + 1,
                                                                               0);
                            }
                            min_to_page = page;
                            min_to_list = list_item;
                        }
                    }
                } else if (minBlockTo.size == 0) {
                    minBlockTo.size = testBlock.size;
                    if (is_half_slot_or_normal == 0) {
                        minBlockTo.index = __bin_calculate_page_offset(page, index, !half_index);
                    } else {
                        minBlockTo.index = __bin_calculate_page_offset(page,
                                                                       (half_index) ? index - 1 : index + 1,
                                                                       0);
                    }
                    min_to_page = page;
                    min_to_list = list_item;
                }
            } /* All slots in page*/
        } /* Scan all pages */

        /* Relocate slots */
        if ((minBlockFrom.size != 0) && (minBlockTo.size != 0) && (min_cost < db->relocation_threshold)) {
            /* Allocate the to index */
            cl_qlist_remove_item(bin, min_to_list);
            min_to_page->bin = NULL;
            index = INDEX(minBlockTo.index) >>
                    PAGETYPE_TO_BINTYPE(page->page_type - (is_half_slot_or_normal == 0));
            if (is_half_slot_or_normal == 0) {
                CL_ASSERT(min_to_page->half_slots & (one << index));
                min_to_page->half_slots &= ~(one << index);
            } else {
                CL_ASSERT(min_to_page->free_slots & (one << index));
                min_to_page->free_slots &= ~(one << index);
            }
            /* Move page to new bin / list */
            __bin_move_page_to_bin(db, min_to_page);

            err = db->relocate((bin_database_t)db, &minBlockFrom, &minBlockTo, FALSE);
            if (SX_UTILS_STATUS_SUCCESS == err) {
                db->reloc_counter += min_cost;
                bin_free((bin_database_t)db, &minBlockFrom);
                return SX_UTILS_STATUS_SUCCESS;
            } else {
                SX_LOG(SX_LOG_ERROR, "Cannot relocate page\n");
                if (is_half_slot_or_normal == 0) {
                    min_to_page->half_slots |= one << index;
                } else {
                    min_to_page->free_slots |= one << index;
                }
                return err;
            }
        }
    } /* Half scan and slot scan */

    return SX_UTILS_STATUS_NO_RESOURCES;
}

static sx_utils_status_t __bin_allocate_from_bin(__bin_database_t* db,
                                                 bin_block_t     * index,
                                                 int               bin_location,
                                                 cl_qlist_t      * bin,
                                                 allocation_type_e slotType)
{
    cl_list_item_t    * list_item;
    __bin_page_entry_t* page;
    sx_utils_status_t   err = SX_UTILS_STATUS_ERROR;

    if ((slotType == HALF_SLOT_E) && (bin_location == 0)) {
        return err;
    }

    if ((slotType == DOUBLE_SLOT_E) && (bin_location == NUM_OF_ENTRIES_PER_PAGE_SHIFT)) {
        return err;
    }


    if ((bin_location >= 0) && (bin_location < (NUM_OF_BINS - 1))
        && (!cl_is_qlist_empty(bin))) {
        /* Found! Get it from not full bin pool */
        list_item = cl_qlist_remove_head(bin);
        page = PARENT_STRUCT(list_item, __bin_page_entry_t, list_item);
        page->bin = NULL;

        /* Allocate 0.5*page_type entries */
        err = __bin_allocate_from_page_and_move_to_bin(db, page, slotType, &index->index);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            cl_qlist_insert_tail(bin, list_item);
            page->bin = bin;
            goto out;
        }
        err = SX_UTILS_STATUS_SUCCESS;
    }

out:
    return err;
}

#ifdef UNITTESTS
static void __dump_uint64(uint64_t num, int max_bits)
{
    char str[65];
    int  i;

    for (i = 0; i < max_bits; i++) {
        if ((num >> i) & 1) {
            str[max_bits - i - 1] = '1';
        } else {
            str[max_bits - i - 1] = '0';
        }
    }
    str[max_bits] = 0;
    printf("%s", str);
}

static void __dump_list(cl_qlist_t* bin, const char* bin_name)
{
    cl_list_item_t     *list_item;
    __bin_page_entry_t* page;
    int                 max_bits;

    if (cl_is_qlist_empty(bin)) {
        printf("   - No pages in %s\n", bin_name);
    } else {
        for (list_item = cl_qlist_head(bin); list_item != cl_qlist_end(bin); list_item = cl_qlist_next(list_item)) {
            page = PARENT_STRUCT(list_item, __bin_page_entry_t, list_item);
            max_bits = MAX_BITS_PER_PAGE(page);
            printf("   - %s page %d.  Free: ", bin_name, page->page_id);
            __dump_uint64(page->free_slots, max_bits);
            if (page->page_type != 1) {
                printf(" Half: ");
                __dump_uint64(page->half_slots, max_bits << 1);
            }
            if (page->page_type != NUM_OF_BINS) {
                printf(" Double: ");
                __dump_uint64(page->double_slots, max_bits >> 1);
            }
            printf("\n");
        }
    }
}

void bin_allocator_dump(bin_database_t database, uint32_t bin)
{
    __bin_database_t* db = (__bin_database_t*)database;
    int               i;

    if (db == NULL) {
        printf("bin_allocator not initialized\n");
        return;
    }

    if (bin == NUM_OF_BINS) {
        printf("bin_allocator_dump\n");
        printf("==================\n");
        printf("  Number of free pages = %d\n", (int)cl_qlist_count(&db->free_page_list));
    }

    for (i = 0; i < NUM_OF_BINS; i++) {
        if ((bin == i) || (bin == NUM_OF_BINS)) {
            printf("  Bin #%d, size = %d\n", i, bin_pool_scheme_bin_size_s[i]);
            printf("  ----------------\n");
            __dump_list(&db->full_bins[i], "full_bins");
            __dump_list(&db->not_full_bins[i], "not_full_bins");
            __dump_list(&db->mixed_full_bins[i], "mixed_full_bins");
            __dump_list(&db->mixed_not_full_bins[i], "mixed_not_full_bins");
        }
    }
}
#endif /* UNITTESTS */

/******************************************************************************************/

void bin_block_init(bin_block_t* block)
{
    if (block == NULL) {
        return;
    }

    block->index = 0xFFFFFFFF;
    block->size = 0xFFFFFFFF;
}

boolean_t bin_is_block_valid(const bin_block_t* block)
{
    int bin_location;

    if (block == NULL) {
        return FALSE;
    }
    if (__get_bin_location(block->size, &bin_location) != SX_UTILS_STATUS_SUCCESS) {
        return FALSE;
    }
    if (block->index == 0xFFFFFFFF) {
        return FALSE;
    }

    return TRUE;
}

sx_utils_status_t bin_get_slot_index(bin_database_t database, const bin_block_t* block, uint32_t* index)
{
    __bin_database_t* db = (__bin_database_t*)database;

#ifdef _DEBUG_
    __bin_page_entry_t* page;
    cl_map_item_t     * map_item;
    int                 bin_location, half_index = 0;
    unsigned int        idx;
#endif /* _DEBUG_ */
    if ((db == NULL) || (index == NULL) || (block == NULL)) {
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

#ifdef _DEBUG_
    if (__get_bin_location(block->size, &bin_location) != SX_UTILS_STATUS_SUCCESS) {
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    /* Get the actual page and compare the bin */
    idx = INDEX(block->index);
    map_item = cl_qmap_get(&db->paged_map, PAGE(block->index));
    if (map_item == cl_qmap_end(&db->paged_map)) {
        /* This is a wrong index or a real bug at the indexing system */
        return SX_UTILS_STATUS_PARAM_ERROR;
    }
    page = PARENT_STRUCT(map_item, __bin_page_entry_t, map_item);

    if ((page->page_type == 0) || ((PAGETYPE_TO_BINTYPE(page->page_type) > (bin_location + 1))) ||
        ((PAGETYPE_TO_BINTYPE(page->page_type) < (bin_location - 1)))) {
        /* This is a wrong index or a real bug at the indexing system */
        return SX_UTILS_STATUS_PARAM_ERROR;
    }

    idx = idx >> PAGETYPE_TO_BINTYPE(page->page_type);

    /* And check block corruption */
    if (PAGETYPE_TO_BINTYPE(page->page_type) == (bin_location + 1)) {
        /* Half slot, check for half-index */
        half_index = (INDEX(block->index) >> (PAGETYPE_TO_BINTYPE(page->page_type) - 1) & 1);
    }
    if (__bin_calculate_page_offset(page, idx, half_index) != block->index) {
        return SX_UTILS_STATUS_ERROR;
    }
#endif /* _DEBUG_ */

    *index = block->index;
    *index += db->start_index;

    return SX_UTILS_STATUS_SUCCESS;
}

cl_status_t __bin_find_page(const cl_list_item_t * const p_list_item, void *context)
{
    __bin_page_entry_t* cur_page = PARENT_STRUCT(p_list_item, __bin_page_entry_t, list_item);
    __bin_page_entry_t* search_page = (__bin_page_entry_t*)context;

    if (cur_page == search_page) {
        return CL_SUCCESS;
    }
    return CL_NOT_FOUND;
}

cl_status_t __bin_find_nonlast_page(const cl_list_item_t * const p_list_item, void *context)
{
    __bin_page_entry_t* cur_page = PARENT_STRUCT(p_list_item, __bin_page_entry_t, list_item);
    uint32_t            last_page_to_find = *(uint32_t*)context;

    if (cur_page->page_id <= last_page_to_find) {
        return CL_SUCCESS;
    }
    return CL_NOT_FOUND;
}

uint32_t bin_get_free_page_count(bin_database_t database)
{
    __bin_database_t* db = (__bin_database_t*)database;

    return cl_qlist_count(&db->free_page_list);
}

sx_utils_status_t bin_resize(bin_database_t database, uint32_t new_end_index)
{
    __bin_database_t  * db = (__bin_database_t*)database;
    uint32_t            diff_entries, diff_pages, i;
    cl_pool_item_t    * pool_item;
    __bin_page_entry_t *page;
    sx_utils_status_t   err = SX_UTILS_STATUS_SUCCESS;

#if 0
    uint32_t            last_page_to_find;
    cl_list_item_t    * list_item;
    cl_map_item_t     * map_item;
    __bin_page_entry_t *free_page;
#endif

    if (new_end_index > (db->start_index + (db->page_count << NUM_OF_ENTRIES_PER_PAGE_SHIFT))) {
        /* Enlarge - add new pages to free list */
        diff_entries = new_end_index - (db->start_index + (db->page_count << NUM_OF_ENTRIES_PER_PAGE_SHIFT));
        diff_pages = diff_entries >> NUM_OF_ENTRIES_PER_PAGE_SHIFT;
        if (diff_pages < 1) {
            SX_LOG(SX_LOG_ERROR, "bin_resize cannot enlarge by %u, which is less than a page\n", diff_entries);
            return SX_UTILS_STATUS_PARAM_ERROR;
        }
        for (i = 0; i < diff_pages; i++) {
            /* Insert a page to the free list */
            pool_item = cl_qpool_get(&db->page_pool);
            if (pool_item == NULL) {
                SX_LOG(SX_LOG_ERROR, "Cannot allocate space for pages of bin allocator during enlarge.\n");
                err = SX_UTILS_STATUS_NO_MEMORY;
                goto out;
            }

            page = PARENT_STRUCT(pool_item, __bin_page_entry_t, pool_item);
            page->page_id = db->page_count;
            cl_qlist_insert_tail(&db->free_page_list, &page->list_item);
            page->bin = &db->free_page_list;

            /* And add this newly created page into the hash table, from index to page */
            cl_qmap_insert(&db->paged_map, page->page_id, &page->map_item);
            db->page_count++;
        }
    } else if (new_end_index < (db->start_index + (db->page_count << NUM_OF_ENTRIES_PER_PAGE_SHIFT))) {
        /* Reduce - make sure last pages are free, and remove them from free list */
        diff_entries = (db->start_index + (db->page_count << NUM_OF_ENTRIES_PER_PAGE_SHIFT)) - new_end_index;
        diff_pages = diff_entries >> NUM_OF_ENTRIES_PER_PAGE_SHIFT;
        if (diff_pages < 1) {
            SX_LOG(SX_LOG_ERROR, "bin_resize cannot reduce by %u, which is less than a page\n", diff_entries);
            return SX_UTILS_STATUS_PARAM_ERROR;
        }
        if (cl_qlist_count(&db->free_page_list) < diff_pages) {
            SX_LOG(SX_LOG_ERROR, "bin_resize cannot reduce by %u, not enough free pages\n", diff_entries);
            return SX_UTILS_STATUS_RESOURCE_IN_USE;
        }

        SX_LOG(SX_LOG_ERROR, "bin_resize does not support reduce yet\n");
        return SX_UTILS_STATUS_CMD_UNSUPPORTED;
#if 0
        last_page_to_find = db->page_count - diff_pages;
        for (i = 0; i < diff_pages; i++) {
            /* Find last page */
            map_item = cl_qmap_get(&db->paged_map, db->page_count - 1);
            CL_ASSERT(map_item != cl_qmap_end(&db->paged_map));
            if (map_item == cl_qmap_end(&db->paged_map)) {
                SX_LOG(SX_LOG_ERROR, "bin_resize cannot find the last page for reduction\n");
                return SX_UTILS_STATUS_ERROR;
            }
            page = PARENT_STRUCT(map_item, __bin_page_entry_t, map_item);
            CL_ASSERT(page->page_id == (db->page_count - 1));
            /* Make sure the last page is free */
            if (page->bin != &db->free_page_list) {
                /* Find a non-last free page. We'll move the contents of the last page to this page */
                list_item = cl_qlist_find_from_head(&db->free_page_list, __bin_find_nonlast_page, &last_page_to_find);
                CL_ASSERT(list_item != cl_qlist_end(&db->free_page_list));
                if (list_item == cl_qlist_end(&db->free_page_list)) {
                    SX_LOG(SX_LOG_ERROR, "bin_resize cannot find a page to use for reduction\n");
                    return SX_UTILS_STATUS_NO_RESOURCES;
                }
                free_page = PARENT_STRUCT(list_item, __bin_page_entry_t, list_item);
                CL_ASSERT(free_page->page_id <= last_page_to_find);
                /* TODO: Relocate all blocks in page to free_page */
                /*err = __bin_swap_page_id(db, page, free_page);
                 *  if (err != SX_UTILS_STATUS_SUCCESS)
                 *  {
                 *   SX_LOG(SX_LOG_ERROR, "bin_resize failed to move page for reduction\n");
                 *   return err;
                 *  }*/
                page = free_page;
            }
            /* Remove this free last page from the database */
            CL_ASSERT(page->bin == &db->free_page_list);
            cl_qlist_remove_item(&db->free_page_list, &page->list_item);
            cl_qmap_remove_item(&db->paged_map, &page->map_item);
            cl_qpool_put(&db->page_pool, &page->pool_item);
            db->page_count--;
        }
#endif
    }

out:
    return err;
}

sx_utils_status_t bin_init(bin_database_t      * database,
                           uint32_t              start_index,
                           uint32_t              end_index,
                           bin_relocation_cost_t relocation_cost,
                           bin_relocation_t      relocation,
                           uint32_t              relocation_threshold)
{
    sx_utils_status_t   err = SX_UTILS_STATUS_SUCCESS;
    __bin_database_t  * db;
    uint32_t            num_pages, i;
    uint32_t            num_entries = end_index - start_index;
    cl_pool_item_t    * pool_item;
    __bin_page_entry_t* page;
    cl_status_t         cl_st = CL_SUCCESS;

    SX_LOG_ENTER();

    if ((relocation == NULL) || (relocation_cost == NULL) || (database == NULL)) {
        SX_LOG(SX_LOG_ERROR, "Called with NULL relocate functions\n");
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (end_index < start_index) {
        SX_LOG(SX_LOG_ERROR, "Wrong index: start:%d end:%d \n", start_index, end_index);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((num_entries & (NUM_OF_ENTRIES_PER_PAGE - 1)) != 0) {
        num_entries &= ~(NUM_OF_ENTRIES_PER_PAGE - 1);
        SX_LOG(SX_LOG_NOTICE, "Table size:%d - will be adjusted to %d. \n",
               end_index - start_index, num_entries);
    }

    num_pages = num_entries >> NUM_OF_ENTRIES_PER_PAGE_SHIFT;


    M_GEN_UTILS_CLR_MEM_GET(&db, 1, sizeof(__bin_database_t), GEN_UTILS_MEM_TYPE_ID_BIN_E, "Bin allocator\n", err);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot allocate space for bin allocator.\n");
        goto out;
    }

    db->relocate = relocation;
    db->relocate_cost = relocation_cost;
    db->reloc_counter = db->old_reloc_counter = 0;
    db->relocation_threshold = relocation_threshold;
    db->defrag_features = DEFRAG_ENABLE_DEMIX | DEFRAG_ENABLE_DEFRAG | DEFRAG_ENABLE_PAGE_DEFRAG;
    db->start_index = start_index;
    db->page_count = 0;

    /* Initialized hash table. Important to execute before pool initialization */
    for (i = 0; i < NUM_OF_BINS; i++) {
        cl_qlist_init(&db->full_bins[i]);
        cl_qlist_init(&db->not_full_bins[i]);
        cl_qlist_init(&db->mixed_full_bins[i]);
        cl_qlist_init(&db->mixed_not_full_bins[i]);
    }
    cl_qlist_init(&db->free_page_list);
    cl_qmap_init(&db->paged_map);
    /* Initialized page pool, starting from 0 location */
    cl_st = CL_QPOOL_INIT(&db->page_pool,
                          0, 0, (num_pages < 4) ? 4 : num_pages, sizeof(__bin_page_entry_t),
                          NULL, NULL, db);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("Cannot allocate page pool of bin allocator.\n");
        err = SX_UTILS_STATUS_NO_MEMORY;
        goto out;
    }

    for (i = 0; i < num_pages; i++) {
        /* Insert a page to the free list */
        pool_item = cl_qpool_get(&db->page_pool);
        if (pool_item == NULL) {
            SX_LOG(SX_LOG_ERROR, "Cannot allocate space for pages of bin allocator.\n");
            err = SX_UTILS_STATUS_NO_MEMORY;
            goto out;
        }

        page = PARENT_STRUCT(pool_item, __bin_page_entry_t, pool_item);
        page->page_id = db->page_count;
        cl_qlist_insert_tail(&db->free_page_list, &page->list_item);
        page->bin = &db->free_page_list;

        /* And add this newly created page into the hash table, from index to page */
        cl_qmap_insert(&db->paged_map, page->page_id, &page->map_item);
        db->page_count++;
    }

    /* Mark as initialized */
    *database = (bin_database_t)db;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t bin_deinit(bin_database_t database)
{
    sx_utils_status_t   err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t   err1 = SX_UTILS_STATUS_SUCCESS;
    __bin_database_t  * db = (__bin_database_t*)database;
    cl_list_item_t    * list_item;
    __bin_page_entry_t* page;
    int                 i;

    SX_LOG_ENTER();

    if (db == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    /* Assert that all bins are empty */
    for (i = 0; i < NUM_OF_BINS; i++) {
        if (!cl_is_qlist_empty(&db->full_bins[i])) {
            SX_LOG(SX_LOG_ERROR, "bin-allocator: Bin is not empty! (full) %d\n", i);
            /* __free_bin(db, &db->full_bins[i]); */
            err = SX_UTILS_STATUS_RESOURCE_IN_USE;
        }
        if (!cl_is_qlist_empty(&db->not_full_bins[i])) {
            SX_LOG(SX_LOG_ERROR, "bin-allocator: Bin is not empty! (not-full) %d\n", i);
            /* __free_bin(db, &db->not_full_bins[i]); */
            err = SX_UTILS_STATUS_RESOURCE_IN_USE;
        }
        if (!cl_is_qlist_empty(&db->mixed_full_bins[i])) {
            SX_LOG(SX_LOG_ERROR, "bin-allocator: Bin is not empty! (Mixed-full) %d\n", i);
            /* __free_bin(db, &db->mixed_full_bins[i]); */
            err = SX_UTILS_STATUS_RESOURCE_IN_USE;
        }
        if (!cl_is_qlist_empty(&db->mixed_not_full_bins[i])) {
            SX_LOG(SX_LOG_ERROR, "bin-allocator: Bin is not empty! (Mixed) %d\n", i);
            /* __free_bin(db, &db->mixed_not_full_bins[i]); */
            err = SX_UTILS_STATUS_RESOURCE_IN_USE;
        }
    }

    if (err != SX_UTILS_STATUS_SUCCESS) {
        goto out;
    }

    cl_qmap_remove_all(&db->paged_map);
    while (cl_qlist_count(&db->free_page_list) > 0) {
        list_item = cl_qlist_remove_head(&db->free_page_list);
        page = PARENT_STRUCT(list_item, __bin_page_entry_t, list_item);
        cl_qpool_put(&db->page_pool, &page->pool_item);
    }
    CL_QPOOL_DESTROY(&db->page_pool);

    M_GEN_UTILS_MEM_PUT(db, GEN_UTILS_MEM_TYPE_ID_BIN_E, "Bin allocator\n", err1);
    if (err == SX_UTILS_STATUS_SUCCESS) {
        err = err1;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t bin_allocate(bin_database_t database, bin_block_t* index)
{
    __bin_database_t  * db = (__bin_database_t*)database;
    sx_utils_status_t   err = SX_UTILS_STATUS_SUCCESS;
    cl_list_item_t     *list_item;
    __bin_page_entry_t* page;
    int                 bin_location;

    SX_LOG_ENTER();

    if (db == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if (index == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL argument\n");
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    /* Test that the size is within the scheme */
    err = __get_bin_location(index->size, &bin_location);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Wrong size was given\n");
        goto out;
    }

    /* Test whether we have not full bin to allocate from */
    err = __bin_allocate_from_bin(db, index, bin_location, &db->not_full_bins[bin_location], SLOT_E);
    if (err == SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_INFO, "Allocated from a not full bin (index = %d)\n", index->index);
        goto out;
    }

    /* Test if there are free pages */
    list_item = cl_qlist_remove_head(&db->free_page_list);
    if (list_item != cl_qlist_end(&db->free_page_list)) {
        /* Found! Get it from free pages pool, and mark it belongs to a new bin type of bin_location */
        page = PARENT_STRUCT(list_item, __bin_page_entry_t, list_item);
        page->bin = NULL;
        page->page_type = BINTYPE_TO_PAGETYPE(bin_location);
        CLR_FREE_SLOTS(page);
        /* Allocate 1*page_type entries */
        err = __bin_allocate_from_page_and_move_to_bin(db, page, SLOT_E, &index->index);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            /* This is a logical bug in the code! */
            SX_LOG(SX_LOG_ERROR, "** BUG IN THE CODE A: %d\n", err);
            CL_ASSERT(0);
            /* And put back to the free page list */
            __bin_free_page(db, page);
            goto out;
        }
        SX_LOG(SX_LOG_INFO, "Allocating from a fresh bin (index = %d)\n", index->index);

        err = SX_UTILS_STATUS_SUCCESS;
        goto out;
    }

    /* Try to allocate from a higher mixed non-full pages a half slot */
    err = __bin_allocate_from_bin(db, index, bin_location, &db->mixed_not_full_bins[bin_location], SLOT_E);
    if (err == SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_INFO, "Allocated from a mixed not full bin (index = %d)\n", index->index);
        goto out;
    }

    /* Try to allocate from a higher mixed non-full pages a half slot */
    err =
        __bin_allocate_from_bin(db, index, bin_location + 1, &db->mixed_not_full_bins[bin_location + 1], HALF_SLOT_E);
    if (err == SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_INFO, "Allocated from a higher not full bin (index = %d)\n", index->index);
        goto out;
    }

    /* Try to allocate from a lower mixed non-full pages a double slot */
    err = __bin_allocate_from_bin(db,
                                  index,
                                  bin_location - 1,
                                  &db->mixed_not_full_bins[bin_location - 1],
                                  DOUBLE_SLOT_E);
    if (err == SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_INFO, "Allocated from a higher not full bin (index = %d)\n", index->index);
        goto out;
    }

    /* Try to allocate from a higher non-full pages a half slot and make it mixed */
    err = __bin_allocate_from_bin(db, index, bin_location + 1, &db->not_full_bins[bin_location + 1], HALF_SLOT_E);
    if (err == SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_INFO, "Allocated from a higher not full bin (index = %d)\n", index->index);
        goto out;
    }

    /* Try to allocate from a lower non-full pages a double slot and make it mixed  */
    err = __bin_allocate_from_bin(db, index, bin_location - 1, &db->not_full_bins[bin_location - 1], DOUBLE_SLOT_E);
    if (err == SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_INFO, "Allocated from a higher not full bin (index = %d)\n", index->index);
        goto out;
    }

    /*SX_LOG(SX_LOG_INFO, "Unable to allocate size %d, no resources\n", index->size);*/
    err = SX_UTILS_STATUS_NO_RESOURCES;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t bin_free(bin_database_t database, bin_block_t* index)
{
    __bin_database_t  * db = (__bin_database_t*)database;
    sx_utils_status_t   err = SX_UTILS_STATUS_SUCCESS;
    __bin_page_entry_t* page;
    cl_map_item_t     * map_item;
    int                 bin_location;
    allocation_type_e   type = SLOT_E;

    SX_LOG_ENTER();

    if (db == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL database\n");
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }

    if (index == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL argument\n");
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    /* Test that the size is within the scheme */
    err = __get_bin_location(index->size, &bin_location);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Wrong size was given\n");
        goto out;
    }

    /* Get the actual page and compare the bin */
    map_item = cl_qmap_get(&db->paged_map, PAGE(index->index));
    if (map_item == cl_qmap_end(&db->paged_map)) {
        /* This is a wrong index or a real bug at the indexing system */
        SX_LOG(SX_LOG_ERROR, "Wrong index was given - %d\n", index->index);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }
    page = PARENT_STRUCT(map_item, __bin_page_entry_t, map_item);

    if ((page->page_type == 0) || ((PAGETYPE_TO_BINTYPE(page->page_type) > (bin_location + 1))) ||
        ((PAGETYPE_TO_BINTYPE(page->page_type) < (bin_location - 1)))) {
        /* This is a wrong index or a real bug at the indexing system */
        SX_LOG(SX_LOG_ERROR, "Wrong page was given - Index = %d, page_type = %d, bin_location = %d, size = %d\n",
               index->index, page->page_type, bin_location, index->size);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (PAGETYPE_TO_BINTYPE(page->page_type) == (bin_location + 1)) {
        type = HALF_SLOT_E;
    }
    if (PAGETYPE_TO_BINTYPE(page->page_type) == (bin_location - 1)) {
        type = DOUBLE_SLOT_E;
    }

    err = __bin_free_from_page_and_move_to_bin(db, INDEX(index->index),
                                               page,
                                               type);
out:
    SX_LOG_EXIT();
    return err;
}

uint32_t bin_get_bin_count()
{
    return NUM_OF_BINS;
}

sx_utils_status_t bin_get_statistics(bin_database_t database,
                                     uint32_t       bin,
                                     unsigned int * number_of_full_pages,
                                     unsigned int * number_of_not_full_pages,
                                     unsigned int * number_of_mixed_full_pages,
                                     unsigned int * number_of_mixed_not_full_pages)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    __bin_database_t* db = (__bin_database_t*)database;

    SX_LOG_ENTER();
    if ((db == NULL) || (bin >= NUM_OF_BINS)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (number_of_full_pages != NULL) {
        *number_of_full_pages = cl_qlist_count(&db->full_bins[bin]);
    }

    if (number_of_not_full_pages != NULL) {
        *number_of_not_full_pages = cl_qlist_count(&db->not_full_bins[bin]);
    }

    if (number_of_mixed_full_pages != NULL) {
        *number_of_mixed_full_pages = cl_qlist_count(&db->mixed_full_bins[bin]);
    }

    if (number_of_mixed_not_full_pages != NULL) {
        *number_of_mixed_not_full_pages = cl_qlist_count(&db->mixed_not_full_bins[bin]);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t bin_defrag(bin_database_t database, uint32_t bin)
{
    sx_utils_status_t err = SX_UTILS_STATUS_NO_RESOURCES;
    __bin_database_t* db = (__bin_database_t*)database;

    SX_LOG_ENTER();

    if ((db == NULL) || (bin >= NUM_OF_BINS)) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    db->old_reloc_counter = db->reloc_counter;

    /* First we will run the demix algorithm (Moving pages from mixed pool) */
    if (db->defrag_features & DEFRAG_ENABLE_DEMIX) {
        err = __bin_demix(db, bin, (int)bin + 1, HALF_SLOT_E);
        if ((err == SX_UTILS_STATUS_SUCCESS) || (err != SX_UTILS_STATUS_NO_RESOURCES)) {
            goto out;
        }
        err = __bin_demix(db, bin, (int)bin - 1, DOUBLE_SLOT_E);
        if ((err == SX_UTILS_STATUS_SUCCESS) || (err != SX_UTILS_STATUS_NO_RESOURCES)) {
            goto out;
        }
    }

    /* We couldn't find any demix activities, moving on to defrag algorithm */
    if (db->defrag_features & DEFRAG_ENABLE_DEFRAG) {
        err = __bin_defrag(db, bin);
        if ((err == SX_UTILS_STATUS_SUCCESS) || (err != SX_UTILS_STATUS_NO_RESOURCES)) {
            goto out;
        }
    }

    /* We couldn't find any defrag activities, moving on to page defrag algorithm */
    if (db->defrag_features & DEFRAG_ENABLE_PAGE_DEFRAG) {
        err = __bin_depage(db, bin);
        if ((err == SX_UTILS_STATUS_SUCCESS) || (err != SX_UTILS_STATUS_NO_RESOURCES)) {
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_utils_status_t bin_get_defrag_counter(bin_database_t database, unsigned int* old_counter, unsigned int* new_counter)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    __bin_database_t* db = (__bin_database_t*)database;

    SX_LOG_ENTER();

    if (db == NULL) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (old_counter != NULL) {
        *old_counter = db->old_reloc_counter;
    }

    if (new_counter != NULL) {
        *new_counter = db->reloc_counter;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t bin_set_relocation_threshold(bin_database_t database, unsigned int relocation_threshold)
{
    sx_utils_status_t err = SX_UTILS_STATUS_PARAM_ERROR;
    __bin_database_t* db = (__bin_database_t*)database;

    SX_LOG_ENTER();
    if (db == NULL) {
        goto out;
    }

    db->relocation_threshold = relocation_threshold;
    err = SX_UTILS_STATUS_SUCCESS;

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t bin_defrag_set_features(bin_database_t database, bin_defrag_features_t features)
{
    sx_utils_status_t err = SX_UTILS_STATUS_PARAM_ERROR;
    __bin_database_t* db = (__bin_database_t*)database;

    SX_LOG_ENTER();

    if (features > DEFRAG_ENABLE_ALL) {
        goto out;
    }

    if (db != NULL) {
        db->defrag_features = features;
        err = SX_UTILS_STATUS_SUCCESS;
    }

out:
    SX_LOG_EXIT();
    return err;
}

int bin_block_compare(const bin_block_t* block1, const bin_block_t* block2)
{
    return block1->index - block2->index;
}
