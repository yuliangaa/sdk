/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/utils/hashtable.h>
#include "complib/cl_mem.h"

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/


/** @file hashtable.c
 *  Implements generic hashtable routines
 */

/* / This struct defines a hashtable */
struct hashtable {
    hashtable_ops_t* ops;   /* /< Sub-implementation specific information */
    uint32_t         count;
    cl_qlist_t       buckets[0]; /* /< Array of hashtable buckets, indexed by hash-value. Each bucket is a linked-list of hashtable entries */
};
hashtable_t* hashtable_alloc(hashtable_ops_t* ops)
{
    uint32_t bucketnum;
    /* Allocate a table with enough buckets for the sub-implementation */
    uint32_t     size = sizeof(hashtable_t) + (sizeof(cl_qlist_t) * ops->num_of_buckets);
    hashtable_t* ret = (hashtable_t*)cl_malloc(size);

    if (ret == NULL) {
        return NULL;
    }

    /* Set table members */
    ret->count = 0;
    ret->ops = ops;

    /* Initialize empty buckets */
    for (bucketnum = 0; bucketnum < ret->ops->num_of_buckets; bucketnum++) {
        cl_qlist_init(&ret->buckets[bucketnum]);
    }

    return ret;
}

void hashtable_free(hashtable_t* table)
{
    uint32_t bucketnum;

    /* Empty all buckets */
    for (bucketnum = 0; bucketnum < table->ops->num_of_buckets; bucketnum++) {
        cl_qlist_t* bucket = &table->buckets[bucketnum];
        /* Free all entries in the bucket, and their nodes */
        cl_list_item_t* item = cl_qlist_head(bucket);
        while (item != cl_qlist_end(bucket)) {
            cl_list_item_t* this_item = item;
            item = cl_qlist_next(item);

            cl_qlist_remove_item(bucket, this_item);
            table->ops->free_func(this_item);
        }
    }
    /* Free the table itself */
    cl_free(table);
}

uint32_t hashtable_count(hashtable_t* table)
{
    return table->count;
}

/** Retrieve a hashtable bucket node, for a given entry key
 *  This is a utility function. This operation has O(N/B) runtime complexity, and is the main algorithm of the hash table
 *  @param table A hashtable to search
 *  @param table_entry_key A pointer to an entry which is used as a lookup key
 *  @param bucketnum Returns the bucket number in which this key resides (e.g. the hash value). Must not be NULL
 *  @param table_entry If non-NULL, returns a bucket list, whose bucket index is the hash value of the table_entry_key
 *  @return Returns an existing entry if the key exists in the table found, or NULL otherwise
 */
static cl_list_item_t* __hashtable_bucket_lookup(hashtable_t   * table,
                                                 cl_list_item_t* table_entry_key,
                                                 cl_qlist_t   ** relevant_bucket)
{
    cl_qlist_t    * bucket;
    cl_list_item_t* item;

    /* Find the bucket for this key, using the hash */
    uint32_t bucketnum = table->ops->hash_func(table_entry_key);

    CL_ASSERT(bucketnum <= table->ops->num_of_buckets);

    bucket = &table->buckets[bucketnum];
    if (relevant_bucket != NULL) {
        *relevant_bucket = bucket;
    }

    item = cl_qlist_head(bucket);
    /* Locate the specific entry in the bucket, with the same key */
    while (item != cl_qlist_end(bucket)) {
        /* If it's the same pointer, no need to look further */
        if (table_entry_key == item) {
            return item;
        }
        if (table->ops->cmp_func(table_entry_key, item) == CL_SUCCESS) {
            return item;
        }

        item = cl_qlist_next(item);
    }
    return NULL;
}

cl_status_t hashtable_bucket_lookup(IN hashtable_t    *table,
                                    IN cl_list_item_t *table_entry_key,
                                    OUT cl_qlist_t   **relevant_bucket)
{
    uint32_t bucketnum = 0;

    /* Find the bucket for this key, using the hash */
    bucketnum = table->ops->hash_func(table_entry_key);

    CL_ASSERT(bucketnum <= table->ops->num_of_buckets);

    *relevant_bucket = &table->buckets[bucketnum];

    return CL_SUCCESS;
}

cl_status_t hashtable_add_entry(hashtable_t* table, cl_list_item_t* table_entry)
{
    cl_qlist_t    * bucket;
    cl_list_item_t* existing_entry;

    /* Find this entry in the table */
    existing_entry = __hashtable_bucket_lookup(table, table_entry, &bucket);
    if (existing_entry != NULL) {
        /* Key already exists */
        return CL_DUPLICATE;
    }

    /* Create a new node */
    cl_qlist_insert_head(bucket, table_entry);
    table->count++;
    return CL_SUCCESS;
}

cl_status_t hashtable_add_entry_without_search(hashtable_t* table, cl_list_item_t* table_entry)
{
    cl_qlist_t * bucket;
    cl_status_t  err;

    err = hashtable_bucket_lookup(table, table_entry, &bucket);
    if (err != CL_SUCCESS) {
        return err;
    }

    /* Create a new node */
    cl_qlist_insert_head(bucket, table_entry);
    table->count++;
    return err;
}

cl_status_t hashtable_delete_entry(hashtable_t* table, cl_list_item_t* table_entry_key)
{
    cl_qlist_t    * bucket;
    cl_list_item_t* existing_entry;

    existing_entry = __hashtable_bucket_lookup(table, table_entry_key, &bucket);
    if (existing_entry == NULL) {
        /* Key does not exist */
        return CL_NOT_FOUND;
    }

    /* Unlink this node */
    cl_qlist_remove_item(bucket, existing_entry);
    /* Free this node's entry */
    table->ops->free_func(existing_entry);
    table->count--;
    return CL_SUCCESS;
}

cl_status_t hashtable_delete_entry_without_search(hashtable_t* table, cl_list_item_t* table_entry)
{
    cl_qlist_t * bucket;
    cl_status_t  err = CL_SUCCESS;

    err = hashtable_bucket_lookup(table, table_entry, &bucket);
    if (err != CL_SUCCESS) {
        return err;
    }

    /* Unlink this node */
    cl_qlist_remove_item(bucket, table_entry);
    /* Free this node's entry */
    table->ops->free_func(table_entry);
    table->count--;
    return err;
}

cl_list_item_t* hashtable_lookup(hashtable_t* table, cl_list_item_t* table_entry_key)
{
    /* Find this entry in the table */
    return __hashtable_bucket_lookup(table, table_entry_key, NULL);
}

cl_list_item_t* hashtable_enum_entries(hashtable_t* table, hashtable_enum_cb cb, void* cbparam)
{
    uint32_t bucketnum;

    /* Iterate buckets */
    for (bucketnum = 0; bucketnum < table->ops->num_of_buckets; bucketnum++) {
        cl_qlist_t    * bucket = &table->buckets[bucketnum];
        cl_list_item_t* next_item = NULL;
        /* Iterate entries inside bucket */
        cl_list_item_t* item = cl_qlist_head(bucket);
        /* Locate the specific entry in the bucket, with the same key */
        while (item != cl_qlist_end(bucket)) {
            next_item = cl_qlist_next(item);
            if (cb(item, cbparam) != CL_NOT_DONE) {
                return item;
            }

            item = next_item;
        }
    }
    return NULL;
}
