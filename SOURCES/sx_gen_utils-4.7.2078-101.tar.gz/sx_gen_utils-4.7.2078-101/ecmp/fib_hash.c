/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/utils/fib_hash.h>
#include <string.h>


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/


/** @file fib_hash.c
 *  Implements Fibonacci hash
 */

uint32_t trunc_msb(uint32_t value, uint32_t bits)
{
    return (value & 0xFFFFFFFF) >> (32 - bits);
}

uint64_t trunc_msb64(uint64_t value, uint32_t bits)
{
    return (value & 0xFFFFFFFFFFFFFFFF) >> (64 - bits);
}

/** Utility function. Compute Fibonacci Hash of up to 32-bits, of a 32-bit value
 *  @param val A 32-bit value to hash
 *  @param bits Number of hash-bits to return. Must be between 1 and 32
 *  @return A (bits)-bit hash value
 */
static uint32_t __fib_hash_uint32(uint32_t val, uint32_t bits)
{
    /* Multiply by golden ratio */
    uint32_t hash = val * 0x9e370001UL;

    /* And trim the low-order bits, which are less random */
    return trunc_msb(hash, bits);
}

static uint64_t __fib_hash_uint64(uint64_t val, uint32_t bits)
{
    /* Multiply by golden ratio */
    uint64_t hash = val * 11400714819323198485ULL;

    /* And trim the low-order bits, which are less random */
    return trunc_msb64(hash, bits);
}


uint32_t fib_hash_add(uint32_t hash, const void* data, uint32_t len, uint32_t bits)
{
    const uint32_t* pdata = (const uint32_t*)data;

    /* Hash whole 32-bit words */
    while (len >= sizeof(uint32_t)) {
        hash ^= __fib_hash_uint32(*pdata, bits);
        pdata++;
        len -= sizeof(uint32_t);
    }
    if (len > 0) {
        /* Hash the leftover bytes too (as a trimmed 32-bit value) */
        uint32_t value = 0;
        memcpy(&value, pdata, len);
        hash ^= __fib_hash_uint32(value, bits);
    }
    return hash;
}

uint64_t fib_hash_add64(uint64_t hash, const void* data, uint32_t len, uint32_t bits)
{
    const uint64_t* pdata = (const uint64_t*)data;

    /* Hash whole 64-bit words */
    while (len >= sizeof(uint64_t)) {
        hash ^= __fib_hash_uint64(*pdata, bits);
        pdata++;
        len -= sizeof(uint64_t);
    }
    if (len > 0) {
        /* Hash the leftover bytes too (as a trimmed 64-bit value) */
        uint64_t value = 0;
        memcpy(&value, pdata, len);
        hash ^= __fib_hash_uint64(value, bits);
    }
    return hash;
}
