/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <unistd.h>
#include <stdlib.h>
#include <sx/utils/ecmp_allocator.h>
#include <sx/utils/hashtable.h>
#include <sx/utils/fib_hash.h>
#include <complib/cl_mem.h>
#include <complib/sx_log.h>
#include <complib/cl_dbg.h>

#undef  __MODULE__
#define __MODULE__ ECMP_ALLOCATOR


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

#define ECMP_LOOKUP_BUCKET_BITS 10
#define ECMP_LOOKUP_BUCKETS     (1 << ECMP_LOOKUP_BUCKET_BITS)

#define SX_ROUTER_NEXT_HOP_MAX (64)


static const uint32_t ecmp_allocator_schema[SX_ROUTER_NEXT_HOP_MAX + 1] = {
    /* 0 next hops */
    0,
    /* 1 next hops */
    1,
    /* 2 next hops */
    2,
    /* 3-4 next hops */
    8, 8,
    /* 5-16 next hops */
    16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
    /* 17-32 next hops */
    32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
    /* 33-64 next hops */
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
};

typedef struct ecmp_block_data {
    cl_pool_item_t pool_item;
    /* Key material: The set of next hops */
    uint32_t           next_hop_count;
    neigh_ecmp_data_t* next_hop_set[SX_ROUTER_NEXT_HOP_MAX];

    /* The adjacency block for this ECMP group */
    bin_block_t block;
    /* ecmp_db.lookup_table item */
    cl_list_item_t hashtable_item;
    /* block_to_entry map item */
    cl_map_item_t map_item;
    /* Best-match-search metadata */
    int                bms_sequence_num;
    uint32_t           bms_match_count;
    neigh_ecmp_data_t* bms_last_neigh;
    /* How many times this block is used by a user of this module */
    uint32_t reference_count;
} ecmp_block_data_t;

static int ecmp_allocator_initialized_s = FALSE;
static struct {
    /* Lookup table for ECMP data, holds associations in the form: next-hop-set -> ecmp_block_data_t */
    struct hashtable* lookup_table;
    /* Lookup map for ECMP data, holds associations in the form: adjacency-block-index -> ecmp_block_data_t */
    cl_qmap_t block_to_entry;
    /* Global best-match search sequence number */
    int bms_sequence;
    /* User's adjacency table */
    bin_database_t adjacency_table;
    /* User's adjacency allocator callback */
    bin_relocation_cost_t router_relocation_cost;
    /* User's adjacency allocator callback */
    bin_relocation_t router_block_moved;
    /* User's adjacency allocator callback */
    adjacency_set_t adjacency_set;
    /* User's enlarge callback */
    ecmp_enlarge_t enlarge_cb;
    /* A pool of neigh_ecmp_entry_t objects */
    cl_qpool_t neigh_ecmp_pool;
    /* A pool of ecmp_block_data_t objects */
    cl_qpool_t ecmp_block_data_pool;

#ifdef UNITTESTS
    /* Accounting information for this module */
    ecmp_accounting_t accounting;
#endif
} ecmp_db;
static uint32_t __ecmp_lookup_table_hash_func(cl_list_item_t* entry)
{
    uint32_t           hash = 0, index;
    ecmp_block_data_t* lookup_entry = PARENT_STRUCT(entry, ecmp_block_data_t, hashtable_item);

    /* Add the count to the hash */
    hash = fib_hash_add(hash, &lookup_entry->next_hop_count,
                        sizeof(lookup_entry->next_hop_count),
                        ECMP_LOOKUP_BUCKET_BITS);
    /* Add the next hops to the hash */
    for (index = 0; index < lookup_entry->next_hop_count; index++) {
        /* Hash the pointers to the neigh_entry structs */
        hash ^= fib_hash_add(0, &lookup_entry->next_hop_set[index],
                             sizeof(lookup_entry->next_hop_set[index]),
                             ECMP_LOOKUP_BUCKET_BITS);
    }
    return hash;
}

static void __ecmp_lookup_table_free_func(cl_list_item_t* entry)
{
    ecmp_block_data_t* lookup_entry = PARENT_STRUCT(entry, ecmp_block_data_t, hashtable_item);

    cl_qpool_put(&ecmp_db.ecmp_block_data_pool, &lookup_entry->pool_item);
}

static cl_status_t __ecmp_lookup_table_cmp_func(cl_list_item_t* entry1, cl_list_item_t* entry2)
{
    uint32_t           index;
    ecmp_block_data_t* lookup_entry1 = PARENT_STRUCT(entry1, ecmp_block_data_t, hashtable_item);
    ecmp_block_data_t* lookup_entry2 = PARENT_STRUCT(entry2, ecmp_block_data_t, hashtable_item);

    /* Compare the next-hop-set size */
    if (lookup_entry1->next_hop_count != lookup_entry2->next_hop_count) {
        return CL_REJECT;
    }

    /* Compare the next-hops one by one */
    for (index = 0; index < lookup_entry1->next_hop_count; index++) {
        if (lookup_entry1->next_hop_set[index] != lookup_entry2->next_hop_set[index]) {
            return CL_REJECT;
        }
    }
    return CL_SUCCESS;
}

static hashtable_ops_t ecmp_lookup_table_ops = {
    ECMP_LOOKUP_BUCKETS, /* num_of_buckets */
    __ecmp_lookup_table_hash_func, /* hash_func */
    __ecmp_lookup_table_free_func, /* free_func */
    __ecmp_lookup_table_cmp_func, /* cmp_func */
};
static sx_utils_status_t __ecmp_hw_delete(bin_block_t* block)
{
    uint32_t          block_start_index, block_offset;
    sx_utils_status_t err;

    CL_ASSERT(bin_is_block_valid(block));
    err = bin_get_slot_index(ecmp_db.adjacency_table, block, &block_start_index);
    CL_ASSERT(err == SX_UTILS_STATUS_SUCCESS);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        return err;
    }

    for (block_offset = 0; block_offset < block->size; block_offset++) {
        err = ecmp_db.adjacency_set(block_start_index + block_offset, NULL);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            return err;
        }
    }
    return SX_UTILS_STATUS_SUCCESS;
}

static sx_utils_status_t __ecmp_hw_write(neigh_ecmp_data_t **neigh_arr, uint32_t next_hop_num, bin_block_t* block)
{
    uint32_t          div, spare, dup_count;
    uint32_t          neigh, block_start_index, block_offset;
    sx_utils_status_t err;

    CL_ASSERT(block->size >= next_hop_num);

    div = block->size / next_hop_num;
    spare = block->size % next_hop_num;

    err = bin_get_slot_index(ecmp_db.adjacency_table, block, &block_start_index);
    CL_ASSERT(err == SX_UTILS_STATUS_SUCCESS);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        return err;
    }

    neigh = 0;
    block_offset = 0;
    while (block_offset < block->size) {
        /* Skip to the next neighbor */
        CL_ASSERT(neigh < next_hop_num);

        /* Determine how many times to duplicate this neighbor in the block */
        dup_count = div;
        if (spare > 0) {
            dup_count++;
            spare--;
        }

        /* Add duplicate entries, distributed for load balancing */
        while (dup_count > 0) {
            CL_ASSERT(block_offset < block->size);

            err = ecmp_db.adjacency_set(block_start_index + block_offset, neigh_arr[neigh]);
            if (err != SX_UTILS_STATUS_SUCCESS) {
                return err;
            }

#ifdef UNITTESTS
            ecmp_db.accounting.ratr_set_count++;
#endif
            block_offset++;
            dup_count--;
        }

        /* Done with this neighbor. Move to the next one */
        neigh++;
    }
    return SX_UTILS_STATUS_SUCCESS;
}

static sx_utils_status_t __ecmp_bin_block_moved(bin_database_t database,
                                                bin_block_t  * old_block,
                                                bin_block_t  * new_block,
                                                boolean_t      enable_ecmp_move)
{
    sx_utils_status_t  err;
    cl_map_item_t    * map_item;
    ecmp_block_data_t* entry;

    UNUSED_PARAM(enable_ecmp_move);

    CL_ASSERT(old_block->size == new_block->size);
    CL_ASSERT(old_block->index != new_block->index);

    /*Calling with enable_ecmp_move==FALSE. If old_block is Adjacency ECMP
     * then PARTIALLY_COMPLETE will be returned.
     * else Router module will handle the move.*/
    err = ecmp_db.router_block_moved(database, old_block, new_block, FALSE);
    if ((err != SX_UTILS_STATUS_SUCCESS) && (err != SX_UTILS_STATUS_PARTIALLY_COMPLETE)) {
        SX_LOG_ERR("Cannot move entry from %u to %u, router callback failed with err: %s\n",
                   old_block->index, new_block->index, SX_UTILS_STATUS_MSG(err));
        return err;
    }
    /*The entry is an Adjacency ECMP*/
    else if (err == SX_UTILS_STATUS_PARTIALLY_COMPLETE) { /*Adjacency_ecmp*/
        uint32_t index;
        /* Moving an ECMP block. Locate the entry */
        CL_ASSERT(database == ecmp_db.adjacency_table);
        err = bin_get_slot_index(ecmp_db.adjacency_table, old_block, &index);
        CL_ASSERT(err == SX_UTILS_STATUS_SUCCESS);
        map_item = cl_qmap_get(&ecmp_db.block_to_entry, index);
        CL_ASSERT(map_item != cl_qmap_end(&ecmp_db.block_to_entry));
        entry = PARENT_STRUCT(map_item, ecmp_block_data_t, map_item);

        /* Create new block in hardware */
        err = __ecmp_hw_write(entry->next_hop_set, entry->next_hop_count, new_block);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Cannot move block from %u to %u, __ecmp_hw_write failed with err: %s\n",
                       old_block->index, new_block->index, SX_UTILS_STATUS_MSG(err));
            return err;
        }

        /* Let the router update its database and issue any register access */
        err = ecmp_db.router_block_moved(database, old_block, new_block, TRUE);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Cannot move block from %u to %u, router callback failed with err: %s\n",
                       old_block->index, new_block->index, SX_UTILS_STATUS_MSG(err));
            return err;
        }

        /* Update the ECMP allocator DB as well */
        cl_qmap_remove_item(&ecmp_db.block_to_entry, &entry->map_item);
        entry->block = *new_block;
        err = bin_get_slot_index(ecmp_db.adjacency_table, new_block, &index);
        CL_ASSERT(err == SX_UTILS_STATUS_SUCCESS);
        cl_qmap_insert(&ecmp_db.block_to_entry, index, &entry->map_item);
#ifdef UNITTESTS
        ecmp_db.accounting.block_movement_count++;
#endif

        /* Delete the old block from hardware */
        err = __ecmp_hw_delete(old_block);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG_ERR("Cannot move block from %u to %u, __ecmp_hw_delete failed with err: %s\n",
                       old_block->index, new_block->index, SX_UTILS_STATUS_MSG(err));
            return err;
        }

        return SX_UTILS_STATUS_SUCCESS;
    } else { /*The entry was not an adjacency ECMP and was handled by the router module*/
#ifdef UNITTESTS
        ecmp_db.accounting.block_movement_count++;
#endif
        return SX_UTILS_STATUS_SUCCESS;
    }

    /* Size should never be 0 */
    CL_ASSERT(FALSE);
    return SX_UTILS_STATUS_SUCCESS;
}

static uint32_t __adjacency_relocation_cost(bin_database_t database, bin_block_t* old_block)
{
    /* Only the router knows the real cost of moving a neighbor */
    return ecmp_db.router_relocation_cost(database, old_block);
}

sx_utils_status_t ecmp_allocator_init(ecmp_params_t* params)
{
    sx_utils_status_t err;
    cl_status_t       cl_err;

    if (ecmp_allocator_initialized_s) {
        return SX_UTILS_STATUS_ALREADY_INITIALIZED;
    }
    if (params == NULL) {
        return SX_UTILS_STATUS_PARAM_NULL;
    }
    if ((params->adjacency_table == NULL) ||
        (params->adjacency_set == NULL) ||
        (params->router_relocation_cost == NULL) ||
        (params->router_block_moved == NULL)) {
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    err = bin_init(&ecmp_db.adjacency_table,
                   params->arp_id_min,
                   params->arp_id_max,
                   __adjacency_relocation_cost,
                   __ecmp_bin_block_moved,
                   RELOCATION_THRESHOLD_ALL);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        return err;
    }

    cl_err = CL_QPOOL_INIT(&ecmp_db.neigh_ecmp_pool,
                           0, 0, SX_ROUTER_NEXT_HOP_MAX,
                           sizeof(neigh_ecmp_entry_t),
                           NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    cl_err = CL_QPOOL_INIT(&ecmp_db.ecmp_block_data_pool,
                           SX_ROUTER_NEXT_HOP_MAX, 0, SX_ROUTER_NEXT_HOP_MAX,
                           sizeof(ecmp_block_data_t),
                           NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        return SX_UTILS_STATUS_NO_RESOURCES;
    }

    ecmp_allocator_initialized_s = TRUE;
    ecmp_db.lookup_table = hashtable_alloc(&ecmp_lookup_table_ops);
    cl_qmap_init(&ecmp_db.block_to_entry);
    ecmp_db.bms_sequence = 0;
    ecmp_db.router_block_moved = params->router_block_moved;
    ecmp_db.router_relocation_cost = params->router_relocation_cost;
    ecmp_db.adjacency_set = params->adjacency_set;
    ecmp_db.enlarge_cb = params->enlarge_cb;
#ifdef UNITTESTS
    ecmp_db.accounting.max_distinct_blocks = 0;
    ecmp_db.accounting.ratr_set_count = 0;
    ecmp_db.accounting.block_movement_count = 0;
    ecmp_db.accounting.exact_hit_count = 0;
    ecmp_db.accounting.best_match_count = 0;
    ecmp_db.accounting.single_path_match_count = 0;
#endif

    *params->adjacency_table = ecmp_db.adjacency_table;
    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t ecmp_allocator_deinit()
{
    if (!ecmp_allocator_initialized_s) {
        return SX_UTILS_STATUS_NOT_INITIALIZED;
    }

    ecmp_allocator_initialized_s = FALSE;
    bin_deinit(ecmp_db.adjacency_table);
    ecmp_db.adjacency_table = NULL;
    ecmp_db.router_block_moved = NULL;
    ecmp_db.router_relocation_cost = NULL;
    cl_qmap_remove_all(&ecmp_db.block_to_entry);
    hashtable_free(ecmp_db.lookup_table);
    ecmp_db.lookup_table = NULL;
    CL_QPOOL_DESTROY(&ecmp_db.neigh_ecmp_pool);
    CL_QPOOL_DESTROY(&ecmp_db.ecmp_block_data_pool);

    return SX_UTILS_STATUS_SUCCESS;
}

#ifdef UNITTESTS
void ecmp_get_accounting(ecmp_accounting_t* accounting)
{
    CL_ASSERT(ecmp_allocator_initialized_s);
    *accounting = ecmp_db.accounting;
}

void ecmp_dump()
{
    cl_map_item_t* map_item;
    uint32_t       index, blocknum = 0;

    printf("ECMP Allocator Dump\n");
    printf("===================\n");
    printf("Total blocks: %u\n", cl_qmap_count(&ecmp_db.block_to_entry));

    for (map_item = cl_qmap_head(&ecmp_db.block_to_entry);
         map_item != cl_qmap_end(&ecmp_db.block_to_entry);
         map_item = cl_qmap_next(map_item)) {
        ecmp_block_data_t* entry = PARENT_STRUCT(map_item, ecmp_block_data_t, map_item);

        printf("%u. Block index=%u; size=%u; ref_count=%u :\n",
               blocknum++, entry->block.index, entry->block.size, entry->reference_count);
        printf("\tHops: ");
        for (index = 0; index < entry->next_hop_count; index++) {
            printf("%p ", entry->next_hop_set[index]);
        }
        printf("\n");
    }
}

#endif

void ecmp_data_init(neigh_ecmp_data_t* ecmp_data)
{
    cl_qmap_init(&ecmp_data->ecmps);
}

static int __ecmp_pointer_compare(const void* ptr1, const void* ptr2)
{
    const char* neigh1 = *(const char**)ptr1;
    const char* neigh2 = *(const char**)ptr2;

    return neigh1 - neigh2;
}

static void __ecmp_lookup_key(neigh_ecmp_data_t **neigh_arr, uint32_t next_hop_num, ecmp_block_data_t* entry)
{
    uint32_t neigh;

    entry->next_hop_count = 0;
    for (neigh = 0; neigh < next_hop_num; neigh++) {
        entry->next_hop_set[entry->next_hop_count] = neigh_arr[neigh];
        entry->next_hop_count++;
    }
    qsort((void*)entry->next_hop_set, entry->next_hop_count, sizeof(entry->next_hop_set[0]), __ecmp_pointer_compare);
}

static void __add_neigh_ecmp(ecmp_block_data_t* entry, neigh_ecmp_data_t* neigh)
{
    neigh_ecmp_entry_t* neigh_ecmp;

    /* Add this block to the list of blocks which use this neighbor */
    cl_pool_item_t* pool_item = cl_qpool_get(&ecmp_db.neigh_ecmp_pool);

    CL_ASSERT(pool_item != NULL);
    neigh_ecmp = PARENT_STRUCT(pool_item, neigh_ecmp_entry_t, pool_item);

    neigh_ecmp->entry = entry;
    neigh_ecmp->neigh = neigh;
    cl_qmap_insert(&neigh->ecmps, (uint64_t)(size_t)entry, &neigh_ecmp->map_item);
}

static void __del_neigh_ecmp(ecmp_block_data_t* entry, neigh_ecmp_data_t* neigh)
{
    neigh_ecmp_entry_t* neigh_ecmp;
    cl_map_item_t     * map_item;

    map_item = cl_qmap_get(&neigh->ecmps, (uint64_t)(size_t)entry);
    CL_ASSERT(map_item != cl_qmap_end(&neigh->ecmps));
    neigh_ecmp = PARENT_STRUCT(map_item, neigh_ecmp_entry_t, map_item);

    cl_qmap_remove_item(&neigh->ecmps, &neigh_ecmp->map_item);
    cl_qpool_put(&ecmp_db.neigh_ecmp_pool, &neigh_ecmp->pool_item);
}

static ecmp_block_data_t* __ecmp_block_to_entry(bin_block_t* block)
{
    uint32_t index;
/*  sx_utils_status_t err;*/
    cl_map_item_t* map_item;

/*  err =*/ bin_get_slot_index(ecmp_db.adjacency_table, block, &index);
/*  CL_ASSERT(err == SX_UTILS_STATUS_SUCCESS);*/
    map_item = cl_qmap_get(&ecmp_db.block_to_entry, index);
    if (map_item == cl_qmap_end(&ecmp_db.block_to_entry)) {
        return NULL;
    }
    return PARENT_STRUCT(map_item, ecmp_block_data_t, map_item);
}

sx_utils_status_t ecmp_allocate_block(neigh_ecmp_data_t **neigh_arr, uint32_t next_hop_num, bin_block_t* block)
{
    sx_utils_status_t  err;
    uint32_t           neigh;
    ecmp_block_data_t* entry;
    uint32_t           index;
/*  int ret;*/
    cl_pool_item_t* pool_item;

    if (!ecmp_allocator_initialized_s) {
        return SX_UTILS_STATUS_NOT_INITIALIZED;
    }
    if ((neigh_arr == NULL) || (block == NULL)) {
        return SX_UTILS_STATUS_PARAM_NULL;
    }
    /* Note: single next-hop is single-path. not ECMP */
    if ((next_hop_num < 2) || (next_hop_num > SX_ROUTER_NEXT_HOP_MAX)) {
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* Caller should not call this function if less than 2 neighbors are ARP-resolved yet */
    CL_ASSERT(next_hop_num >= 2);
    CL_ASSERT(!bin_is_block_valid(block));

    /* Choose ECMP block size */
    block->size = ecmp_allocator_schema[next_hop_num];

    /* Allocate a new ECMP block for the neighbor-set, and calculate distribution within the block */
    err = bin_allocate(ecmp_db.adjacency_table, block);
    if (err == SX_UTILS_STATUS_NO_RESOURCES) {
        if (ecmp_db.enlarge_cb != NULL) {
            err = ecmp_db.enlarge_cb(ecmp_db.adjacency_table);
            if (err != SX_UTILS_STATUS_SUCCESS) {
                if (err != SX_UTILS_STATUS_NO_RESOURCES) {
                    SX_LOG_ERR("Failed to enlarge ECMP's bin allocator: %s\n",
                               SX_UTILS_STATUS_MSG(err));
                }
                bin_block_init(block);
                return err;
            }
            err = bin_allocate(ecmp_db.adjacency_table, block);
        }
    }
    if (err != SX_UTILS_STATUS_SUCCESS) {
        bin_block_init(block);
        return err;
    }

    err = __ecmp_hw_write(neigh_arr, next_hop_num, block);
    if (err != SX_UTILS_STATUS_SUCCESS) {
        bin_free(ecmp_db.adjacency_table, block);
        bin_block_init(block);
        return err;
    }

    /* Create an entry for the lookup table */
    pool_item = cl_qpool_get(&ecmp_db.ecmp_block_data_pool);
    CL_ASSERT(pool_item != NULL);
    entry = PARENT_STRUCT(pool_item, ecmp_block_data_t, pool_item);

    __ecmp_lookup_key(neigh_arr, next_hop_num, entry);
    entry->block = *block;
    entry->bms_sequence_num = 0;
    entry->reference_count = 1;

/*  ret =*/ hashtable_add_entry(ecmp_db.lookup_table, &entry->hashtable_item);
    /* If hashtable_add() failed because the key already exists,
     *  then this whole function shouldn't have been called in the first place,
     *  because there is an exact match */
/*  CL_ASSERT(ret == CL_SUCCESS);*/
#ifdef UNITTESTS
    {
        uint32_t distinct_blocks = hashtable_count(ecmp_db.lookup_table);
        if (ecmp_db.accounting.max_distinct_blocks < distinct_blocks) {
            ecmp_db.accounting.max_distinct_blocks = distinct_blocks;
        }
    }
#endif

    err = bin_get_slot_index(ecmp_db.adjacency_table, &entry->block, &index);
    CL_ASSERT(err == SX_UTILS_STATUS_SUCCESS);
    cl_qmap_insert(&ecmp_db.block_to_entry, index, &entry->map_item);

    for (neigh = 0; neigh < next_hop_num; neigh++) {
        __add_neigh_ecmp(entry, neigh_arr[neigh]);
    }

    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t ecmp_find_exact_match(neigh_ecmp_data_t **neigh_arr, uint32_t next_hop_num, bin_block_t* block)
{
    ecmp_block_data_t  entry_key;
    ecmp_block_data_t* match_entry;
    cl_list_item_t   * entry;

    if (!ecmp_allocator_initialized_s) {
        return SX_UTILS_STATUS_NOT_INITIALIZED;
    }
    if ((neigh_arr == NULL) || (block == NULL)) {
        return SX_UTILS_STATUS_PARAM_NULL;
    }
    if ((next_hop_num < 2) || (next_hop_num > SX_ROUTER_NEXT_HOP_MAX)) {
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    __ecmp_lookup_key(neigh_arr, next_hop_num, &entry_key);
    if (entry_key.next_hop_count < 1) {
        return SX_UTILS_STATUS_PARAM_ERROR;
    }
    entry = hashtable_lookup(ecmp_db.lookup_table, &entry_key.hashtable_item);
    if (entry == NULL) {
        return SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    }

    match_entry = PARENT_STRUCT(entry, ecmp_block_data_t, hashtable_item);
    *block = match_entry->block;
    match_entry->reference_count++;
    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t ecmp_find_best_match(neigh_ecmp_data_t **neigh_arr, uint32_t next_hop_num, bin_block_t* block)
{
    uint32_t           neigh;
    uint32_t           best_match_count = 0;
    ecmp_block_data_t* best_match_entry = NULL;
    ecmp_block_data_t* ecmp_entry = NULL;
    cl_map_item_t    * map_item = NULL;

    if (!ecmp_allocator_initialized_s) {
        return SX_UTILS_STATUS_NOT_INITIALIZED;
    }
    if ((neigh_arr == NULL) || (block == NULL)) {
        return SX_UTILS_STATUS_PARAM_NULL;
    }
    if ((next_hop_num < 2) || (next_hop_num > SX_ROUTER_NEXT_HOP_MAX)) {
        return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE;
    }

    ecmp_db.bms_sequence++;

    for (neigh = 0; neigh < next_hop_num; neigh++) {
        for (map_item = cl_qmap_head(&neigh_arr[neigh]->ecmps);
             map_item != cl_qmap_end(&neigh_arr[neigh]->ecmps);
             map_item = cl_qmap_next(map_item)) {
            neigh_ecmp_entry_t* neigh_ecmp = PARENT_STRUCT(map_item, neigh_ecmp_entry_t, map_item);

            ecmp_entry = neigh_ecmp->entry;
            if (ecmp_entry == NULL) {
                continue;
            }

            if (ecmp_entry->bms_sequence_num != ecmp_db.bms_sequence) {
                /* "Init" the search once for each neigh,
                 *  but only for those neighs which are relevant to this search */
                ecmp_entry->bms_sequence_num = ecmp_db.bms_sequence;
                ecmp_entry->bms_match_count = 0;
                ecmp_entry->bms_last_neigh = NULL;
            }

            if (ecmp_entry->bms_last_neigh != neigh_arr[neigh]) {
                /* Found another single-neigh match */
                ecmp_entry->bms_match_count++;
                ecmp_entry->bms_last_neigh = neigh_arr[neigh];

                if (ecmp_entry->bms_match_count == ecmp_entry->next_hop_count) {
                    /* Matched whole entry.
                     *  This means that the ecmp_entry does not contains any neighs other than the ones we want */
                    if (ecmp_entry->next_hop_count > best_match_count) {
                        /* This is a better match */
                        best_match_count = ecmp_entry->next_hop_count;
                        best_match_entry = ecmp_entry;
                    }
                }
            }
        }
    }
    if (best_match_count == 0) {
        return SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    }
    best_match_entry->reference_count++;
    *block = best_match_entry->block;
    return SX_UTILS_STATUS_SUCCESS;
}

sx_utils_status_t ecmp_free_block(bin_block_t* block)
{
    cl_status_t        cl_err = CL_SUCCESS;
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    cl_map_item_t    * map_item;
    ecmp_block_data_t* entry;
    uint32_t           index, nh_index;

    if (!ecmp_allocator_initialized_s) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        goto out;
    }
    if (block == NULL) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    entry = __ecmp_block_to_entry(block);
    if (entry == NULL) {
        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    entry->reference_count--;
    if (entry->reference_count == 0) {
        /* Only really remove this block, if it's not used anymore */
        err = bin_get_slot_index(ecmp_db.adjacency_table, block, &index);
        CL_ASSERT(err == SX_UTILS_STATUS_SUCCESS);

        for (nh_index = 0; nh_index < entry->next_hop_count; nh_index++) {
            /* Delete this block from the list of blocks which use this neighbor */
            __del_neigh_ecmp(entry, entry->next_hop_set[nh_index]);
        }

        /* Delete this block from hardware */
        err = __ecmp_hw_delete(block);
        if (err != SX_UTILS_STATUS_SUCCESS) {
            return err;
        }

        map_item = cl_qmap_remove(&ecmp_db.block_to_entry, index);
        UNUSED_PARAM(map_item);
        cl_err = hashtable_delete_entry(ecmp_db.lookup_table, &entry->hashtable_item);
        if (cl_err != CL_SUCCESS) {
            SX_LOG_ERR("Failed to delete hash table entry, error %s\n", CL_STATUS_MSG(cl_err));
            goto out;
        }
        err = bin_free(ecmp_db.adjacency_table, block);
        CL_ASSERT(err == SX_UTILS_STATUS_SUCCESS);
    }

out:
    return err;
}

/**
 * Note: Must call ecmp_free_block() if successful
 */
sx_utils_status_t ecmp_add(neigh_ecmp_data_t **neigh_arr, uint32_t next_hop_num, bin_block_t* block)
{
    sx_utils_status_t status;

    status = ecmp_find_exact_match(neigh_arr, next_hop_num, block);
    if (status != SX_UTILS_STATUS_ENTRY_NOT_FOUND) {
#ifdef UNITTESTS
        if (status == SX_UTILS_STATUS_SUCCESS) {
            ecmp_db.accounting.exact_hit_count++;
        }
#endif
        return status;
    }

    status = ecmp_allocate_block(neigh_arr, next_hop_num, block);
    if (status != SX_UTILS_STATUS_NO_RESOURCES) {
        return status;
    }

    status = ecmp_find_best_match(neigh_arr, next_hop_num, block);
#ifdef UNITTESTS
    if (status == SX_UTILS_STATUS_SUCCESS) {
        ecmp_db.accounting.best_match_count++;
    } else {
        ecmp_db.accounting.single_path_match_count++;
    }
#endif
    if (status == SX_UTILS_STATUS_SUCCESS) {
        return SX_UTILS_STATUS_PARTIALLY_COMPLETE;
    }
    return status;
}

sx_utils_status_t ecmp_get_block_neighbors(neigh_ecmp_data_t **neigh_arr, uint32_t* next_hop_num, bin_block_t* block)
{
    ecmp_block_data_t* entry;
    uint32_t           index;

    if (!ecmp_allocator_initialized_s) {
        return SX_UTILS_STATUS_NOT_INITIALIZED;
    }
    if ((block == NULL) || (next_hop_num == NULL)) {
        return SX_UTILS_STATUS_PARAM_NULL;
    }

    entry = __ecmp_block_to_entry(block);
    if (entry == NULL) {
        return SX_UTILS_STATUS_ENTRY_NOT_FOUND;
    }

    if (neigh_arr != NULL) {
        for (index = 0; index < entry->next_hop_count; index++) {
            if (index >= *next_hop_num) {
                break;
            }
            neigh_arr[index] = entry->next_hop_set[index];
        }
    }
    *next_hop_num = entry->next_hop_count;
    return SX_UTILS_STATUS_SUCCESS;
}
