/*
 * Copyright (C) 2015-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "gbin_internal.h"
#include <complib/cl_dbg.h>

#undef  __MODULE__
#define __MODULE__ GBIN_MALLOC

/************************************************
 *  Local Type definitions
 ***********************************************/

 #define INITIAL_GC_POOL_SIZE (32)

/************************************************
 *  Global variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cl_qpool_t gc_context_pool;
static boolean_t  gc_pool_initialized = FALSE;
static cl_qpool_t relocate_context_pool;
static boolean_t  relocate_pool_initialized = FALSE;

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_utils_status_t __bai_get_new_group(bai_user_t   *p_user,
                                             bai_group_t **group,
                                             uint32_t      type);
static sx_utils_status_t __bai_hole_del(bai_group_t *p_group,
                                        uint32_t     offset,
                                        uint32_t     size);
static sx_utils_status_t __bai_holes_reinit(bai_group_t *p_group);

/************************************************
 *  Function implementations
 ***********************************************/


/**
 * Update c_max_size value
 *   As groups fill up, the total number of free lines available falls
 * below the size of the largest possible allocation.  There is no point
 * in wasting cycles compressing all the free space into a single block
 * that isn't big enough, so we figure out the maximum size block that
 * is possible and use that.
 *
 * @param[in] p_group - The group to review
 * @param[out] p_group->c_max_size - Max size that can be allocated
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal error
 */
static sx_utils_status_t __bai_update_c_max_size(bai_group_t *p_group)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i, size;

    if (p_group->max_alloc_size == 0) {
        SX_LOG_ERR("max_alloc_size is 0!\n");

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    if (p_group->bucket_cnt == 0) {
        SX_LOG_ERR("bucket_count is 0!\n");

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    if (p_group->free_lines >= p_group->max_alloc_size) {
        /* The most common case */
        p_group->c_max_size = p_group->max_alloc_size;
    } else {
        size = 0;
        for (i = 0; i < p_group->bucket_cnt; i++) {
            if (p_group->free_lines >= p_group->buckets[i].size) {
                size = p_group->buckets[i].size;
                continue;
            }

            /* size now contains the largest possible allocation */
            break;
        }

        /* Might be 0 which means no allocation possible */
        p_group->c_max_size = size;
    }


out:
    return err;
}


/**
 * Generate an internal LID value
 *
 * @param[in] p_user - User context that owns the group
 * @param[in] p_group - Group containing block
 * @param[in] offset - Offset of first line of the block
 * @param[out] ilid_p - Pointer to where to store calculated iLID
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - Null parameter(s) passed
 * @retrun SX_UTILS_STATUS_PARAM_ERROR - offset or group invalid
 */
sx_utils_status_t __bai_ilid(bai_user_t *p_user, bai_group_t      *p_group, uint32_t offset, bai_logical_id_t *ilid_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          idx_grp, idx_type;
    bai_logical_id_t  iLID;

    if ((p_group == NULL) || (ilid_p == NULL)) {
        SX_LOG_ERR("p_group(%p) and/or ilid_p(%p) NULL!\n", p_group,
                   ilid_p);

        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (p_group->type == GROUP_TYPE_FREE) {
        SX_LOG_ERR("Group type is free!\n");

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (offset >= p_group->alloc_size) {
        SX_LOG_ERR("offset %u exceeds group max %u!\n", offset,
                   p_group->alloc_size);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    idx_grp = p_group - p_user->groups;
    idx_type = p_group->p_template - p_user->templates + 1;

    iLID = ((idx_type & p_user->mask_type) << p_user->shift_type) |
           ((idx_grp & p_user->mask_group) << p_user->shift_group) |
           (offset & p_user->mask_line);

    *ilid_p = iLID;


out:
    return err;
}


/**
 * Lookup LID that owns a block
 *   - This is VERY inefficient.  Don't use in performance path...
 *
 * @param[in] p_user - User context that owns the group
 * @param[in] p_group - Group containing block
 * @param[in] offset - Offset of first line of the block
 * @param[out] lid_p - Pointer to where to store the LID
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - Null parameter(s) passed
 * @retrun SX_UTILS_STATUS_PARAM_ERROR - offset or group invalid
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND - No lid maps this offset
 */
sx_utils_status_t bai_offset_to_lid(bai_user_t      *p_user,
                                    bai_group_t     *p_group,
                                    uint32_t         offset,
                                    ba_logical_id_t *lid_p)
{
    sx_utils_status_t    err = SX_UTILS_STATUS_SUCCESS;
    bai_logical_id_t     iLID;
    cl_map_item_t       *p_item = NULL;
    const cl_map_item_t *p_end = NULL;
    bai_lid_info_t      *p_lid_info = NULL;

    if ((p_user == NULL) || (p_group == NULL) || (lid_p == NULL)) {
        SX_LOG_ERR("user(%p) or group(%p) or return lid(%p) NULL!\n",
                   p_user, p_group, lid_p);

        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    /* Make sure offset is valid for this group */
    if (offset >= p_group->alloc_size) {
        SX_LOG_ERR("Internal error - Offset(%u) exceeds group max(%u)!\n",
                   offset, p_group->alloc_size);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Make sure offset points to the first line of a block */
    if ((p_group->array_map[offset] & LS_FIRST_E) == 0) {
        SX_LOG_ERR("Internal error - offset is not first line of block!\n");

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Generate expected iLID value - PARAM_ERROR if unable to do it */
    err = __bai_ilid(p_user, p_group, offset, &iLID);
    if (err) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Scan the LIDs array looking for one that maps to calculated iLID */
    p_end = cl_qmap_end(&p_user->lids_map);
    p_item = cl_qmap_head(&p_user->lids_map);
    while (p_item != p_end) {
        p_lid_info = PARENT_STRUCT(p_item, bai_lid_info_t, map_item);
        if (p_lid_info->ilid == iLID) {
            *lid_p = p_lid_info->lid;
            goto out;
        }
        p_item = cl_qmap_next(p_item);
    }

    err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;


out:
    return err;
}


/**
 * Validate and modify a hole cache entry
 *
 * @param[in] p_group - Group to update
 * @param[in] p_hole - Pointer to hole cache entry to update
 * @param[in] offset - Offset of the hole we want to cache
 * @param[in] len - Length of the hole in lines
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal error of some sort
 */
static sx_utils_status_t __bai_hole_modify(bai_group_t *p_group, bai_hole_t  *p_hole, uint32_t offset, uint32_t len)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          end;

    /* Special case of clearing an entry */
    if (len == 0) {
        p_hole->offset = 0;
        p_hole->len = 0;
        goto out;
    }

    /* Make sure the thing pointed to by offset/len is in array */
    end = offset + len - 1;

    /* End must always be inside the array */
    if (end >= p_group->alloc_size) {
        SX_LOG_ERR("Internal error - hole[%u..%u] ends outside array %u!\n",
                   offset, end, p_group->alloc_size);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* Offset must be inside the array */
    if (offset >= p_group->alloc_size) {
        SX_LOG_ERR("Internal error - hole[%u..%u] outside array %u!\n",
                   offset, end, p_group->alloc_size);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* The first line of a hole must be marked free in allocation map */
    if (p_group->array_map[offset] != 0) {
        SX_LOG_ERR("Internal error - Hole [%u..%u] starts on active line!\n",
                   offset, end);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* The last line of a hole must also be marked free */
    if (p_group->array_map[end] != 0) {
        SX_LOG_ERR("Internal error - Hole [%u..%u] ends on active line!\n",
                   offset, end);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    p_hole->offset = offset;
    p_hole->len = len;


out:
    return err;
}


/**
 * Return pointer to hole with index provided
 *   Before returning the pointer, this function reviews the space on either
 * size of the hole.  Free space is 'added' to the hole.
 *
 * @param[in] p_group - Group to update
 * @param[in] idx - Index requested from holes cache
 * @param[out] hole_p - Pointer to where to store hole pointer
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_ERROR - Invalid index
 */
static sx_utils_status_t __bai_hole_get(bai_group_t *p_group, uint32_t idx, bai_hole_t  **hole_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_hole_t       *hole;
    uint32_t          i;

    if (idx >= MAX_HOLES) {
        SX_LOG_ERR("Index %u exceeds maximum %u!\n", idx, MAX_HOLES);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    hole = &p_group->holes[idx];

    /* If hole is empty, nothing to review */
    if (hole->len == 0) {
        *hole_p = hole;
        goto out;
    }

    /* Expand the hole if there are empty lines beyond it */
    for (i = hole->offset + hole->len; i < p_group->alloc_size; i++) {
        if (p_group->array_map[i] == 0) {
            /* Line is free, add it to the hole */
            err = __bai_hole_modify(p_group, hole, hole->offset,
                                    hole->len + 1);
            if (err) {
                goto out;
            }

            /* Search for another contiguous free line */
            continue;
        }

        /* Once we find a non-free line, we are done */
        break;
    }

    /* Expand this hole if there are any empty lines ahead of it */
    while (hole->offset > 0) {
        if (p_group->array_map[hole->offset - 1] != 0) {
            /* Once we find a non-free line, we are done */
            break;
        }

        err = __bai_hole_modify(p_group, hole, hole->offset - 1,
                                hole->len + 1);
        if (err) {
            goto out;
        }
    }

    *hole_p = hole;


out:
    return err;
}


/**
 * Update holes cache (if there is space)
 *   Also handle merging with a hole ahead of or after the one
 * given.  If all slots for holes are full, this hole may replace
 * the smallest one.
 *
 * @param[in] p_group - Group to update
 * @param[in] offset - Offset of the hole we want to cache
 * @param[in] len - Length of the hole in lines
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - p_group is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - hole does not fit
 */
static sx_utils_status_t __bai_hole_add(bai_group_t *p_group, uint32_t offset, uint32_t len)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_hole_t       *p_hole, *p_before, *p_after, *p_small;
    uint32_t          i;

    if (!p_group) {
        SX_LOG_ERR("p_group is NULL!\n");

        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if ((offset + len) > p_group->alloc_size) {
        SX_LOG_ERR("offset(%u) + len(%u) exceeds array size(%u)!\n", offset,
                   len, p_group->alloc_size);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* No existing holes found around this block */
    p_before = NULL;
    p_after = NULL;

    p_small = &p_group->holes[0];
    for (i = 0; i < MAX_HOLES; i++) {
        p_hole = &p_group->holes[i];

        /* Remember the smallest hole */
        if (p_hole->len < p_small->len) {
            p_small = p_hole;
        }

        /* If this is an empty hole, nothing more to do */
        if (p_hole->len == 0) {
            continue;
        }

        /* Remember hole that describes free space ahead of block */
        if ((p_hole->offset + p_hole->len) == offset) {
            /* Warn, but continue */
            if (p_before != NULL) {
                SX_LOG_WRN("Duplicate holes: %u/%u + %u/%u before %u!\n",
                           p_hole->offset, p_hole->len,
                           p_before->offset, p_before->len, offset);

                /* Clear both cache entries */
                err = __bai_hole_modify(p_group, p_hole, 0, 0);
                if (err) {
                    goto out;
                }

                err = __bai_hole_modify(p_group, p_before, 0, 0);
                if (err) {
                    goto out;
                }

                /* Forget about the before entry */
                p_hole = NULL;
            }

            p_before = p_hole;
        }

        /* Remember hole that describes free space after block */
        if ((p_hole != NULL) && ((offset + len) == p_hole->offset)) {
            /* Warn, but continue */
            if (p_after != NULL) {
                SX_LOG_WRN("Duplicate holes: %u/%u + %u/%u after %u!\n",
                           p_hole->offset, p_hole->len,
                           p_after->offset, p_after->len, offset);

                /* Clear both cache entries */
                err = __bai_hole_modify(p_group, p_hole, 0, 0);
                if (err) {
                    goto out;
                }

                err = __bai_hole_modify(p_group, p_after, 0, 0);
                if (err) {
                    goto out;
                }

                /* Forget about the before entry */
                p_hole = NULL;
            }

            p_after = p_hole;
        }
    }

    /*
     *   If we don't have a cache entry ahead of this block, we should
     * search backwards for uncached holes.  Since the final line of all
     * allocated blocks is always marked, we can look for free lines in
     * the usual way.
     */
    if ((p_before == NULL) && (offset != 0)) {
        while (offset > 0) {
            if (p_group->array_map[offset - 1] != 0) {
                break;
            }

            offset--;
            len++;
        }
    }

    /* Look for non-cached free lines trailing this block */
    if (p_after == NULL) {
        for (i = offset + len; i < p_group->alloc_size; i++) {
            if (p_group->array_map[i] == 0) {
                len++;

                continue;
            }

            break;
        }
    }

    /* If there is a hole trailing this block, merge them */
    if (p_after) {
        len += p_after->len;

        err = __bai_hole_modify(p_group, p_after, offset, len);
        if (err) {
            goto out;
        }

        /* No need to create a new entry */
        p_small = NULL;
    }

    /* If there is a hole proceeding this one, merge them */
    if (p_before) {
        offset = p_before->offset;
        len += p_before->len;

        err = __bai_hole_modify(p_group, p_before, offset, len);
        if (err) {
            goto out;
        }

        /* If we already merged into 'after', free after */
        if (p_after) {
            err = __bai_hole_modify(p_group, p_after, 0, 0);
            if (err) {
                goto out;
            }
        }

        p_small = NULL;
    }

    /* If the hole was absorbed by existing cache entries, done */
    if (!p_small) {
        goto out;
    }

    /* If this hole is smaller than any cached hole, done */
    if (len < p_small->len) {
        goto out;
    }

    err = __bai_hole_modify(p_group, p_small, offset, len);
    if (err) {
        goto out;
    }


out:
    if ((err) && (p_group)) {
        p_group->hole_cache_valid = FALSE;
    }

    return err;
}


/**
 * Reinitialize the cache of holes
 *
 * @param[in] p_group - Group to clear the hole data on
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 */
static sx_utils_status_t __bai_holes_reinit(bai_group_t *p_group)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i, j, size, total_free;
    uint8_t           entry;

    memset(p_group->holes, 0, sizeof(p_group->holes));

    /* Scan the allocation array picking out the biggest holes */
    total_free = 0;
    for (i = 0; i < p_group->alloc_size; i++) {
        entry = p_group->array_map[i];

        /* Looking at a hole - Calculate size of said hole */
        if (entry == 0) {
            size = 0;
            for (j = i; j < p_group->alloc_size; j++) {
                /* Count unallocated lines */
                if (p_group->array_map[j] == 0) {
                    size++;
                    continue;
                }

                break;
            }

            /* Update the cache of holes */
            err = __bai_hole_add(p_group, i, size);
            if (err) {
                goto out;
            }

            total_free += size;

            /* Point past the hole so we can continue looking */
            i = j - 1;
            continue;
        }

        /* This BETTER be the first block of an allocation */
        err = bai_block_size(p_group, i, &size);
        if (err) {
            goto out;
        }

        /* Point to the final line of the chunk */
        i += size - 1;
    }

    /* Update group free lines count - Log mismatch but not an error */
    if (total_free != p_group->free_lines) {
        SX_LOG_NTC("Group free_lines(%u) mismatch(%u) - Fixing\n",
                   p_group->free_lines, total_free);

        p_group->free_lines = total_free;
    }

    p_group->hole_cache_valid = TRUE;


out:
    return err;
}


/**
 * Handle aligned allocation from an existing hole
 *
 * @param[in] p_group - Group that contains the hole
 * @param[in] p_hole - Description of a hole
 * @param[in] size - Number of lines to allocate in that hole
 * @param[out] offset_p - Where to return offset of allocation (or NULL)
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_NO_RESOURCES - Request does not fit in any hole
 */
static sx_utils_status_t __bai_hole_fit(bai_group_t *p_group, bai_hole_t  *p_hole, uint32_t size,
                                        uint32_t    *offset_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          skip;
    uint32_t          pre_offset, pre_len, post_offset, post_len;
    uint32_t          unmark = 0;

    /* Recover from any previous problems in the cache */
    if (!p_group->hole_cache_valid) {
        err = __bai_holes_reinit(p_group);
        if (err) {
            goto out;
        }
    }

    /* Calculate the offset from beginning of hole needed for alignment */
    switch (p_group->align) {
    case ALIGN_NONE_E:
        skip = 0;
        break;

    case ALIGN_SIZE_E:
        skip = p_hole->offset % size;
        if (skip) {
            skip = size - skip;
        }
        break;

    case ALIGN_EVEN_E:
        skip = (p_hole->offset & 1) ? 1 : 0;
        break;

    default:
        SX_LOG_ERR("Internal error - Invalid align %u\n", p_group->align);
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* If hole is too small to handle size at alignment, we are done */
    if ((size + skip) > p_hole->len) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    /* If they just want an answer and don't want allocation, then done */
    if (!offset_p) {
        goto out;
    }

    /* This is where allocation starts */
    *offset_p = p_hole->offset + skip;

    /* Handle simple case of aligned allocation */
    if (skip == 0) {
        err = __bai_hole_modify(p_group, p_hole, p_hole->offset + size,
                                p_hole->len - size);
        if (err) {
            goto out;
        }

        goto out;
    }

    /* Parameters for new p_hole ahead of our allocated space */
    pre_offset = p_hole->offset;
    pre_len = skip;

    /* Parameters for space left after our allocation */
    post_offset = p_hole->offset + skip + size;
    post_len = p_hole->len - skip - size;

    /* Update the existing hole with the biggest remaining hole */
    if (pre_len > post_len) {
        err = __bai_hole_modify(p_group, p_hole, pre_offset, pre_len);
        if (err) {
            goto out;
        }

        pre_len = post_len;
        pre_offset = (post_len == 0) ? 0 : post_offset;
    } else {
        err = __bai_hole_modify(p_group, p_hole, post_offset, post_len);
        if (err) {
            goto out;
        }
    }

    /*
     *   Add tries to add free space after a hole - Mark first line
     * of new allocation so we don't eat it.  There is nothing ahead of
     * line 0, so we use that to say 'no need to unmark'.
     */
    unmark = *offset_p;
    if (unmark) {
        p_group->array_map[unmark] = LS_FIRST_E | LS_MIDDLE_E;
    }

    /* Try to create a new hole with the smaller space that is left */
    err = __bai_hole_add(p_group, pre_offset, pre_len);
    if (err) {
        goto out;
    }


out:
    if (unmark) {
        p_group->array_map[unmark] = 0;
    }

    return err;
}


/**
 * Reserve a chunk by updating allocation map
 *
 * @param[in] p_group - Pointer to group containing allocation
 * @param[in] offset - Offset of first line of allocation
 * @param[out] size - Pointer to where to start size (optional)
 *
 * @return SX_UTILS_STATUS_SUCCESS - Allocation successful
 * @return SX_UTILS_STATUS_PARAM_ERROR - Invalid request
 */
static sx_utils_status_t __bai_block_reserve(bai_group_t *p_group, uint32_t offset, uint32_t size)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i, *p_len;
    uint8_t           mark_start, mark_stop;
    boolean_t         skip_middle;


    /* Make sure we don't run past the end of allocation map */
    if ((offset + size) > p_group->alloc_size) {
        SX_LOG_ERR("offset(%u) + size(%u) exceeds array size(%u)!\n", offset,
                   size, p_group->alloc_size);

        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Update the hole cache before we update the array */
    err = __bai_hole_del(p_group, offset, size);
    if (err) {
        goto out;
    }

    /* There is no 'middle' for small allocations */
    skip_middle = (size < 3);

    /* Special case exits early */
    if (size == 1) {
        p_group->array_map[offset] = LS_FIRST_E | LS_LAST_E;
    } else {
        /* This allocation uses separate start/end markers */
        mark_start = LS_FIRST_E;
        mark_stop = LS_LAST_E;

        /* See if there is space to cache this entry */
        if (size > MIN_RUNS) {
            mark_start |= LS_RLE_E;

            /* Might be unaligned - HW must support */
            p_len = (uint32_t*)&p_group->array_map[offset + 1];

            *p_len = size;

            skip_middle = TRUE;
        }

        p_group->array_map[offset] = mark_start;
        p_group->array_map[offset + size - 1] = mark_stop;

        if (skip_middle) {
            goto out;
        }

        for (i = offset + 1; i < offset + size - 1; i++) {
            p_group->array_map[i] = LS_MIDDLE_E;
        }
    }


out:
    return err;
}


/**
 * Validate allocation and return size
 *
 * @param[in] p_group - Pointer to group containing allocation
 * @param[in] offset - Offset of first line of allocation
 * @param[out] size_p - Pointer to where to start size (optional)
 *
 * @return SX_UTILS_STATUS_SUCCESS - Successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t bai_block_size(bai_group_t *p_group, uint32_t offset, uint32_t     *size_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i, size;
    uint8_t           entry;

    /* Make sure this is the first line of a chunk */
    entry = p_group->array_map[offset];

    if ((entry & LS_FIRST_E) == 0) {
        SX_LOG_ERR("Offset %u is not first line of a block!\n", offset);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Handle RLE encoding length */
    if (entry & LS_RLE_E) {
        /* Make sure a chunk encoded RLE fits in the array */
        if ((offset + MIN_RUNS) > p_group->alloc_size) {
            SX_LOG_ERR("Internal error - RLE beyond end of array!\n");

            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        /* Extract the size directly */
        size = *(uint32_t*)&p_group->array_map[offset + 1];

        /* Make sure we don't address past the end of the array */
        if ((offset + size) > p_group->alloc_size) {
            SX_LOG_ERR("Internal error - Size exceeds array size!\n");

            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        /* Point to final byte of allocation */
        entry = p_group->array_map[offset + size - 1];
    } else if (entry & LS_LAST_E) {
        /* One line allocations are a little special */
        size = 1;
    } else {
        size = 1;
        for (i = offset + 1; i < p_group->alloc_size; i++) {
            entry = p_group->array_map[i];
            size++;

            if (entry & LS_LAST_E) {
                break;
            }

            /* The first byte is not a middle */
            if (entry & LS_FIRST_E) {
                SX_LOG_ERR("Internal error - Second start found!\n");
                continue;
            }

            /* Make sure nothing is broken */
            if ((entry & LS_MIDDLE_E) == 0) {
                SX_LOG_ERR("Internal error - Non-RLE missing middle mark\n!\n");

                err = SX_UTILS_STATUS_ERROR;
                goto out;
            }
        }
    }

    if ((entry & LS_LAST_E) == 0) {
        SX_LOG_ERR("Internal error - Last line of block not marked!\n");

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* If they care about the answer, return it here */
    if (size_p) {
        *size_p = size;
    }


out:
    return err;
}


/**
 * Verify that the combination of a hole + an allocation can be used
 * to hold the requested 'size'.  This means:
 *   - Hole + moved chunk is big enough
 *   - Alignment fits
 *   - There is space to move the chunk
 *
 * @param[in] p_group - Group to allocate from
 * @param[in] size_needed - Size of required block in lines.
 * @param[in] hole_offset - Offset of the hole
 * @param[in] hole_len - Length of the hole
 * @param[in] chunk_offset - Offset of the chunk to move to make space
 * @param[out] next_p - When a block is found, location to continue search
 * @param[out] cost_p - Cost of moving chunk_offset
 * @param[out] dest_p - Offset to move chunk_offset to
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_NO_RESOURCES - Request does not fit in group
 */
static sx_utils_status_t __bai_relocate_cost(bai_group_t *p_group,
                                             uint32_t     size_needed,
                                             uint32_t     hole_offset,
                                             uint32_t     hole_len,
                                             uint32_t     chunk_offset,
                                             uint32_t     chunk_len,
                                             uint32_t    *next_p,
                                             uint32_t    *cost_p,
                                             uint32_t    *dest_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i;
    bai_hole_t        test;
    boolean_t         found = FALSE;
    uint32_t          fit_start, fit_end, test_start, test_end;

    /* If the chunk is locked, we can't move it */
    if (p_group->array_map[chunk_offset] & LS_LOCKED_E) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    test.offset = (hole_offset < chunk_offset) ? hole_offset : chunk_offset;
    test.len = hole_len + chunk_len;

    /* Increase the length by the size of any trailing hole */
    for (i = test.offset + test.len; i < p_group->alloc_size; i++) {
        if (p_group->array_map[i] == 0) {
            test.len++;
            continue;
        }

        break;
    }

    /* If it is just too small, there is nothing we can do */
    if (test.len < size_needed) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    /* If it can't hold the new block with correct alignment, too bad */
    err = __bai_hole_fit(p_group, &test, size_needed, NULL);
    if (err) {
        goto out;
    }

    /* Scan cache looking for at least enough space for the chunk to move */
    fit_start = test.offset;
    fit_end = fit_start + size_needed - 1;

    for (i = 0; i < MAX_HOLES; i++) {
        if (p_group->holes[i].len < chunk_len) {
            continue;
        }

        /* Make sure hole does not overlap the big block */
        test_start = p_group->holes[i].offset;
        test_end = test_start + p_group->holes[i].len - 1;

        if ((fit_start >= test_start) && (fit_start <= test_end)) {
            continue;
        }

        if ((fit_end >= test_start) && (fit_end <= test_end)) {
            continue;
        }

        /* There is at least one location that we can move the block to */
        found = TRUE;
        break;
    }

    /* If there is no space to move the chunk, no point in looking more */
    if (!found) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    /* Cost is reference count + number of lines */
    *cost_p = p_group->lids[chunk_offset].ref + chunk_len;
    *next_p = test.offset + test.len;
    *dest_p = test_start;


out:
    return err;
}


/**
 * Given a 'size', find the cheapest single block in the passed group to
 * relocate that either opens a hole big enough, or opens a bigger hole
 * than currently exists.
 *
 * @param[in] p_group - Group to allocate from
 * @param[in] size_needed - Size of required block in lines.
 * @param[out] offset_in_p - Pointer to block to move
 * @param[out] offset_out_p - Pointer to where to move it to
 * @param[out] len_p - Pointer to where to return length of block to move
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_NO_RESOURCES - Request does not fit in group
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal error of some sort
 */
static sx_utils_status_t __bai_sync_select_block(bai_group_t *p_group,
                                                 uint32_t     size_needed,
                                                 uint32_t    *offset_in_p,
                                                 uint32_t    *offset_out_p,
                                                 uint32_t    *len_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i, j, size, dest;
    uint32_t          adj_offset = ENTRY_EMPTY, adj_size = 0;
    uint32_t          hole_offset = ENTRY_EMPTY, hole_size = 0;
    uint32_t          best_offset = ENTRY_EMPTY, best_cost = 0xffffffff;
    uint32_t          cost;
    uint32_t          best_len = 0, best_dest = ENTRY_EMPTY;
    boolean_t         last_hole = FALSE;
    uint8_t           entry;

    for (i = 0; i < p_group->alloc_size; i++) {
        entry = p_group->array_map[i];

        /* See if we are at the start of a hole */
        if (entry == 0) {
            size = 0;

            for (j = i; j < p_group->alloc_size; j++) {
                if (p_group->array_map[j] == 0) {
                    size++;
                    continue;
                }

                break;
            }

            hole_offset = i;
            hole_size = size;

            /*
             *   We should have found this hole in the cache already.  But
             * since it was not there, add it now and tell caller there is
             * no relocation needed
             */
            if (hole_size >= size_needed) {
                err = __bai_hole_add(p_group, hole_offset, hole_size);
                if (err) {
                    goto out;
                }

                /* No block needs to be relocated */
                *offset_in_p = ENTRY_EMPTY;
                *len_p = 0;
                *offset_out_p = i;

                goto out;
            }

            /* The last thing we reviewed was a hole */
            last_hole = TRUE;

            /* If there was no previous block, nothing more to do */
            if (adj_offset == ENTRY_EMPTY) {
                continue;
            }

            /* Can we move this line to make the space we need? */
            err = __bai_relocate_cost(p_group, size_needed, hole_offset,
                                      hole_size, adj_offset, adj_size, &j,
                                      &cost, &dest);

            /* Point to 'the next thing' after this hole */
            i = hole_offset + hole_size - 1;

            /* If allocation will not succeed in the hole, try the next one */
            if (err == SX_UTILS_STATUS_NO_RESOURCES) {
                err = SX_UTILS_STATUS_SUCCESS;
                continue;
            } else if (err) {
                /* Internal errors trigger failure case */
                goto out;
            }

            /* If this is the cheapest move, remember it */
            if (cost < best_cost) {
                best_cost = cost;
                best_offset = adj_offset;
                best_len = adj_size;
                best_dest = dest;
            }

            continue;
        }

        /* We must be at the start of an allocated block */
        if ((entry & LS_FIRST_E) == 0) {
            SX_LOG_ERR("Allocation map Index %u invalid!\n", i);

            err = SX_UTILS_STATUS_SDK_ERROR;
            goto out;
        }
        adj_offset = i;

        /* If this is Run Length Encoded, move directly to the end */
        adj_size = ENTRY_EMPTY;
        if (entry & LS_RLE_E) {
            adj_size = *(uint32_t*)&p_group->array_map[i + 1];
        } else {
            /* Scan for the end of this block */
            for (j = 0; j < p_group->alloc_size; j++) {
                if (p_group->array_map[i + j] & LS_LAST_E) {
                    adj_size = j + 1;
                    break;
                }
            }
        }

        /* Catch case were we run off the end of the array */
        if (adj_size == ENTRY_EMPTY) {
            SX_LOG_ERR("Last entry in map not marked final!\n");

            err = SX_UTILS_STATUS_SDK_ERROR;
            goto out;
        }

        /* Point to the first byte of this block */
        i += adj_size - 1;

        /* Make sure we stay in bounds */
        if (i >= p_group->alloc_size) {
            SX_LOG_ERR("Internal error - Size exceeds array bounds!\n");

            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        /* Make sure we are where we expect */
        if ((p_group->array_map[i] & LS_LAST_E) == 0) {
            SX_LOG_ERR("Allocation map Index %u final invalid!\n", i);

            err = SX_UTILS_STATUS_SDK_ERROR;
            goto out;
        }

        /* If the last thing we checked was not a hole, keep looking */
        if (!last_hole) {
            continue;
        }

        /* The last thing we checked was this non-hole block */
        last_hole = FALSE;

        /* Can we move this line to make the space we need? */
        err = __bai_relocate_cost(p_group, size_needed, hole_offset,
                                  hole_size, adj_offset, adj_size, &j, &cost,
                                  &dest);

        /* Setup to point to first element of next chunk/free */
        i = adj_offset + adj_size - 1;

        /* If allocation will not succeed in the hole, try the next one */
        if (err == SX_UTILS_STATUS_NO_RESOURCES) {
            err = SX_UTILS_STATUS_SUCCESS;
            continue;
        } else if (err) {
            goto out;
        }

        /* If this is the cheapest move, remember it */
        if (cost < best_cost) {
            best_cost = cost;
            best_offset = adj_offset;
            best_len = adj_size;
            best_dest = dest;
        }
    }

    /* If we didn't find a block that works, no need to do anything more */
    if (best_offset == ENTRY_EMPTY) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    /* Return the offset/length of the block to relocate */
    *offset_in_p = best_offset;
    *offset_out_p = best_dest;
    *len_p = best_len;


out:
    return err;
}


/**
 * Update the cache of holes to reflect new allocation
 *   When a block is allocated, this function updates the cache of holes to
 * reflect the new allocation.
 *
 * @param[in] p_group - Pointer to group containing allocation
 * @param[in] offset - Offset of first line of allocation
 * @param[in] size - Length of the block allocated at offset
 *
 * @return SX_UTILS_STATUS_SUCCESS - Deallocation successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
static sx_utils_status_t __bai_hole_del(bai_group_t *p_group, uint32_t offset, uint32_t size)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i, start, end;
    uint32_t          before_offset, before_len, after_offset, after_len;
    bai_hole_t       *hole, *hole_small;
    boolean_t         found = FALSE;

    /* Recover from any previous problems in the cache */
    if (!p_group->hole_cache_valid) {
        err = __bai_holes_reinit(p_group);
        if (err) {
            goto out;
        }
    }

    /* Start and end of chunk we are trying to fit into an existing hole */
    start = offset;
    end = offset + size - 1;

    /* Initialize the smallest hole */
    hole_small = &p_group->holes[0];

    for (i = 0; i < MAX_HOLES; i++) {
        err = __bai_hole_get(p_group, i, &hole);
        if (err) {
            goto out;
        }

        /* Track the smallest hole we find */
        if (hole->len < hole_small->len) {
            hole_small = hole;
        }

        /* Skip unused hole cache entries */
        if (hole->len == 0) {
            continue;
        }

        /* If the new block ends before this hole starts, nothing to do */
        if (end < hole->offset) {
            continue;
        }

        /* If the hole ends before the block starts, nothing to do */
        if ((hole->offset + hole->len - 1) < start) {
            continue;
        }

        /* The request should be contained in the hole - Invalidate if not */
        if (size > hole->len) {
            SX_LOG_WRN("Allocation [%u..%u] longer than hole [%u..%u]!\n",
                       offset, offset + size - 1, hole->offset,
                       hole->offset + hole->len - 1);

            /* Clear the cache entry that is impacted */
            err = __bai_hole_modify(p_group, hole, 0, 0);
            if (err) {
                goto out;
            }

            /* Keep looking for other holes that might be impacted */
            continue;
        }

        /* Easy case 1 - Allocation starts at beginning of hole */
        if (hole->offset == start) {
            err = __bai_hole_modify(p_group, hole, end + 1, hole->len - size);
            if (err) {
                goto out;
            }

            goto out;
        }

        /* Easy case 2 - Allocation overlaps the end of the hole */
        if ((hole->offset + hole->len - 1) == end) {
            err = __bai_hole_modify(p_group, hole, hole->offset,
                                    hole->len - size);
            if (err) {
                goto out;
            }

            goto out;
        }

        /* Make sure we are really splitting this hole  - sanity checks */
        if (offset <= hole->offset) {
            SX_LOG_ERR("Split alloc starts before hole!\n");

            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        if (offset >= (hole->offset + hole->len - 1)) {
            SX_LOG_ERR("Split alloc starts after hole!\n");

            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        if (end <= hole->offset) {
            SX_LOG_ERR("Split alloc ends before hole!\n");

            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        if (end >= (hole->offset + hole->len - 1)) {
            SX_LOG_ERR("Split alloc ends after hole!\n");

            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        /* This chunk breaks hole into 2 holes; one before, one after */
        before_offset = hole->offset;
        before_len = offset - hole->offset;

        after_offset = end + 1;
        after_len = hole->offset + hole->len - after_offset;

        /* Use the existing hole to hold the bigger free space */
        if (before_len < after_len) {
            err = __bai_hole_modify(p_group, hole, after_offset, after_len);
            if (err) {
                goto out;
            }

            /* We are going to allocate a new hole with 'after' data */
            after_offset = before_offset;
            after_len = before_len;
        } else {
            hole->len = before_len;
        }

        found = TRUE;
    }

    /* If we don't need to create a new hole, then done */
    if (!found) {
        goto out;
    }

    /* If our remaining hole piece bigger than smallest hole in cache */
    if (after_len > hole_small->len) {
        err = __bai_hole_modify(p_group, hole_small, after_offset, after_len);
        if (err) {
            goto out;
        }
    }


out:
    return err;
}


/**
 * Try to allocate a new block
 *
 * @param[in] p_group - Group to allocate from
 * @param[in] size - Size of required block in lines.
 * @param[out] offset_p - Pointer to where to return first line
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - p_group and/or offset_p is NULL
 * @return SX_UTILS_STATUS_NO_RESOURCES - Request does not fit in group
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Try searching line-by-line
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
static sx_utils_status_t __bai_hole_search(bai_group_t *p_group, uint32_t size, uint32_t    *offset_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_hole_t       *hole, *hole_smallest = NULL;
    uint32_t          i, sum;

    /* Recover from any previous problems in the cache */
    if (!p_group->hole_cache_valid) {
        err = __bai_holes_reinit(p_group);
        if (err) {
            goto out;
        }
    }

    for (sum = i = 0; i < MAX_HOLES; i++) {
        hole = &p_group->holes[i];

        /* Ignore empty entries */
        if (hole->len == 0) {
            continue;
        }

        /* Track free space covered by known holes */
        sum += hole->len;

        /* Ignore holes that are too small */
        if (hole->len < size) {
            continue;
        }

        /* If we already have selected a smaller hole, use it */
        if (hole_smallest && (hole->len > hole_smallest->len)) {
            continue;
        }

        /* Would this hole fit the requested size/alignment? */
        err = __bai_hole_fit(p_group, hole, size, NULL);

        /* If allocation will not succeed in the hole, try the next one */
        if (err == SX_UTILS_STATUS_NO_RESOURCES) {
            err = SX_UTILS_STATUS_SUCCESS;
            continue;
        }

        /* Any other error is a failure */
        if (err) {
            goto out;
        }

        /* This hole is smaller than any other we have seen */
        hole_smallest = hole;
    }

    /* If we found a hole that works, allocate from it and done */
    if (hole_smallest) {
        err = __bai_hole_fit(p_group, hole_smallest, size, offset_p);
        goto out;
    }

    if (sum > p_group->free_lines) {
        SX_LOG_ERR("Internal error - holes free size %u exceeds group %u!\n",
                   sum, p_group->free_lines);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* No space found, relocation disabled or didn't work; tell caller */
    err = (sum == p_group->free_lines) ? SX_UTILS_STATUS_NO_RESOURCES
          : SX_UTILS_STATUS_PARTIALLY_COMPLETE;


out:
    return err;
}

sx_utils_status_t bai_free_group(bai_user_t *p_user, bai_group_t *p_group)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    ba_handle_t       handle = (ba_handle_t)p_user;
    ba_group_t        group;
    uint32_t          i = 0;

    if (!p_group) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_group is NULL\n");
        goto out;
    }

    if (!p_user) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_group is NULL\n");
        goto out;
    }

    if (p_group->free_lines != p_group->alloc_size) {
        SX_LOG_ERR("Internal error - Group is not empty!\n");

        err = SX_UTILS_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    for (i = 0; i < p_group->alloc_size; i++) {
        cl_spinlock_destroy(&p_group->lids[i].lock);
    }

    if (p_group->p_template->cb_free == NULL) {
        SX_LOG_ERR("Internal error - No cb_free callback!\n");

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    group.type = p_group->type;
    group.grp_index = p_group - p_user->groups;

    err = p_group->p_template->cb_free(handle, &group);
    if (err) {
        SX_LOG_WRN("cb_free returns error %u\n", err);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    if (p_group->array_map) {
        M_GEN_UTILS_MEM_PUT(p_group->array_map,          \
                            GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                            "array_map", err);
    }
    p_group->array_map = NULL;
    if (p_group->lids) {
        M_GEN_UTILS_MEM_PUT(p_group->lids,               \
                            GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                            "lids", err);
    }
    p_group->lids = NULL;
    p_group->type = GROUP_TYPE_FREE;

out:
    return err;
}

sx_utils_status_t bai_block_free(bai_group_t *p_group, uint32_t offset)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i, size, clr_size;

    if (!p_group) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_group is NULL\n");
        goto out;
    }

    /* Make sure chunk is allocated and get size */
    err = bai_block_size(p_group, offset, &size);
    if (err) {
        goto out;
    }

    /* Already checked it so it is safe to cleanup */
    if (p_group->array_map[offset] & LS_RLE_E) {
        /* Clear everything except the last byte which is at the end */
        clr_size = MIN_RUNS - 1;

        /* Clear the 'final' block */
        p_group->array_map[offset + size - 1] = 0;
    } else {
        clr_size = size;
    }

    /* Clear the allocation info */
    for (i = 0; i < clr_size; i++) {
        p_group->array_map[offset + i] = 0;
    }

    /* Update the cache of holes */
    err = __bai_hole_add(p_group, offset, size);
    if (err) {
        goto out;
    }

    /* Clear the stats associated with this block */
    p_group->lids[offset].ref = 0;
    p_group->lids[offset].client_context = 0;
    SX_LOG_DBG("LID 0x%X is free lock destroyed ref count = 0!\n", offset);


out:
    return err;
}

/**
 * Invoke relocation callback.
 *   Find the LID associated with the group+offset, call relocation handler
 * if one exists, and return free the iLID after successful return from
 * client relocation handler.
 *
 * NOTE: When we go multi-threaded, locks are required here.
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] p_group_in - Group that contains original block
 * @param[in] offset_in - Offset (in p_group_in) of block to move
 * @param[in] p_group_out - Group that will contain the block
 * @param[in] offset_out - Offset (in p_group_out) of block to move
 * @param[in] size - Length of the block being moved
 * @param[in] reloc_flow - relocation flow type initiating this relocation
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Relocation failed badly
 * @return SX_UTILS_STATUS_ERROR - Relocation failed but no wasted space
 */
static sx_utils_status_t __bai_relocate_block(bai_user_t     *p_user,
                                              bai_group_t    *p_group_in,
                                              uint32_t        offset_in,
                                              bai_group_t    *p_group_out,
                                              uint32_t        offset_out,
                                              uint32_t        size,
                                              ba_reloc_flow_t reloc_flow)
{
    sx_utils_status_t      err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t        lid;
    bai_logical_id_t       iLID, oLID;
    ba_handle_t            handle = (ba_handle_t)p_user;
    uint32_t               cntx;
    ba_index_t             old_idx, new_idx;
    boolean_t              do_free_out = FALSE, do_ref_unlock_in = FALSE;
    boolean_t              do_unlock_in = FALSE, do_unlock_out = FALSE;
    ba_gc_context_t       *p_gc_context = NULL;
    ba_relocate_context_t *p_relocate_context = NULL;
    const cl_map_item_t   *p_end = NULL;
    cl_map_item_t         *p_item = NULL;
    bai_lid_info_t        *p_lid_info = NULL;
    bai_lid_info_t        *p_lid_tmp = NULL;

    /* Make sure user is active - We are so deep we don't check NULLs */
    if (!p_user->allocated) {
        SX_LOG_ERR("Internal error - User not allocated!\n");

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Internal error if block to move is locked */
    if (p_group_in->array_map[offset_in] & LS_LOCKED_E) {
        SX_LOG_ERR("G%u.%u is locked!\n",
                   (uint32_t)(p_group_in - p_user->groups),
                   offset_in);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Lock the input group and remember it needs unlocking */
    p_group_in->array_map[offset_in] |= LS_LOCKED_E;
    cl_spinlock_acquire(&p_group_in->lids[offset_in].lock);
    do_ref_unlock_in = TRUE;
    do_unlock_in = TRUE;

    /* Create the internal LID we are moving from */
    err = __bai_ilid(p_user, p_group_in, offset_in, &iLID);
    if (err) {
        goto out;
    }

    /* Ditto the new internal LID */
    err = __bai_ilid(p_user, p_group_out, offset_out, &oLID);
    if (err) {
        goto out;
    }

    /*
     * Search for external LID that maps to iLID
     *   Since we don't do this often, we will add some DB validity checking
     * by scanning the whole LIDs array to verify:
     *   - No LID points to our selected relocation target
     *   - Multiple LIDs don't point to the same relocation source
     */
    lid = INVALID_LID;
    p_end = cl_qmap_end(&p_user->lids_map);
    p_item = cl_qmap_head(&p_user->lids_map);

    while (p_item != p_end) {
        p_lid_tmp = PARENT_STRUCT(p_item, bai_lid_info_t, map_item);
        if (p_lid_tmp->ilid == oLID) {
            SX_LOG_ERR("LID %u pointing to relocate target 0x%X!\n",
                       p_lid_tmp->lid, oLID);

            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        if (p_lid_tmp->ilid == iLID) {
            if (lid != INVALID_LID) {
                SX_LOG_ERR("LID %u found multiple times iLID=0x%X!\n",
                           p_lid_tmp->lid, iLID);

                err = SX_UTILS_STATUS_ERROR;
                goto out;
            }

            lid = p_lid_tmp->lid;
            p_lid_info = p_lid_tmp;
        }

        p_item = cl_qmap_next(p_item);
    }

    /* This can't really happen, but translate to not found if it does */
    if (lid == INVALID_LID) {
        SX_LOG_WRN("Internal error - LID not found for iLID 0x%8.8X\n", iLID);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Allocate the space we are moving into */
    err = __bai_block_reserve(p_group_out, offset_out, size);
    if (err) {
        goto out;
    }
    do_free_out = TRUE;

    p_group_out->array_map[offset_out] |= LS_LOCKED_E;
    do_unlock_out = TRUE;

    /* Copy the per-LID context (ref + client_context) to new chunk */
    p_group_out->lids[offset_out].ref = p_group_in->lids[offset_in].ref;
    p_group_out->lids[offset_out].client_context = p_group_in->lids[offset_in].client_context;
    SX_LOG_DBG("idx new 0x%8.8X ref %u idx old 0x%.8X ref %u\n", offset_out, p_group_out->lids[offset_out].ref,
               offset_in, p_group_in->lids[offset_in].ref);

    /* Calculate offsets and context values for callback */
    cntx = p_group_in->lids[offset_in].client_context;

    old_idx = ((p_group_in - p_user->groups) * p_user->group_size) +
              offset_in;
    new_idx = ((p_group_out - p_user->groups) * p_user->group_size) +
              offset_out;

    if ((p_user->options & RELOC_ASYNC_GC_E) != 0) {
        err = bai_relocate_context_get(p_user, &p_relocate_context);
        if (err) {
            goto out;
        }
        p_relocate_context->ilid = iLID;
        p_relocate_context->size = size;
        p_relocate_context->lid = lid;
    }

    /* Call the user provided callback handler */
    err = p_group_in->p_template->cb_relocate(handle, lid, cntx, old_idx,
                                              new_idx, p_relocate_context);

    /* Need to keep both mappings because they are both used now */
    if (err == SX_UTILS_STATUS_PARTIALLY_COMPLETE) {
        SX_LOG_ERR("Relocation failed - Keeping both mappings\n");

        do_free_out = FALSE;
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Need to keep old mapping because we could not relocate */
    if (err == SX_UTILS_STATUS_ERROR) {
        SX_LOG_ERR("Relocation failed - Keeping original mapping\n");

        do_free_out = TRUE;
        goto out;
    }

    /* Other errors mean that it didn't work; remove old mapping */
    if (err) {
        do_free_out = TRUE;
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* We have switched to the new block - Don't free it */
    do_free_out = FALSE;

    /* For synchronous relocations, do a synchronous fence, since the purpose of
     * the synchronous relocation is most likely to make room for an allocation.
     */
    if (reloc_flow == BA_RELOC_FLOW_SYNC) {
        err = gc_object_fence(p_user->gc_fence_type);
        if (err) {
            SX_LOG_ERR("Failed to perform fence type %s for object type %s, err = [%s]\n",
                       GC_FENCE_TYPE_STR(p_user->gc_fence_type),
                       GC_OBJECT_TYPE_STR(p_user->gc_object_type),
                       SX_UTILS_STATUS_MSG(err));
            goto out;
        }

        /* Unlock the source block before we free it */
        p_group_in->array_map[offset_in] &= ~LS_LOCKED_E;
        do_unlock_in = FALSE;

        if (p_user->free_object_cb) {
            err = p_user->free_object_cb(handle, reloc_flow, lid, cntx, old_idx);
            if (err) {
                SX_LOG_ERR("At sync relocation, a free object callback failed for the BA object with LID %u!\n",
                           lid);
                goto out;
            }
        }

        /*
         * Free the original block
         *   If there is an error doing this, log it and mark space as unusable
         * for future allocation.  There will be a problem doing shutdown, but
         * that is better than causing problems now.
         */
        cl_spinlock_release(&p_group_in->lids[offset_in].lock);
        do_ref_unlock_in = FALSE;
        err = bai_block_free(p_group_in, offset_in);
        if (err) {
            SX_LOG_WRN(
                "Internal error - G%u.%u len=%u error %d during free; continues\n",
                (uint32_t)(p_group_in - p_user->groups), offset_in, size, err);

            /* Mark the Original block as allocated and locked so we don't use */
            p_group_in->array_map[offset_in] |= LS_LOCKED_E;
            p_group_in->lids[offset_in].ref = MAX_REF_CNT;

            /* Disable relocation because internal data structures bad */
            SX_LOG_WRN("Relocation halted due to being unable to free!\n");
            p_user->options &= ~(RELOC_SYNC_E | RELOC_ASYNC_E | RELOC_ASYNC_GC_E);

            /* Don't confuse caller with an error though */
            err = SX_UTILS_STATUS_SUCCESS;
        }
    }
    /* Asynchronous relocations are handled the normal way concerning garbage
     * collection - the source block is pushed to the GC queue and freed later
     * in the background.
     */
    else {
        /* If user have requested async GC push should be push called at user completion cb.
         * Otherwise push to GC immediately */
        if ((p_user->options & RELOC_ASYNC_GC_E) == 0) {
            err = bai_gc_context_get(p_user, &p_gc_context);
            if (err) {
                goto out;
            }

            err = __bai_gc_object_push(p_user, p_gc_context, iLID, size, lid, reloc_flow);
            if (err) {
                SX_LOG_ERR("Failed to push object type %s iLID %u to GC, err = [%s]\n",
                           GC_OBJECT_TYPE_STR(p_user->gc_object_type),
                           p_gc_context->data.i_lid, SX_UTILS_STATUS_MSG(err));
                goto out;
            }
        }

        /* Don't unlock the source block yet - keep it locked until it's freed. */
        do_unlock_in = FALSE;
    }

    /*Ref could have changed in the relocation CB*/
    SX_LOG_DBG("idx new 0x%8.8X ref %u idx old 0x%.8X ref %u\n", offset_out, p_group_out->lids[offset_out].ref,
               offset_in, p_group_in->lids[offset_in].ref);
    if (p_group_out->lids[offset_out].ref < p_group_in->lids[offset_in].ref) {
        p_group_out->lids[offset_out].ref = p_group_in->lids[offset_in].ref;
    }
    /* Reallocate the old LID to point to the new block */
    SX_LOG_DBG("Relocation old lid 0x%X new Lid ox%X\n", p_lid_info->ilid, oLID);
    p_lid_info->ilid = oLID;
    /* We don't move often so log it for debug */
    SX_LOG_DBG("G%u.%u moves to G%u.%u len=%u\n",
               (uint32_t)(p_group_in - p_user->groups), offset_in,
               (uint32_t)(p_group_out - p_user->groups), offset_out,
               size);


out:
    if (do_unlock_in) {
        p_group_in->array_map[offset_in] &= ~LS_LOCKED_E;
    }
    if (do_ref_unlock_in) {
        cl_spinlock_release(&p_group_in->lids[offset_in].lock);
    }
    if (do_unlock_out) {
        p_group_out->array_map[offset_out] &= ~LS_LOCKED_E;
    }

    if (do_free_out) {
        bai_block_free(p_group_out, offset_out);
    }

    /* Shutdown relocation to avoid additional pressure on broken state */
    if (err) {
        SX_LOG_WRN("Relocation halted due to errors!\n");
        p_user->options &= ~(RELOC_SYNC_E | RELOC_ASYNC_E | RELOC_ASYNC_GC_E);

        if (p_gc_context) {
            bai_gc_context_put(p_gc_context);
        }

        if (p_relocate_context) {
            bai_relocate_context_put(p_relocate_context);
        }
    }

    return err;
}


/**
 * Invoke GC Object Push
 *
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] p_gc_context
 * @param[in] iLID -
 * @param[in] size - Length of the block being moved
 * @param[in] reloc_flow - relocation flow type initiating this relocation
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Relocation failed badly
 * @return SX_UTILS_STATUS_ERROR - Relocation failed but no wasted space
 */
sx_utils_status_t __bai_gc_object_push(bai_user_t      *p_user,
                                       ba_gc_context_t *p_gc_context,
                                       bai_logical_id_t iLID,
                                       uint32_t         size,
                                       ba_logical_id_t  lid,
                                       ba_reloc_flow_t  reloc_flow)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if (!p_gc_context) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("NULL GC context!\n");
        goto out;
    }

    p_gc_context->data.reloc_flow = reloc_flow;
    p_gc_context->data.handle = (ba_handle_t*)p_user;
    p_gc_context->data.i_lid = iLID;
    p_gc_context->data.lid = lid;

    err = gc_object_push(p_user->gc_object_type, p_gc_context,
                         GC_STATE_PENDING_FENCE, size, p_user->gc_subtype,
                         iLID, NULL);
    if (err) {
        SX_LOG_ERR("Failed to push object type %s iLID %u to GC, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(p_user->gc_object_type),
                   p_gc_context->data.i_lid, SX_UTILS_STATUS_MSG(err));
        goto out;
    }

out:

    return err;
}

/**
 * Attempt to do synchronous relocation in the group to free 'size' lines
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] p_group - Group to allocate from
 * @param[in] size - Size of required block in lines.
 * @param[out] offset_p - Pointer to where to return first line
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_NO_RESOURCES - Request does not fit in group
 */
static sx_utils_status_t __bai_sync_relocate(bai_user_t  *p_user,
                                             bai_group_t *p_group_in,
                                             uint32_t     size,
                                             uint32_t    *offset_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          offset_in, offset_out, len;

    /* Look for lowest cost block to move that will allow relocation */
    err = __bai_sync_select_block(p_group_in, size, &offset_in, &offset_out,
                                  &len);
    if (err) {
        /* No sync relocation will fix this */
        goto out;
    }

    /* If we found a big enough hole, no relocation needed */
    if (len != 0) {
        /* Attempt to relocate that block */
        err = __bai_relocate_block(p_user, p_group_in, offset_in, p_group_in,
                                   offset_out, len, BA_RELOC_FLOW_SYNC);
        if (err) {
            goto out;
        }
    }

    /* Search the cache (again) for a free block to hold this one */
    err = __bai_hole_search(p_group_in, size, offset_p);
    if (err) {
        goto out;
    }


out:
    return err;
}


/**
 * Attempt to allocate the size/alignment from existing holes
 *   Update the holes data to reflect the allocation.  If that fails, and
 * synchronous relocation is enabled, then try that.  This is an inner
 * loop function so parameter checking is skipped.
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] p_group - Group to allocate from
 * @param[in] size - Length of the hole in lines
 * @param[out] offset_p - Pointer to where to return first line
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - p_group and/or offset_p is NULL
 * @return SX_UTILS_STATUS_NO_RESOURCES - Request does not fit in group
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Try searching line-by-line
 */
static sx_utils_status_t __bai_hole_alloc(bai_user_t  *p_user,
                                          bai_group_t *p_group,
                                          uint32_t     size,
                                          uint32_t    *offset_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS, err2;

    /* If we can allocate out of an existing hole, do it */
    err = __bai_hole_search(p_group, size, offset_p);
    if (err == SX_UTILS_STATUS_SUCCESS) {
        goto out;
    }

    /* If we don't do synchronous relocation on this group */
    if ((p_group->options & RELOC_SYNC_E) == 0) {
        goto out;
    }

    /* Anything except 'no space' is passed directly on */
    if ((err != SX_UTILS_STATUS_NO_RESOURCES) &&
        (err != SX_UTILS_STATUS_PARTIALLY_COMPLETE)) {
        goto out;
    }

    /* If there is no callback handler, no point in trying */
    if (p_group->p_template->cb_relocate == NULL) {
        goto out;
    }

    /* Attempt synchronous relocation */
    err2 = __bai_sync_relocate(p_user, p_group, size, offset_p);

    /* If we succeeded, then this request succeeded */
    if (err2 == SX_UTILS_STATUS_SUCCESS) {
        err = SX_UTILS_STATUS_SUCCESS;
        goto out;
    }

    /* If we have no space, use the original failure code in err */
    if (err2 == SX_UTILS_STATUS_NO_RESOURCES) {
        goto out;
    }

    /* Reflect the internal error (or whatever) to caller */
    err = err2;


out:
    return err;
}


/**
 * Initialize group cache
 *   When a new group is received from the user it is fairly easy and fast
 * to initialize it without doing any searching.
 *
 * @param[in/out] p_group - The group to initialize
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal error of some sort
 */
static sx_utils_status_t __bai_cache_init(bai_group_t *p_group)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    /* Initialize the hole cache to reflect no allocation */
    memset(p_group->holes, 0, sizeof(p_group->holes));

    /* Create the first (and only) hole that spans all lines in group */
    err = __bai_hole_modify(p_group, &p_group->holes[0], 0,
                            p_group->alloc_size);
    if (err) {
        goto out;
    }

    p_group->hole_cache_valid = TRUE;

    /* An empty group has easy efficiency calculation */
    p_group->c_max_hole = p_group->alloc_size;
    p_group->c_max_size = p_group->max_alloc_size;
    p_group->c_efficiency = 100;
    p_group->alloc_cache_valid = TRUE;


out:
    return err;
}


/**
 * Update group cache
 *   The group cache is not needed for most logic so the cost of keeping
 * it up to date is not worthwhile.  Instead, things that cause a
 * full scan of group allocation logic to calculate new cache values
 * will usually just invalidate it.  Then functions that require up
 * to date cache values, can call this function to recalculate them.
 *
 * @param[in/out] p_group - The group to update; out is cache_* values
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - p_group is NULL
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal error
 */
sx_utils_status_t bai_cache_update(bai_group_t *p_group)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          max_free = 0, too_small = 0, big_free = 0;
    uint32_t          i, j, max_size = 0, size;
    uint8_t           entry;

    if (!p_group) {
        SX_LOG_ERR("p_group is NULL!\n");

        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    if (p_group->alloc_cache_valid) {
        goto out;
    }

    /* Initialize the sum of block relocation costs */
    p_group->c_cost_sum = 0;

    /* Calculate maximum size available for allocation */
    err = __bai_update_c_max_size(p_group);
    if (err) {
        goto out;
    }

    /* Reset cache of holes in this group - We will recalculate it */
    memset(p_group->holes, 0, sizeof(p_group->holes));

    /* Review the portion of the allocation array used by this group */
    for (i = 0; i < p_group->alloc_size; i++) {
        entry = p_group->array_map[i];

        /* Looking at a hole - Calculate size of said hole */
        if (entry == 0) {
            size = 0;
            for (j = i; j < p_group->alloc_size; j++) {
                /* Count unallocated lines */
                if (p_group->array_map[j] == 0) {
                    size++;
                    continue;
                }

                break;
            }

            /* Update the cache of holes */
            err = __bai_hole_add(p_group, i, size);
            if (err) {
                goto out;
            }

            /* If this is the biggest hole seen so far, remember it */
            if (size > max_size) {
                max_size = size;
            }

            max_free += size;

            /*
             * too_small
             *   The number of free 'chunks' (a set of contiguous free lines
             * bounded by the start of the array, the end of the array, or
             * active blocks) smaller than the max allocation size for the
             * group.
             */
            if (size < p_group->max_alloc_size) {
                too_small++;
            } else {
                /*
                 * big_free
                 *   Total free lines in chunks >= max allocation size for the
                 * group.
                 */
                big_free += size;
            }

            /* Point past the hole so we can continue looking */
            i = j - 1;
            continue;
        }

        /* This BETTER be the first block of an allocation */
        err = bai_block_size(p_group, i, &size);
        if (err) {
            goto out;
        }

        /* Update the sum of per-block relocation costs */
        p_group->c_cost_sum += size + p_group->lids[i].ref;

        /* Point to the final line of the chunk */
        i += size - 1;

        if ((entry & LS_FIRST_E) == 0) {
            SX_LOG_ERR("Allocation map Index %u invalid!\n", i);

            err = SX_UTILS_STATUS_SDK_ERROR;
            goto out;
        }
    }

    /* Make sure current free size matches bookkeeping */
    if (max_free != p_group->free_lines) {
        SX_LOG_ERR("Internal error - max_free=%u free_lines=%u!\n", max_free,
                   p_group->free_lines);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* The largest free hole we have */
    p_group->c_max_hole = max_size;

    /* Update the efficiency of this group */
    if ((max_free == 0) || (too_small == 0)) {
        /* This group can't be defragmented any more */
        p_group->c_efficiency = 101;
    } else {
        p_group->c_efficiency = (100 * big_free) / max_free;
    }

    p_group->alloc_cache_valid = TRUE;
    p_group->hole_cache_valid = TRUE;


out:
    return err;
}


/**
 * Convert 'type' value into offset for encoding
 *   BA clients may use any 32-bit value for their 'type'.  Internally,
 * that field is converged to a non-zero 8 bit value in order to encode
 * it in a LID.
 *   - NOTE: User init fails if template_count >= UINT8_MAX - 1
 *
 * @param[in] p_user - User context to locate type in
 * @param[in]  type - User provided 32 bit type value
 * @param[out] lid_type_p - Pointer to where to store LID type field value
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_SDK_ERROR - 'type' not found in template
 */
static sx_utils_status_t bai_type_to_lid_type(bai_user_t *p_user, uint32_t type, uint8_t    *lid_type_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    ba_template_t    *p_template = NULL;
    uint8_t           i;

    for (i = 0; i < p_user->template_count; i++) {
        p_template = &p_user->templates[i];

        if (p_template->type == type) {
            break;
        }

        p_template = NULL;
    }

    /* If we didn't find the user type nothing can be done */
    if (!p_template) {
        SX_LOG_WRN("User type %u not valid!\n", type);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    if (!lid_type_p) {
        /* Function can be used to validate type */
        goto out;
    }

    /* Make sure template index is never 0 */
    *lid_type_p = i + 1;


out:
    return err;
}


/**
 * Convert template index stored in lid to 32 bit user type
 *
 * @param[in] p_user - User context to locate type in
 * @param[in]  lid_type - 8 bit index into templates
 * @param[out] type_p - Pointer to where to store 32 bit user type value
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_SDK_ERROR - 'type' not found in template
 */
static sx_utils_status_t bai_lid_type_to_type(bai_user_t *p_user, uint8_t lid_type, uint32_t   *type_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if (lid_type == 0) {
        SX_LOG_ERR("Index is zero!\n");

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    if (lid_type > p_user->template_count) {
        SX_LOG_ERR("Index %u exceeds user provided values!\n", lid_type);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    if (!type_p) {
        /* Function can be used to validate lid_type */
        goto out;
    }

    *type_p = p_user->templates[lid_type - 1].type;


out:
    return err;
}


/**
 * Extract and validate the fields in an allocated internal LID
 *
 * @param[in] p_user - User context that holds i_lid
 * @param[in] i_lid - Internal lid value
 * @param[in] fn - Pointer to name of function for error log
 * @param[out] p_type - Pointer to where to store type
 * @param[out] p_group_idx - Pointer to where to store group index
 * @param[out] p_line_idx - Pointer to where to store line index
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - r_lid is NULL
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal LID is not valid
 */
sx_utils_status_t bai_extract_i_lid(bai_user_t      *p_user,
                                    bai_logical_id_t i_lid,
                                    const char      *fn,
                                    uint32_t        *p_type,
                                    uint32_t        *p_group_idx,
                                    uint32_t        *p_line_idx)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_group_t      *p_group;
    uint32_t          group_idx, line_idx, type_val;
    uint8_t           lid_type;

    /* Dump the not allocated internal LID first thing */
    if (i_lid == GROUP_TYPE_FREE) {
        SX_LOG_ERR("%s: Unallocated iLID 0!\n", fn);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* Make sure user structure is valid and consistent */
    err = bai_validate_user(p_user, fn);
    if (err) {
        goto out;
    }

    /* Extract the subfields */
    lid_type = (i_lid >> p_user->shift_type) & p_user->mask_type;
    group_idx = (i_lid >> p_user->shift_group) & p_user->mask_group;
    line_idx = i_lid & p_user->mask_line;

    /* Make sure they are not trying to allocate a type=free entry */
    if (lid_type == GROUP_TYPE_FREE) {
        SX_LOG_ERR("%s: iLID 0x%8.8X has type=free!\n", fn, i_lid);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* Convert type index into actual user provided type */
    err = bai_lid_type_to_type(p_user, lid_type, &type_val);
    if (err) {
        goto out;
    }

    /* Group index must be in range [0..group_cnt) */
    if (group_idx >= p_user->group_cnt) {
        SX_LOG_WRN("%s: iLID=0x%8.8X references group %u out of %u!\n", fn,
                   i_lid, group_idx, p_user->group_cnt - 1);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }
    p_group = &p_user->groups[group_idx];

    if (p_group->alloc_size == 0) {
        SX_LOG_ERR("%s: Internal error - Group alloc_size is 0!\n", fn);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /*
     * Line index must be in range [0..alloc_size)
     *   The total number of lines in each group is p_user->group_size, but
     * some templates limit the number of lines that may be allocated for
     * that type to p_group->alloc_size.  In all cases line_idx < alloc_size
     * <= group_size.
     */
    if (line_idx >= p_group->alloc_size) {
        SX_LOG_WRN("%s: iLID=0x%8.8X references line %u out of %u!\n", fn,
                   i_lid, line_idx, p_group->alloc_size - 1);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* Make sure the type matches the group */
    if (type_val != p_group->type) {
        SX_LOG_ERR("%s: iLID %8.8X type=%u does not match group %u type=%u!\n",
                   fn, i_lid, type_val, group_idx, p_group->type);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    if (p_type) {
        *p_type = type_val;
    }

    if (p_group_idx) {
        *p_group_idx = group_idx;
    }

    if (p_line_idx) {
        *p_line_idx = line_idx;
    }


out:
    return err;
}


/**
 * Validate a user structure can be used
 *
 * @param[in] p_user  - User to check
 * @param[in] fn      - Name of calling function for error log
 *
 * @return SX_UTILS_STATUS_SUCCESS - Subsystem initialized
 * @return SX_UTILS_STATUS_ERROR - Invalid user and/or group pointer
 */
sx_utils_status_t bai_validate_user(const bai_user_t *p_user, const char *fn)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if (!p_user) {
        SX_LOG_ERR("%s: Internal error - User is NULL!\n", fn);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    if (!p_user->allocated) {
        SX_LOG_ERR("%s: Internal error - User not allocated!\n", fn);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Make sure groups are allocated */
    if ((p_user->group_cnt == 0) || (p_user->groups == NULL)) {
        SX_LOG_ERR("%s: Internal error - Group count=%u data=%p invalid!\n",
                   fn, p_user->group_cnt, p_user->groups);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* Make sure group size is non-zero */
    if (p_user->group_size == 0) {
        SX_LOG_ERR("%s: Internal error - Group size 0!\n", fn);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Make sure user template correctly initialized */
    if ((p_user->template_count == 0) ||
        (p_user->template_count >= (UINT8_MAX - 1)) ||
        (p_user->template_count >= BIN_ALLOC_MAX_TYPES)) {
        SX_LOG_ERR("%s: Internal error - template count %u not in [1..%u]!\n",
                   fn, p_user->template_count, BIN_ALLOC_MAX_TYPES);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* All good if we get here */
    err = SX_UTILS_STATUS_SUCCESS;


out:
    return err;
}


/**
 * Validate a group structure can be used
 *
 * @param[in] p_user  - User to check
 * @param[in] p_group - Group to check
 * @param[in] fn      - Name of calling function for error log
 *
 * @return SX_UTILS_STATUS_SUCCESS - Subsystem initialized
 * @return SX_UTILS_STATUS_ERROR - Invalid user and/or group pointer
 */
static sx_utils_status_t __bai_validate_user_group(const bai_user_t  *p_user,
                                                   const bai_group_t *p_group,
                                                   const char        *fn)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          group_idx;

    /* Group is only valid in context of a valid user */
    err = bai_validate_user(p_user, fn);
    if (err) {
        goto out;
    }

    if (!p_group) {
        SX_LOG_ERR("%s: Internal error - Group is NULL!\n", fn);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Validate group pointer range */
    if ((p_group < &p_user->groups[0]) ||
        (p_group >= &p_user->groups[p_user->group_cnt])) {
        SX_LOG_ERR("%s: Internal error - Group pointer %p outside range!\n",
                   fn, p_group);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Make sure group points inside user group array */
    group_idx = p_group - p_user->groups;

    if (p_group != &p_user->groups[group_idx]) {
        SX_LOG_ERR("%s: Internal error - Group pointer %p unaligned!\n",
                   fn, p_group);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Validate group alignment */
    switch (p_group->align) {
    case ALIGN_NONE_E:
    case ALIGN_SIZE_E:
    case ALIGN_EVEN_E:
        break;

    default:
        SX_LOG_ERR("%s: Internal error - Unhandled alignment %u!\n",
                   fn, p_group->align);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    if (p_group->alloc_size == 0) {
        SX_LOG_ERR("%s: Internal error - allocate size is 0!\n", fn);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Make sure there is an allocation map of non-zero size */
    if (!p_group->array_map) {
        SX_LOG_ERR("%s: Internal error - No allocation map!\n", fn);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Make sure the per-LID state is allocated as well */
    if (!p_group->lids) {
        SX_LOG_ERR("%s: Internal error - No lid state!\n", fn);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* All good if we get here */
    err = SX_UTILS_STATUS_SUCCESS;


out:
    return err;
}


/**
 * Initialize a newly allocated group of specific type
 *   Called when our client gives us a new group
 *
 * @param[in] p_user - User handle that owns this group
 * @param[in/out] p_group - New group to be initialized for 'type' allocation
 * @param[in] type - Type of allocation this group must support
 *
 * @return SX_UTILS_STATUS_SUCCESS - Subsystem initialized
 * @return SX_UTILS_STATUS_SDK_ERROR - Invalid internal call
 */
static sx_utils_status_t __bai_init_group(const bai_user_t *p_user, bai_group_t      *p_group, const uint32_t type)
{
    sx_utils_status_t    err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t    err2 = SX_UTILS_STATUS_SUCCESS;
    cl_status_t          cl_status = CL_SUCCESS;
    const ba_template_t *p_in;
    bai_bucket_t        *p_out;
    uint32_t             i;
    int32_t              increment;
    int                  idx;

    /* Validate the user structure */
    err = bai_validate_user(p_user, __func__);
    if (err) {
        goto out;
    }

    /* Find the template associated with this type */
    for (idx = -1, i = 0; i < p_user->template_count; i++) {
        /* If we got to the end without finding it */
        if (p_user->templates[i].type == GROUP_TYPE_FREE) {
            break;
        }

        if (p_user->templates[i].type == type) {
            idx = i;
            break;
        }
    }

    if (idx < 0) {
        SX_LOG_WRN("Template %u not supported by this user!\n", type);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    /* Initialize the group allocation info based on type / template */
    p_in = &p_user->templates[idx];

    /* Available lines for allocation might be less than total */
    if ((p_in->length == 0) || (p_in->length > p_user->group_size)) {
        SX_LOG_ERR("Available lines %u not in range [1..%u]!\n", p_in->length,
                   p_user->group_size);

        err = SX_UTILS_STATUS_SDK_ERROR;
        goto out;
    }

    p_group->options = p_user->options;
    p_group->p_template = (ba_template_t*)p_in;
    p_group->alloc_size = p_in->length;
    p_group->free_lines = p_in->length;
    p_group->align = p_in->align;
    p_group->act_thresh = p_group->r_thresh;
    p_group->act_count = p_group->r_count;

    M_GEN_UTILS_CLR_MEM_GET(&p_group->array_map, 1, p_group->alloc_size, \
                            GEN_UTILS_MEM_TYPE_ID_BIN_E, "array_map", err);
    if ((err != 0) || (p_group->array_map == NULL)) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    M_GEN_UTILS_CLR_MEM_GET(&p_group->lids, p_group->alloc_size, \
                            sizeof(bai_lid_data_t),              \
                            GEN_UTILS_MEM_TYPE_ID_BIN_E, "lids", err);
    if ((err != 0) || (p_group->lids == NULL)) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }
    for (i = 0; i < p_group->alloc_size; i++) {
        cl_status = cl_spinlock_init(&p_group->lids[i].lock);
        if (cl_status != CL_SUCCESS) {
            SX_LOG_ERR("failed - init spinlock status code = %s\n", CL_STATUS_MSG(cl_status));
            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }
    }
    /* Initialize allocation buckets */
    for (i = 0; i < BIN_ALLOC_MAX_ALLOC_SIZES; i++) {
        if (p_in->alloc_sizes[i] == 0) {
            break;
        }

        p_out = &p_group->buckets[i];

        /* Calculate increment based on group alignment */
        switch (p_group->align) {
        case ALIGN_NONE_E:
            increment = 1;
            break;

        case ALIGN_SIZE_E:
            increment = p_out->size;
            break;

        case ALIGN_EVEN_E:
            increment = 2;
            break;

        default:
            /* This can't happen as validate above checked for it */
            increment = 1;
            break;
        }

        p_out->size = p_in->alloc_sizes[i];
        p_out->increment = increment;
        p_out->alloc_cnt = 0;
    }

    /* Number of active buckets */
    p_group->bucket_cnt = i;

    /* The size of the biggest bucket */
    p_group->max_alloc_size = p_in->alloc_sizes[p_group->bucket_cnt - 1];

    /* Initialize group cache and allocation hints */
    err = __bai_cache_init(p_group);
    if (err) {
        goto out;
    }

    /* If we got here, the group is initialized */
    p_group->type = type;

out:
    if ((err != SX_UTILS_STATUS_SUCCESS) && (p_group != NULL)) {
        if (p_group->array_map) {
            M_GEN_UTILS_MEM_PUT(p_group->array_map,          \
                                GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                                "array_map", err2);
        }
        p_group->array_map = NULL;

        if (p_group->lids) {
            M_GEN_UTILS_MEM_PUT(p_group->lids,               \
                                GEN_UTILS_MEM_TYPE_ID_BIN_E, \
                                "lids", err2);
        }
        p_group->lids = NULL;
        p_group->type = GROUP_TYPE_FREE;
    }

    return err;
}


/**
 * Return 'index' in to <user, template> of 'size'
 *   Used both to verify size is valid, and return index of group bucket
 * associated with this size.
 *
 * @param[in] p_user     - User context to select template in
 * @param[in] p_template - The template to search for requested size
 * @param[in] size       - The allocation size requested
 * @param[out] index_p   - Optional location to store index
 *
 * @return SX_UTILS_STATUS_SUCCESS - Location found
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND - size not in template
 */
sx_utils_status_t bai_find_size(bai_user_t *p_user, ba_template_t *p_template, uint32_t size, uint32_t      *index_p)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    uint32_t           i, template_idx;
    uint32_t           idx;
    bai_lookup_size_t *p_lookup;

    if ((p_user == NULL) || (p_template == NULL)) {
        SX_LOG_ERR("user(%p) and/or template(%p) NULL!\n", p_user, p_template);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* We need template index to find lookup table */
    template_idx = p_template - p_user->templates;
    if (template_idx >= p_user->template_count) {
        SX_LOG_ERR("Internal error - template pointer(%p) invalid!\n",
                   p_template);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }
    p_lookup = &p_user->lookup_size[template_idx];

    /* If size is small enough to find in lookup table, do that */
    if (size <= BIN_ALLOC_MAX_SIZE_LOOKUP) {
        idx = p_lookup->index[size];
    } else {
        if (p_lookup->slow_start < BIN_ALLOC_MAX_ALLOC_SIZES) {
            /* If we have a valid index, use that */
            idx = p_lookup->slow_start;
        } else {
            /* Otherwise no small blocks so start at 0 */
            idx = 0;
        }

        for (i = idx; i < BIN_ALLOC_MAX_ALLOC_SIZES; i++) {
            if (size == p_template->alloc_sizes[i]) {
                idx = i;
                break;
            }
        }
    }

    /* If we don't know the index, the size is not valid */
    if (size != p_template->alloc_sizes[idx]) {
        SX_LOG_WRN("Internal error - size %u does not match template %u!\n",
                   size, p_template->alloc_sizes[idx]);

        err = SX_UTILS_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (index_p) {
        *index_p = idx;
    }


out:
    return err;
}


/**
 * Search forwards looking for a hole of requested size
 *
 * @param[in] p_group     - Pointer to group to allocate from
 * @param[in] p_bucket    - Pointer to per-size tracking structure
 * @param[out] p_line_idx - Location to store first line of allocation
 *
 * @return SX_UTILS_STATUS_SUCCESS - Location found
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 */
static sx_utils_status_t __bai_search_slow_forward(bai_group_t  *p_group,
                                                   bai_bucket_t *p_bucket,
                                                   uint32_t     *p_line_idx)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i, j, idx, end;
    uint8_t           entry;
    boolean_t         found;

    /* The maximum array size to search */
    end = p_group->alloc_size - p_bucket->size;

    /*
     *   With RLE in use, the allocation array is only 100% valid when
     * starting at the beginning.  This rules out optimizations that
     * 'remember' where we last allocated.
     */
    for (i = 0; i <= end; i++) {
        entry = p_group->array_map[i];

        /* If we are at the start of an RLE segment, skip it */
        if (entry & LS_RLE_E) {
            i += *(uint32_t*)&p_group->array_map[i + 1] - 1;

            continue;
        }

        /* If there is something here, try the next line */
        if (entry) {
            continue;
        }

        /* If this is the wrong alignment keep looking */
        if (i % p_bucket->increment) {
            continue;
        }

        /* Scan from here the length requested */
        found = TRUE;
        for (j = 0; j < p_bucket->size; j++) {
            idx = i + j;

            if (p_group->array_map[idx] == 0) {
                continue;
            }

            found = FALSE;
            break;
        }

        /* Aligned hole of required size starting at i found */
        if (found) {
            *p_line_idx = i;
            goto out;
        }

        /* No point in chewing through the same empty space */
        i = idx - 1;
    }

    err = SX_UTILS_STATUS_NO_RESOURCES;


out:
    return err;
}


/**
 * Find the 'best' location to allocate a block of given size in given group
 *   Scan the allocation map of the given group looking for the best place
 * to allocate a block of the requested size.
 *
 * @param[in] p_user      - Pointer to user context making the call
 * @param[in] p_group     - Pointer to group to allocate from
 * @param[in] p_bucket    - Pointer to per-size tracking structure
 * @param[out] p_line_idx - Location to store first line of allocation
 *
 * @return SX_UTILS_STATUS_SUCCESS - Location found
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 */
sx_utils_status_t __bai_find_slot(bai_user_t   *p_user,
                                  bai_group_t  *p_group,
                                  bai_bucket_t *p_bucket,
                                  uint32_t     *p_line_idx)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          start;

    /* Handle the easy case */
    if (p_group->free_lines < p_bucket->size) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    if (p_line_idx == NULL) {
        SX_LOG_ERR("Internal error - Return location NULL!\n");

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Try to allocate the fast way by looking at existing holes */
    err = __bai_hole_alloc(p_user, p_group, p_bucket->size, p_line_idx);
    if (err == 0) {
        goto out;
    }

    /*
     *   If the holes cache knows about all free lines, and relocation failed,
     * then there is no space available.   Report the failure and out.
     */
    if (err == SX_UTILS_STATUS_NO_RESOURCES) {
        goto out;
    }

    /* If the holes cache does not cover all holes, search the long way */
    if (err == SX_UTILS_STATUS_PARTIALLY_COMPLETE) {
        err = 0;
    } else if (err) {
        /* Real errors get forwarded */
        goto out;
    }

    /* Need to use the slow path */
    err = __bai_search_slow_forward(p_group, p_bucket, &start);
    if (err) {
        goto out;
    }

    *p_line_idx = start;


out:
    return err;
}


/**
 * Given a group, attempt to allocate from it.
 *
 * @param[in] p_user  - Pointer to user context making the call
 * @param[in] p_group - Pointer to group to allocate from
 * @param[in] size    - Number of contiguous entries needed
 * @param[in] cntx    - Initial value of user context associated with this lid
 * @param[out] lid_p  - Pointer to where to store logical ID for allocation
 *
 * @return SX_UTILS_STATUS_SUCCESS - Allocation successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 */
sx_utils_status_t __bai_allocate(bai_user_t       *p_user,
                                 bai_group_t      *p_group,
                                 uint32_t          size,
                                 uint32_t          cntx,
                                 bai_logical_id_t *lid_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          line_idx, bucket_idx;
    uint8_t           lid_type;
    bai_logical_id_t  lid;
    bai_bucket_t     *p_bucket;

    /* Validate the user/group info used for calculations */
    err = __bai_validate_user_group(p_user, p_group, __func__);
    if (err) {
        goto out;
    }

    /* Make sure we got non-NULL pointers */
    if (!lid_p) {
        SX_LOG_ERR("Internal error - LID pointer is NULL!\n");

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Validate size is valid for group */
    err = bai_find_size(p_user, p_group->p_template, size, &bucket_idx);
    if (err) {
        goto out;
    }

    /* Convert size into a pointer to the per-size allocation data */
    p_bucket = &p_group->buckets[bucket_idx];
    if (p_bucket->size != size) {
        SX_LOG_ERR("Internal error - LID bucket %u size=%u not %u!\n",
                   bucket_idx, p_bucket->size, size);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    err = __bai_find_slot(p_user, p_group, p_bucket, &line_idx);
    if (err) {
        goto out;
    }

    /* Found it - Update array_map[] */
    err = __bai_block_reserve(p_group, line_idx, size);
    if (err) {
        goto out;
    }

    /* Initialize reference count and user context */
    p_group->lids[line_idx].ref = 1;
    p_group->lids[line_idx].client_context = cntx;
    SX_LOG_DBG(" LID 0x%X lock inited Ref count = 1\n", line_idx);
    /* Convert user type to encoded value */
    err = bai_type_to_lid_type(p_user, p_group->type, &lid_type);
    if (err) {
        goto out;
    }

    /* Create the lid */
    err = __bai_ilid(p_user, p_group, line_idx, &lid);
    if (err) {
        goto out;
    }

    p_bucket->alloc_cnt++;

    p_group->free_lines -= size;

    *lid_p = lid;


out:
    return err;
}


/**
 * Ask client for a new group and initialize it
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] group  - Pointer to where to return initialized group pointer
 * @param[in] type   - Type of entry to allocate
 *
 * @return SX_UTILS_STATUS_SUCCESS - Allocation successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 */
static sx_utils_status_t __bai_get_new_group(bai_user_t *p_user, bai_group_t **group, uint32_t type)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    const ba_group_t *r_group;
    ba_handle_t       handle = (ba_handle_t)p_user;
    ba_template_t    *p_template;
    bai_group_t      *p_group;
    uint32_t          i;

    /* Find matching template */
    for (i = 0; i < p_user->template_count; i++) {
        p_template = &p_user->templates[i];

        if (p_template->type == type) {
            break;
        }

        p_template = NULL;
    }

    if (!p_template) {
        SX_LOG_ERR("Internal error - No template of type %u found!\n", type);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Request a group from our client */
    err = p_template->cb_alloc(handle, type, &r_group);
    if (err == SX_UTILS_STATUS_NO_RESOURCES) {
        goto out;
    }

    if (err) {
        SX_LOG_ERR("Internal error - Client failed group allocation %u!\n",
                   err);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Validate client response */
    if (!r_group) {
        SX_LOG_ERR("Internal error - Client returned NULL group pointer!\n");

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    if (r_group->type != type) {
        SX_LOG_ERR("Internal error - Client returned type %u not %u!\n",
                   r_group->type, type);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    if (r_group->grp_index >= p_user->group_cnt) {
        SX_LOG_ERR("Internal error - Client returned bad group %u >= %u!\n",
                   r_group->grp_index, p_user->group_cnt);

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    p_group = &p_user->groups[r_group->grp_index];

    if (p_group->type != GROUP_TYPE_FREE) {
        SX_LOG_ERR("Internal error - Client returned ACTIVE group!\n");

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Initialize the new empty group */
    err = __bai_init_group(p_user, p_group, type);
    if (err) {
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    *group = p_group;


out:
    return err;
}


/**
 * compare function needed by qsort (for groups)
 *
 * @param[in] p1 - Pointer to group 1
 * @param[in] p2 - Pointer to group 2
 *
 * Returns:
 *   -1: p1.c_efficiency < p2.c_efficiency
 *    0: p1.c_efficiency == p2.c_efficiency
 *    1: p1.c_efficiency > p2.cache_efficiency
 */
static int __bai_cmp_group(const void *p1, const void *p2)
{
    bai_group_t *p_g1 = *(bai_group_t**)p1;
    bai_group_t *p_g2 = *(bai_group_t**)p2;

    if (p_g1->c_efficiency == p_g2->c_efficiency) {
        return 0;
    } else if (p_g1->c_efficiency < p_g2->c_efficiency) {
        return -1;
    } else {
        return 1;
    }
}


/**
 * compare function needed by qsort (for blocks)
 *   Sort order is decreasing number of lines per-block.  In the case where
 * two blocks have the same length, the block with the lowest reference
 * count (thus cost) is ordered first.
 *
 * @param[in] p1 - Pointer to block 1
 * @param[in] p2 - Pointer to block 2
 *
 * Returns:
 *   -1: b1.len > b2.len (or equal and b1.ref < b2.ref)
 *    0: b1.len/ref is the same as b1.len/ref
 *    1: b1.len < b1.len (or equal and b1.ref > b2.ref)
 */
static int __bai_cmp_block(const void *p1, const void *p2)
{
    bai_block_element_t *p_b1 = (bai_block_element_t*)p1;
    bai_block_element_t *p_b2 = (bai_block_element_t*)p2;

    if (p_b1->len > p_b2->len) {
        return -1;
    } else if (p_b1->len < p_b2->len) {
        return 1;
    }

    /* If equal length, lower reference count wins */
    if (p_b1->ref < p_b2->ref) {
        return -1;
    } else if (p_b1->ref > p_b2->ref) {
        return 1;
    }

    /* If length and reference counts are equal, they are the same */
    return 0;
}


/**
 * Compare function needed by qsort (for cost)
 *   Sort order is increasing cost.
 *
 * @param[in] p1 - Pointer to block 1
 * @param[in] p2 - Pointer to block 2
 *
 * Returns:
 *  -1: b1.cost < b2.cost
 *   0: b1.cost = b2.cost
 *   1: b1.cost > b2.cost
 */
static int __bai_cmp_cost(const void *p1, const void *p2)
{
    bai_block_element_t *p_b1 = (bai_block_element_t*)p1;
    bai_block_element_t *p_b2 = (bai_block_element_t*)p2;
    uint32_t             cost1, cost2;

    cost1 = p_b1->len + p_b1->ref;
    cost2 = p_b2->len + p_b2->ref;

    if (cost1 < cost2) {
        return -1;
    } else if (cost1 > cost2) {
        return 1;
    }

    return 0;
}


/**
 * Create an ordered list of groups to search for a new allocation
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] size   - Number of contiguous entries needed (or 0)
 * @param[in] idx    - Index in p_user->templates[] of template for type
 * @param[out] groups_p - Array of pointers to groups to try
 * @param[out] cnt_p    - Number of entries returned in groups
 *
 * @return SX_UTILS_STATUS_SUCCESS - Allocation successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 */
static sx_utils_status_t __bai_get_group_list(bai_user_t  *p_user,
                                              uint32_t     size,
                                              uint32_t     idx,
                                              bai_group_t *groups_p[],
                                              uint32_t    *cnt_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_group_t      *p_group, *p_tmp, *p_free = NULL, *p_fits = NULL;
    bai_group_t      *t_group[MAX_GROUPS];
    uint32_t          i, cnt, cnt_out = 0, type;

    type = p_user->templates[idx].type;

    /* Create unordered list of groups that match requested type */
    for (i = cnt = 0; i < p_user->group_cnt; i++) {
        p_group = &p_user->groups[i];

        /* Free group never matches - But track the first one we find */
        if (p_group->type == GROUP_TYPE_FREE) {
            if (!p_free) {
                p_free = p_group;
            }

            continue;
        }

        /* If we are subsetting the list, do that here */
        if (size != 0) {
            /* Ignore allocated groups that don't match the type */
            if (p_group->type != type) {
                continue;
            }

            /* Ignore groups that don't have enough free lines */
            if (p_group->free_lines < size) {
                continue;
            }

            /* Track the group that has smallest hole that fits size */
            if (p_group->c_max_hole >= size) {
                if (p_fits == NULL) {
                    p_fits = p_group;
                    continue;
                } else if (p_group->c_max_hole < p_fits->c_max_hole) {
                    p_tmp = p_fits;
                    p_fits = p_group;

                    /* Put the last cached group into the array to sort */
                    p_group = p_tmp;
                }
            }
        }

        /*
         * Update group efficiency (if needed)
         *   When called with selection criteria (size, idx), we don't waste
         * cycles calculating the efficiency of the last group allocated from
         * because we automatically try to allocate from it again.
         */
        if ((size == 0) && (!p_group->alloc_cache_valid)) {
            err = bai_cache_update(p_group);
            if (err) {
                goto out;
            }

            /* Make sure the cache is valid now */
            if (!p_group->alloc_cache_valid) {
                /* Programming error - Nothing we an do here */
                err = SX_UTILS_STATUS_ERROR;
                goto out;
            }
        }

        /* Save the group in the unordered list */
        t_group[cnt++] = p_group;
    }

    /* Sort the array by increasing efficiency */
    if (cnt > 1) {
        qsort(t_group, cnt, sizeof(t_group[0]), __bai_cmp_group);
    }

    /*
     * Output group; cnt=n with sort criteria (size, idx/tpe)
     *   1      - p_fits; Group with smallest hole fitting 'size'
     *   1..n-1 - Ordered list of groups with matching type
     *   n      - Pointer to a free group (if one exists)
     */
    if (p_fits) {
        groups_p[cnt_out++] = p_fits;
    }

    /* Copy the sorted array */
    for (i = 0; i < cnt; i++) {
        groups_p[cnt_out++] = t_group[i];
    }

    /* If we found a free group, and this is a request by alloc, add it */
    if ((size != 0) && (p_free != NULL)) {
        groups_p[cnt_out++] = p_free;
    }

    if (cnt_out == 0) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
    }

    *cnt_p = cnt_out;


out:
    return err;
}


/**
 * Allocate a set of contiguous table entries
 *   - All checks already done
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] type   - Type of entry to allocate
 * @param[in] size   - Number of contiguous entries needed
 * @param[in] cntx   - Initial value of user context associated with this lid
 * @param[in] idx    - Index in p_user->templates[] of template for type
 * @param[out] lid_p - Pointer to where to store logical ID for allocation
 *
 * @return SX_UTILS_STATUS_SUCCESS - Allocation successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 */
sx_utils_status_t bai_alloc(bai_user_t       *p_user,
                            uint32_t          type,
                            uint32_t          size,
                            uint32_t          cntx,
                            uint32_t          idx,
                            bai_logical_id_t *lid_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_group_t      *p_group, *p_last, *groups[MAX_GROUPS];
    uint32_t          i, cnt;

    /* If there is space, try to use the last group that worked */
    p_last = p_user->lookup_size[idx].group_last;

    /*
     *   Always try to allocate from the same group we allocated from last
     * time.  There are a number of things that might have happened to make
     * this allocation invalid so check.
     */
    if (p_last) {
        if ((p_last->type == type) && (p_last->free_lines >= size)) {
            err = __bai_allocate(p_user, p_last, size, cntx, lid_p);
            if (err == SX_UTILS_STATUS_SUCCESS) {
                goto out;
            }
        } else {
            /* No previous group */
            p_last = NULL;
        }
    }

    /* Get an ordered list of groups that can service this request */
    err = __bai_get_group_list(p_user, size, idx, groups, &cnt);
    if (err) {
        goto out;
    }

    /* Try to find an active group with the correct type */
    for (i = 0; i < cnt; i++) {
        p_group = groups[i];

        /* We already tried the last group */
        if ((p_last != NULL) && (p_group == p_last)) {
            continue;
        }

        /*
         *   If we tried all the valid groups and no luck allocating
         * from them, we can try to get a new one.
         */
        if (p_group->type == GROUP_TYPE_FREE) {
            err = __bai_get_new_group(p_user, &p_group, type);
            if (err) {
                goto out;
            }
        }

        /* Try to allocate out of this group */
        err = __bai_allocate(p_user, p_group, size, cntx, lid_p);
        if (err == SX_UTILS_STATUS_NO_RESOURCES) {
            continue;
        }

        /* If we allocated from this group, remember it for next time */
        if (err == SX_UTILS_STATUS_SUCCESS) {
            p_user->lookup_size[idx].group_last = p_group;

            /* Invalidate the cache since allocation has changed */
            p_group->alloc_cache_valid = FALSE;

            /* Reset background relocation count since last user alloc/free */
            p_group->reloc_cnt = 0;
        }

        /* Error or success - we pass it back to our caller */
        goto out;
    }

    /* In case there are no free groups and no space */
    err = SX_UTILS_STATUS_NO_RESOURCES;


out:
    return err;
}


/**
 * Free a previously allocated set of contiguous table entries
 *   - All checks already done
 *
 * @param[in] p_user - Pointer to user info
 * @param[in] lid    - The logical ID to free
 *
 * @return SX_UTILS_STATUS_SUCCESS - Deallocation successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t bai_free(bai_user_t *p_user, bai_logical_id_t lid)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_group_t      *p_group;
    bai_bucket_t     *p_bucket;
    uint32_t          group_idx, line_idx, idx, size;

    /* Extract/validate internal LID fields */
    err = bai_extract_i_lid(p_user, lid, __func__, NULL,
                            &group_idx, &line_idx);
    if (err) {
        goto out;
    }

    p_group = &p_user->groups[group_idx];

    /* Make sure chunk is allocated and get size */
    err = bai_block_size(p_group, line_idx, &size);
    if (err) {
        goto out;
    }

    /* Validate the size and get bucket pointer for stats update */
    err = bai_find_size(p_user, p_group->p_template, size, &idx);
    if (err) {
        goto out;
    }
    p_bucket = &p_group->buckets[idx];

    /* Remove the block from array_map + update hole cache */
    err = bai_block_free(p_group, line_idx);
    if (err) {
        goto out;
    }

    /* Do the bookkeeping for reference counts */
    p_group->free_lines += size;
    p_group->reloc_cnt = 0;

    p_bucket->alloc_cnt--;

    /* If the group is not empty, we are done */
    if (p_group->free_lines != p_group->alloc_size) {
        /* Mark cache as invalid because allocation has changed */
        p_group->alloc_cache_valid = FALSE;

        goto out;
    }

    err = bai_free_group(p_user, p_group);
    if (err) {
        goto out;
    }


out:
    return err;
}


/**
 * Merge blocks out of 'from' to group 'to'
 *   Iterate through all the blocks in 'from' and attempts to move them to
 * group 'to'.  Blocks are selected strictly by size; biggest block first.
 * This minimizes the chances that we will have to move a block twice.
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] p_from - Group to move a block out of
 * @param[in] p_to - Group to move a block into (or try)
 * @param[in/out] used - Count of relocations done
 *
 * @return SX_UTILS_STATUS_SUCCESS - One block moved
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space in p_to
 */
static sx_utils_status_t __bai_merge_one(bai_user_t *p_user, bai_group_t *p_from, bai_group_t *p_to, uint32_t    *used)
{
    sx_utils_status_t    err = SX_UTILS_STATUS_SUCCESS;
    uint32_t             i, max_moves, cur_moves, offset, idx;
    bai_block_element_t *p_block;
    bai_bucket_t        *p_bto;

    max_moves = p_from->act_count;
    cur_moves = *used;

    for (i = 0; i < p_user->cnt_blocks; i++) {
        p_block = &p_user->blocks[i];

        /* Ignore empty blocks - In case somebody edits them for us */
        if (p_block->len == 0) {
            continue;
        }

        /* No point wasting time if it can't service the request */
        if (p_to->free_lines < p_block->len) {
            continue;
        }

        /* Ignore blocks that are locked by the user */
        if (p_from->array_map[p_block->offset] & LS_LOCKED_E) {
            continue;
        }

        /* Need the template associated with the target group */
        err = bai_find_size(p_user, p_to->p_template, p_block->len, &idx);
        if (err) {
            goto out;
        }
        p_bto = &p_to->buckets[idx];

        /* See if we can find a hole of the proper size */
        err = __bai_hole_search(p_to, p_block->len, &offset);
        if (err == SX_UTILS_STATUS_NO_RESOURCES) {
            err = 0;
            continue;
        }

        /* If error indicates there MIGHT be space, search the long way */
        if (err == SX_UTILS_STATUS_PARTIALLY_COMPLETE) {
            err = __bai_search_slow_forward(p_to, p_bto, &offset);
            if (err == SX_UTILS_STATUS_NO_RESOURCES) {
                /* No luck fast or slow - Try the next size */
                err = 0;
                continue;
            }
        }

        /* Anything but no space is unexpected - don't continue */
        if (err) {
            goto out;
        }

        /* Need pointers to the 'from' and 'to' buckets for this size */
        err = bai_find_size(p_user, p_from->p_template, p_block->len, &idx);
        if (err) {
            goto out;
        }

        /* Relocate the block - Should work */
        err = __bai_relocate_block(p_user, p_from, p_block->offset,
                                   p_to, offset, p_block->len,
                                   BA_RELOC_FLOW_MERGE);
        if (err) {
            goto out;
        }

        /* Update bucket counters in destination group */
        p_bto->alloc_cnt++;

        /* Update total free line counts in destination group */
        p_to->free_lines -= p_block->len;

        /* Mark the cache for destination group as invalid */
        p_to->alloc_cache_valid = FALSE;

        /* Bookkeeping to limit work per-dispatch */
        cur_moves++;
        *used = cur_moves;

        /* If we have used all our move budget, have to return now */
        if (cur_moves >= max_moves) {
            goto out;
        }
    }


out:
    *used = cur_moves;

    return err;
}


/**
 * Initialize user allocated block cache
 *
 * @param[in] p_user - Pointer to use context containing the cache
 * @param[in] p_group - Group to parse into the cache
 *
 * @return SX_UTILS_STATUS_SUCCESS - Cache initialized
 * @return SX_UTILS_STATUS_ERROR - Cache already active
 */
static sx_utils_status_t __bai_block_cache_init(bai_user_t *p_user, bai_group_t *p_group)
{
    sx_utils_status_t    err = SX_UTILS_STATUS_SUCCESS;
    bai_block_element_t *p_block;
    uint32_t             i, size, cnt_blocks;

    /* Scan the group we want to empty and initialize blocks cache */
    if (p_user->p_drain) {
        SX_LOG_ERR("Internal error - Group already active!\n");

        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Create an unordered list of blocks in the group to empty */
    p_user->p_drain = p_group;
    for (i = cnt_blocks = 0; i < p_group->alloc_size; i++) {
        if (p_group->array_map[i] == 0) {
            continue;
        }

        err = bai_block_size(p_group, i, &size);
        if (err) {
            goto out;
        }

        p_block = &p_user->blocks[cnt_blocks++];

        p_block->offset = i;
        p_block->len = size;
        p_block->ref = p_group->lids[i].ref;

        i += size - 1;
    }
    p_user->cnt_blocks = cnt_blocks;


out:
    return err;
}


/**
 * Empty the requested group into other active groups of the same type
 *
 * @param[in] p_user - Pointer to user context making the call
 * @param[in] p_empty - Pointer to the group to empty
 * @param[in] groups - The list of all active groups sorted allocation order
 * @param[in] cnt_group - Number of entries in groups[]
 * @param[in/out] used - Pointer to number of relocations
 *
 * @return SX_UTILS_STATUS_SUCCESS - Merge successful
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - Unable to empty p_empty; no space
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Not finished after r_count
 */
static sx_utils_status_t __bai_merge_group(bai_user_t  *p_user,
                                           bai_group_t *p_empty,
                                           bai_group_t *groups[],
                                           uint32_t     cnt_group,
                                           uint32_t    *used)
{
    sx_utils_status_t    err = SX_UTILS_STATUS_SUCCESS;
    bai_group_t         *p_group;
    bai_block_element_t *p_block;
    uint32_t             i = 0;

    /* Initialize the block cache */
    err = __bai_block_cache_init(p_user, p_empty);
    if (err) {
        goto out;
    }

    /* Sort the block array into decreasing number of lines per-block */
    if (p_user->cnt_blocks > 1) {
        qsort(p_user->blocks, p_user->cnt_blocks, sizeof(*p_block), __bai_cmp_block);
    }

    for (i = 0; i < cnt_group; i++) {
        p_group = groups[i];

        /* Ignore empty entries */
        if (!p_group) {
            continue;
        }

        /* If we couldn't finish based on time, return partial result */
        if (*used >= p_group->act_count) {
            err = SX_UTILS_STATUS_PARTIALLY_COMPLETE;

            goto out;
        }

        /* Ignore groups of the wrong type */
        if (p_group->type != p_empty->type) {
            continue;
        }

        /* Ignore the group being emptied */
        if (p_group == p_empty) {
            continue;
        }

        /* Move as many blocks from p_empty to p_group as fit */
        err = __bai_merge_one(p_user, p_empty, p_group, used);
        if (err == SX_UTILS_STATUS_NO_RESOURCES) {
            /* That's ok - Try the next group */
            err = 0;
            continue;
        }

        /* Any other errors mean we have a problem and need to exit */
        if (err) {
            goto out;
        }

        /* If p_empty is really empty, free it */
        if (p_empty->free_lines == p_empty->alloc_size) {
            err = bai_free_group(p_user, p_empty);
            if (err) {
                goto out;
            }

            goto out;
        }
    }

    /* Getting here means we couldn't fit into the other groups */
    err = SX_UTILS_STATUS_NO_RESOURCES;


out:
    /* Invalidate the cache of blocks in this group */
    p_user->p_drain = NULL;

    return err;
}


/**
 * Create ordered list of active groups and update the per-group cache
 *   On output, the groups[] array is sorted in increasing order of
 * efficiency.
 *
 *   A summary, by type, is created as well.  This summary includes the
 * total number of active groups of that type, the total number of free
 * lines across all active groups of that type, and the single group of
 * that type with the lowest 'cost' associated with all allocations in that
 * group.
 *
 * @param[in] p_user - Pointer to user context to defragment
 * @param[in/out] groups - The list of all active groups sorted by efficiency
 * @param[in/out] cnt_p - Pointer to number of active spaces in groups[]
 *
 * @return SX_UTILS_STATUS_SUCCESS - Success
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 */
static sx_utils_status_t __bai_order_groups(bai_user_t *p_user, bai_group_t *groups[], uint32_t    *cnt_p)
{
    sx_utils_status_t  err = SX_UTILS_STATUS_SUCCESS;
    uint32_t           i, cnt;
    bai_group_t       *p_group;
    bai_lookup_size_t *p_lookup;

    /* Request order list of groups (with cache updates0 for this user */
    err = __bai_get_group_list(p_user, 0, 0, groups, &cnt);
    if (err) {
        goto out;
    }

    /* Clear per-type summary info */
    for (i = 0; i < p_user->template_count; i++) {
        p_user->lookup_size[i].total_free_lines = 0;
        p_user->lookup_size[i].total_groups = 0;
        p_user->lookup_size[i].group_min_cost = NULL;
    }

    /* Update per-type summary to decide if merge is possible */
    for (i = 0; i < cnt; i++) {
        p_group = groups[i];

        /* Extract pointer to per-group summary info */
        p_lookup = &p_user->lookup_size[p_group->p_template -
                                        p_user->templates];

        /* Update total per-group free line count */
        p_lookup->total_free_lines += p_group->free_lines;

        /* Update count of groups of this type */
        p_lookup->total_groups++;

        /* Update pointer to group with the largest number of free lines */
        if (p_lookup->group_min_cost == NULL) {
            p_lookup->group_min_cost = p_group;
        } else if (p_lookup->group_min_cost->c_cost_sum > p_group->c_cost_sum) {
            p_lookup->group_min_cost = p_group;
        }
    }


out:
    *cnt_p = cnt;

    return err;
}


/**
 * Find location for moved block
 *   This is a special search that finds a hole not adjacent to the block
 * we are considering moving.
 *
 * @param[in] p_user - Pointer to the user context owning group
 * @param[in] p_group - Pointer to the group we are defragmenting
 * @param[in] p_block - Pointer to the block we want to move (ref=frags)
 * @param[out] p_to - Pointer to a hole to describe destination for movement
 *
 * @return SX_UTILS_STATUS_SUCCESS - Success
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
static sx_utils_status_t __bai_defrag_group(bai_user_t          *p_user,
                                            bai_group_t         *p_group,
                                            bai_block_element_t *p_from,
                                            bai_block_element_t *p_to)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i, j, size, left_size, skip, offset, frags;

    /* Avoid "... may be used uninitialized ..." errors */
    p_to->offset = 0;
    p_to->len = 0;

    /* Scan the group the slow way looking for best fitting hole */
    for (i = 0; i < p_group->alloc_size; i++) {
        /* If we are looking at a block, skip over it and try the next */
        if (p_group->array_map[i]) {
            err = bai_block_size(p_group, i, &size);
            if (err) {
                goto out;
            }

            /* Skip over the block */
            i += size - 1;

            continue;
        }

        /* Calculate the size of the free block */
        offset = i;
        size = 1;

        for (j = i + 1; j < p_group->alloc_size; j++) {
            if (p_group->array_map[j] != 0) {
                break;
            }

            size++;
        }

        /* Point to last line of the free region */
        i += size - 1;

        /* Remember free space just ahead of block that is moving */
        left_size = ((i + 1) == p_from->offset) ? size : 0;

        /* If the free block is too small, ignore it */
        if (size < p_from->len) {
            continue;
        }

        /* Calculate alignment requirements */
        switch (p_group->align) {
        case ALIGN_NONE_E:
            skip = 0;
            break;

        case ALIGN_SIZE_E:
            skip = offset % size;
            if (skip) {
                skip = size - skip;
            }
            break;

        case ALIGN_EVEN_E:
            skip = (offset & 1) ? 1 : 0;
            break;

        default:
            SX_LOG_ERR("Internal error - Invalid align %u\n", p_group->align);
            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        /* Get offset and length of proposed destination */
        offset += skip;
        size -= skip;

        /* If hole too small to handle size with alignment, we are done */
        if (size < p_from->len) {
            continue;
        }

        /* See how many 'too small' fragments are created by this allocation */
        frags = 0;

        /* If we created a fragment ahead of this "move to" location */
        if ((skip != 0) && (skip < p_group->c_max_size)) {
            frags++;
        } else if ((p_from->offset + p_from->len) == offset) {
            /* We moved the block to the free space right after it */
            if ((p_from->len + left_size) < p_group->c_max_size) {
                frags++;
            }
        }

        /* Adjust size if hole we are moving from is block on the right */
        if ((offset + size) == p_from->offset) {
            size += p_from->len;

            for (j = offset + size; j < p_group->alloc_size; j++) {
                if (p_group->array_map[j] != 0) {
                    break;
                }

                size++;
            }
        }

        /* If we created a fragment after this "move to" location */
        if ((size != p_from->len) &&
            ((size - p_from->len) < p_group->c_max_size)) {
            frags++;
        }

        /* If it is a perfect fit, use it */
        if (frags == 0) {
            p_to->offset = offset;
            p_to->len = p_from->len;
            p_to->ref = 0;

            goto out;
        }

        /* If this dest does not decrease group fragmentation, we are done */
        if (frags >= p_from->ref) {
            continue;
        }

        /* If the hole we know is smaller than this one, use it */
        if (p_to->len < size) {
            continue;
        }

        /* Remember the first destination that improves things */
        p_to->offset = offset;
        p_to->len = size;
        p_to->ref = frags;
    }

    /* If we got a non-perfect fit that reduces fragmentation, use it */
    if (p_to->len != 0) {
        p_to->len = p_from->len;
        goto out;
    }

    /* If we got all the way through and didn't relocate the block too bad */
    err = SX_UTILS_STATUS_NO_RESOURCES;


out:
    /* If we found a place to move to, the holes cache is invalid */
    if ((!err)) {
        p_group->hole_cache_valid = FALSE;
    } else if (err != SX_UTILS_STATUS_NO_RESOURCES) {
        /* TMP: Disable relocation if an unexpected error */
        p_user->options &= ~(RELOC_SYNC_E | RELOC_ASYNC_E | RELOC_ASYNC_GC_E);
    }

    return err;
}


/**
 * Attempt to improve efficiency of a group
 *   Scan the list of allocated blocks in this group and move the cheapest
 * block that improves the ability to allocate maximum size blocks in the
 * group.
 *
 * @param[in] p_user - User context for this defragmentation
 * @param[in] p_group - Group to attempt to defragment
 * @param[in/out] used_p - Pointer to number of relocations so far this round
 *
 * @return SX_UTILS_STATUS_SUCCESS - One block was relocated inside group
 * @return SX_UTILS_STATUS_NO_RESOURCES - No move improves group free space
 */
static sx_utils_status_t __bai_improve_one(bai_user_t *p_user, bai_group_t *p_group, uint32_t    *used_p)
{
    sx_utils_status_t    err = SX_UTILS_STATUS_SUCCESS;
    bai_block_element_t *p_block, to;
    hole_state_e         hole_left, hole_right;
    uint32_t             i, j, idx, max_size, bucket_idx = 0;
    bai_bucket_t        *p_bucket = NULL;

    /* Initialize the block cache */
    err = __bai_block_cache_init(p_user, p_group);
    if (err) {
        goto out;
    }

    /* Sort blocks in increasing cost */
    if (p_user->cnt_blocks > 1) {
        qsort(p_user->blocks, p_user->cnt_blocks, sizeof(*p_block),
              __bai_cmp_cost);
    }

    /*
     * For each allocated block, consider if moving it helps.
     *   Moving a block makes the group 'better' only if it increases
     * the number maximum size holes in the that group.  The maximum
     * size hole in a group is the biggest hole that can be allocated
     * from the number of free lines available in the group.
     *
     * Since cache was recalculated above, we can just use this value
     */
    max_size = p_group->c_max_size;

    /* Review each block */
    for (i = 0; i < p_user->cnt_blocks; i++) {
        p_block = &p_user->blocks[i];

        /* We don't expect this, but perhaps the list was edited */
        if (p_block->len == 0) {
            continue;
        }

        /* block.ref encodes number of 'too small' hole around block */
        p_block->ref = 0;

        /* See if the block has a hole to the left */
        idx = p_block->offset;
        if ((idx == 0) || (p_group->array_map[idx - 1] != 0)) {
            hole_left = HOLE_NONE_E;
        } else if (idx < max_size) {
            p_block->ref++;
            hole_left = HOLE_SMALL_E;
        } else {
            hole_left = HOLE_MAX_E;

            /* Anything but empty space means hole is SMALL */
            for (j = idx - max_size; j < idx; j++) {
                if (p_group->array_map[j] != 0) {
                    p_block->ref++;
                    hole_left = HOLE_SMALL_E;
                    break;
                }
            }
        }

        /* See if the block has a hole to the right */
        idx = p_block->offset + p_block->len;
        if ((idx >= p_group->alloc_size) || p_group->array_map[idx]) {
            hole_right = HOLE_NONE_E;
        } else if (idx > (p_group->alloc_size - max_size)) {
            p_block->ref++;
            hole_right = HOLE_SMALL_E;
        } else {
            hole_right = HOLE_MAX_E;

            for (j = 0; j < max_size; j++) {
                if (p_group->array_map[idx + j] != 0) {
                    p_block->ref++;
                    hole_right = HOLE_SMALL_E;
                    break;
                }
            }
        }

        /*
         *   Consider relocating blocks that have SMALL holes on either
         * or both sides.  All other combinations cannot improve the
         * ability to allocate c_max_size blocks in this group.
         */
        if ((hole_left != HOLE_SMALL_E) && (hole_right != HOLE_SMALL_E)) {
            continue;
        }

        /* Ignore blocks that are locked by the user */
        if (p_group->array_map[p_block->offset] & LS_LOCKED_E) {
            continue;
        }

        /* Attempt to find a location to move the block to */
        err = __bai_defrag_group(p_user, p_group, p_block, &to);
        if (err == SX_UTILS_STATUS_NO_RESOURCES) {
            /* Couldn't find a spot - Try the next block */
            err = SX_UTILS_STATUS_SUCCESS;
            continue;
        }

        /* Reflect other errors to caller */
        if (err) {
            goto out;
        }

        /* Relocate the block */
        err = __bai_relocate_block(p_user, p_group, p_block->offset,
                                   p_group, to.offset, to.len,
                                   BA_RELOC_FLOW_IMPROVE);
        if (err) {
            goto out;
        }

        /* Update accounting fields for group and bucket.
         * Even though we relocated inside the same group, since the relocation
         * is done asynchronously (allocate first, free later), the per-group
         * accounting doesn't stay the same until after the free is done. */
        err = bai_find_size(p_user, p_group->p_template, p_block->len,
                            &bucket_idx);
        if (err) {
            goto out;
        }

        p_bucket = &p_group->buckets[bucket_idx];

        /* Update bucket counters in destination group */
        p_bucket->alloc_cnt++;

        /* Update total free line counts in destination group */
        p_group->free_lines -= p_block->len;

        /* Update count of moves done this timer pop */
        *used_p = *used_p + 1;

        /* Mark the cache for this group as invalid */
        p_group->alloc_cache_valid = FALSE;

        err = bai_cache_update(p_group);
        if (err) {
            goto out;
        }

        goto out;
    }

    err = SX_UTILS_STATUS_NO_RESOURCES;


out:
    p_user->p_drain = NULL;
    return err;
}


/**
 * Main entry point for asynchronous merge
 *   Called by the SDK timer thread to attempt to coalesce small blocks of
 * free lines in various groups into larger chunks.
 *
 * @param[in] p_user - Pointer to user context to defragment
 *
 * @return SX_UTILS_STATUS_SUCCESS - It worked
 * @return SX_UTILS_STATUS_PARAM_NULL - p_user is NULL
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Try searching line-by-line
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t bai_async_relocate(bai_user_t *p_user)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    bai_group_t      *p_group, *p_cheap, *p_next;
    bai_group_t      *groups[MAX_GROUPS], *types[MAX_GROUPS];
    uint32_t          i, cnt, cnt_types, max_count, relocations = 0;
    uint32_t          free_total, free_not_me, active_me;
    boolean_t         do_sort;
    boolean_t         check_gc_thresholds = FALSE;
    uint32_t          free_lines = 0;

    if (p_user == NULL) {
        SX_LOG_ERR("Error - user(%p) NULL!\n",
                   p_user);

        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out_p_user_was_null;
    }

    /* If user requested Async GC we need to lock */
    if ((p_user->options & RELOC_ASYNC_GC_E) != 0) {
        err = __bai_thread_lock(p_user);
        if (err) {
            goto out;
        }
    }

    /* Create efficiency ordered list of groups with caches valid */
    err = __bai_order_groups(p_user, groups, &cnt);
    if (err) {
        goto out;
    }

    /* Groups is sorted now and does not need to be re-sorted */
    do_sort = FALSE;

    /*
     *   Scan the per-group summary data looking for the group with the
     * lowest total relocation cost and the type has at least as many
     * free lines as are found in that group.
     */
    p_cheap = NULL;
    cnt_types = 0;
    for (i = 0; i < p_user->template_count; i++) {
        p_group = p_user->lookup_size[i].group_min_cost;

        /* If there is no free space for groups of this type, skip */
        if (!p_group) {
            continue;
        }

        /* If the group does not have a template, it is a bug */
        if (p_group->p_template == NULL) {
            SX_LOG_ERR("Internal error - No template!\n");
            goto out;
        }

        /* If group does not have a relocation handler, skip */
        if (p_group->p_template->cb_relocate == NULL) {
            continue;
        }

        /* No reason to review types with at most 1 group active */
        if (p_user->lookup_size[i].total_groups < 2) {
            continue;
        }

        free_total = p_user->lookup_size[i].total_free_lines;
        free_not_me = free_total - p_group->free_lines;
        active_me = p_group->alloc_size - p_group->free_lines;

        /*
         *   If there is not space enough in the other groups of this type
         * to totally empty the cheapest group, then only proceed if the
         * efficiency of the cheapest group is below the client requested
         * target value.
         */
        if (free_not_me < active_me) {
            if (p_group->act_thresh > p_group->c_efficiency) {
                continue;
            }
        }

        /* Remember the cheapest group for each type that is candidate */
        types[cnt_types++] = p_group;

        /* Update the cheapest group */
        if ((p_cheap == NULL) || (p_cheap->c_cost_sum < p_group->c_cost_sum)) {
            p_cheap = p_group;
        }
    }

    /*
     *   Attempt to merge from the lowest cost group into other groups of
     * that type.
     */
    while (p_cheap) {
        /* Try to empty the cheapest group */
        err = __bai_merge_group(p_user, p_cheap, groups, cnt, &relocations);

        /* If there is more work to do, exit now and finish later */
        if (err == SX_UTILS_STATUS_PARTIALLY_COMPLETE) {
            max_count = p_cheap->r_count + p_cheap->r_count / 2;

            /* Next iteration we will do one more relocation */
            if (p_cheap->act_count < max_count) {
                p_cheap->act_count++;
            }

            check_gc_thresholds = TRUE;
            goto out;
        }

        /* If there was no space in this group, try the next */
        if (err == SX_UTILS_STATUS_NO_RESOURCES) {
            err = 0;
        }

        /* Any other error signals a problem we can't handle, pass it on */
        if (err) {
            goto out;
        }

        /* Any relocation leads to an allocation - therefore check the GC
         * thresholds before finishing.
         */
        check_gc_thresholds = TRUE;

        /* If we expended our total quota of moves, exit this round */
        if (relocations >= p_cheap->act_count) {
            err = SX_UTILS_STATUS_PARTIALLY_COMPLETE;
            goto out;
        }

        /* Once we move anything around, we will recreate the sorted list */
        do_sort = TRUE;

        /* Since we can't clean out this type, try the next one */
        p_next = NULL;
        for (i = 0; i < cnt_types; i++) {
            p_group = types[i];

            /* Ignore empty entries for groups we already tried */
            if (p_group == NULL) {
                continue;
            }

            /* Remove the one we just did */
            if (p_group == p_cheap) {
                types[i] = NULL;
                continue;
            }

            /* Don't bother with groups above client requested efficiency */
            if (p_group->act_thresh < p_group->c_efficiency) {
                types[i] = NULL;
                continue;
            }

            /* If this is the first one in the array, remember it */
            if (!p_next) {
                p_next = p_group;
            }
        }

        /* Get the next type to merge */
        p_cheap = p_next;
    }

    /* If we messed with the groups, redo the sort and cache update */
    if (do_sort) {
        err = __bai_order_groups(p_user, groups, &cnt);
        if (err) {
            goto out;
        }
    }

    /* Attempt to do single group relocation on groups below efficiency */
    for (i = 0; i < cnt; i++) {
        p_group = groups[i];

        /* Shouldn't happen, but avoid SEGV */
        if (!p_group) {
            continue;
        }

        /* Don't mess with groups that exceed user requested efficiency */
        if (p_group->act_thresh < p_group->c_efficiency) {
            continue;
        }

        /*
         * Hard limit
         *   If the contents of a group have not been modified by the user in
         * a long time, then stop checking that group for background
         * relocation.  This is a failsafe to make sure we never get into a
         * loop of moving blocks around.
         */
        if (p_group->reloc_cnt >= (uint32_t)(5 * p_group->r_count)) {
            if (p_group->reloc_cnt != UINT32_MAX) {
                SX_LOG_NTC("Stopping background relocation on group %u\n",
                           (uint32_t)(p_group - p_user->groups));
                p_group->reloc_cnt = UINT32_MAX;
            }

            continue;
        }
        p_group->reloc_cnt++;

        /*
         * Work on this group until we run out of relocation attempts this
         * this cycle or the efficiency improves enough that we don't need
         * to do anything more to this group.
         */
        while (p_group->act_thresh >= p_group->c_efficiency) {
            /* Try to move one block in this group to improve efficiency */
            err = __bai_improve_one(p_user, p_group, &relocations);
            if (err == SX_UTILS_STATUS_NO_RESOURCES) {
                /* If we can't do any more with this group, try next */
                err = SX_UTILS_STATUS_SUCCESS;
                break;
            }

            /* Any other errors get forwarded to caller */
            if (err) {
                goto out;
            }

            /* Any relocation leads to an allocation - therefore check the GC
             * thresholds before finishing.
             */
            check_gc_thresholds = TRUE;

            /* If we hit our relocation limit, done */
            if (relocations >= p_group->act_count) {
                err = SX_UTILS_STATUS_PARTIALLY_COMPLETE;
                goto out;
            }
        }

        /* If we hit our relocation limit, done */
        if (relocations >= p_group->act_count) {
            err = SX_UTILS_STATUS_PARTIALLY_COMPLETE;
            goto out;
        }
    }

    /* No group has more work to do */
    err = SX_UTILS_STATUS_SUCCESS;


out:
    /* If user requested Async GC we need to unlock */
    if ((p_user->options & RELOC_ASYNC_GC_E) != 0) {
        __bai_thread_unlock(p_user);
    }

    if ((!err) && (check_gc_thresholds)) {
        err = bai_user_free_lines_get(p_user, &free_lines);
        if (err) {
            SX_LOG_ERR("Failed to get number of free lines for user, err = [%s]\n",
                       SX_UTILS_STATUS_MSG(err));
        } else {
            err = gc_object_check_thresholds(p_user->gc_object_type,
                                             free_lines);
            if (err) {
                SX_LOG_ERR("Failed to check GC thresholds for object type %s, err = [%s]\n",
                           GC_OBJECT_TYPE_STR(p_user->gc_object_type),
                           SX_UTILS_STATUS_MSG(err));
            }
        }
    }

out_p_user_was_null:
    return err;
}

sx_utils_status_t bai_gc_context_pool_init(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;

    if (gc_pool_initialized) {
        err = SX_UTILS_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("GC context pool is already initialized\n");
        goto out;
    }

    M_GEN_UTILS_MEM_CLR(gc_context_pool);

    /* Initialize GC context pool. We allocate a minimum amount here and do a manual grow when needed.
     * Memory will be allocated based on the sum of the client's group sizes,
     * whenever a client attempts to get an entry from the pool and there are no
     * available entries.
     */
    cl_err = CL_QPOOL_INIT(&gc_context_pool, INITIAL_GC_POOL_SIZE, CL_POOL_UNLIMITED_MAX_SIZE, 0,
                           sizeof(ba_gc_context_t), NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Failed to initialize GC context pool, cl_err = [%s]\n",
                   CL_STATUS_MSG(cl_err));
        goto out;
    }

    gc_pool_initialized = TRUE;

out:
    return err;
}

sx_utils_status_t bai_gc_context_pool_deinit(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if (!gc_pool_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC context pool is not initialized\n");
        goto out;
    }

    CL_QPOOL_DESTROY(&gc_context_pool);
    gc_pool_initialized = FALSE;

out:
    return err;
}

sx_utils_status_t bai_gc_context_get(bai_user_t *p_user, ba_gc_context_t **p_gc_context)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;
    cl_pool_item_t   *p_pool_item = NULL;

    if (!gc_pool_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC context pool is not initialized\n");
        goto out;
    }

    if (!p_user) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_user is NULL\n");
        goto out;
    }

    if (!p_gc_context) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_gc_context is NULL\n");
        goto out;
    }

    /* Get GC context entry from pool */
    p_pool_item = cl_qpool_get(&gc_context_pool);
    if (!p_pool_item) {
        cl_err = cl_qpool_grow(&gc_context_pool,
                               p_user->p_phys_mem->phys_mem_size / 8);
        if (cl_err != CL_SUCCESS) {
            err = SX_UTILS_STATUS_ERROR;
            SX_LOG_ERR("Failed to grow GC context pool by %u entries, cl_err = [%s]\n",
                       p_user->p_phys_mem->phys_mem_size / 8,
                       CL_STATUS_MSG(cl_err));
            goto out;
        }

        p_pool_item = cl_qpool_get(&gc_context_pool);
        if (!p_pool_item) {
            err = SX_UTILS_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to get object from GC context pool\n");
            goto out;
        }
    }

    *p_gc_context = PARENT_STRUCT(p_pool_item, ba_gc_context_t, pool_item);
    M_GEN_UTILS_MEM_CLR((*p_gc_context)->data);

out:
    return err;
}

sx_utils_status_t bai_gc_context_put(ba_gc_context_t *p_gc_context)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if (!gc_pool_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("GC context pool is not initialized\n");
        goto out;
    }

    if (!p_gc_context) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_gc_context is NULL\n");
        goto out;
    }

    cl_qpool_put(&gc_context_pool, &p_gc_context->pool_item);

out:
    return err;
}

sx_utils_status_t bai_user_free_lines_get(bai_user_t *p_user, uint32_t *p_free_lines)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          free_lines = 0;
    uint32_t          i = 0;
    bai_group_t      *p_group = NULL;

    if (!p_user) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_user is NULL\n");
        goto out;
    }

    if (!p_free_lines) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_free_lines is NULL\n");
        goto out;
    }

    for (i = 0; i < p_user->group_cnt; i++) {
        p_group = &p_user->groups[i];
        free_lines += (p_group->type == GROUP_TYPE_FREE) ?
                      p_user->group_size :
                      p_group->free_lines;
    }

    *p_free_lines = free_lines;

out:
    return err;
}


sx_utils_status_t bai_relocate_context_pool_init(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;

    if (relocate_pool_initialized) {
        err = SX_UTILS_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Relocate context pool is already initialized\n");
        goto out;
    }

    M_GEN_UTILS_MEM_CLR(relocate_context_pool);

    /* Initialize Relocate context pool, but don't actually allocate any memory now.
     * Memory will be allocated based on the sum of the client's group sizes,
     * whenever a client attempts to get an entry from the pool and there are no
     * available entries.
     */
    cl_err = CL_QPOOL_INIT(&relocate_context_pool, 0, CL_POOL_UNLIMITED_MAX_SIZE, 0, sizeof(ba_relocate_context_t),
                           NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        err = SX_UTILS_STATUS_ERROR;
        SX_LOG_ERR("Failed to initialize Relocate context pool, cl_err = [%s]\n",
                   CL_STATUS_MSG(cl_err));
        goto out;
    }

    relocate_pool_initialized = TRUE;

out:
    return err;
}


sx_utils_status_t bai_relocate_context_pool_deinit(void)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if (!relocate_pool_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Relocate context pool is not initialized\n");
        goto out;
    }

    CL_QPOOL_DESTROY(&relocate_context_pool);
    relocate_pool_initialized = FALSE;

out:
    return err;
}


sx_utils_status_t bai_relocate_context_get(bai_user_t *p_user, ba_relocate_context_t **p_relocate_context)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;
    cl_pool_item_t   *p_pool_item = NULL;

    if (!relocate_pool_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Relocate context pool is not initialized\n");
        goto out;
    }

    if (!p_user) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_user is NULL\n");
        goto out;
    }

    if (!p_relocate_context) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_relocate_context is NULL\n");
        goto out;
    }

    /* Get Relocate context entry from pool */
    p_pool_item = cl_qpool_get(&relocate_context_pool);
    if (!p_pool_item) {
        cl_err = cl_qpool_grow(&relocate_context_pool,
                               p_user->p_phys_mem->phys_mem_size / 8);
        if (cl_err != CL_SUCCESS) {
            err = SX_UTILS_STATUS_ERROR;
            SX_LOG_ERR("Failed to grow Relocate context pool by %u entries, cl_err = [%s]\n",
                       p_user->p_phys_mem->phys_mem_size / 8,
                       CL_STATUS_MSG(cl_err));
            goto out;
        }

        p_pool_item = cl_qpool_get(&relocate_context_pool);
        if (!p_pool_item) {
            err = SX_UTILS_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to get object from Relocate context pool\n");
            goto out;
        }
    }

    *p_relocate_context = PARENT_STRUCT(p_pool_item, ba_relocate_context_t, pool_item);
    M_GEN_UTILS_MEM_CLR((*p_relocate_context)->ilid);
    M_GEN_UTILS_MEM_CLR((*p_relocate_context)->size);

out:
    return err;
}

sx_utils_status_t bai_relocate_context_put(ba_relocate_context_t *p_relocate_context)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    if (!relocate_pool_initialized) {
        err = SX_UTILS_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("Relocate context pool is not initialized\n");
        goto out;
    }

    if (!p_relocate_context) {
        err = SX_UTILS_STATUS_PARAM_NULL;
        SX_LOG_ERR("p_relocate_context is NULL\n");
        goto out;
    }

    cl_qpool_put(&relocate_context_pool, &p_relocate_context->pool_item);

out:
    return err;
}
