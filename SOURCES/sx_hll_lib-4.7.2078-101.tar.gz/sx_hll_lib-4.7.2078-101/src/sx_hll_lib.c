/*
 * Copyright (C) 2012-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <math.h>
#include <stdio.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_flow_counter.h>
#include <sx/sdk/sx_api_bulk_counter.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_lib_host_ifc.h>
#include <complib/sx_log.h>
#include <complib/cl_types.h>
#include <complib/cl_map.h>
#include <complib/cl_mem.h>
#include <complib/cl_math.h>
#include <complib/cl_dbg.h>
#include "sx/hll_lib/sx_hll_lib.h"

#undef  __MODULE__
#define __MODULE__ SX_HLL_LIB

#define SX_HLL_CHECK_FAIL(STATUS) (SX_HLL_STATUS_SUCCESS != (STATUS))

#define SX_HLL_CHECK_INITIALIZED(init_done)                  \
    do {                                                     \
        if (!(init_done)) {                                  \
            rc = SX_HLL_STATUS_NOT_INITIALIZED;              \
            SX_LOG_ERR("HLL library is not initialized.\n"); \
            goto out;                                        \
        }                                                    \
    } while (0)

#define SX_HLL_STATUS_CONV_SET(x) (sx_status2sx_hll_status_arr[SX_STATUS_ ## x] = SX_HLL_STATUS_ ## x)

#define SX_HLL_FLOW_COUNTER_NUM_MIN  (64)
#define SX_HLL_FLOW_COUNTER_NUM_MAX  (48 * 1024)
#define SX_HLL_FLOW_COUNTER_NUM_GROW (64)

#define SX_HLL_GET_TIMEOUT_SEC      (5)
#define SX_HLL_SELECT_INTERVAL_MSEC (100)


typedef struct sx_hll_lib_bin_group_entry {
    cl_pool_item_t         pool_item;
    cl_map_item_t          map_item;
    sx_hll_lib_bin_group_t bin_group;
} sx_hll_lib_bin_group_entry_t;

typedef struct sx_hll_lib_profile_attr {
    cl_qmap_t                       bin_group_map;
    sx_flow_estimator_profile_key_t profile_key;
    boolean_t                       allocated;
    uint16_t                        bin_group_size;
    sx_hll_lib_bin_group_params_t   bin_group_param;
} sx_hll_lib_profile_attr_t;

typedef struct sx_hll_lib_db {
    cl_qpool_t                bin_group_pool;
    sx_hll_lib_profile_attr_t profiles[SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM];
    sx_fd_t                   sx_fd;
} sx_hll_lib_db_t;

/************************************************
 *  Global variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

static boolean_t       is_initialized_s = FALSE;
static sx_api_handle_t api_handle_s;
static sx_hll_lib_db_t hll_db_s;
static cl_spinlock_t   hll_api_spinlock_s = {
    .mutex = PTHREAD_MUTEX_INITIALIZER,
    .state = CL_INITIALIZED
};

static __attribute__((__used__)) sx_hll_status_t sx_status2sx_hll_status_arr[SX_STATUS_MAX + 1];

/************************************************
 *  Local variables
 ***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/

static inline sx_hll_status_t sx_status_to_hll_status(sx_status_t sx_status)
{
    return sx_status2sx_hll_status_arr[sx_status];
}

static void __sx_hll_lib_init_status_conv(void)
{
    memset(sx_status2sx_hll_status_arr, SX_HLL_STATUS_ERROR, sizeof(sx_status2sx_hll_status_arr));

    SX_HLL_STATUS_CONV_SET(SUCCESS);
    SX_HLL_STATUS_CONV_SET(PARAM_ERROR);
    SX_HLL_STATUS_CONV_SET(PARAM_NULL);
    SX_HLL_STATUS_CONV_SET(ENTRY_NOT_FOUND);
    SX_HLL_STATUS_CONV_SET(ENTRY_ALREADY_EXISTS);
    SX_HLL_STATUS_CONV_SET(ALREADY_INITIALIZED);
    SX_HLL_STATUS_CONV_SET(NO_RESOURCES);
    SX_HLL_STATUS_CONV_SET(NO_MEMORY);
    SX_HLL_STATUS_CONV_SET(UNSUPPORTED);
    SX_HLL_STATUS_CONV_SET(TIMEOUT);
    SX_HLL_STATUS_CONV_SET(RESOURCE_IN_USE);

    sx_status2sx_hll_status_arr[SX_STATUS_DB_NOT_INITIALIZED] = SX_HLL_STATUS_NOT_INITIALIZED;
    sx_status2sx_hll_status_arr[SX_STATUS_MODULE_UNINITIALIZED] = SX_HLL_STATUS_NOT_INITIALIZED;

    return;
}

static sx_hll_status_t __sx_hll_lib_calc_bin_group_size(const uint16_t error_rate_percent, uint16_t *bin_group_size)
{
    sx_hll_status_t rc = SX_HLL_STATUS_SUCCESS;

    if (error_rate_percent >= 37) {
        SX_LOG_ERR("error_rate_percent(%d) is too big.\n", error_rate_percent);
        rc = SX_HLL_STATUS_PARAM_ERROR;
    } else if ((error_rate_percent >= 26) && (error_rate_percent < 37)) {
        *bin_group_size = 16;
    } else if ((error_rate_percent >= 18) && (error_rate_percent < 26)) {
        *bin_group_size = 32;
    } else if ((error_rate_percent >= 13) && (error_rate_percent < 18)) {
        *bin_group_size = 64;
    } else if ((error_rate_percent >= 9) && (error_rate_percent < 13)) {
        *bin_group_size = 128;
    } else if ((error_rate_percent >= 7) && (error_rate_percent < 9)) {
        *bin_group_size = 256;
    } else if ((error_rate_percent >= 5) && (error_rate_percent < 7)) {
        *bin_group_size = 512;
    } else {
        SX_LOG_ERR("error_rate_percent(%d) is too small.\n", error_rate_percent);
        rc = SX_HLL_STATUS_PARAM_ERROR;
    }

    return rc;
}

static sx_hll_status_t __sx_hll_lib_bin_group_create(const sx_hll_lib_bin_group_params_t *params_p,
                                                     sx_hll_lib_bin_group_t              *bin_group_p)
{
    sx_hll_status_t                 rc = SX_HLL_STATUS_SUCCESS;
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    uint16_t                        bin_group_size = 0;
    uint8_t                         i = 0;
    uint8_t                         profile_id = 0;
    sx_flow_estimator_profile_key_t profile_key;
    sx_flow_estimator_profile_key_t profile_key_list[SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM];
    uint32_t                        profile_cnt = SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM;
    boolean_t                       profile_allocated_in_sdk[SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM];
    boolean_t                       profile_created = FALSE;
    sx_flow_estimator_profile_cfg_t profile_cfg;
    sx_flow_counter_bulk_attr_t     bulk_attr;
    sx_flow_counter_bulk_data_t     bulk_data;
    sx_hll_lib_bin_group_entry_t   *bin_group_entry_p = NULL;
    cl_pool_item_t                 *pool_item_p = NULL;

    memset(&profile_key, 0, sizeof(profile_key));
    memset(profile_key_list, 0, sizeof(profile_key_list));
    memset(&profile_cfg, 0, sizeof(profile_cfg));
    memset(profile_allocated_in_sdk, 0, sizeof(profile_allocated_in_sdk));

    rc = __sx_hll_lib_calc_bin_group_size(params_p->error_rate_percent, &bin_group_size);
    if (SX_HLL_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get bin group size by error_rate_percent(%d).\n", params_p->error_rate_percent);
        goto out;
    }

    for (profile_id = 0; profile_id < SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM; profile_id++) {
        if ((hll_db_s.profiles[profile_id].allocated) &&
            (bin_group_size == hll_db_s.profiles[profile_id].bin_group_size)) {
            break;
        }
    }

    if (profile_id > SX_FLOW_ESTIMATOR_PROFILE_ID_MAX) {
        sx_status = sx_api_flow_estimator_profile_iter_get(api_handle_s,
                                                           SX_ACCESS_CMD_GET_FIRST,
                                                           profile_key,
                                                           NULL,
                                                           profile_key_list,
                                                           &profile_cnt);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get flow estimator profile list.\n");
            rc = sx_status_to_hll_status(sx_status);
            goto out;
        }
        for (i = 0; i < profile_cnt; i++) {
            profile_allocated_in_sdk[profile_key_list[i].profile_id] = TRUE;
        }

        for (profile_id = 0; profile_id < SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM; profile_id++) {
            if (!profile_allocated_in_sdk[profile_id]) {
                profile_cfg.bin_group_size = bin_group_size;
                profile_cfg.hash_params_p = NULL;
                profile_key.profile_id = profile_id;

                sx_status = sx_api_flow_estimator_profile_set(api_handle_s,
                                                              SX_ACCESS_CMD_CREATE,
                                                              profile_key,
                                                              &profile_cfg);
                if (SX_CHECK_FAIL(sx_status)) {
                    SX_LOG_ERR("Failed to create flow estimator profile (%d).\n", profile_id);
                    rc = sx_status_to_hll_status(sx_status);
                    goto out;
                }

                profile_created = TRUE;

                hll_db_s.profiles[profile_id].allocated = TRUE;
                hll_db_s.profiles[profile_id].profile_key = profile_key;
                hll_db_s.profiles[profile_id].bin_group_size = bin_group_size;
                hll_db_s.profiles[profile_id].bin_group_param = *params_p;

                break;
            }
        }

        if (profile_id > SX_FLOW_ESTIMATOR_PROFILE_ID_MAX) {
            SX_LOG_ERR("No profile resource in SDK.\n");
            rc = SX_HLL_STATUS_NO_RESOURCES;
            goto out;
        }
    }

    memset(&bulk_attr, 0, sizeof(bulk_attr));
    memset(&bulk_data, 0, sizeof(bulk_data));

    bulk_attr.counter_num = bin_group_size / FLOW_ESTIMATOR_BINS_PER_FLOW_COUNTER;
    bulk_attr.counter_type = SX_FLOW_COUNTER_TYPE_ESTIMATOR;

    sx_status = sx_api_flow_counter_bulk_set(api_handle_s, SX_ACCESS_CMD_CREATE, bulk_attr, &bulk_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to create flow counter.\n");
        rc = sx_status_to_hll_status(sx_status);
        goto rollback_profile;
    }

    if (cl_qmap_contains(&hll_db_s.profiles[profile_id].bin_group_map, (uint64_t)bulk_data.base_counter_id)) {
        SX_LOG_ERR("Flow counter of base counter id (%d) already existed.\n", bulk_data.base_counter_id);
        rc = SX_HLL_STATUS_ENTRY_ALREADY_EXISTS;
        goto rollback_flow_counter;
    }

    bin_group_p->profile_key = hll_db_s.profiles[profile_id].profile_key;
    bin_group_p->counters.flow_cntr_bulk_attr = bulk_attr;
    bin_group_p->counters.flow_cntr_bulk_data = bulk_data;
    bin_group_p->counters.flow_estimator_bins_num = bin_group_size;

    pool_item_p = cl_qpool_get(&hll_db_s.bin_group_pool);
    if (pool_item_p == NULL) {
        SX_LOG_ERR("Failed to get pool item.\n");
        rc = SX_HLL_STATUS_NO_RESOURCES;
        goto rollback_flow_counter;
    }

    bin_group_entry_p = PARENT_STRUCT(pool_item_p, sx_hll_lib_bin_group_entry_t, pool_item);
    bin_group_entry_p->bin_group = *bin_group_p;

    cl_qmap_insert(&hll_db_s.profiles[profile_id].bin_group_map,
                   (uint64_t)bulk_data.base_counter_id,
                   &bin_group_entry_p->map_item);

    goto out;

rollback_flow_counter:
    sx_status = sx_api_flow_counter_bulk_set(api_handle_s, SX_ACCESS_CMD_DESTROY, bulk_attr, &bulk_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to destroy flow counter in rollback.\n");
    }

rollback_profile:
    if (profile_created) {
        sx_status = sx_api_flow_estimator_profile_set(api_handle_s,
                                                      SX_ACCESS_CMD_DESTROY,
                                                      profile_key,
                                                      NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to destroy flow estimator profile (%d) in rollback.\n", profile_id);
        }
    }

out:
    return rc;
}

static sx_hll_status_t __sx_hll_lib_bin_group_validate(const sx_hll_lib_bin_group_t *bin_group_p)
{
    sx_hll_status_t                rc = SX_HLL_STATUS_SUCCESS;
    sx_flow_estimator_profile_id_e profile_id = bin_group_p->profile_key.profile_id;

    if (!hll_db_s.profiles[profile_id].allocated) {
        SX_LOG_ERR("Profile (%d) is not allocated.\n", profile_id);
        rc = SX_HLL_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    if (!cl_qmap_contains(&hll_db_s.profiles[profile_id].bin_group_map,
                          (uint64_t)bin_group_p->counters.flow_cntr_bulk_data.base_counter_id)) {
        SX_LOG_ERR("Flow counter of base counter id (%d) is not found for profile (%d).\n",
                   bin_group_p->counters.flow_cntr_bulk_data.base_counter_id, profile_id);
        rc = SX_HLL_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

out:
    return rc;
}

static sx_hll_status_t __sx_hll_lib_bin_group_destroy(sx_hll_lib_bin_group_t *bin_group_p)
{
    sx_hll_status_t                rc = SX_HLL_STATUS_SUCCESS;
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    sx_flow_estimator_profile_id_e profile_id = bin_group_p->profile_key.profile_id;
    cl_map_item_t                 *map_item_p = NULL;
    cl_pool_item_t                *pool_item_p = NULL;
    sx_hll_lib_bin_group_entry_t  *bin_group_entry_p = NULL;

    rc = __sx_hll_lib_bin_group_validate(bin_group_p);
    if (SX_HLL_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in validation of bin group of profile (%d) and base counter id (%d).\n",
                   profile_id, bin_group_p->counters.flow_cntr_bulk_data.base_counter_id);
        goto out;
    }

    sx_status = sx_api_flow_counter_bulk_set(api_handle_s,
                                             SX_ACCESS_CMD_DESTROY,
                                             bin_group_p->counters.flow_cntr_bulk_attr,
                                             &bin_group_p->counters.flow_cntr_bulk_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to destroy flow counter of base counter id (%d).\n",
                   bin_group_p->counters.flow_cntr_bulk_data.base_counter_id);
        rc = sx_status_to_hll_status(sx_status);
        goto out;
    }

    map_item_p = cl_qmap_remove(&hll_db_s.profiles[profile_id].bin_group_map,
                                (uint64_t)bin_group_p->counters.flow_cntr_bulk_data.base_counter_id);

    bin_group_entry_p = PARENT_STRUCT(map_item_p, sx_hll_lib_bin_group_entry_t, map_item);

    cl_qpool_put(&hll_db_s.bin_group_pool, &bin_group_entry_p->pool_item);

    if (cl_is_qmap_empty(&hll_db_s.profiles[profile_id].bin_group_map)) {
        sx_status = sx_api_flow_estimator_profile_set(api_handle_s, SX_ACCESS_CMD_DESTROY,
                                                      hll_db_s.profiles[profile_id].profile_key, NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to destroy flow estimator profile for id (%d).\n", profile_id);
            rc = sx_status_to_hll_status(sx_status);
            goto rollback_flow_counter;
        }
        hll_db_s.profiles[profile_id].allocated = FALSE;
    }

    goto out;

rollback_flow_counter:
    sx_status = sx_api_flow_counter_bulk_set(api_handle_s,
                                             SX_ACCESS_CMD_CREATE,
                                             bin_group_p->counters.flow_cntr_bulk_attr,
                                             &bin_group_p->counters.flow_cntr_bulk_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to create flow counter of base counter id (%d) during rollback.\n",
                   bin_group_p->counters.flow_cntr_bulk_data.base_counter_id);
    }

    pool_item_p = cl_qpool_get(&hll_db_s.bin_group_pool);
    if (pool_item_p == NULL) {
        SX_LOG_ERR("Failed to get pool item during rollback.\n");
        goto out;
    }

    bin_group_entry_p = PARENT_STRUCT(pool_item_p, sx_hll_lib_bin_group_entry_t, pool_item);
    bin_group_entry_p->bin_group = *bin_group_p;

    cl_qmap_insert(&hll_db_s.profiles[profile_id].bin_group_map,
                   (uint64_t)bin_group_p->counters.flow_cntr_bulk_data.base_counter_id,
                   &bin_group_entry_p->map_item);

out:
    return rc;
}

sx_hll_status_t sx_hll_lib_bin_group_set(const sx_hll_access_cmd_t            cmd,
                                         const sx_hll_lib_bin_group_params_t *params_p,
                                         sx_hll_lib_bin_group_t              *bin_group_p)
{
    sx_hll_status_t rc = SX_HLL_STATUS_SUCCESS;

    cl_spinlock_acquire(&hll_api_spinlock_s);

    SX_HLL_CHECK_INITIALIZED(is_initialized_s);

    if (bin_group_p == NULL) {
        SX_LOG_ERR("Parameter bin_group_p is NULL.\n");
        rc = SX_HLL_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_HLL_ACCESS_CMD_CREATE_E:
        if (params_p == NULL) {
            SX_LOG_ERR("Parameter params_p is NULL when create bin group.\n");
            rc = SX_HLL_STATUS_PARAM_NULL;
            goto out;
        }
        rc = __sx_hll_lib_bin_group_create(params_p, bin_group_p);
        if (SX_HLL_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to create bin group.\n");
            goto out;
        }
        break;

    case SX_HLL_ACCESS_CMD_DESTROY_E:
        rc = __sx_hll_lib_bin_group_destroy(bin_group_p);
        if (SX_HLL_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to destroy bin group.\n");
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command (%d)\n", cmd);
        rc = SX_HLL_STATUS_UNSUPPORTED;
        break;
    }

out:
    cl_spinlock_release(&hll_api_spinlock_s);
    return rc;
}

sx_hll_status_t sx_hll_lib_bin_group_get(const sx_hll_access_cmd_t         cmd,
                                         const sx_hll_lib_bin_group_t     *bin_group_p,
                                         sx_hll_lib_flow_estimator_bins_t *bins_values_p)
{
    sx_hll_status_t                rc = SX_HLL_STATUS_SUCCESS;
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    sx_access_cmd_t                sx_cmd = SX_ACCESS_CMD_NONE;
    sx_receive_info_t              recv_info;
    uint8_t                        buff[1024] = { 0 };
    uint32_t                       buff_size = sizeof(buff);
    sx_bulk_cntr_data_t            cntr_data;
    sx_bulk_cntr_read_key_t        read_key;
    fd_set                         r_fds;
    struct timeval                 tv;
    uint32_t                       count_down = SX_HLL_GET_TIMEOUT_SEC * 1000 / SX_HLL_SELECT_INTERVAL_MSEC;
    uint32_t                       i = 0;
    int                            err = 0;
    sx_bulk_cntr_buffer_t          bulk_cntr_buffer;
    sx_bulk_cntr_buffer_key_t      bulk_cntr_buffer_key;
    sx_flow_estimator_profile_id_e profile_id;

    cl_spinlock_acquire(&hll_api_spinlock_s);

    SX_HLL_CHECK_INITIALIZED(is_initialized_s);

    if (bin_group_p == NULL) {
        SX_LOG_ERR("Parameter bin_group_p is NULL\n");
        rc = SX_HLL_STATUS_PARAM_NULL;
        goto out;
    }
    profile_id = bin_group_p->profile_key.profile_id;

    switch (cmd) {
    case SX_HLL_ACCESS_CMD_READ_E:
        sx_cmd = SX_ACCESS_CMD_READ;
        break;

    case SX_HLL_ACCESS_CMD_READ_CLEAR_E:
        sx_cmd = SX_ACCESS_CMD_READ_CLEAR;
        break;

    default:
        SX_LOG_ERR("Unsupported command (%d)\n", cmd);
        rc = SX_HLL_STATUS_UNSUPPORTED;
        goto out;
        break;
    }

    rc = __sx_hll_lib_bin_group_validate(bin_group_p);
    if (SX_HLL_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in validation of bin group of profile (%d) and base counter id (%d)\n",
                   profile_id, bin_group_p->counters.flow_cntr_bulk_data.base_counter_id);
        goto out;
    }

    bulk_cntr_buffer_key.type = SX_BULK_CNTR_KEY_TYPE_FLOW_ESTIMATOR_E;
    bulk_cntr_buffer_key.key.flow_estimator_key.base_counter_id =
        bin_group_p->counters.flow_cntr_bulk_data.base_counter_id;
    bulk_cntr_buffer_key.key.flow_estimator_key.num_of_counters =
        bin_group_p->counters.flow_cntr_bulk_attr.counter_num;

    sx_status = sx_api_bulk_counter_buffer_set(api_handle_s,
                                               SX_ACCESS_CMD_CREATE,
                                               &bulk_cntr_buffer_key,
                                               &bulk_cntr_buffer);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to create bulk counter buffer: base counter id (%d)\n",
                   bin_group_p->counters.flow_cntr_bulk_data.base_counter_id);
        rc = sx_status_to_hll_status(sx_status);
        goto out;
    }

    sx_status = sx_api_bulk_counter_transaction_set(api_handle_s, sx_cmd, &bulk_cntr_buffer);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set transaction: base counter id (%d)\n",
                   bin_group_p->counters.flow_cntr_bulk_data.base_counter_id);
        rc = sx_status_to_hll_status(sx_status);
        goto out;
    }

    while (count_down) {
        FD_ZERO(&r_fds);
        FD_SET(hll_db_s.sx_fd.fd, &r_fds);
        tv.tv_sec = 0;
        tv.tv_usec = SX_HLL_SELECT_INTERVAL_MSEC * 1000;

        err = select(hll_db_s.sx_fd.fd + 1, &r_fds, NULL, NULL, &tv);
        if (err < 0) {
            SX_LOG_ERR("Failed in select\n");
            rc = SX_HLL_STATUS_ERROR;
            goto out;
        }

        if (err == 0) {
            count_down--;
            continue;
        }
        sx_status = sx_lib_host_ifc_recv(&hll_db_s.sx_fd, buff, &buff_size, &recv_info);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to receive bulk done event\n");
            rc = sx_status_to_hll_status(sx_status);
            goto out;
        }

        if ((recv_info.trap_id == SX_TRAP_ID_BULK_COUNTER_DONE_EVENT) &&
            (recv_info.event_info.bulk_cntr_done_info.buffer_id == bulk_cntr_buffer.buffer_id)) {
            break;
        }
    }

    if (count_down == 0) {
        SX_LOG_ERR("Timeout to read bulk counter: base counter id (%d)\n",
                   bin_group_p->counters.flow_cntr_bulk_data.base_counter_id);
        rc = SX_HLL_STATUS_TIMEOUT;
        goto out;
    }

    for (i = 0; i < bin_group_p->counters.flow_cntr_bulk_attr.counter_num; i++) {
        memset(&read_key, 0, sizeof(read_key));
        read_key.type = SX_BULK_CNTR_KEY_TYPE_FLOW_ESTIMATOR_E;
        read_key.key.flow_estimator_key.cntr_id = bin_group_p->counters.flow_cntr_bulk_data.base_counter_id + i;
        sx_status = sx_api_bulk_counter_transaction_get(api_handle_s,
                                                        &read_key,
                                                        &bulk_cntr_buffer,
                                                        &cntr_data);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get transaction: counter id (%d)\n", read_key.key.flow_estimator_key.cntr_id);
            rc = sx_status_to_hll_status(sx_status);
            goto out;
        }
        memcpy(bins_values_p->flow_estimator_counter_set_p + i,
               cntr_data.data.flow_estimator_data.flow_counter_estimator_p,
               sizeof(sx_flow_estimator_counter_set_t));
    }
    bins_values_p->flow_estimator_counter_set_num = bin_group_p->counters.flow_cntr_bulk_attr.counter_num;

    sx_status = sx_api_bulk_counter_buffer_set(api_handle_s, SX_ACCESS_CMD_DESTROY, NULL, &bulk_cntr_buffer);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to destroy bulk counter buffer: base counter id (%d)\n",
                   bin_group_p->counters.flow_cntr_bulk_data.base_counter_id);
        rc = sx_status_to_hll_status(sx_status);
        goto out;
    }

out:
    cl_spinlock_release(&hll_api_spinlock_s);
    return rc;
}

sx_hll_status_t __sx_hll_lib_get_bin_group_size_coeffient(uint32_t bin_group_size, long double *coeffient)
{
    sx_hll_status_t rc = SX_HLL_STATUS_SUCCESS;

    if (bin_group_size == 512) {
        *coeffient = 0.719783;
    } else if (bin_group_size == 256) {
        *coeffient = 0.718273;
    } else if (bin_group_size == 128) {
        *coeffient = 0.71527;
    } else if (bin_group_size == 64) {
        *coeffient = 0.709;
    } else if (bin_group_size == 32) {
        *coeffient = 0.697;
    } else if (bin_group_size == 16) {
        *coeffient = 0.673;
    } else {
        SX_LOG_ERR("bin_group_size (%d) is not valid.\n", bin_group_size);
        rc = SX_HLL_STATUS_PARAM_ERROR;
    }

    return rc;
}

sx_hll_status_t sx_hll_lib_cardinality_get(const sx_hll_lib_flow_estimator_bins_t  *flow_estimator_bins_p,
                                           sx_hll_lib_flow_estimator_cardinality_t *flow_cardinality_p)
{
    sx_hll_status_t         rc = SX_HLL_STATUS_SUCCESS;
    long double             sum = 0;
    sx_flow_estimator_bin_t bin = 0;
    uint32_t                m = 0;
    uint32_t                n = 0;
    uint32_t                j = 0;
    long double             coeffient = 0;

    cl_spinlock_acquire(&hll_api_spinlock_s);

    SX_HLL_CHECK_INITIALIZED(is_initialized_s);

    if ((flow_estimator_bins_p == NULL) || (flow_cardinality_p == NULL)) {
        SX_LOG_ERR("Parameter is NULL.\n");
        rc = SX_HLL_STATUS_PARAM_NULL;
        goto out;
    }

    n = flow_estimator_bins_p->flow_estimator_counter_set_num * FLOW_ESTIMATOR_BINS_PER_FLOW_COUNTER;
    rc = __sx_hll_lib_get_bin_group_size_coeffient(n, &coeffient);
    if (SX_HLL_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get coefficient value for bin group size (%d).\n", n);
        goto out;
    }

    m = n;
    for (j = 0; j < n; j++) {
        bin = flow_estimator_bins_p->flow_estimator_counter_set_p[j / FLOW_ESTIMATOR_BINS_PER_FLOW_COUNTER].
              flow_estimator_bins[j % FLOW_ESTIMATOR_BINS_PER_FLOW_COUNTER];
        /* bin value is used not as number of leading "0", but the position of first "1".  */
        bin++;
        sum += (1.0 / (long double)((uint64_t)1 << bin));
    }

    flow_cardinality_p->flow_cardinality = (uint64_t)ceil(coeffient * m * m / sum);

out:
    cl_spinlock_release(&hll_api_spinlock_s);
    return rc;
}

sx_hll_status_t sx_hll_lib_init(const sx_hll_lib_init_params_t init_params)
{
    sx_hll_status_t   rc = SX_HLL_STATUS_SUCCESS;
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    cl_status_t       cl_rc = CL_SUCCESS;
    uint8_t           i = 0;
    sx_user_channel_t uc;

    cl_spinlock_acquire(&hll_api_spinlock_s);

    if (is_initialized_s == TRUE) {
        rc = SX_HLL_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("HLL lib is already initialized\n");
        goto out;
    }

    __sx_hll_lib_init_status_conv();

    if (sx_log_init(TRUE, NULL, init_params.logging_cb) != 0) {
        rc = SX_HLL_STATUS_ERROR;
        fprintf(stderr, "Log initialization failed.\n");
        goto out;
    }

    sx_status = sx_api_open(init_params.logging_cb, &api_handle_s);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to open SDK handle, err: %s\n", sx_status_str(sx_status));
        rc = sx_status_to_hll_status(sx_status);
        goto out;
    }

    memset(&hll_db_s, 0, sizeof(hll_db_s));

    cl_rc = CL_QPOOL_INIT(&hll_db_s.bin_group_pool,
                          SX_HLL_FLOW_COUNTER_NUM_MIN, SX_HLL_FLOW_COUNTER_NUM_MAX, SX_HLL_FLOW_COUNTER_NUM_GROW,
                          sizeof(sx_hll_lib_bin_group_entry_t), NULL, NULL, NULL);
    if (cl_rc != CL_SUCCESS) {
        SX_LOG_ERR("Failed to initialize the bin group pool.\n");
        rc = SX_HLL_STATUS_NO_RESOURCES;
        goto out;
    }

    for (i = 0; i < SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM; i++) {
        cl_qmap_init(&hll_db_s.profiles[i].bin_group_map);
    }

    sx_status = sx_api_host_ifc_open(api_handle_s, &hll_db_s.sx_fd);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to open host interface file descriptor, err: %s\n", sx_status_str(sx_status));
        rc = sx_status_to_hll_status(sx_status);
        goto out;
    }

    memset(&uc, 0, sizeof(uc));

    uc.type = SX_USER_CHANNEL_TYPE_FD;
    memcpy(&uc.channel.fd, &hll_db_s.sx_fd, sizeof(uc.channel.fd));
    sx_status = sx_api_host_ifc_trap_id_register_set(api_handle_s,
                                                     SX_ACCESS_CMD_REGISTER,
                                                     0,
                                                     SX_TRAP_ID_BULK_COUNTER_DONE_EVENT,
                                                     &uc);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to register SX_TRAP_ID_BULK_COUNTER_DONE_EVENT, err: %s\n", sx_status_str(sx_status));
        rc = sx_status_to_hll_status(sx_status);
        goto out;
    }

    is_initialized_s = TRUE;

out:
    cl_spinlock_release(&hll_api_spinlock_s);
    return rc;
}

sx_hll_status_t sx_hll_lib_deinit(void)
{
    sx_hll_status_t               rc = SX_HLL_STATUS_SUCCESS;
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    uint8_t                       profile_id = 0;
    cl_map_item_t                *map_item_p = NULL;
    sx_hll_lib_bin_group_entry_t *bin_group_entry_p = NULL;

    cl_spinlock_acquire(&hll_api_spinlock_s);

    SX_HLL_CHECK_INITIALIZED(is_initialized_s);

    for (profile_id = 0; profile_id < SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM; profile_id++) {
        if (hll_db_s.profiles[profile_id].allocated) {
            map_item_p = cl_qmap_head(&hll_db_s.profiles[profile_id].bin_group_map);

            while (map_item_p != cl_qmap_end(&hll_db_s.profiles[profile_id].bin_group_map)) {
                bin_group_entry_p = PARENT_STRUCT(map_item_p, sx_hll_lib_bin_group_entry_t, map_item);
                map_item_p = cl_qmap_next(map_item_p);
                rc = __sx_hll_lib_bin_group_destroy(&bin_group_entry_p->bin_group);
                if (SX_HLL_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to destroy bin group with base counter id (%d) for profile (%d)\n",
                               bin_group_entry_p->bin_group.counters.flow_cntr_bulk_data.base_counter_id, profile_id);
                    rc = sx_status_to_hll_status(sx_status);
                    goto out;
                }
            }
        }
    }

    CL_QPOOL_DESTROY(&hll_db_s.bin_group_pool);

    sx_status = sx_api_host_ifc_close(api_handle_s, &hll_db_s.sx_fd);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to close host interface file descriptor, err: %s\n", sx_status_str(sx_status));
        rc = sx_status_to_hll_status(sx_status);
        goto out;
    }

    sx_status = sx_api_close(&api_handle_s);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to close the SDK handle, err: %s\n", sx_status_str(sx_status));
        rc = sx_status_to_hll_status(sx_status);
        goto out;
    }

    sx_log_close();

    is_initialized_s = FALSE;

out:
    cl_spinlock_release(&hll_api_spinlock_s);
    return rc;
}
