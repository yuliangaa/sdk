/*
 * Copyright (C) 2008-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_HLL_LIB_TYPES_H__
#define __SX_HLL_LIB_TYPES_H__

#include <sx/sdk/sx_flow_counter.h>
#include <sx/sdk/sx_status.h>
#include <complib/sx_log.h>

typedef enum sx_hll_status {
    SX_HLL_STATUS_SUCCESS,
    SX_HLL_STATUS_ERROR,
    SX_HLL_STATUS_PARAM_ERROR,
    SX_HLL_STATUS_PARAM_NULL,
    SX_HLL_STATUS_ENTRY_NOT_FOUND,
    SX_HLL_STATUS_ENTRY_ALREADY_EXISTS,
    SX_HLL_STATUS_NOT_INITIALIZED,
    SX_HLL_STATUS_ALREADY_INITIALIZED,
    SX_HLL_STATUS_NO_RESOURCES,
    SX_HLL_STATUS_NO_MEMORY,
    SX_HLL_STATUS_TIMEOUT,
    SX_HLL_STATUS_UNSUPPORTED,
    SX_HLL_STATUS_RESOURCE_IN_USE,
} sx_hll_status_t;

typedef enum sx_hll_access_cmd {
    SX_HLL_ACCESS_CMD_CREATE_E,
    SX_HLL_ACCESS_CMD_READ_E,
    SX_HLL_ACCESS_CMD_READ_CLEAR_E,
    SX_HLL_ACCESS_CMD_DESTROY_E,
} sx_hll_access_cmd_t;


typedef struct sx_hll_lib_flow_estimator_bins {
    sx_flow_estimator_counter_set_t *flow_estimator_counter_set_p;
    uint32_t                         flow_estimator_counter_set_num;
} sx_hll_lib_flow_estimator_bins_t;

typedef struct sx_hll_lib_flow_estimator_cardinality {
    uint64_t flow_cardinality;
} sx_hll_lib_flow_estimator_cardinality_t;

typedef struct sx_hll_lib_bin_group_params {
    uint16_t error_rate_percent;        /**< Tolerated error rate for cardinality calculation, supported range 5~36 [unit:%].*/
} sx_hll_lib_bin_group_params_t;

typedef struct {
    sx_flow_estimator_profile_key_t profile_key;
    sx_flow_estimator_bin_group_t   counters;
} sx_hll_lib_bin_group_t;

typedef struct sx_hll_lib_init_params {
    sx_log_cb_t logging_cb;
} sx_hll_lib_init_params_t;

#endif /* ifndef __SX_HLL_LIB_TYPES_H__ */
