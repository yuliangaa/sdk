/*
 * Copyright (C) 2008-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_HLL_LIB_H__
#define __SX_HLL_LIB_H__

#include "sx_hll_lib_types.h"

/**
 * This API init sx hll library.
 *
 * @param[in] init_params          - init parameters
 * @return SX_HLL_STATUS_SUCCESS if operation completes successfully
 * @return SX_HLL_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_HLL_STATUS_ERROR for a general error
 */
sx_hll_status_t sx_hll_lib_init(const sx_hll_lib_init_params_t init_params);

/**
 * This API deinit the sx hll library. It will free all existing profiles and bulk counters created via sx_hll_lib_bin_group_set() in
 * the process since sx_hll_lib_init() was called. It requires all those profile ids and bulk counters are not referred by ACL actions.
 * Otherwise, it fails with "SX_HLL_RESOURCE_IN_USE".
 *
 * @return SX_HLL_STATUS_STATUS_SUCCESS if operation completes successfully
 * @return SX_HLL_STATUS_RESOURCE_IN_USE if some profiles or flow estimators are still used in ACL actions
 * @return SX_HLL_STATUS_ERROR for a general error
 */
sx_hll_status_t sx_hll_lib_deinit(void);

/*
 * This API CREATE/DESTROY a bin group pair (a pair of profile and a flow estimator counter base counter id).
 *
 * On CREATE, it would find an existing profile or allocate a new one with bin_group_size matching the input error_percent,
 * then allocate a series of flow estimator counters, whose size is determined by the profile's bin_group_size. Then it
 * return the pair of the profile and flow estimator base counter id.
 *   Notice: The profile and flow estimator counters are maintained by HLL and should not be set or destroyed via SX APIs. Otherwise, HLL
 *   cannot work normally. One exception is sx_api_flow_estimator_profile_set(), which should only change hash params and remain
 *   bin_group_size unchanged, i.e., setting the same bin_group_size as the returned value (flow_estimator_bins_num) in
 *   sx_hll_lib_bin_group_set().
 *
 * On DESTROY, it would free a series of flow estimator counters beginning from the base counter id and destroy the profile if it is not used.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * @param [in] cmd                 - CREATE/DESTROY
 * @param [in] params_p            - Specify user's expected error rate for cardinality.
 * @param [out] bin_group_p        - a pair of profile and a flow estimator counter base counter id.
 *
 * @return SX_HLL_STATUS_SUCCESS if operation completes successfully
 * @return SX_HLL_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_HLL_STATUS_PARAM_NULL  if an input parameter is NULL
 * @return SX_HLL_STATUS_NO_RESOURCES if no flow counter or profile is available to create
 * @return SX_HLL_STATUS_UNSUPPORTED if the operation or parameters are not supported
 * @return SX_HLL_INVALID_HANDLE if called Invalid Handle
 * @return SX_HLL_ERROR general error
 * @return SX_HLL_ENTRY_ALREADY_EXISTS  fails because the profile key has been already created.
 * @return SX_HLL_RESOURCE_IN_USE   fails because of the profile being bound to some ACL actions. Details see SET/DESTROY descriptions.
 */
sx_hll_status_t sx_hll_lib_bin_group_set(const sx_hll_access_cmd_t            cmd,
                                         const sx_hll_lib_bin_group_params_t *params_p,
                                         sx_hll_lib_bin_group_t              *bin_group_p);

/*
 * This API will initiate bulk counter transaction and get counters. Received result
 * will be returned to LIB user and used as a whole in input of sx_hll_lib_cardinality_get().
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * @param [in] cmd                 - READ/READ_CLEAR
 * @param [in] bin_group           - bin_group params, containing profile info and flow bulk counter info.
 * @param [out] bins_values_p      - flow estimator bins (counters) for cardinality calculation. The memory should be allocated and
 *                                   provided by the user and the number of sx_flow_estimator_counter_set_t should be same as input param
 *                                   bin_group_p->counter.flow_cntr_bulk_attr.counter_num.
 *                                   Its flow_estimator_counter_set_num is output value only.
 *
 * @return SX_HLL_STATUS_SUCCESS if operation completes successfully
 * @return SX_HLL_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_HLL_STATUS_PARAM_NULL  if an input parameter is NULL
 * @return SX_HLL_STATUS_NO_RESOURCES if no buff or other resources to do a read transaction
 * @return SX_HLL_STATUS_UNSUPPORTED if the operation or parameters are not supported
 * @return SX_HLL_ERROR    general error
 * @return SX_HLL_ENTRY_NOT_FOUND   fails because of the profile is not created.
 */
sx_hll_status_t sx_hll_lib_bin_group_get(const sx_hll_access_cmd_t         cmd,
                                         const sx_hll_lib_bin_group_t     *bin_group_p,
                                         sx_hll_lib_flow_estimator_bins_t *bins_values_p);

/*
 * This API will calculate the cardinality value based on input bin values which are output of previous call of sx_hll_lib_bin_group_get().
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * @param [in] flow_estimator_bins   - an array of flow estimator bin values.
 * @param [out] flow_cardinality     - cardinality value.
 *
 * @return SX_HLL_STATUS_SUCCESS if operation completes successfully
 * @return SX_HLL_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_HLL_STATUS_PARAM_NULL  if an input parameter is NULL
 * @return SX_HLL_STATUS_NO_RESOURCES if no resource to do the calculation
 * @return SX_HLL_ERROR    general error
 */
sx_hll_status_t sx_hll_lib_cardinality_get(const sx_hll_lib_flow_estimator_bins_t  *flow_estimator_bins_p,
                                           sx_hll_lib_flow_estimator_cardinality_t *flow_cardinality_p);


#endif /* ifndef __SX_HLL_LIB_H__ */
