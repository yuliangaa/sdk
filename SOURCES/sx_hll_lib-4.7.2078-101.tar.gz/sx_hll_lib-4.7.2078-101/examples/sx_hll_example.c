/*
 * Copyright © 2001-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <string.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdlib.h>
#include <complib/cl_types.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include "sx/hll_lib/sx_hll_lib.h"
#include <signal.h>

#define TEST_NUM_KEYS          1
#define TEST_NUM_ACLS_IN_GROUP 1
#define TEST_NUM_RULES         4
#define TEST_NUM_FLOW_COUNTERS (TEST_NUM_RULES)
#define TEST_NUM_ACTIONS       1
#define TEST_NUM_PORTS         2

#define TEST_SX_ASSERT(sx_status, msg)                                                              \
    if (SX_CHECK_FAIL(sx_status)) {                                                                 \
        printf("ERROR [%s:%d]: %s [%s]\n", __FUNCTION__, __LINE__, #msg, sx_status_str(sx_status)); \
        exit(1);                                                                                    \
    }

typedef struct hll_test_data {
    /* acl data */
    sx_acl_key_t            acl_keys[TEST_NUM_KEYS];
    sx_acl_key_type_t       acl_key_handle;
    sx_acl_region_id_t      acl_region_id;
    sx_acl_region_group_t   acl_region_group;
    sx_acl_id_t             acl_id;
    sx_acl_id_t             acl_group_id;
    sx_acl_id_t             acl_id_list[TEST_NUM_ACLS_IN_GROUP];
    sx_acl_rule_offset_t    acl_offsets_list[TEST_NUM_RULES];
    sx_flex_acl_flex_rule_t acl_rules_list[TEST_NUM_RULES];
    /* flow estimator counters allocation */
    sx_hll_lib_bin_group_t *bin_group_p;
    /* ports */
    sx_port_id_t ingress_ports[TEST_NUM_PORTS];
} hll_test_data_t;

static void __init_rule_with_counter(sx_flex_acl_flex_rule_t *rule,
                                     uint16_t                 layer4_port,
                                     sx_hll_lib_bin_group_t  *bin_group_p)
{
    rule->valid = 1;
    rule->key_desc_count = TEST_NUM_KEYS;
    rule->key_desc_list_p[0].key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT;
    rule->key_desc_list_p[0].key.l4_destination_port = layer4_port;
    rule->key_desc_list_p[0].mask.l4_destination_port = 0xffff;
    rule->action_count = TEST_NUM_ACTIONS;
    rule->action_list_p[0].type = SX_FLEX_ACL_ACTION_FLOW_ESTIMATOR;
    rule->action_list_p[0].fields.action_flow_estimator.counter = bin_group_p->counters.flow_cntr_bulk_data;
    rule->action_list_p[0].fields.action_flow_estimator.profile_key = bin_group_p->profile_key;
}


static void __create_acl(sx_api_handle_t api_handle, hll_test_data_t *test_data_p)
{
    sx_status_t sx_status;
    int         i;

    /* create ACL key handle */
    test_data_p->acl_keys[0] = FLEX_ACL_KEY_L4_DESTINATION_PORT;
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_CREATE,
                                        test_data_p->acl_keys,
                                        TEST_NUM_KEYS,
                                        &test_data_p->acl_key_handle);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_flex_key_set()");
    printf("Created ACL key handle\n");

    /* create ACL region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_CREATE,
                                      test_data_p->acl_key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      TEST_NUM_RULES,
                                      &test_data_p->acl_region_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_region_set()");
    printf("Created ACL region\n");

    /* create ACL */
    test_data_p->acl_region_group.regions.acl_packet_agnostic.region = test_data_p->acl_region_id;
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_CREATE,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               SX_ACL_DIRECTION_INGRESS,
                               &test_data_p->acl_region_group,
                               &test_data_p->acl_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_set()");
    printf("Created ACL\n");

    /* create ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_CREATE,
                                     SX_ACL_DIRECTION_INGRESS,
                                     test_data_p->acl_id_list,
                                     0,
                                     &test_data_p->acl_group_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_group_set()");
    printf("Created ACL group\n");

    /* Link ACL to ACL group */
    test_data_p->acl_id_list[0] = test_data_p->acl_id;
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_SET,
                                     SX_ACL_DIRECTION_INGRESS,
                                     test_data_p->acl_id_list,
                                     TEST_NUM_ACLS_IN_GROUP,
                                     &test_data_p->acl_group_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_group_set()");
    printf("Linked ACL to ACL group\n");

    /* initialize ACL rules */
    for (i = 0; i < TEST_NUM_RULES; i++) {
        test_data_p->acl_offsets_list[i] = i;

        sx_status = sx_lib_flex_acl_rule_init(test_data_p->acl_key_handle,
                                              TEST_NUM_ACTIONS,
                                              &test_data_p->acl_rules_list[i]);
        TEST_SX_ASSERT(sx_status, "sx_lib_flex_acl_rule_init()");
    }

    __init_rule_with_counter(&test_data_p->acl_rules_list[0], 8080, test_data_p->bin_group_p);
    __init_rule_with_counter(&test_data_p->acl_rules_list[1], 8081, test_data_p->bin_group_p);
    __init_rule_with_counter(&test_data_p->acl_rules_list[2], 8082, test_data_p->bin_group_p);
    __init_rule_with_counter(&test_data_p->acl_rules_list[3], 8083, test_data_p->bin_group_p);
    printf("Initialized %d ACL rules\n", TEST_NUM_RULES);

    /* set ACL rules */
    sx_status = sx_api_acl_flex_rules_set(api_handle,
                                          SX_ACCESS_CMD_SET,
                                          test_data_p->acl_region_id,
                                          test_data_p->acl_offsets_list,
                                          test_data_p->acl_rules_list,
                                          TEST_NUM_RULES);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_flex_rules_set()");
    printf("Set ACL rules\n");

    /* bind ACL rules to ports */
    for (i = 0; i < TEST_NUM_PORTS; i++) {
        sx_status = sx_api_acl_port_bind_set(api_handle,
                                             SX_ACCESS_CMD_BIND,
                                             test_data_p->ingress_ports[i],
                                             test_data_p->acl_group_id);
        TEST_SX_ASSERT(sx_status, "sx_api_acl_port_bind_set()");
    }
    printf("Bound ACL rules to ingress ports\n");
}


static void __delete_acl(sx_api_handle_t api_handle, hll_test_data_t *test_data_p)
{
    sx_status_t sx_status;
    int         i;

    /* unbind ACL group from ports */
    for (i = 0; i < TEST_NUM_PORTS; i++) {
        sx_status = sx_api_acl_port_bind_set(api_handle,
                                             SX_ACCESS_CMD_UNBIND,
                                             test_data_p->ingress_ports[i],
                                             test_data_p->acl_group_id);
        TEST_SX_ASSERT(sx_status, "sx_api_acl_port_bind_set()");
    }

    /* delete ACL rules */
    sx_status = sx_api_acl_flex_rules_set(api_handle,
                                          SX_ACCESS_CMD_DELETE,
                                          test_data_p->acl_region_id,
                                          test_data_p->acl_offsets_list,
                                          test_data_p->acl_rules_list,
                                          TEST_NUM_RULES);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_flex_rules_set()");

    /* deinitialize ACL rules structure */
    for (i = 0; i < TEST_NUM_RULES; i++) {
        sx_status = sx_lib_flex_acl_rule_deinit(&test_data_p->acl_rules_list[i]);
        TEST_SX_ASSERT(sx_status, "sx_lib_flex_acl_rule_deinit()");
    }

    /* destroy ACL group */
    sx_status = sx_api_acl_group_set(api_handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     SX_ACL_DIRECTION_INGRESS,
                                     test_data_p->acl_id_list,
                                     TEST_NUM_ACLS_IN_GROUP,
                                     &test_data_p->acl_group_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_group_set()");

    /* destroy ACL */
    sx_status = sx_api_acl_set(api_handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               SX_ACL_DIRECTION_INGRESS,
                               &test_data_p->acl_region_group,
                               &test_data_p->acl_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_set()");

    /* destroy ACL region */
    sx_status = sx_api_acl_region_set(api_handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      test_data_p->acl_key_handle,
                                      SX_ACL_ACTION_TYPE_EXTENDED,
                                      TEST_NUM_RULES,
                                      &test_data_p->acl_region_id);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_region_set()");

    /* delete ACL key handle */
    sx_status = sx_api_acl_flex_key_set(api_handle,
                                        SX_ACCESS_CMD_DELETE,
                                        test_data_p->acl_keys,
                                        TEST_NUM_KEYS,
                                        &test_data_p->acl_key_handle);
    TEST_SX_ASSERT(sx_status, "sx_api_acl_flex_key_set()");
}

void __click_any_key_to_continue(const char *msg)
{
    printf("\nCLICK ANY KEY TO %s", msg);
    /* coverity[check_return] */
    getchar();
}

int main(int argc, const char *argv[])
{
    sx_hll_status_t                         rc = SX_HLL_STATUS_SUCCESS;
    sx_api_handle_t                         api_handle;
    sx_status_t                             sx_status = SX_STATUS_SUCCESS;
    sx_hll_lib_init_params_t                init_param;
    sx_hll_lib_bin_group_params_t           bin_group_param;
    sx_hll_lib_bin_group_t                  bin_group;
    sx_hll_lib_flow_estimator_bins_t        flow_estimator_bins;
    sx_hll_lib_flow_estimator_cardinality_t cardinality;
    hll_test_data_t                         test_data;
    uint32_t                                i = 0, j = 0;

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    sx_status = sx_api_open(NULL, &api_handle);
    TEST_SX_ASSERT(sx_status, "sx_api_open()");

    memset(&init_param, 0, sizeof(sx_hll_lib_init_params_t));
    init_param.logging_cb = NULL;

    rc = sx_hll_lib_init(init_param);
    if (rc != SX_HLL_STATUS_SUCCESS) {
        printf("Failed to init HLL library.\n");
        return -1;
    }

    memset(&bin_group_param, 0, sizeof(sx_hll_lib_bin_group_params_t));
    memset(&bin_group, 0, sizeof(sx_hll_lib_bin_group_t));
    bin_group_param.error_rate_percent = 9;

    rc = sx_hll_lib_bin_group_set(SX_HLL_ACCESS_CMD_CREATE_E, &bin_group_param, &bin_group);
    if (rc != SX_HLL_STATUS_SUCCESS) {
        printf("Failed to create bin group.\n");
        return -1;
    }

    memset(&test_data, 0, sizeof(test_data));
    test_data.bin_group_p = &bin_group;
    test_data.ingress_ports[0] = 0x10041;
    test_data.ingress_ports[1] = 0x10005;
    __create_acl(api_handle, &test_data);

    printf("Send traffic with L4 port (8080, 8081, 8082, 8083) to port (0x%x, 0x%x).\n",
           test_data.ingress_ports[0],
           test_data.ingress_ports[1]);
    __click_any_key_to_continue("read counter");

    memset(&flow_estimator_bins, 0, sizeof(sx_hll_lib_flow_estimator_bins_t));
    flow_estimator_bins.flow_estimator_counter_set_p = calloc(bin_group.counters.flow_cntr_bulk_attr.counter_num,
                                                              sizeof(sx_flow_estimator_counter_set_t));

    if (flow_estimator_bins.flow_estimator_counter_set_p == NULL) {
        printf("Failed to allocate memory for flow estimator counters.\n");
        return -1;
    }
    rc = sx_hll_lib_bin_group_get(SX_HLL_ACCESS_CMD_READ_CLEAR_E, &bin_group, &flow_estimator_bins);
    if (rc != SX_HLL_STATUS_SUCCESS) {
        printf("Failed to get flow estimator bins.\n");
        return -1;
    }

    for (i = 0; i < flow_estimator_bins.flow_estimator_counter_set_num; i++) {
        printf("flow_estimator_counter_set[%d]: ", i);
        for (j = 0; j < FLOW_ESTIMATOR_BINS_PER_FLOW_COUNTER; j++) {
            printf("bin[%d] = 0x%x ", j, flow_estimator_bins.flow_estimator_counter_set_p[i].flow_estimator_bins[j]);
        }
        printf("\n");
    }

    memset(&cardinality, 0, sizeof(sx_hll_lib_flow_estimator_cardinality_t));
    rc = sx_hll_lib_cardinality_get(&flow_estimator_bins, &cardinality);
    if (rc != SX_HLL_STATUS_SUCCESS) {
        printf("Failed to get cardinality.\n");
        return -1;
    }

    printf("flow cardinality is %" PRId64 "\n ", cardinality.flow_cardinality);

    __delete_acl(api_handle, &test_data);

    rc = sx_hll_lib_bin_group_set(SX_HLL_ACCESS_CMD_DESTROY_E, NULL, &bin_group);
    if (rc != SX_HLL_STATUS_SUCCESS) {
        printf("Failed to destroy bin group.\n");
        return -1;
    }

    rc = sx_hll_lib_deinit();
    if (rc != SX_HLL_STATUS_SUCCESS) {
        printf("Failed to deinit HLL library.\n");
        return -1;
    }

    sx_api_close(&api_handle);
    return 0;
}
