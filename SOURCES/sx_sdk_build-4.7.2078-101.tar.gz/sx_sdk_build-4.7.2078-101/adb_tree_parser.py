#!/usr/bin/env python3
# -*- coding: latin-1 -*-

import math
import xmltodict
import operator


def toint(esize):
    r = int(esize.split('.', 2)[1])
    if '0x' in esize:
        r += int(esize.split('.', 2)[0], 16) * 8
    return r


class EBasic(object):
    def __init__(self):
        self._name = None
        self._size = 0

    def __init__(self, name, size):
        self._name = name
        self._size = size

    @property
    def name(self):
        return self._name.replace('/', '_').replace(' ', '').replace('-', '_').replace('[', '_').replace(':', '_').replace(']', '_')

    @name.setter
    def name(self, name):
        self._name = name

    @property
    def size(self):
        return max(toint(self._size) / 8, 1)

    @property
    def size_bit(self):
        return toint(self._size)

    @size.setter
    def size(self, size):
        self._size = size


class ENode(EBasic):
    def __init__(self):
        self._is_union = False

    def __init__(self, name, size):
        self._is_union = False
        super(ENode, self).__init__(name, size)

    def __init__(self, name, size, fields):
        self._is_union = False
        super(ENode, self).__init__(name, size)
        if not isinstance(fields, list):
            fields = [fields]
        self._field = {}
        s = ""
        for field in fields:
            if '@subnode' in list(field.keys()):
                s = field['@subnode']
            f = EField(field['@name'], field['@size'],
                       field['@offset'], s,
                       field['@descr'])
            if '@enum' in list(field.keys()):
                f.enum = field['@enum']

            if '@low_bound' in list(field.keys()):
                f.low_bound = field['@low_bound']

            if '@high_bound' in list(field.keys()):
                f.high_bound = field['@high_bound']

            self._field[f.name] = f

    def print_proto_field(self, nodes, dname):
        data = []
        data.append('{dname}.fields.pf_{name} = ProtoField.bytes("{dname}.{name}", "{dname}.{name}")'.format(
            name=self.name,
            dname=dname))

        for f in self.fields:
            if f.subnode not in list(nodes.keys()):
                if len(f.enum):
                    data.append('{dname}.fields.pf_{name} = ProtoField.new("{dname}.{name}", "{dname}.{name}", ftypes.UINT32, {enum}, base.DEC)'.format(
                        name=f.name,
                        dname=dname,
                        enum=f.enum_str))
                else:
                    data.append('{dname}.fields.pf_{name} = ProtoField.uint32("{dname}.{name}", "{dname}.{name}", nil, nil, nil, "{descr}")'.format(
                        name=f.name,
                        dname=dname,
                        descr=f.descr))
            else:
                data.extend(nodes[f.subnode].print_proto_field(nodes, dname))

        return data

    def __get_sbit(self, offset, size):
        """Return start bit of field in u32.

        offset: Field PRM bit offset
        size: Field PRM size (in bits)
        """
        return (32 - (offset % 32) - size)

    def __get_sbyte(self, offset, sbit):
        """Return start byte of field.

        offset: Field PRM bit offset
        sbit: Field start bit in u32
        """
        return ((offset / 32) * 4 + sbit / 8)

    def __get_ebyte(self, sbyte, size):
        """Return end byte of field.

        sbyte: Field start byte.
        size: Field PRM size (in bits)
        """
        return (sbyte + int(math.ceil(size / 8.0)))

    def print_subnode_function(self, nodes, dname):
        data = ['']

        for f in self.fields:
            if f.subnode in list(nodes.keys()):
                data.extend(nodes[f.subnode].print_subnode_function(nodes, dname))

        data.append('-- function for node_{name}'.format(name=self.name))
        data.append('function node_{name}(tvbuf, tree)'.format(name=self.name))
        data.append('\t local subtree = tree:add({dname}.fields.pf_{name}, tvbuf())'.format(
            dname=dname,
            name=self.name))
        for f in self.fields:
            if f.subnode in list(nodes.keys()):
                for i in range(f.low_bound, f.high_bound + 1):
                    data.append('\t node_{name}(tvbuf({offset}, {size}), subtree)'.format(
                        name=f.subnode,
                        offset=f.offset * (i + 1),
                        size=nodes[f.subnode].size))
            else:
                sbit = self.__get_sbit(f.offset_bit, f.size_bit)
                ebit = sbit + f.size_bit - 1
                sbyte = self.__get_sbyte(f.offset_bit, sbit)
                ebyte = self.__get_ebyte(sbyte, f.size_bit)
                data.append('\t subtree:add({dname}.fields.pf_{name}, tvbuf({offset}, {size}), tvbuf({offset}, {size}):bitfield({sbit}, {bsize}))'.format(
                    dname=dname, name=f.name, offset=sbyte, size=ebyte - sbyte,
                    sbit=sbit - 8 * (sbyte % 4), bsize=ebit - sbit + 1))
        data.extend(['end', ''])

        return data

    @property
    def fields(self):
        return sorted(list(self._field.values()), key=operator.attrgetter('offset'))
        # return ' '.join(self._field.keys())


class EField(EBasic):
    def __init__(self):
        pass

    def __init__(self, name, size, offset, subnode, descr):
        self._offset = offset
        self._subnode = subnode
        self._descr = descr
        self._enum = {}
        self._low_bound = 0
        self._high_bound = 0
        super(EField, self).__init__(name, size)

    @property
    def descr(self):
        return self._descr.replace('\\', '').replace('\"', '')

    @property
    def offset(self):
        return toint(self._offset) / 8

    @property
    def offset_bit(self):
        return toint(self._offset)

    @property
    def subnode(self):
        return self._subnode

    @property
    def enum(self):
        return self._enum

    @property
    def enum_str(self):
        return '{ ' + (', '.join('[{v}] = "{k}"'.format(k=k, v=v) for k, v in list(self.enum.items()))) + ' }'

    @property
    def enum_str_hex(self):
        return '{ ' + (', '.join('[{v}] = "{k}"'.format(k=k, v=hex(v)) for k, v in list(self.enum.items()))) + ' }'

    @enum.setter
    def enum(self, val):
        ll = val.split(',')
        for l in ll:
            n = l.split('=')[0]
            v = l.split('=')[1]
            if '0x' in v:
                v = int(v, 16)
            self._enum[n] = v

    @property
    def low_bound(self):
        return self._low_bound

    @low_bound.setter
    def low_bound(self, val):
        self._low_bound = int(val, 10)

    @property
    def high_bound(self):
        return self._high_bound

    @high_bound.setter
    def high_bound(self, val):
        self._high_bound = int(val, 10)


def print_node(node, nodes, l):
    for f in node.fields:
        print('\t' * l + f.name + '(' + f.subnode + ')' + '\t size:' + str(f.size) + ', offset:' + str(f.offset))
        if f.subnode in nodes.keys():
            print_node(nodes[f.subnode], nodes, l + 1)


def print_proto(node, rid, nodes):
    data = []
    data.append('local {name} = Proto("{name}", "{name} Register")'.format(
        name=node.name))
    # data.append('local EMAD_{proto}_TYPE = {rid}'.format(
    #    proto=node.name.upper(),
    #    rid=rid))

    data.append('')
    data.extend(node.print_proto_field(nodes, node.name))

    data.extend(node.print_subnode_function(nodes, node.name))

    data.append('function {name}.dissector(tvbuf, pktinfo, root)'.format(name=node.name))
    # data.append('\tlocal subtree = root:add ({name}, tvbuff())'.format(name=node.name))
    data.append('\tpktinfo.cols.protocol:set("EMAD.{name}")'.format(name=node.name))
    data.append('\tnode_{name}(tvbuf, root)'.format(name=node.name))
    data.extend(['end', ''])
    data.append('DissectorTable.get("emad_regs"):add({rid}, {proto})'.format(
        proto=node.name,
        rid=rid))
    data.append('')
    print('\n'.join(i for i in data if i is not None))

    pass


def print_reg_proto(nodes):
    # print('DissectorTable.new("emad_regs", "emad_regs", ftypes.UINT16, base.DEC)')
    for f in nodes['EMAD_oper_tlv'].fields:
        if f.name == 'register_id':
            # print(f.enum_str_hex)
            for k, v in list(f.enum.items()):
                if k in list(nodes.keys()) and k not in 'rtps':
                    print_proto(nodes[k], v, nodes)


def main():
    nodes = {}
    with open('./Switch_PRM_13_1300_0060.adb') as fd:
        # with open('adb/shomron_prm_st.adb') as fd:
        nd = xmltodict.parse(fd.read())
    for node in nd['NodesDefinition']['node']:
        if 'field' not in list(node.keys()):
            continue
        n = ENode(node['@name'], node['@size'], node['field'])
        nodes[n.name] = n
    # print_node(nodes['prm'], nodes, 0)
    # print_node(nodes['emad_data'], nodes, 0)
    # print_node(nodes['ratr'], nodes, 0)
    # print_node(nodes['Shomron_PRM'], nodes, 0)

    print_reg_proto(nodes)


if __name__ == '__main__':
    main()
