#!/bin/sh
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


PUBLISH_DIR=/mswg/projects/bxm

if [ ! $# -eq 1 ]; then
	echo "Usage: ${0##*/} <binary dist>"
	exit 1
fi

BIN_DIST=${1##*/}
SRC_DIST=${BIN_DIST%.tar.gz}.src.tar.gz

set -x

cp $BIN_DIST $PUBLISH_DIR
cp $SRC_DIST $PUBLISH_DIR

pushd $PUBLISH_DIR

tar xzvf $BIN_DIST

rm -f latest
ln -s ${BIN_DIST%.tar.gz} latest

popd