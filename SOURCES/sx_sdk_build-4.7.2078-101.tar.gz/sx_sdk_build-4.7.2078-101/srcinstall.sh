#!/bin/sh
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


basedir=${0%/*}
echo Installing source RPMs at: $basedir

rpm -ivh \
	$basedir/sx_libs-*.src.rpm \
	$basedir/applibs-*.src.rpm \
	$basedir/sx_kernel-*.src.rpm

for P in sx_libs applibs sx_kernel
	do echo installing $P
	rm -rf /usr/src/redhat/BUILD/${P}-*
	rpmbuild -bc /usr/src/redhat/SPECS/${P}.spec
	pushd /usr/src/redhat/BUILD/${P}-*
	make install
	popd
done

echo << END
Done.
Sources are at: /usr/src/redhat/BUILD/<bxm package>
You can cd to a source tree, make modifications, and then:
make && make install
END
  