#! /usr/bin/env python3

import sys
import os
import subprocess
from optparse import OptionParser


def run_and_test_raising(cmd, should_fail=False):
    rc = run_and_test(cmd, should_fail)
    if rc != 0:
        raise Exception('run_and_test failed of cmd = ' + cmd + ' with rc = ' + str(rc))
    return 0


def run_and_test(cmd, should_fail=False):
    print("Running command : " + cmd)
    ret = subprocess.call(cmd, shell=True)
    failed = (ret != 0)
    # ret = ret / 256
    if should_fail:
        if failed:
            return 0

    if not should_fail:
        if not failed:
            return 0

    print("Command " + cmd + " mismatched Failure = " + str(should_fail))
    print("return value:")
    print(ret)
    return ret

    # >>> ret = os.system('git status | grep "working directory clean"') nothing to commit (working directory clean)    >>> print(ret)


def run_and_get_output(cmd):
    print('Command for output : ' + cmd)
    # for cmd in cmds:
    p1 = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, universal_newlines=True)
    (output, err) = p1.communicate()
    rc = p1.returncode
    if rc != 0 or err is not None:
        print('Error at running: ' + cmd)
        print(err)
        raise Exception('run_and_get_output failed of cmd = ' + cmd + ' with rc = ' + str(rc))
    return output


def init_parser():
    """
    @author: Roy Grossman
    @author: Doron Tsur
    @summary: Function parse the input args.
    @param: None
    @return:  options, contains all args
    """
    usage = "usage: %prog [options]"
    parser = OptionParser(usage)
    parser.add_option("--revision", dest="REVISION", help="Revision value, mandatory parameter", default='missing value')
    parser.add_option("--build_mode", dest="BUILD_MODE", help="Build mode, default is eth, supported modes are: [eth, vpi]", default='eth')
    parser.add_option("--release", dest="RELEASE", action="store_true", help="Release flag, default = False", default=False)
    (options, args) = parser.parse_args()
    return options


def validate_version_and_raise_error(version):
    if version == 'none':
        return True
    parts = version.split('.')
    if len(parts) != 3:
        print("Warning: Illegal version: " + version)
    for number in parts[0:2]:
        try:
            temp = int(number)
        except Exception as e:
            print("Warning: Illegal version (nan): " + version)
