#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#


ib_package_included=@IB_PACKAGE_INCLUDED@
remove_sources="0"
remove_legacy_vpi=0

usage()
{
cat << EOF

	Usage: `basename $0` [--help]: Prints this message
			 [--remove_sources]: Remove all sx_sdk sources.
			 [--remove_legacy_vpi]: Remove IB managment.
EOF
}

###############################################################################
#                          Parsing command line                               #
###############################################################################
while [ ! -z "$1" ]; do
		case "$1" in
		-h|--help)
			usage
			exit 0
			;;
		--remove_sources)
			remove_sources="1"
			;;
		--remove_legacy_vpi)
			remove_legacy_vpi=1
			;;
		*)
			echo "Bad input parameter: $1"
			usage
			exit 1
			;;
	esac
	shift
done

if [ "x${ib_package_included}" == "x1" ]; then
	ib_kernel_modules_dir_list="kernel/drivers/infiniband"
fi

basedir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
source ${basedir}/sdk_file_list.sh

debian_detection=`grep -iE 'debian|buntu|mint' /etc/*release /etc/issue 2> /dev/null`

ex() {
	echo "EXEC: $@"
	eval $@
	if [ "$?" != "0" ]; then
		echo "$@   FAILED"
		exit 1
	fi
}

uninstall_all_instances() {
	package=$1
	instances=`rpm -qa | grep ${package}`
	if [ "XX" == "X${instances}X" ] ; then
		echo "No package found for ${package}"
	else
		for instance in ${instances}
		do
			echo "Uninstalling ${instance}"
			ex rpm -e ${instance}
		done
	fi
}

debian_package_name_transform(){
	echo $1 | sed -e 's/_/-/g' | awk  '{print tolower($0)}' | sed 's/devel/dev/'
}

debian_package_check_instances(){
	package=$1
	echo `dpkg-query -W -f='${Package} ' "${package}*" 2>&1 | grep -v "dpkg-query: no packages found matching*"`
}

check_dpkg_lock() {
  local pkgs="${1}"
  for i in {1..60}; do
      locked_pid="$(timeout -s SIGKILL 10s lsof -P /var/lib/dpkg/lock | grep -v PID | grep -v grep | head -n1 | awk '{print $2}')"
      if [ "x${locked_pid}" == "x" ]; then break; fi
      if [ "x${i}" == "x60" ]; then
          proc_info="$(ps -ef | grep ${locked_pid} | grep -v grep)"
          print_info_and_stdout "-E- dpkg process still locked by PID ${locked_pid}"
          print_info_and_stdout "${proc_info}"
          print_error_and_fail "dpkg lock still held after 60 seconds, cannot uninstall DEB Packages of ${pkgs}"
      fi
      sleep 1
  done
}

debian_remove_packages(){
	instances="$@"
	echo "Uninstalling ${instances}"
	check_dpkg_lock "${instances}"
	ex dpkg --force-all --purge  "${instances}"
}

uninstall_all_debian_instances(){
	package=$1
	instances=$(debian_package_check_instances ${package})
	if [ "X" == "X${instances}" ] ; then
		echo "No package found for ${package}"
	else
		debian_remove_packages ${instances}
	fi
}

dump_sdk_usages() {
    local open_fds=$(timeout -s SIGKILL 10s lsof -VnPX 2> /dev/null | grep -s /dev/sxdevs | grep -v grep || true)
    test ! -z "${open_fds}" && echo -e "Open files for /dev/sxdevs:\n${open_fds}"

    local sx_core_dep=$(lsmod 2> /dev/null | grep -s sx_core | grep -v grep || true)
    test ! -z "${sx_core_dep}" && echo -e "Loaded kernel modules related to sx_core:\n${sx_core_dep}"

    local sdk_proc=$(ps -ef 2> /dev/null | grep -s sx_sdk | grep -v grep || true)
    test ! -z "${sdk_proc}" && echo -e "Running SDK Processes:\n${sdk_proc}"
}

sx_core_script=${SX_SDK_CUSTOM_PREFIX}/etc/init.d/sxdkernel
dvs_stop_script=$(which dvs_stop.sh 2>/dev/null || true)

if ! test -z "${dvs_stop_script}" && test -e ${dvs_stop_script}; then
    echo "SDK DVS Stop script found, running ${dvs_stop_script}"
    ex ${dvs_stop_script}
else
    echo Closing sys_sdk processes
    for binary in evb_manager sx_sdk
    do
      killall ${binary}
    done
    #killall -w flag is not supported on all platforms

    terminate_timeout=50
    echo
    echo "wait for sx_sdk to properly terminate up to ${terminate_timeout} seconds"
    timeout ${terminate_timeout} bash -c -- \
    "while pidof 'sx_sdk' > /dev/null; do printf "."; sleep .01; done"

    echo
    if [ $? == 0 ]; then
        echo 'sx_sdk is down'
    else
        dump_sdk_usages
        echo "-E- sx_sdk did not terminate after ${terminate_timeout} seconds | Check output for usages detected"
        exit 1
    fi

    # the following loop is to wait for remaining references on the driver to be released
    if [ -f /tmp/sx_core_min_dep_file ]; then
      echo
      echo 'wait for all references to the driver to be released'
      wait_iterations=0
      max_wait_iterations=5000 # 50 seconds with interval of one centisecond
      sx_core_min_dep=`cat /tmp/sx_core_min_dep_file`
      rm -rf /tmp/sx_core_min_dep_file
      sx_core_dep=`lsmod | grep '^sx_core' | awk '{print $3}'`
      while (( sx_core_min_dep < sx_core_dep && wait_iterations < max_wait_iterations )); do
        sx_core_dep=`lsmod | grep '^sx_core' | awk '{print $3}'`
        printf "."
        sleep .01
        ((wait_iterations=wait_iterations+1))
      done
      echo
      if test "${wait_iterations}" -eq "${max_wait_iterations}"; then
          dump_sdk_usages
          echo "-E- Not all references to the driver were released | Check output for usages detected"
          exit 1
      fi
    fi

    if [ -x ${sx_core_script} ] ; then
      ex ${sx_core_script} stop
    fi
fi

if [ "x${remove_legacy_vpi}" == "x1" ]; then
	if [ "x${ib_package_included}" == "x1" ]; then
		ex ${basedir}/remove_legacy_vpi.sh
	else
		echo Ignore remove_legacy_vpi flag
	fi
fi

echo Removing sys_sdk packages

if [ "x$debian_detection" == "x" ] ; then
	libnl3_pkg="libnl3-devel"
	libnl3_found=`yum list installed | grep ${libnl3_pkg}`
else #Debian case
	libnl3_pkg="libnl-genl-3-dev"
	libnl3_found=`dpkg --list | grep ${libnl3_pkg}`
fi
if [ "x$?" != "x0" ] ; then
	echo "${libnl3_pkg} is missing from DVS OS"
	echo "Removing sx_libnl"
	libnl_remove=1
	libs64_list+="libnl pkgconfig/libnl"
	include_list+="libnl3"
	packages_list+="sx_libnl-devel sx_libnl"
fi

if [ "x$debian_detection" == "x" ] ; then
	for package_removed in ${packages_list}
	do
		uninstall_all_instances ${package_removed}
	done
else #Debian case
	for package_removed in ${packages_list}
	do
		uninstall_all_debian_instances $(debian_package_name_transform ${package_removed})
	done
fi

python_make_dir=`ls -d  /usr/src/sx_sdk/BUILD/python_sdk_api-*/`
if [ ! -z ${python_make_dir} ] && [ -d ${python_make_dir} ]; then
	pushd ${python_make_dir}
	make uninstall
	popd
fi

if [ -e "/usr/src/sx_sdk/SOURCES/scew-1.1.2" ]; then
	pushd "/usr/src/sx_sdk/SOURCES/scew-1.1.2"
	make uninstall
	popd
fi

echo Removing any non-rpms libraries residues
pushd ${basedir} > /dev/null
for lib_removed in ${libs_list} ${libs64_list}
do
	rm -fv $(readlink -f ../lib)/${lib_removed}*
done

if [ "x$libnl_remove" == "x1" ] ; then
	rm -rfv $(readlink -f ../lib)/libnl*
fi

if [ -d ../lib64 ] ; then
	for lib_removed in ${libs64_list}
	do
		rm -fv $(readlink -f ../lib64)/${lib_removed}*
	done
fi

for include_remove in ${include_list}
do
	rm -rfv $(readlink -f ../include)/$include_remove
done

for bin_remove in ${bin_list}
do
	rm -fv $(readlink -f ../bin)/$bin_remove
done

for shared_obj in dpt lag sem.sxd_sniffer_sem net_lib_ifc net_lib_port wjh_libs_shm
do
	rm -fv /dev/shm/$shared_obj
done

for share_remove in ${share_list}
do
	rm -rfv $(readlink -f ../share)/$share_remove
done

for exp_remove in ${exp_list}
do
	rm -fv $(readlink -f ../experimental)/$exp_remove
done

for etc_remove in ${etc_list}
do
    rm -fv $(readlink -f ../etc)/$etc_remove
done

for kernel_mod_dir_removed in ${kernel_modules_dir_list}
do
	find /lib/modules/*/*/${kernel_mod_dir_removed} 2> /dev/null | xargs rm -rfv
done

rm -fv ${sx_core_script}
rm -fv ${SX_SDK_CUSTOM_PREFIX}/etc/modprobe.d/sx.modprobe.conf ${SX_SDK_CUSTOM_PREFIX}/etc/modprobe.d/blacklist-sx ${SX_SDK_CUSTOM_PREFIX}/etc/modprobe.d/blacklist-sx.conf

# Remove CMake artifacts if exists
if type cmake_uninstall.sh >/dev/null 2>&1; then
    ex cmake_uninstall.sh
else
    echo "CMake uninstall script not found"
fi

sdk_python3_dirs=$(python3 -c "import sys; import site; sys.stdout.write(' '.join(site.getsitepackages()))" 2> /dev/null)
for possible_dir in ${sdk_python3_dirs}; do
    echo "Removing possibly python_sdk_api leftovers from (${possible_dir}/python_sdk_api*)"
    rm -rf ${possible_dir}/python_sdk_api*
done

if [ "${remove_sources}" == "1" ] &&  [ -f "/var/opt/sx_sdk_src_path" ]; then
	src_path=$(cat /var/opt/sx_sdk_src_path)
	echo "Removing sx_sdk sources from ${src_path}"
	rm -rf ${src_path}
fi

rm -f /var/opt/sx_sdk_src_path

popd > /dev/null
rm -fv $0
