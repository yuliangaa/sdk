#! /bin/sh
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


SDK_VERSION=test
BRANCH_NAME=$1

BRANCH=${BRANCH_NAME}

echo "SDK_VERSION $SDK_VERSION"
echo "BRANCH_NAME $BRANCH_NAME"
echo "LASTRC_NAME $LASTRC_NAME"
echo "OWNER $OWNER"
echo "SUFFIX $SUFFIX"
echo "BRANCH $BRANCH"
echo "rel_suffix $rel_suffix"
echo "rel_prefix $rel_prefix"

echo pwd

I=0

DISABLE_USER_PACKAGE_TESTS=YES
#DISABLE_USER_PACKAGE_TESTS=NO

#BUILD_MODES="sx_sdk_eth sx_sdk_vpi"
#BUILD_MODES="sx_sdk_vpi"
BUILD_MODES="sx_sdk_eth"

for BUILD_TYPE in ${BUILD_MODES} ;do  env lastrc_suffix=_${LASTRC_NAME} DISABLE_USER_PACKAGE_TESTS=${DISABLE_USER_PACKAGE_TESTS} DISABLE_DOXYGEN_CHECK=yes DISABLE_COV_CHECK=yes upload_to_server=no sxd_kernel_branch=$BRANCH git_sdk_build_branch=$BRANCH sx_examples_branch=$BRANCH sxd_libs_branch=$BRANCH sx_complib_branch=$BRANCH applibs_branch=$BRANCH sx_doxygen_branch=$BRANCH sx_libnl_branch=$BRANCH sx_eSMA_branch=$BRANCH `pwd`/build ${BUILD_TYPE} ; if [ $? -ne "0" ]; then I=1; fi ;done

if [ $I -eq 1 ]; then
	exit 1
fi
exit 0