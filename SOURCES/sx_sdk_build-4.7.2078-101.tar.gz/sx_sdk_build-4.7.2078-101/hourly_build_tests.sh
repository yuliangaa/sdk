#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


PATH="/usr/local/bin:$PATH"

tmp_file=~/log.txt
full_log_file=~/log_full.txt

tail_lines_count=10
echo "tmp file = " $tmp_file

recipients=doront@mellanox.co.il
cc_recipients=sagir@mellanox.co.il,sx-sw-ver@mellanox.co.il,amosh@mellanox.co.il,itaib@mellanox.co.il,moranl@mellanox.co.il,moranp@mellanox.co.il,nimrod@mellanox.co.il,reuven@mellanox.co.il,roeyt@mellanox.co.il

echo "Start: `date`" > $tmp_file
env dest=/tmp /mswg/projects/art/build sx_sdk 2>>$tmp_file 1>>$full_log_file

RC=$?

cat $tmp_file | tail -n $tail_lines_count > $tmp_file.short

echo "RC= $RC "

if [ ! $RC == 0 ]; then
	echo "build FAILED"
	mail -s "Build failed - 2 hours build watchdog" $recipients -c $cc_recipients < $tmp_file.short
fi

echo "End: `date`" >> $tmp_file

if [! "X$1" == "Xtrial"] ; then
	mail -s "Build complete" $recipients < $tmp_file
fi