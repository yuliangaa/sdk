#!/bin/sh
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


CONF_FILE=gen_doxyfile
OUTPUT_DIR=gen_output

local_folder=`dirname $0`

if [ "x${doxygen_bin}" == "x" ] ; then 
	doxygen_bin=/sysgwork/doxygen-1.7.3/bin/doxygen
fi

CONF_FILE_TEMPLATES=${CONF_FILE_TEMPLATES:-"${local_folder}/Doxyfile ${local_folder}/Doxyfile-without-graphs"}

for CONF_FILE_TEMPLATE in $CONF_FILE_TEMPLATES
do
	rm -f $CONF_FILE
	rm -rf $OUTPUT_DIR
	cp -v $CONF_FILE_TEMPLATE $CONF_FILE
	MY_DIR=`pwd | sed -e "s/\\//\\\\\\\\\\//g"`
	sed -i -e "s/XSOURCEX/${MY_DIR}/g" -e "s/XDESTINATIONX/${MY_DIR}\/${OUTPUT_DIR}/g" ${CONF_FILE}
	${doxygen_bin} $CONF_FILE
	tar -czvf ~/`basename ${CONF_FILE_TEMPLATE}`.tgz `pwd`/${OUTPUT_DIR}
done