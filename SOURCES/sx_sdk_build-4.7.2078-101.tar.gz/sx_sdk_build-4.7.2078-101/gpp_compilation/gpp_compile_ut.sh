#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

set -eE

# GPP Compilation UT Script
# Will attempt to compile gpp application

base_path="$(readlink -f "$(dirname "${0}")")"
build_path="${base_path}/build"

error_exit() {
    local err_msg="${1}"
    echo -e "[ERROR] ${err_msg}\nGPP Compilation UT Failed"
    rm -rf ${build_path}
    exit 1
}

echo "GPP Compilation UT Started | build_path = ${build_path}"

if test -n "${SYS_SDK_ROOT_PATH}"; then
    echo "Using SYS_SDK_ROOT_PATH=${SYS_SDK_ROOT_PATH}"
else
    echo "SYS_SDK_ROOT_PATH Not Set | Will use SDK Sources relative to build_path"
fi

cd ${base_path} && rm -rf ${build_path}
cmake -B build -DSYS_SDK_ROOT_PATH=${SYS_SDK_ROOT_PATH} && cmake --build build -v -j$(nproc) || error_exit "Failed to compile GPP App"
rm -rf ${build_path}

echo "GPP Compilation UT Passed SUCCESS"
