#! /bin/sh
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


folder=`date  +%Y%m%d%H%M%S`


tmp_folder="/tmp/$folder"

doxygen_bin=/sysgwork/doxygen-1.7.3/bin/doxygen


ex() {
	echo "EXEC: $@" 
	eval $@ 
	if [ "$?" != "0" ]; then
		echo "$@   FAILED"
		echo "pwd = `pwd`"
		exit 1
	fi
}


script_folder=`dirname $0`
version=$1

prefix=/mswg/release/sx_sdk_eth/sx_sdk_eth-$version/

#sdk_headers_files_folder
#sxd_header_files_folder
#$(eval echo \${${sx_sdk_package}_git})

for files_list_suffix in lite full
do
	files_list_sdk=${script_folder}/sdk_files_doxygen_${files_list_suffix}.txt
	files_list_sxd=${script_folder}/sxd_files_doxygen_${files_list_suffix}.txt

	if [ "x${sdk_headers_files_folder}${sxd_header_files_folder}" == "x" ]; then
		ex sudo rm -f /var/www/html/${version}_doxygen_${files_list_suffix}
		ex rm -rf $prefix/${version}_doxygen_${files_list_suffix}
	else
		debug_gen=1
	fi

	ex mkdir -p $tmp_folder
	ex pushd $tmp_folder


	if [ "x${sdk_headers_files_folder}${sxd_header_files_folder}" == "x" ] ; then

		ex cp -Rv $prefix $tmp_folder

		ex tar -xzvf $tmp_folder/sx_sdk_eth-${version}/SOURCES/applibs-${version}-0.tar.gz
		ex tar -xzvf $tmp_folder/sx_sdk_eth-${version}/SOURCES/sxd_libs-${version}-0.tar.gz

	fi

	ex mkdir sdk_${version}_${files_list_suffix}
	ex pushd sdk_${version}_${files_list_suffix}
	ex mkdir sdk
	ex mkdir sxd

	if [ "x${sdk_headers_files_folder}${sxd_headers_files_folder}" == "x" ] ; then
		sdk_headers_files_folder_used="../applibs-${version}-0/include"
		sxd_headers_files_folder_used="../sxd_libs-${version}-0/include"
	else
		sdk_headers_files_folder_used=${sdk_headers_files_folder}
		sxd_headers_files_folder_used=${sxd_headers_files_folder}
	fi

	
	for I in `cat ${files_list_sdk}` ; do echo $I; cp -Rv ${sdk_headers_files_folder_used}/$I sdk || exit 1  ; done
	for I in `cat ${files_list_sxd}` ; do echo $I; cp -Rv ${sxd_headers_files_folder_used}/$I sxd || exit 1 ; done



	cp -v ${script_folder}/config_sdk_api/* sdk
	pushd sdk
	conf_file=DoxyfileSDK					  
	ex sed -i -e"s/3.0.1000/$version/g" ./${conf_file}
	ex env CONF_FILE_TEMPLATES=./${conf_file} doxygen_bin=${doxygen_bin} ${script_folder}/doxygen_current_dir.sh
	mv -v gen_output/html .
	popd


	cp -v ${script_folder}/config_sxd_api/* sxd
	pushd sxd
	conf_file=DoxyfileSXD					  
	ex sed -i -e"s/3.0.1000/$version/g" ./${conf_file}
	ex env CONF_FILE_TEMPLATES=./${conf_file} doxygen_bin=${doxygen_bin} ${script_folder}/doxygen_current_dir.sh
	mv -v gen_output/html .
	popd



	ex cp -v sdk/SwitchXSDKSWcomponents.gif sdk/html
	ex cp -v sdk/Mellanoxlogo.gif sdk/html
	ex cp -v sdk/Mellanoxlogo.gif sxd/html

	rm -f sdk/*
	rm -f sxd/*

	pushd sdk/html
	for I in `ls *.html` ;
	do 
		echo $I; 
		sed -i $I -e "s/\"files.html.*SwitchX.*Driver/\"..\/..\/sxd\/html\/&/g"; 
		sed -i $I -e "s/\/html\/\"/\/html\//g";  
		done
	popd
	pushd sxd/html
	for I in `ls *.html` ;
	do 
		echo $I; 
		sed -i $I -e "s/\"files.html.*SwitchX.*SDK/\"..\/..\/sdk\/html\/&/g"; 
		sed -i $I -e "s/\/html\/\"/\/html\//g"; 
		# highlighting correct tab
		sed -i -e "s/<li class=\"current\"><a href=\"\.\./<li><a href=\"\.\./g"	$I
		sed -i -e "s/<li><a href=\"files/<li class=\"current\"><a href=\"files/g" $I
		# pointing to sdk's main index.html
		sed -e"s/<li><a href=\"index.html/<li><a href=\"\.\.\/\.\.\/sdk\/html\/index.html/g" -i $I
	done
	popd

	if [ "x${debug_gen}" != "x1" ] ; then
		ex cp -Rv . $prefix/${version}_doxygen_${files_list_suffix}
		ex sudo ln -s $prefix/${version}_doxygen_${files_list_suffix} /var/www/html/sx_sdk_eth_${version}_doxygen_${files_list_suffix}
		pushd $prefix
		tar -czvf ${version}_doxygen_${files_list_suffix}.tgz ${version}_doxygen_${files_list_suffix}
		popd
	fi

done


if [ "x${debug_gen}" != "x1" ] ; then
	sudo \cp -v ${script_folder}/index.html.in /var/www/html/index.html.in
	sudo sed -e "s/VERSION/${version}/g" -i /var/www/html/index.html.in
	sudo \mv -v /var/www/html/index.html.in /var/www/html/index.html

	echo "doxygen output new version available at: \\\\10.4.0.102\\mswg\\release\\sx_sdk_eth\\sx_sdk_eth-${version}\\${version}_doxygen_lite.tgz link at: http://10.7.34.101/sx_sdk_eth_${version}_doxygen_lite/sdk/html" |  mail -s "new doxygen version available" sx_sdk_doxygen@mellanox.co.il 
fi

ex popd
ex popd

if [ "x${debug_gen}" == "x1" ] ; then
	echo "tmp_folder = $tmp_folder"
else
	ex rm -rf $tmp_folder
fi