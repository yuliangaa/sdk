#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#

# Initial value
package_install_mode=@PACKAGE_INSTALL_MODE@
package_install_version=@PACKAGE_INSTALL_VERSION@
prefix="/usr"
if [ -e /etc/mlnx-release ] || [ -e /etc/nvidia-release ]; then
	nvidia_dvs_os="1"
fi
manual_prefix_set="0"
etc_prefix=
batch="no"
enable_sxd_sniffer="no"
use_cross_compiler="0"
with_memtrack="0"
enable_ecmp_sim="0"
err=0
debian_detection=`grep -iE 'debian|buntu|mint' /etc/*release /etc/issue 2> /dev/null`
if [ "x$debian_detection" == "x" ] ; then
echo "No Debian detected"
fi

# CMake initial values
use_cmake=0
use_fuse=0
cmake_defines="-DUSE_API_TESTER=OFF -DSKIP_UNINSTALL_INSTALL_DEPENDENCY=ON"
cmake_install_prefix=""
cmake_sys_sdk_deb_version=1.mlnx.`echo ${package_install_version} | sed -e 's/-/./g' | sed -e 's/_/./g'`
cmake_extract_sources_dir_name=sys_sdk-${package_install_version}
cmake_rpm_package_file_name=sys_sdk-${package_install_version}.rpm

cmake_deb_package_file_name_prefix=sys-sdk_${cmake_sys_sdk_deb_version}
if lscpu | grep -qEs 'ARM|aarch64' || uname -m | grep -qEs 'aarch64'; then
	cmake_deb_package_file_name_arch+=arm64
else
	cmake_deb_package_file_name_arch+=amd64
fi

cmake_deb_package_file_name_main=${cmake_deb_package_file_name_prefix}_${cmake_deb_package_file_name_arch}.deb
cmake_deb_package_file_name_dev=${cmake_deb_package_file_name_prefix}_${cmake_deb_package_file_name_arch}-dev.deb
cmake_deb_package_file_name_dbgsym=${cmake_deb_package_file_name_prefix}_${cmake_deb_package_file_name_arch}-dbgsym.ddeb

# ASAN initial values
asan="0"

extract_sources="1"
repackage="0"
sdk_incremental_make=${sdk_incremental_make:-"0"}
configure_flags=""
sx_kernel_configure_flags=""
sx_kernel_additional_configure_flags=""
sx_ib_kernel_additional_configure_flags=""
sx_kernel_extra_naming=""
applibs_configure_flags=""
sxd_libs_configure_flags=""
sx_complib_configure_flags=""
sxd_libs_additional_configure_flags=""
sx_complib_additional_configure_flags=""
sx_examples_additional_configure_flags=""
with_sx_core_debug=""
with_debug_info=""
user_level_debug_enabled=""
sx_packages_user_level_debug_info=""
wjh_libs_configure_flags=""
wjh_libs_additional_configure_flags=""
sx_hash_calc_configure_flags=""
sx_hash_calc_additional_configure_flags=""
sx_hll_lib_configure_flags=""
sx_hll_lib_additional_configure_flags=""
sx_sdk_build_configure_flags=""
sx_sdk_build_additional_configure_flags=""
compile_release=""
sx_examples_configure_flags=""
with_sx_examples=1
with_python_sdk_api=1
python_sdk_api_supported="python3"
python_sdk_api_interpreters="python3"
with_sx_parallel_build=1
with_obj_desc_lib=1
with_wjh_lib=1
with_pd_build=0

sx_kernel_rpm_defines=""
sx_ib_kernel_rpm_defines=""
sx_ib_kernel_env_configure_flags=""
applibs_rpm_defines=""
sxd_libs_rpm_defines=""
sx_complib_rpm_defines=""
sx_examples_rpm_defines=""

manual_flags=0
ib_package=0
ib_precompiled=0
eth_package=0

OS=${OS:-"sx_sdk"}
topdir=${topdir:-"/usr/src/${OS}"}
deb_packages_zero_phase=""
sx_packages_first_phase=""
deb_packages_first_phase=""
sx_packages_second_phase=""
deb_packages_second_phase=""
sx_packages_third_phase=""
deb_packages_third_phase=""
deb_packages_fourth_phase=""
deb_packages_fifth_phase=""
sx_kernel_packages="sx_kernel"

package_install_version_rpm=`echo ${package_install_version} | sed -e 's/-/_/g'`

sx_kernel_rpms="sx_kernel sx_kernel-devel"

sxd_libs_rpms="sxd_libs sxd_libs-devel"
sx_eSMA_rpms="sx_eSMA"
sx_complib_rpms="sx_complib sx_complib-devel"
sx_scew_rpms="sx_scew sx_scew-devel"
sx_obj_desc_lib_rpms="sx_obj_desc_lib sx_obj_desc_lib-devel"
sx_hll_lib_rpms="sx_hll_lib sx_hll_lib-devel"
sx_acl_helper_rpms="sx_acl_helper sx_acl_helper-devel"
wjh_libs_rpms="wjh_libs wjh_libs-devel"
sx_hash_calc_rpms="sx_hash_calc"
sx_sdk_build_rpms="sx_sdk_build"

applibs_rpms="applibs applibs-devel"
python_sdk_api_rpms="python_sdk_api"

sx_gen_utils_rpms="sx_gen_utils sx_gen_utils-devel"

infiniband_diags_name="infiniband-diags"
infiniband_diags_rpms="infiniband-diags"

src_path_location="/var/opt/sx_sdk_src_path"

embedded_kernel_drivers_install=${embedded_kernel_drivers_install:-"0"}

name=`basename $0`
cd `dirname $0`
package_dir=`pwd`

LOGFILE=${LOGFILE:-"/tmp/install-sx_sdk.log.$$"}

print_info() {
	echo "$@" >> $LOGFILE
}

print_info_and_stdout() {
	echo "$@"
	if [ "x${LOGFILE}" != "x/dev/stdout" ]; then
		echo "$@" >> $LOGFILE
	fi
}

print_info_and_stdout "Install cmd:"
print_info_and_stdout "$(readlink -f ${package_dir}/${name}) ${*}"
print_info_and_stdout "Install mode: ${package_install_mode}"
print_info_and_stdout "Expected version: ${package_install_version}"


###############################################################################
#                                Internal Options                             #
###############################################################################
# export sx_kernel_packages_build_only, if set to "0" => sx_kernel packages built but not installed.
# export disable_sx_kernel_packages_install  , if set to "1" => sx_kernel packages isn't built or installed at all.


###############################################################################
#                                Local functions                              #
###############################################################################

ex() {
	echo "EXEC: $@" >> $LOGFILE
	eval $@ >> $LOGFILE 2>&1
	if [ "$?" != "0" ]; then
		echo "$@   FAILED - $LOGFILE Tail:"
		echo ""
		timeout 5 tail -80 $LOGFILE | grep .
		echo ""
		echo "$@   FAILED"
		echo "Please review $LOGFILE (Tail snippet listed above)"
		exit 1
	fi
}

print_error_and_fail() {
	echo "$@" >> $LOGFILE
	echo "install.sh failed - $LOGFILE Tail:"
	echo ""
	timeout 5 tail -80 $LOGFILE | grep .
	echo ""
	echo "install.sh failed (Tail snippet listed above)"
	echo "Please review $LOGFILE"
	exit 1
}

check_dpkg_lock() {
	local pkgs="${1}"
	for i in {1..60}; do
		locked_pid="$(timeout -s SIGKILL 10s lsof -P /var/lib/dpkg/lock | grep -v PID | grep -v grep | head -n1 | awk '{print $2}')"
		if [ "x${locked_pid}" == "x" ]; then break; fi
		if [ "x${i}" == "x60" ]; then
			proc_info="$(ps -ef | grep ${locked_pid} | grep -v grep)"
			print_info_and_stdout "-E- dpkg process still locked by PID ${locked_pid}"
			print_info_and_stdout "${proc_info}"
			print_error_and_fail "dpkg lock still held after 60 seconds, cannot install DEB Packages of ${pkgs}"
		fi
		sleep 1
	done
}

basedir=${package_dir}

test_root_available_storage() {
	limit=$1

	res_array=$(df / 2>/dev/null | grep / )

	current_space=`echo $res_array | cut -d " " -f 4 | sed -e "s/ //g" `

	if [ "x${current_space}" == "x" ] ; then
		print_error_and_fail "Invalid root partition available space: ${current_space}"
	fi

	non_numeric_current_space=`echo ${current_space} | sed -e "s/[0-9]//g"`

	if [ "x${non_numeric_current_space}" != "x" ] ; then
		print_error_and_fail "Invalid root partition available space: ${current_space}"
	fi

	if (( ${current_space} < ${limit} )) ; then
		print_error_and_fail "Insufficient root partition available space: ${current_space} KB < required ${limit} KB"
	fi
	print_info_and_stdout "Sufficient root partition available space: ${current_space} KB >= required ${limit} KB"
}

sx_kernel_sx_ib_kernel_env_set () {
	# SX_KERNEL Packaged before sx_ib_kernel - We need to set the parameters below after sx_kernel packaging/build/
	# sx_kernel_latest_package can be determined only after sx_kernel tar gz was actually extracted
	# sx_ib_kernel_env/rpm configuration is dependent on sx_kernel_latest_package
	sx_kernel_latest_package=`ls -td ${topdir}/BUILD/sx_kernel* | head -n 1| cut -d":" -f 1`
	sx_kernel_dir_name=`echo ${sx_kernel_latest_package} | awk -F/ '{print $(NF)}'`
	sx_ib_kernel_env_configure_flags="${sx_ib_kernel_env_configure_flags} SX_KERNEL_DIR=../${sx_kernel_dir_name} SX_KERNEL_SYMVERS=${sx_kernel_latest_package}/Module.symvers KBLD=${kernel_sources}"
	sx_ib_kernel_rpm_defines="${sx_ib_kernel_rpm_defines} --define 'SX_KERNEL_SYMVERS ${sx_kernel_latest_package}/Module.symvers'"
}

# CMake helpers (assume use_cmake = 1)
cmake_extract_sources() {
	print_info_and_stdout "CMake extracting sys_sdk"
	ex rm -rf ${topdir}/BUILD/${cmake_extract_sources_dir_name}
	ex mkdir -p ${topdir}/BUILD/${cmake_extract_sources_dir_name}
	ex pushd ${topdir}/BUILD/${cmake_extract_sources_dir_name}
	ex tar -xzf ${basedir}/SOURCES/${cmake_extract_sources_dir_name}*
	ex popd
}

cmake_build_sources() {
	print_info_and_stdout "CMake building sys_sdk"
	ex pushd ${topdir}/BUILD/${cmake_extract_sources_dir_name}
	ex cmake -B builds/cmake ${cmake_defines}
	ex cmake --build builds/cmake $DEB_PARALLEL -v
	ex popd
}

cmake_install_sources() {
	print_info_and_stdout "CMake installing sys_sdk"
	ex pushd ${topdir}/BUILD/${cmake_extract_sources_dir_name}
	ex cmake --install builds/cmake ${cmake_install_prefix}
	ex popd
}

cmake_pack_debian() {
	print_info_and_stdout "CMake building Debian packages"
	ex pushd ${topdir}/BUILD/${cmake_extract_sources_dir_name}/builds/cmake
	ex cpack -G DEB
	ex cp -fv ${cmake_deb_package_file_name_main} ${topdir}/DEBIAN
	ex cp -fv ${cmake_deb_package_file_name_dev} ${topdir}/DEBIAN
	ex cp -fv ${cmake_deb_package_file_name_dbgsym} ${topdir}/DEBIAN
	ex popd
}

cmake_install_debian() {
	check_dpkg_lock "${cmake_deb_package_file_name}"

	print_info_and_stdout "CMake installing ${cmake_deb_package_file_name_main} Debian package"
	ex dpkg -i --force-all ${topdir}/DEBIAN/${cmake_deb_package_file_name_main}

	print_info_and_stdout "CMake installing ${cmake_deb_package_file_name_dev} Debian package"
	ex dpkg -i --force-all ${topdir}/DEBIAN/${cmake_deb_package_file_name_dev}

	print_info_and_stdout "CMake installing ${cmake_deb_package_file_name_dbgsym} Debian package"
	ex dpkg -i --force-all ${topdir}/DEBIAN/${cmake_deb_package_file_name_dbgsym}
}

cmake_pack_rpm() {
	print_info_and_stdout "CMake building ${cmake_rpm_package_file_name} binary RPM package"
	ex pushd ${topdir}/BUILD/${cmake_extract_sources_dir_name}/builds/cmake
	ex cpack -G RPM
	ex cp -fv ${cmake_rpm_package_file_name} ${topdir}/RPMS
	ex popd
}

cmake_install_rpm() {
	print_info_and_stdout "CMake installing ${cmake_rpm_package_file_name} binary RPM package"
	ex rpm -ivh $topdir/RPMS/${cmake_rpm_package_file_name} --force
}
# CMake helpers - END

extract_sources() {

	print_info_and_stdout "Extracting source tars from ${basedir}"

	for sx_package in ${sx_packages}
	do
		sx_package_name=$(eval echo \${${sx_package}_name})
		sx_package_name=${sx_package_name:-${sx_package}}
		print_info_and_stdout "Extracting $sx_package"
		ex rm -rf ${topdir}/BUILD/${sx_package_name}*
		ex pushd ${topdir}/BUILD
		ex tar -xzf ${basedir}/SOURCES/${sx_package_name}-*
		ex popd
	done

}

package_rpm_defines_to_package_debian_defines() {
	split_rpm_defines=($(echo ${package_rpm_defines} | sed 's/\s/\n/g'))
	package_debian_defines=""
	replace_define=0
	for i in "${split_rpm_defines[@]}"
	do
		if [ "--define" == "$i" ]; then
			package_debian_defines="${package_debian_defines}-e "
			replace_define=1
		elif [[ $replace_define == 1 ]]; then
			package_debian_defines="${package_debian_defines}$i="
			replace_define=0
		else
			package_debian_defines="${package_debian_defines}$i "
		fi
	done

	# Repalce 'SPACE' with ' '. Unique case for debian defines that allow spaces in them (e.g. python_sdk_api_interpreters)
	package_debian_defines=${package_debian_defines//SPACE/ }
}

build_package_debian() {
	sx_package=$1
	print_info_and_stdout "Building Debian ${sx_package} package"

	sx_package_name=$(eval echo \${${sx_package}_name})
	if [ -z ${sx_package_name} ] ; then
		#Empty package name for package ${sx_package}, default replace \"_\" with \"-\""
		sx_package_name=`echo ${sx_package} | sed -e 's/_/-/g'`
		sx_package_name_tarball=${sx_package}
	else
		sx_package_name_tarball=$(eval echo \${${sx_package}_name})
	fi

	sx_package_debian_major_name=$(eval echo \${${sx_package}_debian_major_name})
	if [ -z "${sx_package_debian_major_name}" ] ;then
		sx_package_debian_major_name=`echo ${sx_package} | sed -e 's/_/-/g'`
	fi

	ex rm -rf ${topdir}/BUILD/${sx_package_name_tarball}*
	ex pushd ${topdir}/BUILD
	ex tar -xzf ${basedir}/SOURCES/${sx_package_name_tarball}-*

	debian_package_orig_filename="${sx_package_debian_major_name}.orig.tar.gz"

	ex rm -fv ${debian_package_orig_filename}
	ex ln -s ${basedir}/SOURCES/${sx_package_name_tarball}-* ${debian_package_orig_filename}

	latest_package=`ls -ltrd ${topdir}/BUILD/${sx_package_name_tarball}* | grep ^d | awk '{print $NF}' | tail -1`

	ex pushd ${latest_package}
	package_rpm_defines=$(eval echo \${${sx_package}_rpm_defines})
	package_rpm_defines_to_package_debian_defines
	echo -e _prefix=$prefix package_debian_defines=${package_debian_defines}
	ex debuild -e PATH -e _prefix=$prefix ${package_debian_defines} -us -uc $DEB_PARALLEL --ignore-builtin-builddeps

	PACKAGES_LIST=`find ../ -name "*.deb" | grep -i ${sx_package_debian_major_name} | grep -v static`
	for i in $PACKAGES_LIST  ; do cp -fv $i ${topdir}/DEBIAN ; done
	print_info_and_stdout "You may find available ${sx_package} Debian packages at ${topdir}/DEBIAN"
}

install_package_debian() {
	sx_package=$1
	print_info_and_stdout "Installing Debian ${sx_package} packages"

	sx_package_name=$(eval echo \${${sx_package}_name})
	if [ -z ${sx_package_name} ] ; then
		#Empty package name for package ${sx_package}, default replace \"_\" with \"-\""
		sx_package_name=`echo ${sx_package} | sed -e 's/_/-/g'`
	fi

	sx_package_debian_major_name=$(eval echo \${${sx_package}_debian_major_name})
	if [ -z "${sx_package_debian_major_name}" ] ;then
		sx_package_debian_major_name=`echo ${sx_package} | sed -e 's/_/-/g'`
	fi

	PACKAGES_LIST=`find ${topdir}/DEBIAN -name "*.*deb" | grep -i ${sx_package_debian_major_name} | grep -v static`
	check_dpkg_lock "${PACKAGES_LIST}"
	ex dpkg -i --force-all ${PACKAGES_LIST}

	# Cleanup
	find ${topdir}/BUILD/ -maxdepth 1 -name "${sx_package_debian_major_name}*" -exec rm -f {} \;
}


build_packages_debian_wrapper() {
	package_list="$1"
	failed_packages=""

	if [ "x${with_sx_parallel_build}" == "x1" ] ; then
		print_info_and_stdout "Parallel Building Debian packages: ${package_list}"
		declare -A pid_package_dict
		for package_name in ${package_list}; do
			build_package_debian "${package_name}" & pid=$!   # Run in background and save PID
			trap "kill -9 $pid 2>/dev/null" SIGINT INT EXIT  # Kill process on failure if such occur
			pid_package_dict["$package_name"]="$pid"
			echo "Debian packing process for package ${package_name} = $pid"
		done

		for pkg in "${!pid_package_dict[@]}"; do                           # Wait for all PIDs to finish
			pid=${pid_package_dict[$pkg]}
			if wait "$pid"; then
				echo "Debian packing for package = $pkg (PID $pid) finished success"
			else
				echo "Debian Packing for package = $pkg (PID $pid) failed, will try again"
				failed_packages="${failed_packages} $pkg"
			fi
		done

		if [[ "${failed_packages}" != "" ]]; then
			echo "Failed to pack some DEB Packages, will try to repack 1-by-1"
			for package_name in ${failed_packages}; do
				build_package_debian "${package_name}"
			done
		fi
	else
		for package_name in ${package_list}; do
			build_package_debian "${package_name}"
		done
	fi
}

re_package_debian() {
	sx_package=$1
	sx_package_location=$2
	print_info_and_stdout "Building Debian ${sx_package} package"

	#major_name
	sx_package_debian_major_name=$(eval echo \${${sx_package}_debian_major_name})
	if [ -z "${sx_package_debian_major_name}" ] ;then
		sx_package_debian_major_name=`echo ${sx_package} | sed -e 's/_/-/g'`
	fi

	ex pushd ${sx_package_location}
	package_rpm_defines=$(eval echo \${${sx_package}_rpm_defines})
	package_rpm_defines_to_package_debian_defines
	echo -e _prefix=$prefix package_debian_defines=${package_debian_defines}
	ex debuild -e PATH -e _prefix=$prefix ${package_debian_defines} -us -uc --ignore-builtin-builddeps

	print_info_and_stdout "You may find available ${sx_package} Debian packages at ${topdir}/DEBIAN_REPACKAGED"
	PACKAGES_LIST=`find ../ -name "*.*deb" | grep -i ${sx_package_debian_major_name} | grep -v static`
	for i in $PACKAGES_LIST  ; do cp -fv $i ${topdir}/DEBIAN_REPACKAGED ; done
	SPACKAGES_LIST=`find ../ -type f  -name "*.tar.gz" | grep -i ${sx_package_debian_major_name}`
	for i in $SPACKAGES_LIST  ; do cp -fv $i ${topdir}/SDEBIAN_REPACKAGED ; done

	# Cleanup
	find ${topdir}/BUILD/ -maxdepth 1  -name "${sx_package_debian_major_name}*" -exec rm -f {} \;
	ex popd
}

build_source() {
	sx_package=$1

	if [ "x" == "x$2" ]; then
		package_configure_flags=$(eval echo \${${sx_package}_configure_flags})
	else
		package_configure_flags=$2
	fi
	package_env_configure_flags=$(eval echo \${${sx_package}_env_configure_flags})
	package_extra_make_flags=$(eval echo \${${sx_package}_extra_make_flags})
	package_extra_make_install_flags=$(eval echo \${${sx_package}_extra_make_install_flags})
	package_disable_configure=$(eval echo \${${sx_package}_disable_configure})


	sx_package_name=$(eval echo \${${sx_package}_name})
	sx_package_name=${sx_package_name:-${sx_package}}
	latest_package=`ls -td ${topdir}/BUILD/${sx_package_name}* | head -n 1| cut -d":" -f 1`
	if [ "x${repackage}" == "x1" ];then
		latest_package=`ls -ltrd ${topdir}/BUILD/${sx_package_name}* | grep ^d | awk '{print $NF}' | tail -1`
		re_package_debian $sx_package ${latest_package}
	else
	ex pushd ${latest_package}
	if [ "x$sx_package_name" == "xsx_kernel" ] ; then
		extra_configure_flag="${CROSS_CONFIGURE_FLAGS_KERNEL}"
	else
		if [ "x$sx_package_name" == "xsx_ib_kernel" ] ; then
			extra_configure_flag="${CROSS_CONFIGURE_FLAGS_KERNEL}"
		else
			extra_configure_flag="${CROSS_CONFIGURE_FLAGS}"
		fi
	fi

	if [ "x$sx_package_name" == "xsx_ib_kernel" ] || [ "x$sx_package_name" == "xsx_kernel" ] ; then
		extra_make_flags="${MAKE_INSTALL_KERNEL_FLAGS} ${MAKE_FLAGS_SX_KERNEL}"
		if [ "x${CC}" != "x" ] ; then
			extra_make_flags="${extra_make_flags} CC=\"${CC}\""
		fi
	fi
	ACTIVE_CROSS_COMPILE_ENV="${CROSS_COMPILE_ENV}"

	print_info "configuring enviroment: ${ACTIVE_CROSS_COMPILE_ENV}"
	print_info "configuring enviroment: CFLAGS=${CFLAGS}"
	print_info "configuring enviroment: LDFLAGS=${LDFLAGS}"
	print_info "configuring enviroment: CC=${CC}"

	if [ "x${package_disable_configure}" != "x1" ] ; then
		print_info_and_stdout "configuring ${sx_package_name} with configure flags: ${configure_flags} ${package_configure_flags} ${extra_configure_flag}"
		if [[ ( ! -e Makefile ) || ( "x$sdk_incremental_make" == "x0" ) || (${sx_package_name} == "sx_kernel") || (${sx_package_name} == "sx_ib_kernel") ]] ; then
			print_info_and_stdout configuring ${sx_package_name}
			ex env ${package_env_configure_flags} ${ACTIVE_CROSS_COMPILE_ENV} ./configure ${configure_flags} ${package_configure_flags} ${extra_configure_flag}
		fi
	fi
	print_info_and_stdout making ${sx_package_name}
	ex env ${package_env_configure_flags} ${ACTIVE_CROSS_COMPILE_ENV} make ${MAKEFLAGS} ${extra_make_flags} ${package_extra_make_flags}
	print_info_and_stdout installing ${sx_package_name}
	ex env ${package_env_configure_flags} ${ACTIVE_CROSS_COMPILE_ENV} make ${MAKEFLAGS} ${extra_make_flags} ${package_extra_make_flags} ${package_extra_make_install_flags} install
	extra_make_flags=
	ex popd
	fi
}

build_sources() {
	for sx_package in ${sx_packages}
	do
		build_source ${sx_package}
	done
	if [ "x${disable_sx_kernel_packages_install}" != "x1" ]; then
		if [ "x${ib_package}" == "x1" ] ; then
			case "$(udevinfo -V 2> /dev/null | awk '{print $NF}' 2> /dev/null)" in
			0[1-4]*)
				sed -i -e 's/KERNEL==/KERNEL=/g'  ${etc_prefix}/etc/udev/rules.d/90-ib.rules
				;;
			esac
		fi
	fi
}

copy_source_rpms() {
	for sx_package in ${sx_packages}
	do
		sx_package_name=$(eval echo \${${sx_package}_name})
		sx_package_name=${sx_package_name:-${sx_package}}
		print_info_and_stdout "Copying SRPM for package ${sx_package_name}"
		ex rpm -ivh --define \'_topdir $topdir\' $basedir/SRPMS/${sx_package_name}*
	done
}
build_binary_rpms() {
	sx_package=$1

	sx_package_name=$(eval echo \${${sx_package}_name})
	sx_package_name=${sx_package_name:-${sx_package}}

	package_rpm_defines=$(eval echo \${${sx_package}_rpm_defines})
	print_info_and_stdout "Building binary RPM for package ${sx_package_name}"
	ex rpmbuild -bb --define \'_topdir $topdir\' --define \'_prefix ${prefix}\' ${package_rpm_defines} $topdir/SPECS/${sx_package_name}.spec
}

install_binary_rpms() {
	sx_package_rpm=$1
	print_info_and_stdout "Installing binary RPM for package ${sx_package_rpm}"
	ex rpm -ivh $topdir/RPMS/*/${sx_package_rpm}-${package_install_version_rpm}*.rpm --force ${additional_install_rpm_flags}
	print_info_and_stdout "RPMs installed:"
	print_info_and_stdout `rpm -qa | grep ${sx_package_rpm}`
}

install_binary_debuginfo_rpms() {
	sx_package=$1
	sx_package_name=$(eval echo \${${sx_package}_name})
	sx_package_name=${sx_package_name:-${sx_package}}
	print_info_and_stdout "Installing binary RPM for package ${sx_package_name}"
	ex rpm -ivh $topdir/RPMS/*/${sx_package_name}-debuginfo-${package_install_version_rpm}*.rpm --force ${additional_install_rpm_flags}
	print_info_and_stdout "RPMs installed:"
	print_info_and_stdout `rpm -qa | grep ${sx_package_name}`
}

check_input() {
	if   [ "x$1" == "xy" ] \
	  || [ "x$1" == "xyes" ] \
	  || [ "x$1" == "xY" ] \
	  || [ "x$1" == "xYES" ] \
	  || [ "x$1" == "x" ]  ; then
		return 1
	else
		return 0
	fi
}

check_prev_install_python_sdk_api() {
	if [ "x${with_python_sdk_api}" == "x1" ]; then
		SWIG_VERSION=`swig -version | grep "SWIG Version" | awk '{print $3}'`
		if [[ ("x${SWIG_VERSION}" != "x2.0."*) && ("x${SWIG_VERSION}" != "x3.0."*) && ("x${SWIG_VERSION}" != "x4."*) ]] ; then
			echo "-E- swig 2.0.X/3.0.x/4.x.x is needed, current version ${SWIG_VERSION}"
			exit 1
		else
			echo "swig version = ${SWIG_VERSION} -> OK"
		fi
	fi
}

check_min_cmake_version() {
	if [ "x${use_cmake}" == "x1" ]; then
		if ! command -v cmake &> /dev/null
		then
			print_info_and_stdout "-E- CMake is missing, please install."
			exit 1
		else
			CMAKE_VERSION=`cmake --version | grep "cmake version" | awk '{print $3}'`
			CMAKE_VERSION_MIN=3.16.4
			if [ "${CMAKE_VERSION}" != "${CMAKE_VERSION_MIN}" -a ${CMAKE_VERSION} = "`echo -e "${CMAKE_VERSION}\n${CMAKE_VERSION_MIN}" | sort -V | head -n1`" ] ; then
				print_info_and_stdout "-E- Minimum supprted CMake version is ${CMAKE_VERSION_MIN}, current CMake version ${CMAKE_VERSION}."
				exit 1
			else
				print_info_and_stdout "CMake version = ${CMAKE_VERSION} -> OK"
			fi
		fi
	fi
}


check_prev_install() {
	# Uninstall sx_sdk
	for uninstall_location in ${uninstall_dest_folder}/uninstall_sx_sdk.sh ${prefix}/uninstall_sx_sdk.sh /usr/bin/uninstall_sx_sdk.sh /usr/local/bin/uninstall_sx_sdk.sh
	do
	if [ -x ${uninstall_location} ]; then
		if [ "${batch}" == "no" ]; then
			echo -n "Remove currently installed sx sdk components in ${prefix} by ${uninstall_location} (y/n) [y] ? "
			read force
		else
			force="yes"
		fi
		check_input ${force}
		RC=$?
		if [ $RC == 1 ]; then
			print_info_and_stdout "Cleaning an old distribution at ${prefix}"
			print_info_and_stdout "Running: ${uninstall_location}"
			ex ${uninstall_location}
			ex rm -fv ${uninstall_location}
		else
			echo "Cannot continue without removing sx_sdk first."
			exit 1
		fi
	fi
	if [ "x${ib_package}" == "x1" ]; then
		if [ "x${ignore_ofed_installation}" != "x1" ] ; then
			ofed_uninstall_location=`which ofed_uninstall.sh 2>/dev/null`
			if [ "x${ofed_uninstall_location}" != "x" ]; then
				if [ "${batch}" == "no" ]; then
					echo -n "Remove currently installed OFED components (y/n) [y] ? "
					read force
				else
					force="yes"
				fi
				check_input ${force}
				RC=$?
				if [ $RC == 1 ]; then
					echo "Cleaning OFED installation by ${ofed_uninstall_location}"
					echo y | ${ofed_uninstall_location}
					RC=$?
					if [ $RC != 0 ]; then
						echo "Failed to uninstall OFED"
						exit 1
					fi
				else
					echo "Cannot continue without removing OFED first."
					exit 1
				fi
			fi
			opensm_location=`which opensm 2>/dev/null`
			if [ "x${opensm_location}" != "x" ]; then
				echo "Detected opensm on ${opensm_location} although system has no OFED"
				echo "Consider to clean IB installation first"
			fi
		fi
	fi
	done
}

# Check that a previous version is loaded
check_loaded_modules() {
	if [ ! -z `/sbin/lsmod | grep sx > /dev/null 2>&1` ]; then
		if [ "${batch}" == "no" ]; then
			echo; echo "   In order for newly installed sx modules to load, "
			echo "   previous modules must first be unloaded."
			echo -n "   Do you wish to unload now? (y/n) [y] "
			read force
		else
			force="yes"
		fi
		check_input ${force}
		RC=$?
		if [ ${RC} == 1 ]; then
			print_info_and_stdout "Unloading memtrack modules"
			if [ "${with_memtrack}" == "1" ]; then
				/sbin/rmmod memtrack > /dev/null
			fi
			print_info_and_stdout "Unloading sx modules"
			ex ${prefix}/etc/init.d/sxdkernel stop
		else
			print_info_and_stdout "WARNING: Loading the new installed modules could cause symbol confilcts"
			print_info_and_stdout "         Please unload all prevoius versions of sx modules"
			echo
		fi
	fi
}

if [ "x${package_install_mode}" == "xvpi" ] ; then
	vpi_mode_extra_options="
			 [--ib-libs-precompiled]: do not compile ib packages"
	default_configuration="
	ib_package=1
	eth_package=1
	ib_nvlink_package=0
	app_main_dir=applibs
	"
elif [ "x${package_install_mode}" == "xib_nvlink" ]; then
	default_configuration="
	use_cmake=1
	ib_package=0
	eth_package=0
	ib_nvlink_package=1
	app_main_dir=ib_nvlink_applibs
	"
else
	default_configuration="
	ib_package=0
	eth_package=1
	ib_nvlink_package=0
	app_main_dir=applibs
	"
fi

usage()
{
cat << EOF

		Usage: `basename $0` [--help]: Prints this message
			 [--batch]: Remove all installed components without promt.
			 [--with-memtrack]: Add memtrack support to sx_kernel package.
			 [--with-sxd-sniffer]: Compile with SXD Sniffer support.
			 [--kernel-version]: Use non-default kernel version for sx_kernel package.
			 [--kernel-sources]: Use non-default kernel sources for sx_kernel package.
			 [--kernel-headers]: Use pre-generated kernel headers.
			 [--prefix]: Change default packages install prefix from ${prefix} to custom path <prefix>.
			 		If custom prefix is set, user must perform post env settings after installation:
			 		1) Append <prefix>/usr/bin to env PATH ('export PATH=\$PATH:<prefix>/usr/bin')
			 		2) Append <prefix>/usr/lib to env LD_LIBRARY_PATH ('export LD_LIBRARY_PATH=\$LD_LIBRARY_PATH:<prefix>/usr/lib')
			 		3) Export SX_SDK_CUSTOM_PREFIX Environment, in order to use sx-examples properly ('export SX_SDK_CUSTOM_PREFIX=<prefix>')
			 [--use-sources]: Install from SOURCES folder instead of using binary RPMs, for easier source changes.
			 [--without-kernel]: Exclude SDK kernel drivers install.
			 [--without-sx-examples]: Exclude sx examples install.
			 [--without-obj-desc-lib]: Exclude obj_desc_lib install.
			 [--without-wjh-lib]: Exclude WJH library install.
			 [--without-python-sdk-api]: Exclude python_sdk_api install.
			 [--python-sdk-api-interpreters]: Choose python interpreter(s) for python_sdk_api compilation, separated by SPACE.
				Default: "${python_sdk_api_interpreters}. Currently Supported: "${python_sdk_api_supported}"
			 [--no-optimization]: Compile with -O0 flag.
			 [--kernel-only]: Install kernel package only.
			 [--enable-debug]: add debug compilation flags
			 [--reserve-sources]: do not overwrite /usr/src/sx_sdk/BUILD folders
			 [--disable-parallel-build]: Do not add -j flag to make
			 [--build-root]: Change build root folder [default is /usr/src/sx_sdk]
			 [--enable-pd]: Compile for palladium
			 [--re-package]: Re-package packages(*.deb,*.rpm) in order to update external repositories(without installation)
			 [--ofed-headers]: location of OFED drivers headers
			 [--use-cmake]: Build and install with CMake.
			 [--asan]: Build SDK with address sanitizer support, can be provided only when --use-cmake is provided.
			 [--use-fuse]: Build SDK with FUSE dump support.
			 [--enable-release]: Add Release compilation flag, can be provided only when --use-cmake is provided.
EOF
}

build_and_install_packages()
{
	local sx_current_packages=$1
	local install_flag=$2
	if [ "x${sx_current_packages}" != "x" ] ; then
		for sx_package in ${sx_current_packages}
		do
			build_binary_rpms ${sx_package}
			sx_package_rpms=$(eval echo \${${sx_package}_rpms})
			sx_package_rpms=${sx_package_rpms:-${sx_package}}
			if [ "${install_flag}" != "build_only" ] ;then
				for required_rpm in ${sx_package_rpms}
				do
					install_binary_rpms ${required_rpm}
				done
			else
				print_info_and_stdout "Skipping install for \"${sx_package_rpms}\" packages, only build package preformed"
			fi
		done
	fi
}

###############################################################################
#                          Parsing command line                               #
###############################################################################
while [ ! -z "$1" ]; do
	case "$1" in
	-h|--help)
		usage
		exit 0
		;;
    --x86_64-cross-compile)
        use_cross_compiler="1"
        use_sources="1"
        if [ "x${manual_prefix_set}" != "x1" ] ; then
            prefix=/tmp/sdk_output_x86_64/usr
        fi
        ;;
	--with-sxd-sniffer)
		enable_sxd_sniffer="yes"
		;;
	-b|--batch)
		batch="yes"
		;;
	--reserve-sources)
		extract_sources="0"
		use_sources="1"
		;;
	--use-sources)
		use_sources="1"
		;;
	--use-cmake)
		use_cmake=1
		;;
	--asan)
		asan="1"
		;;
	--with-memtrack)
		with_memtrack="1"
		;;
	--enable-ecmp-simulator)
		enable_ecmp_sim="1"
		;;
	--kernel-version)
		kernel_version="$2"
		shift
		;;
	--use-fuse)
		use_fuse="1"
		;;
	--kernel-sources)
		kernel_sources="$2"
		shift
		;;
	--kernel-headers)
		kernel_headers="$2"
		shift
		;;
	--prefix)
		prefix="$2"
		manual_prefix_set="1"
		cmake_install_prefix="--prefix ${prefix}"
		shift
		;;
	--build-root)
		topdir="$2"
		shift
		;;
    --with-debug-info)
        with_debug_info="1"
        ;;
	--enable-release)
		compile_release="1"
		;;
	--enable-debug)
		user_level_debug_enabled="1"
		;;
	--kernel-only)
		kernel_only="1"
		;;
	--without-sx-examples)
		with_sx_examples="0"
		;;
	--without-obj-desc-lib)
		with_obj_desc_lib="0"
		;;
	--without-wjh-lib)
		with_wjh_lib="0"
		;;
	--without-python-sdk-api)
		with_python_sdk_api="0"
		;;
	--python-sdk-api-interpreters)
		python_set_by_user=1
		python_sdk_api_interpreters="$2"
		shift
		;;
	--no-optimization)
		no_optimization="1"
		;;
	--disable-parallel-build)
		with_sx_parallel_build="0"
		;;
	--without-kernel)
		disable_sx_kernel_packages_install=1
		;;
	--ofed-headers)
		OFED_KERNEL_HEADERS="$2"
		shift
		;;
	--enable-pd)
		with_pd_build="1"
		;;
	--re-package)
		repackage="1"
		use_sources="1"
		extract_sources="0"
		;;
	--ib-libs-precompiled)
		ib_precompiled=1
		;;
	@EXTRA_PARAMS_CASE_OPTIONS@
	*)
		usage
		echo "Bad input parameter: $1. Check usage above."
		exit 1
		;;
	esac
	shift
done

if [ "x${manual_flags}" == "x0" ]; then
	eval ${default_configuration}
fi

# Verify CMake is supported
check_min_cmake_version

# Debian VPI build, without CMake, is not supported
if [ "x${ib_package}" == "x1" -a "x${use_cmake}" == "x0" -a "x${use_sources}" == "x" ]; then
	print_info_and_stdout "-E- Known Issues, DEB Build without CMake for VPI is not supported."
	exit 1
fi

if [ "x${use_cmake}" != "x1" -a "x${asan}" == "x1" ]; then
	print_info_and_stdout "-E- Address sanitizer currently is only supported in CMake build."
	exit 1
fi

# Verify python SDK API Interpreters chosen are all supported
OLD_IFS="$IFS"
IFS=' ' # Setting space as delimiter
read -ra PYTHON_SDK_API_INTERPRETERS_VERSIONS <<< "${python_sdk_api_interpreters}"
for interpreter in "${PYTHON_SDK_API_INTERPRETERS_VERSIONS[@]}"; do
	if [[ ${python_sdk_api_supported} != *"${interpreter}"* ]]; then
		usage
		echo "Python SDK API Interpreter chosen (${interpreter}) is not supported - Check usage"
		exit 1
	fi
done
IFS="$OLD_IFS"

if [ "x${repackage}" == "x1" -a "x$debian_detection" == "x" ] ; then
	print_info_and_stdout "Known Issues, re-package is available only for Debian OS"
	exit 1
else
	#Cleaning old repackaging artifacts
	rm -rf ${topdir}/{DEBIAN,SDEBIAN_REPACKAGED,DEBIAN_REPACKAGED}
	#Creating directories for repackaging artifacts
	mkdir -p ${topdir}/{SDEBIAN_REPACKAGED,DEBIAN_REPACKAGED}
fi

# Verify libnl3 prerequisites
if [ "x$debian_detection" != "x" ]; then
	for required_debian_package in libnl-3-dev libnl-genl-3-dev
	do
		if ! ( dpkg --list | grep "ii  ${required_debian_package}" 1>/dev/null ) ; then
			print_info_and_stdout "${required_debian_package} is required for SDK install"
			print_info_and_stdout "Please install required dependency using: 'apt-get install ${required_debian_package}'"
			exit 1
		fi
	done
else
	for required_package in libnl3-devel libnl3
	do
		if ! ( yum list installed | grep "${required_package}" 1>/dev/null ) ; then
			print_info_and_stdout "${required_package} is required for SDK install"
			print_info_and_stdout "Please install required dependency using: 'yum -y install ${required_package}'"
			exit 1
		fi
	done
fi

# Verify fuse3 exists
verlte() {
[  "$1" = "`echo -e "$1\n$2" | sort -V | head -n1`" ]
}
if [ "x${use_fuse}" == "x1" ]; then
	if [ "x$debian_detection" != "x" ]; then
		for required_debian_package in libfuse3-3 libfuse3-dev
		do
			if ! ( dpkg --list | grep "ii  ${required_debian_package}" 1>/dev/null ) ; then
				print_info_and_stdout "${required_debian_package} is required for SDK install with '--use-fuse'"
				print_info_and_stdout "Please install required dependency using: 'apt-get install ${required_debian_package}'"
				exit 1
			fi
		done
		fuse_version=`dpkg -l | grep "libfuse3-3" | head -n1 | awk '{print $3}' | cut -d'-' -f1`
		verlte ${fuse_version} 3.2.1 && print_error_and_fail "Found Fuse: ${fuse_version}. Only version 3.2.2 and above are supported." || print_info_and_stdout "Found FUSE: ${fuse_version}"
	else
		for required_package in fuse3-libs fuse3-devel
		do
			if ! ( yum list installed | grep "${required_package}" 1>/dev/null ) ; then
				print_info_and_stdout "${required_package} is required for SDK install with '--use-fuse'"
				print_info_and_stdout "Please install required dependency using: 'yum -y install ${required_package}'"
				exit 1
			fi
		done
		fuse_version=`yum list installed | grep "fuse3-libs" | head -n1 | awk '{print $2}' | cut -d'-' -f1`
		verlte ${fuse_version} 3.2.1 && print_error_and_fail "Found Fuse: ${fuse_version}. Only version 3.2.2 and above are supported." || print_info_and_stdout "Found FUSE: ${fuse_version}"
	fi
	applibs_additional_configure_flags+=" --with-fuse"
fi
cmake_defines+=" -DUSE_FUSE=${use_fuse}"

if [ "x${with_pd_build}" == "x1" ] ; then
	for p in sxd_libs ${app_main_dir} sx_examples
	do
		eval "$(echo ${p}_additional_configure_flags)=\"$(echo \${${p}_additional_configure_flags} --enable-pd)\""
	done
	for p in sx_kernel sx_ib_kernel
	do
		eval "$(echo ${p}_env_configure_flags)=\"$(echo \${${p}_env_configure_flags} KCFLAGS=\\\"${KCFLAGS} -DPD_BU\\\")\""
	done
fi
cmake_defines+=" -DPD_PRESENT=${with_pd_build}"

sxd_libs_additional_configure_flags="${sxd_libs_additional_configure_flags} --enable-sniffer=${enable_sxd_sniffer}"
if [ "x${enable_sxd_sniffer}" == "xyes" ]; then
	sxd_libs_rpm_defines="${sxd_libs_rpm_defines} --define 'SXD_SNIFFER 1'"
fi
cmake_defines+=" -DSNIFFER_PRESENT=${enable_sxd_sniffer}"

if [ "x$use_cross_compiler" == "x0" ]; then
    if [ $UID -ne 0 ]; then
        echo Must be root to run this script.
        exit 1
    fi
fi

if [ "x$debian_detection" != "x" ]; then
	if [ "x$nvidia_dvs_os" = "x1"  ] ; then
		if [ "x$package_install_mode" = "xvpi" ] ; then
			glib2_devel_found=`dpkg --list | grep libglib2.0-dev`
			if [ "x$?" != "x0" ] ; then
				print_info_and_stdout "libglib2.0-dev is missing from DVS OS"
				print_info_and_stdout "Please review the NVIDIA SwitchX(R) SDK Release Notes for VPI Development Kit,"
				print_info_and_stdout "Known Issues, for more details / libglib2.0-dev_2.33.12+really2.32.4-5_amd64.deb mirroring"
				exit 1
			fi
		fi
	fi
fi

if [ ! -z "${kernel_sources}" ] ; then
	observed_jernel_version=`cat ${kernel_sources}/include/config/kernel.release`
	if [ "x${observed_jernel_version}" == "x${kernel_version}" ]; then
		echo "kernel_version = ${kernel_version} verified by include/config/kernel.release"
	else
		echo "Updating kernel_version from ${kernel_version} to observed kernel version ${observed_jernel_version} retrieved from include/config/kernel.release"
		kernel_version=${observed_jernel_version}
	fi
fi

if [ -z "${kernel_version}" ]; then
	echo "Kernel version not provided, will set to 'uname -r'"
	kernel_version=$(uname -r)
	echo "Kernel Version detected (uname -r): ${kernel_version}"
	echo "Full Kernel Version (uname -a): $(uname -a)"
fi

DEB_PARALLEL=""
if [ "x${with_sx_parallel_build}" == "x1" ] ; then
	export MAKEFLAGS="-j$(nproc)"
	DEB_PARALLEL="-j$(nproc)"
fi
cmake_defines+=" -DENABLE_PARALLEL_BUILD=${with_sx_parallel_build}"

infiniband_diags_additional_configure_flags="${infiniband_diags_additional_configure_flags} --enable-test-utils"
hw_platform=`uname -m`
if [ "x${hw_platform}" == "xi386" -o "x${hw_platform}" == "xx86_64" ] ; then
	MAKE_FLAGS_SX_KERNEL="SUBARCH=x86"
fi
# will be overrided if we use cross compiler option

if lscpu | grep -qEs 'ARM|aarch64' || uname -m | grep -qEs 'aarch64'; then
	ARCH=arm64
else
	ARCH=x86
fi

ex mkdir -p ${prefix}
ex pushd ${prefix}/..
etc_prefix=`pwd`
popd

LDFLAGS="${LDFLAGS} -L${prefix}/lib"
LDFLAGS+=" -Wl,-z,now -Wl,-z,relro"

if [ "x${use_cross_compiler}" == "x1"  ]; then

    CFLAGS="${CFLAGS} -I${prefix}/include"
    CXXFLAGS="${CXXFLAGS} -I${prefix}/include"

    ignore_ofed_installation=1

    prefix_init_folder=`echo ${etc_prefix} | cut -b-4`
    if [ "x${prefix_init_folder}" == "x/tmp" ]; then
        ex rm -rfv ${etc_prefix}
    fi

    infiniband_diags_additional_configure_flags="${infiniband_diags_additional_configure_flags} --with-ibpath_override=/usr/sbin --with-perl-installdir=${etc_prefix}"
fi

if [ "x${embedded_kernel_drivers_install}" == "x1" ]; then
	MAKE_INSTALL_KERNEL_FLAGS="DESTDIR=${etc_prefix} INSTALL_MOD_PATH=${etc_prefix}"
fi

ex export LDFLAGS
ex export CFLAGS
ex export CXXFLAGS

scewlibs_install_folder="${prefix}"

#required for all modes
sx_packages_first_phase="${sx_packages_first_phase} sx_complib sx_gen_utils sxd_libs"
deb_packages_zero_phase="sx_complib sx_sdk_build"
deb_packages_zero_one_phase="sx_gen_utils"
deb_packages_first_phase="sxd_libs"         # depends on sx_gen_utils

libibmad_env_configure_flags="$libibmad_env_configure_flags CFLAGS=-I${prefix}/include"
infiniband_diags_env_configure_flags="$infiniband_diags_env_configure_flags CFLAGS=-I${prefix}/include CPPFLAGS=-I${prefix}/include"

if [ "x${OFED_KERNEL_HEADERS}" != "x" ]; then
	sx_ib_kernel_env_configure_flags="${sx_ib_kernel_env_configure_flags} OFED_KERNEL_HEADERS=${OFED_KERNEL_HEADERS}"
	sx_ib_kernel_rpm_defines="${sx_ib_kernel_rpm_defines} --define 'OFED_KERNEL_HEADERS ${OFED_KERNEL_HEADERS}'"
fi

if [ ! -z "${kernel_version}" ] ; then
	sx_kernel_configure_flags="${sx_kernel_configure_flags} --kernel-version=${kernel_version}"
	sx_kernel_rpm_defines="${sx_kernel_rpm_defines} --define 'KVERSION ${kernel_version}'"
	sx_ib_kernel_configure_flags="${sx_ib_kernel_configure_flags} --kernel-version=${kernel_version}"
	sx_ib_kernel_rpm_defines="${sx_ib_kernel_rpm_defines} --define 'KVERSION ${kernel_version}'"
	wjh_libs_configure_flags="${wjh_libs_configure_flags} --with-kernel-version=${kernel_version}"
	wjh_libs_rpm_defines="${wjh_libs_rpm_defines} --define 'KVERSION ${kernel_version}'"
fi

if [ ! -z "${kernel_sources}" ] ; then
	sx_kernel_configure_flags="${sx_kernel_configure_flags} --kernel-sources=${kernel_sources}"
	sx_kernel_rpm_defines="${sx_kernel_rpm_defines} --define 'K_SRC ${kernel_sources}'"
	sx_ib_kernel_configure_flags="${sx_ib_kernel_configure_flags} --kernel-sources=${kernel_sources}"
	sx_ib_kernel_rpm_defines="${sx_ib_kernel_rpm_defines} --define 'K_SRC ${kernel_sources}'"
	wjh_libs_configure_flags="${wjh_libs_configure_flags} --with-kernel-sources=${kernel_sources}"
	wjh_libs_rpm_defines="${wjh_libs_rpm_defines} --define 'K_SRC ${kernel_sources}'"
	kernel_headers_folder=${topdir}/BUILD/sx_sdk_kernel_headers
	pushd ${kernel_sources}
	grep "static Linetype\W*getline" scripts/unifdef.c
	if [ "x$?" == "x0"  ] ; then
		patch -p 1 -i ${basedir}/patches/0001-renaming-static-getline-in-scripts-unifdef.c-to-avoi.patch
	fi
	popd
	if [ ! -z "${kernel_headers}" ]; then
		kernel_headers_folder=$kernel_headers
	else
		ex mkdir -p ${kernel_headers_folder}
		ex env ${CROSS_COMPILE_ENV} make -C ${kernel_sources} headers_install ARCH=${ARCH} INSTALL_HDR_PATH=${kernel_headers_folder}
	fi
	applibs_additional_configure_flags="${applibs_additional_configure_flags} --with-alt-kernel-headers=${kernel_headers_folder}/include"
	wjh_libs_additional_configure_flags="${wjh_libs_additional_configure_flags} --with-alt-kernel-headers=${kernel_headers_folder}/include"
fi

wjh_libs_configure_flags="${wjh_libs_configure_flags} --with-wjh-arch=${ARCH}"
wjh_libs_rpm_defines="${wjh_libs_rpm_defines} --define 'WJH_ARCH ${ARCH}'"

if [ "x${with_memtrack}" == "x1" ]; then
	for p in sx_kernel sx_ib_kernel
	do
		eval "$(echo ${p}_additional_configure_flags)=\"$(echo \${${p}_additional_configure_flags} --with-memtrack)\""
		eval "$(echo ${p}_extra_naming)=\"$(echo \${${p}_extra_naming}.memtrack)\""
	done
fi
cmake_defines+=" -DMEMTRACK=${with_memtrack}"

sx_packages_third_phase="sx_scew"
deb_packages_third_phase="sx_scew"

if [ "x${with_python_sdk_api}" == "x1" ]; then
	# User did not set custom python: Validate the default (python3) available
	if test -z "${python_set_by_user}" && ! which python3 > /dev/null 2>&1; then
		print_info_and_stdout "-E- No python interpreters found - Cannot compile Python SDK API"
		print_info_and_stdout "Use --without-python-sdk-api if that's expected"
		exit 1
	fi

	sx_packages_third_phase="${sx_packages_third_phase} python_sdk_api"
	deb_packages_third_phase="${deb_packages_third_phase} python_sdk_api"
	python_sdk_api_env_configure_flags="echo=echo PYTHON_INTERPRETERS='${python_sdk_api_interpreters}'"
	python_sdk_api_configure_flags="--with-python-sdk-api-interpreters='${python_sdk_api_interpreters}'"
	python_sdk_api_rpm_defines="--define 'PYTHON_INTERPRETERS ${python_sdk_api_interpreters}'"
	cmake_defines+=" -DPYTHON_INTERPRETERS=\"${python_sdk_api_interpreters}\""

	if [[ "$(echo \"${python_sdk_api_interpreters}\" | wc -w)" == "1" ]]; then
		PY_VERSION=`echo "${python_sdk_api_interpreters}" | tr -dc '0-9,.'`
		PYTHON_LINK_LIB=`pkg-config --libs ${python_sdk_api_interpreters}`
		python_sdk_api_configure_flags="PYTHON_VERSION=${PY_VERSION} PYTHON_LDFLAGS=${PYTHON_LINK_LIB} ${python_sdk_api_configure_flags}"
	fi

	# Python interpreters support multiple versions separated by a space
	# For RPM Building - we don't care, the rpm_defines will be parsed as is with the spaces
	# For DEB Packaging - Later in package_rpm_defines_to_package_debian_defines(),
	# In order to properly use debuild defines, string is split based on spaces.
	# To WA This - We replace ' ' with 'SPACE' in such case, and later in package_rpm_defines_to_package_debian_defines() will replace back

	spaces_regex=" |'"
	if [[ $python_sdk_api_interpreters =~ $spaces_regex ]]; then
		if [ "x${debian_detection}" != "x" ]; then
			python_sdk_api_interpreters=${python_sdk_api_interpreters// /SPACE}
		fi
		python_sdk_api_rpm_defines="--define 'PYTHON_INTERPRETERS \"${python_sdk_api_interpreters}\"'"
	fi

	if [ "x${with_sx_parallel_build}" == "x1" ] ; then
		python_sdk_api_configure_flags="${python_sdk_api_configure_flags} --enable-parallel-build"
	fi
fi
cmake_defines+=" -DUSE_PYTHON_SDK_API=${with_python_sdk_api}"

if [ "x${ib_package}" == "x1" ]; then
	sx_packages_third_phase="${sx_packages_third_phase} sx_eSMA"
	deb_packages_third_phase="${deb_packages_third_phase} sx_eSMA"
fi
cmake_defines+=" -DIB_PRESENT=${ib_package}"
cmake_defines+=" -DIB_NVLINK=${ib_nvlink_package}"

if [ "x${with_obj_desc_lib}" == "x1" ]; then
	sx_packages_third_phase="${sx_packages_third_phase} sx_obj_desc_lib "
	deb_packages_third_phase="${deb_packages_third_phase} sx_obj_desc_lib"        # ObjDescLib Depends on complib, sxd_libs, applibs (1st & 2nd phases)
fi
cmake_defines+=" -DUSE_OBJ_DESC_LIB=${with_obj_desc_lib}"


if [ "x${ib_nvlink_package}" != "x1" ]; then
	sx_packages_third_phase="${sx_packages_third_phase} sx_hll_lib sx_pcc sx_acl_helper sx_hash_calc"
fi

deb_packages_fourth_phase="${deb_packages_fourth_phase} sx_acl_helper sx_pcc sx_hll_lib"
deb_packages_fifth_phase="${deb_packages_fifth_phase} sx_hash_calc"

if [ "x${with_wjh_lib}" == "x1" ]; then
	if [ "x${ib_nvlink_package}" != "x1" ]; then
		sx_packages_third_phase="${sx_packages_third_phase} wjh_libs "
	fi
	deb_packages_fifth_phase="${deb_packages_fifth_phase} wjh_libs"        # wjh_libs depend on sx_acl_helper
fi
cmake_defines+=" -DUSE_WJH_LIB=${with_wjh_lib}"

if [ "x${with_sx_examples}" == "x1" ]; then
	sx_packages_third_phase="${sx_packages_third_phase} sx_examples"
	deb_packages_fifth_phase="${deb_packages_fifth_phase} sx_examples"    # Depends on acl_rm in 4th phase
	sx_examples_configure_flags="${sx_examples_configure_flags}"
fi
cmake_defines+=" -DUSE_SX_EXAMPLES=${with_sx_examples}"

if [ "x${asan}" == "x1" ];then
	cmake_defines+=" -DCMAKE_BUILD_TYPE=asan"
fi

if [ "x${no_optimization}" == "x1" ] && [ "x${use_cmake}" == "x1" ] ; then
	print_info_and_stdout "In CMake build --no-optimization flag is ignored: Setting --enable-debug instead to enable no-optimization."
	user_level_debug_enabled="1"
fi


if [ "x${compile_release}" == "x1" ]; then
	if [ "x${use_cmake}" == "x0" ]; then
		print_info_and_stdout "-E- Build with --enable-release is valid only when CMake build requested (--use-cmake)"
		exit 1
	fi

	if [ "x${user_level_debug_enabled}" == "x1" ] || [ "x${no_optimization}" == "x1" ] || [ "x${asan}" == "x1" ]; then
		print_info_and_stdout "-E- Build with --enable-release not supported with --asan/--enable-debug/--no-optimization flags."
		exit 1
	fi

	cmake_defines+=" -DCMAKE_BUILD_TYPE=Release"
fi

if [ "x${user_level_debug_enabled}" == "x1" ]; then
	for p in ${sx_packages_third_phase} ${app_main_dir} ${sx_packages_first_phase}
	do
		eval "$(echo ${p}_additional_configure_flags)=\"$(echo \${${p}_additional_configure_flags} --enable-debug)\""
	done

	if [ "x${asan}" != "x1" ];then
		cmake_defines+=" -DCMAKE_BUILD_TYPE=Debug"
	fi
fi

if [ "x${enable_ecmp_sim}" == "x1" ]; then
	echo Ignore deprecated flag --enable-ecmp-simulator
fi

if [ "x${with_debug_info}" == "x1" ]; then
	sx_kernel_additional_configure_flags="${sx_kernel_additional_configure_flags} --with-debug-info"
	sx_kernel_extra_naming="${sx_kernel_extra_naming}.debug_info"
fi

if [ ! -z "${prefix}" ] ; then
	sxd_libs_additional_configure_flags="${sxd_libs_additional_configure_flags} --with-sxcomplib=${prefix}"
	applibs_additional_configure_flags="${applibs_additional_configure_flags} --with-sxdlibs=${prefix} --with-sxcomplib=${prefix} --with-sxgenutils=${prefix} --with-sxecmputil=${prefix}"
	sx_gen_utils_additional_configure_flags="${sx_gen_utils_additional_configure_flags} --with-sxcomplib=${prefix}"
	sx_eSMA_additional_configure_flags="${sx_eSMA_additional_configure_flags} --with-applibs=${prefix} --with-sxdlibs=${prefix} --with-sxcomplib=${prefix}"
	sx_examples_additional_configure_flags="${sx_examples_additional_configure_flags} --with-applibs=${prefix} --with-sxdlibs=${prefix} --with-sxcomplib=${prefix}"
	python_sdk_api_additional_configure_flags="${python_sdk_api_additional_configure_flags} --with-applibs=${prefix} --with-sxdlibs=${prefix} --with-sxcomplib=${prefix}"
	sx_obj_desc_lib_additional_configure_flags="${sx_obj_desc_lib_additional_configure_flags} --with-sxcomplib=${prefix}"
	sx_hll_lib_additional_configure_flags="${sx_hll_additional_configure_flags} --with-sxapplibs=${prefix} --with-sxcomplib=${prefix} --with-sxgenutils=${prefix}"
	sx_acl_helper_additional_configure_flags="${sx_acl_helper_additional_configure_flags} --with-sxapplibs=${prefix} --with-sxdlibs=${prefix} --with-sxcomplib=${prefix}"
	sx_pcc_additional_configure_flags="${sx_pcc_additional_configure_flags} --with-sxapplibs=${prefix} --with-sxcomplib=${prefix}"
	wjh_libs_additional_configure_flags="${wjh_libs_additional_configure_flags} --with-sxapplibs=${prefix} --with-sxdlibs=${prefix} --with-sxcomplib=${prefix}"
	sx_hash_calc_additional_configure_flags="${sx_hash_calc_additional_configure_flags} --with-sxapplibs=${prefix} --with-sxdlibs=${prefix} --with-sxcomplib=${prefix} --with-sxgenutils=${prefix}"

fi

if [ ! -z "${prefix}" ] ; then
	ex mkdir -p ${prefix}
	ex mkdir -p ${prefix}/bin
	configure_flags="${configure_flags} --prefix=${prefix}"
fi

if [ "x${use_cmake}" == "x0" ]; then
	if [ "x${no_optimization}" == "x1" ]; then
		CFLAGS="${CFLAGS} -O0"
	else
		CFLAGS="${CFLAGS} -O3"    # Since we don't go through SDK Makefile defaults (OPT ?= 3), Need to explicitly define here
	fi
fi

if [ "x${COVFILE}" != "x" ]; then
	# COVFILE enviroment variable indicate SDK build for code coverage run.
	# For CMake build, we need a toolchain configuration file, with path to Bullseye Coverage bin directory.
	cmake_defines+=" -DCMAKE_TOOLCHAIN_FILE=cmake/coverage_toolchain.cmake"
fi

if [ "x${ib_package}" == "x1" ]; then
	for p in ${app_main_dir} ${sx_packages_third_phase} sxd_libs
	do
		eval "$(echo ${p}_additional_configure_flags)=\"$(echo \${${p}_additional_configure_flags} --enable-ib)\""
	done
	if [ ! -z "${prefix}" ] ; then
		for p in ${app_main_dir} ${sx_packages_third_phase} sxd_libs
		do
			eval "$(echo ${p}_additional_configure_flags)=\"$(echo \${${p}_additional_configure_flags} --with-ibumad=${prefix} --with-ibmad=${prefix})\""
		done
	fi
fi

for p in ${sx_packages_first_phase} ${app_main_dir} ${sx_packages_third_phase}
do
	eval "$(echo ${p}_additional_configure_flags)=\"$(echo \${${p}_additional_configure_flags} CFLAGS=\\\\\\\"${CFLAGS}\\\\\\\" LDFLAGS=\\\\\\\"${LDFLAGS}\\\\\\\")\""
done

for p in sx_kernel sx_ib_kernel
do
	eval "$(echo ${p}_env_configure_flags)=\"$(echo \${${p}_env_configure_flags} KCFLAGS=\\\"${KCFLAGS}\\\")\""
	eval "$(echo ${p}_rpm_defines)=\"$(echo \${${p}_rpm_defines}) --define 'extra_make_options ${MAKE_FLAGS_SX_KERNEL}'\""
done

if [ "x${ib_package}" == "x1" ]; then
	sx_kernel_packages="${sx_kernel_packages} sx_ib_kernel"
	if [ "x${ib_precompiled}" == "x0" ]; then
		print_info_and_stdout "IB user tools MUST be precompiled (libibumad libibmad opensm infiniband_diags)"
	fi
fi

for p in sx_kernel sx_ib_kernel ${sx_packages_first_phase} ${app_main_dir} ${sx_packages_third_phase}
do
	if [ ! -z "$(eval echo \${${p}_additional_configure_flags})" ] ; then
		eval "$(echo ${p}_rpm_defines)=\"$(echo \${${p}_rpm_defines}) --define 'configure_options $(eval echo \${${p}_additional_configure_flags})'\""
		eval "$(echo ${p}_configure_flags)=\"$(echo \${${p}_configure_flags}) $(eval echo \${${p}_additional_configure_flags})\""
	fi
done

if [ ! -z "${sx_kernel_extra_naming}" ] ; then
	for p in sx_kernel sx_ib_kernel
	do
		eval "$(echo ${p}_rpm_defines)=\"$(echo \${${p}_rpm_defines} --define \'extra_release \${${p}_extra_naming}\')\""
	done
fi

uninstall_dest_folder=${prefix}/bin

###############################################################################
if [ "x${eth_package}" == "x1" ]; then
	sx_packages_second_phase="${sx_packages_second_phase} ${app_main_dir}"
	deb_packages_second_phase="${deb_packages_second_phase} ${app_main_dir}"
fi

if [ "x${disable_sx_kernel_packages_install}" == "x1" ]; then
	# Delete kernel packages list
	sx_kernel_packages=""
	cmake_defines+=" -DUSE_KERNEL=off"
fi

# creating packages list
sx_packages="${sx_kernel_packages}"
if [ ! "x${kernel_only}" == "x1" ];  then
	sx_packages="${sx_packages} ${sx_packages_first_phase} ${sx_packages_second_phase} ${sx_packages_third_phase}"
fi

if [ "${with_debug_info}" == "1" ]; then
	sx_packages_user_level_debug_info="${sx_packages_first_phase} ${app_main_dir} ${sx_packages_third_phase}"
fi

scew_configure_flags="--prefix ${scewlibs_install_folder}"

ex cd ${package_dir}
print_info_and_stdout "Installing sx sdk ${package_install_mode} for Linux"
print_info_and_stdout "Log file : ${LOGFILE}"
print_info_and_stdout "Starting installation at `date`..."

###############################################################################
#                     Reviewing Build System dependencies                     #
###############################################################################
test_root_available_storage 512000

# Clean old Packages
print_info_and_stdout "removing former Packages files from build folder ${topdir}/RPMS / ${topdir}/DEBIAN"
rm -rf ${topdir}/RPMS/*
rm -rf ${topdir}/DEBIAN/*
mkdir -p ${topdir}/{BUILD,RPMS,DEBIAN,SOURCES,SPECS,SRPMS}

# Clean old source code
if [ "x${disable_check_prev_install}" != "x1" -a "x${repackage}" == "x0" ] ; then
    check_prev_install
fi

# Add the uninstall_sx_sdk script
ex cp uninstall_sx_sdk.sh ${uninstall_dest_folder}
ex cp sdk_file_list.sh ${uninstall_dest_folder}
ex cp remove_legacy_vpi.sh ${uninstall_dest_folder}

# Check that a previous version is loaded
check_loaded_modules

echo "${topdir}" > ${src_path_location}

if [ "x${use_cmake}" == "x1" ]; then
    if [ "${use_sources}" != "1" ]; then
        cmake_defines+=" -DSKIP_DEPMOD_IN_INSTALL_PHASE=ON"
    fi
    if [ "${extract_sources}" == "1" ]; then
        cmake_extract_sources
    fi
    cmake_build_sources
    if [ "${use_sources}" == "1" ]; then
        cmake_install_sources
    elif [ "x${debian_detection}" != "x" ]; then
        cmake_pack_debian
        cmake_install_debian
    else
        cmake_pack_rpm
        cmake_install_rpm
    fi
elif [ "${use_sources}" == "1" ]; then
    if [ "${extract_sources}" == "1" ]; then
        extract_sources
    fi

    if [ "x${ib_package}" == "x1" ]; then
        sx_kernel_sx_ib_kernel_env_set
    fi
    build_sources
elif [ "x${debian_detection}" != "x" ]; then
    # Force debian build timestamp to be now and not taken from
    # last timestamp in file debian/changelog
    export DEB_BUILD_TIMESTAMP="$(date +%s)"
    export SOURCE_DATE_EPOCH="$DEB_BUILD_TIMESTAMP"

    if [ "x${kernel_only}" == "x1" ];  then                     		# Build DEB Files only for kernel packages
        if [ "x${sx_kernel_packages_build_only}" == "x1" ]; then
            for debian_package in  ${sx_kernel_packages}; do
                build_package_debian "${debian_package}"
            done
        else
            build_packages_debian_wrapper "${sx_kernel_packages}"
            for debian_package in ${sx_kernel_packages}; do install_package_debian "${debian_package}"; done
        fi
    else                                                            # Build all packages including SX_KERNEL
        # Phase 0
        if [ "x${ib_package}" == "x1" ]; then
            # In IB Mode DEB Build - Need to first finish with sx_kernel, only then move to sx_ib_kernel
            build_packages_debian_wrapper "${deb_packages_zero_phase}"
            for debian_package in ${deb_packages_zero_phase}; do install_package_debian "${debian_package}"; done

            for sx_kernel_pkg in ${sx_kernel_packages}; do
                build_packages_debian_wrapper "${sx_kernel_pkg}"
                install_package_debian "${sx_kernel_pkg}"
                if [ "${sx_kernel_pkg}" == "sx_kernel" ]; then
                    sx_kernel_sx_ib_kernel_env_set
                fi
            done
        else
            build_packages_debian_wrapper "${deb_packages_zero_phase} ${sx_kernel_packages}"
            for debian_package in ${deb_packages_zero_phase} ${sx_kernel_packages}; do install_package_debian "${debian_package}"; done
        fi

        # Phase 0.1
        build_packages_debian_wrapper "${deb_packages_zero_one_phase}"
        for debian_package in ${deb_packages_zero_one_phase}; do install_package_debian "${debian_package}"; done

        #Phase 1
        build_packages_debian_wrapper "${deb_packages_first_phase}"
        for debian_package in ${deb_packages_first_phase}; do install_package_debian "${debian_package}"; done

        #Phase 2
        build_packages_debian_wrapper "${deb_packages_second_phase}"
        for debian_package in ${deb_packages_second_phase}; do install_package_debian "${debian_package}"; done

        #Phase 3-5
        build_packages_debian_wrapper "${deb_packages_third_phase}"
        for debian_package in ${deb_packages_third_phase}; do install_package_debian "${debian_package}"; done

        build_packages_debian_wrapper "${deb_packages_fourth_phase}"
        for debian_package in ${deb_packages_fourth_phase}; do install_package_debian "${debian_package}"; done

        build_packages_debian_wrapper "${deb_packages_fifth_phase}"
        for debian_package in ${deb_packages_fifth_phase}; do install_package_debian "${debian_package}"; done
    fi
else    # Not debian
    copy_source_rpms
    if [ ! "x${kernel_only}" == "x1" ];  then
        build_and_install_packages "${sx_packages_first_phase}"

        build_and_install_packages "${sx_packages_second_phase}"

        additional_install_rpm_flags=" --nodeps"
        build_and_install_packages "${sx_packages_third_phase}"
        additional_install_rpm_flags=""

        for user_level_package in ${sx_packages_user_level_debug_info}
        do
            if [[ "${user_level_package}" != *"python_sdk_api"* ]]; then	# No debuginfo available for python sdk api RPMs
                install_binary_debuginfo_rpms ${user_level_package}
            fi
        done
    fi

    if [ "x${sx_kernel_packages_build_only}" != "x1" ]; then
        build_and_install_packages "${sx_kernel_packages}"
    else
        build_and_install_packages "${sx_kernel_packages}" "build_only"
    fi
fi

if [ "x${ib_package}" == "x1" ]; then
    lastrc_packages="sx_kernel sx_ib_kernel"
else
    lastrc_packages="sx_kernel"
fi
for lastrc_pointed_package in $lastrc_packages
do
    number_of_lastrc_packages=`ls ${topdir}/BUILD/${lastrc_pointed_package}-* -d 2>/dev/null | wc -l`
    if [ "x${number_of_lastrc_packages}" != "x0" ] ; then
        latest_package=`ls -td ${topdir}/BUILD/${lastrc_pointed_package}-* | head -n 1| cut -d":" -f 1`
        latest_package_pointer=${topdir}/BUILD/${lastrc_pointed_package}
        rm -f ${latest_package_pointer}
        ln -s ${latest_package} ${latest_package_pointer}
    fi
done

if [ "x$use_cross_compiler" == "x0" ]; then
    libsx_location=`find ${prefix}/lib* -name libsxdemad.so`
    if [ "x$libsx_location" != "x" ]; then
        libsx_folder=`dirname ${libsx_location}`
        echo "${libsx_folder}" > /etc/ld.so.conf.d/switchx_sdk.conf
        ldconfig || print_info_and_stdout "Warning: ldconfig command failed"
    fi
fi
if [ ${err} -eq 0 ]; then
	if [[ "${manual_prefix_set}" == "1" ]]; then
		print_info_and_stdout "NOTE: Custom prefix ${prefix} was set. For proper SDK Scripts usage, please run:"
		print_info_and_stdout "1) export PATH=\$PATH:${prefix}/usr/bin"
		print_info_and_stdout "2) export LD_LIBRARY_PATH=\$LD_LIBRARY_PATH:${prefix}/usr/lib"
		print_info_and_stdout "3) export SX_SDK_CUSTOM_PREFIX=${prefix}"
	fi

	print_info_and_stdout "Installation finished successfully."
	echo << END
	Done.
	Sources are at: ${topdir}/BUILD/<sx package>
	You can cd to a source tree, make modifications, and then:
	make && make install
END

else
	print_info_and_stdout "Installation finished with errors."
	print_info_and_stdout "See ${LOGFILE}"
fi

