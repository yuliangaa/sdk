#!/bin/bash
#
# Copyright (C) 2008-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
#
# This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
# (the "Company") and all right, title, and interest in and to the software product,
# including all associated intellectual property rights, are and shall
# remain exclusively with the Company.
#
# This software product is governed by the End User License Agreement
# provided with the software product.
#

ib_pre_package_list="opensm-devel opensm"
ib_packages_list="infiniband-diags opensm-libs \
	libibmad-devel libibmad \
	libibumad-devel libibumad"
ib_sbins_list="check_lft_balance.pl ibcheckerrors ibcheckportstate ibclearerrors ibhosts ibnetdiscover \
	ibprintrt.pl ibrouters ibsendtrap ibsysstat perfquery smpquery dump_lfts.sh ibcheckerrs ibcheckportwidth \
	ibdatacounters ibidsverify.pl ibnodes ibprintswitch.pl ibstat ibtracert saquery vendstat \
	dump_mfts.sh ibchecknet ibcheckstate ibdatacounts iblinkinfo ibping ibqueryerrors ibstatus \
	opensm set_nodedesc.sh ibaddr ibchecknode ibcheckwidth ibdiscover.pl iblinkinfo.pl ibportstate \
	ibqueryerrors.pl ibswitches opensm.bk sminfo ibcacheedit ibcheckport ibclearcounters ibfindnodesusing.pl \
	ibmirror ibprintca.pl ibroute ibswportwatch.pl mcm_rereg_test osmtest smpdump testleaks"
ib_includes=infiniband
sx_ib_script=/etc/init.d/openibd
openib_conf_script=/etc/infiniband/openib.conf

packages_list="${ib_packages_list}"

libs_list="libosmcomp libosmvendor libibmad libibnetdisc libibumad libopensm"

ib_man_list="ibnd_* umad_* \
	torus-2QoS.conf.5 \
	check_lft_balance.8 ibcheckerrors.8 ibcheckportstate.8 ibclearerrors.8 ibhosts.8 ibping.8 ibqueryerrors.8 ibswitches.8 opensm.8 smpdump.8 \
	dump_lfts.8 ibcheckerrs.8 ibcheckportwidth.8 ibdatacounters.8 ibidsverify.8 ibportstate.8 ibroute.8 ibswportwatch.8 osmtest.8 smpquery.8 \
	dump_mfts.8 ibchecknet.8 ibcheckstate.8 ibdatacounts.8 iblinkinfo.8 ibprintca.8 ibrouters.8 ibsysstat.8 perfquery.8 torus-2QoS.8 \
	ibaddr.8 ibchecknode.8 ibcheckwidth.8 ibdiscover.8 ibnetdiscover.8 ibprintrt.8 ibstat.8 ibtracert.8 saquery.8 vendstat.8 \
	ibcacheedit.8 ibcheckport.8 ibclearcounters.8 ibfindnodesusing.8 ibnodes.8 ibprintswitch.8 ibstatus.8 infiniband-diags.8 sminfo.8"

basedir=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

debian_detection=`grep -iE 'debian|buntu|mint' /etc/*release /etc/issue 2> /dev/null`

ex() {
	echo "EXEC: $@"
	eval $@
	if [ "$?" != "0" ]; then
		echo "$@   FAILED"
		exit 1
	fi
}

uninstall_all_instances() {
	package=$1
	instances=`rpm -qa | grep ${package}`
	if [ "XX" == "X${instances}X" ] ; then
		echo "No package found for ${package}"
	else
		for instance in ${instances}
		do
			echo "Uninstalling ${instance}"
			ex rpm -e ${instance}
		done
	fi
}

debian_package_name_transform(){
	echo $1 | sed -e 's/_/-/g' | awk  '{print tolower($0)}' | sed 's/devel/dev/'
}

debian_package_check_instances(){
	package=$1
	echo `dpkg-query -W -f='${Package} ' "${package}*" 2>&1 | grep -v "dpkg-query: no packages found matching*"`
}

debian_remove_packages(){
	instances="$@"
	echo "Uninstalling ${instances}"
	ex dpkg --force-all --remove "${instances}"
	ex dpkg --force-all --purge  "${instances}"
}

uninstall_all_debian_instances(){
	package=$1
	instances=$(debian_package_check_instances ${package})
	if [ "X" == "X${instances}" ] ; then
		echo "No package found for ${package}"
	else
		debian_remove_packages ${instances}
	fi
}

echo Closing IB

killall opensm

if [ -x ${sx_ib_script} ] ; then
	ex ${sx_ib_script} stop
fi

echo Removing IB packages

if [ "x$debian_detection" == "x" ] ; then
	for package_removed in ${ib_pre_package_list}
	do
		is_installed=`rpm -q ${package_removed} | grep "not installed"`
		if [ "x${is_installed}" == "x" ]; then
			rpm -e --allmatches ${package_removed}
		fi
	done

	for package_removed in ${packages_list}
	do
		uninstall_all_instances ${package_removed}
	done
else #Debian case
	for package_removed in ${ib_pre_package_list}
	do
		uninstall_all_debian_instances $(debian_package_name_transform ${package_removed})
		done

	for package_removed in ${packages_list}
	do
		uninstall_all_debian_instances $(debian_package_name_transform ${package_removed})
	done
fi

echo Removing any non-package libraries residues

pushd ${basedir} > /dev/null
for lib_removed in ${libs_list}
do
	rm -fv ../lib/${lib_removed}*
done

for include_remove in ${ib_includes}
do
	rm -rfv ../include/$include_remove
done

for sbin_remove in ${ib_sbins_list}
do
	rm -fv ../sbin/$sbin_remove
done

for man_remove in ${ib_man_list}
do
	rm -fv ../man/*/$man_remove
done

rm -fv ${openib_conf_script} ${sx_ib_script}

popd > /dev/null
rm -fv $0
