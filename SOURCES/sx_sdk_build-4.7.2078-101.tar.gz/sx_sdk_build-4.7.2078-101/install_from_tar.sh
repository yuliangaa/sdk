#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


ex() {
	echo "EXEC: $@"
	eval $@
	if [ "$?" != "0" ]; then
		echo "$@   FAILED"
		exit 1
	fi
}

print_error_and_fail() {
	echo "$@"
	echo "Target install failed"
	exit 1
}

test_root_available_storage() {
	limit=$1

	res_array=$(df / 2>/dev/null | grep / )

	current_space=`echo $res_array | cut -d " " -f 4 | sed -e "s/ //g" `

	if [ "x${current_space}" == "x" ] ; then
		print_error_and_fail "Invalid root partition available space: ${current_space}"
	fi

	non_numeric_current_space=`echo ${current_space} | sed -e "s/[0-9]//g"`

	if [ "x${non_numeric_current_space}" != "x" ] ; then
		print_error_and_fail "Invalid root partition available space: ${current_space}"
	fi

	if (( ${current_space} < ${limit} )) ; then
		print_error_and_fail "Insufficient root partition available space: ${current_space} KB < required ${limit} KB"
	fi

	echo "Sufficient root partition available space: ${current_space} KB >= required ${limit} KB"
}

usage() {
	echo "Usage: $0 <tarred objects package path>"
}

if [ "x$1" == "x" ] ; then
	usage
	exit 1
fi

if [ ! -e $1 ] ; then
	usage
	exit 1
fi

test_root_available_storage 100000

if [ "x$2" == "xi386" ] ; then
	echo "Stopping SDK on target"
	if [ -e /usr/bin/dvs_stop.sh ]; then
		ex /usr/bin/dvs_stop.sh
	fi
else
	echo "Uninstalling previous install on target"
	if [ -e /usr/bin/uninstall_sx_sdk.sh ]; then
		ex /usr/bin/uninstall_sx_sdk.sh
	fi
fi

echo "Installing content from $1"
ex tar --directory=/ -xzvf $1
if [ ! -e /sbin/pam_console_apply ]; then
	ex "echo \"#! /bin/sh\" > /sbin/pam_console_apply"
	ex "echo \"echo \\\$*\" >> /sbin/pam_console_apply"
	ex chmod +x /sbin/pam_console_apply
fi
echo "Running: depmod"
ex depmod

if [ "x$2" == "xi386" ] ; then
	device=`ls /dev/mst/*pciconf*|head -1|sed 's|/|\\\\/|g'`
	echo ${device}
	cp /usr/bin/get_system_type.sh /usr/bin/get_system_type.sh.orig
	sed s/mlnxsw-255/${device}/ /usr/bin/get_system_type.sh >/usr/bin/get_system_type.sh.new
	mv /usr/bin/get_system_type.sh.new /usr/bin/get_system_type.sh
	chmod a+x /usr/bin/get_system_type.sh
fi

