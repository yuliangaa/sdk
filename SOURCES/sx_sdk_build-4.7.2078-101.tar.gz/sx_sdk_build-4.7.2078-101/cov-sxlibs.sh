#!/bin/bash
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


make clean
if test $? = 1; then
echo make clean error
exit 1
fi
/swgwork/itaib/coverity/cov-sa-linux64-5.2.0/bin/cov-build --dir /swgwork/nimrod/coverity/sx_libs/ make
if test $? = 1; then
echo coverity make error
exit 2
fi
/swgwork/itaib/coverity/cov-sa-linux64-5.2.0/bin/cov-analyze --dir /swgwork/nimrod/coverity/sx_libs/
if test $? = 1; then
echo coverity analyze error
exit 3
fi
/swgwork/itaib/coverity/cov-sa-linux64-5.2.0/bin/cov-commit-defects --remote vnc1 --dataport 9090 --stream switchx --dir /swgwork/nimrod/coverity/sx_libs/ --user admin --password 3tango
if test $? = 1; then
echo coverity defect commit error
exit 4
fi
make clean
if test $? = 1; then
echo make clean error
exit 5
fi