#! /bin/sh
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


cp -v BLDS/build-sx_sdk_eth.in /mswg/projects/art/BLDS/build-sx_sdk_eth.in
cp -v BLDS/build-sx_sdk_vpi.in /mswg/projects/art/BLDS/build-sx_sdk_vpi.in