#!/bin/sh
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #


package_tested=$1

log_file=${package_tested}_code_style.txt

echo `date` > ${log_file}
for I in `find . | grep -e "\.c$\|\.h$\|Make*"` 
do 
	echo $I
	/swgwork/doront/patches/checkpatch.pl --file $I --strict --root /swgwork/doront/git_factory/sx-gits/sxd_kernel/ >> ${log_file} 
done

echo `date` >> ${log_file}


mail doront@mellanox.co.il -s ${log_file} < ${log_file}