#!/bin/tcsh
#
 # Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 #
 # This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 # (the "Company") and all right, title, and interest in and to the software product,
 # including all associated intellectual property rights, are and shall
 # remain exclusively with the Company.
 #
 # This software product is governed by the End User License Agreement
 # provided with the software product.
 #

set find = "/usr/bin/find"
set xargs = "/usr/bin/xargs"
set grep = "/bin/grep"
set tr = "/usr/bin/tr"
set sort = "/bin/sort"
set rm = "/bin/rm"
set wc = "/usr/bin/wc"
set cat = "/bin/cat"
set head = "/usr/bin/head"
set tail = "/usr/bin/tail"

if ( $?DEBUG ) then
	echo "find='$find'"
	echo "xargs='$xargs'"
	echo "grep='$grep'"
	echo "tr='$tr'"
	echo "sort='$sort'"
	echo "rm='$rm'"
	echo "wc='$wc'"
	echo "cat='$cat'"
endif

set out_dir = "./"
set suffix_in = ".in"

set files_filter = "output|output32"
set suffix = ""
set path = ""

set licenses = ('BSD' 'GPL' 'Copyright .* Mellanox Technologies Ltd')
set filename = ("BSD_license" "GPL_license" "MLX_license")

if ( "$1" != "skip" ) then
	
	while ($#argv)
		if ( $?DEBUG ) then
			echo '$1'"='$1', "'$2'"='$2'"
		endif
		switch($1:q)
		case -o:
			set out_dir = "$2"
			shift
			shift 
			breaksw;
		case -s:
			if ( "$suffix" == "" ) then
				set suffix = $2
			else
				set suffix = "$suffix$2"
			endif
			shift
			shift 
			breaksw;
		case -p:
			if ( "$path" == "" ) then
				set path = $2
			else
				set path = "$path $2"
			endif
			shift
			shift 
			breaksw;
		default:
			echo "ERROR: Unknown switch ($1)"
			exit 1
		endsw
	end

	if ( $?DEBUG ) then
		echo "OUTPUT-DIR='$out_dir'"
		echo "SEARCH-PATH(S)='$path'"
		echo "SEARCH-SUFFIX(S)='$suffix'"
	endif

	if ( "$suffix" == "" ) then
		echo "ERROR: Wanted suffix(es) not specified (use -s <suffix>)"
		exit 2
	endif
	# O/W:
	if ( "$path" == "" ) then
		echo "ERROR: Wanted path(s) not specified (use -p <path>)"
		exit 3
	endif
	# O/W:
	if ( ! -d "$out_dir" ) then
		echo "ERROR: Specified output directory (-o <directory>) is in valid"
		exit 4
	endif
	# O/W:
	foreach p (`echo $path`)
		if ( ! -d "$p" ) then
			echo "ERROR: Specified path directory (-p '$p') is in valid"
			exit 5
		endif
	end

	echo "Checking all files under the following path(s):"
	foreach p (`echo $path`)
		echo $p
	end

	echo "Which match the following suffix(es): *.[$suffix]"

	foreach i (1 2 3)
		$rm -rf $out_dir$filename[$i]$suffix_in
		echo "Writing to File: $out_dir$filename[$i]$suffix_in"
		$find `echo $path` -name "*.[$suffix]" | $xargs $grep -icEw "$licenses[$i]" | $grep -v ':0' | $grep -wvE "$files_filter" | $tr ":" "\n" | $grep -E "*.[$suffix]" | $sort -u >> "$out_dir$filename[$i]$suffix_in"
	end
else
	echo "Skipping files cheking (relying on previous script run)..."
endif

set filename = "ALL_license"

if ( "$1" != "skip" ) then
	echo "Writing to File: ${out_dir}$filename$suffix_in"
	$find `echo $path` -name "*.[$suffix]" | $grep -wvE "$files_filter" | $sort -u > "${out_dir}$filename$suffix_in"
endif

set suffix_out = ".out"

set out_files = (	"${out_dir}GPL+BSD+MLX$suffix_out"	"${out_dir}GPL+BSD$suffix_out"	"${out_dir}GPL+MLX$suffix_out"	"${out_dir}BSD+MLX$suffix_out"	"${out_dir}GPL$suffix_out"	"${out_dir}BSD$suffix_out"	"${out_dir}MLX$suffix_out"	"${out_dir}NONE$suffix_out")

if ( "$1" != "skip" ) then

	$rm -rf $out_files

	foreach file (`$cat ${out_dir}$filename$suffix_in`)
		# If found @ GPL:
		if ( "" != `$grep -w $file ${out_dir}GPL_license$suffix_in` ) then
			# If found @ GPL+BSD:
			if ( "" != `$grep -w $file ${out_dir}BSD_license$suffix_in` ) then
				# If found @ GPL+BSD+MLX (111):
				if ( "" != `$grep -w $file ${out_dir}MLX_license$suffix_in` ) then
					echo $file >> "${out_dir}GPL+BSD+MLX$suffix_out"
				# If found @ GPL+BSD (110):
				else
					echo $file >> "${out_dir}GPL+BSD$suffix_out"
				endif
			else	# If found @ GPL+MLX (101):
				if ( "" != `$grep -w $file ${out_dir}MLX_license$suffix_in` ) then
					echo $file >> "${out_dir}GPL+MLX$suffix_out"
				# If found @ GPL (100):
				else
					echo $file >> "${out_dir}GPL$suffix_out"
				endif
			endif
		else	# If found @ BSD:
			if ( "" != `$grep -w $file ${out_dir}BSD_license$suffix_in` ) then
				# If found @ BSD+MLX (011):
				if ( "" != `$grep -w $file ${out_dir}MLX_license$suffix_in` ) then
					echo $file >> "${out_dir}BSD+MLX$suffix_out"
				# If found @ BSD (010):
				else
					echo $file >> "${out_dir}BSD$suffix_out"
				endif
			else	# If found @ MLX (001):
				if ( "" != `$grep -w $file ${out_dir}MLX_license$suffix_in` ) then
					echo $file >> "${out_dir}MLX$suffix_out"
				# If found @ none of the above (000):
				else
					echo $file >> "${out_dir}NONE$suffix_out"
				endif
			endif
		endif
	end
endif

echo "###########"
echo "Statistics:"
echo "###########"

echo -n ALL": "
$wc -l ${out_dir}$filename$suffix_in | $tr " " "\n" | $head -1

foreach file ('GPL+BSD+MLX' 'BSD+MLX' 'GPL+MLX' 'GPL+BSD' 'GPL' 'BSD' 'MLX' 'NONE')
	echo -n $file": "
	if ( -f "${out_dir}${file}$suffix_out" ) then
		$wc -l "${out_dir}${file}$suffix_out" | $tr " " "\n" | $head -1
	else
		echo "0"
	endif
end