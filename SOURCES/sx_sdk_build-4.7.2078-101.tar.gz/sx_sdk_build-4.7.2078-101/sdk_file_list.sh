#!/bin/bash
#
# SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#


packages_list="sx_eSMA \
	       python_sdk_api \
	       sx_examples-devel sx_examples \
	       sx_topo_manager \
	       wjh_libs-devel wjh_libs \
		   sx_hash_calc \
	       sx_acl_helper-devel sx_acl_helper \
	       sx_pcc-devel sx_pcc \
	       sx_obj_desc_lib-devel sx_obj_desc_lib \
	       sx_hll_lib-devel sx_hll_lib \
	       applibs-devel applibs \
	       sx_scew-devel sx_scew \
	       sxd_libs-devel sxd_libs \
	       sx_gen_utils-devel sx_gen_utils \
	       sx_complib-devel sx_complib \
	       sx_libs-devel sx_libs \
	       sx_ib_kernel-devel sx_ib_kernel \
	       sx_kernel-devel sx_kernel \
	       sx_sdk_build \
	       sys_sdk"

libs_list="libscew \
	   libsxapi libsxcore libsxrouter libsxhostifc libsxutils libsxatcam libsxacl libsxnet libsxregbulk \
	   libsxflow_counter libsxbulk_counter libsxpolicer libsxspan libsxtimer libsxkvd libsxpgt libsxgc libsxlinear_manager \
	   libsdkhwdmccontainer libsdkmccontainer \
	   libsxmpem \
	   libsxib libsxibl2 libsxibl3 libsxtcal3 libsw_hwd_rm libsw_rm libsxbrg libsxtele \
	   libsxcomp libsxlog libsxrpc \
	   libsxgenutils libsxecmputil\
	   libsxdemad libsxdemadparser libsxdev libsxcom libsxdreg_access \
	   libsxobjdesc \
	   libsxhll \
	   libsxaclhelper \
	   libsxpcc \
	   libwjh \
	   libwjhhelper \
	   libevblog libsdkd libutils \
	   libsxsniffer \
	   libsxdsniffer \
	   libsxdbg libsxdbgdumpmodules libsdkrouter libroutercom \
	   libsdkbridge \
	   libsxcm \
	   libbridgecom \
	   libsdkpolicer \
	   libpolicercom \
	   libsxtunnel \
	   libtunnel \
	   libsxissu \
       libsxmpls \
	   sx_api \
	   sx_api_eldk54 \
	   sxd_lib \
       libsxworkqp \
       libcraccess \
       libsxd_fw_dbg \
       libsxd_fw_trace \
       libautoreg \
       libsdkmpls \
       libsxtidm \
       libsxflexparser \
	   sxd_libs_eldk54 \
	   libsxbfd \
	   libsxadviser \
	   libsxxm \
       libsxptp \
       libsxregister \
       libsxstatefuldb \
       libsxflexmodifier \
        libmgmt \
        libsdkmgmt \
        libmgmtcom \
        libsxadaptive_routing\
        libsxmacsec libsxmacsechwd\
        libsxadaptive_routing \
        libsxflexpm\
       libsxtruncationprofile"


libs64_list="libclish liblub libtinyrl libtinyxml"

kernel_modules_dir_list="kernel/drivers/net/mlx_sx \
                         kernel/drivers/net/sx_* \
                         ${ib_kernel_modules_dir_list}"

include_list="complib scew sx resource_manager resource_manager_int wjh"

bin_list="sx_*.py* sx_*.sh* sxd_*.py* internal/sx_*.py* internal/sxd_*.py* internal/README.txt common_infra_acl.py* \
	   flex_acl_common.py* test_infra_common.py* sdk_api_cli.py* *.so chassis_manager resources_manager evb_manager \
           run_chassis.sh run_resources.sh run_evb_manager.sh sx_sdk sx_sdk_ib_load.sh sx_sdk_eth_load.sh \
           sx_sdk_vpi_load.sh *_eth_start.sh *ib_start.sh *ib2_start.sh *_vpi_start.sh \
           *_spectrum_start.sh evb_start.sh evb_stop.sh evb_restart.sh \
           switchx_sma get_system_type.sh dvs_manager run_dvs_manager.sh dvs_start.sh dvs_stop.sh \
           sx_player sx_player_start.sh sx_debug_cmd_client emad_dump.sh sx_debug_shell.sh sxd_player emad_listener sxd_sniffer_delete_shm\
           sdk_file_list.sh remove_legacy_vpi.sh wjh_example wjh_example.py wjh_example_backend.py wjh_dissector.lua sx_obj_desc_example sx_obj_desc_example.py \
           sx_filter_maker.py filter.mapping filter_sample.txt sx_def_filter wjh_netlink_example.py sx_hll_example sx_hash_calculator"

share_list="evb_manager_*.xml dvs_manager_*.xml sx_fw_dump"

exp_list="6502_eth_start.sh 6506_eth_start.sh 6518_eth_start.sh 65XX_start.sh evb_manager_eth_6506.xml evb_manager_eth_6518.xml evb_manager_ib_6502.xml 6502_ib_start.sh 6512_eth_start.sh 6536_eth_start.sh evb_manager_eth_6502.xml evb_manager_eth_6512.xml evb_manager_eth_6536.xml"

etc_list="wjh_lib_conf.xml wjh_linux_channel_tp.yaml"
